
//--TRIMMABLE-BOUNDARY-START(59945)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $WXSuKd;
    let $uyZAKf;
    let $DUXcbg;
    let $mdCthl;
    let $ZdVClf;
    let $axAqhb;
    let $iMxyaf;
    let $WrfGFj;
    let $DOpcxc;
    let $QnRFri;
    let $vZabuj;
    let $dAdHdd;
    let $TywXfb;
    let $jvpmob;
    let $cYQKBa;
    let $vfpJIj;
    let $fFZgGa;
    let $KZnWwc;
    let $gJrPjj;
    let $Vijrbk;
    let $TAMqwb;
    let $RFySZh;
    let $vvMaAe;
    let $xGAwNk;
    let $PmSjgk;
    let $nNPRya;
    let $vvOsLe;
    let $gpTCUd;
    let $Tkoidi;
    let $buxyWe;
    let $oVfAfl;
    let $zFSJra;
    let $Sbqcsc;
    let $ZEsMIc;
    let $MDahGb;
    let $xpkrdd;
    let $sIznsb;
    let $PxRQGj;
    let $yJiJoh;
    let $kkexjh;
    let $AbrmUh;
    let $KsGijc;
    let $MNtAFg;
    let $UACghk;
    let $mXUHIg;
    let $sTtNlj;
    let $jLyqgh;
    let $uzRNMf;
    let $hPvuNa;
    let $AMvTHk;
    let $mbYuEa;
    let $nxwIfh;
    let $NiySUg;
    let $AenxBb;
    let $izaZMd;
    let $FmnAEa;
    let $foCxDk;
    let $HXqypd;
    let $CkguZe;
    let $WNPoHg;
    let $SDYSMf;
    let $udBYMc;
    let $ISbHuj;
    let $rnbUlk;
    let $EfyhIc;
    let $jknued;
    let $zGaOCc;
    let $VAYPce;
    let $SekOeh;
    let $UXrqDc;
    let $ImolKa;
    let $sFdGVb;
    let $iXcEkh;
    let $KOyQlk;
    let $IULDVe;
    let $rcArMh;
    let $iiWbjf;
    let $JfPisa;
    let $xnqOvj;
    let $ubclGk;
    let $uYjAAk;
    let $ChklCi;
    let $zrASoe;
    let $FkpWTf;
    let $nWIiDh;
    let $Qdoilc;
    let $RNRARj;
    let $csOJda;
    let $ETRhIk;
    let $VPpuqc;
    let $TtheNe;
    let $TdFFQc;
    let $OruvKa;
    let $yzerfh;
    let $tAtdYb;
    let $ixuXbk;
    let $asBSdk;
    let $BUwKTe;
    let $cIPtqb;
    let $UMAvsf;
    let $WRzVgc;
    let $bzwqMk;
    let $ILgFBh;
    let $TpJqMe;
    let $QLYsfh;
    let $LZgSDd;
    let $RMuVck;
    let $ZcTeJh;
    let $vfwyig;
    let $wLSHhj;
    let $IKKwbb;
    let $EjYeVf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Election.Common", 
    {
  "h": 59945,
  "f": "LivingThing.Core.Community.Election.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Election.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Election.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(649769)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionCategoryModelCustomAttributesProvider`, ($self) => class CommunityElectionCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295617065)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295617065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$TBFc.LCCECM.CommunityElectionCategoryModel, $.$TBFc.LCCECM.CommunityElectionPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295617065)
            
            static $h = 649769;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295617065),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 649769,
      "h": 4295617065,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295617065)
  ],
  "h": 649769
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(649769)
        
        

        //--TRIMMABLE-BOUNDARY-START(125481)
        $asm.$cls(`$TBFc.LCCEC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295092777)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295092777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$TBFc.LCCECM.CommunityElectionCandidateModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelCustomAttributesProvider, $.$TBFc.LCCECM.CommunityElectionCandidateModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$TBFc.LCCECM.CommunityElectionCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$TBFc.LCCECM.CommunityElectionCategoryModelCustomAttributesProvider, $.$TBFc.LCCECM.CommunityElectionCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$TBFc.LCCECM.CommunityElectionFeatureModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$TBFc.LCCECM.CommunityElectionFeatureModelCustomAttributesProvider, $.$TBFc.LCCECM.CommunityElectionFeatureModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$TBFc.LCCECM.CommunityElectionModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$TBFc.LCCECM.CommunityElectionModelCustomAttributesProvider, $.$TBFc.LCCECM.CommunityElectionModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$TBFc.LCCECM.CommunityElectionPositionModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$TBFc.LCCECM.CommunityElectionPositionModelCustomAttributesProvider, $.$TBFc.LCCECM.CommunityElectionPositionModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$TBFc.LCCECM.CommunityElectionState.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$TBFc.LCCECM.CommunityElectionStateCustomAttributesProvider, $.$TBFc.LCCECM.CommunityElectionStateCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$TBFc.LCCECM.CommunityElectionPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelCustomAttributesProvider, $.$TBFc.LCCECM.CommunityElectionPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$TBFc.LCCECM.CommunityElectionVoteModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$TBFc.LCCECM.CommunityElectionVoteModelCustomAttributesProvider, $.$TBFc.LCCECM.CommunityElectionVoteModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$TBFc.LCCECS$1.CommunityElectionSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$TBFc.LCCECS$1.CommunityElectionSettingsCustomAttributesProvider, $.$TBFc.LCCECS$1.CommunityElectionSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$TBFc.LCCECS$2.CommunityElectionStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$TBFc.LCCECS$2.CommunityElectionStatesCustomAttributesProvider, $.$TBFc.LCCECS$2.CommunityElectionStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295092777)
            
            static $h = 125481;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295092777),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 125481,
      "h": 4295092777,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295092777)
  ],
  "h": 125481
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(125481)
        
        

        //--TRIMMABLE-BOUNDARY-START(1960489)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionStateCustomAttributesProvider`, ($self) => class CommunityElectionStateCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296927785)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296927785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296927785)
            
            static $h = 1960489;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296927785),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1960489,
      "h": 4296927785,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296927785)
  ],
  "h": 1960489
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionStateCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionStateCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1960489)
        
        

        //--TRIMMABLE-BOUNDARY-START(191017)
        $asm.$cls(`$TBFc.LCCEC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295158313)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295158313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295158313)
            
            static $h = 191017;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295158313),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 191017,
      "h": 4295158313,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295158313)
  ],
  "h": 191017
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(191017)
        
        

        //--TRIMMABLE-BOUNDARY-START(3009065)
        $asm.$cls(`$TBFc.LCCECS$2.CommunityElectionStatesCustomAttributesProvider`, ($self) => class CommunityElectionStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297976361)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297976361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297976361)
            
            static $h = 3009065;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297976361),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3009065,
      "h": 4297976361,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297976361)
  ],
  "h": 3009065
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.States.CommunityElectionStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}States${separator}CommunityElectionStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3009065)
        
        

        //--TRIMMABLE-BOUNDARY-START(911913)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionFeatureModelCustomAttributesProvider`, ($self) => class CommunityElectionFeatureModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295879209)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295879209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.AccountFeatureModelCustomAttributesProvider$$($.$TBFc.LCCECM.CommunityElectionFeatureModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295879209)
            
            static $h = 911913;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295879209),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 911913,
      "h": 4295879209,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295879209)
  ],
  "h": 911913
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionFeatureModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionFeatureModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(911913)
        
        

        //--TRIMMABLE-BOUNDARY-START(1436201)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionPositionModelCustomAttributesProvider`, ($self) => class CommunityElectionPositionModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296403497)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296403497)
            
            //--TRIMMABLE-BOUNDARY-START(8591370793)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591370793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$TBFc.LCCECM.CommunityElectionPositionModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("VotingFee", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1024);
                            $i3.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DisableSelfVote", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (1028);
                            $i4.Description = "Don't someone to vote themself for this position";
                            $i4.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-cash"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$TBFc.LCCECM.CommunityElectionPositionModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $WXSuKd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1436201,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $uyZAKf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1436201,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591370793)
            
            static $h = 1436201;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591370793),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1436201,
      "h": 8591370793,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591370793)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296403497),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1436201,
      "h": 4296403497,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296403497)
  ],
  "h": 1436201
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionPositionModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1436201)
        
        

        //--TRIMMABLE-BOUNDARY-START(3140137)
        $asm.$cls(`$TBFc.LCCECS$2.CommunityElectionStatesTypeDescriptorBuilder`, ($self) => class CommunityElectionStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593074729)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593074729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$TBFc.LCCECS$2.CommunityElectionStatesTypeDescriptor()
                        const $t1 = $.$TBFc.LCCECS$2.CommunityElectionStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Election.Common.States.CommunityElectionStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $DUXcbg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3140137,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$TBFc.LCCECS$2.CommunityElectionStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593074729)
            
            //--TRIMMABLE-BOUNDARY-START(4298107433)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298107433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298107433)
            
            //--TRIMMABLE-BOUNDARY-START(4298107433)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298107433)
            
            static $h = 3140137;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593074729),
    {
      "r": 65537,
      "n": "Register",
      "d": 3140137,
      "h": 8593074729,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593074729)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298107433),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3140137,
      "h": 4298107433,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298107433)
  ],
  "h": 3140137
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.States.CommunityElectionStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}States${separator}CommunityElectionStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3140137)
        
        

        //--TRIMMABLE-BOUNDARY-START(1698345)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionPostModelCustomAttributesProvider`, ($self) => class CommunityElectionPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296665641)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296665641)
            
            //--TRIMMABLE-BOUNDARY-START(8591632937)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591632937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$TBFc.LCCECM.CommunityElectionPostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(11, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("StartDate", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1024);
                            $i3.Description = "The date the election is starting";
                            $i3.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-calendar"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("EndDate", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (1025);
                            $i4.Description = "The date the election is ending";
                            $i4.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-calendar"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("NominationFee", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (1026);
                            $i5.Description = "How much to nominate member";
                            $i5.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-cash"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SelfNomination", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (1027);
                            $i6.Description = "Allow member to nominate themself";
                            $i6.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-cash"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SingleNomination", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (1028);
                            $i7.Description = "Allow members to nominate only once";
                            $i7.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i7.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-cash"], [-1], null);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DisableSelfVote", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (1029);
                            $i8.Description = "Don't allow candidate to vote for themself";
                            $i8.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i8.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-cash"], [-1], null);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Candidates", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Positions", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PositionLabel", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CandidateLabel", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("State", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t13 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$4();
                            $i13.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$TBFc.LCCECM.CommunityElectionPostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $DOpcxc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1698345,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $QnRFri ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1698345,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$TBFc.LCCECM.CommunityElectionCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591632937)
            
            static $h = 1698345;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591632937),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1698345,
      "h": 8591632937,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591632937)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296665641),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1698345,
      "h": 4296665641,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296665641)
  ],
  "h": 1698345
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1698345)
        
        

        //--TRIMMABLE-BOUNDARY-START(1174057)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionModelCustomAttributesProvider`, ($self) => class CommunityElectionModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296141353)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296141353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$TBFc.LCCECS$1.CommunityElectionSettings, $.$TBFc.LCCECS$2.CommunityElectionStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296141353)
            
            static $h = 1174057;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296141353),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1174057,
      "h": 4296141353,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296141353)
  ],
  "h": 1174057
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1174057)
        
        

        //--TRIMMABLE-BOUNDARY-START(2877993)
        $asm.$cls(`$TBFc.LCCECS$1.CommunityElectionSettingsTypeDescriptorBuilder`, ($self) => class CommunityElectionSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592812585)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592812585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$TBFc.LCCECS$1.CommunityElectionSettingsTypeDescriptor()
                        const $t1 = $.$TBFc.LCCECS$1.CommunityElectionSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Election.Common.Settings.CommunityElectionSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ZdVClf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2877993,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$TBFc.LCCECS$1.CommunityElectionSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592812585)
            
            //--TRIMMABLE-BOUNDARY-START(4297845289)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297845289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297845289)
            
            //--TRIMMABLE-BOUNDARY-START(4297845289)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297845289)
            
            static $h = 2877993;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592812585),
    {
      "r": 65537,
      "n": "Register",
      "d": 2877993,
      "h": 8592812585,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592812585)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297845289),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2877993,
      "h": 4297845289,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297845289)
  ],
  "h": 2877993
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Settings.CommunityElectionSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Settings${separator}CommunityElectionSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2877993)
        
        

        //--TRIMMABLE-BOUNDARY-START(2157097)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionVoteModelCustomAttributesProvider`, ($self) => class CommunityElectionVoteModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297124393)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297124393)
            
            //--TRIMMABLE-BOUNDARY-START(8592091689)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592091689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$TBFc.LCCECM.CommunityElectionVoteModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Position", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Candidate", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$TBFc.LCCECM.CommunityElectionVoteModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $TywXfb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2157097,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $jvpmob ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2157097,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592091689)
            
            static $h = 2157097;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592091689),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2157097,
      "h": 8592091689,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592091689)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297124393),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2157097,
      "h": 4297124393,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297124393)
  ],
  "h": 2157097
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionVoteModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2157097)
        
        

        //--TRIMMABLE-BOUNDARY-START(780841)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionCategoryModelTypeDescriptorBuilder`, ($self) => class CommunityElectionCategoryModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590715433)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590715433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$TBFc.LCCECM.CommunityElectionCategoryModelTypeDescriptor()
                        const $t1 = $.$TBFc.LCCECM.CommunityElectionCategoryModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $cYQKBa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":780841,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$TBFc.LCCECM.CommunityElectionCategoryModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590715433)
            
            //--TRIMMABLE-BOUNDARY-START(4295748137)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295748137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295748137)
            
            //--TRIMMABLE-BOUNDARY-START(4295748137)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295748137)
            
            static $h = 780841;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590715433),
    {
      "r": 65537,
      "n": "Register",
      "d": 780841,
      "h": 8590715433,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590715433)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295748137),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 780841,
      "h": 4295748137,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295748137)
  ],
  "h": 780841
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionCategoryModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(780841)
        
        

        //--TRIMMABLE-BOUNDARY-START(3205673)
        $asm.$cls(`$TBFc.LCCEC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298172969)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298172969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptorBuilder.Register();
                $.$TBFc.LCCECM.CommunityElectionCategoryModelTypeDescriptorBuilder.Register();
                $.$TBFc.LCCECM.CommunityElectionFeatureModelTypeDescriptorBuilder.Register();
                $.$TBFc.LCCECM.CommunityElectionModelTypeDescriptorBuilder.Register();
                $.$TBFc.LCCECM.CommunityElectionPositionModelTypeDescriptorBuilder.Register();
                $.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptorBuilder.Register();
                $.$TBFc.LCCECM.CommunityElectionVoteModelTypeDescriptorBuilder.Register();
                $.$TBFc.LCCECS$1.CommunityElectionSettingsTypeDescriptorBuilder.Register();
                $.$TBFc.LCCECS$2.CommunityElectionStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298172969)
            
            static $h = 3205673;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298172969),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3205673,
      "h": 4298172969,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298172969)
  ],
  "h": 3205673
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3205673)
        
        

        //--TRIMMABLE-BOUNDARY-START(1305129)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionModelTypeDescriptorBuilder`, ($self) => class CommunityElectionModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591239721)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591239721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$TBFc.LCCECM.CommunityElectionModelTypeDescriptor()
                        const $t1 = $.$TBFc.LCCECM.CommunityElectionModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Election.Common.Models.CommunityElectionModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iMxyaf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1305129,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$TBFc.LCCECM.CommunityElectionModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591239721)
            
            //--TRIMMABLE-BOUNDARY-START(4296272425)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296272425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296272425)
            
            //--TRIMMABLE-BOUNDARY-START(4296272425)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296272425)
            
            static $h = 1305129;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591239721),
    {
      "r": 65537,
      "n": "Register",
      "d": 1305129,
      "h": 8591239721,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591239721)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296272425),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1305129,
      "h": 4296272425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296272425)
  ],
  "h": 1305129
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1305129)
        
        

        //--TRIMMABLE-BOUNDARY-START(1567273)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionPositionModelTypeDescriptorBuilder`, ($self) => class CommunityElectionPositionModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591501865)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591501865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$TBFc.LCCECM.CommunityElectionPositionModelTypeDescriptor()
                        const $t1 = $.$TBFc.LCCECM.CommunityElectionPositionModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $HXqypd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1567273,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$TBFc.LCCECM.CommunityElectionPositionModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591501865)
            
            //--TRIMMABLE-BOUNDARY-START(4296534569)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296534569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296534569)
            
            //--TRIMMABLE-BOUNDARY-START(4296534569)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296534569)
            
            static $h = 1567273;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591501865),
    {
      "r": 65537,
      "n": "Register",
      "d": 1567273,
      "h": 8591501865,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591501865)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296534569),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1567273,
      "h": 4296534569,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296534569)
  ],
  "h": 1567273
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionPositionModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1567273)
        
        

        //--TRIMMABLE-BOUNDARY-START(1829417)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptorBuilder`, ($self) => class CommunityElectionPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591764009)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591764009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor()
                        const $t1 = $.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ETRhIk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1829417,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$TBFc.LCCECM.CommunityElectionPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591764009)
            
            //--TRIMMABLE-BOUNDARY-START(4296796713)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296796713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296796713)
            
            //--TRIMMABLE-BOUNDARY-START(4296796713)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296796713)
            
            static $h = 1829417;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591764009),
    {
      "r": 65537,
      "n": "Register",
      "d": 1829417,
      "h": 8591764009,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591764009)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296796713),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1829417,
      "h": 4296796713,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296796713)
  ],
  "h": 1829417
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1829417)
        
        

        //--TRIMMABLE-BOUNDARY-START(1042985)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionFeatureModelTypeDescriptorBuilder`, ($self) => class CommunityElectionFeatureModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590977577)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590977577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$TBFc.LCCECM.CommunityElectionFeatureModelTypeDescriptor()
                        const $t1 = $.$TBFc.LCCECM.CommunityElectionFeatureModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Election.Common.Models.CommunityElectionFeatureModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $vZabuj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1042985,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$TBFc.LCCECM.CommunityElectionFeatureModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590977577)
            
            //--TRIMMABLE-BOUNDARY-START(4296010281)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296010281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296010281)
            
            //--TRIMMABLE-BOUNDARY-START(4296010281)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296010281)
            
            static $h = 1042985;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590977577),
    {
      "r": 65537,
      "n": "Register",
      "d": 1042985,
      "h": 8590977577,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590977577)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296010281),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1042985,
      "h": 4296010281,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296010281)
  ],
  "h": 1042985
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionFeatureModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionFeatureModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1042985)
        
        

        //--TRIMMABLE-BOUNDARY-START(256553)
        $asm.$cls(`$TBFc.LCCEC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295223849)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295223849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$TBFc.LCCECS.ICommunityElectionFeedRemoteService, $.$TBFc.LCCECS.ICommunityElectionFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCCECS.ICommunityElectionFeedRemoteService_Mocking().$ctor$3(impl);
                }, $Vijrbk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$TBFc.LCCECS.ICommunityElectionFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCCECS.ICommunityElectionFeedRemoteService_Mocking().$ctor$3(impl);
                }, $TAMqwb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$TBFc.LCCECS.IComunityElectionRemoteService, $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking().$ctor$3(impl);
                }, $RFySZh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking().$ctor$3(impl);
                }, $vvMaAe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking().$ctor$3(impl);
                }, $xGAwNk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking().$ctor$3(impl);
                }, $PmSjgk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking().$ctor$3(impl);
                }, $nNPRya ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking().$ctor$3(impl);
                }, $vvOsLe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking().$ctor$3(impl);
                }, $gpTCUd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCCECS.IComunityElectionRemoteService_Mocking().$ctor$3(impl);
                }, $Tkoidi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking().$ctor$3(impl);
                }, $buxyWe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking().$ctor$3(impl);
                }, $oVfAfl ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking().$ctor$3(impl);
                }, $zFSJra ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking().$ctor$3(impl);
                }, $Sbqcsc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking().$ctor$3(impl);
                }, $ZEsMIc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking().$ctor$3(impl);
                }, $MDahGb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking().$ctor$3(impl);
                }, $xpkrdd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking().$ctor$3(impl);
                }, $sIznsb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking().$ctor$3(impl);
                }, $PxRQGj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking().$ctor$3(impl);
                }, $yJiJoh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking().$ctor$3(impl);
                }, $kkexjh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking().$ctor$3(impl);
                }, $AbrmUh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking().$ctor$3(impl);
                }, $KsGijc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking().$ctor$3(impl);
                }, $MNtAFg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking().$ctor$3(impl);
                }, $UACghk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking().$ctor$3(impl);
                }, $mXUHIg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking().$ctor$3(impl);
                }, $sTtNlj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking().$ctor$3(impl);
                }, $jLyqgh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking().$ctor$3(impl);
                }, $uzRNMf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking().$ctor$3(impl);
                }, $hPvuNa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking().$ctor$3(impl);
                }, $AMvTHk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking().$ctor$3(impl);
                }, $mbYuEa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking().$ctor$3(impl);
                }, $nxwIfh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking().$ctor$3(impl);
                }, $NiySUg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking().$ctor$3(impl);
                }, $AenxBb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking().$ctor$3(impl);
                }, $izaZMd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking().$ctor$3(impl);
                }, $FmnAEa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking().$ctor$3(impl);
                }, $foCxDk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256553,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295223849)
            
            static $h = 256553;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295223849),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 256553,
      "h": 4295223849,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295223849)
  ],
  "h": 256553
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(256553)
        
        

        //--TRIMMABLE-BOUNDARY-START(2288169)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionVoteModelTypeDescriptorBuilder`, ($self) => class CommunityElectionVoteModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592222761)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592222761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$TBFc.LCCECM.CommunityElectionVoteModelTypeDescriptor()
                        const $t1 = $.$TBFc.LCCECM.CommunityElectionVoteModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $EfyhIc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2288169,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$TBFc.LCCECM.CommunityElectionVoteModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592222761)
            
            //--TRIMMABLE-BOUNDARY-START(4297255465)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297255465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297255465)
            
            //--TRIMMABLE-BOUNDARY-START(4297255465)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297255465)
            
            static $h = 2288169;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592222761),
    {
      "r": 65537,
      "n": "Register",
      "d": 2288169,
      "h": 8592222761,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592222761)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297255465),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2288169,
      "h": 4297255465,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297255465)
  ],
  "h": 2288169
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionVoteModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2288169)
        
        

        //--TRIMMABLE-BOUNDARY-START(387625)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionCandidateModelCustomAttributesProvider`, ($self) => class CommunityElectionCandidateModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295354921)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295354921)
            
            //--TRIMMABLE-BOUNDARY-START(8590322217)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590322217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$TBFc.LCCECM.CommunityElectionCandidateModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(7, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Role", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Election", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Position", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("NomineeAccount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Account", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Nominations", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Votes", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$TBFc.LCCECM.CommunityElectionCandidateModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $KZnWwc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":387625,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $gJrPjj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":387625,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590322217)
            
            static $h = 387625;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590322217),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 387625,
      "h": 8590322217,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590322217)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295354921),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 387625,
      "h": 4295354921,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295354921)
  ],
  "h": 387625
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionCandidateModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(387625)
        
        

        //--TRIMMABLE-BOUNDARY-START(2746921)
        $asm.$cls(`$TBFc.LCCECS$1.CommunityElectionSettingsCustomAttributesProvider`, ($self) => class CommunityElectionSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297714217)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297714217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297714217)
            
            static $h = 2746921;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297714217),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2746921,
      "h": 4297714217,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297714217)
  ],
  "h": 2746921
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Settings.CommunityElectionSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Settings${separator}CommunityElectionSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2746921)
        
        

        //--TRIMMABLE-BOUNDARY-START(518697)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptorBuilder`, ($self) => class CommunityElectionCandidateModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590453289)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590453289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor()
                        const $t1 = $.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $sFdGVb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":518697,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$TBFc.LCCECM.CommunityElectionCandidateModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590453289)
            
            //--TRIMMABLE-BOUNDARY-START(4295485993)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295485993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295485993)
            
            //--TRIMMABLE-BOUNDARY-START(4295485993)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295485993)
            
            static $h = 518697;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590453289),
    {
      "r": 65537,
      "n": "Register",
      "d": 518697,
      "h": 8590453289,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590453289)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295485993),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 518697,
      "h": 4295485993,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295485993)
  ],
  "h": 518697
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionCandidateModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(518697)
        
        

        //--TRIMMABLE-BOUNDARY-START(2353705)
        $asm.$cls(`$TBFc.LCCEC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592288297)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592288297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$TBFc.LCCECM.CommunityElectionCategoryModel, 10754/*PostTypes.ElectionCategory*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$TBFc.LCCECM.CommunityElectionPostModel, 10753/*PostTypes.ElectionPost*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$TBFc.LCCECM.CommunityElectionCandidateModel, 10756/*PostTypes.ElectionCandidate*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$TBFc.LCCECM.CommunityElectionPositionModel, 10755/*PostTypes.ElectionPosition*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$TBFc.LCCECM.CommunityElectionVoteModel, 10757/*PostTypes.ElectionVote*/);
                $.$TBFc.LCCEC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$TBFc.LCCEC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$TBFc.LCCEC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592288297)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$TBFc.LCCEC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297321001)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297321001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297321001)
            
            //--TRIMMABLE-BOUNDARY-START(4297321001)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297321001)
            
            static $h = 2353705;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592288297),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2353705,
      "h": 8592288297,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592288297)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297321001),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2353705,
      "h": 4297321001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297321001)
  ],
  "h": 2353705
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2353705)
        
        

        //--TRIMMABLE-BOUNDARY-START(1894953)
        $asm.$str(`$TBFc.LCCECM.CommunityElectionState`, ($self) => class CommunityElectionState extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Pending = 0;
            static Ongoing = 1;
            static Ended = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1894953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Pending": 0n,
                    "Ongoing": 1n,
                    "Ended": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296862249)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296862249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296862249)
            
            //--TRIMMABLE-BOUNDARY-START(4296862249)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296862249)
            
            static $h = 1894953;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181764137),
    {
      "t": 1894953,
      "n": "Pending",
      "d": 1894953,
      "h": 17181764137,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181764137),
//--TRIMMABLE-BOUNDARY-START(12886796841),
    {
      "t": 1894953,
      "n": "Ongoing",
      "d": 1894953,
      "h": 12886796841,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886796841),
//--TRIMMABLE-BOUNDARY-START(8591829545),
    {
      "t": 1894953,
      "n": "Ended",
      "d": 1894953,
      "h": 8591829545,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591829545)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296862249),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1894953,
      "h": 4296862249,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296862249)
  ],
  "h": 1894953
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1894953)
        
        

        //--TRIMMABLE-BOUNDARY-START(846377)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionFeatureModel`, ($self) => class CommunityElectionFeatureModel extends $.$LCOv.LCFCPM$1.AccountFeatureModel$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(12885748265)
            static /*string */ GetFeatureKey(/*IDataModel?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885748265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `Election`;
            }
            //--TRIMMABLE-BOUNDARY-END(12885748265)
            
            //--TRIMMABLE-BOUNDARY-START(8590780969)
            static /*CommunityElectionFeatureModel? */ From(/*IDataModel*/ target, /*IDataModel?*/ context, /*bool?*/ createIfNotExist)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590780969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let feature = $.$Iaui.LCFCM.DataPropertiesExtensions.GetFeatures($.$TBFc.LCCECM.CommunityElectionFeatureModel, ($.$cast(target, $.$Iaui.LCFCM.DataModel)), $.$TBFc.LCCECM.CommunityElectionFeatureModel.GetFeatureKey(context), createIfNotExist);
                return feature;
            }
            //--TRIMMABLE-BOUNDARY-END(8590780969)
            
            //--TRIMMABLE-BOUNDARY-START(8607009110)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionFeatureModel>.GetFeatureKey(LivingThing.Core.Frameworks.Common.Data.IDataModel?)
            static LCFCD$IDataFeatureModel$$$GetFeatureKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8607009110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$TBFc.LCCECM.CommunityElectionFeatureModel.GetFeatureKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8607009110)
            
            //--TRIMMABLE-BOUNDARY-START(4312041814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionFeatureModel>.From(LivingThing.Core.Frameworks.Common.Data.IDataModel, LivingThing.Core.Frameworks.Common.Data.IDataModel?, bool?)
            static LCFCD$IDataFeatureModel$$$From()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312041814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$TBFc.LCCECM.CommunityElectionFeatureModel.From(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312041814)
            
            //--TRIMMABLE-BOUNDARY-START(4295813673)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295813673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295813673)
            
            //--TRIMMABLE-BOUNDARY-START(4295813673)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295813673)
            
            static $h = 846377;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.AccountFeatureModel$$($.$TBFc.LCCECM.CommunityElectionFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885748265),
    {
      "r": 1310721,
      "p": [
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        }
      ],
      "n": "GetFeatureKey",
      "d": 846377,
      "h": 12885748265,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885748265),
//--TRIMMABLE-BOUNDARY-START(8590780969),
    {
      "r": 846377,
      "p": [
        {
          "n": "target",
          "p": 17533270
        },
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        },
        {
          "n": "createIfNotExist",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65
        }
      ],
      "n": "From",
      "d": 846377,
      "h": 8590780969,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590780969)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295813673),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 846377,
      "h": 4295813673,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295813673)
  ],
  "h": 846377
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD.IDataFeatureModel$$($.$TBFc.LCCECM.CommunityElectionFeatureModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionFeatureModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionFeatureModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(846377)
        
        

        //--TRIMMABLE-BOUNDARY-START(2026025)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionUserPreference`, ($self) => class CommunityElectionUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4296993321)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296993321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296993321)
            
            //--TRIMMABLE-BOUNDARY-START(4296993321)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296993321)
            
            static $h = 2026025;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296993321),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2026025,
      "h": 4296993321,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296993321)
  ],
  "h": 2026025
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2026025)
        
        

        //--TRIMMABLE-BOUNDARY-START(2681385)
        $asm.$cls(`$TBFc.LCCECS$1.CommunityElectionSettings`, ($self) => class CommunityElectionSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297648681)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297648681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297648681)
            
            //--TRIMMABLE-BOUNDARY-START(4297648681)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297648681)
            
            static $h = 2681385;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297648681),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2681385,
      "h": 4297648681,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297648681)
  ],
  "h": 2681385
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Settings.CommunityElectionSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Settings${separator}CommunityElectionSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2681385)
        
        

        //--TRIMMABLE-BOUNDARY-START(2943529)
        $asm.$cls(`$TBFc.LCCECS$2.CommunityElectionStates`, ($self) => class CommunityElectionStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4297910825)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297910825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297910825)
            
            //--TRIMMABLE-BOUNDARY-START(4297910825)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297910825)
            
            static $h = 2943529;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297910825),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2943529,
      "h": 4297910825,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297910825)
  ],
  "h": 2943529
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.States.CommunityElectionStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}States${separator}CommunityElectionStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2943529)
        
        

        //--TRIMMABLE-BOUNDARY-START(977449)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionFeatureModelTypeDescriptor`, ($self) => class CommunityElectionFeatureModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionFeatureModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295944745)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295944745);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$TBFc.LCCECM.CommunityElectionFeatureModelTypeDescriptor.GenerateProperties($.$TBFc.LCCECM.CommunityElectionFeatureModel, this, factory);
                    }, $dAdHdd ??= {"r":65537,"n":"","d":977449,"h":0,"f":17825794}), 0, "CommunityElectionFeatureModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Election.Common\\Models_CommunityElectionFeatureModel_LivingThing.Core.Community.Election.Common.Models.CommunityElectionFeatureModelTypeDescriptorBuilder.g.cs", "CommunityElectionFeatureModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295944745)
            
            //--TRIMMABLE-BOUNDARY-START(12885879337)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885879337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.AccountFeatureModelTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionFeatureModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885879337)
            
            //--TRIMMABLE-BOUNDARY-START(17180846633)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionFeatureModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180846633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.AccountFeatureModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionFeatureModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.AccountFeatureModelTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionFeatureModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.AccountFeatureModel$$($.$TBFc.LCCECM.CommunityElectionFeatureModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180846633)
            
            //--TRIMMABLE-BOUNDARY-START(8590912041)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionFeatureModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590912041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$TBFc.LCCECM.CommunityElectionFeatureModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$TBFc.LCCECM.CommunityElectionFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionFeatureModel)))
                {
                    /*var*/ let result = $.$TBFc.LCCECM.CommunityElectionFeatureModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionFeatureModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$TBFc.LCCECM.CommunityElectionFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionFeatureModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590912041)
            
            static $h = 977449;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885879337),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 977449,
      "h": 12885879337,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885879337),
//--TRIMMABLE-BOUNDARY-START(17180846633),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 846377,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 977449,
      "h": 17180846633,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180846633),
//--TRIMMABLE-BOUNDARY-START(8590912041),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 846377,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 977449,
      "h": 8590912041,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590912041)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295944745),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 977449,
      "h": 4295944745,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295944745)
  ],
  "h": 977449
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionFeatureModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionFeatureModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionFeatureModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(977449)
        
        

        //--TRIMMABLE-BOUNDARY-START(3074601)
        $asm.$cls(`$TBFc.LCCECS$2.CommunityElectionStatesTypeDescriptor`, ($self) => class CommunityElectionStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECS$2.CommunityElectionStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4298041897)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298041897);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$TBFc.LCCECS$2.CommunityElectionStatesTypeDescriptor.GenerateProperties($.$TBFc.LCCECS$2.CommunityElectionStates, this, factory);
                    }, $mdCthl ??= {"r":65537,"n":"","d":3074601,"h":0,"f":17825794}), 0, "CommunityElectionStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Election.Common\\States_CommunityElectionStates_LivingThing.Core.Community.Election.Common.States.CommunityElectionStatesTypeDescriptorBuilder.g.cs", "CommunityElectionStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298041897)
            
            //--TRIMMABLE-BOUNDARY-START(12887976489)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887976489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887976489)
            
            //--TRIMMABLE-BOUNDARY-START(17182943785)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.States.CommunityElectionStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182943785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182943785)
            
            //--TRIMMABLE-BOUNDARY-START(8593009193)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.States.CommunityElectionStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593009193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$TBFc.LCCECS$2.CommunityElectionStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$TBFc.LCCECS$2.CommunityElectionStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECS$2.CommunityElectionStates)))
                {
                    /*var*/ let result = $.$TBFc.LCCECS$2.CommunityElectionStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECS$2.CommunityElectionStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$TBFc.LCCECS$2.CommunityElectionStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECS$2.CommunityElectionStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593009193)
            
            static $h = 3074601;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECS$2.CommunityElectionStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887976489),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3074601,
      "h": 12887976489,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887976489),
//--TRIMMABLE-BOUNDARY-START(17182943785),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2943529,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3074601,
      "h": 17182943785,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182943785),
//--TRIMMABLE-BOUNDARY-START(8593009193),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2943529,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3074601,
      "h": 8593009193,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593009193)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298041897),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3074601,
      "h": 4298041897,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298041897)
  ],
  "h": 3074601
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$TBFc.LCCECS$2.CommunityElectionStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.States.CommunityElectionStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}States${separator}CommunityElectionStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3074601)
        
        

        //--TRIMMABLE-BOUNDARY-START(2812457)
        $asm.$cls(`$TBFc.LCCECS$1.CommunityElectionSettingsTypeDescriptor`, ($self) => class CommunityElectionSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECS$1.CommunityElectionSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297779753)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297779753);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$TBFc.LCCECS$1.CommunityElectionSettingsTypeDescriptor.GenerateProperties($.$TBFc.LCCECS$1.CommunityElectionSettings, this, factory);
                    }, $axAqhb ??= {"r":65537,"n":"","d":2812457,"h":0,"f":17825794}), 0, "CommunityElectionSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Election.Common\\Settings_CommunityElectionSettings_LivingThing.Core.Community.Election.Common.Settings.CommunityElectionSettingsTypeDescriptorBuilder.g.cs", "CommunityElectionSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297779753)
            
            //--TRIMMABLE-BOUNDARY-START(12887714345)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887714345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887714345)
            
            //--TRIMMABLE-BOUNDARY-START(17182681641)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Settings.CommunityElectionSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182681641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182681641)
            
            //--TRIMMABLE-BOUNDARY-START(8592747049)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Settings.CommunityElectionSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592747049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$TBFc.LCCECS$1.CommunityElectionSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$TBFc.LCCECS$1.CommunityElectionSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECS$1.CommunityElectionSettings)))
                {
                    /*var*/ let result = $.$TBFc.LCCECS$1.CommunityElectionSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECS$1.CommunityElectionSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$TBFc.LCCECS$1.CommunityElectionSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECS$1.CommunityElectionSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592747049)
            
            static $h = 2812457;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECS$1.CommunityElectionSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887714345),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2812457,
      "h": 12887714345,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887714345),
//--TRIMMABLE-BOUNDARY-START(17182681641),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2681385,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2812457,
      "h": 17182681641,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182681641),
//--TRIMMABLE-BOUNDARY-START(8592747049),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2681385,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2812457,
      "h": 8592747049,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592747049)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297779753),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2812457,
      "h": 4297779753,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297779753)
  ],
  "h": 2812457
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$TBFc.LCCECS$1.CommunityElectionSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Settings.CommunityElectionSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Settings${separator}CommunityElectionSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2812457)
        
        

        //--TRIMMABLE-BOUNDARY-START(2091561)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionVoteModel`, ($self) => class CommunityElectionVoteModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(68721568297)
            /*PostTypes */ get Type()
            {
                return 10757/*PostTypes.ElectionVote*/;
            }
            //--TRIMMABLE-BOUNDARY-END(68721568297)
            
            //--TRIMMABLE-BOUNDARY-START(47246731817)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246731817);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246731817)
            
            //--TRIMMABLE-BOUNDARY-START(42951764521)
            /*bool */ RequiresPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951764521);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951764521)
            
            //--TRIMMABLE-BOUNDARY-START(38656797225)
            /*CommunityElectionPositionModel? */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771895337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociation$1($.$TBFc.LCCECM.CommunityElectionPositionModel, null);
            }
            /*CommunityElectionPositionModel? */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426601001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociation($.$TBFc.LCCECM.CommunityElectionPositionModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(38656797225)
            
            //--TRIMMABLE-BOUNDARY-START(8592026153)
            /*CommunityElectionCandidateModel? */ get Candidate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181960745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociation$1($.$TBFc.LCCECM.CommunityElectionCandidateModel, null);
            }
            /*CommunityElectionCandidateModel? */ set Candidate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836666409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociation($.$TBFc.LCCECM.CommunityElectionCandidateModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8592026153)
            
            //--TRIMMABLE-BOUNDARY-START(4297058857)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297058857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297058857)
            
            //--TRIMMABLE-BOUNDARY-START(4297058857)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4297058857)
            
            static $h = 2091561;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68721568297),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361829929,
        "f": 50364417
      },
      "n": "Type",
      "d": 2091561,
      "h": 68721568297,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68721568297),
//--TRIMMABLE-BOUNDARY-START(38656797225),
    {
      "p": 1370665,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771895337,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426601001,
        "f": 83886081
      },
      "n": "Position",
      "d": 2091561,
      "h": 38656797225,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656797225),
//--TRIMMABLE-BOUNDARY-START(8592026153),
    {
      "p": 322089,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181960745,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836666409,
        "f": 83886081
      },
      "n": "Candidate",
      "d": 2091561,
      "h": 8592026153,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592026153)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246731817),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 2091561,
      "h": 47246731817,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246731817),
//--TRIMMABLE-BOUNDARY-START(42951764521),
    {
      "r": 262145,
      "n": "RequiresPost",
      "d": 2091561,
      "h": 42951764521,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951764521)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297058857),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2091561,
      "h": 4297058857,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297058857)
  ],
  "h": 2091561
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionVoteModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2091561)
        
        

        //--TRIMMABLE-BOUNDARY-START(322089)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionCandidateModel`, ($self) => class CommunityElectionCandidateModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(171799013929)
            /*PostTypes */ get Type()
            {
                return 10756/*PostTypes.ElectionCandidate*/;
            }
            //--TRIMMABLE-BOUNDARY-END(171799013929)
            
            //--TRIMMABLE-BOUNDARY-START(103079537193)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079537193);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079537193)
            
            //--TRIMMABLE-BOUNDARY-START(98784569897)
            /*bool */ RequiresPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784569897);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784569897)
            
            //--TRIMMABLE-BOUNDARY-START(107374504489)
            /*string? */ get Role()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424831529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "Role", null);
            }
            /*string? */ set Role(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914112041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "Role");
            }
            //--TRIMMABLE-BOUNDARY-END(107374504489)
            
            //--TRIMMABLE-BOUNDARY-START(12885223977)
            /*CommunityElectionPostModel? */ get Election()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065093161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociation$1($.$TBFc.LCCECM.CommunityElectionPostModel, null);
            }
            /*CommunityElectionPostModel? */ set Election(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554373673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociation($.$TBFc.LCCECM.CommunityElectionPostModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(12885223977)
            
            //--TRIMMABLE-BOUNDARY-START(94489602601)
            /*CommunityElectionPositionModel? */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834896937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociation$1($.$TBFc.LCCECM.CommunityElectionPositionModel, null);
            }
            /*CommunityElectionPositionModel? */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324177449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociation($.$TBFc.LCCECM.CommunityElectionPositionModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(94489602601)
            
            //--TRIMMABLE-BOUNDARY-START(90194635305)
            /*AccountModel? */ get NomineeAccount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244962345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociation$1($.$LCOv.LCFCPM$1.AccountModel, null);
            }
            /*AccountModel? */ set NomineeAccount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734242857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociation($.$LCOv.LCFCPM$1.AccountModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(90194635305)
            
            //--TRIMMABLE-BOUNDARY-START(8590256681)
            /*AccountBaseModel? */ get Account()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475158569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NomineeAccount ?? super.Account;
            }
            /*AccountBaseModel? */ set Account(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964439081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.Account = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590256681)
            
            //--TRIMMABLE-BOUNDARY-START(85899668009)
            /*int */ get Nominations()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655027753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, 0, "Nominations", null);
            }
            /*int */ set Nominations(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144308265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, value, "Nominations", null);
            }
            //--TRIMMABLE-BOUNDARY-END(85899668009)
            
            //--TRIMMABLE-BOUNDARY-START(176093981225)
            /*int */ get Votes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604700713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, 0, "Votes", null);
            }
            /*int */ set Votes(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504046633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, value, "Votes", null);
            }
            //--TRIMMABLE-BOUNDARY-END(176093981225)
            
            //--TRIMMABLE-BOUNDARY-START(4295289385)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295289385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295289385)
            
            //--TRIMMABLE-BOUNDARY-START(4295289385)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295289385)
            
            static $h = 322089;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(171799013929),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014766121,
        "f": 50364417
      },
      "n": "Type",
      "d": 322089,
      "h": 171799013929,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(171799013929),
//--TRIMMABLE-BOUNDARY-START(107374504489),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424831529,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914112041,
        "f": 83886081
      },
      "n": "Role",
      "d": 322089,
      "h": 107374504489,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107374504489),
//--TRIMMABLE-BOUNDARY-START(12885223977),
    {
      "p": 1632809,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065093161,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554373673,
        "f": 83886081
      },
      "n": "Election",
      "d": 322089,
      "h": 12885223977,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885223977),
//--TRIMMABLE-BOUNDARY-START(94489602601),
    {
      "p": 1370665,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834896937,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324177449,
        "f": 83886081
      },
      "n": "Position",
      "d": 322089,
      "h": 94489602601,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94489602601),
//--TRIMMABLE-BOUNDARY-START(90194635305),
    {
      "p": 7858612,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244962345,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734242857,
        "f": 83886081
      },
      "n": "NomineeAccount",
      "d": 322089,
      "h": 90194635305,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194635305),
//--TRIMMABLE-BOUNDARY-START(8590256681),
    {
      "p": 6220212,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475158569,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964439081,
        "f": 83918849
      },
      "n": "Account",
      "d": 322089,
      "h": 8590256681,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590256681),
//--TRIMMABLE-BOUNDARY-START(85899668009),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655027753,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144308265,
        "f": 83886081
      },
      "n": "Nominations",
      "d": 322089,
      "h": 85899668009,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85899668009),
//--TRIMMABLE-BOUNDARY-START(176093981225),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604700713,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504046633,
        "f": 83886081
      },
      "n": "Votes",
      "d": 322089,
      "h": 176093981225,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176093981225)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103079537193),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 322089,
      "h": 103079537193,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103079537193),
//--TRIMMABLE-BOUNDARY-START(98784569897),
    {
      "r": 262145,
      "n": "RequiresPost",
      "d": 322089,
      "h": 98784569897,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98784569897)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295289385),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 322089,
      "h": 4295289385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295289385)
  ],
  "h": 322089
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionCandidateModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(322089)
        
        

        //--TRIMMABLE-BOUNDARY-START(1370665)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionPositionModel`, ($self) => class CommunityElectionPositionModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(68720847401)
            /*PostTypes */ get Type()
            {
                return 10755/*PostTypes.ElectionPosition*/;
            }
            //--TRIMMABLE-BOUNDARY-END(68720847401)
            
            //--TRIMMABLE-BOUNDARY-START(47246010921)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246010921);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246010921)
            
            //--TRIMMABLE-BOUNDARY-START(42951043625)
            /*bool */ RequiresPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951043625);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951043625)
            
            //--TRIMMABLE-BOUNDARY-START(38656076329)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656076329);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656076329)
            
            //--TRIMMABLE-BOUNDARY-START(73015814697)
            /*Money? */ get VotingFee()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361109033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$typeNullable($.$fPer.LCFCDM.Money), null, "VotingFee", null);
            }
            /*Money? */ set VotingFee(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425880105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$typeNullable($.$fPer.LCFCDM.Money), $.$clone(value), "VotingFee");
            }
            //--TRIMMABLE-BOUNDARY-END(73015814697)
            
            //--TRIMMABLE-BOUNDARY-START(8591305257)
            /*bool */ get DisableSelfVote()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181239849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Boolean, false, "DisableSelfVote", null);
            }
            /*bool */ set DisableSelfVote(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835945513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Boolean, value, "DisableSelfVote");
            }
            //--TRIMMABLE-BOUNDARY-END(8591305257)
            
            //--TRIMMABLE-BOUNDARY-START(4296337961)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296337961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296337961)
            
            //--TRIMMABLE-BOUNDARY-START(4296337961)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296337961)
            
            static $h = 1370665;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720847401),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771174441,
        "f": 50364417
      },
      "n": "Type",
      "d": 1370665,
      "h": 68720847401,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68720847401),
//--TRIMMABLE-BOUNDARY-START(73015814697),
    {
      "p": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361109033,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425880105,
        "f": 83886081
      },
      "n": "VotingFee",
      "d": 1370665,
      "h": 73015814697,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1024,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015814697),
//--TRIMMABLE-BOUNDARY-START(8591305257),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181239849,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835945513,
        "f": 83886081
      },
      "n": "DisableSelfVote",
      "d": 1370665,
      "h": 8591305257,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1028,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Don\u0027t someone to vote themself for this position",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-cash"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591305257)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246010921),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 1370665,
      "h": 47246010921,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246010921),
//--TRIMMABLE-BOUNDARY-START(42951043625),
    {
      "r": 262145,
      "n": "RequiresPost",
      "d": 1370665,
      "h": 42951043625,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951043625),
//--TRIMMABLE-BOUNDARY-START(38656076329),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 1370665,
      "h": 38656076329,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656076329)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296337961),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1370665,
      "h": 4296337961,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296337961)
  ],
  "h": 1370665
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionPositionModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1370665)
        
        

        //--TRIMMABLE-BOUNDARY-START(3467817)
        $asm.$cls(`$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4298435113)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298435113);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298435113)
            
            //--TRIMMABLE-BOUNDARY-START(8593402409)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionVoteModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593402409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionVoteModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionVoteModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8593402409)
            
            //--TRIMMABLE-BOUNDARY-START(17183337001)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionVoteModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183337001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionVoteModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TBFc.LCCECM.CommunityElectionVoteModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17183337001)
            
            //--TRIMMABLE-BOUNDARY-START(21478304297)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionVoteModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478304297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$TBFc.LCCECM.CommunityElectionVoteModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$fPer.LCFCD.WireTransportModel$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TBFc.LCCECM.CommunityElectionVoteModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21478304297)
            
            //--TRIMMABLE-BOUNDARY-START(25773271593)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionVoteModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773271593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionVoteModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionVoteModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25773271593)
            
            //--TRIMMABLE-BOUNDARY-START(12888369705)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888369705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionVoteModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12888369705)
            
            static $h = 3467817;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298435113),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3467817,
      "h": 4298435113,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298435113)
  ],
  "h": 3467817
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$fPer.LCFCD.IReadDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityElectionVoteModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3467817)
        
        

        //--TRIMMABLE-BOUNDARY-START(3271209)
        $asm.$cls(`$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4298238505)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298238505);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298238505)
            
            //--TRIMMABLE-BOUNDARY-START(8593205801)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionCandidateModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593205801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionCandidateModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8593205801)
            
            //--TRIMMABLE-BOUNDARY-START(17183140393)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionCandidateModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183140393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TBFc.LCCECM.CommunityElectionCandidateModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17183140393)
            
            //--TRIMMABLE-BOUNDARY-START(21478107689)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionCandidateModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478107689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$fPer.LCFCD.WireTransportModel$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TBFc.LCCECM.CommunityElectionCandidateModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21478107689)
            
            //--TRIMMABLE-BOUNDARY-START(25773074985)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionCandidateModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773074985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionCandidateModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25773074985)
            
            //--TRIMMABLE-BOUNDARY-START(12888173097)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888173097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionCandidateModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12888173097)
            
            static $h = 3271209;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298238505),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3271209,
      "h": 4298238505,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298238505)
  ],
  "h": 3271209
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$fPer.LCFCD.IReadDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityElectionCandidateModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3271209)
        
        

        //--TRIMMABLE-BOUNDARY-START(3402281)
        $asm.$cls(`$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4298369577)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298369577);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298369577)
            
            //--TRIMMABLE-BOUNDARY-START(8593336873)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionPositionModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593336873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPositionModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionPositionModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8593336873)
            
            //--TRIMMABLE-BOUNDARY-START(17183271465)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionPositionModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183271465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPositionModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TBFc.LCCECM.CommunityElectionPositionModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17183271465)
            
            //--TRIMMABLE-BOUNDARY-START(21478238761)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionPositionModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478238761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$TBFc.LCCECM.CommunityElectionPositionModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$fPer.LCFCD.WireTransportModel$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TBFc.LCCECM.CommunityElectionPositionModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21478238761)
            
            //--TRIMMABLE-BOUNDARY-START(25773206057)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionPositionModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773206057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPositionModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionPositionModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25773206057)
            
            //--TRIMMABLE-BOUNDARY-START(12888304169)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888304169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionPositionModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12888304169)
            
            static $h = 3402281;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298369577),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3402281,
      "h": 4298369577,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298369577)
  ],
  "h": 3402281
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$fPer.LCFCD.IReadDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityElectionPositionModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3402281)
        
        

        //--TRIMMABLE-BOUNDARY-START(1501737)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionPositionModelTypeDescriptor`, ($self) => class CommunityElectionPositionModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionPositionModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296469033)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296469033);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$TBFc.LCCECM.CommunityElectionPositionModelTypeDescriptor.GenerateProperties($.$TBFc.LCCECM.CommunityElectionPositionModel, this, factory);
                    }, $CkguZe ??= {"r":65537,"n":"","d":1501737,"h":0,"f":17825794}), 0, "CommunityElectionPositionModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Election.Common\\Models_CommunityElectionPositionModel_LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModelTypeDescriptorBuilder.g.cs", "CommunityElectionPositionModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296469033)
            
            //--TRIMMABLE-BOUNDARY-START(12886403625)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886403625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("VotingFee"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPositionModel.$type, $.$discardRef(), "VotingFee", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("VotingFee")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$fPer.LCFCDM.Money), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "VotingFee";
                        $i1.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPositionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$fPer.LCFCDM.Money, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPositionModel)).VotingFee);
                        }, $WNPoHg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1501737,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPositionModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.VotingFee = value.AsNullableValue($.$fPer.LCFCDM.Money);
                        }, $SDYSMf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1501737,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DisableSelfVote"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPositionModel.$type, $.$discardRef(), "DisableSelfVote", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DisableSelfVote")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "DisableSelfVote";
                        $i3.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPositionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPositionModel)).DisableSelfVote);
                        }, $udBYMc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1501737,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPositionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DisableSelfVote = value.AsBool();
                        }, $ISbHuj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1501737,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPositionModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Type";
                        $i5.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPositionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPositionModel)).Type);
                        }, $rnbUlk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1501737,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886403625)
            
            //--TRIMMABLE-BOUNDARY-START(17181370921)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181370921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _VotingFee = _target.VotingFee;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("VotingFee"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$fPer.LCFCDM.Money)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$fPer.LCFCDM.Money), () => _VotingFee, ($v) => _VotingFee = $v, null, true)))
                    {
                        _target.VotingFee = $.$clone(_VotingFee);
                    }
                }
                {
                    /*var*/ let _DisableSelfVote = _target.DisableSelfVote;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DisableSelfVote"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _DisableSelfVote, ($v) => _DisableSelfVote = $v, null, true)))
                    {
                        _target.DisableSelfVote = _DisableSelfVote;
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181370921)
            
            //--TRIMMABLE-BOUNDARY-START(8591436329)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591436329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$TBFc.LCCECM.CommunityElectionPositionModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$TBFc.LCCECM.CommunityElectionPositionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionPositionModel)))
                {
                    /*var*/ let result = $.$TBFc.LCCECM.CommunityElectionPositionModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionPositionModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$TBFc.LCCECM.CommunityElectionPositionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionPositionModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591436329)
            
            static $h = 1501737;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionPositionModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886403625),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1501737,
      "h": 12886403625,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886403625),
//--TRIMMABLE-BOUNDARY-START(17181370921),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1370665,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1501737,
      "h": 17181370921,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181370921),
//--TRIMMABLE-BOUNDARY-START(8591436329),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1370665,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1501737,
      "h": 8591436329,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591436329)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296469033),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1501737,
      "h": 4296469033,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296469033)
  ],
  "h": 1501737
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionPositionModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1501737)
        
        

        //--TRIMMABLE-BOUNDARY-START(2222633)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionVoteModelTypeDescriptor`, ($self) => class CommunityElectionVoteModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionVoteModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297189929)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297189929);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$TBFc.LCCECM.CommunityElectionVoteModelTypeDescriptor.GenerateProperties($.$TBFc.LCCECM.CommunityElectionVoteModel, this, factory);
                    }, $jknued ??= {"r":65537,"n":"","d":2222633,"h":0,"f":17825794}), 0, "CommunityElectionVoteModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Election.Common\\Models_CommunityElectionVoteModel_LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModelTypeDescriptorBuilder.g.cs", "CommunityElectionVoteModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297189929)
            
            //--TRIMMABLE-BOUNDARY-START(12887124521)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887124521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionVoteModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionVoteModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionVoteModel)).Type);
                        }, $zGaOCc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2222633,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Position"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionVoteModel.$type, $.$discardRef(), "Position", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Position")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$TBFc.LCCECM.CommunityElectionPositionModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Position";
                        $i3.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionVoteModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$TBFc.LCCECM.CommunityElectionPositionModel, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionVoteModel)).Position);
                        }, $VAYPce ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2222633,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionVoteModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Position = value.AsReference($.$TBFc.LCCECM.CommunityElectionPositionModel);
                        }, $SekOeh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2222633,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Candidate"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionVoteModel.$type, $.$discardRef(), "Candidate", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Candidate")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$TBFc.LCCECM.CommunityElectionCandidateModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Candidate";
                        $i5.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionVoteModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$TBFc.LCCECM.CommunityElectionCandidateModel, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionVoteModel)).Candidate);
                        }, $UXrqDc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2222633,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionVoteModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Candidate = value.AsReference($.$TBFc.LCCECM.CommunityElectionCandidateModel);
                        }, $ImolKa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2222633,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887124521)
            
            //--TRIMMABLE-BOUNDARY-START(17182091817)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182091817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Position = _target.Position;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Position"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$TBFc.LCCECM.CommunityElectionPositionModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Position, ($v) => _Position = $v, $.$TBFc.LCCECM.CommunityElectionPositionModel)))
                    {
                        _target.Position = _Position;
                    }
                }
                {
                    /*var*/ let _Candidate = _target.Candidate;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Candidate"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$TBFc.LCCECM.CommunityElectionCandidateModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Candidate, ($v) => _Candidate = $v, $.$TBFc.LCCECM.CommunityElectionCandidateModel)))
                    {
                        _target.Candidate = _Candidate;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182091817)
            
            //--TRIMMABLE-BOUNDARY-START(8592157225)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592157225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$TBFc.LCCECM.CommunityElectionVoteModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$TBFc.LCCECM.CommunityElectionVoteModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionVoteModel)))
                {
                    /*var*/ let result = $.$TBFc.LCCECM.CommunityElectionVoteModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionVoteModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$TBFc.LCCECM.CommunityElectionVoteModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionVoteModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592157225)
            
            static $h = 2222633;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionVoteModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887124521),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2222633,
      "h": 12887124521,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887124521),
//--TRIMMABLE-BOUNDARY-START(17182091817),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2091561,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2222633,
      "h": 17182091817,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182091817),
//--TRIMMABLE-BOUNDARY-START(8592157225),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2091561,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2222633,
      "h": 8592157225,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592157225)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297189929),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2222633,
      "h": 4297189929,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297189929)
  ],
  "h": 2222633
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionVoteModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionVoteModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2222633)
        
        

        //--TRIMMABLE-BOUNDARY-START(453161)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor`, ($self) => class CommunityElectionCandidateModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionCandidateModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295420457)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295420457);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor.GenerateProperties($.$TBFc.LCCECM.CommunityElectionCandidateModel, this, factory);
                    }, $iXcEkh ??= {"r":65537,"n":"","d":453161,"h":0,"f":17825794}), 0, "CommunityElectionCandidateModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Election.Common\\Models_CommunityElectionCandidateModel_LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModelTypeDescriptorBuilder.g.cs", "CommunityElectionCandidateModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295420457)
            
            //--TRIMMABLE-BOUNDARY-START(12885355049)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885355049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionCandidateModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionCandidateModel)).Type);
                        }, $KOyQlk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":453161,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Role"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionCandidateModel.$type, $.$discardRef(), "Role", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Role")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Role";
                        $i3.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionCandidateModel)).Role);
                        }, $IULDVe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":453161,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Role = value.AsReference($.$$.S.String);
                        }, $rcArMh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":453161,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Election"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionCandidateModel.$type, $.$discardRef(), "Election", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Election")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$TBFc.LCCECM.CommunityElectionPostModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Election";
                        $i5.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$TBFc.LCCECM.CommunityElectionPostModel, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionCandidateModel)).Election);
                        }, $iiWbjf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":453161,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Election = value.AsReference($.$TBFc.LCCECM.CommunityElectionPostModel);
                        }, $JfPisa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":453161,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Position"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionCandidateModel.$type, $.$discardRef(), "Position", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Position")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$TBFc.LCCECM.CommunityElectionPositionModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Position";
                        $i7.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$TBFc.LCCECM.CommunityElectionPositionModel, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionCandidateModel)).Position);
                        }, $xnqOvj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":453161,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Position = value.AsReference($.$TBFc.LCCECM.CommunityElectionPositionModel);
                        }, $ubclGk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":453161,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("NomineeAccount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionCandidateModel.$type, $.$discardRef(), "NomineeAccount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("NomineeAccount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.AccountModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "NomineeAccount";
                        $i9.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$LCOv.LCFCPM$1.AccountModel, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionCandidateModel)).NomineeAccount);
                        }, $uYjAAk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":453161,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.NomineeAccount = value.AsReference($.$LCOv.LCFCPM$1.AccountModel);
                        }, $ChklCi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":453161,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Account"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionCandidateModel.$type, $.$discardRef(), "Account", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Account")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.AccountBaseModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Account";
                        $i11.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$LCOv.LCFCPM$1.AccountBaseModel, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionCandidateModel)).Account);
                        }, $zrASoe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":453161,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Account = value.AsReference($.$LCOv.LCFCPM$1.AccountBaseModel);
                        }, $FkpWTf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":453161,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Nominations"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionCandidateModel.$type, $.$discardRef(), "Nominations", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Nominations")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Nominations";
                        $i13.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$TBFc.LCCECM.CommunityElectionCandidateModel)).Nominations);
                        }, $nWIiDh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":453161,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Nominations = value.AsInt();
                        }, $Qdoilc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":453161,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Votes"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionCandidateModel.$type, $.$discardRef(), "Votes", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Votes")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Votes";
                        $i15.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$TBFc.LCCECM.CommunityElectionCandidateModel)).Votes);
                        }, $RNRARj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":453161,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Votes = value.AsInt();
                        }, $csOJda ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":453161,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885355049)
            
            //--TRIMMABLE-BOUNDARY-START(17180322345)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180322345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Role = _target.Role;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Role"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Role, ($v) => _Role = $v, $.$$.S.String)))
                    {
                        _target.Role = _Role;
                    }
                }
                {
                    /*var*/ let _Election = _target.Election;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Election"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$TBFc.LCCECM.CommunityElectionPostModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Election, ($v) => _Election = $v, $.$TBFc.LCCECM.CommunityElectionPostModel)))
                    {
                        _target.Election = _Election;
                    }
                }
                {
                    /*var*/ let _Position = _target.Position;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Position"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$TBFc.LCCECM.CommunityElectionPositionModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Position, ($v) => _Position = $v, $.$TBFc.LCCECM.CommunityElectionPositionModel)))
                    {
                        _target.Position = _Position;
                    }
                }
                {
                    /*var*/ let _NomineeAccount = _target.NomineeAccount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("NomineeAccount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.AccountModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _NomineeAccount, ($v) => _NomineeAccount = $v, $.$LCOv.LCFCPM$1.AccountModel)))
                    {
                        _target.NomineeAccount = _NomineeAccount;
                    }
                }
                {
                    /*var*/ let _Account = _target.Account;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Account"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.AccountBaseModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Account, ($v) => _Account = $v, $.$LCOv.LCFCPM$1.AccountBaseModel)))
                    {
                        _target.Account = _Account;
                    }
                }
                {
                    /*var*/ let _Nominations = _target.Nominations;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Nominations"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Nominations, ($v) => _Nominations = $v, $.$$.S.Int32)))
                    {
                        _target.Nominations = _Nominations;
                    }
                }
                {
                    /*var*/ let _Votes = _target.Votes;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Votes"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Votes, ($v) => _Votes = $v, $.$$.S.Int32)))
                    {
                        _target.Votes = _Votes;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180322345)
            
            //--TRIMMABLE-BOUNDARY-START(8590387753)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590387753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$TBFc.LCCECM.CommunityElectionCandidateModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$TBFc.LCCECM.CommunityElectionCandidateModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionCandidateModel)))
                {
                    /*var*/ let result = $.$TBFc.LCCECM.CommunityElectionCandidateModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionCandidateModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$TBFc.LCCECM.CommunityElectionCandidateModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionCandidateModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590387753)
            
            static $h = 453161;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionCandidateModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885355049),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 453161,
      "h": 12885355049,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885355049),
//--TRIMMABLE-BOUNDARY-START(17180322345),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 322089,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 453161,
      "h": 17180322345,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180322345),
//--TRIMMABLE-BOUNDARY-START(8590387753),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 322089,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 453161,
      "h": 8590387753,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590387753)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295420457),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 453161,
      "h": 4295420457,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295420457)
  ],
  "h": 453161
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionCandidateModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(453161)
        
        

        $asm.$typeProxy("$TBFc.LCCECM.CommunityElectionCategoryModel", "$TBFc.LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel");
        //--TRIMMABLE-BOUNDARY-START(1632809)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionPostModel`, ($self) => class CommunityElectionPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$TBFc.LCCECM.CommunityElectionCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(244814768681)
            /*PostTypes */ get Type()
            {
                return 10753/*PostTypes.ElectionPost*/;
            }
            //--TRIMMABLE-BOUNDARY-END(244814768681)
            
            //--TRIMMABLE-BOUNDARY-START(236224834089)
            /*DateTime? */ get StartDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375815209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$typeNullable($.$$.S.DateTime), null, "StartDate", null);
            }
            /*DateTime? */ set StartDate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634899497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$typeNullable($.$$.S.DateTime), $.$clone(value), "StartDate");
            }
            //--TRIMMABLE-BOUNDARY-END(236224834089)
            
            //--TRIMMABLE-BOUNDARY-START(21476469289)
            /*DateTime? */ get EndDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836207657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$typeNullable($.$$.S.DateTime), null, "EndDate", null);
            }
            /*DateTime? */ set EndDate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095291945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$typeNullable($.$$.S.DateTime), $.$clone(value), "EndDate");
            }
            //--TRIMMABLE-BOUNDARY-END(21476469289)
            
            //--TRIMMABLE-BOUNDARY-START(128850651689)
            /*Money? */ get NominationFee()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426142249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$typeNullable($.$fPer.LCFCDM.Money), null, "NominationFee", null);
            }
            /*Money? */ set NominationFee(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685226537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$typeNullable($.$fPer.LCFCDM.Money), $.$clone(value), "NominationFee");
            }
            //--TRIMMABLE-BOUNDARY-END(128850651689)
            
            //--TRIMMABLE-BOUNDARY-START(141735553577)
            /*bool */ get SelfNomination()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195946025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Boolean, false, "SelfNomination", null);
            }
            /*bool */ set SelfNomination(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455030313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Boolean, value, "SelfNomination");
            }
            //--TRIMMABLE-BOUNDARY-END(141735553577)
            
            //--TRIMMABLE-BOUNDARY-START(231929866793)
            /*bool */ get SingleNomination()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785880617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Boolean, false, "SingleNomination", null);
            }
            /*bool */ set SingleNomination(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044964905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Boolean, value, "SingleNomination");
            }
            //--TRIMMABLE-BOUNDARY-END(231929866793)
            
            //--TRIMMABLE-BOUNDARY-START(17181501993)
            /*bool */ get DisableSelfVote()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246273065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Boolean, false, "DisableSelfVote", null);
            }
            /*bool */ set DisableSelfVote(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505357353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Boolean, value, "DisableSelfVote");
            }
            //--TRIMMABLE-BOUNDARY-END(17181501993)
            
            //--TRIMMABLE-BOUNDARY-START(12886534697)
            /*IEnumerable<CommunityElectionCandidateModel>? */ get Candidates()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656338473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociations$1($.$TBFc.LCCECM.CommunityElectionCandidateModel, null);
            }
            /*IEnumerable<CommunityElectionCandidateModel>? */ set Candidates(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915422761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociations($.$TBFc.LCCECM.CommunityElectionCandidateModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(12886534697)
            
            //--TRIMMABLE-BOUNDARY-START(137440586281)
            /*IEnumerable<CommunityElectionPositionModel>? */ get Positions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606011433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociations$1($.$TBFc.LCCECM.CommunityElectionPositionModel, null);
            }
            /*IEnumerable<CommunityElectionPositionModel>? */ set Positions(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865095721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociations($.$TBFc.LCCECM.CommunityElectionPositionModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(137440586281)
            
            //--TRIMMABLE-BOUNDARY-START(133145618985)
            /*string? */ get PositionLabel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016076841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "PositionLabel", null);
            }
            /*string? */ set PositionLabel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275161129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "PositionLabel");
            }
            //--TRIMMABLE-BOUNDARY-END(133145618985)
            
            //--TRIMMABLE-BOUNDARY-START(8591567401)
            /*string? */ get CandidateLabel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066403881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "CandidateLabel", null);
            }
            /*string? */ set CandidateLabel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325488169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "CandidateLabel");
            }
            //--TRIMMABLE-BOUNDARY-END(8591567401)
            
            //--TRIMMABLE-BOUNDARY-START(240519801385)
            /*CommunityElectionState */ get State()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965749801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let now = $.$$.S.DateTime.UtcNow;
                if (now < this.StartDate)
                {
                    return 0/*CommunityElectionState.Pending*/;
                }
                if (now > this.EndDate)
                {
                    return 2/*CommunityElectionState.Ended*/;
                }
                return 1/*CommunityElectionState.Ongoing*/;
            }
            //--TRIMMABLE-BOUNDARY-END(240519801385)
            
            //--TRIMMABLE-BOUNDARY-START(249109735977)
            /*ValueTask<bool> */ Validate(/*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109735977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.StartDate >= this.EndDate)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Start date must be less than end date");
                }
                return super.Validate($.$clone(schema));
            }
            //--TRIMMABLE-BOUNDARY-END(249109735977)
            
            //--TRIMMABLE-BOUNDARY-START(4296600105)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296600105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296600105)
            
            //--TRIMMABLE-BOUNDARY-START(4296600105)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296600105)
            
            static $h = 1632809;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$TBFc.LCCECM.CommunityElectionCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(244814768681),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555684393,
        "f": 50364417
      },
      "n": "Type",
      "d": 1632809,
      "h": 244814768681,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(244814768681),
//--TRIMMABLE-BOUNDARY-START(236224834089),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375815209,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227634899497,
        "f": 83886081
      },
      "n": "StartDate",
      "d": 1632809,
      "h": 236224834089,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1024,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "The date the election is starting",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-calendar"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236224834089),
//--TRIMMABLE-BOUNDARY-START(21476469289),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836207657,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176095291945,
        "f": 83886081
      },
      "n": "EndDate",
      "d": 1632809,
      "h": 21476469289,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1025,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "The date the election is ending",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-calendar"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476469289),
//--TRIMMABLE-BOUNDARY-START(128850651689),
    {
      "p": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426142249,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184685226537,
        "f": 83886081
      },
      "n": "NominationFee",
      "d": 1632809,
      "h": 128850651689,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1026,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "How much to nominate member",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-cash"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128850651689),
//--TRIMMABLE-BOUNDARY-START(141735553577),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195946025,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210455030313,
        "f": 83886081
      },
      "n": "SelfNomination",
      "d": 1632809,
      "h": 141735553577,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1027,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Allow member to nominate themself",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-cash"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141735553577),
//--TRIMMABLE-BOUNDARY-START(231929866793),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785880617,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044964905,
        "f": 83886081
      },
      "n": "SingleNomination",
      "d": 1632809,
      "h": 231929866793,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1028,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Allow members to nominate only once",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-cash"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231929866793),
//--TRIMMABLE-BOUNDARY-START(17181501993),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246273065,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505357353,
        "f": 83886081
      },
      "n": "DisableSelfVote",
      "d": 1632809,
      "h": 17181501993,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1029,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Don\u0027t allow candidate to vote for themself",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-cash"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181501993),
//--TRIMMABLE-BOUNDARY-START(12886534697),
    {
      "p": $.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656338473,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915422761,
        "f": 83886081
      },
      "n": "Candidates",
      "d": 1632809,
      "h": 12886534697,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886534697),
//--TRIMMABLE-BOUNDARY-START(137440586281),
    {
      "p": $.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionPositionModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606011433,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201865095721,
        "f": 83886081
      },
      "n": "Positions",
      "d": 1632809,
      "h": 137440586281,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137440586281),
//--TRIMMABLE-BOUNDARY-START(133145618985),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016076841,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193275161129,
        "f": 83886081
      },
      "n": "PositionLabel",
      "d": 1632809,
      "h": 133145618985,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133145618985),
//--TRIMMABLE-BOUNDARY-START(8591567401),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066403881,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325488169,
        "f": 83886081
      },
      "n": "CandidateLabel",
      "d": 1632809,
      "h": 8591567401,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591567401),
//--TRIMMABLE-BOUNDARY-START(240519801385),
    {
      "p": 1894953,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965749801,
        "f": 50331649
      },
      "n": "State",
      "d": 1632809,
      "h": 240519801385,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(240519801385)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(249109735977),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Validate",
      "d": 1632809,
      "h": 249109735977,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(249109735977)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296600105),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1632809,
      "h": 4296600105,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296600105)
  ],
  "h": 1632809
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1632809)
        
        

        //--TRIMMABLE-BOUNDARY-START(584233)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionCategoryModel`, ($self) => class CommunityElectionCategoryModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$TBFc.LCCECM.CommunityElectionPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180453417)
            /*PostTypes */ get Type()
            {
                return 10754/*PostTypes.ElectionCategory*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180453417)
            
            //--TRIMMABLE-BOUNDARY-START(4295551529)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295551529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295551529)
            
            //--TRIMMABLE-BOUNDARY-START(4295551529)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295551529)
            
            static $h = 584233;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$TBFc.LCCECM.CommunityElectionCategoryModel, $.$TBFc.LCCECM.CommunityElectionPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180453417),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885486121,
        "f": 50364417
      },
      "n": "Type",
      "d": 584233,
      "h": 17180453417,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180453417)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295551529),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 584233,
      "h": 4295551529,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295551529)
  ],
  "h": 584233
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(584233)
        
        

        //--TRIMMABLE-BOUNDARY-START(2419241)
        $asm.$cls(`$TBFc.LCCECS.ICommunityElectionFeedRemoteService`, ($self) => class ICommunityElectionFeedRemoteService
        {
            static $h = 2419241;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2419241,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Services.ICommunityElectionFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Services${separator}ICommunityElectionFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2419241)
        
        

        //--TRIMMABLE-BOUNDARY-START(2550313)
        $asm.$cls(`$TBFc.LCCECS.IComunityElectionRemoteService`, ($self) => class IComunityElectionRemoteService
        {
            static $h = 2550313;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2550313,
  "a": [
    {
      "t": 3537875,
      "c": 8593472467,
      "a": [
        {
          "v": [$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel).$h,$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionPositionModel).$h,$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$h,$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionVoteModel).$h
          ],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.IReadDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Services.IComunityElectionRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Services${separator}IComunityElectionRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2550313)
        
        

        //--TRIMMABLE-BOUNDARY-START(2484777)
        $asm.$cls(`$TBFc.LCCECS.ICommunityElectionFeedRemoteService_Mocking`, ($self) => class ICommunityElectionFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297452073)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297452073);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297452073)
            
            //--TRIMMABLE-BOUNDARY-START(8592419369)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionPostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592419369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$TBFc.LCCECM.CommunityElectionPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592419369)
            
            static $h = 2484777;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297452073),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2484777,
      "h": 4297452073,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297452073)
  ],
  "h": 2484777
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$TBFc.LCCECS.ICommunityElectionFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Services.ICommunityElectionFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Services${separator}ICommunityElectionFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2484777)
        
        

        //--TRIMMABLE-BOUNDARY-START(3336745)
        $asm.$cls(`$TBFc.LCFCR.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4298304041)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298304041);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298304041)
            
            //--TRIMMABLE-BOUNDARY-START(8593271337)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionCategoryModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593271337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionCategoryModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionCategoryModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8593271337)
            
            //--TRIMMABLE-BOUNDARY-START(17183205929)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionCategoryModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183205929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionCategoryModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TBFc.LCCECM.CommunityElectionCategoryModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17183205929)
            
            //--TRIMMABLE-BOUNDARY-START(21478173225)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionCategoryModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478173225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$TBFc.LCCECM.CommunityElectionCategoryModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$fPer.LCFCD.WireTransportModel$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TBFc.LCCECM.CommunityElectionCategoryModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21478173225)
            
            //--TRIMMABLE-BOUNDARY-START(25773140521)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionCategoryModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773140521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionCategoryModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionCategoryModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25773140521)
            
            //--TRIMMABLE-BOUNDARY-START(12888238633)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888238633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionCategoryModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12888238633)
            
            static $h = 3336745;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298304041),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3336745,
      "h": 4298304041,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298304041)
  ],
  "h": 3336745
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$fPer.LCFCD.IReadDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityElectionCategoryModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3336745)
        
        

        //--TRIMMABLE-BOUNDARY-START(2615849)
        $asm.$cls(`$TBFc.LCCECS.IComunityElectionRemoteService_Mocking`, ($self) => class IComunityElectionRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297583145)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297583145);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297583145)
            
            //--TRIMMABLE-BOUNDARY-START(8592550441)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592550441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592550441)
            
            //--TRIMMABLE-BOUNDARY-START(17182485033)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182485033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TBFc.LCCECM.CommunityElectionPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17182485033)
            
            //--TRIMMABLE-BOUNDARY-START(21477452329)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477452329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$TBFc.LCCECM.CommunityElectionPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TBFc.LCCECM.CommunityElectionPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21477452329)
            
            //--TRIMMABLE-BOUNDARY-START(25772419625)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Election$Common$Models$CommunityElectionPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772419625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25772419625)
            
            //--TRIMMABLE-BOUNDARY-START(12887517737)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887517737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$TBFc.LCCECM.CommunityElectionPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12887517737)
            
            static $h = 2615849;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297583145),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2615849,
      "h": 4297583145,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297583145)
  ],
  "h": 2615849
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$TBFc.LCCECS.IComunityElectionRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.IReadDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Services.IComunityElectionRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Services${separator}IComunityElectionRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2615849)
        
        

        //--TRIMMABLE-BOUNDARY-START(715305)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionCategoryModelTypeDescriptor`, ($self) => class CommunityElectionCategoryModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionCategoryModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295682601)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295682601);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$TBFc.LCCECM.CommunityElectionCategoryModelTypeDescriptor.GenerateProperties($.$TBFc.LCCECM.CommunityElectionCategoryModel, this, factory);
                    }, $vfpJIj ??= {"r":65537,"n":"","d":715305,"h":0,"f":17825794}), 0, "CommunityElectionCategoryModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Election.Common\\Models_CommunityElectionCategoryModel_LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModelTypeDescriptorBuilder.g.cs", "CommunityElectionCategoryModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295682601)
            
            //--TRIMMABLE-BOUNDARY-START(12885617193)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885617193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionCategoryModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionCategoryModel)).Type);
                        }, $fFZgGa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":715305,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$TBFc.LCCECM.CommunityElectionCategoryModel, $.$TBFc.LCCECM.CommunityElectionPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885617193)
            
            //--TRIMMABLE-BOUNDARY-START(17180584489)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180584489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel, LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$TBFc.LCCECM.CommunityElectionCategoryModel, $.$TBFc.LCCECM.CommunityElectionPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$TBFc.LCCECM.CommunityElectionCategoryModel, $.$TBFc.LCCECM.CommunityElectionPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180584489)
            
            //--TRIMMABLE-BOUNDARY-START(8590649897)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590649897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$TBFc.LCCECM.CommunityElectionCategoryModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$TBFc.LCCECM.CommunityElectionCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionCategoryModel)))
                {
                    /*var*/ let result = $.$TBFc.LCCECM.CommunityElectionCategoryModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionCategoryModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$TBFc.LCCECM.CommunityElectionCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionCategoryModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590649897)
            
            static $h = 715305;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionCategoryModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885617193),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 715305,
      "h": 12885617193,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885617193),
//--TRIMMABLE-BOUNDARY-START(17180584489),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 584233,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 715305,
      "h": 17180584489,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180584489),
//--TRIMMABLE-BOUNDARY-START(8590649897),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 584233,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 715305,
      "h": 8590649897,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590649897)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295682601),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 715305,
      "h": 4295682601,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295682601)
  ],
  "h": 715305
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionCategoryModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionCategoryModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(715305)
        
        

        //--TRIMMABLE-BOUNDARY-START(1763881)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor`, ($self) => class CommunityElectionPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296731177)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296731177);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor.GenerateProperties($.$TBFc.LCCECM.CommunityElectionPostModel, this, factory);
                    }, $VPpuqc ??= {"r":65537,"n":"","d":1763881,"h":0,"f":17825794}), 0, "CommunityElectionPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Election.Common\\Models_CommunityElectionPostModel_LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModelTypeDescriptorBuilder.g.cs", "CommunityElectionPostModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296731177)
            
            //--TRIMMABLE-BOUNDARY-START(12886665769)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886665769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StartDate"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPostModel.$type, $.$discardRef(), "StartDate", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StartDate")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateTime), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "StartDate";
                        $i1.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateTime, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPostModel)).StartDate);
                        }, $TtheNe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1763881,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.StartDate = value.AsNullableValue($.$$.S.DateTime);
                        }, $TdFFQc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1763881,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EndDate"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPostModel.$type, $.$discardRef(), "EndDate", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EndDate")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateTime), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "EndDate";
                        $i3.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateTime, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPostModel)).EndDate);
                        }, $OruvKa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1763881,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.EndDate = value.AsNullableValue($.$$.S.DateTime);
                        }, $yzerfh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1763881,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("NominationFee"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPostModel.$type, $.$discardRef(), "NominationFee", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("NominationFee")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$fPer.LCFCDM.Money), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "NominationFee";
                        $i5.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$fPer.LCFCDM.Money, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPostModel)).NominationFee);
                        }, $tAtdYb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1763881,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.NominationFee = value.AsNullableValue($.$fPer.LCFCDM.Money);
                        }, $ixuXbk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1763881,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SelfNomination"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPostModel.$type, $.$discardRef(), "SelfNomination", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SelfNomination")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "SelfNomination";
                        $i7.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPostModel)).SelfNomination);
                        }, $asBSdk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1763881,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.SelfNomination = value.AsBool();
                        }, $BUwKTe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1763881,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SingleNomination"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPostModel.$type, $.$discardRef(), "SingleNomination", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SingleNomination")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "SingleNomination";
                        $i9.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPostModel)).SingleNomination);
                        }, $cIPtqb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1763881,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SingleNomination = value.AsBool();
                        }, $UMAvsf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1763881,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DisableSelfVote"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPostModel.$type, $.$discardRef(), "DisableSelfVote", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DisableSelfVote")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "DisableSelfVote";
                        $i11.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPostModel)).DisableSelfVote);
                        }, $WRzVgc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1763881,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DisableSelfVote = value.AsBool();
                        }, $bzwqMk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1763881,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Type";
                        $i13.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPostModel)).Type);
                        }, $ILgFBh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1763881,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Candidates"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPostModel.$type, $.$discardRef(), "Candidates", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Candidates")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Candidates";
                        $i15.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPostModel)).Candidates);
                        }, $TpJqMe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1763881,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Candidates = value.AsReference($.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionCandidateModel));
                        }, $QLYsfh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1763881,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Positions"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPostModel.$type, $.$discardRef(), "Positions", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Positions")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionPositionModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Positions";
                        $i17.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionPositionModel), ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPostModel)).Positions);
                        }, $LZgSDd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1763881,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Positions = value.AsReference($.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionPositionModel));
                        }, $RMuVck ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1763881,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PositionLabel"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPostModel.$type, $.$discardRef(), "PositionLabel", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PositionLabel")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "PositionLabel";
                        $i19.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPostModel)).PositionLabel);
                        }, $ZcTeJh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1763881,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PositionLabel = value.AsReference($.$$.S.String);
                        }, $vfwyig ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1763881,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CandidateLabel"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPostModel.$type, $.$discardRef(), "CandidateLabel", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CandidateLabel")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "CandidateLabel";
                        $i21.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPostModel)).CandidateLabel);
                        }, $wLSHhj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1763881,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CandidateLabel = value.AsReference($.$$.S.String);
                        }, $IKKwbb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1763881,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("State"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$TBFc.LCCECM.CommunityElectionPostModel.$type, $.$discardRef(), "State", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("State")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$TBFc.LCCECM.CommunityElectionState, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "State";
                        $i23.DelaredOn = "LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$TBFc.LCCECM.CommunityElectionState, ($.$cast(target, $.$TBFc.LCCECM.CommunityElectionPostModel)).State);
                        }, $EjYeVf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1763881,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$TBFc.LCCECM.CommunityElectionCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886665769)
            
            //--TRIMMABLE-BOUNDARY-START(17181633065)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181633065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCategoryModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$TBFc.LCCECM.CommunityElectionCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$TBFc.LCCECM.CommunityElectionCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _StartDate = _target.StartDate;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StartDate"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateTime)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateTime), () => _StartDate, ($v) => _StartDate = $v, null, true)))
                    {
                        _target.StartDate = $.$clone(_StartDate);
                    }
                }
                {
                    /*var*/ let _EndDate = _target.EndDate;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EndDate"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateTime)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateTime), () => _EndDate, ($v) => _EndDate = $v, null, true)))
                    {
                        _target.EndDate = $.$clone(_EndDate);
                    }
                }
                {
                    /*var*/ let _NominationFee = _target.NominationFee;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("NominationFee"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$fPer.LCFCDM.Money)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$fPer.LCFCDM.Money), () => _NominationFee, ($v) => _NominationFee = $v, null, true)))
                    {
                        _target.NominationFee = $.$clone(_NominationFee);
                    }
                }
                {
                    /*var*/ let _SelfNomination = _target.SelfNomination;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SelfNomination"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _SelfNomination, ($v) => _SelfNomination = $v, null, true)))
                    {
                        _target.SelfNomination = _SelfNomination;
                    }
                }
                {
                    /*var*/ let _SingleNomination = _target.SingleNomination;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SingleNomination"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _SingleNomination, ($v) => _SingleNomination = $v, null, true)))
                    {
                        _target.SingleNomination = _SingleNomination;
                    }
                }
                {
                    /*var*/ let _DisableSelfVote = _target.DisableSelfVote;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DisableSelfVote"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _DisableSelfVote, ($v) => _DisableSelfVote = $v, null, true)))
                    {
                        _target.DisableSelfVote = _DisableSelfVote;
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Candidates = _target.Candidates;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Candidates"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionCandidateModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$TBFc.LCCECM.CommunityElectionCandidateModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$TBFc.LCCECM.CommunityElectionCandidateModel, property, $.$ref(() => _Candidates, ($v) => _Candidates = $v, $.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionCandidateModel))))
                    {
                        _target.Candidates = _Candidates;
                        if (_Candidates !== null)
                        {
                            let $en39 = _Candidates.SCG$IEnumerable$$$GetEnumerator();
                            while ($en39.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en39.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$TBFc.LCCECM.CommunityElectionCandidateModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$TBFc.LCCECM.CommunityElectionCandidateModel, property, $.$ref(() => _Candidates, ($v) => _Candidates = $v, $.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionCandidateModel)));
                    }
                }
                {
                    /*var*/ let _Positions = _target.Positions;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Positions"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionPositionModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$TBFc.LCCECM.CommunityElectionPositionModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$TBFc.LCCECM.CommunityElectionPositionModel, property, $.$ref(() => _Positions, ($v) => _Positions = $v, $.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionPositionModel))))
                    {
                        _target.Positions = _Positions;
                        if (_Positions !== null)
                        {
                            let $en44 = _Positions.SCG$IEnumerable$$$GetEnumerator();
                            while ($en44.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en44.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$TBFc.LCCECM.CommunityElectionPositionModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$TBFc.LCCECM.CommunityElectionPositionModel, property, $.$ref(() => _Positions, ($v) => _Positions = $v, $.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionPositionModel)));
                    }
                }
                {
                    /*var*/ let _PositionLabel = _target.PositionLabel;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PositionLabel"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _PositionLabel, ($v) => _PositionLabel = $v, $.$$.S.String)))
                    {
                        _target.PositionLabel = _PositionLabel;
                    }
                }
                {
                    /*var*/ let _CandidateLabel = _target.CandidateLabel;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CandidateLabel"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _CandidateLabel, ($v) => _CandidateLabel = $v, $.$$.S.String)))
                    {
                        _target.CandidateLabel = _CandidateLabel;
                    }
                }
                {
                    /*var*/ let _State = _target.State;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("State"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$TBFc.LCCECM.CommunityElectionState));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$TBFc.LCCECM.CommunityElectionState, () => _State, ($v) => _State = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181633065)
            
            //--TRIMMABLE-BOUNDARY-START(8591698473)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591698473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$TBFc.LCCECM.CommunityElectionPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$TBFc.LCCECM.CommunityElectionPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionPostModel)))
                {
                    /*var*/ let result = $.$TBFc.LCCECM.CommunityElectionPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$TBFc.LCCECM.CommunityElectionPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591698473)
            
            static $h = 1763881;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886665769),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1763881,
      "h": 12886665769,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886665769),
//--TRIMMABLE-BOUNDARY-START(17181633065),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1632809,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1763881,
      "h": 17181633065,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181633065),
//--TRIMMABLE-BOUNDARY-START(8591698473),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1632809,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1763881,
      "h": 8591698473,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591698473)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296731177),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1763881,
      "h": 4296731177,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296731177)
  ],
  "h": 1763881
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1763881)
        
        

        //--TRIMMABLE-BOUNDARY-START(1108521)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionModel`, ($self) => class CommunityElectionModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$TBFc.LCCECS$1.CommunityElectionSettings, $.$TBFc.LCCECS$2.CommunityElectionStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296075817)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296075817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296075817)
            
            //--TRIMMABLE-BOUNDARY-START(4296075817)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4296075817)
            
            static $h = 1108521;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$TBFc.LCCECS$1.CommunityElectionSettings, $.$TBFc.LCCECS$2.CommunityElectionStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296075817),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1108521,
      "h": 4296075817,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296075817)
  ],
  "h": 1108521
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1108521)
        
        

        //--TRIMMABLE-BOUNDARY-START(1239593)
        $asm.$cls(`$TBFc.LCCECM.CommunityElectionModelTypeDescriptor`, ($self) => class CommunityElectionModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296206889)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296206889);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$TBFc.LCCECM.CommunityElectionModelTypeDescriptor.GenerateProperties($.$TBFc.LCCECM.CommunityElectionModel, this, factory);
                    }, $WrfGFj ??= {"r":65537,"n":"","d":1239593,"h":0,"f":17825794}), 0, "CommunityElectionModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Election.Common\\Models_CommunityElectionModel_LivingThing.Core.Community.Election.Common.Models.CommunityElectionModelTypeDescriptorBuilder.g.cs", "CommunityElectionModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296206889)
            
            //--TRIMMABLE-BOUNDARY-START(12886141481)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886141481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$TBFc.LCCECS$1.CommunityElectionSettings, $.$TBFc.LCCECS$2.CommunityElectionStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886141481)
            
            //--TRIMMABLE-BOUNDARY-START(17181108777)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181108777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Election.Common.Settings.CommunityElectionSettings, LivingThing.Core.Community.Election.Common.States.CommunityElectionStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$TBFc.LCCECS$1.CommunityElectionSettings, $.$TBFc.LCCECS$2.CommunityElectionStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$TBFc.LCCECS$1.CommunityElectionSettings, $.$TBFc.LCCECS$2.CommunityElectionStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181108777)
            
            //--TRIMMABLE-BOUNDARY-START(8591174185)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Election.Common.Models.CommunityElectionModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591174185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$TBFc.LCCECM.CommunityElectionModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$TBFc.LCCECM.CommunityElectionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionModel)))
                {
                    /*var*/ let result = $.$TBFc.LCCECM.CommunityElectionModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$TBFc.LCCECM.CommunityElectionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$TBFc.LCCECM.CommunityElectionModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591174185)
            
            static $h = 1239593;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886141481),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1239593,
      "h": 12886141481,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886141481),
//--TRIMMABLE-BOUNDARY-START(17181108777),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1108521,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1239593,
      "h": 17181108777,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181108777),
//--TRIMMABLE-BOUNDARY-START(8591174185),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1108521,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1239593,
      "h": 8591174185,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591174185)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296206889),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1239593,
      "h": 4296206889,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296206889)
  ],
  "h": 1239593
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$TBFc.LCCECM.CommunityElectionModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Common.Models.CommunityElectionModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Common${separator}Models${separator}CommunityElectionModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1239593)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(59945)
