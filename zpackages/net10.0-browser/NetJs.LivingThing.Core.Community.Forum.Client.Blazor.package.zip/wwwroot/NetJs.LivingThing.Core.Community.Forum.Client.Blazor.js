
//--TRIMMABLE-BOUNDARY-START(56224)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $lAxY) {
    "use strict";
    let _;
    let $XZqsbb;
    let $uCWNta;
    let $imdfuj;
    let $ZdpvXb;
    let $ashLEe;
    let $zaMTUd;
    let $AtkKjh;
    let $vFoNug;
    let $WFseVi;
    let $WJHaDc;
    let $CrhWEd;
    let $lofmVg;
    let $DtprOf;
    let $CpQYLf;
    let $xKXiOh;
    let $vINGxb;
    let $jtNqKk;
    let $ViCXef;
    let $HisZsk;
    let $JcUfld;
    let $Zyqtzc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Forum.Client.Blazor", 
    {
  "h": 56224,
  "f": "LivingThing.Core.Community.Forum.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Forum.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Forum.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(187296)
        $asm.$cls(`$gUjM.LCCFC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295154592)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295154592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$gUjM.LCCFC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295154592)
            
            static $h = 187296;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295154592),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 187296,
      "h": 4295154592,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295154592)
  ],
  "h": 187296
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(187296)
        
        

        //--TRIMMABLE-BOUNDARY-START(252832)
        $asm.$cls(`$gUjM.LCCFC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180122016)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$gUjM.LCCFCP.CommunityForumApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$gUjM.LCCFCP.CommunityForumApp().$ctor$6();
                    }, $XZqsbb ??= {"r":2752627,"n":"","d":252832,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180122016)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295220128)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295220128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295220128)
            
            //--TRIMMABLE-BOUNDARY-START(4295220128)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295220128)
            
            static $h = 252832;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180122016),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885154720,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 252832,
      "h": 17180122016,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180122016)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295220128),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 252832,
      "h": 4295220128,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295220128)
  ],
  "h": 252832
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(252832)
        
        

        //--TRIMMABLE-BOUNDARY-START(514976)
        $asm.$cls(`$gUjM.LCCFC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590449568)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590449568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$gUjM.LCCFCS.CommunityForumService, $.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFCA$1.ISchemaOptionReader$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$lAxY.LCCFCM.CommunityForumCategoryReader, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$lAxY.LCCFCM.CommunityForumCategoryModel)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$lAxY.LCCFCM.CommunityForumCategoryReader, x);
                }, $ZdpvXb ??= {"r":$.$fPer.LCFCA$1.ISchemaOptionReader$$($.$lAxY.LCCFCM.CommunityForumCategoryModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":514976,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$gUjM.LCCFCS.CommunityForumThreadFeedProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel, $.$lAxY.LCCFCM.CommunityForumPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityUserDashboardApplicationPage, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$gUjM.LCCFCS.CommunityForumApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$gUjM.LCCFCS.CommunityForumApplication, x);
                }, $ashLEe ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":514976,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$gUjM.LCCFCS.CommunityForumApplication, x);
                }, $zaMTUd ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":514976,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityUserDashboardApplicationPage))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$gUjM.LCCFCS.CommunityForumApplication, x);
                }, $AtkKjh ??= {"r":19371456,"p":[{"n":"x","p":327718}],"n":"","d":514976,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel, $.$lAxY.LCCFCM.CommunityForumPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$gUjM.LCCFCS.CommunityForumApplication, x);
                }, $vFoNug ??= {"r":$.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel, $.$lAxY.LCCFCM.CommunityForumPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference).$h,"p":[{"n":"x","p":327718}],"n":"","d":514976,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$lAxY.LCCFCM.CommunityForumThreadModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$lAxY.LCCFCM.CommunityForumCategoryModel, services, null);
                $.$gUjM.LCCFC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590449568)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$gUjM.LCCFC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295482272)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295482272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295482272)
            
            //--TRIMMABLE-BOUNDARY-START(4295482272)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295482272)
            
            static $h = 514976;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590449568),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 514976,
      "h": 8590449568,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590449568)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295482272),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 514976,
      "h": 4295482272,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295482272)
  ],
  "h": 514976
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(514976)
        
        

        //--TRIMMABLE-BOUNDARY-START(1104800)
        $asm.$cls(`$gUjM.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296072096)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296072096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296072096)
            
            //--TRIMMABLE-BOUNDARY-START(4296072096)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296072096)
            
            static $h = 1104800;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296072096),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1104800,
      "h": 4296072096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296072096)
  ],
  "h": 1104800
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1104800)
        
        

        //--TRIMMABLE-BOUNDARY-START(1170336)
        $asm.$cls(`$gUjM.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296137632)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296137632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296137632)
            
            //--TRIMMABLE-BOUNDARY-START(4296137632)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296137632)
            
            static $h = 1170336;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296137632),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1170336,
      "h": 4296137632,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296137632)
  ],
  "h": 1170336,
  "a": [
    {
      "t": 1104800,
      "c": 4296072096
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1170336)
        
        

        //--TRIMMABLE-BOUNDARY-START(973728)
        $asm.$cls(`$gUjM.LCCFCS$1.ForumQA`, ($self) => class ForumQA extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590908320)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590908320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590908320)
            
            //--TRIMMABLE-BOUNDARY-START(4295941024)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295941024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295941024)
            
            //--TRIMMABLE-BOUNDARY-START(4295941024)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295941024)
            
            static $h = 973728;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590908320),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 973728,
      "h": 8590908320,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590908320)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295941024),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 973728,
      "h": 4295941024,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295941024)
  ],
  "h": 973728
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client.Shared.ForumQA`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}Shared${separator}ForumQA`; }
        });
        //--TRIMMABLE-BOUNDARY-END(973728)
        
        

        //--TRIMMABLE-BOUNDARY-START(318368)
        $asm.$cls(`$gUjM.LCCFCP.App`, ($self) => class App extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590252960)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590252960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590252960)
            
            //--TRIMMABLE-BOUNDARY-START(4295285664)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295285664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295285664)
            
            //--TRIMMABLE-BOUNDARY-START(4295285664)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295285664)
            
            static $h = 318368;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590252960),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 318368,
      "h": 8590252960,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590252960)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295285664),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 318368,
      "h": 4295285664,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295285664)
  ],
  "h": 318368
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client.Pages.App`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}Pages${separator}App`; }
        });
        //--TRIMMABLE-BOUNDARY-END(318368)
        
        

        //--TRIMMABLE-BOUNDARY-START(842656)
        $asm.$cls(`$gUjM.LCCFCS$1.ForumPoll`, ($self) => class ForumPoll extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590777248)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590777248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590777248)
            
            //--TRIMMABLE-BOUNDARY-START(4295809952)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295809952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295809952)
            
            //--TRIMMABLE-BOUNDARY-START(4295809952)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295809952)
            
            static $h = 842656;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590777248),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 842656,
      "h": 8590777248,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590777248)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295809952),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 842656,
      "h": 4295809952,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295809952)
  ],
  "h": 842656
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client.Shared.ForumPoll`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}Shared${separator}ForumPoll`; }
        });
        //--TRIMMABLE-BOUNDARY-END(842656)
        
        

        //--TRIMMABLE-BOUNDARY-START(121760)
        $asm.$cls(`$gUjM.LCCFC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590056352)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590056352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590056352)
            
            //--TRIMMABLE-BOUNDARY-START(4295089056)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295089056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295089056)
            
            //--TRIMMABLE-BOUNDARY-START(4295089056)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295089056)
            
            static $h = 121760;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590056352),
    {
      "r": 65537,
      "n": "Execute",
      "d": 121760,
      "h": 8590056352,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590056352)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295089056),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 121760,
      "h": 4295089056,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295089056)
  ],
  "h": 121760
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(121760)
        
        

        //--TRIMMABLE-BOUNDARY-START(908192)
        $asm.$cls(`$gUjM.LCCFCS$1.ForumPostMicro`, ($self) => class ForumPostMicro extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590842784)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590842784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMarkupContent(1, "<h4 class=\"mgt-0 mgb-1 cl-primary\">My Reply</h4>\r\n    ");
                __builder.AddMarkupContent(2, "<em class=\"d-block fsz-small\">Lorem ipsum reply</em>\r\n    ");
                __builder.OpenElement(3, "small");
                __builder.AddContent$4(4, "Posted by ");
                __builder.OpenComponent$1($.$macw.MACR$2.NavLink, 5);
                __builder.AddAttribute$3(6, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$4(7, "Samson");
                }), $uCWNta ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":908192,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddContent$4(8, ", 9/21/2013 3:22 PM in ");
                __builder.OpenComponent$1($.$macw.MACR$2.NavLink, 9);
                __builder.AddAttribute$3(10, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$4(11, "Generic");
                }), $imdfuj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":908192,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590842784)
            
            //--TRIMMABLE-BOUNDARY-START(4295875488)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295875488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295875488)
            
            //--TRIMMABLE-BOUNDARY-START(4295875488)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295875488)
            
            static $h = 908192;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590842784),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 908192,
      "h": 8590842784,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590842784)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295875488),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 908192,
      "h": 4295875488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295875488)
  ],
  "h": 908192
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client.Shared.ForumPostMicro`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}Shared${separator}ForumPostMicro`; }
        });
        //--TRIMMABLE-BOUNDARY-END(908192)
        
        

        //--TRIMMABLE-BOUNDARY-START(1039264)
        $asm.$cls(`$gUjM.LCCFCS$1.ForumWindow`, ($self) => class ForumWindow extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590973856)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590973856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590973856)
            
            //--TRIMMABLE-BOUNDARY-START(4296006560)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296006560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296006560)
            
            //--TRIMMABLE-BOUNDARY-START(4296006560)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296006560)
            
            static $h = 1039264;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590973856),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1039264,
      "h": 8590973856,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590973856)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296006560),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1039264,
      "h": 4296006560,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296006560)
  ],
  "h": 1039264
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client.Shared.ForumWindow`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}Shared${separator}ForumWindow`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1039264)
        
        

        //--TRIMMABLE-BOUNDARY-START(449440)
        $asm.$cls(`$gUjM.LCCFCP.UserApp<>`, (TAccountModel) => $asm.$gt(`$gUjM.LCCFCP.UserApp<>`, [TAccountModel], ($self) => class UserApp$$ extends $.$lJUR.LCFCS.ApplicationPageBase$$(TAccountModel)
        {
            //--TRIMMABLE-BOUNDARY-START(21475285920)
            /*string */ get OptimizedComponentName()
            {
                return "userapp";
            }
            //--TRIMMABLE-BOUNDARY-END(21475285920)
            
            //--TRIMMABLE-BOUNDARY-START(8590384032)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590384032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 0);
                __builder.AddComponentParameter(1, "Name", "Forum/Questions");
                __builder.AddComponentParameter(2, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("OwnForum/Questions")));
                __builder.AddComponentParameter(3, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)))().$ctor(this, ( (/*e*/ e) =>
                {
                    return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~12/*CommunityLayoutFeatures.PadX*/, null, null, true);
                }), $WFseVi ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.AddAttribute$3(4, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(5, "<b>Questions</b>");
                    }, $WJHaDc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }), $CrhWEd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.AddAttribute$3(6, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(7, "<i class=\"mdi mdi-forum\"></i>");
                    }, $lofmVg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }), $DtprOf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.AddAttribute$3(8, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunityAppIntro, 9);
                        __builder2.AddComponentParameter(10, "Class", "mgb");
                        __builder2.AddComponentParameter(11, "Title", "QUESTIONS");
                        __builder2.AddComponentParameter(12, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Parameter.Title));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(13, "\r\n        ");
                        __builder2.OpenComponent$1($.$ahDc.LCCCSP.CommunityPosts$$($.$lAxY.LCCFCM.CommunityForumThreadModel), 14);
                        __builder2.AddComponentParameter(15, "Class", "mgt-10");
                        __builder2.AddComponentParameter(16, "Filter", new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Parameter.Account.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)));
                        __builder2.CloseComponent();
                    }, $CpQYLf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }), $xKXiOh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(17, "\r\n");
                __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 18);
                __builder.AddComponentParameter(19, "Name", "Forum/Followed");
                __builder.AddComponentParameter(20, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("OwnForum/Followed")));
                __builder.AddAttribute$3(21, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(22, "<b>Followed</b>");
                    }, $vINGxb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }), $jtNqKk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.AddAttribute$3(23, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(24, "<i class=\"mdi mdi-heart\"></i>");
                    }, $ViCXef ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }), $HisZsk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.AddAttribute$3(25, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunityAppIntro, 26);
                        __builder2.AddComponentParameter(27, "Class", "mgb");
                        __builder2.AddComponentParameter(28, "Title", "Followed");
                        __builder2.AddComponentParameter(29, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Parameter.Title));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(30, "\r\n        ");
                        __builder2.OpenComponent$1($.$ahDc.LCCCSP.CommunityPosts$$($.$lAxY.LCCFCM.CommunityForumThreadModel), 31);
                        __builder2.AddComponentParameter(32, "Class", "mgt-10");
                        __builder2.AddComponentParameter(33, "Filter", new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Parameter.Account.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741827/*PostFilterTypes.Subscriptions*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)));
                        __builder2.CloseComponent();
                    }, $JcUfld ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }), $Zyqtzc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590384032)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295416736)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295416736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295416736)
            
            //--TRIMMABLE-BOUNDARY-START(4295416736)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295416736)
            
            static $H = 449440;
            static $h = 449440;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationPageBase$$(TAccountModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475285920),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17180318624,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 21475285920,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475285920)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590384032),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 8590384032,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590384032)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295416736),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 4295416736,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295416736)
  ],
  "s": [
    {
      "h": TAccountModel?.$h??1572864,
      "n": "TAccountModel",
      "c": [6220212
      ]
    }
  ],
  "r": 1,
  "H": 449440,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client.Pages.UserApp<${TAccountModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}Pages${separator}UserApp$${TAccountModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(449440)
        
        

        //--TRIMMABLE-BOUNDARY-START(646048)
        $asm.$cls(`$gUjM.LCCFCS.CommunityForumPostFeedProvider`, ($self) => class CommunityForumPostFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$lAxY.LCCFCM.CommunityForumPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295613344)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295613344);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295613344)
            
            //--TRIMMABLE-BOUNDARY-START(8590580640)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityForumPostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590580640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`answered a question in forum`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590580640)
            
            static $h = 646048;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$lAxY.LCCFCM.CommunityForumPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590580640),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 553417
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 646048,
      "h": 8590580640,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590580640)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295613344),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 646048,
      "h": 4295613344,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295613344)
  ],
  "h": 646048
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client.Services.CommunityForumPostFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}Services${separator}CommunityForumPostFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(646048)
        
        

        //--TRIMMABLE-BOUNDARY-START(777120)
        $asm.$cls(`$gUjM.LCCFCS.CommunityForumThreadFeedProvider`, ($self) => class CommunityForumThreadFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$lAxY.LCCFCM.CommunityForumThreadModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295744416)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295744416);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295744416)
            
            //--TRIMMABLE-BOUNDARY-START(8590711712)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityForumThreadModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590711712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1("asked a question in forum", false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590711712)
            
            static $h = 777120;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$lAxY.LCCFCM.CommunityForumThreadModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590711712),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 815561
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 777120,
      "h": 8590711712,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590711712)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295744416),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 777120,
      "h": 4295744416,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295744416)
  ],
  "h": 777120
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client.Services.CommunityForumThreadFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}Services${separator}CommunityForumThreadFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(777120)
        
        

        //--TRIMMABLE-BOUNDARY-START(383904)
        $asm.$cls(`$gUjM.LCCFCP.CommunityForumApp`, ($self) => class CommunityForumApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel, $.$lAxY.LCCFCM.CommunityForumPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(111669533600)
            /*string*/ ProviderId = null;
            //--TRIMMABLE-BOUNDARY-END(111669533600)
            
            //--TRIMMABLE-BOUNDARY-START(34360122272)
            /*string*/ CategoryId = null;
            //--TRIMMABLE-BOUNDARY-END(34360122272)
            
            //--TRIMMABLE-BOUNDARY-START(42950056864)
            /*CommunityForumService*/ ForumService = null;
            //--TRIMMABLE-BOUNDARY-END(42950056864)
            
            //--TRIMMABLE-BOUNDARY-START(38655089568)
            /*CommunityForumApplication*/ ForumApplication = null;
            //--TRIMMABLE-BOUNDARY-END(38655089568)
            
            //--TRIMMABLE-BOUNDARY-START(25770187680)
            /*ICommunityClientApplication */ get Application()
            {
                return this.ForumApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(25770187680)
            
            //--TRIMMABLE-BOUNDARY-START(103079599008)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079599008);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Service.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103079599008)
            
            //--TRIMMABLE-BOUNDARY-START(107374566304)
            /*string */ get OptimizedComponentName()
            {
                return "communityforumapp communitydefaultpages";
            }
            //--TRIMMABLE-BOUNDARY-END(107374566304)
            
            //--TRIMMABLE-BOUNDARY-START(150324239264)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324239264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch3 = parameter.Name;
                switch($switch3)
                {
                    case "ProviderId":
                    this.ProviderId = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "CategoryId":
                    this.CategoryId = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(150324239264)
            
            //--TRIMMABLE-BOUNDARY-START(98784631712)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784631712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ForumService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$gUjM.LCCFCS.CommunityForumService, serviceProvider);
                this.ForumApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$gUjM.LCCFCS.CommunityForumApplication, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(98784631712)
            
            //--TRIMMABLE-BOUNDARY-START(30065154976)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065154976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
            }
            //--TRIMMABLE-BOUNDARY-END(30065154976)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21475220384)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475220384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475220384)
            
            //--TRIMMABLE-BOUNDARY-START(21475220384)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(21475220384)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42950056864)
                this.ForumService = null;
                //--TRIMMABLE-BOUNDARY-END(42950056864)
                
                //--TRIMMABLE-BOUNDARY-START(38655089568)
                this.ForumApplication = null;
                //--TRIMMABLE-BOUNDARY-END(38655089568)
                
            }
            static $h = 383904;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel, $.$lAxY.LCCFCM.CommunityForumPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111669533600),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489664416,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029271968,
        "f": 83886081
      },
      "n": "ProviderId",
      "d": 383904,
      "h": 111669533600,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669533600),
//--TRIMMABLE-BOUNDARY-START(34360122272),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129926048,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259468192,
        "f": 83886081
      },
      "n": "CategoryId",
      "d": 383904,
      "h": 34360122272,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360122272),
//--TRIMMABLE-BOUNDARY-START(42950056864),
    {
      "p": 711584,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309795232,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439337376,
        "f": 83886081
      },
      "n": "ForumService",
      "d": 383904,
      "h": 42950056864,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950056864),
//--TRIMMABLE-BOUNDARY-START(38655089568),
    {
      "p": 580512,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719860640,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849402784,
        "f": 83886081
      },
      "n": "ForumApplication",
      "d": 383904,
      "h": 38655089568,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655089568),
//--TRIMMABLE-BOUNDARY-START(25770187680),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539991456,
        "f": 50364420
      },
      "n": "Application",
      "d": 383904,
      "h": 25770187680,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(25770187680),
//--TRIMMABLE-BOUNDARY-START(107374566304),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899729824,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 383904,
      "h": 107374566304,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107374566304)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103079599008),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 383904,
      "h": 103079599008,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(103079599008),
//--TRIMMABLE-BOUNDARY-START(150324239264),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 383904,
      "h": 150324239264,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324239264),
//--TRIMMABLE-BOUNDARY-START(98784631712),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 383904,
      "h": 98784631712,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98784631712),
//--TRIMMABLE-BOUNDARY-START(30065154976),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 383904,
      "h": 30065154976,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30065154976)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475220384),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 383904,
      "h": 21475220384,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475220384)
  ],
  "h": 383904
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client.Pages.CommunityForumApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}Pages${separator}CommunityForumApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(383904)
        
        

        //--TRIMMABLE-BOUNDARY-START(711584)
        $asm.$cls(`$gUjM.LCCFCS.CommunityForumService`, ($self) => class CommunityForumService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295678880)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295678880);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295678880)
            
            //--TRIMMABLE-BOUNDARY-START(17180580768)
            /*bool */ get LoadCategories()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180580768)
            
            static $h = 711584;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180580768),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885613472,
        "f": 50364417
      },
      "n": "LoadCategories",
      "d": 711584,
      "h": 17180580768,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180580768)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295678880),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 711584,
      "h": 4295678880,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295678880)
  ],
  "h": 711584
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client.Services.CommunityForumService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}Services${separator}CommunityForumService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(711584)
        
        

        //--TRIMMABLE-BOUNDARY-START(580512)
        $asm.$cls(`$gUjM.LCCFCS.CommunityForumApplication`, ($self) => class CommunityForumApplication extends $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel, $.$lAxY.LCCFCM.CommunityForumPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(12885482400)
            $ctor$3(/*CommunityForumService*/ service)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885482400);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885482400)
            
            //--TRIMMABLE-BOUNDARY-START(163209337760)
            /*string */ get Name()
            {
                return "Forum";
            }
            //--TRIMMABLE-BOUNDARY-END(163209337760)
            
            //--TRIMMABLE-BOUNDARY-START(184684174240)
            /*string */ get Title()
            {
                return "Forum";
            }
            //--TRIMMABLE-BOUNDARY-END(184684174240)
            
            //--TRIMMABLE-BOUNDARY-START(30065351584)
            /*string */ get Description()
            {
                return "Ask questions, get answers";
            }
            //--TRIMMABLE-BOUNDARY-END(30065351584)
            
            //--TRIMMABLE-BOUNDARY-START(158914370464)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-forum"/*MaterialDesignIconNames.Forum*/);
            }
            //--TRIMMABLE-BOUNDARY-END(158914370464)
            
            //--TRIMMABLE-BOUNDARY-START(180389206944)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#0D3B66";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(180389206944)
            
            //--TRIMMABLE-BOUNDARY-START(38655286176)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/ | 4/*ApplicationServiceFeatures.Recommended*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38655286176)
            
            //--TRIMMABLE-BOUNDARY-START(17180449696)
            /*Type? */ get ApplicationViewType()
            {
                return $.$gUjM.LCCFCP.CommunityForumApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180449696)
            
            //--TRIMMABLE-BOUNDARY-START(154619403168)
            /*RenderFragment? */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619403168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(154619403168)
            
            //--TRIMMABLE-BOUNDARY-START(34360318880)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360318880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(34360318880)
            
            //--TRIMMABLE-BOUNDARY-START(171799272352)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799272352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(171799272352)
            
            //--TRIMMABLE-BOUNDARY-START(167504305056)
            /*int */ get Order()
            {
                return 3000;
            }
            //--TRIMMABLE-BOUNDARY-END(167504305056)
            
            //--TRIMMABLE-BOUNDARY-START(25770384288)
            /*string */ get CreateLink()
            {
                return "Forum/EditPost";
            }
            //--TRIMMABLE-BOUNDARY-END(25770384288)
            
            //--TRIMMABLE-BOUNDARY-START(21475416992)
            /*string */ get CreateLabel()
            {
                return "Ask a Question";
            }
            //--TRIMMABLE-BOUNDARY-END(21475416992)
            
            //--TRIMMABLE-BOUNDARY-START(4295547808)
            /*CommunityForumService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295547808)
            
            //--TRIMMABLE-BOUNDARY-START(176094239648)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(176094239648)
            
            //--TRIMMABLE-BOUNDARY-START(188979141536)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(1024/*PostTypes.Forum*/, 1028/*PostTypes.ForumEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(188979141536)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            //--TRIMMABLE-BOUNDARY-START(25772137952)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.ICreatorApplicationProxy.CreateLink.get
            get LCFCA$ICreatorApplicationProxy$CreateLink()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592268768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLink;
            }
            //--TRIMMABLE-BOUNDARY-END(25772137952)
            
            //--TRIMMABLE-BOUNDARY-START(17182203360)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.ICreatorApplicationProxy.CreateLabel.get
            get LCFCA$ICreatorApplicationProxy$CreateLabel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297301472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLabel;
            }
            //--TRIMMABLE-BOUNDARY-END(17182203360)
            
            static $h = 580512;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel, $.$lAxY.LCCFCM.CommunityForumPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(163209337760),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374762912,
        "f": 50364417
      },
      "n": "Name",
      "d": 580512,
      "h": 163209337760,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209337760),
//--TRIMMABLE-BOUNDARY-START(184684174240),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734501280,
        "f": 50364417
      },
      "n": "Title",
      "d": 580512,
      "h": 184684174240,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(184684174240),
//--TRIMMABLE-BOUNDARY-START(30065351584),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604959136,
        "f": 50364417
      },
      "n": "Description",
      "d": 580512,
      "h": 30065351584,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065351584),
//--TRIMMABLE-BOUNDARY-START(158914370464),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784828320,
        "f": 50364417
      },
      "n": "Icon",
      "d": 580512,
      "h": 158914370464,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914370464),
//--TRIMMABLE-BOUNDARY-START(180389206944),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144566688,
        "f": 50364417
      },
      "n": "Theme",
      "d": 580512,
      "h": 180389206944,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389206944),
//--TRIMMABLE-BOUNDARY-START(38655286176),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194893728,
        "f": 50364417
      },
      "n": "Features",
      "d": 580512,
      "h": 38655286176,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655286176),
//--TRIMMABLE-BOUNDARY-START(17180449696),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835155360,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 580512,
      "h": 17180449696,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180449696),
//--TRIMMABLE-BOUNDARY-START(167504305056),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964697504,
        "f": 50364417
      },
      "n": "Order",
      "d": 580512,
      "h": 167504305056,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(167504305056),
//--TRIMMABLE-BOUNDARY-START(25770384288),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015024544,
        "f": 50331649
      },
      "n": "CreateLink",
      "d": 580512,
      "h": 25770384288,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770384288),
//--TRIMMABLE-BOUNDARY-START(21475416992),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425089952,
        "f": 50331649
      },
      "n": "CreateLabel",
      "d": 580512,
      "h": 21475416992,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475416992),
//--TRIMMABLE-BOUNDARY-START(4295547808),
    {
      "p": 711584,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245220768,
        "f": 50331650
      },
      "n": "_Service",
      "d": 580512,
      "h": 4295547808,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295547808),
//--TRIMMABLE-BOUNDARY-START(176094239648),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554632096,
        "f": 50364417
      },
      "n": "Service",
      "d": 580512,
      "h": 176094239648,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176094239648),
//--TRIMMABLE-BOUNDARY-START(188979141536),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324435872,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 580512,
      "h": 188979141536,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(188979141536)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(154619403168),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 580512,
      "h": 154619403168,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(154619403168),
//--TRIMMABLE-BOUNDARY-START(34360318880),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 580512,
      "h": 34360318880,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360318880),
//--TRIMMABLE-BOUNDARY-START(171799272352),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 580512,
      "h": 171799272352,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171799272352)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885482400),
    {
      "p": [
        {
          "n": "service",
          "p": 711584
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 580512,
      "h": 12885482400,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885482400)
  ],
  "h": 580512
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel, $.$lAxY.LCCFCM.CommunityForumPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$lAxY.LCCFCM.CommunityForumThreadModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$ahDc.LCCCS.ICommunitySearchApplication, $.$ahDc.LCCCS.ICommunityCreatorApplication, $.$ahDc.LCCCS.ICommunityClientApplication, $.$sZVd.LCFCA.IClientApplication, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$yleQ.LCFCA.ICreatorApplicationProxy, $.$ahDc.LCCCS.ICommunityUserDashboardApplicationPage, $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$LCOv.LCFCPM$1.AccountModel), $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Client.Services.CommunityForumApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Client${separator}Services${separator}CommunityForumApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(580512)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Forum.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(56224)
