
//--TRIMMABLE-BOUNDARY-START(29129)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $zSzsqd;
    let $Ebseee;
    let $UTFBad;
    let $BCsxoh;
    let $vdbbFf;
    let $ibEWnj;
    let $ZZvWpc;
    let $OCLVEd;
    let $dBMcNi;
    let $VZdKwi;
    let $wjzTid;
    let $LIOfEb;
    let $ybYPdi;
    let $biskOh;
    let $sygejj;
    let $BxMAac;
    let $iBHyag;
    let $RYoNQg;
    let $UgySbf;
    let $tYGhUh;
    let $EbcTeh;
    let $SeYFDd;
    let $gdsaEj;
    let $PCQXVb;
    let $ykCOVb;
    let $etvqNa;
    let $EKvWLe;
    let $jpVFLk;
    let $YdDpxb;
    let $VoTTuj;
    let $TRfBwk;
    let $mSVQvi;
    let $CDAJPh;
    let $LBRUta;
    let $WGbtsk;
    let $mWynNj;
    let $jgajCh;
    let $Wresgb;
    let $tbOYYc;
    let $HEDbUk;
    let $tQvsSf;
    let $QQmQKe;
    let $gUtAjg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Forum.Common", 
    {
  "h": 29129,
  "f": "LivingThing.Core.Community.Forum.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Forum.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Forum.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1274313)
        $asm.$cls(`$lAxY.LCCFCS.ICommunityForumRemoteService`, ($self) => class ICommunityForumRemoteService
        {
            static $h = 1274313;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1274313,
  "a": [
    {
      "t": 3537875,
      "c": 8593472467,
      "a": [
        {
          "v": [$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$lAxY.LCCFCM.CommunityForumThreadModel).$h,$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$lAxY.LCCFCM.CommunityForumPostModel).$h,$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel).$h
          ],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Services.ICommunityForumRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Services${separator}ICommunityForumRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1274313)
        
        

        //--TRIMMABLE-BOUNDARY-START(1536457)
        $asm.$cls(`$lAxY.LCCFC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296503753)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296503753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$lAxY.LCCFCM.CommunityForumCategoryModelTypeDescriptorBuilder.Register();
                $.$lAxY.LCCFCM.CommunityForumPostModelTypeDescriptorBuilder.Register();
                $.$lAxY.LCCFCM.CommunityForumThreadModelTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296503753)
            
            static $h = 1536457;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296503753),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1536457,
      "h": 4296503753,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296503753)
  ],
  "h": 1536457
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1536457)
        
        

        //--TRIMMABLE-BOUNDARY-START(94665)
        $asm.$cls(`$lAxY.LCCFC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295061961)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295061961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$lAxY.LCCFCM.CommunityForumCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$lAxY.LCCFCM.CommunityForumCategoryModelCustomAttributesProvider, $.$lAxY.LCCFCM.CommunityForumCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$lAxY.LCCFCM.CommunityForumPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$lAxY.LCCFCM.CommunityForumPostModelCustomAttributesProvider, $.$lAxY.LCCFCM.CommunityForumPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$lAxY.LCCFCM.CommunityForumThreadModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$lAxY.LCCFCM.CommunityForumThreadModelCustomAttributesProvider, $.$lAxY.LCCFCM.CommunityForumThreadModelCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295061961)
            
            static $h = 94665;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295061961),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 94665,
      "h": 4295061961,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295061961)
  ],
  "h": 94665
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(94665)
        
        

        //--TRIMMABLE-BOUNDARY-START(291273)
        $asm.$cls(`$lAxY.LCCFCM.CommunityForumCategoryModelCustomAttributesProvider`, ($self) => class CommunityForumCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295258569)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295258569)
            
            //--TRIMMABLE-BOUNDARY-START(8590225865)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590225865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$lAxY.LCCFCM.CommunityForumCategoryModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["/Icon=Forum"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$lAxY.LCCFCM.CommunityForumCategoryModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $vdbbFf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":291273,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $ibEWnj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":291273,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590225865)
            
            static $h = 291273;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590225865),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 291273,
      "h": 8590225865,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590225865)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295258569),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 291273,
      "h": 4295258569,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295258569)
  ],
  "h": 291273
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Models${separator}CommunityForumCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(291273)
        
        

        //--TRIMMABLE-BOUNDARY-START(881097)
        $asm.$cls(`$lAxY.LCCFCM.CommunityForumThreadModelCustomAttributesProvider`, ($self) => class CommunityForumThreadModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295848393)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295848393)
            
            //--TRIMMABLE-BOUNDARY-START(8590815689)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590815689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$lAxY.LCCFCM.CommunityForumThreadModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("IsThread", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$lAxY.LCCFCM.CommunityForumThreadModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $zSzsqd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":881097,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $Ebseee ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":881097,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590815689)
            
            static $h = 881097;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590815689),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 881097,
      "h": 8590815689,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590815689)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295848393),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 881097,
      "h": 4295848393,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295848393)
  ],
  "h": 881097
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Models${separator}CommunityForumThreadModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(881097)
        
        

        //--TRIMMABLE-BOUNDARY-START(160201)
        $asm.$cls(`$lAxY.LCCFC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295127497)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295127497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$lAxY.LCCFCS.ICommunityForumPostFeedRemoteService, $.$lAxY.LCCFCS.ICommunityForumPostFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCCFCS.ICommunityForumPostFeedRemoteService_Mocking().$ctor$3(impl);
                }, $ybYPdi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$lAxY.LCCFCS.ICommunityForumPostFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCCFCS.ICommunityForumPostFeedRemoteService_Mocking().$ctor$3(impl);
                }, $biskOh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$lAxY.LCCFCS.ICommunityForumRemoteService, $.$lAxY.LCCFCS.ICommunityForumRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCCFCS.ICommunityForumRemoteService_Mocking().$ctor$3(impl);
                }, $sygejj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking().$ctor$3(impl);
                }, $BxMAac ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking().$ctor$3(impl);
                }, $iBHyag ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking().$ctor$3(impl);
                }, $RYoNQg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking().$ctor$3(impl);
                }, $UgySbf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking().$ctor$3(impl);
                }, $tYGhUh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking().$ctor$3(impl);
                }, $EbcTeh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking().$ctor$3(impl);
                }, $SeYFDd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking().$ctor$3(impl);
                }, $gdsaEj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking().$ctor$3(impl);
                }, $PCQXVb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking().$ctor$3(impl);
                }, $ykCOVb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking().$ctor$3(impl);
                }, $etvqNa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking().$ctor$3(impl);
                }, $EKvWLe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking().$ctor$3(impl);
                }, $jpVFLk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking().$ctor$3(impl);
                }, $YdDpxb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking().$ctor$3(impl);
                }, $VoTTuj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking().$ctor$3(impl);
                }, $TRfBwk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking().$ctor$3(impl);
                }, $mSVQvi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking().$ctor$3(impl);
                }, $CDAJPh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking().$ctor$3(impl);
                }, $LBRUta ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking().$ctor$3(impl);
                }, $WGbtsk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking().$ctor$3(impl);
                }, $mWynNj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$lAxY.LCCFCS.ICommunityForumThreadFeedRemoteService, $.$lAxY.LCCFCS.ICommunityForumThreadFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCCFCS.ICommunityForumThreadFeedRemoteService_Mocking().$ctor$3(impl);
                }, $jgajCh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$lAxY.LCCFCS.ICommunityForumThreadFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lAxY.LCCFCS.ICommunityForumThreadFeedRemoteService_Mocking().$ctor$3(impl);
                }, $Wresgb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160201,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295127497)
            
            static $h = 160201;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295127497),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 160201,
      "h": 4295127497,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295127497)
  ],
  "h": 160201
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(160201)
        
        

        //--TRIMMABLE-BOUNDARY-START(618953)
        $asm.$cls(`$lAxY.LCCFCM.CommunityForumPostModelCustomAttributesProvider`, ($self) => class CommunityForumPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295586249)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295586249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295586249)
            
            static $h = 618953;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295586249),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 618953,
      "h": 4295586249,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295586249)
  ],
  "h": 618953
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Models${separator}CommunityForumPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(618953)
        
        

        //--TRIMMABLE-BOUNDARY-START(750025)
        $asm.$cls(`$lAxY.LCCFCM.CommunityForumPostModelTypeDescriptorBuilder`, ($self) => class CommunityForumPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590684617)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590684617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$lAxY.LCCFCM.CommunityForumPostModelTypeDescriptor()
                        const $t1 = $.$lAxY.LCCFCM.CommunityForumPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $VZdKwi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":750025,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$lAxY.LCCFCM.CommunityForumPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590684617)
            
            //--TRIMMABLE-BOUNDARY-START(4295717321)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295717321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295717321)
            
            //--TRIMMABLE-BOUNDARY-START(4295717321)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295717321)
            
            static $h = 750025;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590684617),
    {
      "r": 65537,
      "n": "Register",
      "d": 750025,
      "h": 8590684617,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590684617)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295717321),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 750025,
      "h": 4295717321,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295717321)
  ],
  "h": 750025
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Models${separator}CommunityForumPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(750025)
        
        

        //--TRIMMABLE-BOUNDARY-START(422345)
        $asm.$cls(`$lAxY.LCCFCM.CommunityForumCategoryModelTypeDescriptorBuilder`, ($self) => class CommunityForumCategoryModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590356937)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590356937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$lAxY.LCCFCM.CommunityForumCategoryModelTypeDescriptor()
                        const $t1 = $.$lAxY.LCCFCM.CommunityForumCategoryModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ZZvWpc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":422345,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$lAxY.LCCFCM.CommunityForumCategoryModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590356937)
            
            //--TRIMMABLE-BOUNDARY-START(4295389641)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295389641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295389641)
            
            //--TRIMMABLE-BOUNDARY-START(4295389641)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295389641)
            
            static $h = 422345;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590356937),
    {
      "r": 65537,
      "n": "Register",
      "d": 422345,
      "h": 8590356937,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590356937)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295389641),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 422345,
      "h": 4295389641,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295389641)
  ],
  "h": 422345
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Models${separator}CommunityForumCategoryModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(422345)
        
        

        //--TRIMMABLE-BOUNDARY-START(1012169)
        $asm.$cls(`$lAxY.LCCFCM.CommunityForumThreadModelTypeDescriptorBuilder`, ($self) => class CommunityForumThreadModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590946761)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590946761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$lAxY.LCCFCM.CommunityForumThreadModelTypeDescriptor()
                        const $t1 = $.$lAxY.LCCFCM.CommunityForumThreadModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $tbOYYc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1012169,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$lAxY.LCCFCM.CommunityForumThreadModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590946761)
            
            //--TRIMMABLE-BOUNDARY-START(4295979465)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295979465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295979465)
            
            //--TRIMMABLE-BOUNDARY-START(4295979465)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295979465)
            
            static $h = 1012169;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590946761),
    {
      "r": 65537,
      "n": "Register",
      "d": 1012169,
      "h": 8590946761,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590946761)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295979465),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1012169,
      "h": 4295979465,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295979465)
  ],
  "h": 1012169
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Models${separator}CommunityForumThreadModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1012169)
        
        

        //--TRIMMABLE-BOUNDARY-START(1077705)
        $asm.$cls(`$lAxY.LCCFC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591012297)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591012297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$lAxY.LCCFCM.CommunityForumCategoryModel, 1025/*PostTypes.ForumCategory*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$lAxY.LCCFCM.CommunityForumThreadModel, 1026/*PostTypes.ForumDiscussion*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$lAxY.LCCFCM.CommunityForumPostModel, 1027/*PostTypes.ForumPost*/);
                $.$lAxY.LCCFC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$lAxY.LCCFC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$lAxY.LCCFC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591012297)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$lAxY.LCCFC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296045001)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296045001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296045001)
            
            //--TRIMMABLE-BOUNDARY-START(4296045001)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296045001)
            
            static $h = 1077705;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591012297),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1077705,
      "h": 8591012297,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591012297)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296045001),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1077705,
      "h": 4296045001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296045001)
  ],
  "h": 1077705
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1077705)
        
        

        //--TRIMMABLE-BOUNDARY-START(1339849)
        $asm.$cls(`$lAxY.LCCFCS.ICommunityForumRemoteService_Mocking`, ($self) => class ICommunityForumRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296307145)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296307145);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296307145)
            
            static $h = 1339849;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296307145),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1339849,
      "h": 4296307145,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296307145)
  ],
  "h": 1339849
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$lAxY.LCCFCS.ICommunityForumRemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Services.ICommunityForumRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Services${separator}ICommunityForumRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1339849)
        
        

        //--TRIMMABLE-BOUNDARY-START(553417)
        $asm.$cls(`$lAxY.LCCFCM.CommunityForumPostModel`, ($self) => class CommunityForumPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295520713)
            $ctor$6()
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295520713);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = "_";
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295520713)
            
            //--TRIMMABLE-BOUNDARY-START(55835128265)
            /*PostTypes */ get Type()
            {
                return 1027/*PostTypes.ForumPost*/;
            }
            //--TRIMMABLE-BOUNDARY-END(55835128265)
            
            //--TRIMMABLE-BOUNDARY-START(42950226377)
            /*bool */ ShouldEditName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950226377);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950226377)
            
            //--TRIMMABLE-BOUNDARY-START(25770357193)
            /*bool */ RequiresName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770357193);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770357193)
            
            //--TRIMMABLE-BOUNDARY-START(47245193673)
            /*bool */ ShouldEditSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245193673);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245193673)
            
            //--TRIMMABLE-BOUNDARY-START(30065324489)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065324489);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065324489)
            
            //--TRIMMABLE-BOUNDARY-START(38655259081)
            /*bool */ ShouldEditIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655259081);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655259081)
            
            //--TRIMMABLE-BOUNDARY-START(21475389897)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475389897);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475389897)
            
            //--TRIMMABLE-BOUNDARY-START(51540160969)
            /*bool */ ShouldEditTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540160969);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540160969)
            
            //--TRIMMABLE-BOUNDARY-START(34360291785)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360291785);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360291785)
            
            //--TRIMMABLE-BOUNDARY-START(17180422601)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180422601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Schema === 1/*SchemaType.Form*/)
                {
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Post", "Reply", "Reply to Forum Question", "mdi mdi-message-reply-text-outline"/*MaterialDesignIconNames.MessageReplyTextOutline*/, null, null);
                }
                super.ModifyDescriptor(propertyBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(17180422601)
            
            //--TRIMMABLE-BOUNDARY-START(60130095561)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130095561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 1/*SchemaType.Form*/)
                {
                    return descriptors = $.$LCOv.LCFCPM$1.PostBaseModel.Include(descriptors, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "Post" ], null, null));
                }
                return super.UpdateDescriptors(descriptors, $.$clone(schema));
            }
            //--TRIMMABLE-BOUNDARY-END(60130095561)
            
            //--TRIMMABLE-BOUNDARY-START(8594254260)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThreadPost.ParentId.get
            get LCFCP$IPostThreadPost$ParentId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889221556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParentId;
            }
            //--TRIMMABLE-BOUNDARY-END(8594254260)
            
            //--TRIMMABLE-BOUNDARY-START(21479156148)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThreadPost.ParentId.set
            set LCFCP$IPostThreadPost$ParentId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889221556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ParentId = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21479156148)
            
            //--TRIMMABLE-BOUNDARY-START(8593271220)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesCount.get
            get LCFCP$IPostReplyable$RepliesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478173108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593271220)
            
            //--TRIMMABLE-BOUNDARY-START(17183205812)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesDepth.get
            get LCFCP$IPostReplyable$RepliesDepth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773140404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesDepth;
            }
            //--TRIMMABLE-BOUNDARY-END(17183205812)
            
            //--TRIMMABLE-BOUNDARY-START(8594385332)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostVotable.VotesCount.get
            get LCFCP$IPostVotable$VotesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479287220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.VotesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8594385332)
            
            //--TRIMMABLE-BOUNDARY-START(17184319924)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostVotable.VotesCount.set
            set LCFCP$IPostVotable$VotesCount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479287220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.VotesCount = value;
            }
            //--TRIMMABLE-BOUNDARY-END(17184319924)
            
            //--TRIMMABLE-BOUNDARY-START(8593992116)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSubscribable.SubscribersCount.get
            get LCFCP$IPostSubscribable$SubscribersCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888959412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SubscribersCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593992116)
            
            //--TRIMMABLE-BOUNDARY-START(4295520713)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295520713)
            
            static $h = 553417;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835128265),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885455305,
        "f": 50364417
      },
      "n": "Type",
      "d": 553417,
      "h": 55835128265,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55835128265)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950226377),
    {
      "r": 262145,
      "n": "ShouldEditName",
      "d": 553417,
      "h": 42950226377,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950226377),
//--TRIMMABLE-BOUNDARY-START(25770357193),
    {
      "r": 262145,
      "n": "RequiresName",
      "d": 553417,
      "h": 25770357193,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770357193),
//--TRIMMABLE-BOUNDARY-START(47245193673),
    {
      "r": 262145,
      "n": "ShouldEditSummary",
      "d": 553417,
      "h": 47245193673,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245193673),
//--TRIMMABLE-BOUNDARY-START(30065324489),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 553417,
      "h": 30065324489,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065324489),
//--TRIMMABLE-BOUNDARY-START(38655259081),
    {
      "r": 262145,
      "n": "ShouldEditIcon",
      "d": 553417,
      "h": 38655259081,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655259081),
//--TRIMMABLE-BOUNDARY-START(21475389897),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 553417,
      "h": 21475389897,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475389897),
//--TRIMMABLE-BOUNDARY-START(51540160969),
    {
      "r": 262145,
      "n": "ShouldEditTags",
      "d": 553417,
      "h": 51540160969,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540160969),
//--TRIMMABLE-BOUNDARY-START(34360291785),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": 553417,
      "h": 34360291785,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360291785),
//--TRIMMABLE-BOUNDARY-START(17180422601),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 553417,
      "h": 17180422601,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180422601),
//--TRIMMABLE-BOUNDARY-START(60130095561),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": 553417,
      "h": 60130095561,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130095561)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295520713),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 553417,
      "h": 4295520713,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295520713)
  ],
  "h": 553417
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostThreadPost, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostVotable, $.$LCOv.LCFCP.IPostSubscribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Models${separator}CommunityForumPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(553417)
        
        

        //--TRIMMABLE-BOUNDARY-START(1143241)
        $asm.$cls(`$lAxY.LCCFCS.ICommunityForumPostFeedRemoteService`, ($self) => class ICommunityForumPostFeedRemoteService
        {
            static $h = 1143241;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1143241,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Services.ICommunityForumPostFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Services${separator}ICommunityForumPostFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1143241)
        
        

        //--TRIMMABLE-BOUNDARY-START(1208777)
        $asm.$cls(`$lAxY.LCCFCS.ICommunityForumPostFeedRemoteService_Mocking`, ($self) => class ICommunityForumPostFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296176073)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296176073);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296176073)
            
            //--TRIMMABLE-BOUNDARY-START(8591143369)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumPostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591143369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$lAxY.LCCFCM.CommunityForumPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumPostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591143369)
            
            static $h = 1208777;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296176073),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1208777,
      "h": 4296176073,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296176073)
  ],
  "h": 1208777
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$lAxY.LCCFCS.ICommunityForumPostFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Services.ICommunityForumPostFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Services${separator}ICommunityForumPostFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1208777)
        
        

        //--TRIMMABLE-BOUNDARY-START(1667529)
        $asm.$cls(`$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumPostModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityForumPostModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296634825)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296634825);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296634825)
            
            //--TRIMMABLE-BOUNDARY-START(8591602121)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591602121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$lAxY.LCCFCM.CommunityForumPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591602121)
            
            //--TRIMMABLE-BOUNDARY-START(17181536713)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181536713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$lAxY.LCCFCM.CommunityForumPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181536713)
            
            //--TRIMMABLE-BOUNDARY-START(21476504009)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476504009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$lAxY.LCCFCM.CommunityForumPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$lAxY.LCCFCM.CommunityForumPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476504009)
            
            //--TRIMMABLE-BOUNDARY-START(25771471305)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771471305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$lAxY.LCCFCM.CommunityForumPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771471305)
            
            //--TRIMMABLE-BOUNDARY-START(12886569417)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886569417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$lAxY.LCCFCM.CommunityForumPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886569417)
            
            static $h = 1667529;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296634825),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1667529,
      "h": 4296634825,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296634825)
  ],
  "h": 1667529
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFCD.IReadDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityForumPostModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityForumPostModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1667529)
        
        

        //--TRIMMABLE-BOUNDARY-START(684489)
        $asm.$cls(`$lAxY.LCCFCM.CommunityForumPostModelTypeDescriptor`, ($self) => class CommunityForumPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lAxY.LCCFCM.CommunityForumPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295651785)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295651785);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$lAxY.LCCFCM.CommunityForumPostModelTypeDescriptor.GenerateProperties($.$lAxY.LCCFCM.CommunityForumPostModel, this, factory);
                    }, $wjzTid ??= {"r":65537,"n":"","d":684489,"h":0,"f":17825794}), 0, "CommunityForumPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Forum.Common\\Models_CommunityForumPostModel_LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModelTypeDescriptorBuilder.g.cs", "CommunityForumPostModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295651785)
            
            //--TRIMMABLE-BOUNDARY-START(12885586377)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885586377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$lAxY.LCCFCM.CommunityForumPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$lAxY.LCCFCM.CommunityForumPostModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$lAxY.LCCFCM.CommunityForumPostModel)).Type);
                        }, $LIOfEb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":684489,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885586377)
            
            //--TRIMMABLE-BOUNDARY-START(17180553673)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180553673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180553673)
            
            //--TRIMMABLE-BOUNDARY-START(8590619081)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590619081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$lAxY.LCCFCM.CommunityForumPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$lAxY.LCCFCM.CommunityForumPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$lAxY.LCCFCM.CommunityForumPostModel)))
                {
                    /*var*/ let result = $.$lAxY.LCCFCM.CommunityForumPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$lAxY.LCCFCM.CommunityForumPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$lAxY.LCCFCM.CommunityForumPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$lAxY.LCCFCM.CommunityForumPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590619081)
            
            static $h = 684489;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lAxY.LCCFCM.CommunityForumPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885586377),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 684489,
      "h": 12885586377,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885586377),
//--TRIMMABLE-BOUNDARY-START(17180553673),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 553417,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 684489,
      "h": 17180553673,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180553673),
//--TRIMMABLE-BOUNDARY-START(8590619081),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 553417,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 684489,
      "h": 8590619081,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590619081)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295651785),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 684489,
      "h": 4295651785,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295651785)
  ],
  "h": 684489
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$lAxY.LCCFCM.CommunityForumPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Models${separator}CommunityForumPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(684489)
        
        

        $asm.$typeProxy("$lAxY.LCCFCM.CommunityForumThreadModel", "$lAxY.LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel");
        //--TRIMMABLE-BOUNDARY-START(225737)
        $asm.$cls(`$lAxY.LCCFCM.CommunityForumCategoryModel`, ($self) => class CommunityForumCategoryModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$lAxY.LCCFCM.CommunityForumThreadModel)
        {
            //--TRIMMABLE-BOUNDARY-START(30064996809)
            /*PostTypes */ get Type()
            {
                return 1025/*PostTypes.ForumCategory*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30064996809)
            
            //--TRIMMABLE-BOUNDARY-START(25770029513)
            /*bool */ ShouldSerializeTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770029513);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770029513)
            
            //--TRIMMABLE-BOUNDARY-START(21475062217)
            /*bool */ ShouldSerializeIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475062217);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475062217)
            
            //--TRIMMABLE-BOUNDARY-START(17180094921)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180094921);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180094921)
            
            //--TRIMMABLE-BOUNDARY-START(8593992116)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSubscribable.SubscribersCount.get
            get LCFCP$IPostSubscribable$SubscribersCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888959412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SubscribersCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593992116)
            
            //--TRIMMABLE-BOUNDARY-START(8594188724)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThreadCategory.ThreadsCount.get
            get LCFCP$IPostThreadCategory$ThreadsCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889156020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ThreadsCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8594188724)
            
            //--TRIMMABLE-BOUNDARY-START(4295193033)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295193033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295193033)
            
            //--TRIMMABLE-BOUNDARY-START(4295193033)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295193033)
            
            static $h = 225737;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064996809),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885127625,
        "f": 50364417
      },
      "n": "Type",
      "d": 225737,
      "h": 30064996809,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30064996809)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770029513),
    {
      "r": 262145,
      "n": "ShouldSerializeTags",
      "d": 225737,
      "h": 25770029513,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770029513),
//--TRIMMABLE-BOUNDARY-START(21475062217),
    {
      "r": 262145,
      "n": "ShouldSerializeIcon",
      "d": 225737,
      "h": 21475062217,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475062217),
//--TRIMMABLE-BOUNDARY-START(17180094921),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": 225737,
      "h": 17180094921,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180094921)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295193033),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 225737,
      "h": 4295193033,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295193033)
  ],
  "h": 225737,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "/Icon=Forum"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostThreadCategory, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostNestedCategory, $.$LCOv.LCFCP.IPostByAdminOnly ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Models${separator}CommunityForumCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(225737)
        
        

        //--TRIMMABLE-BOUNDARY-START(815561)
        $asm.$cls(`$lAxY.LCCFCM.CommunityForumThreadModel`, ($self) => class CommunityForumThreadModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(90195128777)
            /*PostTypes */ get Type()
            {
                return 1026/*PostTypes.ForumDiscussion*/;
            }
            //--TRIMMABLE-BOUNDARY-END(90195128777)
            
            //--TRIMMABLE-BOUNDARY-START(81605194185)
            /*bool */ ShouldEditName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605194185);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605194185)
            
            //--TRIMMABLE-BOUNDARY-START(73015259593)
            /*bool */ RequiresName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015259593);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015259593)
            
            //--TRIMMABLE-BOUNDARY-START(85900161481)
            /*bool */ ShouldEditSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900161481);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900161481)
            
            //--TRIMMABLE-BOUNDARY-START(77310226889)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310226889);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310226889)
            
            //--TRIMMABLE-BOUNDARY-START(38655521225)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$2(this, null, "Forum/Post", null, true);
            }
            //--TRIMMABLE-BOUNDARY-END(38655521225)
            
            //--TRIMMABLE-BOUNDARY-START(64425325001)
            /*IPost? */ get LCFCP$IPostThread$LastPost()
            {
                return this.LastPost;
            }
            //--TRIMMABLE-BOUNDARY-END(64425325001)
            
            //--TRIMMABLE-BOUNDARY-START(42950488521)
            /*IPost? */ get LCFCP$IPostCategorizable$Category()
            {
                return this.Category;
            }
            //--TRIMMABLE-BOUNDARY-END(42950488521)
            
            //--TRIMMABLE-BOUNDARY-START(34360553929)
            /*bool */ get IsThread()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(34360553929)
            
            //--TRIMMABLE-BOUNDARY-START(68720292297)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720292297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Name", "Title", null, null, null, null);
                $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Post", "Question", "Enter your questions here", "mdi mdi-message-reply-text-outline"/*MaterialDesignIconNames.MessageReplyTextOutline*/, null, null);
                super.ModifyDescriptor(propertyBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(68720292297)
            
            //--TRIMMABLE-BOUNDARY-START(8594123188)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThread.IsThread.get
            get LCFCP$IPostThread$IsThread()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479025076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsThread;
            }
            //--TRIMMABLE-BOUNDARY-END(8594123188)
            
            //--TRIMMABLE-BOUNDARY-START(8594254260)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThreadPost.ParentId.get
            get LCFCP$IPostThreadPost$ParentId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889221556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParentId;
            }
            //--TRIMMABLE-BOUNDARY-END(8594254260)
            
            //--TRIMMABLE-BOUNDARY-START(21479156148)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThreadPost.ParentId.set
            set LCFCP$IPostThreadPost$ParentId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889221556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ParentId = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21479156148)
            
            //--TRIMMABLE-BOUNDARY-START(8594385332)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostVotable.VotesCount.get
            get LCFCP$IPostVotable$VotesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479287220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.VotesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8594385332)
            
            //--TRIMMABLE-BOUNDARY-START(17184319924)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostVotable.VotesCount.set
            set LCFCP$IPostVotable$VotesCount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479287220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.VotesCount = value;
            }
            //--TRIMMABLE-BOUNDARY-END(17184319924)
            
            //--TRIMMABLE-BOUNDARY-START(8594319796)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostViewTrackable.ViewsCount.get
            get LCFCP$IPostViewTrackable$ViewsCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889287092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ViewsCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8594319796)
            
            //--TRIMMABLE-BOUNDARY-START(8593992116)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSubscribable.SubscribersCount.get
            get LCFCP$IPostSubscribable$SubscribersCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888959412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SubscribersCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593992116)
            
            //--TRIMMABLE-BOUNDARY-START(8593271220)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesCount.get
            get LCFCP$IPostReplyable$RepliesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478173108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593271220)
            
            //--TRIMMABLE-BOUNDARY-START(17183205812)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesDepth.get
            get LCFCP$IPostReplyable$RepliesDepth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773140404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesDepth;
            }
            //--TRIMMABLE-BOUNDARY-END(17183205812)
            
            //--TRIMMABLE-BOUNDARY-START(4295782857)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295782857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295782857)
            
            //--TRIMMABLE-BOUNDARY-START(4295782857)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295782857)
            
            static $h = 815561;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90195128777),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065586633,
        "f": 50364417
      },
      "n": "Type",
      "d": 815561,
      "h": 90195128777,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90195128777),
//--TRIMMABLE-BOUNDARY-START(38655521225),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475652041,
        "f": 50364417
      },
      "n": "Link",
      "d": 815561,
      "h": 38655521225,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655521225),
//--TRIMMABLE-BOUNDARY-START(64425325001),
    {
      "p": 1173940,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130357705,
        "f": 50331650
      },
      "n": "{4188596}.LastPost",
      "o": "LCFCP$IPostThread$LastPost",
      "d": 815561,
      "h": 64425325001,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64425325001),
//--TRIMMABLE-BOUNDARY-START(42950488521),
    {
      "p": 1173940,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540423113,
        "f": 50331650
      },
      "n": "{1632692}.Category",
      "o": "LCFCP$IPostCategorizable$Category",
      "d": 815561,
      "h": 42950488521,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(42950488521),
//--TRIMMABLE-BOUNDARY-START(34360553929),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885717449,
        "f": 50331649
      },
      "n": "IsThread",
      "d": 815561,
      "h": 34360553929,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360553929)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605194185),
    {
      "r": 262145,
      "n": "ShouldEditName",
      "d": 815561,
      "h": 81605194185,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605194185),
//--TRIMMABLE-BOUNDARY-START(73015259593),
    {
      "r": 262145,
      "n": "RequiresName",
      "d": 815561,
      "h": 73015259593,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015259593),
//--TRIMMABLE-BOUNDARY-START(85900161481),
    {
      "r": 262145,
      "n": "ShouldEditSummary",
      "d": 815561,
      "h": 85900161481,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900161481),
//--TRIMMABLE-BOUNDARY-START(77310226889),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 815561,
      "h": 77310226889,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310226889),
//--TRIMMABLE-BOUNDARY-START(68720292297),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 815561,
      "h": 68720292297,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720292297)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295782857),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 815561,
      "h": 4295782857,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295782857)
  ],
  "h": 815561
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostThread, $.$LCOv.LCFCP.IPostThreadPost, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostVotable, $.$LCOv.LCFCP.IPostCategorizable, $.$LCOv.LCFCP.IPostViewTrackable, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostReplyable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Models${separator}CommunityForumThreadModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(815561)
        
        

        //--TRIMMABLE-BOUNDARY-START(1405385)
        $asm.$cls(`$lAxY.LCCFCS.ICommunityForumThreadFeedRemoteService`, ($self) => class ICommunityForumThreadFeedRemoteService
        {
            static $h = 1405385;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1405385,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Services.ICommunityForumThreadFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Services${separator}ICommunityForumThreadFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1405385)
        
        

        //--TRIMMABLE-BOUNDARY-START(487881)
        $asm.$cls(`$lAxY.LCCFCM.CommunityForumCategoryReader`, ($self) => class CommunityForumCategoryReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885389769)
            /*ICommunityApplicationService<CommunityForumCategoryModel, CommunityForumThreadModel>*/ service = null;
            //--TRIMMABLE-BOUNDARY-END(12885389769)
            
            //--TRIMMABLE-BOUNDARY-START(4295455177)
            $ctor$1(/*ICommunityApplicationService<CommunityForumCategoryModel, CommunityForumThreadModel>*/ service)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295455177);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295455177)
            
            //--TRIMMABLE-BOUNDARY-START(8590422473)
            /*Pager<ISelectOption<CommunityForumCategoryModel?>>? */ GetOptions(/*object?*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590422473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$lAxY.LCCFCM.CommunityForumCategoryModel)))().$ctor(this, /*async*/  (/*filter*/ filter) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$($.$fPer.LCFC.ISelectOption$$($.$lAxY.LCCFCM.CommunityForumCategoryModel))), $.$fPer.LCFCD.PagingDataResult$$($.$fPer.LCFC.ISelectOption$$($.$lAxY.LCCFCM.CommunityForumCategoryModel)), async ($asnycContext) => 
                    {
                        let $t1, $r1;
                        ($t1 = this.service.LCCCS$ICommunityApplicationService$$$$$BackgroundLoading(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel>?*/ let __ca1__;
                        /*var*/ let ops = ((__ca1__ = this.service.LCCCS$ICommunityApplicationService$$$$$Categories) !== null ? $.$sl.SL.Enumerable.Select$1($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$fPer.LCFC.ISelectOption$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), __ca1__, new ($.$$.S.Func$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$fPer.LCFC.ISelectOption$$($.$lAxY.LCCFCM.CommunityForumCategoryModel)))().$ctor(this,  (/*c*/ c) =>
                        {
                            return (() =>
                            {
                                //new $.$fPer.LCFC.SelectOption$$($.$lAxY.LCCFCM.CommunityForumCategoryModel)()
                                const $t2 = $.$fPer.LCFC.SelectOption$$($.$lAxY.LCCFCM.CommunityForumCategoryModel);
                                const $i2 = new $t2();
                                $i2.$ctor$3(c);
                                $i2.Title = `${$.$strNN(c.Title)}`;
                                return $i2;
                            })();
                        }, $UTFBad ??= {"r":$.$fPer.LCFC.ISelectOption$$($.$lAxY.LCCFCM.CommunityForumCategoryModel).$h,"p":[{"n":"c","p":225737}],"n":"","d":487881,"h":0,"f":17825794})) : null);
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$fPer.LCFCD.Paging.AsPagingDataResult$1($.$fPer.LCFC.ISelectOption$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), ops));
                    });
                }, $BCsxoh ??= {"r":$.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$($.$fPer.LCFC.ISelectOption$$($.$lAxY.LCCFCM.CommunityForumCategoryModel))).$h,"p":[{"n":"filter","p":9734486}],"n":"","d":487881,"h":0,"f":17829890});
            }
            //--TRIMMABLE-BOUNDARY-END(8590422473)
            
            //--TRIMMABLE-BOUNDARY-START(4297034070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaOptionReader<LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel>.GetOptions(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaOptionReader$LivingThing$Core$Community$Forum$Common$Models$CommunityForumCategoryModel$GetOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297034070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOptions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297034070)
            
            static $h = 487881;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590422473),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$lAxY.LCCFCM.CommunityForumCategoryModel)).$h,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "GetOptions",
      "d": 487881,
      "h": 8590422473,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590422473)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885389769),
    {
      "t": $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel).$h,
      "n": "service",
      "d": 487881,
      "h": 12885389769,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885389769)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295455177),
    {
      "p": [
        {
          "n": "service",
          "p": $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 487881,
      "h": 4295455177,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295455177)
  ],
  "h": 487881
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$lAxY.LCCFCM.CommunityForumCategoryModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Models${separator}CommunityForumCategoryReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(487881)
        
        

        //--TRIMMABLE-BOUNDARY-START(1470921)
        $asm.$cls(`$lAxY.LCCFCS.ICommunityForumThreadFeedRemoteService_Mocking`, ($self) => class ICommunityForumThreadFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296438217)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296438217);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296438217)
            
            //--TRIMMABLE-BOUNDARY-START(8591405513)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumThreadModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591405513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$lAxY.LCCFCM.CommunityForumThreadModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumThreadModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591405513)
            
            static $h = 1470921;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296438217),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1470921,
      "h": 4296438217,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296438217)
  ],
  "h": 1470921
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$lAxY.LCCFCS.ICommunityForumThreadFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Services.ICommunityForumThreadFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Services${separator}ICommunityForumThreadFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1470921)
        
        

        //--TRIMMABLE-BOUNDARY-START(1733065)
        $asm.$cls(`$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityForumThreadModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296700361)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296700361);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296700361)
            
            //--TRIMMABLE-BOUNDARY-START(8591667657)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumThreadModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591667657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumThreadModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$lAxY.LCCFCM.CommunityForumThreadModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591667657)
            
            //--TRIMMABLE-BOUNDARY-START(17181602249)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumThreadModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181602249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumThreadModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$lAxY.LCCFCM.CommunityForumThreadModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181602249)
            
            //--TRIMMABLE-BOUNDARY-START(21476569545)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumThreadModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476569545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$lAxY.LCCFCM.CommunityForumThreadModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFCD.WireTransportModel$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$lAxY.LCCFCM.CommunityForumThreadModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476569545)
            
            //--TRIMMABLE-BOUNDARY-START(25771536841)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumThreadModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771536841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumThreadModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$lAxY.LCCFCM.CommunityForumThreadModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771536841)
            
            //--TRIMMABLE-BOUNDARY-START(12886634953)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886634953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$lAxY.LCCFCM.CommunityForumThreadModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886634953)
            
            static $h = 1733065;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296700361),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1733065,
      "h": 4296700361,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296700361)
  ],
  "h": 1733065
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFCD.ICreateDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFCD.IReadDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFCD.IReadManyDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFCD.IUpdateDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFCD.IDeleteDataService$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityForumThreadModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityForumThreadModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1733065)
        
        

        //--TRIMMABLE-BOUNDARY-START(1601993)
        $asm.$cls(`$lAxY.LCFCR.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296569289)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296569289);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296569289)
            
            //--TRIMMABLE-BOUNDARY-START(8591536585)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumCategoryModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591536585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumCategoryModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$lAxY.LCCFCM.CommunityForumCategoryModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591536585)
            
            //--TRIMMABLE-BOUNDARY-START(17181471177)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumCategoryModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181471177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumCategoryModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$lAxY.LCCFCM.CommunityForumCategoryModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181471177)
            
            //--TRIMMABLE-BOUNDARY-START(21476438473)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumCategoryModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476438473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$lAxY.LCCFCM.CommunityForumCategoryModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$fPer.LCFCD.WireTransportModel$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$lAxY.LCCFCM.CommunityForumCategoryModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476438473)
            
            //--TRIMMABLE-BOUNDARY-START(25771405769)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Forum$Common$Models$CommunityForumCategoryModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771405769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumCategoryModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$lAxY.LCCFCM.CommunityForumCategoryModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771405769)
            
            //--TRIMMABLE-BOUNDARY-START(12886503881)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886503881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$lAxY.LCCFCM.CommunityForumCategoryModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886503881)
            
            static $h = 1601993;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296569289),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1601993,
      "h": 4296569289,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296569289)
  ],
  "h": 1601993
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$fPer.LCFCD.ICreateDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$fPer.LCFCD.IReadDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$fPer.LCFCD.IReadManyDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$fPer.LCFCD.IUpdateDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$fPer.LCFCD.IDeleteDataService$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityForumCategoryModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1601993)
        
        

        //--TRIMMABLE-BOUNDARY-START(356809)
        $asm.$cls(`$lAxY.LCCFCM.CommunityForumCategoryModelTypeDescriptor`, ($self) => class CommunityForumCategoryModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lAxY.LCCFCM.CommunityForumCategoryModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295324105)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295324105);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$lAxY.LCCFCM.CommunityForumCategoryModelTypeDescriptor.GenerateProperties($.$lAxY.LCCFCM.CommunityForumCategoryModel, this, factory);
                    }, $OCLVEd ??= {"r":65537,"n":"","d":356809,"h":0,"f":17825794}), 0, "CommunityForumCategoryModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Forum.Common\\Models_CommunityForumCategoryModel_LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModelTypeDescriptorBuilder.g.cs", "CommunityForumCategoryModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295324105)
            
            //--TRIMMABLE-BOUNDARY-START(12885258697)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885258697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$lAxY.LCCFCM.CommunityForumCategoryModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$lAxY.LCCFCM.CommunityForumCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$lAxY.LCCFCM.CommunityForumCategoryModel)).Type);
                        }, $dBMcNi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":356809,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885258697)
            
            //--TRIMMABLE-BOUNDARY-START(17180225993)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180225993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel, LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumThreadModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180225993)
            
            //--TRIMMABLE-BOUNDARY-START(8590291401)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590291401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$lAxY.LCCFCM.CommunityForumCategoryModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$lAxY.LCCFCM.CommunityForumCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$lAxY.LCCFCM.CommunityForumCategoryModel)))
                {
                    /*var*/ let result = $.$lAxY.LCCFCM.CommunityForumCategoryModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$lAxY.LCCFCM.CommunityForumCategoryModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$lAxY.LCCFCM.CommunityForumCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$lAxY.LCCFCM.CommunityForumCategoryModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590291401)
            
            static $h = 356809;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lAxY.LCCFCM.CommunityForumCategoryModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885258697),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 356809,
      "h": 12885258697,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885258697),
//--TRIMMABLE-BOUNDARY-START(17180225993),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 225737,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 356809,
      "h": 17180225993,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180225993),
//--TRIMMABLE-BOUNDARY-START(8590291401),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 225737,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 356809,
      "h": 8590291401,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590291401)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295324105),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 356809,
      "h": 4295324105,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295324105)
  ],
  "h": 356809
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$lAxY.LCCFCM.CommunityForumCategoryModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Models${separator}CommunityForumCategoryModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(356809)
        
        

        //--TRIMMABLE-BOUNDARY-START(946633)
        $asm.$cls(`$lAxY.LCCFCM.CommunityForumThreadModelTypeDescriptor`, ($self) => class CommunityForumThreadModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lAxY.LCCFCM.CommunityForumThreadModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295913929)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295913929);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$lAxY.LCCFCM.CommunityForumThreadModelTypeDescriptor.GenerateProperties($.$lAxY.LCCFCM.CommunityForumThreadModel, this, factory);
                    }, $HEDbUk ??= {"r":65537,"n":"","d":946633,"h":0,"f":17825794}), 0, "CommunityForumThreadModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Forum.Common\\Models_CommunityForumThreadModel_LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModelTypeDescriptorBuilder.g.cs", "CommunityForumThreadModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295913929)
            
            //--TRIMMABLE-BOUNDARY-START(12885848521)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885848521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$lAxY.LCCFCM.CommunityForumThreadModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$lAxY.LCCFCM.CommunityForumThreadModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$lAxY.LCCFCM.CommunityForumThreadModel)).Type);
                        }, $tQvsSf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":946633,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$lAxY.LCCFCM.CommunityForumThreadModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Link";
                        $i3.DelaredOn = "LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$lAxY.LCCFCM.CommunityForumThreadModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$lAxY.LCCFCM.CommunityForumThreadModel)).Link);
                        }, $QQmQKe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":946633,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsThread"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$lAxY.LCCFCM.CommunityForumThreadModel.$type, $.$discardRef(), "IsThread", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsThread")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "IsThread";
                        $i5.DelaredOn = "LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$lAxY.LCCFCM.CommunityForumThreadModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$lAxY.LCCFCM.CommunityForumThreadModel)).IsThread);
                        }, $gUtAjg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":946633,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885848521)
            
            //--TRIMMABLE-BOUNDARY-START(17180815817)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180815817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.Forum.Common.Models.CommunityForumCategoryModel, LivingThing.Core.Community.Forum.Common.Models.CommunityForumPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$lAxY.LCCFCM.CommunityForumCategoryModel, $.$lAxY.LCCFCM.CommunityForumPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _IsThread = _target.IsThread;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsThread"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsThread, ($v) => _IsThread = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180815817)
            
            //--TRIMMABLE-BOUNDARY-START(8590881225)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590881225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$lAxY.LCCFCM.CommunityForumThreadModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$lAxY.LCCFCM.CommunityForumThreadModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$lAxY.LCCFCM.CommunityForumThreadModel)))
                {
                    /*var*/ let result = $.$lAxY.LCCFCM.CommunityForumThreadModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$lAxY.LCCFCM.CommunityForumThreadModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$lAxY.LCCFCM.CommunityForumThreadModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$lAxY.LCCFCM.CommunityForumThreadModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590881225)
            
            static $h = 946633;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lAxY.LCCFCM.CommunityForumThreadModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885848521),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 946633,
      "h": 12885848521,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885848521),
//--TRIMMABLE-BOUNDARY-START(17180815817),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 815561,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 946633,
      "h": 17180815817,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180815817),
//--TRIMMABLE-BOUNDARY-START(8590881225),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 815561,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 946633,
      "h": 8590881225,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590881225)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295913929),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 946633,
      "h": 4295913929,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295913929)
  ],
  "h": 946633
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$lAxY.LCCFCM.CommunityForumThreadModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Forum.Common.Models.CommunityForumThreadModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Forum${separator}Common${separator}Models${separator}CommunityForumThreadModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(946633)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(29129)
