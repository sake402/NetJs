
//--TRIMMABLE-BOUNDARY-START(47849)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $WcGF) {
    "use strict";
    let _;
    let $RRSTLf;
    let $Joizkd;
    let $ZUZSDi;
    let $kZpfPa;
    let $magPJk;
    let $AuRvgh;
    let $DeAhxe;
    let $VctGwk;
    let $vkKZfd;
    let $fYRzBb;
    let $LfZAsk;
    let $tQMmwa;
    let $qpzclh;
    let $okhMqk;
    let $uxTihc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.FundMe.Client.Blazor", 
    {
  "h": 47849,
  "f": "LivingThing.Core.Community.FundMe.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.FundMe.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.FundMe.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(178921)
        $asm.$cls(`$QcZy.LCCFC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295146217)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295146217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$QcZy.LCCFC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295146217)
            
            static $h = 178921;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295146217),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 178921,
      "h": 4295146217,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295146217)
  ],
  "h": 178921
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(178921)
        
        

        //--TRIMMABLE-BOUNDARY-START(244457)
        $asm.$cls(`$QcZy.LCCFC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180113641)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QcZy.LCCFCP.CommunityFundMeApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QcZy.LCCFCP.CommunityFundMeApp().$ctor$3();
                    }, $RRSTLf ??= {"r":2752627,"n":"","d":244457,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180113641)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295211753)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295211753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295211753)
            
            //--TRIMMABLE-BOUNDARY-START(4295211753)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295211753)
            
            static $h = 244457;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180113641),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885146345,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 244457,
      "h": 17180113641,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180113641)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295211753),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 244457,
      "h": 4295211753,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295211753)
  ],
  "h": 244457
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(244457)
        
        

        //--TRIMMABLE-BOUNDARY-START(375529)
        $asm.$cls(`$QcZy.LCCFC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590310121)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590310121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$QcZy.LCCFCS.CommunityFundMeService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$WcGF.LCCFCM.CommunityFundMePostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$QcZy.LCCFCS.CommunityFundMeApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QcZy.LCCFCS.CommunityFundMeApplication, x);
                }, $Joizkd ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":375529,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QcZy.LCCFCS.CommunityFundMeApplication, x);
                }, $ZUZSDi ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":375529,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$WcGF.LCCFCM.CommunityFundMePostModel, services, null);
                $.$QcZy.LCCFC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590310121)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$QcZy.LCCFC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295342825)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295342825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295342825)
            
            //--TRIMMABLE-BOUNDARY-START(4295342825)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295342825)
            
            static $h = 375529;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590310121),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 375529,
      "h": 8590310121,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590310121)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295342825),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 375529,
      "h": 4295342825,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295342825)
  ],
  "h": 375529
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(375529)
        
        

        //--TRIMMABLE-BOUNDARY-START(572137)
        $asm.$cls(`$QcZy.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295539433)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295539433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295539433)
            
            //--TRIMMABLE-BOUNDARY-START(4295539433)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295539433)
            
            static $h = 572137;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295539433),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 572137,
      "h": 4295539433,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295539433)
  ],
  "h": 572137
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(572137)
        
        

        //--TRIMMABLE-BOUNDARY-START(637673)
        $asm.$cls(`$QcZy.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295604969)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295604969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295604969)
            
            //--TRIMMABLE-BOUNDARY-START(4295604969)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295604969)
            
            static $h = 637673;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295604969),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 637673,
      "h": 4295604969,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295604969)
  ],
  "h": 637673,
  "a": [
    {
      "t": 572137,
      "c": 4295539433
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(637673)
        
        

        //--TRIMMABLE-BOUNDARY-START(113385)
        $asm.$cls(`$QcZy.LCCFC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590047977)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590047977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590047977)
            
            //--TRIMMABLE-BOUNDARY-START(4295080681)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295080681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295080681)
            
            //--TRIMMABLE-BOUNDARY-START(4295080681)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295080681)
            
            static $h = 113385;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590047977),
    {
      "r": 65537,
      "n": "Execute",
      "d": 113385,
      "h": 8590047977,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590047977)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295080681),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 113385,
      "h": 4295080681,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295080681)
  ],
  "h": 113385
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(113385)
        
        

        //--TRIMMABLE-BOUNDARY-START(309993)
        $asm.$cls(`$QcZy.LCCFCP.CommunityFundMeApp`, ($self) => class CommunityFundMeApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(60129852137)
            /*CommunityFundMeService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(60129852137)
            
            //--TRIMMABLE-BOUNDARY-START(21475146473)
            /*CommunityFundMeApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(21475146473)
            
            //--TRIMMABLE-BOUNDARY-START(55834884841)
            /*IUIRenderingProvider*/ Rendering = null;
            //--TRIMMABLE-BOUNDARY-END(55834884841)
            
            //--TRIMMABLE-BOUNDARY-START(25770113769)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770113769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "InitialViewIndex", "0");
                __builder.AddComponentParameter(2, "Name", "FundMe");
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(5, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 6);
                        __builder2.AddComponentParameter(7, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                        __builder2.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(9, wrap.View);
                        }), $kZpfPa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":309993,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $magPJk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":309993,"h":0,"f":17825794});
                }), $AuRvgh ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":309993,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/*splash*/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 11);
                        __builder2.AddComponentParameter(12, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, splash.ViewModel));
                        __builder2.AddComponentParameter(13, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, splash.Message));
                        __builder2.CloseComponent();
                    }, $DeAhxe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":309993,"h":0,"f":17825794});
                }), $VctGwk ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":309993,"h":0,"f":17825794}));
                __builder.AddAttribute$3(14, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 15);
                    __builder2.AddComponentParameter(16, "Name", "");
                    __builder2.AddComponentParameter(17, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddAttribute$3(18, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(19, "FundMe");
                        }, $vkKZfd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":309993,"h":0,"f":17825794});
                    }), $fYRzBb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":309993,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(20, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(21, "<i class=\"mdi mdi-book\"></i>");
                        }, $LfZAsk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":309993,"h":0,"f":17825794});
                    }), $tQMmwa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":309993,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(22, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityApplicationUnderDevelopment, 23);
                            __builder3.AddComponentParameter(24, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCS.ICommunityClientApplication, this.Application));
                            __builder3.CloseComponent();
                        }, $qpzclh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":309993,"h":0,"f":17825794});
                    }), $okhMqk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":309993,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $uxTihc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":309993,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25770113769)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180179177)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180179177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180179177)
            
            //--TRIMMABLE-BOUNDARY-START(17180179177)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17180179177)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60129852137)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(60129852137)
                
                //--TRIMMABLE-BOUNDARY-START(21475146473)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(21475146473)
                
                //--TRIMMABLE-BOUNDARY-START(55834884841)
                this.Rendering = null;
                //--TRIMMABLE-BOUNDARY-END(55834884841)
                
            }
            static $h = 309993;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129852137),
    {
      "p": 506601,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539917545,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899655913,
        "f": 83886081
      },
      "n": "Service",
      "d": 309993,
      "h": 60129852137,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60129852137),
//--TRIMMABLE-BOUNDARY-START(21475146473),
    {
      "p": 441065,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360048361,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719786729,
        "f": 83886081
      },
      "n": "Application",
      "d": 309993,
      "h": 21475146473,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475146473),
//--TRIMMABLE-BOUNDARY-START(55834884841),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949982953,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309721321,
        "f": 83886081
      },
      "n": "Rendering",
      "d": 309993,
      "h": 55834884841,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834884841)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770113769),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 309993,
      "h": 25770113769,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770113769)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180179177),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 309993,
      "h": 17180179177,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180179177)
  ],
  "h": 309993
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Client.Pages.CommunityFundMeApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Client${separator}Pages${separator}CommunityFundMeApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(309993)
        
        

        //--TRIMMABLE-BOUNDARY-START(441065)
        $asm.$cls(`$QcZy.LCCFCS.CommunityFundMeApplication`, ($self) => class CommunityFundMeApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885342953)
            $ctor$5(/*CommunityFundMeService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885342953);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885342953)
            
            //--TRIMMABLE-BOUNDARY-START(137439394537)
            /*string */ get Name()
            {
                return "FundMe";
            }
            //--TRIMMABLE-BOUNDARY-END(137439394537)
            
            //--TRIMMABLE-BOUNDARY-START(158914231017)
            /*string */ get Title()
            {
                return "FundMe";
            }
            //--TRIMMABLE-BOUNDARY-END(158914231017)
            
            //--TRIMMABLE-BOUNDARY-START(21475277545)
            /*string */ get Description()
            {
                return "Raise fund from the community for a cause or purpose.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475277545)
            
            //--TRIMMABLE-BOUNDARY-START(133144427241)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-handshake"/*MaterialDesignIconNames.Handshake*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144427241)
            
            //--TRIMMABLE-BOUNDARY-START(154619263721)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2E069B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619263721)
            
            //--TRIMMABLE-BOUNDARY-START(30065212137)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065212137)
            
            //--TRIMMABLE-BOUNDARY-START(17180310249)
            /*Type? */ get ApplicationViewType()
            {
                return $.$QcZy.LCCFCP.CommunityFundMeApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180310249)
            
            //--TRIMMABLE-BOUNDARY-START(128849459945)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849459945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$QcZy.LCCFCP.CommunityFundMeApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849459945)
            
            //--TRIMMABLE-BOUNDARY-START(25770244841)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770244841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770244841)
            
            //--TRIMMABLE-BOUNDARY-START(146029329129)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029329129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029329129)
            
            //--TRIMMABLE-BOUNDARY-START(141734361833)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734361833)
            
            //--TRIMMABLE-BOUNDARY-START(4295408361)
            /*CommunityFundMeService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295408361)
            
            //--TRIMMABLE-BOUNDARY-START(150324296425)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(150324296425)
            
            //--TRIMMABLE-BOUNDARY-START(163209198313)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(4096/*PostTypes.FundMe*/, 4097/*PostTypes.FundMeEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209198313)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 441065;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439394537),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604819689,
        "f": 50364417
      },
      "n": "Name",
      "d": 441065,
      "h": 137439394537,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439394537),
//--TRIMMABLE-BOUNDARY-START(158914231017),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964558057,
        "f": 50364417
      },
      "n": "Title",
      "d": 441065,
      "h": 158914231017,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914231017),
//--TRIMMABLE-BOUNDARY-START(21475277545),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835015913,
        "f": 50364417
      },
      "n": "Description",
      "d": 441065,
      "h": 21475277545,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475277545),
//--TRIMMABLE-BOUNDARY-START(133144427241),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014885097,
        "f": 50364417
      },
      "n": "Icon",
      "d": 441065,
      "h": 133144427241,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144427241),
//--TRIMMABLE-BOUNDARY-START(154619263721),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374623465,
        "f": 50364417
      },
      "n": "Theme",
      "d": 441065,
      "h": 154619263721,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619263721),
//--TRIMMABLE-BOUNDARY-START(30065212137),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424950505,
        "f": 50364417
      },
      "n": "Features",
      "d": 441065,
      "h": 30065212137,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065212137),
//--TRIMMABLE-BOUNDARY-START(17180310249),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245081321,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 441065,
      "h": 17180310249,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180310249),
//--TRIMMABLE-BOUNDARY-START(141734361833),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194754281,
        "f": 50364417
      },
      "n": "Order",
      "d": 441065,
      "h": 141734361833,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734361833),
//--TRIMMABLE-BOUNDARY-START(4295408361),
    {
      "p": 506601,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655146729,
        "f": 50331650
      },
      "n": "_Service",
      "d": 441065,
      "h": 4295408361,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295408361),
//--TRIMMABLE-BOUNDARY-START(150324296425),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784688873,
        "f": 50364417
      },
      "n": "Service",
      "d": 441065,
      "h": 150324296425,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324296425),
//--TRIMMABLE-BOUNDARY-START(163209198313),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554492649,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 441065,
      "h": 163209198313,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209198313)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849459945),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 441065,
      "h": 128849459945,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849459945),
//--TRIMMABLE-BOUNDARY-START(25770244841),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 441065,
      "h": 25770244841,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770244841),
//--TRIMMABLE-BOUNDARY-START(146029329129),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 441065,
      "h": 146029329129,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029329129)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885342953),
    {
      "p": [
        {
          "n": "service",
          "p": 506601
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 441065,
      "h": 12885342953,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885342953)
  ],
  "h": 441065
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$WcGF.LCCFCM.CommunityFundMePostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Client.Services.CommunityFundMeApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Client${separator}Services${separator}CommunityFundMeApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(441065)
        
        

        //--TRIMMABLE-BOUNDARY-START(506601)
        $asm.$cls(`$QcZy.LCCFCS.CommunityFundMeService`, ($self) => class CommunityFundMeService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$WcGF.LCCFCM.CommunityFundMePostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295473897)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295473897);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295473897)
            
            static $h = 506601;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$WcGF.LCCFCM.CommunityFundMePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295473897),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 506601,
      "h": 4295473897,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295473897)
  ],
  "h": 506601
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$WcGF.LCCFCM.CommunityFundMePostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$WcGF.LCCFCM.CommunityFundMePostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Client.Services.CommunityFundMeService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Client${separator}Services${separator}CommunityFundMeService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(506601)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.FundMe.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(47849)
