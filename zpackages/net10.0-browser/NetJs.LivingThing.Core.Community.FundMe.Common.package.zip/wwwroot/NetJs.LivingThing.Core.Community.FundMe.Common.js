
//--TRIMMABLE-BOUNDARY-START(45868)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $oLgVcc;
    let $Qnsnse;
    let $gqTsib;
    let $SoLzNi;
    let $yWQNfk;
    let $jIHWYg;
    let $ylGefc;
    let $GNkAGd;
    let $pdTLUh;
    let $LAQOsg;
    let $PrFldd;
    let $lbGTrh;
    let $sLivDb;
    let $eIznWd;
    let $VQDEQg;
    let $uvbsCe;
    let $vcZTeg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.FundMe.Common", 
    {
  "h": 45868,
  "f": "LivingThing.Core.Community.FundMe.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.FundMe.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.FundMe.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1291052)
        $asm.$cls(`$WcGF.LCCFCS$2.CommunityFundMeStatesCustomAttributesProvider`, ($self) => class CommunityFundMeStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296258348)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296258348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296258348)
            
            static $h = 1291052;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296258348),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1291052,
      "h": 4296258348,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296258348)
  ],
  "h": 1291052
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.States.CommunityFundMeStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}States${separator}CommunityFundMeStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1291052)
        
        

        //--TRIMMABLE-BOUNDARY-START(308012)
        $asm.$cls(`$WcGF.LCCFCM.CommunityFundMeModelCustomAttributesProvider`, ($self) => class CommunityFundMeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295275308)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295275308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$WcGF.LCCFCS$1.CommunityFundMeSettings, $.$WcGF.LCCFCS$2.CommunityFundMeStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295275308)
            
            static $h = 308012;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295275308),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 308012,
      "h": 4295275308,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295275308)
  ],
  "h": 308012
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Models${separator}CommunityFundMeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(308012)
        
        

        //--TRIMMABLE-BOUNDARY-START(1028908)
        $asm.$cls(`$WcGF.LCCFCS$1.CommunityFundMeSettingsCustomAttributesProvider`, ($self) => class CommunityFundMeSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295996204)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295996204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295996204)
            
            static $h = 1028908;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295996204),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1028908,
      "h": 4295996204,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295996204)
  ],
  "h": 1028908
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Settings.CommunityFundMeSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Settings${separator}CommunityFundMeSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1028908)
        
        

        //--TRIMMABLE-BOUNDARY-START(1487660)
        $asm.$cls(`$WcGF.LCCFC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296454956)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296454956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$WcGF.LCCFCM.CommunityFundMeModelTypeDescriptorBuilder.Register();
                $.$WcGF.LCCFCM.CommunityFundMePostModelTypeDescriptorBuilder.Register();
                $.$WcGF.LCCFCS$1.CommunityFundMeSettingsTypeDescriptorBuilder.Register();
                $.$WcGF.LCCFCS$2.CommunityFundMeStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296454956)
            
            static $h = 1487660;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296454956),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1487660,
      "h": 4296454956,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296454956)
  ],
  "h": 1487660
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1487660)
        
        

        //--TRIMMABLE-BOUNDARY-START(111404)
        $asm.$cls(`$WcGF.LCCFC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295078700)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295078700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WcGF.LCCFCM.CommunityFundMeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WcGF.LCCFCM.CommunityFundMeModelCustomAttributesProvider, $.$WcGF.LCCFCM.CommunityFundMeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WcGF.LCCFCM.CommunityFundMePostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WcGF.LCCFCM.CommunityFundMePostModelCustomAttributesProvider, $.$WcGF.LCCFCM.CommunityFundMePostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WcGF.LCCFCS$1.CommunityFundMeSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WcGF.LCCFCS$1.CommunityFundMeSettingsCustomAttributesProvider, $.$WcGF.LCCFCS$1.CommunityFundMeSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WcGF.LCCFCS$2.CommunityFundMeStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WcGF.LCCFCS$2.CommunityFundMeStatesCustomAttributesProvider, $.$WcGF.LCCFCS$2.CommunityFundMeStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295078700)
            
            static $h = 111404;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295078700),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 111404,
      "h": 4295078700,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295078700)
  ],
  "h": 111404
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(111404)
        
        

        //--TRIMMABLE-BOUNDARY-START(176940)
        $asm.$cls(`$WcGF.LCCFC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295144236)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295144236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$WcGF.LCCFCS.IComunityFundMeRemoteService, $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking().$ctor$3(impl);
                }, $oLgVcc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":176940,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking().$ctor$3(impl);
                }, $Qnsnse ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":176940,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking().$ctor$3(impl);
                }, $gqTsib ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":176940,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking().$ctor$3(impl);
                }, $SoLzNi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":176940,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking().$ctor$3(impl);
                }, $yWQNfk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":176940,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking().$ctor$3(impl);
                }, $jIHWYg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":176940,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking().$ctor$3(impl);
                }, $ylGefc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":176940,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking().$ctor$3(impl);
                }, $GNkAGd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":176940,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295144236)
            
            static $h = 176940;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295144236),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 176940,
      "h": 4295144236,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295144236)
  ],
  "h": 176940
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(176940)
        
        

        //--TRIMMABLE-BOUNDARY-START(701228)
        $asm.$cls(`$WcGF.LCCFCM.CommunityFundMePostModelTypeDescriptorBuilder`, ($self) => class CommunityFundMePostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590635820)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590635820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WcGF.LCCFCM.CommunityFundMePostModelTypeDescriptor()
                        const $t1 = $.$WcGF.LCCFCM.CommunityFundMePostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $sLivDb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":701228,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WcGF.LCCFCM.CommunityFundMePostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590635820)
            
            //--TRIMMABLE-BOUNDARY-START(4295668524)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295668524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295668524)
            
            //--TRIMMABLE-BOUNDARY-START(4295668524)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295668524)
            
            static $h = 701228;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590635820),
    {
      "r": 65537,
      "n": "Register",
      "d": 701228,
      "h": 8590635820,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590635820)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295668524),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 701228,
      "h": 4295668524,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295668524)
  ],
  "h": 701228
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Models${separator}CommunityFundMePostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(701228)
        
        

        //--TRIMMABLE-BOUNDARY-START(1159980)
        $asm.$cls(`$WcGF.LCCFCS$1.CommunityFundMeSettingsTypeDescriptorBuilder`, ($self) => class CommunityFundMeSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591094572)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591094572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WcGF.LCCFCS$1.CommunityFundMeSettingsTypeDescriptor()
                        const $t1 = $.$WcGF.LCCFCS$1.CommunityFundMeSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.FundMe.Common.Settings.CommunityFundMeSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $pdTLUh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1159980,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WcGF.LCCFCS$1.CommunityFundMeSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591094572)
            
            //--TRIMMABLE-BOUNDARY-START(4296127276)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296127276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296127276)
            
            //--TRIMMABLE-BOUNDARY-START(4296127276)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296127276)
            
            static $h = 1159980;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591094572),
    {
      "r": 65537,
      "n": "Register",
      "d": 1159980,
      "h": 8591094572,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591094572)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296127276),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1159980,
      "h": 4296127276,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296127276)
  ],
  "h": 1159980
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Settings.CommunityFundMeSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Settings${separator}CommunityFundMeSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1159980)
        
        

        //--TRIMMABLE-BOUNDARY-START(439084)
        $asm.$cls(`$WcGF.LCCFCM.CommunityFundMeModelTypeDescriptorBuilder`, ($self) => class CommunityFundMeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590373676)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590373676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WcGF.LCCFCM.CommunityFundMeModelTypeDescriptor()
                        const $t1 = $.$WcGF.LCCFCM.CommunityFundMeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $PrFldd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":439084,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WcGF.LCCFCM.CommunityFundMeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590373676)
            
            //--TRIMMABLE-BOUNDARY-START(4295406380)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295406380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295406380)
            
            //--TRIMMABLE-BOUNDARY-START(4295406380)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295406380)
            
            static $h = 439084;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590373676),
    {
      "r": 65537,
      "n": "Register",
      "d": 439084,
      "h": 8590373676,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590373676)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295406380),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 439084,
      "h": 4295406380,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295406380)
  ],
  "h": 439084
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Models${separator}CommunityFundMeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(439084)
        
        

        //--TRIMMABLE-BOUNDARY-START(1422124)
        $asm.$cls(`$WcGF.LCCFCS$2.CommunityFundMeStatesTypeDescriptorBuilder`, ($self) => class CommunityFundMeStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591356716)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591356716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WcGF.LCCFCS$2.CommunityFundMeStatesTypeDescriptor()
                        const $t1 = $.$WcGF.LCCFCS$2.CommunityFundMeStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.FundMe.Common.States.CommunityFundMeStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $uvbsCe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1422124,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WcGF.LCCFCS$2.CommunityFundMeStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591356716)
            
            //--TRIMMABLE-BOUNDARY-START(4296389420)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296389420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296389420)
            
            //--TRIMMABLE-BOUNDARY-START(4296389420)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296389420)
            
            static $h = 1422124;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591356716),
    {
      "r": 65537,
      "n": "Register",
      "d": 1422124,
      "h": 8591356716,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591356716)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296389420),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1422124,
      "h": 4296389420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296389420)
  ],
  "h": 1422124
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.States.CommunityFundMeStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}States${separator}CommunityFundMeStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1422124)
        
        

        //--TRIMMABLE-BOUNDARY-START(570156)
        $asm.$cls(`$WcGF.LCCFCM.CommunityFundMePostModelCustomAttributesProvider`, ($self) => class CommunityFundMePostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295537452)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295537452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295537452)
            
            static $h = 570156;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295537452),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 570156,
      "h": 4295537452,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295537452)
  ],
  "h": 570156
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Models${separator}CommunityFundMePostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(570156)
        
        

        //--TRIMMABLE-BOUNDARY-START(766764)
        $asm.$cls(`$WcGF.LCCFC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590701356)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590701356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$WcGF.LCCFCM.CommunityFundMePostModel, 4096/*PostTypes.FundMe*/);
                $.$WcGF.LCCFC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$WcGF.LCCFC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$WcGF.LCCFC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590701356)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$WcGF.LCCFC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295734060)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295734060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295734060)
            
            //--TRIMMABLE-BOUNDARY-START(4295734060)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295734060)
            
            static $h = 766764;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590701356),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 766764,
      "h": 8590701356,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590701356)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295734060),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 766764,
      "h": 4295734060,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295734060)
  ],
  "h": 766764
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(766764)
        
        

        //--TRIMMABLE-BOUNDARY-START(963372)
        $asm.$cls(`$WcGF.LCCFCS$1.CommunityFundMeSettings`, ($self) => class CommunityFundMeSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4295930668)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295930668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295930668)
            
            //--TRIMMABLE-BOUNDARY-START(4295930668)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295930668)
            
            static $h = 963372;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295930668),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 963372,
      "h": 4295930668,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295930668)
  ],
  "h": 963372
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Settings.CommunityFundMeSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Settings${separator}CommunityFundMeSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(963372)
        
        

        //--TRIMMABLE-BOUNDARY-START(1225516)
        $asm.$cls(`$WcGF.LCCFCS$2.CommunityFundMeStates`, ($self) => class CommunityFundMeStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296192812)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296192812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296192812)
            
            //--TRIMMABLE-BOUNDARY-START(4296192812)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296192812)
            
            static $h = 1225516;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296192812),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1225516,
      "h": 4296192812,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296192812)
  ],
  "h": 1225516
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.States.CommunityFundMeStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}States${separator}CommunityFundMeStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1225516)
        
        

        //--TRIMMABLE-BOUNDARY-START(1094444)
        $asm.$cls(`$WcGF.LCCFCS$1.CommunityFundMeSettingsTypeDescriptor`, ($self) => class CommunityFundMeSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WcGF.LCCFCS$1.CommunityFundMeSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296061740)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296061740);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WcGF.LCCFCS$1.CommunityFundMeSettingsTypeDescriptor.GenerateProperties($.$WcGF.LCCFCS$1.CommunityFundMeSettings, this, factory);
                    }, $LAQOsg ??= {"r":65537,"n":"","d":1094444,"h":0,"f":17825794}), 0, "CommunityFundMeSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.FundMe.Common\\Settings_CommunityFundMeSettings_LivingThing.Core.Community.FundMe.Common.Settings.CommunityFundMeSettingsTypeDescriptorBuilder.g.cs", "CommunityFundMeSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296061740)
            
            //--TRIMMABLE-BOUNDARY-START(12885996332)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885996332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885996332)
            
            //--TRIMMABLE-BOUNDARY-START(17180963628)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.FundMe.Common.Settings.CommunityFundMeSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180963628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180963628)
            
            //--TRIMMABLE-BOUNDARY-START(8591029036)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.FundMe.Common.Settings.CommunityFundMeSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591029036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WcGF.LCCFCS$1.CommunityFundMeSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WcGF.LCCFCS$1.CommunityFundMeSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$WcGF.LCCFCS$1.CommunityFundMeSettings)))
                {
                    /*var*/ let result = $.$WcGF.LCCFCS$1.CommunityFundMeSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WcGF.LCCFCS$1.CommunityFundMeSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WcGF.LCCFCS$1.CommunityFundMeSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$WcGF.LCCFCS$1.CommunityFundMeSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591029036)
            
            static $h = 1094444;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WcGF.LCCFCS$1.CommunityFundMeSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885996332),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1094444,
      "h": 12885996332,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885996332),
//--TRIMMABLE-BOUNDARY-START(17180963628),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 963372,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1094444,
      "h": 17180963628,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180963628),
//--TRIMMABLE-BOUNDARY-START(8591029036),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 963372,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1094444,
      "h": 8591029036,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591029036)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296061740),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1094444,
      "h": 4296061740,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296061740)
  ],
  "h": 1094444
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WcGF.LCCFCS$1.CommunityFundMeSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Settings.CommunityFundMeSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Settings${separator}CommunityFundMeSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1094444)
        
        

        //--TRIMMABLE-BOUNDARY-START(1356588)
        $asm.$cls(`$WcGF.LCCFCS$2.CommunityFundMeStatesTypeDescriptor`, ($self) => class CommunityFundMeStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WcGF.LCCFCS$2.CommunityFundMeStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296323884)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296323884);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WcGF.LCCFCS$2.CommunityFundMeStatesTypeDescriptor.GenerateProperties($.$WcGF.LCCFCS$2.CommunityFundMeStates, this, factory);
                    }, $vcZTeg ??= {"r":65537,"n":"","d":1356588,"h":0,"f":17825794}), 0, "CommunityFundMeStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.FundMe.Common\\States_CommunityFundMeStates_LivingThing.Core.Community.FundMe.Common.States.CommunityFundMeStatesTypeDescriptorBuilder.g.cs", "CommunityFundMeStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296323884)
            
            //--TRIMMABLE-BOUNDARY-START(12886258476)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886258476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886258476)
            
            //--TRIMMABLE-BOUNDARY-START(17181225772)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.FundMe.Common.States.CommunityFundMeStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181225772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181225772)
            
            //--TRIMMABLE-BOUNDARY-START(8591291180)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.FundMe.Common.States.CommunityFundMeStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591291180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WcGF.LCCFCS$2.CommunityFundMeStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WcGF.LCCFCS$2.CommunityFundMeStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$WcGF.LCCFCS$2.CommunityFundMeStates)))
                {
                    /*var*/ let result = $.$WcGF.LCCFCS$2.CommunityFundMeStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WcGF.LCCFCS$2.CommunityFundMeStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WcGF.LCCFCS$2.CommunityFundMeStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$WcGF.LCCFCS$2.CommunityFundMeStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591291180)
            
            static $h = 1356588;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WcGF.LCCFCS$2.CommunityFundMeStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886258476),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1356588,
      "h": 12886258476,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886258476),
//--TRIMMABLE-BOUNDARY-START(17181225772),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1225516,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1356588,
      "h": 17181225772,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181225772),
//--TRIMMABLE-BOUNDARY-START(8591291180),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1225516,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1356588,
      "h": 8591291180,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591291180)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296323884),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1356588,
      "h": 4296323884,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296323884)
  ],
  "h": 1356588
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WcGF.LCCFCS$2.CommunityFundMeStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.States.CommunityFundMeStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}States${separator}CommunityFundMeStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1356588)
        
        

        //--TRIMMABLE-BOUNDARY-START(504620)
        $asm.$cls(`$WcGF.LCCFCM.CommunityFundMePostModel`, ($self) => class CommunityFundMePostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180373804)
            /*PostTypes */ get Type()
            {
                return 4096/*PostTypes.FundMe*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180373804)
            
            //--TRIMMABLE-BOUNDARY-START(4295471916)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295471916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295471916)
            
            //--TRIMMABLE-BOUNDARY-START(4295471916)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295471916)
            
            static $h = 504620;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180373804),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885406508,
        "f": 50364417
      },
      "n": "Type",
      "d": 504620,
      "h": 17180373804,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180373804)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295471916),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 504620,
      "h": 4295471916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295471916)
  ],
  "h": 504620
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Models${separator}CommunityFundMePostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(504620)
        
        

        //--TRIMMABLE-BOUNDARY-START(832300)
        $asm.$cls(`$WcGF.LCCFCS.IComunityFundMeRemoteService`, ($self) => class IComunityFundMeRemoteService
        {
            static $h = 832300;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 832300,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.ICreateDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.IReadDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Services.IComunityFundMeRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Services${separator}IComunityFundMeRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(832300)
        
        

        //--TRIMMABLE-BOUNDARY-START(897836)
        $asm.$cls(`$WcGF.LCCFCS.IComunityFundMeRemoteService_Mocking`, ($self) => class IComunityFundMeRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295865132)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295865132);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295865132)
            
            //--TRIMMABLE-BOUNDARY-START(8590832428)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$FundMe$Common$Models$CommunityFundMePostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590832428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$WcGF.LCCFCM.CommunityFundMePostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$WcGF.LCCFCM.CommunityFundMePostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590832428)
            
            //--TRIMMABLE-BOUNDARY-START(17180767020)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$FundMe$Common$Models$CommunityFundMePostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180767020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$WcGF.LCCFCM.CommunityFundMePostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$WcGF.LCCFCM.CommunityFundMePostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180767020)
            
            //--TRIMMABLE-BOUNDARY-START(21475734316)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$FundMe$Common$Models$CommunityFundMePostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475734316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$WcGF.LCCFCM.CommunityFundMePostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.WireTransportModel$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$WcGF.LCCFCM.CommunityFundMePostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475734316)
            
            //--TRIMMABLE-BOUNDARY-START(25770701612)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$FundMe$Common$Models$CommunityFundMePostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770701612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$WcGF.LCCFCM.CommunityFundMePostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$WcGF.LCCFCM.CommunityFundMePostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770701612)
            
            //--TRIMMABLE-BOUNDARY-START(12885799724)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885799724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$WcGF.LCCFCM.CommunityFundMePostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885799724)
            
            static $h = 897836;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295865132),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 897836,
      "h": 4295865132,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295865132)
  ],
  "h": 897836
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$WcGF.LCCFCS.IComunityFundMeRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.ICreateDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.IReadDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Services.IComunityFundMeRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Services${separator}IComunityFundMeRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(897836)
        
        

        //--TRIMMABLE-BOUNDARY-START(635692)
        $asm.$cls(`$WcGF.LCCFCM.CommunityFundMePostModelTypeDescriptor`, ($self) => class CommunityFundMePostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WcGF.LCCFCM.CommunityFundMePostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295602988)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295602988);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WcGF.LCCFCM.CommunityFundMePostModelTypeDescriptor.GenerateProperties($.$WcGF.LCCFCM.CommunityFundMePostModel, this, factory);
                    }, $eIznWd ??= {"r":65537,"n":"","d":635692,"h":0,"f":17825794}), 0, "CommunityFundMePostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.FundMe.Common\\Models_CommunityFundMePostModel_LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModelTypeDescriptorBuilder.g.cs", "CommunityFundMePostModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295602988)
            
            //--TRIMMABLE-BOUNDARY-START(12885537580)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885537580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WcGF.LCCFCM.CommunityFundMePostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WcGF.LCCFCM.CommunityFundMePostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$WcGF.LCCFCM.CommunityFundMePostModel)).Type);
                        }, $VQDEQg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":635692,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885537580)
            
            //--TRIMMABLE-BOUNDARY-START(17180504876)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180504876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180504876)
            
            //--TRIMMABLE-BOUNDARY-START(8590570284)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590570284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WcGF.LCCFCM.CommunityFundMePostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WcGF.LCCFCM.CommunityFundMePostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WcGF.LCCFCM.CommunityFundMePostModel)))
                {
                    /*var*/ let result = $.$WcGF.LCCFCM.CommunityFundMePostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WcGF.LCCFCM.CommunityFundMePostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WcGF.LCCFCM.CommunityFundMePostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WcGF.LCCFCM.CommunityFundMePostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590570284)
            
            static $h = 635692;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WcGF.LCCFCM.CommunityFundMePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885537580),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 635692,
      "h": 12885537580,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885537580),
//--TRIMMABLE-BOUNDARY-START(17180504876),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 504620,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 635692,
      "h": 17180504876,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180504876),
//--TRIMMABLE-BOUNDARY-START(8590570284),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 504620,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 635692,
      "h": 8590570284,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590570284)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295602988),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 635692,
      "h": 4295602988,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295602988)
  ],
  "h": 635692
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WcGF.LCCFCM.CommunityFundMePostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMePostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Models${separator}CommunityFundMePostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(635692)
        
        

        //--TRIMMABLE-BOUNDARY-START(242476)
        $asm.$cls(`$WcGF.LCCFCM.CommunityFundMeModel`, ($self) => class CommunityFundMeModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$WcGF.LCCFCS$1.CommunityFundMeSettings, $.$WcGF.LCCFCS$2.CommunityFundMeStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295209772)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295209772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295209772)
            
            //--TRIMMABLE-BOUNDARY-START(4295209772)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295209772)
            
            static $h = 242476;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$WcGF.LCCFCS$1.CommunityFundMeSettings, $.$WcGF.LCCFCS$2.CommunityFundMeStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295209772),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 242476,
      "h": 4295209772,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295209772)
  ],
  "h": 242476
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Models${separator}CommunityFundMeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(242476)
        
        

        //--TRIMMABLE-BOUNDARY-START(373548)
        $asm.$cls(`$WcGF.LCCFCM.CommunityFundMeModelTypeDescriptor`, ($self) => class CommunityFundMeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WcGF.LCCFCM.CommunityFundMeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295340844)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295340844);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WcGF.LCCFCM.CommunityFundMeModelTypeDescriptor.GenerateProperties($.$WcGF.LCCFCM.CommunityFundMeModel, this, factory);
                    }, $lbGTrh ??= {"r":65537,"n":"","d":373548,"h":0,"f":17825794}), 0, "CommunityFundMeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.FundMe.Common\\Models_CommunityFundMeModel_LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMeModelTypeDescriptorBuilder.g.cs", "CommunityFundMeModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295340844)
            
            //--TRIMMABLE-BOUNDARY-START(12885275436)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885275436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$WcGF.LCCFCS$1.CommunityFundMeSettings, $.$WcGF.LCCFCS$2.CommunityFundMeStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885275436)
            
            //--TRIMMABLE-BOUNDARY-START(17180242732)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180242732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.FundMe.Common.Settings.CommunityFundMeSettings, LivingThing.Core.Community.FundMe.Common.States.CommunityFundMeStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$WcGF.LCCFCS$1.CommunityFundMeSettings, $.$WcGF.LCCFCS$2.CommunityFundMeStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$WcGF.LCCFCS$1.CommunityFundMeSettings, $.$WcGF.LCCFCS$2.CommunityFundMeStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180242732)
            
            //--TRIMMABLE-BOUNDARY-START(8590308140)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590308140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WcGF.LCCFCM.CommunityFundMeModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WcGF.LCCFCM.CommunityFundMeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WcGF.LCCFCM.CommunityFundMeModel)))
                {
                    /*var*/ let result = $.$WcGF.LCCFCM.CommunityFundMeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WcGF.LCCFCM.CommunityFundMeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WcGF.LCCFCM.CommunityFundMeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WcGF.LCCFCM.CommunityFundMeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590308140)
            
            static $h = 373548;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WcGF.LCCFCM.CommunityFundMeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885275436),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 373548,
      "h": 12885275436,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885275436),
//--TRIMMABLE-BOUNDARY-START(17180242732),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 242476,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 373548,
      "h": 17180242732,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180242732),
//--TRIMMABLE-BOUNDARY-START(8590308140),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 242476,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 373548,
      "h": 8590308140,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590308140)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295340844),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 373548,
      "h": 4295340844,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295340844)
  ],
  "h": 373548
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WcGF.LCCFCM.CommunityFundMeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.FundMe.Common.Models.CommunityFundMeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}FundMe${separator}Common${separator}Models${separator}CommunityFundMeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(373548)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(45868)
