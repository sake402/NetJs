
//--TRIMMABLE-BOUNDARY-START(15062)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $tCiC) {
    "use strict";
    let _;
    let $ZAusvc;
    let $CObxOf;
    let $XEqORj;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Games.Client.Blazor", 
    {
  "h": 15062,
  "f": "LivingThing.Core.Community.Games.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Games.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Games.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(146134)
        $asm.$cls(`$uERE.LCCGC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295113430)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295113430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$uERE.LCCGC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295113430)
            
            static $h = 146134;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295113430),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 146134,
      "h": 4295113430,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295113430)
  ],
  "h": 146134
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(146134)
        
        

        //--TRIMMABLE-BOUNDARY-START(211670)
        $asm.$cls(`$uERE.LCCGC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180080854)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$uERE.LCCGCP.CommunityGamesApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$uERE.LCCGCP.CommunityGamesApp().$ctor$6();
                    }, $ZAusvc ??= {"r":2752627,"n":"","d":211670,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180080854)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295178966)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295178966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295178966)
            
            //--TRIMMABLE-BOUNDARY-START(4295178966)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295178966)
            
            static $h = 211670;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180080854),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885113558,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 211670,
      "h": 17180080854,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180080854)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295178966),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 211670,
      "h": 4295178966,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295178966)
  ],
  "h": 211670
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(211670)
        
        

        //--TRIMMABLE-BOUNDARY-START(342742)
        $asm.$cls(`$uERE.LCCGC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590277334)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590277334);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$uERE.LCCGCS.CommunityGamesService, $.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$tCiC.LCCGCM.CommunityGamesPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$uERE.LCCGCS.CommunityGamesApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uERE.LCCGCS.CommunityGamesApplication, x);
                }, $CObxOf ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":342742,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uERE.LCCGCS.CommunityGamesApplication, x);
                }, $XEqORj ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":342742,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$uERE.LCCGCS.CommunityGamesFeedProvider, services);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$tCiC.LCCGCM.CommunityGamesPostModel, services, null);
                $.$uERE.LCCGC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590277334)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$uERE.LCCGC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295310038)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295310038);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295310038)
            
            //--TRIMMABLE-BOUNDARY-START(4295310038)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295310038)
            
            static $h = 342742;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590277334),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 342742,
      "h": 8590277334,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590277334)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295310038),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 342742,
      "h": 4295310038,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295310038)
  ],
  "h": 342742
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(342742)
        
        

        //--TRIMMABLE-BOUNDARY-START(670422)
        $asm.$cls(`$uERE.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295637718)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295637718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295637718)
            
            //--TRIMMABLE-BOUNDARY-START(4295637718)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295637718)
            
            static $h = 670422;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295637718),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 670422,
      "h": 4295637718,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295637718)
  ],
  "h": 670422,
  "a": [
    {
      "t": 604886,
      "c": 4295572182
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(670422)
        
        

        //--TRIMMABLE-BOUNDARY-START(604886)
        $asm.$cls(`$uERE.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295572182)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295572182);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295572182)
            
            //--TRIMMABLE-BOUNDARY-START(4295572182)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295572182)
            
            static $h = 604886;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295572182),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 604886,
      "h": 4295572182,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295572182)
  ],
  "h": 604886
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(604886)
        
        

        //--TRIMMABLE-BOUNDARY-START(80598)
        $asm.$cls(`$uERE.LCCGC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590015190)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590015190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590015190)
            
            //--TRIMMABLE-BOUNDARY-START(4295047894)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295047894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295047894)
            
            //--TRIMMABLE-BOUNDARY-START(4295047894)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295047894)
            
            static $h = 80598;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590015190),
    {
      "r": 65537,
      "n": "Execute",
      "d": 80598,
      "h": 8590015190,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590015190)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295047894),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 80598,
      "h": 4295047894,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295047894)
  ],
  "h": 80598
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(80598)
        
        

        //--TRIMMABLE-BOUNDARY-START(473814)
        $asm.$cls(`$uERE.LCCGCS.CommunityGamesFeedProvider`, ($self) => class CommunityGamesFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$tCiC.LCCGCM.CommunityGamesPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295441110)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295441110);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295441110)
            
            //--TRIMMABLE-BOUNDARY-START(8590408406)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityGamesPostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590408406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`created an article`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590408406)
            
            static $h = 473814;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$tCiC.LCCGCM.CommunityGamesPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590408406),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 840608
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 473814,
      "h": 8590408406,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590408406)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295441110),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 473814,
      "h": 4295441110,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295441110)
  ],
  "h": 473814
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Client.Services.CommunityGamesFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Client${separator}Services${separator}CommunityGamesFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(473814)
        
        

        //--TRIMMABLE-BOUNDARY-START(408278)
        $asm.$cls(`$uERE.LCCGCS.CommunityGamesApplication`, ($self) => class CommunityGamesApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(17180277462)
            $ctor$5(/*CommunityGamesService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180277462);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180277462)
            
            //--TRIMMABLE-BOUNDARY-START(150324263638)
            /*string */ get Name()
            {
                return "Games";
            }
            //--TRIMMABLE-BOUNDARY-END(150324263638)
            
            //--TRIMMABLE-BOUNDARY-START(176094067414)
            /*string */ get Title()
            {
                return "Games";
            }
            //--TRIMMABLE-BOUNDARY-END(176094067414)
            
            //--TRIMMABLE-BOUNDARY-START(25770212054)
            /*string */ get Description()
            {
                return "";
            }
            //--TRIMMABLE-BOUNDARY-END(25770212054)
            
            //--TRIMMABLE-BOUNDARY-START(146029296342)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-gamepad"/*MaterialDesignIconNames.Gamepad*/);
            }
            //--TRIMMABLE-BOUNDARY-END(146029296342)
            
            //--TRIMMABLE-BOUNDARY-START(171799100118)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#FFFF00";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(171799100118)
            
            //--TRIMMABLE-BOUNDARY-START(34360146646)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(34360146646)
            
            //--TRIMMABLE-BOUNDARY-START(21475244758)
            /*Type? */ get ApplicationViewType()
            {
                return $.$uERE.LCCGCP.CommunityGamesApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(21475244758)
            
            //--TRIMMABLE-BOUNDARY-START(141734329046)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734329046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$uERE.LCCGCP.CommunityGamesApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(141734329046)
            
            //--TRIMMABLE-BOUNDARY-START(30065179350)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065179350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(30065179350)
            
            //--TRIMMABLE-BOUNDARY-START(158914198230)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914198230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(158914198230)
            
            //--TRIMMABLE-BOUNDARY-START(154619230934)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(154619230934)
            
            //--TRIMMABLE-BOUNDARY-START(4295375574)
            /*CommunityGamesService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295375574)
            
            //--TRIMMABLE-BOUNDARY-START(163209165526)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(163209165526)
            
            //--TRIMMABLE-BOUNDARY-START(167504132822)
            /*IEnumerable<IApplicationSubService>?*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(167504132822)
            
            //--TRIMMABLE-BOUNDARY-START(180389034710)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(8960/*PostTypes.Games*/, 8963/*PostTypes.GamesEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(180389034710)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 408278;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(150324263638),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899754198,
        "f": 50364417
      },
      "n": "Name",
      "d": 408278,
      "h": 150324263638,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324263638),
//--TRIMMABLE-BOUNDARY-START(176094067414),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849427158,
        "f": 50364417
      },
      "n": "Title",
      "d": 408278,
      "h": 176094067414,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176094067414),
//--TRIMMABLE-BOUNDARY-START(25770212054),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129950422,
        "f": 50364417
      },
      "n": "Description",
      "d": 408278,
      "h": 25770212054,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770212054),
//--TRIMMABLE-BOUNDARY-START(146029296342),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309819606,
        "f": 50364417
      },
      "n": "Icon",
      "d": 408278,
      "h": 146029296342,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029296342),
//--TRIMMABLE-BOUNDARY-START(171799100118),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259492566,
        "f": 50364417
      },
      "n": "Theme",
      "d": 408278,
      "h": 171799100118,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(171799100118),
//--TRIMMABLE-BOUNDARY-START(34360146646),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719885014,
        "f": 50364417
      },
      "n": "Features",
      "d": 408278,
      "h": 34360146646,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360146646),
//--TRIMMABLE-BOUNDARY-START(21475244758),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540015830,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 408278,
      "h": 21475244758,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475244758),
//--TRIMMABLE-BOUNDARY-START(154619230934),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489688790,
        "f": 50364417
      },
      "n": "Order",
      "d": 408278,
      "h": 154619230934,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619230934),
//--TRIMMABLE-BOUNDARY-START(4295375574),
    {
      "p": 539350,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950081238,
        "f": 50331650
      },
      "n": "_Service",
      "d": 408278,
      "h": 4295375574,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295375574),
//--TRIMMABLE-BOUNDARY-START(163209165526),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079623382,
        "f": 50364417
      },
      "n": "Service",
      "d": 408278,
      "h": 163209165526,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209165526),
//--TRIMMABLE-BOUNDARY-START(167504132822),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669557974,
        "f": 50364417
      },
      "n": "Services",
      "d": 408278,
      "h": 167504132822,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(167504132822),
//--TRIMMABLE-BOUNDARY-START(180389034710),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439361750,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 408278,
      "h": 180389034710,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389034710)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(141734329046),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 408278,
      "h": 141734329046,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(141734329046),
//--TRIMMABLE-BOUNDARY-START(30065179350),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 408278,
      "h": 30065179350,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065179350),
//--TRIMMABLE-BOUNDARY-START(158914198230),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 408278,
      "h": 158914198230,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914198230)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180277462),
    {
      "p": [
        {
          "n": "service",
          "p": 539350
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 408278,
      "h": 17180277462,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180277462)
  ],
  "h": 408278
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$tCiC.LCCGCM.CommunityGamesPostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Client.Services.CommunityGamesApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Client${separator}Services${separator}CommunityGamesApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(408278)
        
        

        //--TRIMMABLE-BOUNDARY-START(277206)
        $asm.$cls(`$uERE.LCCGCP.CommunityGamesApp`, ($self) => class CommunityGamesApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$tCiC.LCCGCM.CommunityGamesPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$tCiC.LCCGCM.CommunityGamesUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(30065048278)
            /*CommunityGamesService*/ GamesService = null;
            //--TRIMMABLE-BOUNDARY-END(30065048278)
            
            //--TRIMMABLE-BOUNDARY-START(25770080982)
            /*CommunityGamesApplication*/ GamesApplication = null;
            //--TRIMMABLE-BOUNDARY-END(25770080982)
            
            //--TRIMMABLE-BOUNDARY-START(17180146390)
            /*ICommunityClientApplication */ get Application()
            {
                return this.GamesApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(17180146390)
            
            //--TRIMMABLE-BOUNDARY-START(60129819350)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129819350);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.GamesService.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60129819350)
            
            //--TRIMMABLE-BOUNDARY-START(21475113686)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475113686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
            }
            //--TRIMMABLE-BOUNDARY-END(21475113686)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885179094)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885179094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885179094)
            
            //--TRIMMABLE-BOUNDARY-START(12885179094)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12885179094)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30065048278)
                this.GamesService = null;
                //--TRIMMABLE-BOUNDARY-END(30065048278)
                
                //--TRIMMABLE-BOUNDARY-START(25770080982)
                this.GamesApplication = null;
                //--TRIMMABLE-BOUNDARY-END(25770080982)
                
            }
            static $h = 277206;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$tCiC.LCCGCM.CommunityGamesPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$tCiC.LCCGCM.CommunityGamesUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065048278),
    {
      "p": 539350,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834852054,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309688534,
        "f": 83886081
      },
      "n": "GamesService",
      "d": 277206,
      "h": 30065048278,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065048278),
//--TRIMMABLE-BOUNDARY-START(25770080982),
    {
      "p": 408278,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244917462,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719753942,
        "f": 83886081
      },
      "n": "GamesApplication",
      "d": 277206,
      "h": 25770080982,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770080982),
//--TRIMMABLE-BOUNDARY-START(17180146390),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654982870,
        "f": 50364420
      },
      "n": "Application",
      "d": 277206,
      "h": 17180146390,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(17180146390)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60129819350),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 277206,
      "h": 60129819350,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(60129819350),
//--TRIMMABLE-BOUNDARY-START(21475113686),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 277206,
      "h": 21475113686,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475113686)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885179094),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 277206,
      "h": 12885179094,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885179094)
  ],
  "h": 277206
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Client.Pages.CommunityGamesApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Client${separator}Pages${separator}CommunityGamesApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(277206)
        
        

        //--TRIMMABLE-BOUNDARY-START(539350)
        $asm.$cls(`$uERE.LCCGCS.CommunityGamesService`, ($self) => class CommunityGamesService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$tCiC.LCCGCM.CommunityGamesPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295506646)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295506646);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295506646)
            
            static $h = 539350;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$tCiC.LCCGCM.CommunityGamesPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295506646),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 539350,
      "h": 4295506646,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295506646)
  ],
  "h": 539350
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$tCiC.LCCGCM.CommunityGamesPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$tCiC.LCCGCM.CommunityGamesPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Client.Services.CommunityGamesService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Client${separator}Services${separator}CommunityGamesService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(539350)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Games.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(15062)
