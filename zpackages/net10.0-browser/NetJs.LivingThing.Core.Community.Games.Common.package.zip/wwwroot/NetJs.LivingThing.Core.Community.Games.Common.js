
//--TRIMMABLE-BOUNDARY-START(54176)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $GDJtoh;
    let $dCTlzk;
    let $tCqwfe;
    let $jgFzza;
    let $KvAVAi;
    let $pLCpAb;
    let $CdOXBd;
    let $GFBAda;
    let $texRLa;
    let $TLIcaa;
    let $MTUCea;
    let $BoPXza;
    let $shwfnc;
    let $dkyjOc;
    let $iyCKaf;
    let $vPyiLe;
    let $peZEsh;
    let $xxXtWd;
    let $QsbGgb;
    let $zJHWJk;
    let $rLSouh;
    let $XcqMEe;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Games.Common", 
    {
  "h": 54176,
  "f": "LivingThing.Core.Community.Games.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Games.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Games.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1692576)
        $asm.$cls(`$tCiC.LCCGCS.IGamePlayer`, ($self) => class IGamePlayer
        {
            static $h = 1692576;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886594464),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591627168,
        "f": 50331905
      },
      "n": "Name",
      "o": "LCCGCS$IGamePlayer$Name",
      "d": 1692576,
      "h": 12886594464,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886594464)
  ],
  "h": 1692576
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Services.IGamePlayer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Services${separator}IGamePlayer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1692576)
        
        

        //--TRIMMABLE-BOUNDARY-START(1627040)
        $asm.$cls(`$tCiC.LCCGCS.IGame`, ($self) => class IGame
        {
            static $h = 1627040;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656332704),
    {
      "p": 1233824,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476463520,
        "f": 50331905
      },
      "n": "State",
      "o": "LCCGCS$IGame$State",
      "d": 1627040,
      "h": 38656332704,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38656332704),
//--TRIMMABLE-BOUNDARY-START(30066398112),
    {
      "p": $.$$.SCG.IEnumerable$$($.$tCiC.LCCGCS.IGamePlayer).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886528928,
        "f": 50331905
      },
      "n": "Players",
      "o": "LCCGCS$IGame$Players",
      "d": 1627040,
      "h": 30066398112,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30066398112)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361365408),
    {
      "r": 178454529,
      "n": "Start",
      "o": "LCCGCS$IGame$Start",
      "d": 1627040,
      "h": 34361365408,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34361365408),
//--TRIMMABLE-BOUNDARY-START(25771430816),
    {
      "r": 178454529,
      "n": "Pause",
      "o": "LCCGCS$IGame$Pause",
      "d": 1627040,
      "h": 25771430816,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25771430816),
//--TRIMMABLE-BOUNDARY-START(4296594336),
    {
      "r": 178454529,
      "p": [
        {
          "n": "player",
          "p": 1692576
        }
      ],
      "n": "AddPlayer",
      "o": "LCCGCS$IGame$AddPlayer",
      "d": 1627040,
      "h": 4296594336,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296594336)
  ],
  "h": 1627040
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Services.IGame`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Services${separator}IGame`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1627040)
        
        

        //--TRIMMABLE-BOUNDARY-START(185248)
        $asm.$cls(`$tCiC.LCCGC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295152544)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295152544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295152544)
            
            static $h = 185248;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295152544),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 185248,
      "h": 4295152544,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295152544)
  ],
  "h": 185248
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(185248)
        
        

        //--TRIMMABLE-BOUNDARY-START(119712)
        $asm.$cls(`$tCiC.LCCGC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295087008)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295087008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tCiC.LCCGCM.CommunityGamesCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tCiC.LCCGCM.CommunityGamesCategoryModelCustomAttributesProvider, $.$tCiC.LCCGCM.CommunityGamesCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tCiC.LCCGCM.CommunityGamesModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tCiC.LCCGCM.CommunityGamesModelCustomAttributesProvider, $.$tCiC.LCCGCM.CommunityGamesModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tCiC.LCCGCM.CommunityGamesPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tCiC.LCCGCM.CommunityGamesPostModelCustomAttributesProvider, $.$tCiC.LCCGCM.CommunityGamesPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tCiC.LCCGCS.GameState.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tCiC.LCCGCS.GameStateCustomAttributesProvider, $.$tCiC.LCCGCS.GameStateCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tCiC.LCCGCS$1.CommunityGamesSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tCiC.LCCGCS$1.CommunityGamesSettingsCustomAttributesProvider, $.$tCiC.LCCGCS$1.CommunityGamesSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tCiC.LCCGCS$2.CommunityGamesStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tCiC.LCCGCS$2.CommunityGamesStatesCustomAttributesProvider, $.$tCiC.LCCGCS$2.CommunityGamesStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295087008)
            
            static $h = 119712;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295087008),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 119712,
      "h": 4295087008,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295087008)
  ],
  "h": 119712
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(119712)
        
        

        //--TRIMMABLE-BOUNDARY-START(1299360)
        $asm.$cls(`$tCiC.LCCGCS.GameStateCustomAttributesProvider`, ($self) => class GameStateCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296266656)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296266656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296266656)
            
            static $h = 1299360;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296266656),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1299360,
      "h": 4296266656,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296266656)
  ],
  "h": 1299360
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Services.GameStateCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Services${separator}GameStateCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1299360)
        
        

        //--TRIMMABLE-BOUNDARY-START(381856)
        $asm.$cls(`$tCiC.LCCGCM.CommunityGamesCategoryModelCustomAttributesProvider`, ($self) => class CommunityGamesCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295349152)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295349152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$tCiC.LCCGCM.CommunityGamesPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295349152)
            
            static $h = 381856;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295349152),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 381856,
      "h": 4295349152,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295349152)
  ],
  "h": 381856
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Models.CommunityGamesCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Models${separator}CommunityGamesCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(381856)
        
        

        //--TRIMMABLE-BOUNDARY-START(2085792)
        $asm.$cls(`$tCiC.LCCGCS$2.CommunityGamesStatesCustomAttributesProvider`, ($self) => class CommunityGamesStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297053088)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297053088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297053088)
            
            static $h = 2085792;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297053088),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2085792,
      "h": 4297053088,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297053088)
  ],
  "h": 2085792
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.States.CommunityGamesStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}States${separator}CommunityGamesStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2085792)
        
        

        //--TRIMMABLE-BOUNDARY-START(644000)
        $asm.$cls(`$tCiC.LCCGCM.CommunityGamesModelCustomAttributesProvider`, ($self) => class CommunityGamesModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295611296)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295611296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$tCiC.LCCGCS$1.CommunityGamesSettings, $.$tCiC.LCCGCS$2.CommunityGamesStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295611296)
            
            static $h = 644000;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295611296),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 644000,
      "h": 4295611296,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295611296)
  ],
  "h": 644000
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Models.CommunityGamesModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Models${separator}CommunityGamesModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(644000)
        
        

        //--TRIMMABLE-BOUNDARY-START(906144)
        $asm.$cls(`$tCiC.LCCGCM.CommunityGamesPostModelCustomAttributesProvider`, ($self) => class CommunityGamesPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295873440)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295873440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295873440)
            
            static $h = 906144;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295873440),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 906144,
      "h": 4295873440,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295873440)
  ],
  "h": 906144
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Models${separator}CommunityGamesPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(906144)
        
        

        //--TRIMMABLE-BOUNDARY-START(1954720)
        $asm.$cls(`$tCiC.LCCGCS$1.CommunityGamesSettingsTypeDescriptorBuilder`, ($self) => class CommunityGamesSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591889312)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591889312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tCiC.LCCGCS$1.CommunityGamesSettingsTypeDescriptor()
                        const $t1 = $.$tCiC.LCCGCS$1.CommunityGamesSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Games.Common.Settings.CommunityGamesSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $GDJtoh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1954720,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tCiC.LCCGCS$1.CommunityGamesSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591889312)
            
            //--TRIMMABLE-BOUNDARY-START(4296922016)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296922016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296922016)
            
            //--TRIMMABLE-BOUNDARY-START(4296922016)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296922016)
            
            static $h = 1954720;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591889312),
    {
      "r": 65537,
      "n": "Register",
      "d": 1954720,
      "h": 8591889312,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591889312)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296922016),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1954720,
      "h": 4296922016,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296922016)
  ],
  "h": 1954720
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Settings.CommunityGamesSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Settings${separator}CommunityGamesSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1954720)
        
        

        //--TRIMMABLE-BOUNDARY-START(512928)
        $asm.$cls(`$tCiC.LCCGCM.CommunityGamesCategoryModelTypeDescriptorBuilder`, ($self) => class CommunityGamesCategoryModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590447520)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590447520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tCiC.LCCGCM.CommunityGamesCategoryModelTypeDescriptor()
                        const $t1 = $.$tCiC.LCCGCM.CommunityGamesCategoryModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Games.Common.Models.CommunityGamesCategoryModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $peZEsh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":512928,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tCiC.LCCGCM.CommunityGamesCategoryModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590447520)
            
            //--TRIMMABLE-BOUNDARY-START(4295480224)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295480224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295480224)
            
            //--TRIMMABLE-BOUNDARY-START(4295480224)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295480224)
            
            static $h = 512928;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590447520),
    {
      "r": 65537,
      "n": "Register",
      "d": 512928,
      "h": 8590447520,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590447520)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295480224),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 512928,
      "h": 4295480224,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295480224)
  ],
  "h": 512928
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Models.CommunityGamesCategoryModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Models${separator}CommunityGamesCategoryModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(512928)
        
        

        //--TRIMMABLE-BOUNDARY-START(250784)
        $asm.$cls(`$tCiC.LCCGC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295218080)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295218080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$tCiC.LCCGCS.ICommunityGamesFeedRemoteService, $.$tCiC.LCCGCS.ICommunityGamesFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$tCiC.LCCGCS.ICommunityGamesFeedRemoteService_Mocking().$ctor$3(impl);
                }, $tCqwfe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":250784,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$tCiC.LCCGCS.ICommunityGamesFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$tCiC.LCCGCS.ICommunityGamesFeedRemoteService_Mocking().$ctor$3(impl);
                }, $jgFzza ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":250784,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$tCiC.LCCGCS.IComunityGamesRemoteService, $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking().$ctor$3(impl);
                }, $KvAVAi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":250784,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking().$ctor$3(impl);
                }, $pLCpAb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":250784,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking().$ctor$3(impl);
                }, $CdOXBd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":250784,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking().$ctor$3(impl);
                }, $GFBAda ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":250784,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking().$ctor$3(impl);
                }, $texRLa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":250784,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking().$ctor$3(impl);
                }, $TLIcaa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":250784,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking().$ctor$3(impl);
                }, $MTUCea ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":250784,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking().$ctor$3(impl);
                }, $BoPXza ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":250784,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295218080)
            
            static $h = 250784;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295218080),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 250784,
      "h": 4295218080,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295218080)
  ],
  "h": 250784
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(250784)
        
        

        //--TRIMMABLE-BOUNDARY-START(1823648)
        $asm.$cls(`$tCiC.LCCGCS$1.CommunityGamesSettingsCustomAttributesProvider`, ($self) => class CommunityGamesSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296790944)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296790944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296790944)
            
            static $h = 1823648;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296790944),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1823648,
      "h": 4296790944,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296790944)
  ],
  "h": 1823648
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Settings.CommunityGamesSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Settings${separator}CommunityGamesSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1823648)
        
        

        //--TRIMMABLE-BOUNDARY-START(2282400)
        $asm.$cls(`$tCiC.LCCGC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297249696)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297249696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$tCiC.LCCGCM.CommunityGamesCategoryModelTypeDescriptorBuilder.Register();
                $.$tCiC.LCCGCM.CommunityGamesModelTypeDescriptorBuilder.Register();
                $.$tCiC.LCCGCM.CommunityGamesPostModelTypeDescriptorBuilder.Register();
                $.$tCiC.LCCGCS$1.CommunityGamesSettingsTypeDescriptorBuilder.Register();
                $.$tCiC.LCCGCS$2.CommunityGamesStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297249696)
            
            static $h = 2282400;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297249696),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2282400,
      "h": 4297249696,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297249696)
  ],
  "h": 2282400
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2282400)
        
        

        //--TRIMMABLE-BOUNDARY-START(2216864)
        $asm.$cls(`$tCiC.LCCGCS$2.CommunityGamesStatesTypeDescriptorBuilder`, ($self) => class CommunityGamesStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592151456)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592151456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tCiC.LCCGCS$2.CommunityGamesStatesTypeDescriptor()
                        const $t1 = $.$tCiC.LCCGCS$2.CommunityGamesStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Games.Common.States.CommunityGamesStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $shwfnc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2216864,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tCiC.LCCGCS$2.CommunityGamesStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592151456)
            
            //--TRIMMABLE-BOUNDARY-START(4297184160)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297184160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297184160)
            
            //--TRIMMABLE-BOUNDARY-START(4297184160)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297184160)
            
            static $h = 2216864;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592151456),
    {
      "r": 65537,
      "n": "Register",
      "d": 2216864,
      "h": 8592151456,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592151456)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297184160),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2216864,
      "h": 4297184160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297184160)
  ],
  "h": 2216864
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.States.CommunityGamesStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}States${separator}CommunityGamesStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2216864)
        
        

        //--TRIMMABLE-BOUNDARY-START(775072)
        $asm.$cls(`$tCiC.LCCGCM.CommunityGamesModelTypeDescriptorBuilder`, ($self) => class CommunityGamesModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590709664)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590709664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tCiC.LCCGCM.CommunityGamesModelTypeDescriptor()
                        const $t1 = $.$tCiC.LCCGCM.CommunityGamesModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Games.Common.Models.CommunityGamesModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iyCKaf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":775072,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tCiC.LCCGCM.CommunityGamesModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590709664)
            
            //--TRIMMABLE-BOUNDARY-START(4295742368)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295742368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295742368)
            
            //--TRIMMABLE-BOUNDARY-START(4295742368)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295742368)
            
            static $h = 775072;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590709664),
    {
      "r": 65537,
      "n": "Register",
      "d": 775072,
      "h": 8590709664,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590709664)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295742368),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 775072,
      "h": 4295742368,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295742368)
  ],
  "h": 775072
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Models.CommunityGamesModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Models${separator}CommunityGamesModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(775072)
        
        

        //--TRIMMABLE-BOUNDARY-START(1037216)
        $asm.$cls(`$tCiC.LCCGCM.CommunityGamesPostModelTypeDescriptorBuilder`, ($self) => class CommunityGamesPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590971808)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590971808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tCiC.LCCGCM.CommunityGamesPostModelTypeDescriptor()
                        const $t1 = $.$tCiC.LCCGCM.CommunityGamesPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $zJHWJk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1037216,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tCiC.LCCGCM.CommunityGamesPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590971808)
            
            //--TRIMMABLE-BOUNDARY-START(4296004512)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296004512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296004512)
            
            //--TRIMMABLE-BOUNDARY-START(4296004512)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296004512)
            
            static $h = 1037216;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590971808),
    {
      "r": 65537,
      "n": "Register",
      "d": 1037216,
      "h": 8590971808,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590971808)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296004512),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1037216,
      "h": 4296004512,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296004512)
  ],
  "h": 1037216
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Models${separator}CommunityGamesPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1037216)
        
        

        //--TRIMMABLE-BOUNDARY-START(1168288)
        $asm.$cls(`$tCiC.LCCGC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591102880)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591102880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$tCiC.LCCGCM.CommunityGamesCategoryModel, 8961/*PostTypes.GamesCategory*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$tCiC.LCCGCM.CommunityGamesPostModel, 8962/*PostTypes.GamesPost*/);
                $.$tCiC.LCCGC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$tCiC.LCCGC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$tCiC.LCCGC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591102880)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$tCiC.LCCGC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296135584)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296135584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296135584)
            
            //--TRIMMABLE-BOUNDARY-START(4296135584)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296135584)
            
            static $h = 1168288;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591102880),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1168288,
      "h": 8591102880,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591102880)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296135584),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1168288,
      "h": 4296135584,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296135584)
  ],
  "h": 1168288
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1168288)
        
        

        //--TRIMMABLE-BOUNDARY-START(1233824)
        $asm.$str(`$tCiC.LCCGCS.GameState`, ($self) => class GameState extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Stopped = 0;
            static Started = 1;
            static Paused = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1233824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Stopped": 0n,
                    "Started": 1n,
                    "Paused": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296201120)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296201120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296201120)
            
            //--TRIMMABLE-BOUNDARY-START(4296201120)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296201120)
            
            static $h = 1233824;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181103008),
    {
      "t": 1233824,
      "n": "Stopped",
      "d": 1233824,
      "h": 17181103008,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181103008),
//--TRIMMABLE-BOUNDARY-START(12886135712),
    {
      "t": 1233824,
      "n": "Started",
      "d": 1233824,
      "h": 12886135712,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886135712),
//--TRIMMABLE-BOUNDARY-START(8591168416),
    {
      "t": 1233824,
      "n": "Paused",
      "d": 1233824,
      "h": 8591168416,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591168416)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296201120),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1233824,
      "h": 4296201120,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296201120)
  ],
  "h": 1233824
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Services.GameState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Services${separator}GameState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1233824)
        
        

        //--TRIMMABLE-BOUNDARY-START(1102752)
        $asm.$cls(`$tCiC.LCCGCM.CommunityGamesUserPreference`, ($self) => class CommunityGamesUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4296070048)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296070048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296070048)
            
            //--TRIMMABLE-BOUNDARY-START(4296070048)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296070048)
            
            static $h = 1102752;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296070048),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1102752,
      "h": 4296070048,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296070048)
  ],
  "h": 1102752
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Models.CommunityGamesUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Models${separator}CommunityGamesUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1102752)
        
        

        //--TRIMMABLE-BOUNDARY-START(2020256)
        $asm.$cls(`$tCiC.LCCGCS$2.CommunityGamesStates`, ($self) => class CommunityGamesStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296987552)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296987552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296987552)
            
            //--TRIMMABLE-BOUNDARY-START(4296987552)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296987552)
            
            static $h = 2020256;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296987552),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2020256,
      "h": 4296987552,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296987552)
  ],
  "h": 2020256
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.States.CommunityGamesStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}States${separator}CommunityGamesStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2020256)
        
        

        //--TRIMMABLE-BOUNDARY-START(1758112)
        $asm.$cls(`$tCiC.LCCGCS$1.CommunityGamesSettings`, ($self) => class CommunityGamesSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296725408)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296725408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296725408)
            
            //--TRIMMABLE-BOUNDARY-START(4296725408)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296725408)
            
            static $h = 1758112;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296725408),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1758112,
      "h": 4296725408,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296725408)
  ],
  "h": 1758112
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Settings.CommunityGamesSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Settings${separator}CommunityGamesSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1758112)
        
        

        //--TRIMMABLE-BOUNDARY-START(1889184)
        $asm.$cls(`$tCiC.LCCGCS$1.CommunityGamesSettingsTypeDescriptor`, ($self) => class CommunityGamesSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tCiC.LCCGCS$1.CommunityGamesSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296856480)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296856480);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tCiC.LCCGCS$1.CommunityGamesSettingsTypeDescriptor.GenerateProperties($.$tCiC.LCCGCS$1.CommunityGamesSettings, this, factory);
                    }, $dCTlzk ??= {"r":65537,"n":"","d":1889184,"h":0,"f":17825794}), 0, "CommunityGamesSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Games.Common\\Settings_CommunityGamesSettings_LivingThing.Core.Community.Games.Common.Settings.CommunityGamesSettingsTypeDescriptorBuilder.g.cs", "CommunityGamesSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296856480)
            
            //--TRIMMABLE-BOUNDARY-START(12886791072)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886791072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886791072)
            
            //--TRIMMABLE-BOUNDARY-START(17181758368)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Games.Common.Settings.CommunityGamesSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181758368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181758368)
            
            //--TRIMMABLE-BOUNDARY-START(8591823776)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Games.Common.Settings.CommunityGamesSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591823776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tCiC.LCCGCS$1.CommunityGamesSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tCiC.LCCGCS$1.CommunityGamesSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCS$1.CommunityGamesSettings)))
                {
                    /*var*/ let result = $.$tCiC.LCCGCS$1.CommunityGamesSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCS$1.CommunityGamesSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tCiC.LCCGCS$1.CommunityGamesSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCS$1.CommunityGamesSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591823776)
            
            static $h = 1889184;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tCiC.LCCGCS$1.CommunityGamesSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886791072),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1889184,
      "h": 12886791072,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886791072),
//--TRIMMABLE-BOUNDARY-START(17181758368),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1758112,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1889184,
      "h": 17181758368,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181758368),
//--TRIMMABLE-BOUNDARY-START(8591823776),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1758112,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1889184,
      "h": 8591823776,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591823776)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296856480),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1889184,
      "h": 4296856480,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296856480)
  ],
  "h": 1889184
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tCiC.LCCGCS$1.CommunityGamesSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Settings.CommunityGamesSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Settings${separator}CommunityGamesSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1889184)
        
        

        //--TRIMMABLE-BOUNDARY-START(2151328)
        $asm.$cls(`$tCiC.LCCGCS$2.CommunityGamesStatesTypeDescriptor`, ($self) => class CommunityGamesStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tCiC.LCCGCS$2.CommunityGamesStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4297118624)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297118624);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tCiC.LCCGCS$2.CommunityGamesStatesTypeDescriptor.GenerateProperties($.$tCiC.LCCGCS$2.CommunityGamesStates, this, factory);
                    }, $dkyjOc ??= {"r":65537,"n":"","d":2151328,"h":0,"f":17825794}), 0, "CommunityGamesStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Games.Common\\States_CommunityGamesStates_LivingThing.Core.Community.Games.Common.States.CommunityGamesStatesTypeDescriptorBuilder.g.cs", "CommunityGamesStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297118624)
            
            //--TRIMMABLE-BOUNDARY-START(12887053216)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887053216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887053216)
            
            //--TRIMMABLE-BOUNDARY-START(17182020512)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Games.Common.States.CommunityGamesStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182020512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182020512)
            
            //--TRIMMABLE-BOUNDARY-START(8592085920)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Games.Common.States.CommunityGamesStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592085920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tCiC.LCCGCS$2.CommunityGamesStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tCiC.LCCGCS$2.CommunityGamesStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCS$2.CommunityGamesStates)))
                {
                    /*var*/ let result = $.$tCiC.LCCGCS$2.CommunityGamesStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCS$2.CommunityGamesStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tCiC.LCCGCS$2.CommunityGamesStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCS$2.CommunityGamesStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592085920)
            
            static $h = 2151328;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tCiC.LCCGCS$2.CommunityGamesStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887053216),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2151328,
      "h": 12887053216,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887053216),
//--TRIMMABLE-BOUNDARY-START(17182020512),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2020256,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2151328,
      "h": 17182020512,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182020512),
//--TRIMMABLE-BOUNDARY-START(8592085920),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2020256,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2151328,
      "h": 8592085920,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592085920)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297118624),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2151328,
      "h": 4297118624,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297118624)
  ],
  "h": 2151328
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tCiC.LCCGCS$2.CommunityGamesStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.States.CommunityGamesStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}States${separator}CommunityGamesStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2151328)
        
        

        $asm.$typeProxy("$tCiC.LCCGCM.CommunityGamesPostModel", "$tCiC.LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel");
        //--TRIMMABLE-BOUNDARY-START(316320)
        $asm.$cls(`$tCiC.LCCGCM.CommunityGamesCategoryModel`, ($self) => class CommunityGamesCategoryModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$tCiC.LCCGCM.CommunityGamesPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180185504)
            /*PostTypes */ get Type()
            {
                return 8961/*PostTypes.GamesCategory*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180185504)
            
            //--TRIMMABLE-BOUNDARY-START(4295283616)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295283616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295283616)
            
            //--TRIMMABLE-BOUNDARY-START(4295283616)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295283616)
            
            static $h = 316320;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$tCiC.LCCGCM.CommunityGamesPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180185504),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885218208,
        "f": 50364417
      },
      "n": "Type",
      "d": 316320,
      "h": 17180185504,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180185504)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295283616),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 316320,
      "h": 4295283616,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295283616)
  ],
  "h": 316320
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Models.CommunityGamesCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Models${separator}CommunityGamesCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(316320)
        
        

        //--TRIMMABLE-BOUNDARY-START(840608)
        $asm.$cls(`$tCiC.LCCGCM.CommunityGamesPostModel`, ($self) => class CommunityGamesPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180709792)
            /*PostTypes */ get Type()
            {
                return 8962/*PostTypes.GamesPost*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180709792)
            
            //--TRIMMABLE-BOUNDARY-START(4295807904)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295807904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295807904)
            
            //--TRIMMABLE-BOUNDARY-START(4295807904)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295807904)
            
            static $h = 840608;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180709792),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885742496,
        "f": 50364417
      },
      "n": "Type",
      "d": 840608,
      "h": 17180709792,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180709792)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295807904),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 840608,
      "h": 4295807904,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295807904)
  ],
  "h": 840608
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Models${separator}CommunityGamesPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(840608)
        
        

        //--TRIMMABLE-BOUNDARY-START(1364896)
        $asm.$cls(`$tCiC.LCCGCS.ICommunityGamesFeedRemoteService`, ($self) => class ICommunityGamesFeedRemoteService
        {
            static $h = 1364896;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1364896,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Services.ICommunityGamesFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Services${separator}ICommunityGamesFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1364896)
        
        

        //--TRIMMABLE-BOUNDARY-START(1495968)
        $asm.$cls(`$tCiC.LCCGCS.IComunityGamesRemoteService`, ($self) => class IComunityGamesRemoteService
        {
            static $h = 1495968;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1495968,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.IReadDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Services.IComunityGamesRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Services${separator}IComunityGamesRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1495968)
        
        

        //--TRIMMABLE-BOUNDARY-START(1430432)
        $asm.$cls(`$tCiC.LCCGCS.ICommunityGamesFeedRemoteService_Mocking`, ($self) => class ICommunityGamesFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296397728)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296397728);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296397728)
            
            //--TRIMMABLE-BOUNDARY-START(8591365024)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Games$Common$Models$CommunityGamesPostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591365024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$tCiC.LCCGCM.CommunityGamesPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$tCiC.LCCGCM.CommunityGamesPostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591365024)
            
            static $h = 1430432;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296397728),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1430432,
      "h": 4296397728,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296397728)
  ],
  "h": 1430432
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$tCiC.LCCGCS.ICommunityGamesFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Services.ICommunityGamesFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Services${separator}ICommunityGamesFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1430432)
        
        

        //--TRIMMABLE-BOUNDARY-START(1561504)
        $asm.$cls(`$tCiC.LCCGCS.IComunityGamesRemoteService_Mocking`, ($self) => class IComunityGamesRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296528800)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296528800);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296528800)
            
            //--TRIMMABLE-BOUNDARY-START(8591496096)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Games$Common$Models$CommunityGamesPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591496096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$tCiC.LCCGCM.CommunityGamesPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$tCiC.LCCGCM.CommunityGamesPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591496096)
            
            //--TRIMMABLE-BOUNDARY-START(17181430688)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Games$Common$Models$CommunityGamesPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181430688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$tCiC.LCCGCM.CommunityGamesPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$tCiC.LCCGCM.CommunityGamesPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181430688)
            
            //--TRIMMABLE-BOUNDARY-START(21476397984)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Games$Common$Models$CommunityGamesPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476397984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$tCiC.LCCGCM.CommunityGamesPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$tCiC.LCCGCM.CommunityGamesPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476397984)
            
            //--TRIMMABLE-BOUNDARY-START(25771365280)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Games$Common$Models$CommunityGamesPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771365280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$tCiC.LCCGCM.CommunityGamesPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$tCiC.LCCGCM.CommunityGamesPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771365280)
            
            //--TRIMMABLE-BOUNDARY-START(12886463392)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886463392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$tCiC.LCCGCM.CommunityGamesPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886463392)
            
            static $h = 1561504;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296528800),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1561504,
      "h": 4296528800,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296528800)
  ],
  "h": 1561504
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$tCiC.LCCGCS.IComunityGamesRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.IReadDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Services.IComunityGamesRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Services${separator}IComunityGamesRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1561504)
        
        

        //--TRIMMABLE-BOUNDARY-START(447392)
        $asm.$cls(`$tCiC.LCCGCM.CommunityGamesCategoryModelTypeDescriptor`, ($self) => class CommunityGamesCategoryModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295414688)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295414688);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tCiC.LCCGCM.CommunityGamesCategoryModelTypeDescriptor.GenerateProperties($.$tCiC.LCCGCM.CommunityGamesCategoryModel, this, factory);
                    }, $xxXtWd ??= {"r":65537,"n":"","d":447392,"h":0,"f":17825794}), 0, "CommunityGamesCategoryModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Games.Common\\Models_CommunityGamesCategoryModel_LivingThing.Core.Community.Games.Common.Models.CommunityGamesCategoryModelTypeDescriptorBuilder.g.cs", "CommunityGamesCategoryModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295414688)
            
            //--TRIMMABLE-BOUNDARY-START(12885349280)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885349280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$tCiC.LCCGCM.CommunityGamesCategoryModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Games.Common.Models.CommunityGamesCategoryModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tCiC.LCCGCM.CommunityGamesCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$tCiC.LCCGCM.CommunityGamesCategoryModel)).Type);
                        }, $QsbGgb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":447392,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$tCiC.LCCGCM.CommunityGamesPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885349280)
            
            //--TRIMMABLE-BOUNDARY-START(17180316576)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Games.Common.Models.CommunityGamesCategoryModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180316576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.Games.Common.Models.CommunityGamesCategoryModel, LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$tCiC.LCCGCM.CommunityGamesPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$tCiC.LCCGCM.CommunityGamesPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180316576)
            
            //--TRIMMABLE-BOUNDARY-START(8590381984)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Games.Common.Models.CommunityGamesCategoryModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590381984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tCiC.LCCGCM.CommunityGamesCategoryModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tCiC.LCCGCM.CommunityGamesCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCM.CommunityGamesCategoryModel)))
                {
                    /*var*/ let result = $.$tCiC.LCCGCM.CommunityGamesCategoryModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCM.CommunityGamesCategoryModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tCiC.LCCGCM.CommunityGamesCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCM.CommunityGamesCategoryModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590381984)
            
            static $h = 447392;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885349280),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 447392,
      "h": 12885349280,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885349280),
//--TRIMMABLE-BOUNDARY-START(17180316576),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 316320,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 447392,
      "h": 17180316576,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180316576),
//--TRIMMABLE-BOUNDARY-START(8590381984),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 316320,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 447392,
      "h": 8590381984,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590381984)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295414688),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 447392,
      "h": 4295414688,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295414688)
  ],
  "h": 447392
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Models.CommunityGamesCategoryModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Models${separator}CommunityGamesCategoryModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(447392)
        
        

        //--TRIMMABLE-BOUNDARY-START(971680)
        $asm.$cls(`$tCiC.LCCGCM.CommunityGamesPostModelTypeDescriptor`, ($self) => class CommunityGamesPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tCiC.LCCGCM.CommunityGamesPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295938976)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295938976);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tCiC.LCCGCM.CommunityGamesPostModelTypeDescriptor.GenerateProperties($.$tCiC.LCCGCM.CommunityGamesPostModel, this, factory);
                    }, $rLSouh ??= {"r":65537,"n":"","d":971680,"h":0,"f":17825794}), 0, "CommunityGamesPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Games.Common\\Models_CommunityGamesPostModel_LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModelTypeDescriptorBuilder.g.cs", "CommunityGamesPostModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295938976)
            
            //--TRIMMABLE-BOUNDARY-START(12885873568)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885873568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$tCiC.LCCGCM.CommunityGamesPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tCiC.LCCGCM.CommunityGamesPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$tCiC.LCCGCM.CommunityGamesPostModel)).Type);
                        }, $XcqMEe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":971680,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885873568)
            
            //--TRIMMABLE-BOUNDARY-START(17180840864)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180840864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.Games.Common.Models.CommunityGamesCategoryModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$tCiC.LCCGCM.CommunityGamesCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180840864)
            
            //--TRIMMABLE-BOUNDARY-START(8590906272)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590906272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tCiC.LCCGCM.CommunityGamesPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tCiC.LCCGCM.CommunityGamesPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCM.CommunityGamesPostModel)))
                {
                    /*var*/ let result = $.$tCiC.LCCGCM.CommunityGamesPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCM.CommunityGamesPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tCiC.LCCGCM.CommunityGamesPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCM.CommunityGamesPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590906272)
            
            static $h = 971680;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tCiC.LCCGCM.CommunityGamesPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885873568),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 971680,
      "h": 12885873568,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885873568),
//--TRIMMABLE-BOUNDARY-START(17180840864),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 840608,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 971680,
      "h": 17180840864,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180840864),
//--TRIMMABLE-BOUNDARY-START(8590906272),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 840608,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 971680,
      "h": 8590906272,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590906272)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295938976),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 971680,
      "h": 4295938976,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295938976)
  ],
  "h": 971680
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tCiC.LCCGCM.CommunityGamesPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Models.CommunityGamesPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Models${separator}CommunityGamesPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(971680)
        
        

        //--TRIMMABLE-BOUNDARY-START(578464)
        $asm.$cls(`$tCiC.LCCGCM.CommunityGamesModel`, ($self) => class CommunityGamesModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$tCiC.LCCGCS$1.CommunityGamesSettings, $.$tCiC.LCCGCS$2.CommunityGamesStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295545760)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295545760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295545760)
            
            //--TRIMMABLE-BOUNDARY-START(4295545760)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295545760)
            
            static $h = 578464;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$tCiC.LCCGCS$1.CommunityGamesSettings, $.$tCiC.LCCGCS$2.CommunityGamesStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295545760),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 578464,
      "h": 4295545760,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295545760)
  ],
  "h": 578464
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Models.CommunityGamesModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Models${separator}CommunityGamesModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(578464)
        
        

        //--TRIMMABLE-BOUNDARY-START(709536)
        $asm.$cls(`$tCiC.LCCGCM.CommunityGamesModelTypeDescriptor`, ($self) => class CommunityGamesModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tCiC.LCCGCM.CommunityGamesModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295676832)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295676832);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tCiC.LCCGCM.CommunityGamesModelTypeDescriptor.GenerateProperties($.$tCiC.LCCGCM.CommunityGamesModel, this, factory);
                    }, $vPyiLe ??= {"r":65537,"n":"","d":709536,"h":0,"f":17825794}), 0, "CommunityGamesModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Games.Common\\Models_CommunityGamesModel_LivingThing.Core.Community.Games.Common.Models.CommunityGamesModelTypeDescriptorBuilder.g.cs", "CommunityGamesModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295676832)
            
            //--TRIMMABLE-BOUNDARY-START(12885611424)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885611424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$tCiC.LCCGCS$1.CommunityGamesSettings, $.$tCiC.LCCGCS$2.CommunityGamesStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885611424)
            
            //--TRIMMABLE-BOUNDARY-START(17180578720)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Games.Common.Models.CommunityGamesModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180578720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Games.Common.Settings.CommunityGamesSettings, LivingThing.Core.Community.Games.Common.States.CommunityGamesStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$tCiC.LCCGCS$1.CommunityGamesSettings, $.$tCiC.LCCGCS$2.CommunityGamesStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$tCiC.LCCGCS$1.CommunityGamesSettings, $.$tCiC.LCCGCS$2.CommunityGamesStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180578720)
            
            //--TRIMMABLE-BOUNDARY-START(8590644128)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Games.Common.Models.CommunityGamesModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590644128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tCiC.LCCGCM.CommunityGamesModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tCiC.LCCGCM.CommunityGamesModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCM.CommunityGamesModel)))
                {
                    /*var*/ let result = $.$tCiC.LCCGCM.CommunityGamesModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCM.CommunityGamesModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tCiC.LCCGCM.CommunityGamesModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tCiC.LCCGCM.CommunityGamesModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590644128)
            
            static $h = 709536;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tCiC.LCCGCM.CommunityGamesModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885611424),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 709536,
      "h": 12885611424,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885611424),
//--TRIMMABLE-BOUNDARY-START(17180578720),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 578464,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 709536,
      "h": 17180578720,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180578720),
//--TRIMMABLE-BOUNDARY-START(8590644128),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 578464,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 709536,
      "h": 8590644128,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590644128)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295676832),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 709536,
      "h": 4295676832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295676832)
  ],
  "h": 709536
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tCiC.LCCGCM.CommunityGamesModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Games.Common.Models.CommunityGamesModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Games${separator}Common${separator}Models${separator}CommunityGamesModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(709536)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(54176)
