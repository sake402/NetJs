
//--TRIMMABLE-BOUNDARY-START(49768)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $XtuU) {
    "use strict";
    let _;
    let $BhHMIf;
    let $lotrma;
    let $wnPhKc;
    let $sCdvGe;
    let $mxtAzg;
    let $hPrglg;
    let $RWwGjd;
    let $cfFUYe;
    let $iPIhqf;
    let $gGhSya;
    let $JPLFxf;
    let $iGIHfe;
    let $RpWthb;
    let $WUuBLd;
    let $Ywamni;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Gift.Client.Blazor", 
    {
  "h": 49768,
  "f": "LivingThing.Core.Community.Gift.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Gift.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Gift.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(180840)
        $asm.$cls(`$wmbl.LCCGC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295148136)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295148136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$wmbl.LCCGC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295148136)
            
            static $h = 180840;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295148136),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 180840,
      "h": 4295148136,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295148136)
  ],
  "h": 180840
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(180840)
        
        

        //--TRIMMABLE-BOUNDARY-START(246376)
        $asm.$cls(`$wmbl.LCCGC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180115560)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$wmbl.LCCGCP.CommunityGiftApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$wmbl.LCCGCP.CommunityGiftApp().$ctor$3();
                    }, $BhHMIf ??= {"r":2752627,"n":"","d":246376,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180115560)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295213672)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295213672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295213672)
            
            //--TRIMMABLE-BOUNDARY-START(4295213672)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295213672)
            
            static $h = 246376;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180115560),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885148264,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 246376,
      "h": 17180115560,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180115560)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295213672),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 246376,
      "h": 4295213672,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295213672)
  ],
  "h": 246376
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(246376)
        
        

        //--TRIMMABLE-BOUNDARY-START(377448)
        $asm.$cls(`$wmbl.LCCGC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590312040)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590312040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$wmbl.LCCGCS.CommunityGiftService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$XtuU.LCCGCM.CommunityGiftPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$wmbl.LCCGCS.CommunityGiftApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$wmbl.LCCGCS.CommunityGiftApplication, x);
                }, $lotrma ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":377448,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$wmbl.LCCGCS.CommunityGiftApplication, x);
                }, $wnPhKc ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":377448,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$XtuU.LCCGCM.CommunityGiftPostModel, services, null);
                $.$wmbl.LCCGC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590312040)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wmbl.LCCGC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295344744)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295344744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295344744)
            
            //--TRIMMABLE-BOUNDARY-START(4295344744)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295344744)
            
            static $h = 377448;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590312040),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 377448,
      "h": 8590312040,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590312040)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295344744),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 377448,
      "h": 4295344744,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295344744)
  ],
  "h": 377448
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(377448)
        
        

        //--TRIMMABLE-BOUNDARY-START(574056)
        $asm.$cls(`$wmbl.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295541352)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295541352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295541352)
            
            //--TRIMMABLE-BOUNDARY-START(4295541352)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295541352)
            
            static $h = 574056;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295541352),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 574056,
      "h": 4295541352,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295541352)
  ],
  "h": 574056
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(574056)
        
        

        //--TRIMMABLE-BOUNDARY-START(639592)
        $asm.$cls(`$wmbl.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295606888)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295606888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295606888)
            
            //--TRIMMABLE-BOUNDARY-START(4295606888)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295606888)
            
            static $h = 639592;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295606888),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 639592,
      "h": 4295606888,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295606888)
  ],
  "h": 639592,
  "a": [
    {
      "t": 574056,
      "c": 4295541352
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(639592)
        
        

        //--TRIMMABLE-BOUNDARY-START(115304)
        $asm.$cls(`$wmbl.LCCGC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590049896)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590049896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590049896)
            
            //--TRIMMABLE-BOUNDARY-START(4295082600)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295082600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295082600)
            
            //--TRIMMABLE-BOUNDARY-START(4295082600)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295082600)
            
            static $h = 115304;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590049896),
    {
      "r": 65537,
      "n": "Execute",
      "d": 115304,
      "h": 8590049896,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590049896)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295082600),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 115304,
      "h": 4295082600,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295082600)
  ],
  "h": 115304
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(115304)
        
        

        //--TRIMMABLE-BOUNDARY-START(311912)
        $asm.$cls(`$wmbl.LCCGCP.CommunityGiftApp`, ($self) => class CommunityGiftApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(60129854056)
            /*CommunityGiftService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(60129854056)
            
            //--TRIMMABLE-BOUNDARY-START(21475148392)
            /*CommunityGiftApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(21475148392)
            
            //--TRIMMABLE-BOUNDARY-START(55834886760)
            /*IUIRenderingProvider*/ Rendering = null;
            //--TRIMMABLE-BOUNDARY-END(55834886760)
            
            //--TRIMMABLE-BOUNDARY-START(25770115688)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770115688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "InitialViewIndex", "0");
                __builder.AddComponentParameter(2, "Name", "Gift");
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(5, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 6);
                        __builder2.AddComponentParameter(7, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                        __builder2.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(9, wrap.View);
                        }), $sCdvGe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":311912,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $mxtAzg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":311912,"h":0,"f":17825794});
                }), $hPrglg ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":311912,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/*splash*/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 11);
                        __builder2.AddComponentParameter(12, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, splash.ViewModel));
                        __builder2.AddComponentParameter(13, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, splash.Message));
                        __builder2.CloseComponent();
                    }, $RWwGjd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":311912,"h":0,"f":17825794});
                }), $cfFUYe ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":311912,"h":0,"f":17825794}));
                __builder.AddAttribute$3(14, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 15);
                    __builder2.AddComponentParameter(16, "Name", "");
                    __builder2.AddComponentParameter(17, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddAttribute$3(18, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(19, "Gift");
                        }, $iPIhqf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":311912,"h":0,"f":17825794});
                    }), $gGhSya ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":311912,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(20, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(21, "<i class=\"mdi mdi-book\"></i>");
                        }, $JPLFxf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":311912,"h":0,"f":17825794});
                    }), $iGIHfe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":311912,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(22, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityApplicationUnderDevelopment, 23);
                            __builder3.AddComponentParameter(24, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCS.ICommunityClientApplication, this.Application));
                            __builder3.CloseComponent();
                        }, $RpWthb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":311912,"h":0,"f":17825794});
                    }), $WUuBLd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":311912,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $Ywamni ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":311912,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25770115688)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180181096)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180181096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180181096)
            
            //--TRIMMABLE-BOUNDARY-START(17180181096)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17180181096)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60129854056)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(60129854056)
                
                //--TRIMMABLE-BOUNDARY-START(21475148392)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(21475148392)
                
                //--TRIMMABLE-BOUNDARY-START(55834886760)
                this.Rendering = null;
                //--TRIMMABLE-BOUNDARY-END(55834886760)
                
            }
            static $h = 311912;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129854056),
    {
      "p": 508520,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539919464,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899657832,
        "f": 83886081
      },
      "n": "Service",
      "d": 311912,
      "h": 60129854056,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60129854056),
//--TRIMMABLE-BOUNDARY-START(21475148392),
    {
      "p": 442984,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360050280,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719788648,
        "f": 83886081
      },
      "n": "Application",
      "d": 311912,
      "h": 21475148392,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475148392),
//--TRIMMABLE-BOUNDARY-START(55834886760),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949984872,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309723240,
        "f": 83886081
      },
      "n": "Rendering",
      "d": 311912,
      "h": 55834886760,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834886760)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770115688),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 311912,
      "h": 25770115688,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770115688)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180181096),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 311912,
      "h": 17180181096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180181096)
  ],
  "h": 311912
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Client.Pages.CommunityGiftApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Client${separator}Pages${separator}CommunityGiftApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(311912)
        
        

        //--TRIMMABLE-BOUNDARY-START(442984)
        $asm.$cls(`$wmbl.LCCGCS.CommunityGiftApplication`, ($self) => class CommunityGiftApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885344872)
            $ctor$5(/*CommunityGiftService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885344872);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885344872)
            
            //--TRIMMABLE-BOUNDARY-START(137439396456)
            /*string */ get Name()
            {
                return "Gift";
            }
            //--TRIMMABLE-BOUNDARY-END(137439396456)
            
            //--TRIMMABLE-BOUNDARY-START(154619265640)
            /*string */ get Title()
            {
                return "Gift";
            }
            //--TRIMMABLE-BOUNDARY-END(154619265640)
            
            //--TRIMMABLE-BOUNDARY-START(21475279464)
            /*string */ get Description()
            {
                return "Gift your loved ones.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475279464)
            
            //--TRIMMABLE-BOUNDARY-START(133144429160)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-gift"/*MaterialDesignIconNames.Gift*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144429160)
            
            //--TRIMMABLE-BOUNDARY-START(150324298344)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2E962B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(150324298344)
            
            //--TRIMMABLE-BOUNDARY-START(30065214056)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065214056)
            
            //--TRIMMABLE-BOUNDARY-START(17180312168)
            /*Type? */ get ApplicationViewType()
            {
                return $.$wmbl.LCCGCP.CommunityGiftApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180312168)
            
            //--TRIMMABLE-BOUNDARY-START(128849461864)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849461864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$wmbl.LCCGCP.CommunityGiftApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849461864)
            
            //--TRIMMABLE-BOUNDARY-START(25770246760)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770246760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770246760)
            
            //--TRIMMABLE-BOUNDARY-START(141734363752)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734363752)
            
            //--TRIMMABLE-BOUNDARY-START(4295410280)
            /*CommunityGiftService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295410280)
            
            //--TRIMMABLE-BOUNDARY-START(146029331048)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(146029331048)
            
            //--TRIMMABLE-BOUNDARY-START(158914232936)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(4864/*PostTypes.Gift*/, 4865/*PostTypes.GiftEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(158914232936)
            
            static $h = 442984;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439396456),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604821608,
        "f": 50364417
      },
      "n": "Name",
      "d": 442984,
      "h": 137439396456,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439396456),
//--TRIMMABLE-BOUNDARY-START(154619265640),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964559976,
        "f": 50364417
      },
      "n": "Title",
      "d": 442984,
      "h": 154619265640,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619265640),
//--TRIMMABLE-BOUNDARY-START(21475279464),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835017832,
        "f": 50364417
      },
      "n": "Description",
      "d": 442984,
      "h": 21475279464,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475279464),
//--TRIMMABLE-BOUNDARY-START(133144429160),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014887016,
        "f": 50364417
      },
      "n": "Icon",
      "d": 442984,
      "h": 133144429160,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144429160),
//--TRIMMABLE-BOUNDARY-START(150324298344),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374625384,
        "f": 50364417
      },
      "n": "Theme",
      "d": 442984,
      "h": 150324298344,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324298344),
//--TRIMMABLE-BOUNDARY-START(30065214056),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424952424,
        "f": 50364417
      },
      "n": "Features",
      "d": 442984,
      "h": 30065214056,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065214056),
//--TRIMMABLE-BOUNDARY-START(17180312168),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245083240,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 442984,
      "h": 17180312168,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180312168),
//--TRIMMABLE-BOUNDARY-START(141734363752),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194756200,
        "f": 50364417
      },
      "n": "Order",
      "d": 442984,
      "h": 141734363752,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734363752),
//--TRIMMABLE-BOUNDARY-START(4295410280),
    {
      "p": 508520,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655148648,
        "f": 50331650
      },
      "n": "_Service",
      "d": 442984,
      "h": 4295410280,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295410280),
//--TRIMMABLE-BOUNDARY-START(146029331048),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784690792,
        "f": 50364417
      },
      "n": "Service",
      "d": 442984,
      "h": 146029331048,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029331048),
//--TRIMMABLE-BOUNDARY-START(158914232936),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554494568,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 442984,
      "h": 158914232936,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914232936)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849461864),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 442984,
      "h": 128849461864,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849461864),
//--TRIMMABLE-BOUNDARY-START(25770246760),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 442984,
      "h": 25770246760,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770246760)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885344872),
    {
      "p": [
        {
          "n": "service",
          "p": 508520
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 442984,
      "h": 12885344872,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885344872)
  ],
  "h": 442984
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Client.Services.CommunityGiftApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Client${separator}Services${separator}CommunityGiftApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(442984)
        
        

        //--TRIMMABLE-BOUNDARY-START(508520)
        $asm.$cls(`$wmbl.LCCGCS.CommunityGiftService`, ($self) => class CommunityGiftService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$XtuU.LCCGCM.CommunityGiftPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295475816)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295475816);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295475816)
            
            static $h = 508520;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$XtuU.LCCGCM.CommunityGiftPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295475816),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 508520,
      "h": 4295475816,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295475816)
  ],
  "h": 508520
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$XtuU.LCCGCM.CommunityGiftPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$XtuU.LCCGCM.CommunityGiftPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Client.Services.CommunityGiftService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Client${separator}Services${separator}CommunityGiftService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(508520)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Gift.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(49768)
