
//--TRIMMABLE-BOUNDARY-START(31298)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $KKFNHf;
    let $sphkka;
    let $EVTTZj;
    let $OdMxMk;
    let $jlvKyk;
    let $ckofhl;
    let $qKnDuk;
    let $EfWrqa;
    let $SciYvh;
    let $JEgsDj;
    let $IxGfxh;
    let $DzGeZh;
    let $uOiaYf;
    let $eaJAzd;
    let $opiOwc;
    let $sXGnfd;
    let $vMGELc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Gift.Common", 
    {
  "h": 31298,
  "f": "LivingThing.Core.Community.Gift.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Gift.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Gift.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(293442)
        $asm.$cls(`$XtuU.LCCGCM.CommunityGiftModelCustomAttributesProvider`, ($self) => class CommunityGiftModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295260738)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295260738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$XtuU.LCCGCS$1.CommunityGiftSettings, $.$XtuU.LCCGCS$2.CommunityGiftStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295260738)
            
            static $h = 293442;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295260738),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 293442,
      "h": 4295260738,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295260738)
  ],
  "h": 293442
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Models.CommunityGiftModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Models${separator}CommunityGiftModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(293442)
        
        

        //--TRIMMABLE-BOUNDARY-START(1014338)
        $asm.$cls(`$XtuU.LCCGCS$1.CommunityGiftSettingsCustomAttributesProvider`, ($self) => class CommunityGiftSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295981634)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295981634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295981634)
            
            static $h = 1014338;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295981634),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1014338,
      "h": 4295981634,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295981634)
  ],
  "h": 1014338
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Settings.CommunityGiftSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Settings${separator}CommunityGiftSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1014338)
        
        

        //--TRIMMABLE-BOUNDARY-START(555586)
        $asm.$cls(`$XtuU.LCCGCM.CommunityGiftPostModelCustomAttributesProvider`, ($self) => class CommunityGiftPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295522882)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295522882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295522882)
            
            static $h = 555586;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295522882),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 555586,
      "h": 4295522882,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295522882)
  ],
  "h": 555586
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Models${separator}CommunityGiftPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(555586)
        
        

        //--TRIMMABLE-BOUNDARY-START(1276482)
        $asm.$cls(`$XtuU.LCCGCS$2.CommunityGiftStatesCustomAttributesProvider`, ($self) => class CommunityGiftStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296243778)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296243778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296243778)
            
            static $h = 1276482;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296243778),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1276482,
      "h": 4296243778,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296243778)
  ],
  "h": 1276482
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.States.CommunityGiftStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}States${separator}CommunityGiftStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1276482)
        
        

        //--TRIMMABLE-BOUNDARY-START(96834)
        $asm.$cls(`$XtuU.LCCGC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295064130)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295064130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$XtuU.LCCGCM.CommunityGiftModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$XtuU.LCCGCM.CommunityGiftModelCustomAttributesProvider, $.$XtuU.LCCGCM.CommunityGiftModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$XtuU.LCCGCM.CommunityGiftPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$XtuU.LCCGCM.CommunityGiftPostModelCustomAttributesProvider, $.$XtuU.LCCGCM.CommunityGiftPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$XtuU.LCCGCS$1.CommunityGiftSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$XtuU.LCCGCS$1.CommunityGiftSettingsCustomAttributesProvider, $.$XtuU.LCCGCS$1.CommunityGiftSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$XtuU.LCCGCS$2.CommunityGiftStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$XtuU.LCCGCS$2.CommunityGiftStatesCustomAttributesProvider, $.$XtuU.LCCGCS$2.CommunityGiftStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295064130)
            
            static $h = 96834;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295064130),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 96834,
      "h": 4295064130,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295064130)
  ],
  "h": 96834
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(96834)
        
        

        //--TRIMMABLE-BOUNDARY-START(1473090)
        $asm.$cls(`$XtuU.LCCGC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296440386)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296440386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XtuU.LCCGCM.CommunityGiftModelTypeDescriptorBuilder.Register();
                $.$XtuU.LCCGCM.CommunityGiftPostModelTypeDescriptorBuilder.Register();
                $.$XtuU.LCCGCS$1.CommunityGiftSettingsTypeDescriptorBuilder.Register();
                $.$XtuU.LCCGCS$2.CommunityGiftStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296440386)
            
            static $h = 1473090;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296440386),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1473090,
      "h": 4296440386,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296440386)
  ],
  "h": 1473090
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1473090)
        
        

        //--TRIMMABLE-BOUNDARY-START(162370)
        $asm.$cls(`$XtuU.LCCGC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295129666)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295129666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$XtuU.LCCGCS.IComunityGiftRemoteService, $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking().$ctor$3(impl);
                }, $KKFNHf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":162370,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking().$ctor$3(impl);
                }, $sphkka ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":162370,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking().$ctor$3(impl);
                }, $EVTTZj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":162370,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking().$ctor$3(impl);
                }, $OdMxMk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":162370,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking().$ctor$3(impl);
                }, $jlvKyk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":162370,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking().$ctor$3(impl);
                }, $ckofhl ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":162370,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking().$ctor$3(impl);
                }, $qKnDuk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":162370,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking().$ctor$3(impl);
                }, $EfWrqa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":162370,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295129666)
            
            static $h = 162370;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295129666),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 162370,
      "h": 4295129666,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295129666)
  ],
  "h": 162370
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(162370)
        
        

        //--TRIMMABLE-BOUNDARY-START(1145410)
        $asm.$cls(`$XtuU.LCCGCS$1.CommunityGiftSettingsTypeDescriptorBuilder`, ($self) => class CommunityGiftSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591080002)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591080002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$XtuU.LCCGCS$1.CommunityGiftSettingsTypeDescriptor()
                        const $t1 = $.$XtuU.LCCGCS$1.CommunityGiftSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Gift.Common.Settings.CommunityGiftSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $SciYvh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1145410,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$XtuU.LCCGCS$1.CommunityGiftSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591080002)
            
            //--TRIMMABLE-BOUNDARY-START(4296112706)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296112706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296112706)
            
            //--TRIMMABLE-BOUNDARY-START(4296112706)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296112706)
            
            static $h = 1145410;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591080002),
    {
      "r": 65537,
      "n": "Register",
      "d": 1145410,
      "h": 8591080002,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591080002)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296112706),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1145410,
      "h": 4296112706,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296112706)
  ],
  "h": 1145410
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Settings.CommunityGiftSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Settings${separator}CommunityGiftSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1145410)
        
        

        //--TRIMMABLE-BOUNDARY-START(1407554)
        $asm.$cls(`$XtuU.LCCGCS$2.CommunityGiftStatesTypeDescriptorBuilder`, ($self) => class CommunityGiftStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591342146)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591342146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$XtuU.LCCGCS$2.CommunityGiftStatesTypeDescriptor()
                        const $t1 = $.$XtuU.LCCGCS$2.CommunityGiftStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Gift.Common.States.CommunityGiftStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $IxGfxh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1407554,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$XtuU.LCCGCS$2.CommunityGiftStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591342146)
            
            //--TRIMMABLE-BOUNDARY-START(4296374850)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296374850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296374850)
            
            //--TRIMMABLE-BOUNDARY-START(4296374850)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296374850)
            
            static $h = 1407554;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591342146),
    {
      "r": 65537,
      "n": "Register",
      "d": 1407554,
      "h": 8591342146,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591342146)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296374850),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1407554,
      "h": 4296374850,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296374850)
  ],
  "h": 1407554
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.States.CommunityGiftStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}States${separator}CommunityGiftStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1407554)
        
        

        //--TRIMMABLE-BOUNDARY-START(424514)
        $asm.$cls(`$XtuU.LCCGCM.CommunityGiftModelTypeDescriptorBuilder`, ($self) => class CommunityGiftModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590359106)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590359106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$XtuU.LCCGCM.CommunityGiftModelTypeDescriptor()
                        const $t1 = $.$XtuU.LCCGCM.CommunityGiftModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Gift.Common.Models.CommunityGiftModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $uOiaYf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":424514,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$XtuU.LCCGCM.CommunityGiftModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590359106)
            
            //--TRIMMABLE-BOUNDARY-START(4295391810)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295391810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295391810)
            
            //--TRIMMABLE-BOUNDARY-START(4295391810)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295391810)
            
            static $h = 424514;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590359106),
    {
      "r": 65537,
      "n": "Register",
      "d": 424514,
      "h": 8590359106,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590359106)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295391810),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 424514,
      "h": 4295391810,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295391810)
  ],
  "h": 424514
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Models.CommunityGiftModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Models${separator}CommunityGiftModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(424514)
        
        

        //--TRIMMABLE-BOUNDARY-START(686658)
        $asm.$cls(`$XtuU.LCCGCM.CommunityGiftPostModelTypeDescriptorBuilder`, ($self) => class CommunityGiftPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590621250)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590621250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$XtuU.LCCGCM.CommunityGiftPostModelTypeDescriptor()
                        const $t1 = $.$XtuU.LCCGCM.CommunityGiftPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $opiOwc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":686658,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$XtuU.LCCGCM.CommunityGiftPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590621250)
            
            //--TRIMMABLE-BOUNDARY-START(4295653954)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295653954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295653954)
            
            //--TRIMMABLE-BOUNDARY-START(4295653954)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295653954)
            
            static $h = 686658;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590621250),
    {
      "r": 65537,
      "n": "Register",
      "d": 686658,
      "h": 8590621250,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590621250)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295653954),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 686658,
      "h": 4295653954,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295653954)
  ],
  "h": 686658
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Models${separator}CommunityGiftPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(686658)
        
        

        //--TRIMMABLE-BOUNDARY-START(752194)
        $asm.$cls(`$XtuU.LCCGC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590686786)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590686786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$XtuU.LCCGCM.CommunityGiftPostModel, 4864/*PostTypes.Gift*/);
                $.$XtuU.LCCGC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$XtuU.LCCGC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$XtuU.LCCGC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590686786)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XtuU.LCCGC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295719490)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295719490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295719490)
            
            //--TRIMMABLE-BOUNDARY-START(4295719490)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295719490)
            
            static $h = 752194;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590686786),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 752194,
      "h": 8590686786,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590686786)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295719490),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 752194,
      "h": 4295719490,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295719490)
  ],
  "h": 752194
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(752194)
        
        

        //--TRIMMABLE-BOUNDARY-START(948802)
        $asm.$cls(`$XtuU.LCCGCS$1.CommunityGiftSettings`, ($self) => class CommunityGiftSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4295916098)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295916098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295916098)
            
            //--TRIMMABLE-BOUNDARY-START(4295916098)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295916098)
            
            static $h = 948802;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295916098),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 948802,
      "h": 4295916098,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295916098)
  ],
  "h": 948802
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Settings.CommunityGiftSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Settings${separator}CommunityGiftSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(948802)
        
        

        //--TRIMMABLE-BOUNDARY-START(1210946)
        $asm.$cls(`$XtuU.LCCGCS$2.CommunityGiftStates`, ($self) => class CommunityGiftStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296178242)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296178242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296178242)
            
            //--TRIMMABLE-BOUNDARY-START(4296178242)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296178242)
            
            static $h = 1210946;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296178242),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1210946,
      "h": 4296178242,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296178242)
  ],
  "h": 1210946
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.States.CommunityGiftStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}States${separator}CommunityGiftStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1210946)
        
        

        //--TRIMMABLE-BOUNDARY-START(1079874)
        $asm.$cls(`$XtuU.LCCGCS$1.CommunityGiftSettingsTypeDescriptor`, ($self) => class CommunityGiftSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XtuU.LCCGCS$1.CommunityGiftSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296047170)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296047170);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$XtuU.LCCGCS$1.CommunityGiftSettingsTypeDescriptor.GenerateProperties($.$XtuU.LCCGCS$1.CommunityGiftSettings, this, factory);
                    }, $JEgsDj ??= {"r":65537,"n":"","d":1079874,"h":0,"f":17825794}), 0, "CommunityGiftSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Gift.Common\\Settings_CommunityGiftSettings_LivingThing.Core.Community.Gift.Common.Settings.CommunityGiftSettingsTypeDescriptorBuilder.g.cs", "CommunityGiftSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296047170)
            
            //--TRIMMABLE-BOUNDARY-START(12885981762)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885981762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885981762)
            
            //--TRIMMABLE-BOUNDARY-START(17180949058)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Gift.Common.Settings.CommunityGiftSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180949058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180949058)
            
            //--TRIMMABLE-BOUNDARY-START(8591014466)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Gift.Common.Settings.CommunityGiftSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591014466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$XtuU.LCCGCS$1.CommunityGiftSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$XtuU.LCCGCS$1.CommunityGiftSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$XtuU.LCCGCS$1.CommunityGiftSettings)))
                {
                    /*var*/ let result = $.$XtuU.LCCGCS$1.CommunityGiftSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$XtuU.LCCGCS$1.CommunityGiftSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$XtuU.LCCGCS$1.CommunityGiftSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$XtuU.LCCGCS$1.CommunityGiftSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591014466)
            
            static $h = 1079874;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XtuU.LCCGCS$1.CommunityGiftSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885981762),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1079874,
      "h": 12885981762,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885981762),
//--TRIMMABLE-BOUNDARY-START(17180949058),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 948802,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1079874,
      "h": 17180949058,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180949058),
//--TRIMMABLE-BOUNDARY-START(8591014466),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 948802,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1079874,
      "h": 8591014466,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591014466)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296047170),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1079874,
      "h": 4296047170,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296047170)
  ],
  "h": 1079874
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$XtuU.LCCGCS$1.CommunityGiftSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Settings.CommunityGiftSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Settings${separator}CommunityGiftSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1079874)
        
        

        //--TRIMMABLE-BOUNDARY-START(1342018)
        $asm.$cls(`$XtuU.LCCGCS$2.CommunityGiftStatesTypeDescriptor`, ($self) => class CommunityGiftStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XtuU.LCCGCS$2.CommunityGiftStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296309314)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296309314);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$XtuU.LCCGCS$2.CommunityGiftStatesTypeDescriptor.GenerateProperties($.$XtuU.LCCGCS$2.CommunityGiftStates, this, factory);
                    }, $DzGeZh ??= {"r":65537,"n":"","d":1342018,"h":0,"f":17825794}), 0, "CommunityGiftStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Gift.Common\\States_CommunityGiftStates_LivingThing.Core.Community.Gift.Common.States.CommunityGiftStatesTypeDescriptorBuilder.g.cs", "CommunityGiftStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296309314)
            
            //--TRIMMABLE-BOUNDARY-START(12886243906)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886243906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886243906)
            
            //--TRIMMABLE-BOUNDARY-START(17181211202)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Gift.Common.States.CommunityGiftStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181211202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181211202)
            
            //--TRIMMABLE-BOUNDARY-START(8591276610)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Gift.Common.States.CommunityGiftStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591276610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$XtuU.LCCGCS$2.CommunityGiftStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$XtuU.LCCGCS$2.CommunityGiftStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$XtuU.LCCGCS$2.CommunityGiftStates)))
                {
                    /*var*/ let result = $.$XtuU.LCCGCS$2.CommunityGiftStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$XtuU.LCCGCS$2.CommunityGiftStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$XtuU.LCCGCS$2.CommunityGiftStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$XtuU.LCCGCS$2.CommunityGiftStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591276610)
            
            static $h = 1342018;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XtuU.LCCGCS$2.CommunityGiftStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886243906),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1342018,
      "h": 12886243906,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886243906),
//--TRIMMABLE-BOUNDARY-START(17181211202),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1210946,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1342018,
      "h": 17181211202,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181211202),
//--TRIMMABLE-BOUNDARY-START(8591276610),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1210946,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1342018,
      "h": 8591276610,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591276610)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296309314),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1342018,
      "h": 4296309314,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296309314)
  ],
  "h": 1342018
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$XtuU.LCCGCS$2.CommunityGiftStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.States.CommunityGiftStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}States${separator}CommunityGiftStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1342018)
        
        

        //--TRIMMABLE-BOUNDARY-START(490050)
        $asm.$cls(`$XtuU.LCCGCM.CommunityGiftPostModel`, ($self) => class CommunityGiftPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180359234)
            /*PostTypes */ get Type()
            {
                return 4864/*PostTypes.Gift*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180359234)
            
            //--TRIMMABLE-BOUNDARY-START(4295457346)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295457346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295457346)
            
            //--TRIMMABLE-BOUNDARY-START(4295457346)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295457346)
            
            static $h = 490050;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180359234),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885391938,
        "f": 50364417
      },
      "n": "Type",
      "d": 490050,
      "h": 17180359234,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180359234)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295457346),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 490050,
      "h": 4295457346,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295457346)
  ],
  "h": 490050
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Models${separator}CommunityGiftPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(490050)
        
        

        //--TRIMMABLE-BOUNDARY-START(817730)
        $asm.$cls(`$XtuU.LCCGCS.IComunityGiftRemoteService`, ($self) => class IComunityGiftRemoteService
        {
            static $h = 817730;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 817730,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.IReadDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Services.IComunityGiftRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Services${separator}IComunityGiftRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(817730)
        
        

        //--TRIMMABLE-BOUNDARY-START(883266)
        $asm.$cls(`$XtuU.LCCGCS.IComunityGiftRemoteService_Mocking`, ($self) => class IComunityGiftRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295850562)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295850562);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295850562)
            
            //--TRIMMABLE-BOUNDARY-START(8590817858)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Gift$Common$Models$CommunityGiftPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590817858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$XtuU.LCCGCM.CommunityGiftPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$XtuU.LCCGCM.CommunityGiftPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590817858)
            
            //--TRIMMABLE-BOUNDARY-START(17180752450)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Gift$Common$Models$CommunityGiftPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180752450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$XtuU.LCCGCM.CommunityGiftPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$XtuU.LCCGCM.CommunityGiftPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180752450)
            
            //--TRIMMABLE-BOUNDARY-START(21475719746)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Gift$Common$Models$CommunityGiftPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475719746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$XtuU.LCCGCM.CommunityGiftPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$XtuU.LCCGCM.CommunityGiftPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475719746)
            
            //--TRIMMABLE-BOUNDARY-START(25770687042)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Gift$Common$Models$CommunityGiftPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770687042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$XtuU.LCCGCM.CommunityGiftPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$XtuU.LCCGCM.CommunityGiftPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770687042)
            
            //--TRIMMABLE-BOUNDARY-START(12885785154)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885785154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$XtuU.LCCGCM.CommunityGiftPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885785154)
            
            static $h = 883266;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295850562),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 883266,
      "h": 4295850562,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295850562)
  ],
  "h": 883266
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$XtuU.LCCGCS.IComunityGiftRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.IReadDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Services.IComunityGiftRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Services${separator}IComunityGiftRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(883266)
        
        

        //--TRIMMABLE-BOUNDARY-START(621122)
        $asm.$cls(`$XtuU.LCCGCM.CommunityGiftPostModelTypeDescriptor`, ($self) => class CommunityGiftPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XtuU.LCCGCM.CommunityGiftPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295588418)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295588418);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$XtuU.LCCGCM.CommunityGiftPostModelTypeDescriptor.GenerateProperties($.$XtuU.LCCGCM.CommunityGiftPostModel, this, factory);
                    }, $sXGnfd ??= {"r":65537,"n":"","d":621122,"h":0,"f":17825794}), 0, "CommunityGiftPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Gift.Common\\Models_CommunityGiftPostModel_LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModelTypeDescriptorBuilder.g.cs", "CommunityGiftPostModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295588418)
            
            //--TRIMMABLE-BOUNDARY-START(12885523010)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885523010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$XtuU.LCCGCM.CommunityGiftPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$XtuU.LCCGCM.CommunityGiftPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$XtuU.LCCGCM.CommunityGiftPostModel)).Type);
                        }, $vMGELc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":621122,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885523010)
            
            //--TRIMMABLE-BOUNDARY-START(17180490306)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180490306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180490306)
            
            //--TRIMMABLE-BOUNDARY-START(8590555714)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590555714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$XtuU.LCCGCM.CommunityGiftPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$XtuU.LCCGCM.CommunityGiftPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XtuU.LCCGCM.CommunityGiftPostModel)))
                {
                    /*var*/ let result = $.$XtuU.LCCGCM.CommunityGiftPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$XtuU.LCCGCM.CommunityGiftPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$XtuU.LCCGCM.CommunityGiftPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XtuU.LCCGCM.CommunityGiftPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590555714)
            
            static $h = 621122;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XtuU.LCCGCM.CommunityGiftPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885523010),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 621122,
      "h": 12885523010,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885523010),
//--TRIMMABLE-BOUNDARY-START(17180490306),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 490050,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 621122,
      "h": 17180490306,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180490306),
//--TRIMMABLE-BOUNDARY-START(8590555714),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 490050,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 621122,
      "h": 8590555714,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590555714)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295588418),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 621122,
      "h": 4295588418,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295588418)
  ],
  "h": 621122
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$XtuU.LCCGCM.CommunityGiftPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Models.CommunityGiftPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Models${separator}CommunityGiftPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(621122)
        
        

        //--TRIMMABLE-BOUNDARY-START(227906)
        $asm.$cls(`$XtuU.LCCGCM.CommunityGiftModel`, ($self) => class CommunityGiftModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$XtuU.LCCGCS$1.CommunityGiftSettings, $.$XtuU.LCCGCS$2.CommunityGiftStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295195202)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295195202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295195202)
            
            //--TRIMMABLE-BOUNDARY-START(4295195202)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295195202)
            
            static $h = 227906;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$XtuU.LCCGCS$1.CommunityGiftSettings, $.$XtuU.LCCGCS$2.CommunityGiftStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295195202),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 227906,
      "h": 4295195202,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295195202)
  ],
  "h": 227906
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Models.CommunityGiftModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Models${separator}CommunityGiftModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(227906)
        
        

        //--TRIMMABLE-BOUNDARY-START(358978)
        $asm.$cls(`$XtuU.LCCGCM.CommunityGiftModelTypeDescriptor`, ($self) => class CommunityGiftModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XtuU.LCCGCM.CommunityGiftModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295326274)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295326274);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$XtuU.LCCGCM.CommunityGiftModelTypeDescriptor.GenerateProperties($.$XtuU.LCCGCM.CommunityGiftModel, this, factory);
                    }, $eaJAzd ??= {"r":65537,"n":"","d":358978,"h":0,"f":17825794}), 0, "CommunityGiftModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Gift.Common\\Models_CommunityGiftModel_LivingThing.Core.Community.Gift.Common.Models.CommunityGiftModelTypeDescriptorBuilder.g.cs", "CommunityGiftModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295326274)
            
            //--TRIMMABLE-BOUNDARY-START(12885260866)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885260866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$XtuU.LCCGCS$1.CommunityGiftSettings, $.$XtuU.LCCGCS$2.CommunityGiftStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885260866)
            
            //--TRIMMABLE-BOUNDARY-START(17180228162)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Gift.Common.Models.CommunityGiftModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180228162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Gift.Common.Settings.CommunityGiftSettings, LivingThing.Core.Community.Gift.Common.States.CommunityGiftStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$XtuU.LCCGCS$1.CommunityGiftSettings, $.$XtuU.LCCGCS$2.CommunityGiftStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$XtuU.LCCGCS$1.CommunityGiftSettings, $.$XtuU.LCCGCS$2.CommunityGiftStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180228162)
            
            //--TRIMMABLE-BOUNDARY-START(8590293570)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Gift.Common.Models.CommunityGiftModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590293570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$XtuU.LCCGCM.CommunityGiftModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$XtuU.LCCGCM.CommunityGiftModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XtuU.LCCGCM.CommunityGiftModel)))
                {
                    /*var*/ let result = $.$XtuU.LCCGCM.CommunityGiftModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$XtuU.LCCGCM.CommunityGiftModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$XtuU.LCCGCM.CommunityGiftModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XtuU.LCCGCM.CommunityGiftModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590293570)
            
            static $h = 358978;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XtuU.LCCGCM.CommunityGiftModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885260866),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 358978,
      "h": 12885260866,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885260866),
//--TRIMMABLE-BOUNDARY-START(17180228162),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 227906,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 358978,
      "h": 17180228162,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180228162),
//--TRIMMABLE-BOUNDARY-START(8590293570),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 227906,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 358978,
      "h": 8590293570,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590293570)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295326274),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 358978,
      "h": 4295326274,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295326274)
  ],
  "h": 358978
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$XtuU.LCCGCM.CommunityGiftModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Gift.Common.Models.CommunityGiftModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Gift${separator}Common${separator}Models${separator}CommunityGiftModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(358978)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(31298)
