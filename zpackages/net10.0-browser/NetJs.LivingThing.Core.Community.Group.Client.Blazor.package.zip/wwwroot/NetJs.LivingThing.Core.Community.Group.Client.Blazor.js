
//--TRIMMABLE-BOUNDARY-START(44446)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $jlvo, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $GYJg, $PZCj) {
    "use strict";
    let _;
    let $xTbRTg;
    let $GNlTqf;
    let $Qrcmfd;
    let $ZKxnjl;
    let $HVvzKb;
    let $CLQJxf;
    let $KhiPRe;
    let $ZxBKKh;
    let $ihlZlg;
    let $eVcuCd;
    let $mlQhBb;
    let $kmxcJd;
    let $GKNuIh;
    let $zuQLui;
    let $WksNIa;
    let $osbCAf;
    let $GPuGTi;
    let $hYjQgg;
    let $wSDcOa;
    let $BLgDji;
    let $uksUYg;
    let $udaith;
    let $VlJfyh;
    let $SUqRri;
    let $kXQhKc;
    let $SXEPac;
    let $lgsuBc;
    let $dQllqc;
    let $WkBFWi;
    let $oGVMpe;
    let $aZRahc;
    let $LESWDg;
    let $aAbCDh;
    let $iadjgi;
    let $wCZtdc;
    let $xhmKgb;
    let $KGZTGe;
    let $pWFwLj;
    let $jsxjIg;
    let $eveRuk;
    let $qqKtXe;
    let $IUrKjl;
    let $jWSGAh;
    let $AJerhe;
    let $drMfeb;
    let $WZYYWc;
    let $gwLcnc;
    let $HXRWdf;
    let $cprdIj;
    let $ekvwqe;
    let $PTJebd;
    let $qCfKPi;
    let $VzLjLe;
    let $ilfSbe;
    let $aqWKQb;
    let $dRbmkj;
    let $fcvNek;
    let $evoqjh;
    let $YGwIJk;
    let $fdFCVg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Group.Client.Blazor", 
    {
  "h": 44446,
  "f": "LivingThing.Core.Community.Group.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Group.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Group.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(765342)
        $asm.$cls(`$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler`, ($self) => class ICommunityGroupApplicationTypeHandler
        {
            //--TRIMMABLE-BOUNDARY-START(51540372894)
            /*string */ get LCFCA$IApplicationServiceProxy$Type()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(51540372894)
            
            static $h = 765342;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540372894),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245405598,
        "f": 50331650
      },
      "n": "{2203104}.Type",
      "o": "LCFCA$IApplicationServiceProxy$Type",
      "d": 765342,
      "h": 51540372894,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51540372894),
//--TRIMMABLE-BOUNDARY-START(64425274782),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770569118,
        "f": 50331905
      },
      "n": "Type",
      "o": "LCCGCS$ICommunityGroupApplicationTypeHandler$Type",
      "d": 765342,
      "h": 64425274782,
      "f": 538968321
    },
//--TRIMMABLE-BOUNDARY-END(64425274782),
//--TRIMMABLE-BOUNDARY-START(60130307486),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180634526,
        "f": 50331905
      },
      "n": "SubGroupTitle",
      "o": "LCCGCS$ICommunityGroupApplicationTypeHandler$SubGroupTitle",
      "d": 765342,
      "h": 60130307486,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(60130307486),
//--TRIMMABLE-BOUNDARY-START(55835340190),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590699934,
        "f": 50331905
      },
      "n": "Roles",
      "o": "LCCGCS$ICommunityGroupApplicationTypeHandler$Roles",
      "d": 765342,
      "h": 55835340190,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(55835340190)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360503710),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetGroupSynopsis",
      "o": "LCCGCS$ICommunityGroupApplicationTypeHandler$GetGroupSynopsis",
      "d": 765342,
      "h": 34360503710,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360503710),
//--TRIMMABLE-BOUNDARY-START(30065536414),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetGroupPages",
      "o": "LCCGCS$ICommunityGroupApplicationTypeHandler$GetGroupPages",
      "d": 765342,
      "h": 30065536414,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065536414),
//--TRIMMABLE-BOUNDARY-START(38655471006),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetHomePage",
      "o": "LCCGCS$ICommunityGroupApplicationTypeHandler$GetHomePage",
      "d": 765342,
      "h": 38655471006,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38655471006)
  ],
  "h": 765342
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ydCm.LCCCS.ICommunityApplicationSubService, $.$yleQ.LCFCA.IApplicationSubService, $.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Client.Services.ICommunityGroupApplicationTypeHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Client${separator}Services${separator}ICommunityGroupApplicationTypeHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(765342)
        
        

        //--TRIMMABLE-BOUNDARY-START(830878)
        $asm.$cls(`$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler<,,>`, (TCommunityGroupPostModel, TCommunityGroupPostSettings, TCommunityGroupPostStates) => $asm.$gt(`$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler<,,>`, [TCommunityGroupPostModel, TCommunityGroupPostSettings, TCommunityGroupPostStates], ($self) => class ICommunityGroupApplicationTypeHandler$$$$
        {
            //--TRIMMABLE-BOUNDARY-START(8590765470)
            /*RenderFragment? */ LCCGCS$ICommunityGroupApplicationTypeHandler$GetHomePage(/*AccountBaseModel*/ group)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590765470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LCCGCS$ICommunityGroupApplicationTypeHandler$$$$$GetGroupTypedHomePage(group, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590765470)
            
            static $H = 830878;
            static $h = 830878;
            static $g = 3;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295798174),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        },
        {
          "n": "route",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetGroupTypedHomePage",
      "o": "LCCGCS$ICommunityGroupApplicationTypeHandler$$$$$GetGroupTypedHomePage",
      "d": this.$h,
      "H": 4295798174,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295798174)
  ],
  "s": [
    {
      "h": TCommunityGroupPostModel?.$h??1572864,
      "n": "TCommunityGroupPostModel",
      "c": [$.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TCommunityGroupPostSettings, TCommunityGroupPostStates).$h
      ]
    },
    {
      "h": TCommunityGroupPostSettings?.$h??1638400,
      "n": "TCommunityGroupPostSettings",
      "c": [2502566
      ]
    },
    {
      "h": TCommunityGroupPostStates?.$h??1703936,
      "n": "TCommunityGroupPostStates",
      "c": [3026854
      ]
    }
  ],
  "r": 3,
  "H": 830878,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, $.$ydCm.LCCCS.ICommunityApplicationSubService, $.$yleQ.LCFCA.IApplicationSubService, $.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Client.Services.ICommunityGroupApplicationTypeHandler<${TCommunityGroupPostModel?.$fullName},${TCommunityGroupPostSettings?.$fullName},${TCommunityGroupPostStates?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Client${separator}Services${separator}ICommunityGroupApplicationTypeHandler$${TCommunityGroupPostModel?.$getFullName(separator)}$${TCommunityGroupPostSettings?.$getFullName(separator)}$${TCommunityGroupPostStates?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(830878)
        
        

        //--TRIMMABLE-BOUNDARY-START(699806)
        $asm.$cls(`$PIIp.LCCGCS.CommunityGroupTypeHandlerBase<,,>`, (TCommunityGroupPostModel, TCommunityGroupPostSettings, TCommunityGroupPostStates) => $asm.$gt(`$PIIp.LCCGCS.CommunityGroupTypeHandlerBase<,,>`, [TCommunityGroupPostModel, TCommunityGroupPostSettings, TCommunityGroupPostStates], ($self) => class CommunityGroupTypeHandlerBase$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(283468541342)
            /*string?*/ $SubGroupTitle = null;
            /*string? */ get SubGroupTitle()
            {
                return this.$SubGroupTitle;
            }
             /*string? */ set SubGroupTitle(value)
            {
                this.$SubGroupTitle = value;
            }
            //--TRIMMABLE-BOUNDARY-END(283468541342)
            
            //--TRIMMABLE-BOUNDARY-START(274878606750)
            /*IEnumerable<string>?*/ $Roles = null;
            /*IEnumerable<string>? */ get Roles()
            {
                return this.$Roles;
            }
             /*IEnumerable<string>? */ set Roles(value)
            {
                this.$Roles = value;
            }
            //--TRIMMABLE-BOUNDARY-END(274878606750)
            
            //--TRIMMABLE-BOUNDARY-START(60130241950)
            /*string?*/ $Description = null;
            /*string? */ get Description()
            {
                return this.$Description;
            }
             /*string? */ set Description(value)
            {
                this.$Description = value;
            }
            //--TRIMMABLE-BOUNDARY-END(60130241950)
            
            //--TRIMMABLE-BOUNDARY-START(261993704862)
            /*int*/ $Order = 0;
            /*int */ get Order()
            {
                return this.$Order;
            }
             /*int */ set Order(value)
            {
                this.$Order = value;
            }
            //--TRIMMABLE-BOUNDARY-END(261993704862)
            
            //--TRIMMABLE-BOUNDARY-START(266288672158)
            /*string[]? */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["/" + $.$strNN(this.Name)], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(266288672158)
            
            //--TRIMMABLE-BOUNDARY-START(64425209246)
            /*ApplicationServiceFeatures*/ $Features = 0;
            /*ApplicationServiceFeatures */ get Features()
            {
                return this.$Features;
            }
             /*ApplicationServiceFeatures */ set Features(value)
            {
                this.$Features = value;
            }
            //--TRIMMABLE-BOUNDARY-END(64425209246)
            
            //--TRIMMABLE-BOUNDARY-START(51540307358)
            /*IEnumerable<string>?*/ Assemblies = null;
            //--TRIMMABLE-BOUNDARY-END(51540307358)
            
            //--TRIMMABLE-BOUNDARY-START(55835274654)
            /*IEnumerable<string>?*/ DependencyAssemblies = null;
            //--TRIMMABLE-BOUNDARY-END(55835274654)
            
            //--TRIMMABLE-BOUNDARY-START(300648410526)
            /*string?*/ $UIEntryType = null;
            /*string? */ get UIEntryType()
            {
                return this.$UIEntryType;
            }
             /*string? */ set UIEntryType(value)
            {
                this.$UIEntryType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(300648410526)
            
            //--TRIMMABLE-BOUNDARY-START(47245340062)
            /*IApplicationProxy */ get Application()
            {
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(47245340062)
            
            //--TRIMMABLE-BOUNDARY-START(231928933790)
            /*RenderFragment? */ GetAccountView(/*AccountBaseModel*/ account, /*string?*/ route)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(231928933790);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetGroupTypedHomePage(account, route);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231928933790)
            
            //--TRIMMABLE-BOUNDARY-START(236223901086)
            /*RenderFragment? */ GetGroupPages(/*AccountBaseModel*/ group)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(236223901086);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236223901086)
            
            //--TRIMMABLE-BOUNDARY-START(240518868382)
            /*RenderFragment? */ GetGroupSynopsis(/*AccountBaseModel*/ group)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(240518868382);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(240518868382)
            
            //--TRIMMABLE-BOUNDARY-START(244813835678)
            /*RenderFragment? */ GetGroupTypedHomePage(/*AccountBaseModel*/ group, /*string?*/ route)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813835678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$PIIp.LCCGCS$1.CommunityGroupApplicationView$$$$(TCommunityGroupPostModel, TCommunityGroupPostSettings, TCommunityGroupPostStates), (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("ViewModel", $.$box($.$cast(group, TCommunityGroupPostModel), TCommunityGroupPostModel));
                    $i1.set_Item("Route", route);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(244813835678)
            
            //--TRIMMABLE-BOUNDARY-START(4295798174)
            //Generated interface implemetation for LivingThing.Core.Community.Group.Client.Services.ICommunityGroupApplicationTypeHandler<TCommunityGroupPostModel, TCommunityGroupPostSettings, TCommunityGroupPostStates>.GetGroupTypedHomePage(LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel, string?)
            LCCGCS$ICommunityGroupApplicationTypeHandler$$$$$GetGroupTypedHomePage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295798174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetGroupTypedHomePage(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295798174)
            
            //--TRIMMABLE-BOUNDARY-START(25770569118)
            //Generated interface implemetation for LivingThing.Core.Community.Group.Client.Services.ICommunityGroupApplicationTypeHandler.Type.get
            get LCCGCS$ICommunityGroupApplicationTypeHandler$Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425274782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Type;
            }
            //--TRIMMABLE-BOUNDARY-END(25770569118)
            
            //--TRIMMABLE-BOUNDARY-START(17180634526)
            //Generated interface implemetation for LivingThing.Core.Community.Group.Client.Services.ICommunityGroupApplicationTypeHandler.SubGroupTitle.get
            get LCCGCS$ICommunityGroupApplicationTypeHandler$SubGroupTitle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130307486);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SubGroupTitle;
            }
            //--TRIMMABLE-BOUNDARY-END(17180634526)
            
            //--TRIMMABLE-BOUNDARY-START(8590699934)
            //Generated interface implemetation for LivingThing.Core.Community.Group.Client.Services.ICommunityGroupApplicationTypeHandler.Roles.get
            get LCCGCS$ICommunityGroupApplicationTypeHandler$Roles()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835340190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Roles;
            }
            //--TRIMMABLE-BOUNDARY-END(8590699934)
            
            //--TRIMMABLE-BOUNDARY-START(34360503710)
            //Generated interface implemetation for LivingThing.Core.Community.Group.Client.Services.ICommunityGroupApplicationTypeHandler.GetGroupSynopsis(LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel)
            LCCGCS$ICommunityGroupApplicationTypeHandler$GetGroupSynopsis()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360503710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetGroupSynopsis(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34360503710)
            
            //--TRIMMABLE-BOUNDARY-START(30065536414)
            //Generated interface implemetation for LivingThing.Core.Community.Group.Client.Services.ICommunityGroupApplicationTypeHandler.GetGroupPages(LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel)
            LCCGCS$ICommunityGroupApplicationTypeHandler$GetGroupPages()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065536414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetGroupPages(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065536414)
            
            //--TRIMMABLE-BOUNDARY-START(8595419636)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Services.ICommunityApplicationSubService.PostsName.get
            get LCCCS$ICommunityApplicationSubService$PostsName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21480321524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostsName;
            }
            //--TRIMMABLE-BOUNDARY-END(8595419636)
            
            //--TRIMMABLE-BOUNDARY-START(17185354228)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Services.ICommunityApplicationSubService.ServiceCategories.get
            get LCCCS$ICommunityApplicationSubService$ServiceCategories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25775288820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceCategories;
            }
            //--TRIMMABLE-BOUNDARY-END(17185354228)
            
            //--TRIMMABLE-BOUNDARY-START(47246843360)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Id.get
            get LCFCA$IApplicationServiceProxy$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901549024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(47246843360)
            
            //--TRIMMABLE-BOUNDARY-START(81606581728)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.UIEntryType.get
            get LCFCA$IApplicationServiceProxy$UIEntryType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081418208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UIEntryType;
            }
            //--TRIMMABLE-BOUNDARY-END(81606581728)
            
            //--TRIMMABLE-BOUNDARY-START(21477039584)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Application.get
            get LCFCA$IApplicationServiceProxy$Application()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297170400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Application;
            }
            //--TRIMMABLE-BOUNDARY-END(21477039584)
            
            //--TRIMMABLE-BOUNDARY-START(38656908768)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Features.get
            get LCFCA$IApplicationServiceProxy$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887104992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(38656908768)
            
            //--TRIMMABLE-BOUNDARY-START(64426712544)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Paths.get
            get LCFCA$IApplicationServiceProxy$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491483616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(64426712544)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(8610351446)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOrderedData.Order.get
            get LCFCD$IOrderedData$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12905318742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(8610351446)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //--TRIMMABLE-BOUNDARY-START(12901717440)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityAccountApplicationViewProvider.AccountsType.get
            get LCCCS$ICommunityAccountApplicationViewProvider$AccountsType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311782848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AccountsType;
            }
            //--TRIMMABLE-BOUNDARY-END(12901717440)
            
            //--TRIMMABLE-BOUNDARY-START(17196684736)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityAccountApplicationViewProvider.GetAccountView(LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel, string?)
            LCCCS$ICommunityAccountApplicationViewProvider$GetAccountView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17196684736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAccountView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17196684736)
            
            //--TRIMMABLE-BOUNDARY-START(38655405470)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655405470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655405470)
            
            //--TRIMMABLE-BOUNDARY-START(38655405470)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(38655405470)
            
            static $H = 699806;
            static $h = 699806;
            static $g = 3;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(296353443230),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "H": 219044031902,
        "h": Number(BigInt(this.$h)|0x3300000000n),
        "f": 50331905
      },
      "n": "Type",
      "d": this.$h,
      "H": 296353443230,
      "h": Number(BigInt(this.$h)|0x4500000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(296353443230),
//--TRIMMABLE-BOUNDARY-START(283468541342),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 193274228126,
        "h": Number(BigInt(this.$h)|0x2D00000000n),
        "f": 50331777
      },
      "n": "SubGroupTitle",
      "d": this.$h,
      "H": 283468541342,
      "h": Number(BigInt(this.$h)|0x4200000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(283468541342),
//--TRIMMABLE-BOUNDARY-START(274878606750),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 176094358942,
        "h": Number(BigInt(this.$h)|0x2900000000n),
        "f": 50331777
      },
      "n": "Roles",
      "d": this.$h,
      "H": 274878606750,
      "h": Number(BigInt(this.$h)|0x4000000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(274878606750),
//--TRIMMABLE-BOUNDARY-START(253403770270),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 133144685982,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 50331905
      },
      "n": "Id",
      "d": this.$h,
      "H": 253403770270,
      "h": Number(BigInt(this.$h)|0x3B00000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(253403770270),
//--TRIMMABLE-BOUNDARY-START(270583639454),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 167504424350,
        "h": Number(BigInt(this.$h)|0x2700000000n),
        "f": 50331905
      },
      "n": "PostsName",
      "d": this.$h,
      "H": 270583639454,
      "h": Number(BigInt(this.$h)|0x3F00000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(270583639454),
//--TRIMMABLE-BOUNDARY-START(279173574046),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS.ICommunityApplicationServiceCategory).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 184684293534,
        "h": Number(BigInt(this.$h)|0x2B00000000n),
        "f": 50331905
      },
      "n": "ServiceCategories",
      "d": this.$h,
      "H": 279173574046,
      "h": Number(BigInt(this.$h)|0x4100000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(279173574046),
//--TRIMMABLE-BOUNDARY-START(292058475934),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 210454097310,
        "h": Number(BigInt(this.$h)|0x3100000000n),
        "f": 50331905
      },
      "n": "Title",
      "d": this.$h,
      "H": 292058475934,
      "h": Number(BigInt(this.$h)|0x4400000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(292058475934),
//--TRIMMABLE-BOUNDARY-START(60130241950),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107374882206,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331777
      },
      "n": "Description",
      "d": this.$h,
      "H": 60130241950,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(60130241950),
//--TRIMMABLE-BOUNDARY-START(249108802974),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "H": 124554751390,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 50331905
      },
      "n": "Icon",
      "d": this.$h,
      "H": 249108802974,
      "h": Number(BigInt(this.$h)|0x3A00000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(249108802974),
//--TRIMMABLE-BOUNDARY-START(257698737566),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 141734620574,
        "h": Number(BigInt(this.$h)|0x2100000000n),
        "f": 50331905
      },
      "n": "Name",
      "d": this.$h,
      "H": 257698737566,
      "h": Number(BigInt(this.$h)|0x3C00000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(257698737566),
//--TRIMMABLE-BOUNDARY-START(287763508638),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "H": 201864162718,
        "h": Number(BigInt(this.$h)|0x2F00000000n),
        "f": 50331905
      },
      "n": "Theme",
      "d": this.$h,
      "H": 287763508638,
      "h": Number(BigInt(this.$h)|0x4300000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(287763508638),
//--TRIMMABLE-BOUNDARY-START(42950372766),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73015143838,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331905
      },
      "n": "AccountsType",
      "d": this.$h,
      "H": 42950372766,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42950372766),
//--TRIMMABLE-BOUNDARY-START(261993704862),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 150324555166,
        "h": Number(BigInt(this.$h)|0x2300000000n),
        "f": 50331777
      },
      "n": "Order",
      "d": this.$h,
      "H": 261993704862,
      "h": Number(BigInt(this.$h)|0x3D00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(261993704862),
//--TRIMMABLE-BOUNDARY-START(266288672158),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 158914489758,
        "h": Number(BigInt(this.$h)|0x2500000000n),
        "f": 50331777
      },
      "n": "Paths",
      "d": this.$h,
      "H": 266288672158,
      "h": Number(BigInt(this.$h)|0x3E00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(266288672158),
//--TRIMMABLE-BOUNDARY-START(64425209246),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "H": 115964816798,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50331777
      },
      "n": "Features",
      "d": this.$h,
      "H": 64425209246,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(64425209246),
//--TRIMMABLE-BOUNDARY-START(51540307358),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90195013022,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "n": "Assemblies",
      "d": this.$h,
      "H": 51540307358,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540307358),
//--TRIMMABLE-BOUNDARY-START(55835274654),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98784947614,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "n": "DependencyAssemblies",
      "d": this.$h,
      "H": 55835274654,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835274654),
//--TRIMMABLE-BOUNDARY-START(300648410526),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 227633966494,
        "h": Number(BigInt(this.$h)|0x3500000000n),
        "f": 50331777
      },
      "n": "UIEntryType",
      "d": this.$h,
      "H": 300648410526,
      "h": Number(BigInt(this.$h)|0x4600000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(300648410526),
//--TRIMMABLE-BOUNDARY-START(47245340062),
    {
      "p": 1482208,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81605078430,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331777
      },
      "n": "Application",
      "d": this.$h,
      "H": 47245340062,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(47245340062)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(231928933790),
    {
      "r": 6881395,
      "p": [
        {
          "n": "account",
          "p": 6220212
        },
        {
          "n": "route",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetAccountView",
      "d": this.$h,
      "H": 231928933790,
      "h": Number(BigInt(this.$h)|0x3600000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(231928933790),
//--TRIMMABLE-BOUNDARY-START(236223901086),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetGroupPages",
      "d": this.$h,
      "H": 236223901086,
      "h": Number(BigInt(this.$h)|0x3700000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(236223901086),
//--TRIMMABLE-BOUNDARY-START(240518868382),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetGroupSynopsis",
      "d": this.$h,
      "H": 240518868382,
      "h": Number(BigInt(this.$h)|0x3800000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(240518868382),
//--TRIMMABLE-BOUNDARY-START(244813835678),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        },
        {
          "n": "route",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetGroupTypedHomePage",
      "d": this.$h,
      "H": 244813835678,
      "h": Number(BigInt(this.$h)|0x3900000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(244813835678)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655405470),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 38655405470,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(38655405470)
  ],
  "s": [
    {
      "h": TCommunityGroupPostModel?.$h??1572864,
      "n": "TCommunityGroupPostModel",
      "c": [$.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TCommunityGroupPostSettings, TCommunityGroupPostStates).$h
      ]
    },
    {
      "h": TCommunityGroupPostSettings?.$h??1638400,
      "n": "TCommunityGroupPostSettings",
      "c": [2502566
      ]
    },
    {
      "h": TCommunityGroupPostStates?.$h??1703936,
      "n": "TCommunityGroupPostStates",
      "c": [3026854
      ]
    }
  ],
  "r": 3,
  "H": 699806,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler$$$$(TCommunityGroupPostModel, TCommunityGroupPostSettings, TCommunityGroupPostStates), $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, $.$ydCm.LCCCS.ICommunityApplicationSubService, $.$yleQ.LCFCA.IApplicationSubService, $.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Client.Services.CommunityGroupTypeHandlerBase<${TCommunityGroupPostModel?.$fullName},${TCommunityGroupPostSettings?.$fullName},${TCommunityGroupPostStates?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Client${separator}Services${separator}CommunityGroupTypeHandlerBase$${TCommunityGroupPostModel?.$getFullName(separator)}$${TCommunityGroupPostSettings?.$getFullName(separator)}$${TCommunityGroupPostStates?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(699806)
        
        

        //--TRIMMABLE-BOUNDARY-START(175518)
        $asm.$cls(`$PIIp.LCCGC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295142814)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295142814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$PIIp.LCCGC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295142814)
            
            static $h = 175518;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295142814),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 175518,
      "h": 4295142814,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295142814)
  ],
  "h": 175518
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(175518)
        
        

        //--TRIMMABLE-BOUNDARY-START(437662)
        $asm.$cls(`$PIIp.LCCGCS.CommunityGroupAccountsProvider`, ($self) => class CommunityGroupAccountsProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34360176030)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(34360176030)
            
            //--TRIMMABLE-BOUNDARY-START(12885339550)
            /*IDataCacheStorageService*/ Cache = null;
            //--TRIMMABLE-BOUNDARY-END(12885339550)
            
            //--TRIMMABLE-BOUNDARY-START(30065208734)
            /*IUIRenderingProvider*/ Rendering = null;
            //--TRIMMABLE-BOUNDARY-END(30065208734)
            
            //--TRIMMABLE-BOUNDARY-START(4295404958)
            $ctor$1(/*IServerRemoteService*/ server, /*IDataCacheStorageService*/ cache, /*IUIRenderingProvider*/ rendering)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295404958);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                    this.Cache = cache;
                    this.Rendering = rendering;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295404958)
            
            //--TRIMMABLE-BOUNDARY-START(8590372254)
            /*IEnumerable<PostTypes> */ get AccountTypes()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostTypes), [2304/*PostTypes.Group*/, 2307/*PostTypes.GroupChurch*/, 2306/*PostTypes.GroupOrganization*/, 2305/*PostTypes.GroupUser*/, 2308/*PostTypes.GroupSchool*/, 2558/*PostTypes.GroupSub*/], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590372254)
            
            //--TRIMMABLE-BOUNDARY-START(25770241438)
            /*ValueTask<IEnumerable<AccountBaseModel>?> *//*async*/  GetCurrentUserAccountsAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountBaseModel)), $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountBaseModel), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770241438);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let groups = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$PZCj.LCCGCM.CommunityGroupPostModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)), (() =>
                    {
                        //new $.$uvJL.LCFCR.RemoteProxyExecutionContext()
                        const $t2 = $.$uvJL.LCFCR.RemoteProxyExecutionContext;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ServerCache = this.Rendering;
                        $i2.DataCache = this.Cache;
                        return $i2;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.N.InterfaceVarianceStubHandler.Create(groups.Data, $.$$.SCG.IEnumerable$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountBaseModel)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770241438)
            
            //--TRIMMABLE-BOUNDARY-START(12904207808)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityUserAccountProvider.AccountTypes.get
            get LCCCS$ICommunityUserAccountProvider$AccountTypes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4314273216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AccountTypes;
            }
            //--TRIMMABLE-BOUNDARY-END(12904207808)
            
            //--TRIMMABLE-BOUNDARY-START(17199175104)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityUserAccountProvider.GetCurrentUserAccountsAsync()
            LCCCS$ICommunityUserAccountProvider$GetCurrentUserAccountsAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17199175104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCurrentUserAccountsAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17199175104)
            
            static $h = 437662;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590372254),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475274142,
        "f": 50331649
      },
      "n": "AccountTypes",
      "d": 437662,
      "h": 8590372254,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590372254)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770241438),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountBaseModel)).$h,
      "n": "GetCurrentUserAccountsAsync",
      "d": 437662,
      "h": 25770241438,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(25770241438)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360176030),
    {
      "t": 1309651,
      "n": "Server",
      "d": 437662,
      "h": 34360176030,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360176030),
//--TRIMMABLE-BOUNDARY-START(12885339550),
    {
      "t": 63867222,
      "n": "Cache",
      "d": 437662,
      "h": 12885339550,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885339550),
//--TRIMMABLE-BOUNDARY-START(30065208734),
    {
      "t": 5463464,
      "n": "Rendering",
      "d": 437662,
      "h": 30065208734,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065208734)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295404958),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "cache",
          "p": 63867222
        },
        {
          "n": "rendering",
          "p": 5463464
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 437662,
      "h": 4295404958,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295404958)
  ],
  "h": 437662
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityUserAccountProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Client.Services.CommunityGroupAccountsProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Client${separator}Services${separator}CommunityGroupAccountsProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(437662)
        
        

        //--TRIMMABLE-BOUNDARY-START(241054)
        $asm.$cls(`$PIIp.LCCGC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180110238)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$PIIp.LCCGCP.CommunityGroupApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$PIIp.LCCGCP.CommunityGroupApp().$ctor$6();
                    }, $xTbRTg ??= {"r":2752627,"n":"","d":241054,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180110238)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295208350)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295208350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295208350)
            
            //--TRIMMABLE-BOUNDARY-START(4295208350)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295208350)
            
            static $h = 241054;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180110238),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885142942,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 241054,
      "h": 17180110238,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180110238)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295208350),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 241054,
      "h": 4295208350,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295208350)
  ],
  "h": 241054
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(241054)
        
        

        //--TRIMMABLE-BOUNDARY-START(372126)
        $asm.$cls(`$PIIp.LCCGC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590306718)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590306718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$PIIp.LCCGCS.CommunityGroupService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$PZCj.LCCGCM.CommunityGroupPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$PIIp.LCCGCS.CommunityGroupApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PIIp.LCCGCS.CommunityGroupApplication, x);
                }, $GNlTqf ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":372126,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PIIp.LCCGCS.CommunityGroupApplication, x);
                }, $Qrcmfd ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":372126,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$PZCj.LCCGCM.CommunityGroupPostModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$PZCj.LCCGCM.CommunitySubGroupPostModel, services, null);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$PIIp.LCCGCS.CommunityGroupFeedProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCS.ICommunityUserAccountProvider, $.$PIIp.LCCGCS.CommunityGroupAccountsProvider, services);
                $.$PIIp.LCCGC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590306718)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PIIp.LCCGC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295339422)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295339422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295339422)
            
            //--TRIMMABLE-BOUNDARY-START(4295339422)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295339422)
            
            static $h = 372126;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590306718),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 372126,
      "h": 8590306718,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590306718)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295339422),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 372126,
      "h": 4295339422,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295339422)
  ],
  "h": 372126
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(372126)
        
        

        //--TRIMMABLE-BOUNDARY-START(1027486)
        $asm.$cls(`$PIIp.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295994782)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295994782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295994782)
            
            //--TRIMMABLE-BOUNDARY-START(4295994782)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295994782)
            
            static $h = 1027486;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295994782),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1027486,
      "h": 4295994782,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295994782)
  ],
  "h": 1027486,
  "a": [
    {
      "t": 961950,
      "c": 4295929246
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1027486)
        
        

        //--TRIMMABLE-BOUNDARY-START(961950)
        $asm.$cls(`$PIIp.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295929246)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295929246);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295929246)
            
            //--TRIMMABLE-BOUNDARY-START(4295929246)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295929246)
            
            static $h = 961950;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295929246),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 961950,
      "h": 4295929246,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295929246)
  ],
  "h": 961950
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(961950)
        
        

        //--TRIMMABLE-BOUNDARY-START(109982)
        $asm.$cls(`$PIIp.LCCGC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590044574)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590044574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590044574)
            
            //--TRIMMABLE-BOUNDARY-START(4295077278)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295077278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295077278)
            
            //--TRIMMABLE-BOUNDARY-START(4295077278)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295077278)
            
            static $h = 109982;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590044574),
    {
      "r": 65537,
      "n": "Execute",
      "d": 109982,
      "h": 8590044574,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590044574)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295077278),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 109982,
      "h": 4295077278,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295077278)
  ],
  "h": 109982
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(109982)
        
        

        //--TRIMMABLE-BOUNDARY-START(896414)
        $asm.$cls(`$PIIp.LCCGCS$1.CommunityGroupApplicationView<,,>`, (TCommunityGroupPostModel, TCommunityGroupPostSettings, TCommunityGroupPostStates) => $asm.$gt(`$PIIp.LCCGCS$1.CommunityGroupApplicationView<,,>`, [TCommunityGroupPostModel, TCommunityGroupPostSettings, TCommunityGroupPostStates], ($self) => class CommunityGroupApplicationView$$$$ extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$(TCommunityGroupPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(158914686366)
            /*string */ get OptimizedComponentName()
            {
                return "communitygroupapplicationview";
            }
            //--TRIMMABLE-BOUNDARY-END(158914686366)
            
            //--TRIMMABLE-BOUNDARY-START(249108999582)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108999582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Route":
                    this.Route = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(249108999582)
            
            //--TRIMMABLE-BOUNDARY-START(150324751774)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324751774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.GroupHandlers = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler), serviceProvider);
                this.MediaProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.ICommunityMediaProvider, serviceProvider);
                this.ChatProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.ICommunityChatProvider, serviceProvider);
                this.ArticleProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.ICommunityArticleProvider, serviceProvider);
                this.CalendarProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.ICommunityCalendarProvider, serviceProvider);
                this.Application = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PIIp.LCCGCS.CommunityGroupApplication, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PIIp.LCCGCS.CommunityGroupService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(150324751774)
            
            //--TRIMMABLE-BOUNDARY-START(146029784478)
            /*IEnumerable<ICommunityGroupApplicationTypeHandler>*/ GroupHandlers = null;
            //--TRIMMABLE-BOUNDARY-END(146029784478)
            
            //--TRIMMABLE-BOUNDARY-START(154619719070)
            /*ICommunityMediaProvider*/ MediaProvider = null;
            //--TRIMMABLE-BOUNDARY-END(154619719070)
            
            //--TRIMMABLE-BOUNDARY-START(60130438558)
            /*ICommunityChatProvider*/ ChatProvider = null;
            //--TRIMMABLE-BOUNDARY-END(60130438558)
            
            //--TRIMMABLE-BOUNDARY-START(47245536670)
            /*ICommunityArticleProvider*/ ArticleProvider = null;
            //--TRIMMABLE-BOUNDARY-END(47245536670)
            
            //--TRIMMABLE-BOUNDARY-START(55835471262)
            /*ICommunityCalendarProvider*/ CalendarProvider = null;
            //--TRIMMABLE-BOUNDARY-END(55835471262)
            
            //--TRIMMABLE-BOUNDARY-START(42950569374)
            /*CommunityGroupApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(42950569374)
            
            //--TRIMMABLE-BOUNDARY-START(167504620958)
            /*CommunityGroupService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(167504620958)
            
            //--TRIMMABLE-BOUNDARY-START(163209653662)
            /*string?*/ Route = null;
            //--TRIMMABLE-BOUNDARY-END(163209653662)
            
            //--TRIMMABLE-BOUNDARY-START(141734817182)
            /*ICommunityGroupApplicationTypeHandler? */ GetHandler()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141734817182);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.SingleOrDefault$1($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, this.GroupHandlers, new ($.$$.S.Func$$$($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, $.$$.S.Boolean))().$ctor(this,  (/*h*/ h) =>
                    {
                        return h.LCCGCS$ICommunityGroupApplicationTypeHandler$Type === this.ViewModel.Type;
                    }, $osbCAf ??= {"r":262145,"p":[{"n":"h","p":765342}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734817182)
            
            //--TRIMMABLE-BOUNDARY-START(244814032286)
            /*RemoteDataList<CommunitySubGroupPostModel>?*/ subGroupList = null;
            //--TRIMMABLE-BOUNDARY-END(244814032286)
            
            //--TRIMMABLE-BOUNDARY-START(240519064990)
            /*ValueTask */ SubGroupCreated(/*CommunitySubGroupPostModel*/ subGroup)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519064990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.subGroupList.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$PZCj.LCCGCM.CommunitySubGroupPostModel), [ subGroup ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(240519064990)
            
            //--TRIMMABLE-BOUNDARY-START(51540503966)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540503966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ownsGroup = this.Service.CommunityService.IsOwnedByCurrentUser($.$box(this.ViewModel, TCommunityGroupPostModel));
                /*var*/ let handler = this.GetHandler();
                __builder.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountApplication$$$$(TCommunityGroupPostModel, TCommunityGroupPostSettings, TCommunityGroupPostStates), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck(TCommunityGroupPostModel, this.ViewModel), TCommunityGroupPostModel));
                __builder.AddComponentParameter(2, "Application", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCS.ICommunityClientApplication, this.Application));
                __builder.AddComponentParameter(3, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Route));
                __builder.AddAttribute$3(4, "PreFeeds", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$1(5, (handler?.LCCGCS$ICommunityGroupApplicationTypeHandler$GetGroupSynopsis(this.ViewModel) ?? null));
                }), $GPuGTi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.AddAttribute$3(6, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$1(7, (handler?.LCCGCS$ICommunityGroupApplicationTypeHandler$GetGroupPages(this.ViewModel) ?? null));
                    if (handler !== null)
                    {
                        __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 8);
                        __builder2.AddComponentParameter(9, "Name", "Members");
                        __builder2.AddComponentParameter(10, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 4000), $.$$.S.Int32));
                        __builder2.AddAttribute$3(11, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$4(12, "Members");
                            }, $hYjQgg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                        }), $wSDcOa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(13, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$1(14, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account-multiple"/*MaterialDesignIconNames.AccountMultiple*/), false));
                            }, $BLgDji ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                        }), $uksUYg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(15, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                if (handler.LCCGCS$ICommunityGroupApplicationTypeHandler$Roles !== null)
                                {
                                    let $en2 = handler.LCCGCS$ICommunityGroupApplicationTypeHandler$Roles.SCG$IEnumerable$$$GetEnumerator();
                                    while ($en2.SC$1$IEnumerator$MoveNext())
                                    {
                                        let _role = $en2.SCG$IEnumerator$$$Current;
                                        {
                                            /*var*/ let role = _role;
                                            __builder3.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountAvatarList, 16);
                                            __builder3.AddComponentParameter(17, "Filter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$9(this.ViewModel.Identifier, null, role, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741860/*PostFilterTypes.InRole*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                                            __builder3.AddAttribute$3(18, "TitleView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                                {
                                                    __builder4.OpenElement(19, "h3");
                                                    __builder4.AddAttribute$5(20, "class", "mg-0");
                                                    __builder4.AddContent$4(21, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(role));
                                                    __builder4.CloseElement();
                                                }, $udaith ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                            }), $VlJfyh ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                            __builder3.CloseComponent();
                                            __builder3.AddMarkupContent(22, "\r\n                            ");
                                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$LCOv.LCFCPM$1.AccountModel), 23);
                                            __builder3.AddComponentParameter(24, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$9(this.ViewModel.Identifier, null, role, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741860/*PostFilterTypes.InRole*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                                            __builder3.AddComponentParameter(25, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 70), $.$$.S.Int32));
                                            __builder3.AddComponentParameter(26, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                                            __builder3.AddComponentParameter(27, "Class", "mgb-10");
                                            __builder3.AddComponentParameter(28, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (ownsGroup ? 64n | 128n : 0n) | 34359738368n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                            __builder3.AddAttribute$3(29, "CustomToolBar", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*Menu*/ Menu) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                                {
                                                    if (Menu.Features === 34359738368n)
                                                    {
                                                        __builder4.OpenElement(30, "h2");
                                                        __builder4.AddAttribute$5(31, "class", "mg-0");
                                                        __builder4.AddContent$4(32, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(role));
                                                        __builder4.CloseElement();
                                                    }
                                                }, $SUqRri ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                            }), $kXQhKc ??= {"r":6881395,"p":[{"n":"Menu","p":$.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                            __builder3.AddAttribute$3(33, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*member*/ member) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                                {
                                                    __builder4.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountCard, 34);
                                                    __builder4.AddComponentParameter(35, "Size", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 70), $.$$.S.Int32));
                                                    __builder4.AddComponentParameter(36, "Account", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.AccountBaseModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).op_Implicit$1(member)));
                                                    __builder4.CloseComponent();
                                                }, $SXEPac ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                            }), $lgsuBc ??= {"r":6881395,"p":[{"n":"member","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                            __builder3.AddAttribute$3(37, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                            {
                                                __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 38);
                                                __builder4.AddComponentParameter(39, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `No ${$.$strNN(role)}`));
                                                __builder4.CloseComponent();
                                            }), $dQllqc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                            __builder3.CloseComponent();
                                        }
                                    }
                                }
                                __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$LCOv.LCFCPM$1.AccountModel), 40);
                                __builder3.AddComponentParameter(41, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.ViewModel.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741828/*PostFilterTypes.Subscribers*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                                __builder3.AddComponentParameter(42, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 70), $.$$.S.Int32));
                                __builder3.AddComponentParameter(43, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                                __builder3.AddComponentParameter(44, "Class", "mgb-10");
                                __builder3.AddComponentParameter(45, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 34359738368n | 70368744177664n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                __builder3.AddAttribute$3(46, "CustomToolBar", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*Menu*/ Menu) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.AddMarkupContent(47, "<h3 class=\"mg-0\">Members</h3>");
                                    }, $WkBFWi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                }), $oGVMpe ??= {"r":6881395,"p":[{"n":"Menu","p":$.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                __builder3.AddAttribute$3(48, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*member*/ member) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountCard, 49);
                                        __builder4.AddComponentParameter(50, "Size", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 70), $.$$.S.Int32));
                                        __builder4.AddComponentParameter(51, "Account", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.AccountBaseModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).op_Implicit$1(member)));
                                        __builder4.CloseComponent();
                                    }, $aZRahc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                }), $LESWDg ??= {"r":6881395,"p":[{"n":"member","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                __builder3.AddAttribute$3(52, "Details", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*member*/ member) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountDetailsInApplicationDrawer, 53);
                                        __builder4.AddComponentParameter(54, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.AccountBaseModel, member.Data));
                                        __builder4.CloseComponent();
                                    }, $aAbCDh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                }), $iadjgi ??= {"r":6881395,"p":[{"n":"member","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                __builder3.AddAttribute$3(55, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 56);
                                    __builder4.AddComponentParameter(57, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `No members`));
                                    __builder4.CloseComponent();
                                }), $wCZtdc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }, $xhmKgb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                        }), $KGZTGe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        if (handler.LCCGCS$ICommunityGroupApplicationTypeHandler$SubGroupTitle !== null)
                        {
                            __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 58);
                            __builder2.AddComponentParameter(59, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$fPer.LCFCS$6.StringExtension.Pluralize(handler.LCCGCS$ICommunityGroupApplicationTypeHandler$SubGroupTitle)));
                            __builder2.AddComponentParameter(60, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 4002), $.$$.S.Int32));
                            __builder2.AddAttribute$3(61, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.AddContent$4(62, $.$fPer.LCFCS$6.StringExtension.Pluralize(handler.LCCGCS$ICommunityGroupApplicationTypeHandler$SubGroupTitle));
                                }, $pWFwLj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $jsxjIg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(63, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.AddContent$1(64, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account-group"/*MaterialDesignIconNames.AccountGroup*/), false));
                                }, $eveRuk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $qqKtXe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(65, "ToolBarChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    if (ownsGroup)
                                    {
                                        __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 66);
                                        __builder3.AddAttribute$3(67, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*_*/ _0) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                            {
                                                __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 68);
                                                __builder4.AddComponentParameter(69, "href", "CreateSubGroup");
                                                __builder4.AddComponentParameter(70, "Class", "mdi mdi-plus");
                                                __builder4.AddComponentParameter(71, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, new ($.$$.S.ValueTuple$$$$(TCommunityGroupPostModel, $.$PZCj.LCCGCM.CommunitySubGroupPostModel, $.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)))().$ctor$3(this.ViewModel, null, $.$cast(2558/*PostTypes.GroupSub*/, $.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)))));
                                                __builder4.CloseComponent();
                                            }, $IUrKjl ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                        }), $jWSGAh ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                        __builder3.CloseComponent();
                                    }
                                }, $AJerhe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $drMfeb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(72, "FloatingButtons", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    if (ownsGroup)
                                    {
                                        __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 73);
                                        __builder3.AddComponentParameter(74, "PageLink", "CreateSubGroup");
                                        __builder3.AddComponentParameter(75, "Class", "mdi mdi-plus");
                                        __builder3.AddComponentParameter(76, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                        __builder3.AddComponentParameter(77, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 132178/*ButtonFeatures.FloatingButton*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                        __builder3.AddComponentParameter(78, "PageParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, new ($.$$.S.ValueTuple$$$$(TCommunityGroupPostModel, $.$PZCj.LCCGCM.CommunitySubGroupPostModel, $.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)))().$ctor$3(this.ViewModel, null, $.$cast(2558/*PostTypes.GroupSub*/, $.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)))));
                                        __builder3.CloseComponent();
                                    }
                                }, $WZYYWc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $gwLcnc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(79, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(80, "h2");
                                    __builder3.AddAttribute$5(81, "class", "mgt-0");
                                    __builder3.AddContent$4(82, $.$fPer.LCFCS$6.StringExtension.Pluralize(handler.LCCGCS$ICommunityGroupApplicationTypeHandler$SubGroupTitle));
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(83, "\r\n                        ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$PZCj.LCCGCM.CommunitySubGroupPostModel), 84);
                                    __builder3.AddComponentParameter(85, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.ViewModel.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                                    __builder3.AddAttribute$3(86, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$PZCj.LCCGCM.CommunitySubGroupPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$PZCj.LCCGCM.CommunitySubGroupPostModel))))().$ctor(this, ( (/*subGroup*/ subGroup) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            /*var*/ let text = $.$ljzt.LCFCWM.MarkdownProcessor.ToText(subGroup.Data.Description, null);
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 87);
                                            __builder4.AddComponentParameter(88, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, subGroup.Data.Name));
                                            /*string?*/ let __ca1__;
                                            __builder4.AddComponentParameter(89, "Description", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN(((__ca1__ = text) !== null ? $.$$.S.String.Substring.call(__ca1__, 0, $.$$.S.Math.Min$4(40, text.length)) : null))}...`));
                                            __builder4.AddComponentParameter(90, "ResourceImage", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, subGroup.Data.Icon));
                                            __builder4.AddComponentParameter(91, "IconDescriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, $.$fPer.LCFC.IconDescriptor.op_Implicit(this.ResolvePath("img/branch.png", true, false, false))));
                                            __builder4.AddComponentParameter(92, "NavigateIcon", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                                            __builder4.AddComponentParameter(93, "Link", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, subGroup.Data.Link));
                                            __builder4.AddComponentParameter(94, "LinkParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, subGroup.Data));
                                            __builder4.AddComponentParameter(95, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures, 0/*DataListDefaultItemTemplateFeatures.Default*/ | 1/*DataListDefaultItemTemplateFeatures.RoundedImage*/), $.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures));
                                            __builder4.CloseComponent();
                                        }, $HXRWdf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                    }), $cprdIj ??= {"r":6881395,"p":[{"n":"subGroup","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$PZCj.LCCGCM.CommunitySubGroupPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$PZCj.LCCGCM.CommunitySubGroupPostModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(96, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 97);
                                        __builder4.AddComponentParameter(98, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `No ${$.$strNN(handler.LCCGCS$ICommunityGroupApplicationTypeHandler$SubGroupTitle)}`));
                                        __builder4.CloseComponent();
                                    }), $ekvwqe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                    __builder3.AddComponentReferenceCapture(99, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                                    {
                                        this.subGroupList = $.$cast(__value, $.$hDPm.LCFCCD$1.RemoteDataList$$($.$PZCj.LCCGCM.CommunitySubGroupPostModel));
                                    }, $PTJebd ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }, $qCfKPi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $VzLjLe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }
                    }
                    if ((handler?.LCCGCS$ICommunityGroupApplicationTypeHandler$SubGroupTitle ?? null) !== null && ownsGroup)
                    {
                        __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactory, 100);
                        __builder2.AddComponentParameter(101, "Name", "CreateSubGroup");
                        __builder2.AddComponentParameter(102, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 5051), $.$$.S.Int32));
                        __builder2.AddAttribute$3(103, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$4(104, "New ");
                                __builder3.AddContent$4(105, handler.LCCGCS$ICommunityGroupApplicationTypeHandler$SubGroupTitle);
                            }, $ilfSbe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                        }), $aqWKQb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(106, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$1(107, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-message"/*MaterialDesignIconNames.Message*/), false));
                            }, $dRbmkj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                        }), $fcvNek ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(108, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityCreate$$$($.$PZCj.LCCGCM.CommunityGroupPostModel, $.$PZCj.LCCGCM.CommunitySubGroupPostModel), 109);
                                __builder3.AddComponentParameter(110, "Parent", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.PostBaseModel, this.ViewModel));
                                __builder3.AddComponentParameter(111, "OnCreated", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$PZCj.LCCGCM.CommunitySubGroupPostModel), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$PZCj.LCCGCM.CommunitySubGroupPostModel, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$PZCj.LCCGCM.CommunitySubGroupPostModel, $.$$.STT.ValueTask))().$ctor(this, this.SubGroupCreated))));
                                __builder3.CloseComponent();
                            }, $evoqjh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                        }), $YGwIJk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                }), $fdFCVg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(51540503966)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(38655602078)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655602078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655602078)
            
            //--TRIMMABLE-BOUNDARY-START(38655602078)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(38655602078)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(146029784478)
                this.GroupHandlers = null;
                //--TRIMMABLE-BOUNDARY-END(146029784478)
                
                //--TRIMMABLE-BOUNDARY-START(154619719070)
                this.MediaProvider = null;
                //--TRIMMABLE-BOUNDARY-END(154619719070)
                
                //--TRIMMABLE-BOUNDARY-START(60130438558)
                this.ChatProvider = null;
                //--TRIMMABLE-BOUNDARY-END(60130438558)
                
                //--TRIMMABLE-BOUNDARY-START(47245536670)
                this.ArticleProvider = null;
                //--TRIMMABLE-BOUNDARY-END(47245536670)
                
                //--TRIMMABLE-BOUNDARY-START(55835471262)
                this.CalendarProvider = null;
                //--TRIMMABLE-BOUNDARY-END(55835471262)
                
                //--TRIMMABLE-BOUNDARY-START(42950569374)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(42950569374)
                
                //--TRIMMABLE-BOUNDARY-START(167504620958)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(167504620958)
                
            }
            static $H = 896414;
            static $h = 896414;
            static $g = 3;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$(TCommunityGroupPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(158914686366),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 120259980702,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 158914686366,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914686366),
//--TRIMMABLE-BOUNDARY-START(146029784478),
    {
      "p": $.$$.SCG.IEnumerable$$($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 103080111518,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 210454293918,
        "h": Number(BigInt(this.$h)|0x3100000000n),
        "f": 83886081
      },
      "n": "GroupHandlers",
      "d": this.$h,
      "H": 146029784478,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029784478),
//--TRIMMABLE-BOUNDARY-START(154619719070),
    {
      "p": 17929664,
      "g": {
        "r": 0,
        "d": 0,
        "H": 111670046110,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 219044228510,
        "h": Number(BigInt(this.$h)|0x3300000000n),
        "f": 83886081
      },
      "n": "MediaProvider",
      "d": this.$h,
      "H": 154619719070,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619719070),
//--TRIMMABLE-BOUNDARY-START(60130438558),
    {
      "p": 17405376,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94490176926,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 201864359326,
        "h": Number(BigInt(this.$h)|0x2F00000000n),
        "f": 83886081
      },
      "n": "ChatProvider",
      "d": this.$h,
      "H": 60130438558,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130438558),
//--TRIMMABLE-BOUNDARY-START(47245536670),
    {
      "p": 17274304,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77310307742,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 184684490142,
        "h": Number(BigInt(this.$h)|0x2B00000000n),
        "f": 83886081
      },
      "n": "ArticleProvider",
      "d": this.$h,
      "H": 47245536670,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245536670),
//--TRIMMABLE-BOUNDARY-START(55835471262),
    {
      "p": 17339840,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85900242334,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 193274424734,
        "h": Number(BigInt(this.$h)|0x2D00000000n),
        "f": 83886081
      },
      "n": "CalendarProvider",
      "d": this.$h,
      "H": 55835471262,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835471262),
//--TRIMMABLE-BOUNDARY-START(42950569374),
    {
      "p": 503198,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68720373150,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 176094555550,
        "h": Number(BigInt(this.$h)|0x2900000000n),
        "f": 83886081
      },
      "n": "Application",
      "d": this.$h,
      "H": 42950569374,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950569374),
//--TRIMMABLE-BOUNDARY-START(167504620958),
    {
      "p": 634270,
      "g": {
        "r": 0,
        "d": 0,
        "H": 137439849886,
        "h": Number(BigInt(this.$h)|0x2000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 236224097694,
        "h": Number(BigInt(this.$h)|0x3700000000n),
        "f": 83886081
      },
      "n": "Service",
      "d": this.$h,
      "H": 167504620958,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167504620958),
//--TRIMMABLE-BOUNDARY-START(163209653662),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 128849915294,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 227634163102,
        "h": Number(BigInt(this.$h)|0x3500000000n),
        "f": 83886081
      },
      "n": "Route",
      "d": this.$h,
      "H": 163209653662,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209653662)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(249108999582),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 249108999582,
      "h": Number(BigInt(this.$h)|0x3A00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(249108999582),
//--TRIMMABLE-BOUNDARY-START(150324751774),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": this.$h,
      "H": 150324751774,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324751774),
//--TRIMMABLE-BOUNDARY-START(141734817182),
    {
      "r": 765342,
      "n": "GetHandler",
      "d": this.$h,
      "H": 141734817182,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141734817182),
//--TRIMMABLE-BOUNDARY-START(240519064990),
    {
      "r": 181338113,
      "p": [
        {
          "n": "subGroup",
          "p": 1650598
        }
      ],
      "n": "SubGroupCreated",
      "d": this.$h,
      "H": 240519064990,
      "h": Number(BigInt(this.$h)|0x3800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(240519064990),
//--TRIMMABLE-BOUNDARY-START(51540503966),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 51540503966,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540503966)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(244814032286),
    {
      "t": $.$hDPm.LCFCCD$1.RemoteDataList$$($.$PZCj.LCCGCM.CommunitySubGroupPostModel).$h,
      "n": "subGroupList",
      "d": this.$h,
      "H": 244814032286,
      "h": Number(BigInt(this.$h)|0x3900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(244814032286)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655602078),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 38655602078,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655602078)
  ],
  "s": [
    {
      "h": TCommunityGroupPostModel?.$h??1572864,
      "n": "TCommunityGroupPostModel",
      "c": [$.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TCommunityGroupPostSettings, TCommunityGroupPostStates).$h
      ]
    },
    {
      "h": TCommunityGroupPostSettings?.$h??1638400,
      "n": "TCommunityGroupPostSettings",
      "c": [2502566
      ]
    },
    {
      "h": TCommunityGroupPostStates?.$h??1703936,
      "n": "TCommunityGroupPostStates",
      "c": [3026854
      ]
    }
  ],
  "r": 3,
  "H": 896414,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Client.Shared.CommunityGroupApplicationView<${TCommunityGroupPostModel?.$fullName},${TCommunityGroupPostSettings?.$fullName},${TCommunityGroupPostStates?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Client${separator}Shared${separator}CommunityGroupApplicationView$${TCommunityGroupPostModel?.$getFullName(separator)}$${TCommunityGroupPostSettings?.$getFullName(separator)}$${TCommunityGroupPostStates?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(896414)
        
        

        //--TRIMMABLE-BOUNDARY-START(568734)
        $asm.$cls(`$PIIp.LCCGCS.CommunityGroupFeedProvider`, ($self) => class CommunityGroupFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$PZCj.LCCGCM.CommunityGroupPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295536030)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295536030);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295536030)
            
            //--TRIMMABLE-BOUNDARY-START(8590503326)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityGroupPostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590503326);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`created their ${$.$strNN(model.TypeTitle)}`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590503326)
            
            static $h = 568734;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$PZCj.LCCGCM.CommunityGroupPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590503326),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 1191846
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 568734,
      "h": 8590503326,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590503326)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295536030),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 568734,
      "h": 4295536030,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295536030)
  ],
  "h": 568734
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Client.Services.CommunityGroupFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Client${separator}Services${separator}CommunityGroupFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(568734)
        
        

        //--TRIMMABLE-BOUNDARY-START(503198)
        $asm.$cls(`$PIIp.LCCGCS.CommunityGroupApplication`, ($self) => class CommunityGroupApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(17180372382)
            $ctor$5(/*CommunityGroupService*/ service, /*IEnumerable<ICommunityGroupApplicationTypeHandler>*/ providers)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180372382);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                    this.Providers = providers;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180372382)
            
            //--TRIMMABLE-BOUNDARY-START(184684096926)
            /*string */ get Name()
            {
                return "Group";
            }
            //--TRIMMABLE-BOUNDARY-END(184684096926)
            
            //--TRIMMABLE-BOUNDARY-START(214748867998)
            /*string */ get Title()
            {
                return "Group";
            }
            //--TRIMMABLE-BOUNDARY-END(214748867998)
            
            //--TRIMMABLE-BOUNDARY-START(34360241566)
            /*string */ get Description()
            {
                return "Organize users into groups including organizations, religious and more. Groups can be open or closed.";
            }
            //--TRIMMABLE-BOUNDARY-END(34360241566)
            
            //--TRIMMABLE-BOUNDARY-START(180389129630)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-group"/*MaterialDesignIconNames.Group*/);
            }
            //--TRIMMABLE-BOUNDARY-END(180389129630)
            
            //--TRIMMABLE-BOUNDARY-START(210453900702)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#7EA61B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(210453900702)
            
            //--TRIMMABLE-BOUNDARY-START(42950176158)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(42950176158)
            
            //--TRIMMABLE-BOUNDARY-START(21475339678)
            /*Type? */ get ApplicationViewType()
            {
                return $.$PIIp.LCCGCP.CommunityGroupApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(21475339678)
            
            //--TRIMMABLE-BOUNDARY-START(176094162334)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094162334);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$PIIp.LCCGCP.CommunityGroupApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(176094162334)
            
            //--TRIMMABLE-BOUNDARY-START(38655208862)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655208862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(38655208862)
            
            //--TRIMMABLE-BOUNDARY-START(197568998814)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568998814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(197568998814)
            
            //--TRIMMABLE-BOUNDARY-START(188979064222)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(188979064222)
            
            //--TRIMMABLE-BOUNDARY-START(4295470494)
            /*CommunityGroupService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295470494)
            
            //--TRIMMABLE-BOUNDARY-START(193274031518)
            /*IEnumerable<ICommunityGroupApplicationTypeHandler>*/ Providers = null;
            //--TRIMMABLE-BOUNDARY-END(193274031518)
            
            //--TRIMMABLE-BOUNDARY-START(201863966110)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(201863966110)
            
            //--TRIMMABLE-BOUNDARY-START(206158933406)
            /*IEnumerable<IApplicationSubService>? */ get Services()
            {
                return $.$$.N.InterfaceVarianceStubHandler.Create(this.Providers, $.$$.SCG.IEnumerable$$($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler), $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService));
            }
            //--TRIMMABLE-BOUNDARY-END(206158933406)
            
            //--TRIMMABLE-BOUNDARY-START(30065274270)
            /*string */ get CreateLink()
            {
                return "Group/New";
            }
            //--TRIMMABLE-BOUNDARY-END(30065274270)
            
            //--TRIMMABLE-BOUNDARY-START(25770306974)
            /*string */ get CreateLabel()
            {
                return "Start a Group";
            }
            //--TRIMMABLE-BOUNDARY-END(25770306974)
            
            //--TRIMMABLE-BOUNDARY-START(219043835294)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return (() =>
                {
                    //new $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes)()
                    const $t2 = $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes);
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Ranges = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.ValueTuple$$$($.$LCOv.LCFCPM$1.PostTypes, $.$LCOv.LCFCPM$1.PostTypes)), [new ($.$$.S.ValueTuple$$$($.$LCOv.LCFCPM$1.PostTypes, $.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(2304/*PostTypes.Group*/, 2559/*PostTypes.GroupEnds*/), new ($.$$.S.ValueTuple$$$($.$LCOv.LCFCPM$1.PostTypes, $.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(10240/*PostTypes.GroupThrift*/, 10243/*PostTypes.GroupThriftEnd*/)], [-1], null);
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(219043835294)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 503198;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(184684096926),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669652894,
        "f": 50364417
      },
      "n": "Name",
      "d": 503198,
      "h": 184684096926,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(184684096926),
//--TRIMMABLE-BOUNDARY-START(214748867998),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209260446,
        "f": 50364417
      },
      "n": "Title",
      "d": 503198,
      "h": 214748867998,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(214748867998),
//--TRIMMABLE-BOUNDARY-START(34360241566),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899849118,
        "f": 50364417
      },
      "n": "Description",
      "d": 503198,
      "h": 34360241566,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360241566),
//--TRIMMABLE-BOUNDARY-START(180389129630),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079718302,
        "f": 50364417
      },
      "n": "Icon",
      "d": 503198,
      "h": 180389129630,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389129630),
//--TRIMMABLE-BOUNDARY-START(210453900702),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619325854,
        "f": 50364417
      },
      "n": "Theme",
      "d": 503198,
      "h": 210453900702,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(210453900702),
//--TRIMMABLE-BOUNDARY-START(42950176158),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489783710,
        "f": 50364417
      },
      "n": "Features",
      "d": 503198,
      "h": 42950176158,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950176158),
//--TRIMMABLE-BOUNDARY-START(21475339678),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130045342,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 503198,
      "h": 21475339678,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475339678),
//--TRIMMABLE-BOUNDARY-START(188979064222),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259587486,
        "f": 50364417
      },
      "n": "Order",
      "d": 503198,
      "h": 188979064222,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(188979064222),
//--TRIMMABLE-BOUNDARY-START(4295470494),
    {
      "p": 634270,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540110750,
        "f": 50331650
      },
      "n": "_Service",
      "d": 503198,
      "h": 4295470494,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295470494),
//--TRIMMABLE-BOUNDARY-START(193274031518),
    {
      "p": $.$$.SCG.IEnumerable$$($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849522078,
        "f": 50331650
      },
      "n": "Providers",
      "d": 503198,
      "h": 193274031518,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(193274031518),
//--TRIMMABLE-BOUNDARY-START(201863966110),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439456670,
        "f": 50364417
      },
      "n": "Service",
      "d": 503198,
      "h": 201863966110,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(201863966110),
//--TRIMMABLE-BOUNDARY-START(206158933406),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029391262,
        "f": 50364417
      },
      "n": "Services",
      "d": 503198,
      "h": 206158933406,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(206158933406),
//--TRIMMABLE-BOUNDARY-START(30065274270),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309914526,
        "f": 50331649
      },
      "n": "CreateLink",
      "d": 503198,
      "h": 30065274270,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065274270),
//--TRIMMABLE-BOUNDARY-START(25770306974),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719979934,
        "f": 50331649
      },
      "n": "CreateLabel",
      "d": 503198,
      "h": 25770306974,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770306974),
//--TRIMMABLE-BOUNDARY-START(219043835294),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799195038,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 503198,
      "h": 219043835294,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(219043835294)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(176094162334),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 503198,
      "h": 176094162334,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(176094162334),
//--TRIMMABLE-BOUNDARY-START(38655208862),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 503198,
      "h": 38655208862,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655208862),
//--TRIMMABLE-BOUNDARY-START(197568998814),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 503198,
      "h": 197568998814,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197568998814)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180372382),
    {
      "p": [
        {
          "n": "service",
          "p": 634270
        },
        {
          "n": "providers",
          "p": $.$$.SCG.IEnumerable$$($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 503198,
      "h": 17180372382,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180372382)
  ],
  "h": 503198
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$PZCj.LCCGCM.CommunityGroupPostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Client.Services.CommunityGroupApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Client${separator}Services${separator}CommunityGroupApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(503198)
        
        

        //--TRIMMABLE-BOUNDARY-START(306590)
        $asm.$cls(`$PIIp.LCCGCP.CommunityGroupApp`, ($self) => class CommunityGroupApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$PZCj.LCCGCM.CommunityGroupPostModel, $.$PZCj.LCCGCM.CommunitySubGroupPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(154619129246)
            /*string */ get OptimizedComponentName()
            {
                return "communitygroupapp communitydefaultpages";
            }
            //--TRIMMABLE-BOUNDARY-END(154619129246)
            
            //--TRIMMABLE-BOUNDARY-START(150324161950)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324161950);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.GroupService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PIIp.LCCGCS.CommunityGroupService, serviceProvider);
                this.GroupApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PIIp.LCCGCS.CommunityGroupApplication, serviceProvider);
                this.GroupHandlers = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(150324161950)
            
            //--TRIMMABLE-BOUNDARY-START(146029194654)
            /*CommunityGroupService*/ GroupService = null;
            //--TRIMMABLE-BOUNDARY-END(146029194654)
            
            //--TRIMMABLE-BOUNDARY-START(137439260062)
            /*CommunityGroupApplication*/ GroupApplication = null;
            //--TRIMMABLE-BOUNDARY-END(137439260062)
            
            //--TRIMMABLE-BOUNDARY-START(141734227358)
            /*IEnumerable<ICommunityGroupApplicationTypeHandler>*/ GroupHandlers = null;
            //--TRIMMABLE-BOUNDARY-END(141734227358)
            
            //--TRIMMABLE-BOUNDARY-START(25770110366)
            /*ICommunityClientApplication */ get Application()
            {
                return this.GroupApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(25770110366)
            
            //--TRIMMABLE-BOUNDARY-START(38655012254)
            /*CommunityPostView */ get CardView()
            {
                return 3/*CommunityPostView.CardFeed*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38655012254)
            
            //--TRIMMABLE-BOUNDARY-START(42949979550)
            /*int? */ get CardWidthHint()
            {
                return 300;
            }
            //--TRIMMABLE-BOUNDARY-END(42949979550)
            
            //--TRIMMABLE-BOUNDARY-START(34360044958)
            /*int? */ get CardSpaceHint()
            {
                return 20;
            }
            //--TRIMMABLE-BOUNDARY-END(34360044958)
            
            //--TRIMMABLE-BOUNDARY-START(184683900318)
            /*UseDefaultPage */ get UsePage()
            {
                return 65535/*UseDefaultPage.Default*/ & ~4/*UseDefaultPage.CategoriesView*/ & ~8/*UseDefaultPage.CategoryView*/;
            }
            //--TRIMMABLE-BOUNDARY-END(184683900318)
            
            //--TRIMMABLE-BOUNDARY-START(133144292766)
            /*ICommunityGroupApplicationTypeHandler? */ GetHandler(/*AccountBaseModel*/ group)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144292766);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.SingleOrDefault$1($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, this.GroupHandlers, new ($.$$.S.Func$$$($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, $.$$.S.Boolean))().$ctor(this,  (/*h*/ h) =>
                    {
                        return h.LCCGCS$ICommunityGroupApplicationTypeHandler$Type === group.Type;
                    }, $ZKxnjl ??= {"r":262145,"p":[{"n":"h","p":765342}],"n":"","d":306590,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144292766)
            
            //--TRIMMABLE-BOUNDARY-START(30065077662)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065077662);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
            }
            //--TRIMMABLE-BOUNDARY-END(30065077662)
            
            //--TRIMMABLE-BOUNDARY-START(21475143070)
            /*RenderFragment */ get AppendPages()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$LCOv.LCFCPM$1.AccountBaseModel), 1);
                    __builder2.AddComponentParameter(2, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Account|User|School|Church|Organization|/${$.$strNN("***"/*RoutePath.OneOrMorePathSegment*/)}`)));
                    __builder2.AddComponentParameter(3, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, $.trunc(2147483647/*int.MaxValue*/ / 2)), $.$$.S.Int32));
                    __builder2.AddComponentParameter(4, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$LCOv.LCFCPM$1.AccountBaseModel)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~15/*CommunityLayoutFeatures.Pad*/, null, null, true);
                    }), $HVvzKb ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$LCOv.LCFCPM$1.AccountBaseModel).$h}],"n":"","d":306590,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(5, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$LCOv.LCFCPM$1.AccountBaseModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(6, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$LCOv.LCFCPM$1.AccountBaseModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.AccountBaseModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e.Title;
                            }, $CLQJxf ??= {"r":131073,"p":[{"n":"e","p":6220212}],"n":"","d":306590,"h":0,"f":17825794}), true));
                        }, $KhiPRe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":306590,"h":0,"f":17825794});
                    }), $ZxBKKh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$LCOv.LCFCPM$1.AccountBaseModel)).$h}],"n":"","d":306590,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(7, "FloatingButtons", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$LCOv.LCFCPM$1.AccountBaseModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(8, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$LCOv.LCFCPM$1.AccountBaseModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.AccountBaseModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return this.EditPostButton($.$LCOv.LCFCPM$1.AccountBaseModel, e);
                            }, $ihlZlg ??= {"r":6881395,"p":[{"n":"e","p":6220212}],"n":"","d":306590,"h":0,"f":17825794}), null, true));
                        }, $eVcuCd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":306590,"h":0,"f":17825794});
                    }), $mlQhBb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$LCOv.LCFCPM$1.AccountBaseModel)).$h}],"n":"","d":306590,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(9, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$LCOv.LCFCPM$1.AccountBaseModel))))().$ctor(this, ( (/*group*/ group) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(10, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$LCOv.LCFCPM$1.AccountBaseModel, group.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.AccountBaseModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                /*var*/ let handler = this.GetHandler(e);
                                return handler?.LCCGCS$ICommunityGroupApplicationTypeHandler$GetHomePage(e) ?? null;
                            }, $kmxcJd ??= {"r":6881395,"p":[{"n":"e","p":6220212}],"n":"","d":306590,"h":0,"f":17825794}), null, true));
                        }, $GKNuIh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":306590,"h":0,"f":17825794});
                    }), $zuQLui ??= {"r":6881395,"p":[{"n":"group","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$LCOv.LCFCPM$1.AccountBaseModel)).$h}],"n":"","d":306590,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $WksNIa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":306590,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(21475143070)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180175774)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180175774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180175774)
            
            //--TRIMMABLE-BOUNDARY-START(17180175774)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(17180175774)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(146029194654)
                this.GroupService = null;
                //--TRIMMABLE-BOUNDARY-END(146029194654)
                
                //--TRIMMABLE-BOUNDARY-START(137439260062)
                this.GroupApplication = null;
                //--TRIMMABLE-BOUNDARY-END(137439260062)
                
                //--TRIMMABLE-BOUNDARY-START(141734227358)
                this.GroupHandlers = null;
                //--TRIMMABLE-BOUNDARY-END(141734227358)
                
            }
            static $h = 306590;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$PZCj.LCCGCM.CommunityGroupPostModel, $.$PZCj.LCCGCM.CommunitySubGroupPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(154619129246),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259390878,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 306590,
      "h": 154619129246,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619129246),
//--TRIMMABLE-BOUNDARY-START(146029194654),
    {
      "p": 634270,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669456286,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180388933022,
        "f": 83886081
      },
      "n": "GroupService",
      "d": 306590,
      "h": 146029194654,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029194654),
//--TRIMMABLE-BOUNDARY-START(137439260062),
    {
      "p": 503198,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489587102,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209063838,
        "f": 83886081
      },
      "n": "GroupApplication",
      "d": 306590,
      "h": 137439260062,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439260062),
//--TRIMMABLE-BOUNDARY-START(141734227358),
    {
      "p": $.$$.SCG.IEnumerable$$($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079521694,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171798998430,
        "f": 83886081
      },
      "n": "GroupHandlers",
      "d": 306590,
      "h": 141734227358,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141734227358),
//--TRIMMABLE-BOUNDARY-START(25770110366),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129848734,
        "f": 50364420
      },
      "n": "Application",
      "d": 306590,
      "h": 25770110366,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(25770110366),
//--TRIMMABLE-BOUNDARY-START(38655012254),
    {
      "p": 31299008,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309717918,
        "f": 50364420
      },
      "n": "CardView",
      "d": 306590,
      "h": 38655012254,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(38655012254),
//--TRIMMABLE-BOUNDARY-START(42949979550),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899652510,
        "f": 50364420
      },
      "n": "CardWidthHint",
      "d": 306590,
      "h": 42949979550,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(42949979550),
//--TRIMMABLE-BOUNDARY-START(34360044958),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719783326,
        "f": 50364420
      },
      "n": "CardSpaceHint",
      "d": 306590,
      "h": 34360044958,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(34360044958),
//--TRIMMABLE-BOUNDARY-START(184683900318),
    {
      "p": 34379200,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849325470,
        "f": 50364420
      },
      "n": "UsePage",
      "d": 306590,
      "h": 184683900318,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(184683900318),
//--TRIMMABLE-BOUNDARY-START(21475143070),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539914142,
        "f": 50364420
      },
      "n": "AppendPages",
      "d": 306590,
      "h": 21475143070,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(21475143070)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(150324161950),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 306590,
      "h": 150324161950,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324161950),
//--TRIMMABLE-BOUNDARY-START(133144292766),
    {
      "r": 765342,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetHandler",
      "d": 306590,
      "h": 133144292766,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133144292766),
//--TRIMMABLE-BOUNDARY-START(30065077662),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 306590,
      "h": 30065077662,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30065077662)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180175774),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 306590,
      "h": 17180175774,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180175774)
  ],
  "h": 306590
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Client.Pages.CommunityGroupApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Client${separator}Pages${separator}CommunityGroupApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(306590)
        
        

        //--TRIMMABLE-BOUNDARY-START(634270)
        $asm.$cls(`$PIIp.LCCGCS.CommunityGroupService`, ($self) => class CommunityGroupService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$PZCj.LCCGCM.CommunityGroupPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295601566)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295601566);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295601566)
            
            static $h = 634270;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$PZCj.LCCGCM.CommunityGroupPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295601566),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 634270,
      "h": 4295601566,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295601566)
  ],
  "h": 634270
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$PZCj.LCCGCM.CommunityGroupPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$PZCj.LCCGCM.CommunityGroupPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Client.Services.CommunityGroupService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Client${separator}Services${separator}CommunityGroupService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(634270)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Account.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Account.Client.Blazor", "NetJs.LivingThing.Core.Community.Group.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(44446)
