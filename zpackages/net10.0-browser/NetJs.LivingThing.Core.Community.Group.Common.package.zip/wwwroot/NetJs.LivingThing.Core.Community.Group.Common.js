
//--TRIMMABLE-BOUNDARY-START(12198)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $PjAfug;
    let $jsYnYh;
    let $EbCgbl;
    let $ttktVa;
    let $JtWOBg;
    let $GNqohj;
    let $xzPryi;
    let $FrPcDb;
    let $xVojLf;
    let $tMMrDf;
    let $yZdUBg;
    let $RixGZd;
    let $bstmmb;
    let $uSKtLj;
    let $qbSrOa;
    let $gTzMaf;
    let $npiZSb;
    let $NYvMrc;
    let $dZdUwa;
    let $gfTzUb;
    let $JvZBZg;
    let $gzSpHe;
    let $JiIgFj;
    let $liDyMi;
    let $ujRhGc;
    let $WFVIrk;
    let $BFbMzi;
    let $ghknKk;
    let $Vutyid;
    let $GYLtDe;
    let $uATRFc;
    let $dQrcua;
    let $famApe;
    let $Xsijzj;
    let $tDkJuj;
    let $NwCGTk;
    let $YiRyge;
    let $lswLDd;
    let $HOXjeh;
    let $qEhqMi;
    let $QwGBCf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Group.Common", 
    {
  "h": 12198,
  "f": "LivingThing.Core.Community.Group.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Group.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Group.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1912742)
        $asm.$cls(`$PZCj.LCCGCM.ICommunityGroupFeatureProvider`, ($self) => class ICommunityGroupFeatureProvider
        {
            static $h = 1912742;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1912742
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IAccountFeatureProvider, $.$LCOv.LCFCPS.IPostFeatureProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.ICommunityGroupFeatureProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}ICommunityGroupFeatureProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1912742)
        
        

        //--TRIMMABLE-BOUNDARY-START(1978278)
        $asm.$cls(`$PZCj.LCCGCM.ICommunityGroupFeatureProvider<>`, (TFeatureModel) => $asm.$gt(`$PZCj.LCCGCM.ICommunityGroupFeatureProvider<>`, [TFeatureModel], ($self) => class ICommunityGroupFeatureProvider$$
        {
            static $H = 1978278;
            static $h = 1978278;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "s": [
    {
      "h": TFeatureModel?.$h??1572864,
      "n": "TFeatureModel",
      "f": 4,
      "c": [$.$LCOv.LCFCPM$1.AccountFeatureModel$$(TFeatureModel).$h,$.$fPer.LCFCD.IDataFeatureModel$$(TFeatureModel).$h
      ]
    }
  ],
  "r": 1,
  "H": 1978278,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$PZCj.LCCGCM.ICommunityGroupFeatureProvider, $.$LCOv.LCFCPS.IAccountFeatureProvider$$(TFeatureModel), $.$LCOv.LCFCPS.IPostFeatureProvider$$(TFeatureModel), $.$LCOv.LCFCPS.IAccountFeatureProvider, $.$LCOv.LCFCPS.IPostFeatureProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.ICommunityGroupFeatureProvider<${TFeatureModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}ICommunityGroupFeatureProvider$${TFeatureModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1978278)
        
        

        //--TRIMMABLE-BOUNDARY-START(2043814)
        $asm.$cls(`$PZCj.LCCGCM.ICommunityGroupModel`, ($self) => class ICommunityGroupModel
        {
            static $h = 2043814;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2043814
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostReactable, $.$LCOv.LCFCP.IPostSharable, $.$LCOv.LCFCP.IPostViewTrackable, $.$LCOv.LCFCP.IPostApplicationScope, $.$LCOv.LCFCP.IGroupAccountModel, $.$LCOv.LCFCP.IUserAccountModel, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.ICommunityGroupModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}ICommunityGroupModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2043814)
        
        

        //--TRIMMABLE-BOUNDARY-START(602022)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupMemberFeatureModel<>`, (TSelf) => $asm.$gt(`$PZCj.LCCGCM.CommunityGroupMemberFeatureModel<>`, [TSelf], ($self) => class CommunityGroupMemberFeatureModel$$ extends $.$LCOv.LCFCPM.AccountMembershipFeatureModel$$(TSelf)
        {
            //--TRIMMABLE-BOUNDARY-START(4295569318)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295569318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295569318)
            
            //--TRIMMABLE-BOUNDARY-START(4295569318)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295569318)
            
            static $H = 602022;
            static $h = 602022;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM.AccountMembershipFeatureModel$$(TSelf); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295569318),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": this.$h,
      "H": 4295569318,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295569318)
  ],
  "s": [
    {
      "h": TSelf?.$h??1572864,
      "n": "TSelf",
      "c": [$.$LCOv.LCFCPM.IAccountMembershipFeatureModel$$(TSelf).$h
      ]
    }
  ],
  "r": 1,
  "H": 602022,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.IPropertyDescriptorNotify ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupMemberFeatureModel<${TSelf?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupMemberFeatureModel$${TSelf?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(602022)
        
        

        //--TRIMMABLE-BOUNDARY-START(1716134)
        $asm.$cls(`$PZCj.LCCGCM.CommunitySubGroupPostModelCustomAttributesProvider`, ($self) => class CommunitySubGroupPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296683430)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296683430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCM.CommunityGroupPostModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296683430)
            
            static $h = 1716134;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296683430),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1716134,
      "h": 4296683430,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296683430)
  ],
  "h": 1716134
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunitySubGroupPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunitySubGroupPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1716134)
        
        

        //--TRIMMABLE-BOUNDARY-START(3354534)
        $asm.$cls(`$PZCj.LCCGCS$2.CommunityGroupServiceStatesCustomAttributesProvider`, ($self) => class CommunityGroupServiceStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298321830)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298321830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ServiceStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298321830)
            
            static $h = 3354534;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298321830),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3354534,
      "h": 4298321830,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298321830)
  ],
  "h": 3354534
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.States.CommunityGroupServiceStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}States${separator}CommunityGroupServiceStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3354534)
        
        

        //--TRIMMABLE-BOUNDARY-START(2109350)
        $asm.$cls(`$PZCj.LCCGCM.ICommunityGroupModelCustomAttributesProvider`, ($self) => class ICommunityGroupModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297076646)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297076646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297076646)
            
            static $h = 2109350;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297076646),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2109350,
      "h": 4297076646,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297076646)
  ],
  "h": 2109350
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.ICommunityGroupModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}ICommunityGroupModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2109350)
        
        

        //--TRIMMABLE-BOUNDARY-START(3092390)
        $asm.$cls(`$PZCj.LCCGCS$2.CommunityGroupPostStatesCustomAttributesProvider`, ($self) => class CommunityGroupPostStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298059686)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298059686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPS$2.AccountStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298059686)
            
            static $h = 3092390;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298059686),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3092390,
      "h": 4298059686,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298059686)
  ],
  "h": 3092390
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.States.CommunityGroupPostStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}States${separator}CommunityGroupPostStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3092390)
        
        

        //--TRIMMABLE-BOUNDARY-START(995238)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupModelCustomAttributesProvider`, ($self) => class CommunityGroupModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295962534)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295962534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$PZCj.LCCGCS$1.CommunityGroupServiceSettings, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295962534)
            
            static $h = 995238;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295962534),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 995238,
      "h": 4295962534,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295962534)
  ],
  "h": 995238
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(995238)
        
        

        //--TRIMMABLE-BOUNDARY-START(2568102)
        $asm.$cls(`$PZCj.LCCGCS$1.CommunityGroupPostSettingsCustomAttributesProvider`, ($self) => class CommunityGroupPostSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297535398)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297535398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPS$1.AccountSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297535398)
            
            static $h = 2568102;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297535398),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2568102,
      "h": 4297535398,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297535398)
  ],
  "h": 2568102
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Settings.CommunityGroupPostSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Settings${separator}CommunityGroupPostSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2568102)
        
        

        //--TRIMMABLE-BOUNDARY-START(1585062)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupVisibilityCustomAttributesProvider`, ($self) => class CommunityGroupVisibilityCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296552358)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296552358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296552358)
            
            static $h = 1585062;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296552358),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1585062,
      "h": 4296552358,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296552358)
  ],
  "h": 1585062
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupVisibilityCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupVisibilityCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1585062)
        
        

        //--TRIMMABLE-BOUNDARY-START(143270)
        $asm.$cls(`$PZCj.LCCGC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295110566)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295110566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295110566)
            
            static $h = 143270;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295110566),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 143270,
      "h": 4295110566,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295110566)
  ],
  "h": 143270
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(143270)
        
        

        //--TRIMMABLE-BOUNDARY-START(77734)
        $asm.$cls(`$PZCj.LCCGC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295045030)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295045030);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PZCj.LCCGCM.CommunityGroupModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PZCj.LCCGCM.CommunityGroupModelCustomAttributesProvider, $.$PZCj.LCCGCM.CommunityGroupModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PZCj.LCCGCM.CommunityGroupPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PZCj.LCCGCM.CommunityGroupPostModelCustomAttributesProvider, $.$PZCj.LCCGCM.CommunityGroupPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PZCj.LCCGCM.CommunityGroupVisibility.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PZCj.LCCGCM.CommunityGroupVisibilityCustomAttributesProvider, $.$PZCj.LCCGCM.CommunityGroupVisibilityCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PZCj.LCCGCM.CommunitySubGroupPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PZCj.LCCGCM.CommunitySubGroupPostModelCustomAttributesProvider, $.$PZCj.LCCGCM.CommunitySubGroupPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PZCj.LCCGCM.ICommunityGroupModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PZCj.LCCGCM.ICommunityGroupModelCustomAttributesProvider, $.$PZCj.LCCGCM.ICommunityGroupModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PZCj.LCCGCS$1.CommunityGroupPostSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PZCj.LCCGCS$1.CommunityGroupPostSettingsCustomAttributesProvider, $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PZCj.LCCGCS$1.CommunityGroupServiceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsCustomAttributesProvider, $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PZCj.LCCGCS$2.CommunityGroupPostStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PZCj.LCCGCS$2.CommunityGroupPostStatesCustomAttributesProvider, $.$PZCj.LCCGCS$2.CommunityGroupPostStatesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PZCj.LCCGCS$2.CommunityGroupServiceStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PZCj.LCCGCS$2.CommunityGroupServiceStatesCustomAttributesProvider, $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295045030)
            
            static $h = 77734;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295045030),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 77734,
      "h": 4295045030,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295045030)
  ],
  "h": 77734
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(77734)
        
        

        //--TRIMMABLE-BOUNDARY-START(667558)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupMemberFeatureModelCustomAttributesProvider<>`, (TSelf) => $asm.$gt(`$PZCj.LCCGCM.CommunityGroupMemberFeatureModelCustomAttributesProvider<>`, [TSelf], ($self) => class CommunityGroupMemberFeatureModelCustomAttributesProvider$$
        {
            //--TRIMMABLE-BOUNDARY-START(4295634854)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295634854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM.AccountMembershipFeatureModelCustomAttributesProvider$$(TSelf).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295634854)
            
            static $H = 667558;
            static $h = 667558;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295634854),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": this.$h,
      "H": 4295634854,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295634854)
  ],
  "s": [
    {
      "h": TSelf?.$h??1572864,
      "n": "TSelf",
      "c": [$.$LCOv.LCFCPM.IAccountMembershipFeatureModel$$(TSelf).$h
      ]
    }
  ],
  "r": 1,
  "H": 667558,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupMemberFeatureModelCustomAttributesProvider<${TSelf?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupMemberFeatureModelCustomAttributesProvider$${TSelf?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(667558)
        
        

        //--TRIMMABLE-BOUNDARY-START(2830246)
        $asm.$cls(`$PZCj.LCCGCS$1.CommunityGroupServiceSettingsCustomAttributesProvider`, ($self) => class CommunityGroupServiceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297797542)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297797542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ServiceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297797542)
            
            static $h = 2830246;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297797542),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2830246,
      "h": 4297797542,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297797542)
  ],
  "h": 2830246
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Settings.CommunityGroupServiceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Settings${separator}CommunityGroupServiceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2830246)
        
        

        //--TRIMMABLE-BOUNDARY-START(733094)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupMemberFeatureModelCustomAttributesProviderRegistrar1`, ($self) => class CommunityGroupMemberFeatureModelCustomAttributesProviderRegistrar1
        {
            //--TRIMMABLE-BOUNDARY-START(4295700390)
            static /*void */ AddGeneratedFastAttributesOfCommunityGroupMemberFeatureModel(TSelf, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295700390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$(TSelf).$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PZCj.LCCGCM.CommunityGroupMemberFeatureModelCustomAttributesProvider$$(TSelf), $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModelCustomAttributesProvider$$(TSelf).GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295700390)
            
            static $h = 733094;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295700390),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TSelf"
      ],
      "n": "AddGeneratedFastAttributesOfCommunityGroupMemberFeatureModel",
      "d": 733094,
      "h": 4295700390,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4295700390)
  ],
  "h": 733094
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupMemberFeatureModelCustomAttributesProviderRegistrar1`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupMemberFeatureModelCustomAttributesProviderRegistrar1`; }
        });
        //--TRIMMABLE-BOUNDARY-END(733094)
        
        

        //--TRIMMABLE-BOUNDARY-START(1847206)
        $asm.$cls(`$PZCj.LCCGCM.CommunitySubGroupPostModelTypeDescriptorBuilder`, ($self) => class CommunitySubGroupPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591781798)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591781798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PZCj.LCCGCM.CommunitySubGroupPostModelTypeDescriptor()
                        const $t1 = $.$PZCj.LCCGCM.CommunitySubGroupPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.Common.Models.CommunitySubGroupPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $qbSrOa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1847206,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PZCj.LCCGCM.CommunitySubGroupPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591781798)
            
            //--TRIMMABLE-BOUNDARY-START(4296814502)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296814502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296814502)
            
            //--TRIMMABLE-BOUNDARY-START(4296814502)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296814502)
            
            static $h = 1847206;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591781798),
    {
      "r": 65537,
      "n": "Register",
      "d": 1847206,
      "h": 8591781798,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591781798)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296814502),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1847206,
      "h": 4296814502,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296814502)
  ],
  "h": 1847206
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunitySubGroupPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunitySubGroupPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1847206)
        
        

        //--TRIMMABLE-BOUNDARY-START(1388454)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupPostModelTypeDescriptorBuilder`, ($self) => class CommunityGroupPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591323046)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591323046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PZCj.LCCGCM.CommunityGroupPostModelTypeDescriptor()
                        const $t1 = $.$PZCj.LCCGCM.CommunityGroupPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $xVojLf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1388454,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PZCj.LCCGCM.CommunityGroupPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591323046)
            
            //--TRIMMABLE-BOUNDARY-START(4296355750)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296355750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296355750)
            
            //--TRIMMABLE-BOUNDARY-START(4296355750)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296355750)
            
            static $h = 1388454;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591323046),
    {
      "r": 65537,
      "n": "Register",
      "d": 1388454,
      "h": 8591323046,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591323046)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296355750),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1388454,
      "h": 4296355750,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296355750)
  ],
  "h": 1388454
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1388454)
        
        

        //--TRIMMABLE-BOUNDARY-START(339878)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupBasePostModelCustomAttributesProvider<,>`, (TGroupPostSettings, TGroupPostStates) => $asm.$gt(`$PZCj.LCCGCM.CommunityGroupBasePostModelCustomAttributesProvider<,>`, [TGroupPostSettings, TGroupPostStates], ($self) => class CommunityGroupBasePostModelCustomAttributesProvider$$$
        {
            //--TRIMMABLE-BOUNDARY-START(4295307174)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295307174)
            
            //--TRIMMABLE-BOUNDARY-START(8590274470)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590274470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$PZCj.LCCGCM.CommunityGroupBasePostModelCustomAttributesProvider$$$(TGroupPostSettings, TGroupPostStates).compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(5, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i3.Description = "Zoey Group allows users in the community to self organize. Some group types also has specific application that allows creator to manage members.";
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Type", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SetType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (1);
                            $i5.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            $i5.Description = "Group specific usage type";
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=SourceBranch"], [-1], null);
                            $i5.OptionsReader = ($.$PZCj.LCCGCM.CommunityGroupTypeSchemaReader.$type);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Visibility", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (2);
                            $i6.Description = "How will user join this group";
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=GoogleLens"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CanFollow", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$PZCj.LCCGCM.CommunityGroupBasePostModelCustomAttributesProvider$$$(TGroupPostSettings, TGroupPostStates).compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $bstmmb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $uSKtLj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.AccountBaseModelCustomAttributesProvider$$$(TGroupPostSettings, TGroupPostStates).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590274470)
            
            static $H = 339878;
            static $h = 339878;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590274470),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": this.$h,
      "H": 8590274470,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590274470)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295307174),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": this.$h,
      "H": 4295307174,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295307174)
  ],
  "s": [
    {
      "h": TGroupPostSettings?.$h??1572864,
      "n": "TGroupPostSettings",
      "c": [2502566
      ]
    },
    {
      "h": TGroupPostStates?.$h??1638400,
      "n": "TGroupPostStates",
      "c": [3026854
      ]
    }
  ],
  "r": 2,
  "H": 339878,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModelCustomAttributesProvider<${TGroupPostSettings?.$fullName},${TGroupPostStates?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupBasePostModelCustomAttributesProvider$${TGroupPostSettings?.$getFullName(separator)}$${TGroupPostStates?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(339878)
        
        

        //--TRIMMABLE-BOUNDARY-START(3223462)
        $asm.$cls(`$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptorBuilder`, ($self) => class CommunityGroupPostStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593158054)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593158054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptor()
                        const $t1 = $.$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.Common.States.CommunityGroupPostStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $EbCgbl ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3223462,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PZCj.LCCGCS$2.CommunityGroupPostStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593158054)
            
            //--TRIMMABLE-BOUNDARY-START(4298190758)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298190758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298190758)
            
            //--TRIMMABLE-BOUNDARY-START(4298190758)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298190758)
            
            static $h = 3223462;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593158054),
    {
      "r": 65537,
      "n": "Register",
      "d": 3223462,
      "h": 8593158054,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593158054)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298190758),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3223462,
      "h": 4298190758,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298190758)
  ],
  "h": 3223462
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.States.CommunityGroupPostStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}States${separator}CommunityGroupPostStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3223462)
        
        

        //--TRIMMABLE-BOUNDARY-START(864166)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupMemberFeatureModelTypeDescriptorBuilder<>`, (TSelf) => $asm.$gt(`$PZCj.LCCGCM.CommunityGroupMemberFeatureModelTypeDescriptorBuilder<>`, [TSelf], ($self) => class CommunityGroupMemberFeatureModelTypeDescriptorBuilder$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590798758)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590798758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModelTypeDescriptor$$(TSelf)()
                        const $t1 = $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModelTypeDescriptor$$(TSelf);
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.Common.Models.CommunityGroupMemberFeatureModel<TSelf>");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $JtWOBg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$(TSelf).$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590798758)
            
            //--TRIMMABLE-BOUNDARY-START(4295831462)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295831462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295831462)
            
            //--TRIMMABLE-BOUNDARY-START(4295831462)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295831462)
            
            static $H = 864166;
            static $h = 864166;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590798758),
    {
      "r": 65537,
      "n": "Register",
      "d": this.$h,
      "H": 8590798758,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590798758)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295831462),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295831462,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295831462)
  ],
  "s": [
    {
      "h": TSelf?.$h??1572864,
      "n": "TSelf",
      "c": [$.$LCOv.LCFCPM.IAccountMembershipFeatureModel$$(TSelf).$h
      ]
    }
  ],
  "r": 1,
  "H": 864166,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupMemberFeatureModelTypeDescriptorBuilder<${TSelf?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupMemberFeatureModelTypeDescriptorBuilder$${TSelf?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(864166)
        
        

        //--TRIMMABLE-BOUNDARY-START(2961318)
        $asm.$cls(`$PZCj.LCCGCS$1.CommunityGroupServiceSettingsTypeDescriptorBuilder`, ($self) => class CommunityGroupServiceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592895910)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592895910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsTypeDescriptor()
                        const $t1 = $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.Common.Settings.CommunityGroupServiceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $PjAfug ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2961318,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PZCj.LCCGCS$1.CommunityGroupServiceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592895910)
            
            //--TRIMMABLE-BOUNDARY-START(4297928614)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297928614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297928614)
            
            //--TRIMMABLE-BOUNDARY-START(4297928614)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297928614)
            
            static $h = 2961318;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592895910),
    {
      "r": 65537,
      "n": "Register",
      "d": 2961318,
      "h": 8592895910,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592895910)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297928614),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2961318,
      "h": 4297928614,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297928614)
  ],
  "h": 2961318
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Settings.CommunityGroupServiceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Settings${separator}CommunityGroupServiceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2961318)
        
        

        //--TRIMMABLE-BOUNDARY-START(1126310)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupModelTypeDescriptorBuilder`, ($self) => class CommunityGroupModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591060902)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591060902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PZCj.LCCGCM.CommunityGroupModelTypeDescriptor()
                        const $t1 = $.$PZCj.LCCGCM.CommunityGroupModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.Common.Models.CommunityGroupModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $yZdUBg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1126310,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PZCj.LCCGCM.CommunityGroupModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591060902)
            
            //--TRIMMABLE-BOUNDARY-START(4296093606)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296093606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296093606)
            
            //--TRIMMABLE-BOUNDARY-START(4296093606)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296093606)
            
            static $h = 1126310;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591060902),
    {
      "r": 65537,
      "n": "Register",
      "d": 1126310,
      "h": 8591060902,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591060902)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296093606),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1126310,
      "h": 4296093606,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296093606)
  ],
  "h": 1126310
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1126310)
        
        

        //--TRIMMABLE-BOUNDARY-START(3551142)
        $asm.$cls(`$PZCj.LCCGC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298518438)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298518438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCD$1.SystemTypeDescriptor.RegisterLazyTypeDescriptorRegistrar($.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$().$type, new ($.$$.S.Action$$($.$typeArray($.$$.S.Type)))().$ctor(this,  (/*types*/ types) =>
                {
                    return $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptorBuilder$$$().$type.MakeGenericType(types).GetMethod$9("Register", 8/*System.Reflection.BindingFlags.Static*/ | 16/*System.Reflection.BindingFlags.Public*/).Invoke(null, null);
                }, $xzPryi ??= {"r":65537,"p":[{"n":"types","p":$.$typeArray($.$$.S.Type).$h}],"n":"","d":3551142,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.RegisterLazyTypeDescriptorRegistrar($.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$().$type, new ($.$$.S.Action$$($.$typeArray($.$$.S.Type)))().$ctor(this,  (/*types*/ types) =>
                {
                    return $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModelTypeDescriptorBuilder$$().$type.MakeGenericType(types).GetMethod$9("Register", 8/*System.Reflection.BindingFlags.Static*/ | 16/*System.Reflection.BindingFlags.Public*/).Invoke(null, null);
                }, $FrPcDb ??= {"r":65537,"p":[{"n":"types","p":$.$typeArray($.$$.S.Type).$h}],"n":"","d":3551142,"h":0,"f":17825794}));
                $.$PZCj.LCCGCM.CommunityGroupModelTypeDescriptorBuilder.Register();
                $.$PZCj.LCCGCM.CommunityGroupPostModelTypeDescriptorBuilder.Register();
                $.$PZCj.LCCGCM.CommunitySubGroupPostModelTypeDescriptorBuilder.Register();
                $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptorBuilder.Register();
                $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsTypeDescriptorBuilder.Register();
                $.$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptorBuilder.Register();
                $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298518438)
            
            static $h = 3551142;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298518438),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3551142,
      "h": 4298518438,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298518438)
  ],
  "h": 3551142
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3551142)
        
        

        //--TRIMMABLE-BOUNDARY-START(208806)
        $asm.$cls(`$PZCj.LCCGC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295176102)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295176102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$PZCj.LCCGCS.ICommunityGroupFeedRemoteService, $.$PZCj.LCCGCS.ICommunityGroupFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$PZCj.LCCGCS.ICommunityGroupFeedRemoteService_Mocking().$ctor$3(impl);
                }, $gfTzUb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":208806,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$PZCj.LCCGCS.ICommunityGroupFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$PZCj.LCCGCS.ICommunityGroupFeedRemoteService_Mocking().$ctor$3(impl);
                }, $JvZBZg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":208806,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$PZCj.LCCGCS.IComunityGroupRemoteService, $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking().$ctor$3(impl);
                }, $gzSpHe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":208806,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking().$ctor$3(impl);
                }, $JiIgFj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":208806,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking().$ctor$3(impl);
                }, $liDyMi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":208806,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking().$ctor$3(impl);
                }, $ujRhGc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":208806,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking().$ctor$3(impl);
                }, $WFVIrk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":208806,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking().$ctor$3(impl);
                }, $BFbMzi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":208806,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking().$ctor$3(impl);
                }, $ghknKk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":208806,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking().$ctor$3(impl);
                }, $Vutyid ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":208806,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295176102)
            
            static $h = 208806;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295176102),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 208806,
      "h": 4295176102,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295176102)
  ],
  "h": 208806
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(208806)
        
        

        //--TRIMMABLE-BOUNDARY-START(2699174)
        $asm.$cls(`$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptorBuilder`, ($self) => class CommunityGroupPostSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592633766)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592633766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptor()
                        const $t1 = $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.Common.Settings.CommunityGroupPostSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $NYvMrc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2699174,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PZCj.LCCGCS$1.CommunityGroupPostSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592633766)
            
            //--TRIMMABLE-BOUNDARY-START(4297666470)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297666470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297666470)
            
            //--TRIMMABLE-BOUNDARY-START(4297666470)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297666470)
            
            static $h = 2699174;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592633766),
    {
      "r": 65537,
      "n": "Register",
      "d": 2699174,
      "h": 8592633766,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592633766)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297666470),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2699174,
      "h": 4297666470,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297666470)
  ],
  "h": 2699174
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Settings.CommunityGroupPostSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Settings${separator}CommunityGroupPostSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2699174)
        
        

        //--TRIMMABLE-BOUNDARY-START(1257382)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupPostModelCustomAttributesProvider`, ($self) => class CommunityGroupPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296224678)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296224678)
            
            //--TRIMMABLE-BOUNDARY-START(8591191974)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591191974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$PZCj.LCCGCM.CommunityGroupPostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i3.Description = "Zoey Group allows users in the community to self organize. Some group types also has specific application that allows creator to manage members.";
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i4 = new $t4();
                        $i4.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i4.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute), [(() =>
                        {
                            //new $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute()
                            const $t5 = $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$2();
                            $i5.SettingsType = ($.$PZCj.LCCGCS$1.CommunityGroupPostSettings.$type);
                            $i5.StateType = ($.$PZCj.LCCGCS$2.CommunityGroupPostStates.$type);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i4;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$PZCj.LCCGCM.CommunityGroupPostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $GYLtDe ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1257382,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $uATRFc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1257382,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$PZCj.LCCGCM.CommunityGroupBasePostModelCustomAttributesProvider$$$($.$PZCj.LCCGCS$1.CommunityGroupPostSettings, $.$PZCj.LCCGCS$2.CommunityGroupPostStates).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591191974)
            
            static $h = 1257382;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591191974),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1257382,
      "h": 8591191974,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591191974)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296224678),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1257382,
      "h": 4296224678,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296224678)
  ],
  "h": 1257382
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1257382)
        
        

        //--TRIMMABLE-BOUNDARY-START(536486)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptorBuilder<,>`, (TGroupPostSettings, TGroupPostStates) => $asm.$gt(`$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptorBuilder<,>`, [TGroupPostSettings, TGroupPostStates], ($self) => class CommunityGroupBasePostModelTypeDescriptorBuilder$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590471078)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590471078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$(TGroupPostSettings, TGroupPostStates)()
                        const $t1 = $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$(TGroupPostSettings, TGroupPostStates);
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel<TGroupPostSettings, TGroupPostStates>");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Xsijzj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates).$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590471078)
            
            //--TRIMMABLE-BOUNDARY-START(4295503782)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295503782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295503782)
            
            //--TRIMMABLE-BOUNDARY-START(4295503782)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295503782)
            
            static $H = 536486;
            static $h = 536486;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590471078),
    {
      "r": 65537,
      "n": "Register",
      "d": this.$h,
      "H": 8590471078,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590471078)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295503782),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295503782,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295503782)
  ],
  "s": [
    {
      "h": TGroupPostSettings?.$h??1572864,
      "n": "TGroupPostSettings",
      "c": [2502566
      ]
    },
    {
      "h": TGroupPostStates?.$h??1638400,
      "n": "TGroupPostStates",
      "c": [3026854
      ]
    }
  ],
  "r": 2,
  "H": 536486,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModelTypeDescriptorBuilder<${TGroupPostSettings?.$fullName},${TGroupPostStates?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupBasePostModelTypeDescriptorBuilder$${TGroupPostSettings?.$getFullName(separator)}$${TGroupPostStates?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(536486)
        
        

        //--TRIMMABLE-BOUNDARY-START(405414)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupBasePostModelCustomAttributesProviderRegistrar2`, ($self) => class CommunityGroupBasePostModelCustomAttributesProviderRegistrar2
        {
            //--TRIMMABLE-BOUNDARY-START(4295372710)
            static /*void */ AddGeneratedFastAttributesOfCommunityGroupBasePostModel(TGroupPostSettings, TGroupPostStates, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295372710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates).$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PZCj.LCCGCM.CommunityGroupBasePostModelCustomAttributesProvider$$$(TGroupPostSettings, TGroupPostStates), $.$PZCj.LCCGCM.CommunityGroupBasePostModelCustomAttributesProvider$$$(TGroupPostSettings, TGroupPostStates).GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295372710)
            
            static $h = 405414;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295372710),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TGroupPostSettings",
        "TGroupPostStates"
      ],
      "n": "AddGeneratedFastAttributesOfCommunityGroupBasePostModel",
      "d": 405414,
      "h": 4295372710,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4295372710)
  ],
  "h": 405414
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModelCustomAttributesProviderRegistrar2`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupBasePostModelCustomAttributesProviderRegistrar2`; }
        });
        //--TRIMMABLE-BOUNDARY-END(405414)
        
        

        //--TRIMMABLE-BOUNDARY-START(3485606)
        $asm.$cls(`$PZCj.LCCGCS$2.CommunityGroupServiceStatesTypeDescriptorBuilder`, ($self) => class CommunityGroupServiceStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593420198)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593420198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesTypeDescriptor()
                        const $t1 = $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.Common.States.CommunityGroupServiceStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dQrcua ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3485606,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PZCj.LCCGCS$2.CommunityGroupServiceStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593420198)
            
            //--TRIMMABLE-BOUNDARY-START(4298452902)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298452902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298452902)
            
            //--TRIMMABLE-BOUNDARY-START(4298452902)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298452902)
            
            static $h = 3485606;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593420198),
    {
      "r": 65537,
      "n": "Register",
      "d": 3485606,
      "h": 8593420198,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593420198)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298452902),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3485606,
      "h": 4298452902,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298452902)
  ],
  "h": 3485606
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.States.CommunityGroupServiceStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}States${separator}CommunityGroupServiceStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3485606)
        
        

        //--TRIMMABLE-BOUNDARY-START(2174886)
        $asm.$cls(`$PZCj.LCCGC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592109478)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592109478);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$PZCj.LCCGCM.CommunityGroupPostModel, 2304/*PostTypes.Group*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$PZCj.LCCGCM.CommunitySubGroupPostModel, 2558/*PostTypes.GroupSub*/);
                $.$PZCj.LCCGC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$PZCj.LCCGC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$PZCj.LCCGC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592109478)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297142182)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297142182);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297142182)
            
            //--TRIMMABLE-BOUNDARY-START(4297142182)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297142182)
            
            static $h = 2174886;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592109478),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2174886,
      "h": 8592109478,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592109478)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297142182),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2174886,
      "h": 4297142182,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297142182)
  ],
  "h": 2174886
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2174886)
        
        

        //--TRIMMABLE-BOUNDARY-START(1519526)
        $asm.$str(`$PZCj.LCCGCM.CommunityGroupVisibility`, ($self) => class CommunityGroupVisibility extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Public = 0;
            static ByInvitation = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1519526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Public": 0n,
                    "ByInvitation": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296486822)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296486822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296486822)
            
            //--TRIMMABLE-BOUNDARY-START(4296486822)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296486822)
            
            static $h = 1519526;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886421414),
    {
      "t": 1519526,
      "n": "Public",
      "d": 1519526,
      "h": 12886421414,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886421414),
//--TRIMMABLE-BOUNDARY-START(8591454118),
    {
      "t": 1519526,
      "n": "ByInvitation",
      "d": 1519526,
      "h": 8591454118,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591454118)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296486822),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1519526,
      "h": 4296486822,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296486822)
  ],
  "h": 1519526
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupVisibility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupVisibility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1519526)
        
        

        //--TRIMMABLE-BOUNDARY-START(798630)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupMemberFeatureModelTypeDescriptor<>`, (TSelf) => $asm.$gt(`$PZCj.LCCGCM.CommunityGroupMemberFeatureModelTypeDescriptor<>`, [TSelf], ($self) => class CommunityGroupMemberFeatureModelTypeDescriptor$$ extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$(TSelf))
        {
            //--TRIMMABLE-BOUNDARY-START(4295765926)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295765926);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModelTypeDescriptor$$(TSelf).GenerateProperties($.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$(TSelf), this, factory);
                    }, $GNqohj ??= {"r":65537,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), 0, "CommunityGroupMemberFeatureModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.Common\\Models_CommunityGroupMemberFeatureModel_LivingThing.Core.Community.Group.Common.Models.CommunityGroupMemberFeatureModel_TSelf_TypeDescriptorBuilder.g.cs", "CommunityGroupMemberFeatureModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295765926)
            
            //--TRIMMABLE-BOUNDARY-START(12885700518)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885700518);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM.AccountMembershipFeatureModelTypeDescriptor$$(TSelf).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885700518)
            
            //--TRIMMABLE-BOUNDARY-START(17180667814)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Models.CommunityGroupMemberFeatureModel<TSelf>*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180667814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Membership.AccountMembershipFeatureModel<TSelf>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM.AccountMembershipFeatureModelTypeDescriptor$$(TSelf).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM.AccountMembershipFeatureModel$$(TSelf)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180667814)
            
            //--TRIMMABLE-BOUNDARY-START(8590733222)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Models.CommunityGroupMemberFeatureModel<TSelf>?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590733222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$(TSelf), null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$(TSelf))))
                {
                    /*var*/ let result = $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModelTypeDescriptor$$(TSelf).VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$(TSelf)));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$(TSelf), null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$(TSelf)));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590733222)
            
            static $H = 798630;
            static $h = 798630;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$(TSelf)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885700518),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": this.$h,
      "H": 12885700518,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885700518),
//--TRIMMABLE-BOUNDARY-START(17180667814),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$(TSelf).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": this.$h,
      "H": 17180667814,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180667814),
//--TRIMMABLE-BOUNDARY-START(8590733222),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$(TSelf).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": this.$h,
      "H": 8590733222,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590733222)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295765926),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4295765926,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295765926)
  ],
  "s": [
    {
      "h": TSelf?.$h??1572864,
      "n": "TSelf",
      "c": [$.$LCOv.LCFCPM.IAccountMembershipFeatureModel$$(TSelf).$h
      ]
    }
  ],
  "r": 1,
  "H": 798630,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$(TSelf)), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupMemberFeatureModelTypeDescriptor<${TSelf?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupMemberFeatureModelTypeDescriptor$${TSelf?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(798630)
        
        

        //--TRIMMABLE-BOUNDARY-START(1453990)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupTypeSchemaReader`, ($self) => class CommunityGroupTypeSchemaReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591388582)
            /*Pager<ISelectOption<PostTypes?>> */ GetOptions(/*object?*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591388582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCP.PostUtility.GetPostTypeOptions(this, "Group", null);
            }
            //--TRIMMABLE-BOUNDARY-END(8591388582)
            
            //--TRIMMABLE-BOUNDARY-START(4297034070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaOptionReader<LivingThing.Core.Frameworks.Common.Posts.Models.PostTypes?>.GetOptions(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            [`LCFCA$1$ISchemaOptionReader$LivingThing$Core$Frameworks$Common$Posts$Models$PostTypes$LivingThing$Core$Frameworks$Common$Posts$Models$PostTypes$$GetOptions`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297034070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOptions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297034070)
            
            //--TRIMMABLE-BOUNDARY-START(4296421286)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296421286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296421286)
            
            //--TRIMMABLE-BOUNDARY-START(4296421286)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296421286)
            
            static $h = 1453990;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591388582),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes))).$h,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "GetOptions",
      "d": 1453990,
      "h": 8591388582,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591388582)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296421286),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1453990,
      "h": 4296421286,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296421286)
  ],
  "h": 1453990
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupTypeSchemaReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupTypeSchemaReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1453990)
        
        

        //--TRIMMABLE-BOUNDARY-START(3026854)
        $asm.$cls(`$PZCj.LCCGCS$2.CommunityGroupPostStates`, ($self) => class CommunityGroupPostStates extends $.$LCOv.LCFCPS$2.AccountStates
        {
            //--TRIMMABLE-BOUNDARY-START(4297994150)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297994150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297994150)
            
            //--TRIMMABLE-BOUNDARY-START(4297994150)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297994150)
            
            static $h = 3026854;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPS$2.AccountStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297994150),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3026854,
      "h": 4297994150,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297994150)
  ],
  "h": 3026854
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.States.CommunityGroupPostStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}States${separator}CommunityGroupPostStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3026854)
        
        

        //--TRIMMABLE-BOUNDARY-START(2764710)
        $asm.$cls(`$PZCj.LCCGCS$1.CommunityGroupServiceSettings`, ($self) => class CommunityGroupServiceSettings extends $.$Iaui.LCFCMS.ServiceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297732006)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297732006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297732006)
            
            //--TRIMMABLE-BOUNDARY-START(4297732006)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297732006)
            
            static $h = 2764710;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ServiceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297732006),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2764710,
      "h": 4297732006,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297732006)
  ],
  "h": 2764710
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Settings.CommunityGroupServiceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Settings${separator}CommunityGroupServiceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2764710)
        
        

        //--TRIMMABLE-BOUNDARY-START(2502566)
        $asm.$cls(`$PZCj.LCCGCS$1.CommunityGroupPostSettings`, ($self) => class CommunityGroupPostSettings extends $.$LCOv.LCFCPS$1.AccountSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297469862)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297469862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297469862)
            
            //--TRIMMABLE-BOUNDARY-START(4297469862)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297469862)
            
            static $h = 2502566;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPS$1.AccountSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297469862),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2502566,
      "h": 4297469862,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297469862)
  ],
  "h": 2502566
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Settings.CommunityGroupPostSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Settings${separator}CommunityGroupPostSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2502566)
        
        

        //--TRIMMABLE-BOUNDARY-START(3288998)
        $asm.$cls(`$PZCj.LCCGCS$2.CommunityGroupServiceStates`, ($self) => class CommunityGroupServiceStates extends $.$Iaui.LCFCMS$1.ServiceStates
        {
            //--TRIMMABLE-BOUNDARY-START(4298256294)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298256294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298256294)
            
            //--TRIMMABLE-BOUNDARY-START(4298256294)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4298256294)
            
            static $h = 3288998;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ServiceStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298256294),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3288998,
      "h": 4298256294,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298256294)
  ],
  "h": 3288998
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.States.CommunityGroupServiceStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}States${separator}CommunityGroupServiceStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3288998)
        
        

        //--TRIMMABLE-BOUNDARY-START(3157926)
        $asm.$cls(`$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptor`, ($self) => class CommunityGroupPostStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCS$2.CommunityGroupPostStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4298125222)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298125222);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptor.GenerateProperties($.$PZCj.LCCGCS$2.CommunityGroupPostStates, this, factory);
                    }, $ttktVa ??= {"r":65537,"n":"","d":3157926,"h":0,"f":17825794}), 0, "CommunityGroupPostStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.Common\\States_CommunityGroupPostStates_LivingThing.Core.Community.Group.Common.States.CommunityGroupPostStatesTypeDescriptorBuilder.g.cs", "CommunityGroupPostStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298125222)
            
            //--TRIMMABLE-BOUNDARY-START(12888059814)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888059814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPS$2.AccountStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888059814)
            
            //--TRIMMABLE-BOUNDARY-START(17183027110)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.States.CommunityGroupPostStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183027110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.States.AccountStates?*/ let targetBase = _target;
                $.$LCOv.LCFCPS$2.AccountStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPS$2.AccountStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183027110)
            
            //--TRIMMABLE-BOUNDARY-START(8593092518)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.States.CommunityGroupPostStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593092518);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PZCj.LCCGCS$2.CommunityGroupPostStates().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PZCj.LCCGCS$2.CommunityGroupPostStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCS$2.CommunityGroupPostStates)))
                {
                    /*var*/ let result = $.$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCS$2.CommunityGroupPostStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PZCj.LCCGCS$2.CommunityGroupPostStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCS$2.CommunityGroupPostStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593092518)
            
            static $h = 3157926;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCS$2.CommunityGroupPostStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888059814),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3157926,
      "h": 12888059814,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888059814),
//--TRIMMABLE-BOUNDARY-START(17183027110),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3026854,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3157926,
      "h": 17183027110,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183027110),
//--TRIMMABLE-BOUNDARY-START(8593092518),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3026854,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3157926,
      "h": 8593092518,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593092518)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298125222),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3157926,
      "h": 4298125222,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298125222)
  ],
  "h": 3157926
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PZCj.LCCGCS$2.CommunityGroupPostStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.States.CommunityGroupPostStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}States${separator}CommunityGroupPostStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3157926)
        
        

        //--TRIMMABLE-BOUNDARY-START(2895782)
        $asm.$cls(`$PZCj.LCCGCS$1.CommunityGroupServiceSettingsTypeDescriptor`, ($self) => class CommunityGroupServiceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCS$1.CommunityGroupServiceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297863078)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297863078);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsTypeDescriptor.GenerateProperties($.$PZCj.LCCGCS$1.CommunityGroupServiceSettings, this, factory);
                    }, $jsYnYh ??= {"r":65537,"n":"","d":2895782,"h":0,"f":17825794}), 0, "CommunityGroupServiceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.Common\\Settings_CommunityGroupServiceSettings_LivingThing.Core.Community.Group.Common.Settings.CommunityGroupServiceSettingsTypeDescriptorBuilder.g.cs", "CommunityGroupServiceSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297863078)
            
            //--TRIMMABLE-BOUNDARY-START(12887797670)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887797670);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ServiceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887797670)
            
            //--TRIMMABLE-BOUNDARY-START(17182764966)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Settings.CommunityGroupServiceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182764966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ServiceSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ServiceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ServiceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182764966)
            
            //--TRIMMABLE-BOUNDARY-START(8592830374)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Settings.CommunityGroupServiceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592830374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings)))
                {
                    /*var*/ let result = $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592830374)
            
            static $h = 2895782;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCS$1.CommunityGroupServiceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887797670),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2895782,
      "h": 12887797670,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887797670),
//--TRIMMABLE-BOUNDARY-START(17182764966),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2764710,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2895782,
      "h": 17182764966,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182764966),
//--TRIMMABLE-BOUNDARY-START(8592830374),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2764710,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2895782,
      "h": 8592830374,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592830374)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297863078),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2895782,
      "h": 4297863078,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297863078)
  ],
  "h": 2895782
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PZCj.LCCGCS$1.CommunityGroupServiceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Settings.CommunityGroupServiceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Settings${separator}CommunityGroupServiceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2895782)
        
        

        //--TRIMMABLE-BOUNDARY-START(2633638)
        $asm.$cls(`$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptor`, ($self) => class CommunityGroupPostSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCS$1.CommunityGroupPostSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297600934)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297600934);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptor.GenerateProperties($.$PZCj.LCCGCS$1.CommunityGroupPostSettings, this, factory);
                    }, $dZdUwa ??= {"r":65537,"n":"","d":2633638,"h":0,"f":17825794}), 0, "CommunityGroupPostSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.Common\\Settings_CommunityGroupPostSettings_LivingThing.Core.Community.Group.Common.Settings.CommunityGroupPostSettingsTypeDescriptorBuilder.g.cs", "CommunityGroupPostSettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297600934)
            
            //--TRIMMABLE-BOUNDARY-START(12887535526)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887535526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPS$1.AccountSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887535526)
            
            //--TRIMMABLE-BOUNDARY-START(17182502822)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Settings.CommunityGroupPostSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182502822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Settings.AccountSettings?*/ let targetBase = _target;
                $.$LCOv.LCFCPS$1.AccountSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPS$1.AccountSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182502822)
            
            //--TRIMMABLE-BOUNDARY-START(8592568230)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Settings.CommunityGroupPostSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592568230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PZCj.LCCGCS$1.CommunityGroupPostSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PZCj.LCCGCS$1.CommunityGroupPostSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCS$1.CommunityGroupPostSettings)))
                {
                    /*var*/ let result = $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCS$1.CommunityGroupPostSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PZCj.LCCGCS$1.CommunityGroupPostSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCS$1.CommunityGroupPostSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592568230)
            
            static $h = 2633638;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCS$1.CommunityGroupPostSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887535526),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2633638,
      "h": 12887535526,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887535526),
//--TRIMMABLE-BOUNDARY-START(17182502822),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2502566,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2633638,
      "h": 17182502822,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182502822),
//--TRIMMABLE-BOUNDARY-START(8592568230),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2502566,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2633638,
      "h": 8592568230,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592568230)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297600934),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2633638,
      "h": 4297600934,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297600934)
  ],
  "h": 2633638
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PZCj.LCCGCS$1.CommunityGroupPostSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Settings.CommunityGroupPostSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Settings${separator}CommunityGroupPostSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2633638)
        
        

        //--TRIMMABLE-BOUNDARY-START(3420070)
        $asm.$cls(`$PZCj.LCCGCS$2.CommunityGroupServiceStatesTypeDescriptor`, ($self) => class CommunityGroupServiceStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCS$2.CommunityGroupServiceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4298387366)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298387366);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesTypeDescriptor.GenerateProperties($.$PZCj.LCCGCS$2.CommunityGroupServiceStates, this, factory);
                    }, $famApe ??= {"r":65537,"n":"","d":3420070,"h":0,"f":17825794}), 0, "CommunityGroupServiceStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.Common\\States_CommunityGroupServiceStates_LivingThing.Core.Community.Group.Common.States.CommunityGroupServiceStatesTypeDescriptorBuilder.g.cs", "CommunityGroupServiceStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298387366)
            
            //--TRIMMABLE-BOUNDARY-START(12888321958)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888321958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ServiceStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888321958)
            
            //--TRIMMABLE-BOUNDARY-START(17183289254)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.States.CommunityGroupServiceStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183289254);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ServiceStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ServiceStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ServiceStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183289254)
            
            //--TRIMMABLE-BOUNDARY-START(8593354662)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.States.CommunityGroupServiceStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593354662);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PZCj.LCCGCS$2.CommunityGroupServiceStates().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates)))
                {
                    /*var*/ let result = $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593354662)
            
            static $h = 3420070;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCS$2.CommunityGroupServiceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888321958),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3420070,
      "h": 12888321958,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888321958),
//--TRIMMABLE-BOUNDARY-START(17183289254),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3288998,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3420070,
      "h": 17183289254,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183289254),
//--TRIMMABLE-BOUNDARY-START(8593354662),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3288998,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3420070,
      "h": 8593354662,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593354662)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298387366),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3420070,
      "h": 4298387366,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298387366)
  ],
  "h": 3420070
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PZCj.LCCGCS$2.CommunityGroupServiceStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.States.CommunityGroupServiceStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}States${separator}CommunityGroupServiceStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3420070)
        
        

        //--TRIMMABLE-BOUNDARY-START(274342)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupBasePostModel<,>`, (TGroupPostSettings, TGroupPostStates) => $asm.$gt(`$PZCj.LCCGCM.CommunityGroupBasePostModel<,>`, [TGroupPostSettings, TGroupPostStates], ($self) => class CommunityGroupBasePostModel$$$ extends $.$LCOv.LCFCPM$1.AccountBaseModel$$$(TGroupPostSettings, TGroupPostStates)
        {
            //--TRIMMABLE-BOUNDARY-START(77309685670)
            /*PostTypes */ get Type()
            {
                return this.SetType ?? 2304/*PostTypes.Group*/;
            }
            //--TRIMMABLE-BOUNDARY-END(77309685670)
            
            //--TRIMMABLE-BOUNDARY-START(73014718374)
            /*PostTypes? */ get SetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770078118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.SetType;
            }
            /*PostTypes? */ set SetType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129816486);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.SetType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(73014718374)
            
            //--TRIMMABLE-BOUNDARY-START(85899620262)
            /*CommunityGroupVisibility */ get Visibility()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949947302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$PZCj.LCCGCM.CommunityGroupVisibility, 0, "Visibility", null);
            }
            /*CommunityGroupVisibility */ set Visibility(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719751078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$PZCj.LCCGCM.CommunityGroupVisibility, value, "Visibility");
            }
            //--TRIMMABLE-BOUNDARY-END(85899620262)
            
            //--TRIMMABLE-BOUNDARY-START(51539881894)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539881894);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539881894)
            
            //--TRIMMABLE-BOUNDARY-START(8590208934)
            /*bool */ get CanFollow()
            {
                return this.Visibility === 0/*CommunityGroupVisibility.Public*/;
            }
            //--TRIMMABLE-BOUNDARY-END(8590208934)
            
            //--TRIMMABLE-BOUNDARY-START(81604652966)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604652966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                descriptors = $.$LCOv.LCFCPM$1.PostBaseModel.Exclude(descriptors, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "Email", "PhoneNumber" ], null, null));
                if ($.$$.S.Object.GetType.call(this) !== $.$PZCj.LCCGCM.CommunityGroupPostModel.$type)
                {
                    descriptors = $.$LCOv.LCFCPM$1.PostBaseModel.Exclude(descriptors, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "SetType" ], null, null));
                }
                return super.UpdateDescriptors(descriptors, $.$clone(schema));
            }
            //--TRIMMABLE-BOUNDARY-END(81604652966)
            
            //--TRIMMABLE-BOUNDARY-START(47244914598)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244914598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Schema === 1/*SchemaType.Form*/)
                {
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "SetType", "Type", null, null, null, null);
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Name", "Title", "Name this group", null, null, null);
                }
                super.ModifyDescriptor(propertyBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(47244914598)
            
            //--TRIMMABLE-BOUNDARY-START(4295241638)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$7();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295241638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295241638)
            
            //--TRIMMABLE-BOUNDARY-START(4295241638)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295241638)
            
            static $H = 274342;
            static $h = 274342;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.AccountBaseModel$$$(TGroupPostSettings, TGroupPostStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77309685670),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360012710,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50364417
      },
      "n": "Type",
      "d": this.$h,
      "H": 77309685670,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77309685670),
//--TRIMMABLE-BOUNDARY-START(73014718374),
    {
      "p": $.$typeNullable($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770078118,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 60129816486,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 83918849
      },
      "n": "SetType",
      "d": this.$h,
      "H": 73014718374,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            },
            {
              "n": "Description",
              "v": "Group specific usage type",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=SourceBranch"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            },
            {
              "n": "OptionsReader",
              "v": 1453990,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73014718374),
//--TRIMMABLE-BOUNDARY-START(85899620262),
    {
      "p": 1519526,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42949947302,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 68719751078,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 83886081
      },
      "n": "Visibility",
      "d": this.$h,
      "H": 85899620262,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "How will user join this group",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=GoogleLens"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85899620262),
//--TRIMMABLE-BOUNDARY-START(8590208934),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17180143526,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50364417
      },
      "n": "CanFollow",
      "d": this.$h,
      "H": 8590208934,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590208934)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539881894),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": this.$h,
      "H": 51539881894,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51539881894),
//--TRIMMABLE-BOUNDARY-START(81604652966),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": this.$h,
      "H": 81604652966,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604652966),
//--TRIMMABLE-BOUNDARY-START(47244914598),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": this.$h,
      "H": 47244914598,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47244914598)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295241638),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": this.$h,
      "H": 4295241638,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295241638)
  ],
  "s": [
    {
      "h": TGroupPostSettings?.$h??1572864,
      "n": "TGroupPostSettings",
      "c": [2502566
      ]
    },
    {
      "h": TGroupPostStates?.$h??1638400,
      "n": "TGroupPostStates",
      "c": [3026854
      ]
    }
  ],
  "r": 2,
  "H": 274342,
  "h": this.$h,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Exclude",
          "v": 16777214,
          "t": 2722134
        },
        {
          "n": "Description",
          "v": "Zoey Group allows users in the community to self organize. Some group types also has specific application that allows creator to manage members.",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostRatable, $.$YUlm.LCSCM.IShipmentAccount, $.$Iaui.LCFCM.IApplicationAccountModel, $.$LCOv.LCFCP.IPostNamedLocation, $.$PZCj.LCCGCM.ICommunityGroupModel, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostReactable, $.$LCOv.LCFCP.IPostSharable, $.$LCOv.LCFCP.IPostViewTrackable, $.$LCOv.LCFCP.IPostApplicationScope, $.$LCOv.LCFCP.IGroupAccountModel, $.$LCOv.LCFCP.IUserAccountModel, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel<${TGroupPostSettings?.$fullName},${TGroupPostStates?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupBasePostModel$${TGroupPostSettings?.$getFullName(separator)}$${TGroupPostStates?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(274342)
        
        

        //--TRIMMABLE-BOUNDARY-START(470950)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor<,>`, (TGroupPostSettings, TGroupPostStates) => $asm.$gt(`$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor<,>`, [TGroupPostSettings, TGroupPostStates], ($self) => class CommunityGroupBasePostModelTypeDescriptor$$$ extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates))
        {
            //--TRIMMABLE-BOUNDARY-START(4295438246)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295438246);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$(TGroupPostSettings, TGroupPostStates).GenerateProperties($.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates), this, factory);
                    }, $tDkJuj ??= {"r":65537,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), 0, "CommunityGroupBasePostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.Common\\Models_CommunityGroupBasePostModel_LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel_TGroupPostSettings__TGroupPostStates_TypeDescriptorBuilder.g.cs", "CommunityGroupBasePostModelTypeDescriptor", 43);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295438246)
            
            //--TRIMMABLE-BOUNDARY-START(12885372838)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885372838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SetType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates).$type, $.$discardRef(), "SetType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SetType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$LCOv.LCFCPM$1.PostTypes), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "SetType";
                        $i1.DelaredOn = "LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel<TGroupPostSettings, TGroupPostStates>";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$(TGroupPostSettings, TGroupPostStates), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates))).SetType);
                        }, $NwCGTk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$(TGroupPostSettings, TGroupPostStates), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SetType = value.AsNullableValue($.$LCOv.LCFCPM$1.PostTypes);
                        }, $YiRyge ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Visibility"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates).$type, $.$discardRef(), "Visibility", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Visibility")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$PZCj.LCCGCM.CommunityGroupVisibility, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Visibility";
                        $i3.DelaredOn = "LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel<TGroupPostSettings, TGroupPostStates>";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$(TGroupPostSettings, TGroupPostStates), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$PZCj.LCCGCM.CommunityGroupVisibility, ($.$cast(target, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates))).Visibility);
                        }, $lswLDd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$(TGroupPostSettings, TGroupPostStates), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Visibility = value.AsEnumValue($.$PZCj.LCCGCM.CommunityGroupVisibility);
                        }, $HOXjeh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates).$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Type";
                        $i5.DelaredOn = "LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel<TGroupPostSettings, TGroupPostStates>";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$(TGroupPostSettings, TGroupPostStates), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates))).Type);
                        }, $qEhqMi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CanFollow"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates).$type, $.$discardRef(), "CanFollow", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CanFollow")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "CanFollow";
                        $i7.DelaredOn = "LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel<TGroupPostSettings, TGroupPostStates>";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$(TGroupPostSettings, TGroupPostStates), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates))).CanFollow);
                        }, $QwGBCf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.AccountBaseModelTypeDescriptor$$$(TGroupPostSettings, TGroupPostStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885372838)
            
            //--TRIMMABLE-BOUNDARY-START(17180340134)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel<TGroupPostSettings, TGroupPostStates>*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180340134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel<TGroupPostSettings, TGroupPostStates>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.AccountBaseModelTypeDescriptor$$$(TGroupPostSettings, TGroupPostStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.AccountBaseModel$$$(TGroupPostSettings, TGroupPostStates)));
                {
                    /*var*/ let _SetType = _target.SetType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SetType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$LCOv.LCFCPM$1.PostTypes), () => _SetType, ($v) => _SetType = $v, null, true)))
                    {
                        _target.SetType = _SetType;
                    }
                }
                {
                    /*var*/ let _Visibility = _target.Visibility;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Visibility"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$PZCj.LCCGCM.CommunityGroupVisibility));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$PZCj.LCCGCM.CommunityGroupVisibility, () => _Visibility, ($v) => _Visibility = $v, null, true)))
                    {
                        _target.Visibility = _Visibility;
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _CanFollow = _target.CanFollow;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CanFollow"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _CanFollow, ($v) => _CanFollow = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180340134)
            
            //--TRIMMABLE-BOUNDARY-START(8590405542)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel<TGroupPostSettings, TGroupPostStates>?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590405542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates), null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates))))
                {
                    /*var*/ let result = $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$(TGroupPostSettings, TGroupPostStates).VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates)));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates), null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates)));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590405542)
            
            static $H = 470950;
            static $h = 470950;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885372838),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": this.$h,
      "H": 12885372838,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885372838),
//--TRIMMABLE-BOUNDARY-START(17180340134),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": this.$h,
      "H": 17180340134,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180340134),
//--TRIMMABLE-BOUNDARY-START(8590405542),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": this.$h,
      "H": 8590405542,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590405542)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295438246),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4295438246,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295438246)
  ],
  "s": [
    {
      "h": TGroupPostSettings?.$h??1572864,
      "n": "TGroupPostSettings",
      "c": [2502566
      ]
    },
    {
      "h": TGroupPostStates?.$h??1638400,
      "n": "TGroupPostStates",
      "c": [3026854
      ]
    }
  ],
  "r": 2,
  "H": 470950,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$(TGroupPostSettings, TGroupPostStates)), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModelTypeDescriptor<${TGroupPostSettings?.$fullName},${TGroupPostStates?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupBasePostModelTypeDescriptor$${TGroupPostSettings?.$getFullName(separator)}$${TGroupPostStates?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(470950)
        
        

        //--TRIMMABLE-BOUNDARY-START(929702)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupModel`, ($self) => class CommunityGroupModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$PZCj.LCCGCS$1.CommunityGroupServiceSettings, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295896998)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295896998);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295896998)
            
            //--TRIMMABLE-BOUNDARY-START(4295896998)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295896998)
            
            static $h = 929702;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$PZCj.LCCGCS$1.CommunityGroupServiceSettings, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295896998),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 929702,
      "h": 4295896998,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295896998)
  ],
  "h": 929702
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(929702)
        
        

        //--TRIMMABLE-BOUNDARY-START(1191846)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupPostModel`, ($self) => class CommunityGroupPostModel extends $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$PZCj.LCCGCS$1.CommunityGroupPostSettings, $.$PZCj.LCCGCS$2.CommunityGroupPostStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296159142)
            //default constructor overload
            $ctor$9()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296159142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296159142)
            
            //--TRIMMABLE-BOUNDARY-START(4296159142)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(4296159142)
            
            static $h = 1191846;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$PZCj.LCCGCS$1.CommunityGroupPostSettings, $.$PZCj.LCCGCS$2.CommunityGroupPostStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296159142),
    {
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 1191846,
      "h": 4296159142,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296159142)
  ],
  "h": 1191846,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Exclude",
          "v": 16777214,
          "t": 2722134
        },
        {
          "n": "Description",
          "v": "Zoey Group allows users in the community to self organize. Some group types also has specific application that allows creator to manage members.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 4859222,
      "c": 12889761110,
      "n": [
        {
          "n": "SettingsType",
          "v": 2502566,
          "t": 188547073
        },
        {
          "n": "StateType",
          "v": 3026854,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostRatable, $.$YUlm.LCSCM.IShipmentAccount, $.$Iaui.LCFCM.IApplicationAccountModel, $.$LCOv.LCFCP.IPostNamedLocation, $.$PZCj.LCCGCM.ICommunityGroupModel, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostReactable, $.$LCOv.LCFCP.IPostSharable, $.$LCOv.LCFCP.IPostViewTrackable, $.$LCOv.LCFCP.IPostApplicationScope, $.$LCOv.LCFCP.IGroupAccountModel, $.$LCOv.LCFCP.IUserAccountModel, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1191846)
        
        

        //--TRIMMABLE-BOUNDARY-START(2240422)
        $asm.$cls(`$PZCj.LCCGCS.ICommunityGroupFeedRemoteService`, ($self) => class ICommunityGroupFeedRemoteService
        {
            static $h = 2240422;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2240422,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Services.ICommunityGroupFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Services${separator}ICommunityGroupFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2240422)
        
        

        //--TRIMMABLE-BOUNDARY-START(2371494)
        $asm.$cls(`$PZCj.LCCGCS.IComunityGroupRemoteService`, ($self) => class IComunityGroupRemoteService
        {
            static $h = 2371494;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297338790),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "groupId",
          "p": 1310721
        }
      ],
      "n": "RefreshYouTube",
      "o": "LCCGCS$IComunityGroupRemoteService$RefreshYouTube",
      "d": 2371494,
      "h": 4297338790,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297338790)
  ],
  "h": 2371494,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.IReadDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Services.IComunityGroupRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Services${separator}IComunityGroupRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2371494)
        
        

        //--TRIMMABLE-BOUNDARY-START(1060774)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupModelTypeDescriptor`, ($self) => class CommunityGroupModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCM.CommunityGroupModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296028070)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296028070);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PZCj.LCCGCM.CommunityGroupModelTypeDescriptor.GenerateProperties($.$PZCj.LCCGCM.CommunityGroupModel, this, factory);
                    }, $RixGZd ??= {"r":65537,"n":"","d":1060774,"h":0,"f":17825794}), 0, "CommunityGroupModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.Common\\Models_CommunityGroupModel_LivingThing.Core.Community.Group.Common.Models.CommunityGroupModelTypeDescriptorBuilder.g.cs", "CommunityGroupModelTypeDescriptor", 42);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296028070)
            
            //--TRIMMABLE-BOUNDARY-START(12885962662)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885962662);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$PZCj.LCCGCS$1.CommunityGroupServiceSettings, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885962662)
            
            //--TRIMMABLE-BOUNDARY-START(17180929958)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Models.CommunityGroupModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180929958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Group.Common.Settings.CommunityGroupServiceSettings, LivingThing.Core.Community.Group.Common.States.CommunityGroupServiceStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$PZCj.LCCGCS$1.CommunityGroupServiceSettings, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$PZCj.LCCGCS$1.CommunityGroupServiceSettings, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180929958)
            
            //--TRIMMABLE-BOUNDARY-START(8590995366)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Models.CommunityGroupModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590995366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PZCj.LCCGCM.CommunityGroupModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PZCj.LCCGCM.CommunityGroupModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunityGroupModel)))
                {
                    /*var*/ let result = $.$PZCj.LCCGCM.CommunityGroupModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunityGroupModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PZCj.LCCGCM.CommunityGroupModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunityGroupModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590995366)
            
            static $h = 1060774;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCM.CommunityGroupModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885962662),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1060774,
      "h": 12885962662,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885962662),
//--TRIMMABLE-BOUNDARY-START(17180929958),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 929702,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1060774,
      "h": 17180929958,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180929958),
//--TRIMMABLE-BOUNDARY-START(8590995366),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 929702,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1060774,
      "h": 8590995366,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590995366)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296028070),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1060774,
      "h": 4296028070,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296028070)
  ],
  "h": 1060774
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PZCj.LCCGCM.CommunityGroupModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1060774)
        
        

        //--TRIMMABLE-BOUNDARY-START(1650598)
        $asm.$cls(`$PZCj.LCCGCM.CommunitySubGroupPostModel`, ($self) => class CommunitySubGroupPostModel extends $.$PZCj.LCCGCM.CommunityGroupPostModel
        {
            //--TRIMMABLE-BOUNDARY-START(17181519782)
            /*PostTypes */ get Type()
            {
                return 2558/*PostTypes.GroupSub*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17181519782)
            
            //--TRIMMABLE-BOUNDARY-START(21476487078)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476487078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 1/*SchemaType.Form*/)
                {
                    descriptors = $.$LCOv.LCFCPM$1.PostBaseModel.Exclude(descriptors, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "Type" ], null, null));
                }
                return super.UpdateDescriptors(descriptors, $.$clone(schema));
            }
            //--TRIMMABLE-BOUNDARY-END(21476487078)
            
            //--TRIMMABLE-BOUNDARY-START(4296617894)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$9();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296617894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296617894)
            
            //--TRIMMABLE-BOUNDARY-START(4296617894)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4296617894)
            
            static $h = 1650598;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCM.CommunityGroupPostModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181519782),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886552486,
        "f": 50364417
      },
      "n": "Type",
      "d": 1650598,
      "h": 17181519782,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17181519782)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476487078),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": 1650598,
      "h": 21476487078,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476487078)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296617894),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 1650598,
      "h": 4296617894,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296617894)
  ],
  "h": 1650598
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostRatable, $.$YUlm.LCSCM.IShipmentAccount, $.$Iaui.LCFCM.IApplicationAccountModel, $.$LCOv.LCFCP.IPostNamedLocation, $.$PZCj.LCCGCM.ICommunityGroupModel, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostReactable, $.$LCOv.LCFCP.IPostSharable, $.$LCOv.LCFCP.IPostViewTrackable, $.$LCOv.LCFCP.IPostApplicationScope, $.$LCOv.LCFCP.IGroupAccountModel, $.$LCOv.LCFCP.IUserAccountModel, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunitySubGroupPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunitySubGroupPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1650598)
        
        

        //--TRIMMABLE-BOUNDARY-START(2305958)
        $asm.$cls(`$PZCj.LCCGCS.ICommunityGroupFeedRemoteService_Mocking`, ($self) => class ICommunityGroupFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297273254)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297273254);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297273254)
            
            //--TRIMMABLE-BOUNDARY-START(8592240550)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Group$Common$Models$CommunityGroupPostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592240550);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$PZCj.LCCGCM.CommunityGroupPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$PZCj.LCCGCM.CommunityGroupPostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592240550)
            
            static $h = 2305958;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297273254),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2305958,
      "h": 4297273254,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297273254)
  ],
  "h": 2305958
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$PZCj.LCCGCS.ICommunityGroupFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Services.ICommunityGroupFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Services${separator}ICommunityGroupFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2305958)
        
        

        //--TRIMMABLE-BOUNDARY-START(2437030)
        $asm.$cls(`$PZCj.LCCGCS.IComunityGroupRemoteService_Mocking`, ($self) => class IComunityGroupRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297404326)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297404326);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297404326)
            
            //--TRIMMABLE-BOUNDARY-START(8592371622)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel> */ LCCGCS$IComunityGroupRemoteService$RefreshYouTube(/*string*/ groupId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592371622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$PZCj.LCCGCS.IComunityGroupRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel.$type;
                    $i1.MethodName = "RefreshYouTube";
                    return $i1;
                })();
                return this.InvokeAsync($.$PZCj.LCCGCS.IComunityGroupRemoteService, $.$fPer.LCFCD.WireTransportModel, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, groupId) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592371622)
            
            //--TRIMMABLE-BOUNDARY-START(12887338918)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Group$Common$Models$CommunityGroupPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887338918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$PZCj.LCCGCM.CommunityGroupPostModel).$type;
                    $i2.MethodName = "Create";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$PZCj.LCCGCM.CommunityGroupPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12887338918)
            
            //--TRIMMABLE-BOUNDARY-START(21477273510)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Group$Common$Models$CommunityGroupPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477273510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$PZCj.LCCGCM.CommunityGroupPostModel).$type;
                    $i3.MethodName = "ReadMany";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$PZCj.LCCGCM.CommunityGroupPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21477273510)
            
            //--TRIMMABLE-BOUNDARY-START(25772240806)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Group$Common$Models$CommunityGroupPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772240806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$PZCj.LCCGCM.CommunityGroupPostModel).$type;
                    $i4.MethodName = "ReadSingle";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$PZCj.LCCGCM.CommunityGroupPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25772240806)
            
            //--TRIMMABLE-BOUNDARY-START(30067208102)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Group$Common$Models$CommunityGroupPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067208102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$PZCj.LCCGCM.CommunityGroupPostModel).$type;
                    $i5.MethodName = "Update";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$PZCj.LCCGCM.CommunityGroupPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30067208102)
            
            //--TRIMMABLE-BOUNDARY-START(17182306214)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182306214);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel).$type;
                    $i6.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i6.MethodName = "Delete";
                    return $i6;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$PZCj.LCCGCM.CommunityGroupPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17182306214)
            
            static $h = 2437030;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297404326),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2437030,
      "h": 4297404326,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297404326)
  ],
  "h": 2437030
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$PZCj.LCCGCS.IComunityGroupRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.IReadDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Services.IComunityGroupRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Services${separator}IComunityGroupRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2437030)
        
        

        //--TRIMMABLE-BOUNDARY-START(1322918)
        $asm.$cls(`$PZCj.LCCGCM.CommunityGroupPostModelTypeDescriptor`, ($self) => class CommunityGroupPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCM.CommunityGroupPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296290214)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296290214);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PZCj.LCCGCM.CommunityGroupPostModelTypeDescriptor.GenerateProperties($.$PZCj.LCCGCM.CommunityGroupPostModel, this, factory);
                    }, $tMMrDf ??= {"r":65537,"n":"","d":1322918,"h":0,"f":17825794}), 0, "CommunityGroupPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.Common\\Models_CommunityGroupPostModel_LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModelTypeDescriptorBuilder.g.cs", "CommunityGroupPostModelTypeDescriptor", 41);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296290214)
            
            //--TRIMMABLE-BOUNDARY-START(12886224806)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886224806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$($.$PZCj.LCCGCS$1.CommunityGroupPostSettings, $.$PZCj.LCCGCS$2.CommunityGroupPostStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886224806)
            
            //--TRIMMABLE-BOUNDARY-START(17181192102)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181192102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel<LivingThing.Core.Community.Group.Common.Settings.CommunityGroupPostSettings, LivingThing.Core.Community.Group.Common.States.CommunityGroupPostStates>?*/ let targetBase = _target;
                $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$($.$PZCj.LCCGCS$1.CommunityGroupPostSettings, $.$PZCj.LCCGCS$2.CommunityGroupPostStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$PZCj.LCCGCS$1.CommunityGroupPostSettings, $.$PZCj.LCCGCS$2.CommunityGroupPostStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181192102)
            
            //--TRIMMABLE-BOUNDARY-START(8591257510)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591257510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PZCj.LCCGCM.CommunityGroupPostModel().$ctor$9();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PZCj.LCCGCM.CommunityGroupPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunityGroupPostModel)))
                {
                    /*var*/ let result = $.$PZCj.LCCGCM.CommunityGroupPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunityGroupPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PZCj.LCCGCM.CommunityGroupPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunityGroupPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591257510)
            
            static $h = 1322918;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCM.CommunityGroupPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886224806),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1322918,
      "h": 12886224806,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886224806),
//--TRIMMABLE-BOUNDARY-START(17181192102),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1191846,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1322918,
      "h": 17181192102,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181192102),
//--TRIMMABLE-BOUNDARY-START(8591257510),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1191846,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1322918,
      "h": 8591257510,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591257510)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296290214),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1322918,
      "h": 4296290214,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296290214)
  ],
  "h": 1322918
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PZCj.LCCGCM.CommunityGroupPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunityGroupPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1322918)
        
        

        //--TRIMMABLE-BOUNDARY-START(1781670)
        $asm.$cls(`$PZCj.LCCGCM.CommunitySubGroupPostModelTypeDescriptor`, ($self) => class CommunitySubGroupPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCM.CommunitySubGroupPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296748966)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296748966);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PZCj.LCCGCM.CommunitySubGroupPostModelTypeDescriptor.GenerateProperties($.$PZCj.LCCGCM.CommunitySubGroupPostModel, this, factory);
                    }, $gTzMaf ??= {"r":65537,"n":"","d":1781670,"h":0,"f":17825794}), 0, "CommunitySubGroupPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.Common\\Models_CommunitySubGroupPostModel_LivingThing.Core.Community.Group.Common.Models.CommunitySubGroupPostModelTypeDescriptorBuilder.g.cs", "CommunitySubGroupPostModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296748966)
            
            //--TRIMMABLE-BOUNDARY-START(12886683558)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886683558);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PZCj.LCCGCM.CommunitySubGroupPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Group.Common.Models.CommunitySubGroupPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PZCj.LCCGCM.CommunitySubGroupPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$PZCj.LCCGCM.CommunitySubGroupPostModel)).Type);
                        }, $npiZSb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1781670,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$PZCj.LCCGCM.CommunityGroupPostModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886683558)
            
            //--TRIMMABLE-BOUNDARY-START(17181650854)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Models.CommunitySubGroupPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181650854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Models.CommunityGroupPostModel?*/ let targetBase = _target;
                $.$PZCj.LCCGCM.CommunityGroupPostModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCM.CommunityGroupPostModel));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181650854)
            
            //--TRIMMABLE-BOUNDARY-START(8591716262)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.Common.Models.CommunitySubGroupPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591716262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PZCj.LCCGCM.CommunitySubGroupPostModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PZCj.LCCGCM.CommunitySubGroupPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunitySubGroupPostModel)))
                {
                    /*var*/ let result = $.$PZCj.LCCGCM.CommunitySubGroupPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunitySubGroupPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PZCj.LCCGCM.CommunitySubGroupPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PZCj.LCCGCM.CommunitySubGroupPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591716262)
            
            static $h = 1781670;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PZCj.LCCGCM.CommunitySubGroupPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886683558),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1781670,
      "h": 12886683558,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886683558),
//--TRIMMABLE-BOUNDARY-START(17181650854),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1650598,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1781670,
      "h": 17181650854,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181650854),
//--TRIMMABLE-BOUNDARY-START(8591716262),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1650598,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1781670,
      "h": 8591716262,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591716262)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296748966),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1781670,
      "h": 4296748966,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296748966)
  ],
  "h": 1781670
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PZCj.LCCGCM.CommunitySubGroupPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.Common.Models.CommunitySubGroupPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}Common${separator}Models${separator}CommunitySubGroupPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1781670)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(12198)
