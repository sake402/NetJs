
//--TRIMMABLE-BOUNDARY-START(30124)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $jlvo, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $GYJg, $PZCj, $PIIp, $RoTr) {
    "use strict";
    let _;
    let $ooHSga;
    let $dfJLqh;
    let $mVxbkh;
    let $yrUabj;
    let $hOPtld;
    let $dvMeSb;
    let $PJtONb;
    let $AaAtNc;
    let $kLDjna;
    let $AgKWkb;
    let $zUfUBj;
    let $kVFFVi;
    let $jgGozi;
    let $jPIXQh;
    let $EUKsXf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Group.User.Client.Blazor", 
    {
  "h": 30124,
  "f": "LivingThing.Core.Community.Group.User.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Group.User.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Group.User.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(226732)
        $asm.$cls(`$vOBI.LCCGUC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295194028)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295194028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$vOBI.LCCGUC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295194028)
            
            static $h = 226732;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295194028),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 226732,
      "h": 4295194028,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295194028)
  ],
  "h": 226732
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(226732)
        
        

        //--TRIMMABLE-BOUNDARY-START(619948)
        $asm.$cls(`$vOBI.LCCGUCS.Place`, ($self) => class Place extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(77310031276)
            /*string?*/ Icon = null;
            //--TRIMMABLE-BOUNDARY-END(77310031276)
            
            //--TRIMMABLE-BOUNDARY-START(133144606124)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(133144606124)
            
            //--TRIMMABLE-BOUNDARY-START(30065391020)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(30065391020)
            
            //--TRIMMABLE-BOUNDARY-START(81604998572)
            /*string?*/ Link = null;
            //--TRIMMABLE-BOUNDARY-END(81604998572)
            
            //--TRIMMABLE-BOUNDARY-START(85899965868)
            /*object?*/ LinkParameter = null;
            //--TRIMMABLE-BOUNDARY-END(85899965868)
            
            //--TRIMMABLE-BOUNDARY-START(25770423724)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770423724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770423724)
            
            //--TRIMMABLE-BOUNDARY-START(25770423724)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770423724)
            
            static $h = 619948;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310031276),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245260204,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079835052,
        "f": 83886081
      },
      "n": "Icon",
      "d": 619948,
      "h": 77310031276,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310031276),
//--TRIMMABLE-BOUNDARY-START(133144606124),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015063980,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849638828,
        "f": 83886081
      },
      "n": "Title",
      "d": 619948,
      "h": 133144606124,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144606124),
//--TRIMMABLE-BOUNDARY-START(30065391020),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655325612,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489900460,
        "f": 83886081
      },
      "n": "Description",
      "d": 619948,
      "h": 30065391020,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065391020),
//--TRIMMABLE-BOUNDARY-START(81604998572),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835194796,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669769644,
        "f": 83886081
      },
      "n": "Link",
      "d": 619948,
      "h": 81604998572,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604998572),
//--TRIMMABLE-BOUNDARY-START(85899965868),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425129388,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259704236,
        "f": 83886081
      },
      "n": "LinkParameter",
      "d": 619948,
      "h": 85899965868,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899965868)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770423724),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 619948,
      "h": 25770423724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770423724)
  ],
  "h": 619948
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Client.Services.Place`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Client${separator}Services${separator}Place`; }
        });
        //--TRIMMABLE-BOUNDARY-END(619948)
        
        

        //--TRIMMABLE-BOUNDARY-START(554412)
        $asm.$cls(`$vOBI.LCCGUCS.CommunityGroupUserService`, ($self) => class CommunityGroupUserService extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590489004)
            $ctor$1(/*CommunityGroupService*/ service)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590489004);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.GroupService = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590489004)
            
            //--TRIMMABLE-BOUNDARY-START(25770358188)
            /*CommunityGroupService*/ GroupService = null;
            //--TRIMMABLE-BOUNDARY-END(25770358188)
            
            //--TRIMMABLE-BOUNDARY-START(21475390892)
            /*IEnumerable<Place> */ GetPlaces(/*CommunityGroupUserPostModel*/ group)
            {
                return new ($.$$.N.YieldToIterator$$($.$vOBI.LCCGUCS.Place))().$ctor$1(function*()
                {
                    return;
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(21475390892)
            
            static $h = 554412;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770358188),
    {
      "p": 634270,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180423596,
        "f": 50331649
      },
      "n": "GroupService",
      "d": 554412,
      "h": 25770358188,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770358188)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475390892),
    {
      "r": $.$$.SCG.IEnumerable$$($.$vOBI.LCCGUCS.Place).$h,
      "p": [
        {
          "n": "group",
          "p": 227820
        }
      ],
      "n": "GetPlaces",
      "d": 554412,
      "h": 21475390892,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475390892)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590489004),
    {
      "p": [
        {
          "n": "service",
          "p": 634270
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 554412,
      "h": 8590489004,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590489004)
  ],
  "h": 554412
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Client.Services.CommunityGroupUserService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Client${separator}Services${separator}CommunityGroupUserService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(554412)
        
        

        //--TRIMMABLE-BOUNDARY-START(95660)
        $asm.$cls(`$vOBI._LCCGUCPH.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295062956)
            static /*void */ CreateCommunityAccountBanner_0(TAccount, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TAccount*/ __arg0)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295062956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountBanner$$(TAccount), seq);
                __builder.AddComponentParameter(__seq0, "ViewModel", $.$box(__arg0, TAccount));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295062956)
            
            static $h = 95660;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295062956),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TAccount) => TAccount.$h
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "CreateCommunityAccountBanner_0",
      "d": 95660,
      "h": 4295062956,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295062956)
  ],
  "h": 95660
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Group.User.Client.Pages.HomePage.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Client${separator}Pages${separator}HomePage${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(95660)
        
        

        //--TRIMMABLE-BOUNDARY-START(292268)
        $asm.$cls(`$vOBI.LCCGUC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180161452)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$vOBI.LCCGUCP.HomePage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$vOBI.LCCGUCP.HomePage().$ctor$3();
                    }, $ooHSga ??= {"r":2752627,"n":"","d":292268,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$vOBI.LCCGUCS$1.Synopsis.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$vOBI.LCCGUCS$1.Synopsis().$ctor$3();
                    }, $dfJLqh ??= {"r":2752627,"n":"","d":292268,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180161452)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295259564)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295259564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295259564)
            
            //--TRIMMABLE-BOUNDARY-START(4295259564)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295259564)
            
            static $h = 292268;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180161452),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885194156,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 292268,
      "h": 17180161452,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180161452)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295259564),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 292268,
      "h": 4295259564,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295259564)
  ],
  "h": 292268
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(292268)
        
        

        //--TRIMMABLE-BOUNDARY-START(423340)
        $asm.$cls(`$vOBI.LCCGUC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590357932)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590357932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$vOBI.LCCGUCS.CommunityGroupUserService, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$vOBI.LCCGUCS.CommunityGroupUserApplicationHandler, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vOBI.LCCGUCS.CommunityGroupUserApplicationHandler, x);
                }, $mVxbkh ??= {"r":16815552,"p":[{"n":"x","p":327718}],"n":"","d":423340,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vOBI.LCCGUCS.CommunityGroupUserApplicationHandler, x);
                }, $yrUabj ??= {"r":765342,"p":[{"n":"x","p":327718}],"n":"","d":423340,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590357932)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vOBI.LCCGUC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295390636)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295390636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295390636)
            
            //--TRIMMABLE-BOUNDARY-START(4295390636)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295390636)
            
            static $h = 423340;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590357932),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 423340,
      "h": 8590357932,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590357932)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295390636),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 423340,
      "h": 4295390636,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295390636)
  ],
  "h": 423340
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(423340)
        
        

        //--TRIMMABLE-BOUNDARY-START(816556)
        $asm.$cls(`$vOBI.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295783852)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295783852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295783852)
            
            //--TRIMMABLE-BOUNDARY-START(4295783852)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295783852)
            
            static $h = 816556;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295783852),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 816556,
      "h": 4295783852,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295783852)
  ],
  "h": 816556,
  "a": [
    {
      "t": 751020,
      "c": 4295718316
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(816556)
        
        

        //--TRIMMABLE-BOUNDARY-START(751020)
        $asm.$cls(`$vOBI.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295718316)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295718316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295718316)
            
            //--TRIMMABLE-BOUNDARY-START(4295718316)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295718316)
            
            static $h = 751020;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295718316),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 751020,
      "h": 4295718316,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295718316)
  ],
  "h": 751020
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(751020)
        
        

        //--TRIMMABLE-BOUNDARY-START(161196)
        $asm.$cls(`$vOBI.LCCGUC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590095788)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590095788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590095788)
            
            //--TRIMMABLE-BOUNDARY-START(4295128492)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295128492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295128492)
            
            //--TRIMMABLE-BOUNDARY-START(4295128492)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295128492)
            
            static $h = 161196;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590095788),
    {
      "r": 65537,
      "n": "Execute",
      "d": 161196,
      "h": 8590095788,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590095788)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295128492),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 161196,
      "h": 4295128492,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295128492)
  ],
  "h": 161196
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(161196)
        
        

        //--TRIMMABLE-BOUNDARY-START(685484)
        $asm.$cls(`$vOBI.LCCGUCS$1.Synopsis`, ($self) => class Synopsis extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(94489965996)
            /*ICommunityNuggetProvider*/ NuggetProvider = null;
            //--TRIMMABLE-BOUNDARY-END(94489965996)
            
            //--TRIMMABLE-BOUNDARY-START(30065456556)
            /*ICommunityCalendarProvider*/ EventProvider = null;
            //--TRIMMABLE-BOUNDARY-END(30065456556)
            
            //--TRIMMABLE-BOUNDARY-START(103079900588)
            /*CommunityGroupUserService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(103079900588)
            
            //--TRIMMABLE-BOUNDARY-START(85900031404)
            /*CommunityGroupUserPostModel*/ Group = null;
            //--TRIMMABLE-BOUNDARY-END(85900031404)
            
            //--TRIMMABLE-BOUNDARY-START(141734606252)
            /*DataFilter */ get TodayNuggetFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Group.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741847/*PostFilterTypes.FeaturedInParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1286/*PostTypes.ArticleNugget*/, $.$LCOv.LCFCPM$1.PostTypes) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(141734606252)
            
            //--TRIMMABLE-BOUNDARY-START(98784933292)
            /*string */ get OptimizedComponentName()
            {
                return "synopsis";
            }
            //--TRIMMABLE-BOUNDARY-END(98784933292)
            
            //--TRIMMABLE-BOUNDARY-START(146029573548)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029573548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Group":
                    this.Group = $.$cast(parameter.Value, $.$RoTr.LCCGUCM.CommunityGroupUserPostModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(146029573548)
            
            //--TRIMMABLE-BOUNDARY-START(90194998700)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194998700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.NuggetProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.ICommunityNuggetProvider, serviceProvider);
                this.EventProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.ICommunityCalendarProvider, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vOBI.LCCGUCS.CommunityGroupUserService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(90194998700)
            
            //--TRIMMABLE-BOUNDARY-START(25770489260)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770489260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pdx mgb-10");
                __builder.AddContent$1(2, this.NuggetProvider.LCCCS$ICommunityNuggetProvider$GetTodayNugget(this.TodayNuggetFilter));
                __builder.AddMarkupContent(3, "\r\n    ");
                __builder.AddContent$1(4, this.EventProvider.LCCCS$ICommunityCalendarProvider$GetUpcomingEvents(this.Group));
                __builder.AddMarkupContent(5, "\r\n    ");
                __builder.OpenElement(6, "ul");
                __builder.AddAttribute$5(7, "class", "reset grid colm-1 gap-05");
                let $en2 = $.$sl.SL.Enumerable.Take($.$vOBI.LCCGUCS.Place, this.Service.GetPlaces(this.Group), 9).SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let place = $en2.SCG$IEnumerator$$$Current;
                    {
                        __builder.OpenElement(8, "li");
                        __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 9);
                        __builder.AddComponentParameter(10, "href", place.Link);
                        __builder.AddComponentParameter(11, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, place.LinkParameter));
                        __builder.AddComponentParameter(12, "Class", "mg-a d-block text-center");
                        __builder.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(14, "div");
                            __builder2.AddAttribute$5(15, "class", "stack corner-2 pdx-1 pdy mg-1 bg-card bd-primary shadow clickable flex");
                            __builder2.OpenElement(16, "i");
                            __builder2.AddAttribute$5(17, "class", $.$strNN($.$strNN($.$strNN("mgx-a" + " mdi") + " fsz-35") + " ") + $.$strNN((place.Icon)));
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(18, "\r\n                        ");
                            __builder2.OpenElement(19, "h4");
                            __builder2.AddAttribute$5(20, "class", "mgx-a text-center mgt-1 mgb-0 nowrap");
                            __builder2.AddContent$4(21, place.Title);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }), $hOPtld ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":685484,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(25770489260)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21475521964)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475521964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475521964)
            
            //--TRIMMABLE-BOUNDARY-START(21475521964)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21475521964)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(94489965996)
                this.NuggetProvider = null;
                //--TRIMMABLE-BOUNDARY-END(94489965996)
                
                //--TRIMMABLE-BOUNDARY-START(30065456556)
                this.EventProvider = null;
                //--TRIMMABLE-BOUNDARY-END(30065456556)
                
                //--TRIMMABLE-BOUNDARY-START(103079900588)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(103079900588)
                
            }
            static $h = 685484;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94489965996),
    {
      "p": 18060736,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835260332,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849704364,
        "f": 83886081
      },
      "n": "NuggetProvider",
      "d": 685484,
      "h": 94489965996,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94489965996),
//--TRIMMABLE-BOUNDARY-START(30065456556),
    {
      "p": 17339840,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655391148,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669835180,
        "f": 83886081
      },
      "n": "EventProvider",
      "d": 685484,
      "h": 30065456556,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065456556),
//--TRIMMABLE-BOUNDARY-START(103079900588),
    {
      "p": 554412,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015129516,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439638956,
        "f": 83886081
      },
      "n": "Service",
      "d": 685484,
      "h": 103079900588,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103079900588),
//--TRIMMABLE-BOUNDARY-START(85900031404),
    {
      "p": 227820,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245325740,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259769772,
        "f": 83886081
      },
      "n": "Group",
      "d": 685484,
      "h": 85900031404,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900031404),
//--TRIMMABLE-BOUNDARY-START(141734606252),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605064108,
        "f": 50331650
      },
      "n": "TodayNuggetFilter",
      "d": 685484,
      "h": 141734606252,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(141734606252),
//--TRIMMABLE-BOUNDARY-START(98784933292),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425194924,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 685484,
      "h": 98784933292,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98784933292)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(146029573548),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 685484,
      "h": 146029573548,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029573548),
//--TRIMMABLE-BOUNDARY-START(90194998700),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 685484,
      "h": 90194998700,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90194998700),
//--TRIMMABLE-BOUNDARY-START(25770489260),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 685484,
      "h": 25770489260,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770489260)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475521964),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 685484,
      "h": 21475521964,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475521964)
  ],
  "h": 685484
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Client.Shared.Synopsis`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Client${separator}Shared${separator}Synopsis`; }
        });
        //--TRIMMABLE-BOUNDARY-END(685484)
        
        

        //--TRIMMABLE-BOUNDARY-START(357804)
        $asm.$cls(`$vOBI.LCCGUCP.HomePage`, ($self) => class HomePage extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21475194284)
            /*CommunityGroupApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(21475194284)
            
            //--TRIMMABLE-BOUNDARY-START(81604736428)
            /*CommunityGroupUserService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(81604736428)
            
            //--TRIMMABLE-BOUNDARY-START(68719834540)
            /*CommunityGroupUserPostModel*/ Group = null;
            //--TRIMMABLE-BOUNDARY-END(68719834540)
            
            //--TRIMMABLE-BOUNDARY-START(77309769132)
            /*string */ get OptimizedComponentName()
            {
                return "homepage";
            }
            //--TRIMMABLE-BOUNDARY-END(77309769132)
            
            //--TRIMMABLE-BOUNDARY-START(111669507500)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669507500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Group":
                    this.Group = $.$cast(parameter.Value, $.$RoTr.LCCGUCM.CommunityGroupUserPostModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(111669507500)
            
            //--TRIMMABLE-BOUNDARY-START(73014801836)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014801836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Application = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PIIp.LCCGCS.CommunityGroupApplication, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vOBI.LCCGUCS.CommunityGroupUserService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(73014801836)
            
            //--TRIMMABLE-BOUNDARY-START(25770161580)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770161580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 0);
                __builder.AddComponentParameter(1, "Name", "");
                __builder.AddComponentParameter(2, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, -2147483648/*int.MinValue*/), $.$$.S.Int32));
                __builder.AddComponentParameter(3, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/ | (((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? 4/*ApplicationPageAccessibility.Tab*/ : 0/*ApplicationPageAccessibility.None*/)), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                __builder.AddComponentParameter(4, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ | 16/*ApplicationPageFeatures.TopToolBarOverlay*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                __builder.AddComponentParameter(5, "ToolBarBackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                __builder.AddComponentParameter(6, "RemoveApplicationFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 128/*ApplicationFeatures.ToolBarBorder*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddComponentParameter(7, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)))().$ctor(this, ( (/*e*/ e) =>
                {
                    return $.$ahDc.LCCCSL.CommunityLayoutExtension.SetLayoutHeader($.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~(12/*CommunityLayoutFeatures.PadX*/ | 1/*CommunityLayoutFeatures.PadT*/), null, null, true), this.GetBanner());
                }), $dvMeSb ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object).$h}],"n":"","d":357804,"h":0,"f":17825794}));
                __builder.AddAttribute$3(8, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$4(9, this.Group.Title);
                    }, $PJtONb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":357804,"h":0,"f":17825794});
                }), $AaAtNc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":357804,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$1(11, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-User"), false));
                    }, $kLDjna ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":357804,"h":0,"f":17825794});
                }), $AgKWkb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":357804,"h":0,"f":17825794}));
                __builder.AddAttribute$3(12, "ToolBarControls", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        /*var*/ let ownsAccount = this.Service.GroupService.CommunityService.IsOwnedByCurrentUser(this.Group);
                        if (ownsAccount)
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 13);
                            __builder2.AddComponentParameter(14, "PageLink", "Settings");
                            __builder2.AddComponentParameter(15, "link-class", "mdi mdi-cog");
                            __builder2.CloseComponent();
                        }
                    }, $zUfUBj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":357804,"h":0,"f":17825794});
                }), $kVFFVi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":357804,"h":0,"f":17825794}));
                __builder.AddAttribute$3(16, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*__*/ __) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                    }, $jgGozi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":357804,"h":0,"f":17825794});
                }), $jPIXQh ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":357804,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(17, "\r\n\r\n}");
            }
            //--TRIMMABLE-BOUNDARY-END(25770161580)
            
            //--TRIMMABLE-BOUNDARY-START(64424867244)
            /*RenderFragment */ GetBanner()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424867244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    $.$vOBI._LCCGUCPH.TypeInference.CreateCommunityAccountBanner_0($.$RoTr.LCCGUCM.CommunityGroupUserPostModel, __builder2, 18, 19, this.Group);
                }, $EUKsXf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":357804,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(64424867244)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180226988)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180226988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180226988)
            
            //--TRIMMABLE-BOUNDARY-START(17180226988)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17180226988)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475194284)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(21475194284)
                
                //--TRIMMABLE-BOUNDARY-START(81604736428)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(81604736428)
                
            }
            static $h = 357804;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475194284),
    {
      "p": 503198,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360096172,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194671020,
        "f": 83886081
      },
      "n": "Application",
      "d": 357804,
      "h": 21475194284,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475194284),
//--TRIMMABLE-BOUNDARY-START(81604736428),
    {
      "p": 554412,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129899948,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374540204,
        "f": 83886081
      },
      "n": "Service",
      "d": 357804,
      "h": 81604736428,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81604736428),
//--TRIMMABLE-BOUNDARY-START(68719834540),
    {
      "p": 227820,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950030764,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784605612,
        "f": 83886081
      },
      "n": "Group",
      "d": 357804,
      "h": 68719834540,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719834540),
//--TRIMMABLE-BOUNDARY-START(77309769132),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539965356,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 357804,
      "h": 77309769132,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77309769132)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111669507500),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 357804,
      "h": 111669507500,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669507500),
//--TRIMMABLE-BOUNDARY-START(73014801836),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 357804,
      "h": 73014801836,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73014801836),
//--TRIMMABLE-BOUNDARY-START(25770161580),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 357804,
      "h": 25770161580,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770161580),
//--TRIMMABLE-BOUNDARY-START(64424867244),
    {
      "r": 6881395,
      "n": "GetBanner",
      "d": 357804,
      "h": 64424867244,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64424867244)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180226988),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 357804,
      "h": 17180226988,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180226988)
  ],
  "h": 357804
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Client.Pages.HomePage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Client${separator}Pages${separator}HomePage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(357804)
        
        

        //--TRIMMABLE-BOUNDARY-START(488876)
        $asm.$cls(`$vOBI.LCCGUCS.CommunityGroupUserApplicationHandler`, ($self) => class CommunityGroupUserApplicationHandler extends $.$PIIp.LCCGCS.CommunityGroupTypeHandlerBase$$$$($.$RoTr.LCCGUCM.CommunityGroupUserPostModel, $.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates)
        {
            //--TRIMMABLE-BOUNDARY-START(137439442348)
            /*PostTypes */ get Type()
            {
                return 2305/*PostTypes.GroupUser*/;
            }
            //--TRIMMABLE-BOUNDARY-END(137439442348)
            
            //--TRIMMABLE-BOUNDARY-START(111669638572)
            /*string */ get Id()
            {
                return "User";
            }
            //--TRIMMABLE-BOUNDARY-END(111669638572)
            
            //--TRIMMABLE-BOUNDARY-START(120259573164)
            /*string */ get PostsName()
            {
                return "Users";
            }
            //--TRIMMABLE-BOUNDARY-END(120259573164)
            
            //--TRIMMABLE-BOUNDARY-START(124554540460)
            /*IEnumerable<ICommunityApplicationServiceCategory>?*/ ServiceCategories = null;
            //--TRIMMABLE-BOUNDARY-END(124554540460)
            
            //--TRIMMABLE-BOUNDARY-START(133144475052)
            /*string? */ get Title()
            {
                return "User";
            }
            //--TRIMMABLE-BOUNDARY-END(133144475052)
            
            //--TRIMMABLE-BOUNDARY-START(107374671276)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account-group"/*MaterialDesignIconNames.AccountGroup*/);
            }
            //--TRIMMABLE-BOUNDARY-END(107374671276)
            
            //--TRIMMABLE-BOUNDARY-START(115964605868)
            /*string? */ get Name()
            {
                return "Chruch";
            }
            //--TRIMMABLE-BOUNDARY-END(115964605868)
            
            //--TRIMMABLE-BOUNDARY-START(128849507756)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#8E9633";
                    $i1.ForegroundColor = "#FFFFFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(128849507756)
            
            //--TRIMMABLE-BOUNDARY-START(12885390764)
            /*IEnumerable<PostTypes> */ get AccountsType()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostTypes), [2305/*PostTypes.GroupUser*/], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(12885390764)
            
            //--TRIMMABLE-BOUNDARY-START(94489769388)
            /*RenderFragment? */ GetAccountView(/*AccountBaseModel*/ account, /*string?*/ route)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489769388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$PIIp.LCCGCS$1.CommunityGroupApplicationView$$$$($.$RoTr.LCCGUCM.CommunityGroupUserPostModel, $.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates), (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.set_Item("ViewModel", $.$LCOv.LCFCPM$1.PostFactory.EnsureIsCorrectType$1($.$LCOv.LCFCPM$1.AccountBaseModel, $.$RoTr.LCCGUCM.CommunityGroupUserPostModel, account));
                    $i2.set_Item("Route", route);
                    return $i2;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(94489769388)
            
            //--TRIMMABLE-BOUNDARY-START(103079703980)
            /*RenderFragment? */ GetGroupSynopsis(/*AccountBaseModel*/ group)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079703980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$vOBI.LCCGUCS$1.Synopsis, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t3 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.set_Item("Group", group);
                    return $i3;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(103079703980)
            
            //--TRIMMABLE-BOUNDARY-START(98784736684)
            /*RenderFragment? */ GetGroupPages(/*AccountBaseModel*/ group)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784736684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
                return $.$hDPm.LCFC.FragmentView.Join(null, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mac.MAC.RenderFragment), [ $.$hDPm.LCFC.FragmentView.From$1($.$vOBI.LCCGUCP.HomePage, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.set_Item("Group", group);
                    return $i4;
                })(), null, null) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(98784736684)
            
            //--TRIMMABLE-BOUNDARY-START(8590423468)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590423468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590423468)
            
            //--TRIMMABLE-BOUNDARY-START(8590423468)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590423468)
            
            static $h = 488876;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PIIp.LCCGCS.CommunityGroupTypeHandlerBase$$$$($.$RoTr.LCCGUCM.CommunityGroupUserPostModel, $.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439442348),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194802092,
        "f": 50364417
      },
      "n": "Type",
      "d": 488876,
      "h": 137439442348,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439442348),
//--TRIMMABLE-BOUNDARY-START(111669638572),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655194540,
        "f": 50364417
      },
      "n": "Id",
      "d": 488876,
      "h": 111669638572,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(111669638572),
//--TRIMMABLE-BOUNDARY-START(120259573164),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835063724,
        "f": 50364417
      },
      "n": "PostsName",
      "d": 488876,
      "h": 120259573164,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120259573164),
//--TRIMMABLE-BOUNDARY-START(124554540460),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS.ICommunityApplicationServiceCategory).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424998316,
        "f": 50364417
      },
      "n": "ServiceCategories",
      "d": 488876,
      "h": 124554540460,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(124554540460),
//--TRIMMABLE-BOUNDARY-START(133144475052),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604867500,
        "f": 50364417
      },
      "n": "Title",
      "d": 488876,
      "h": 133144475052,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144475052),
//--TRIMMABLE-BOUNDARY-START(107374671276),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065259948,
        "f": 50364417
      },
      "n": "Icon",
      "d": 488876,
      "h": 107374671276,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107374671276),
//--TRIMMABLE-BOUNDARY-START(115964605868),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245129132,
        "f": 50364417
      },
      "n": "Name",
      "d": 488876,
      "h": 115964605868,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115964605868),
//--TRIMMABLE-BOUNDARY-START(128849507756),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014932908,
        "f": 50364417
      },
      "n": "Theme",
      "d": 488876,
      "h": 128849507756,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128849507756),
//--TRIMMABLE-BOUNDARY-START(12885390764),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475325356,
        "f": 50364417
      },
      "n": "AccountsType",
      "d": 488876,
      "h": 12885390764,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885390764)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94489769388),
    {
      "r": 6881395,
      "p": [
        {
          "n": "account",
          "p": 6220212
        },
        {
          "n": "route",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetAccountView",
      "d": 488876,
      "h": 94489769388,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489769388),
//--TRIMMABLE-BOUNDARY-START(103079703980),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetGroupSynopsis",
      "d": 488876,
      "h": 103079703980,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103079703980),
//--TRIMMABLE-BOUNDARY-START(98784736684),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetGroupPages",
      "d": 488876,
      "h": 98784736684,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98784736684)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590423468),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 488876,
      "h": 8590423468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590423468)
  ],
  "h": 488876
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler$$$$($.$RoTr.LCCGUCM.CommunityGroupUserPostModel, $.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates), $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, $.$ydCm.LCCCS.ICommunityApplicationSubService, $.$yleQ.LCFCA.IApplicationSubService, $.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Client.Services.CommunityGroupUserApplicationHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Client${separator}Services${separator}CommunityGroupUserApplicationHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(488876)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Account.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Account.Client.Blazor", "NetJs.LivingThing.Core.Community.Group.Common", "NetJs.LivingThing.Core.Community.Group.Client.Blazor", "NetJs.LivingThing.Core.Community.Group.User.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(30124)
