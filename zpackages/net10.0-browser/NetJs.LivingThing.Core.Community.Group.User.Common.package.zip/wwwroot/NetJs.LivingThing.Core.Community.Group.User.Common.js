
//--TRIMMABLE-BOUNDARY-START(31212)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm, $PZCj) {
    "use strict";
    let _;
    let $zPGFJg;
    let $lbaehk;
    let $Ulsyii;
    let $ERbVdg;
    let $NsmNyh;
    let $bOtJXb;
    let $WTBQoi;
    let $CEgVkb;
    let $VykXej;
    let $QIDUFf;
    let $evDMfe;
    let $eOqkUk;
    let $SNEJrh;
    let $aLOXsg;
    let $HDRcod;
    let $qXsGRd;
    let $vOBzpa;
    let $TYIQSj;
    let $gUmbBi;
    let $OcTNif;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Group.User.Common", 
    {
  "h": 31212,
  "f": "LivingThing.Core.Community.Group.User.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Group.User.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Group.User.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(817644)
        $asm.$cls(`$RoTr.LCCGUCM.CommunityGroupUserServiceTierCustomAttributesProvider`, ($self) => class CommunityGroupUserServiceTierCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295784940)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295784940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295784940)
            
            static $h = 817644;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295784940),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 817644,
      "h": 4295784940,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295784940)
  ],
  "h": 817644
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserServiceTierCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Models${separator}CommunityGroupUserServiceTierCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(817644)
        
        

        //--TRIMMABLE-BOUNDARY-START(162284)
        $asm.$cls(`$RoTr.LCCGUC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295129580)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295129580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295129580)
            
            static $h = 162284;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295129580),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 162284,
      "h": 4295129580,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295129580)
  ],
  "h": 162284
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(162284)
        
        

        //--TRIMMABLE-BOUNDARY-START(555500)
        $asm.$cls(`$RoTr.LCCGUCM.CommunityGroupUserServiceModelCustomAttributesProvider`, ($self) => class CommunityGroupUserServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295522796)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295522796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ServiceModelCustomAttributesProvider$$$$($.$RoTr.LCCGUCM.CommunityGroupUserServiceTier, $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295522796)
            
            static $h = 555500;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295522796),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 555500,
      "h": 4295522796,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295522796)
  ],
  "h": 555500
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Models${separator}CommunityGroupUserServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(555500)
        
        

        //--TRIMMABLE-BOUNDARY-START(1538540)
        $asm.$cls(`$RoTr.LCCGUCS$1.CommunityGroupUserPostStatesCustomAttributesProvider`, ($self) => class CommunityGroupUserPostStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296505836)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296505836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$2.CommunityGroupPostStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296505836)
            
            static $h = 1538540;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296505836),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1538540,
      "h": 4296505836,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296505836)
  ],
  "h": 1538540
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserPostStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}States${separator}CommunityGroupUserPostStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1538540)
        
        

        //--TRIMMABLE-BOUNDARY-START(1800684)
        $asm.$cls(`$RoTr.LCCGUCS$1.CommunityGroupUserServiceStatesCustomAttributesProvider`, ($self) => class CommunityGroupUserServiceStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296767980)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296767980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296767980)
            
            static $h = 1800684;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296767980),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1800684,
      "h": 4296767980,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296767980)
  ],
  "h": 1800684
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserServiceStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}States${separator}CommunityGroupUserServiceStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1800684)
        
        

        //--TRIMMABLE-BOUNDARY-START(1014252)
        $asm.$cls(`$RoTr.LCCGUCS.CommunityGroupUserPostSettingsCustomAttributesProvider`, ($self) => class CommunityGroupUserPostSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295981548)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295981548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295981548)
            
            static $h = 1014252;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295981548),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1014252,
      "h": 4295981548,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295981548)
  ],
  "h": 1014252
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserPostSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Settings${separator}CommunityGroupUserPostSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1014252)
        
        

        //--TRIMMABLE-BOUNDARY-START(1997292)
        $asm.$cls(`$RoTr.LCCGUC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296964588)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296964588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$RoTr.LCCGUCM.CommunityGroupUserPostModelTypeDescriptorBuilder.Register();
                $.$RoTr.LCCGUCM.CommunityGroupUserServiceModelTypeDescriptorBuilder.Register();
                $.$RoTr.LCCGUCS.CommunityGroupUserPostSettingsTypeDescriptorBuilder.Register();
                $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettingsTypeDescriptorBuilder.Register();
                $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStatesTypeDescriptorBuilder.Register();
                $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296964588)
            
            static $h = 1997292;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296964588),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1997292,
      "h": 4296964588,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296964588)
  ],
  "h": 1997292
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1997292)
        
        

        //--TRIMMABLE-BOUNDARY-START(96748)
        $asm.$cls(`$RoTr.LCCGUC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295064044)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295064044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RoTr.LCCGUCM.CommunityGroupUserPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RoTr.LCCGUCM.CommunityGroupUserPostModelCustomAttributesProvider, $.$RoTr.LCCGUCM.CommunityGroupUserPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RoTr.LCCGUCM.CommunityGroupUserServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RoTr.LCCGUCM.CommunityGroupUserServiceModelCustomAttributesProvider, $.$RoTr.LCCGUCM.CommunityGroupUserServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RoTr.LCCGUCM.CommunityGroupUserServiceTier.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RoTr.LCCGUCM.CommunityGroupUserServiceTierCustomAttributesProvider, $.$RoTr.LCCGUCM.CommunityGroupUserServiceTierCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RoTr.LCCGUCS.CommunityGroupUserPostSettingsCustomAttributesProvider, $.$RoTr.LCCGUCS.CommunityGroupUserPostSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RoTr.LCCGUCS.CommunityGroupUserServiceSettingsCustomAttributesProvider, $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RoTr.LCCGUCS$1.CommunityGroupUserPostStatesCustomAttributesProvider, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStatesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStatesCustomAttributesProvider, $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295064044)
            
            static $h = 96748;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295064044),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 96748,
      "h": 4295064044,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295064044)
  ],
  "h": 96748
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(96748)
        
        

        //--TRIMMABLE-BOUNDARY-START(1276396)
        $asm.$cls(`$RoTr.LCCGUCS.CommunityGroupUserServiceSettingsCustomAttributesProvider`, ($self) => class CommunityGroupUserServiceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296243692)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296243692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296243692)
            
            static $h = 1276396;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296243692),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1276396,
      "h": 4296243692,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296243692)
  ],
  "h": 1276396
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserServiceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Settings${separator}CommunityGroupUserServiceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1276396)
        
        

        //--TRIMMABLE-BOUNDARY-START(1407468)
        $asm.$cls(`$RoTr.LCCGUCS.CommunityGroupUserServiceSettingsTypeDescriptorBuilder`, ($self) => class CommunityGroupUserServiceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591342060)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591342060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettingsTypeDescriptor()
                        const $t1 = $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserServiceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $WTBQoi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1407468,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591342060)
            
            //--TRIMMABLE-BOUNDARY-START(4296374764)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296374764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296374764)
            
            //--TRIMMABLE-BOUNDARY-START(4296374764)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296374764)
            
            static $h = 1407468;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591342060),
    {
      "r": 65537,
      "n": "Register",
      "d": 1407468,
      "h": 8591342060,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591342060)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296374764),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1407468,
      "h": 4296374764,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296374764)
  ],
  "h": 1407468
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserServiceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Settings${separator}CommunityGroupUserServiceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1407468)
        
        

        //--TRIMMABLE-BOUNDARY-START(424428)
        $asm.$cls(`$RoTr.LCCGUCM.CommunityGroupUserPostModelTypeDescriptorBuilder`, ($self) => class CommunityGroupUserPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590359020)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590359020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RoTr.LCCGUCM.CommunityGroupUserPostModelTypeDescriptor()
                        const $t1 = $.$RoTr.LCCGUCM.CommunityGroupUserPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $qXsGRd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":424428,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RoTr.LCCGUCM.CommunityGroupUserPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590359020)
            
            //--TRIMMABLE-BOUNDARY-START(4295391724)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295391724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295391724)
            
            //--TRIMMABLE-BOUNDARY-START(4295391724)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295391724)
            
            static $h = 424428;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590359020),
    {
      "r": 65537,
      "n": "Register",
      "d": 424428,
      "h": 8590359020,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590359020)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295391724),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 424428,
      "h": 4295391724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295391724)
  ],
  "h": 424428
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Models${separator}CommunityGroupUserPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(424428)
        
        

        //--TRIMMABLE-BOUNDARY-START(1145324)
        $asm.$cls(`$RoTr.LCCGUCS.CommunityGroupUserPostSettingsTypeDescriptorBuilder`, ($self) => class CommunityGroupUserPostSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591079916)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591079916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RoTr.LCCGUCS.CommunityGroupUserPostSettingsTypeDescriptor()
                        const $t1 = $.$RoTr.LCCGUCS.CommunityGroupUserPostSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserPostSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Ulsyii ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1145324,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591079916)
            
            //--TRIMMABLE-BOUNDARY-START(4296112620)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296112620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296112620)
            
            //--TRIMMABLE-BOUNDARY-START(4296112620)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296112620)
            
            static $h = 1145324;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591079916),
    {
      "r": 65537,
      "n": "Register",
      "d": 1145324,
      "h": 8591079916,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591079916)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296112620),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1145324,
      "h": 4296112620,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296112620)
  ],
  "h": 1145324
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserPostSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Settings${separator}CommunityGroupUserPostSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1145324)
        
        

        //--TRIMMABLE-BOUNDARY-START(293356)
        $asm.$cls(`$RoTr.LCCGUCM.CommunityGroupUserPostModelCustomAttributesProvider`, ($self) => class CommunityGroupUserPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295260652)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295260652)
            
            //--TRIMMABLE-BOUNDARY-START(8590227948)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590227948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$RoTr.LCCGUCM.CommunityGroupUserPostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates).$type, $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates)), [(() =>
                        {
                            //new $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates)()
                            const $t3 = $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates);
                            const $i3 = new $t3();
                            $i3.$ctor$3();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates)), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i4 = new $t4();
                        $i4.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i4.set_Item("ServiceId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i4;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$RoTr.LCCGUCM.CommunityGroupUserPostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $zPGFJg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":293356,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $lbaehk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":293356,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$PZCj.LCCGCM.CommunityGroupBasePostModelCustomAttributesProvider$$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590227948)
            
            static $h = 293356;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590227948),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 293356,
      "h": 8590227948,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590227948)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295260652),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 293356,
      "h": 4295260652,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295260652)
  ],
  "h": 293356
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Models${separator}CommunityGroupUserPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(293356)
        
        

        //--TRIMMABLE-BOUNDARY-START(1669612)
        $asm.$cls(`$RoTr.LCCGUCS$1.CommunityGroupUserPostStatesTypeDescriptorBuilder`, ($self) => class CommunityGroupUserPostStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591604204)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591604204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStatesTypeDescriptor()
                        const $t1 = $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserPostStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $NsmNyh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1669612,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591604204)
            
            //--TRIMMABLE-BOUNDARY-START(4296636908)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296636908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296636908)
            
            //--TRIMMABLE-BOUNDARY-START(4296636908)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296636908)
            
            static $h = 1669612;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591604204),
    {
      "r": 65537,
      "n": "Register",
      "d": 1669612,
      "h": 8591604204,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591604204)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296636908),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1669612,
      "h": 4296636908,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296636908)
  ],
  "h": 1669612
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserPostStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}States${separator}CommunityGroupUserPostStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1669612)
        
        

        //--TRIMMABLE-BOUNDARY-START(686572)
        $asm.$cls(`$RoTr.LCCGUCM.CommunityGroupUserServiceModelTypeDescriptorBuilder`, ($self) => class CommunityGroupUserServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590621164)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590621164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RoTr.LCCGUCM.CommunityGroupUserServiceModelTypeDescriptor()
                        const $t1 = $.$RoTr.LCCGUCM.CommunityGroupUserServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $evDMfe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":686572,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RoTr.LCCGUCM.CommunityGroupUserServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590621164)
            
            //--TRIMMABLE-BOUNDARY-START(4295653868)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295653868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295653868)
            
            //--TRIMMABLE-BOUNDARY-START(4295653868)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295653868)
            
            static $h = 686572;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590621164),
    {
      "r": 65537,
      "n": "Register",
      "d": 686572,
      "h": 8590621164,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590621164)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295653868),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 686572,
      "h": 4295653868,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295653868)
  ],
  "h": 686572
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Models${separator}CommunityGroupUserServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(686572)
        
        

        //--TRIMMABLE-BOUNDARY-START(1931756)
        $asm.$cls(`$RoTr.LCCGUCS$1.CommunityGroupUserServiceStatesTypeDescriptorBuilder`, ($self) => class CommunityGroupUserServiceStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591866348)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591866348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStatesTypeDescriptor()
                        const $t1 = $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserServiceStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $VykXej ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1931756,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591866348)
            
            //--TRIMMABLE-BOUNDARY-START(4296899052)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296899052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296899052)
            
            //--TRIMMABLE-BOUNDARY-START(4296899052)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296899052)
            
            static $h = 1931756;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591866348),
    {
      "r": 65537,
      "n": "Register",
      "d": 1931756,
      "h": 8591866348,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591866348)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296899052),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1931756,
      "h": 4296899052,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296899052)
  ],
  "h": 1931756
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserServiceStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}States${separator}CommunityGroupUserServiceStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1931756)
        
        

        //--TRIMMABLE-BOUNDARY-START(883180)
        $asm.$cls(`$RoTr.LCCGUC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590817772)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590817772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$RoTr.LCCGUCM.CommunityGroupUserPostModel, 2305/*PostTypes.GroupUser*/);
                $.$RoTr.LCCGUC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$RoTr.LCCGUC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590817772)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$RoTr.LCCGUC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295850476)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295850476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295850476)
            
            //--TRIMMABLE-BOUNDARY-START(4295850476)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295850476)
            
            static $h = 883180;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590817772),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 883180,
      "h": 8590817772,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590817772)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295850476),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 883180,
      "h": 4295850476,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295850476)
  ],
  "h": 883180
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(883180)
        
        

        //--TRIMMABLE-BOUNDARY-START(752108)
        $asm.$str(`$RoTr.LCCGUCM.CommunityGroupUserServiceTier`, ($self) => class CommunityGroupUserServiceTier extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Trial = 0;
            static Standard = 1;
            static Gold = 2;
            static Platinum = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(752108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Trial": 0n,
                    "Standard": 1n,
                    "Gold": 2n,
                    "Platinum": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295719404)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295719404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295719404)
            
            //--TRIMMABLE-BOUNDARY-START(4295719404)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295719404)
            
            static $h = 752108;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475588588),
    {
      "t": 752108,
      "n": "Trial",
      "d": 752108,
      "h": 21475588588,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475588588),
//--TRIMMABLE-BOUNDARY-START(17180621292),
    {
      "t": 752108,
      "n": "Standard",
      "d": 752108,
      "h": 17180621292,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180621292),
//--TRIMMABLE-BOUNDARY-START(8590686700),
    {
      "t": 752108,
      "n": "Gold",
      "d": 752108,
      "h": 8590686700,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590686700),
//--TRIMMABLE-BOUNDARY-START(12885653996),
    {
      "t": 752108,
      "n": "Platinum",
      "d": 752108,
      "h": 12885653996,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885653996)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295719404),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 752108,
      "h": 4295719404,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295719404)
  ],
  "h": 752108
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserServiceTier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Models${separator}CommunityGroupUserServiceTier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(752108)
        
        

        //--TRIMMABLE-BOUNDARY-START(1210860)
        $asm.$cls(`$RoTr.LCCGUCS.CommunityGroupUserServiceSettings`, ($self) => class CommunityGroupUserServiceSettings extends $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296178156)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296178156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296178156)
            
            //--TRIMMABLE-BOUNDARY-START(4296178156)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296178156)
            
            static $h = 1210860;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296178156),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1210860,
      "h": 4296178156,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296178156)
  ],
  "h": 1210860
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserServiceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Settings${separator}CommunityGroupUserServiceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1210860)
        
        

        //--TRIMMABLE-BOUNDARY-START(1473004)
        $asm.$cls(`$RoTr.LCCGUCS$1.CommunityGroupUserPostStates`, ($self) => class CommunityGroupUserPostStates extends $.$PZCj.LCCGCS$2.CommunityGroupPostStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296440300)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296440300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296440300)
            
            //--TRIMMABLE-BOUNDARY-START(4296440300)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296440300)
            
            static $h = 1473004;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$2.CommunityGroupPostStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296440300),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1473004,
      "h": 4296440300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296440300)
  ],
  "h": 1473004
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserPostStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}States${separator}CommunityGroupUserPostStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1473004)
        
        

        //--TRIMMABLE-BOUNDARY-START(1735148)
        $asm.$cls(`$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates`, ($self) => class CommunityGroupUserServiceStates extends $.$PZCj.LCCGCS$2.CommunityGroupServiceStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296702444)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296702444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296702444)
            
            //--TRIMMABLE-BOUNDARY-START(4296702444)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296702444)
            
            static $h = 1735148;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$2.CommunityGroupServiceStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296702444),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1735148,
      "h": 4296702444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296702444)
  ],
  "h": 1735148
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserServiceStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}States${separator}CommunityGroupUserServiceStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1735148)
        
        

        //--TRIMMABLE-BOUNDARY-START(948716)
        $asm.$cls(`$RoTr.LCCGUCS.CommunityGroupUserPostSettings`, ($self) => class CommunityGroupUserPostSettings extends $.$PZCj.LCCGCS$1.CommunityGroupPostSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4295916012)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295916012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295916012)
            
            //--TRIMMABLE-BOUNDARY-START(4295916012)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295916012)
            
            static $h = 948716;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$1.CommunityGroupPostSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295916012),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 948716,
      "h": 4295916012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295916012)
  ],
  "h": 948716
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserPostSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Settings${separator}CommunityGroupUserPostSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(948716)
        
        

        //--TRIMMABLE-BOUNDARY-START(1341932)
        $asm.$cls(`$RoTr.LCCGUCS.CommunityGroupUserServiceSettingsTypeDescriptor`, ($self) => class CommunityGroupUserServiceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296309228)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296309228);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettingsTypeDescriptor.GenerateProperties($.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings, this, factory);
                    }, $CEgVkb ??= {"r":65537,"n":"","d":1341932,"h":0,"f":17825794}), 0, "CommunityGroupUserServiceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.User.Common\\Settings_CommunityGroupUserServiceSettings_LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserServiceSettingsTypeDescriptorBuilder.g.cs", "CommunityGroupUserServiceSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296309228)
            
            //--TRIMMABLE-BOUNDARY-START(12886243820)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886243820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886243820)
            
            //--TRIMMABLE-BOUNDARY-START(17181211116)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserServiceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181211116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Settings.CommunityGroupServiceSettings?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181211116)
            
            //--TRIMMABLE-BOUNDARY-START(8591276524)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserServiceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591276524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings)))
                {
                    /*var*/ let result = $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591276524)
            
            static $h = 1341932;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886243820),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1341932,
      "h": 12886243820,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886243820),
//--TRIMMABLE-BOUNDARY-START(17181211116),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1210860,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1341932,
      "h": 17181211116,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181211116),
//--TRIMMABLE-BOUNDARY-START(8591276524),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1210860,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1341932,
      "h": 8591276524,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591276524)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296309228),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1341932,
      "h": 4296309228,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296309228)
  ],
  "h": 1341932
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserServiceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Settings${separator}CommunityGroupUserServiceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1341932)
        
        

        //--TRIMMABLE-BOUNDARY-START(1079788)
        $asm.$cls(`$RoTr.LCCGUCS.CommunityGroupUserPostSettingsTypeDescriptor`, ($self) => class CommunityGroupUserPostSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296047084)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296047084);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RoTr.LCCGUCS.CommunityGroupUserPostSettingsTypeDescriptor.GenerateProperties($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, this, factory);
                    }, $ERbVdg ??= {"r":65537,"n":"","d":1079788,"h":0,"f":17825794}), 0, "CommunityGroupUserPostSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.User.Common\\Settings_CommunityGroupUserPostSettings_LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserPostSettingsTypeDescriptorBuilder.g.cs", "CommunityGroupUserPostSettingsTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296047084)
            
            //--TRIMMABLE-BOUNDARY-START(12885981676)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885981676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885981676)
            
            //--TRIMMABLE-BOUNDARY-START(17180948972)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserPostSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180948972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Settings.CommunityGroupPostSettings?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$1.CommunityGroupPostSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180948972)
            
            //--TRIMMABLE-BOUNDARY-START(8591014380)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserPostSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591014380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$RoTr.LCCGUCS.CommunityGroupUserPostSettings().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCS.CommunityGroupUserPostSettings)))
                {
                    /*var*/ let result = $.$RoTr.LCCGUCS.CommunityGroupUserPostSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCS.CommunityGroupUserPostSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCS.CommunityGroupUserPostSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591014380)
            
            static $h = 1079788;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885981676),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1079788,
      "h": 12885981676,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885981676),
//--TRIMMABLE-BOUNDARY-START(17180948972),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 948716,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1079788,
      "h": 17180948972,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180948972),
//--TRIMMABLE-BOUNDARY-START(8591014380),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 948716,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1079788,
      "h": 8591014380,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591014380)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296047084),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1079788,
      "h": 4296047084,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296047084)
  ],
  "h": 1079788
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserPostSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Settings${separator}CommunityGroupUserPostSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1079788)
        
        

        //--TRIMMABLE-BOUNDARY-START(1604076)
        $asm.$cls(`$RoTr.LCCGUCS$1.CommunityGroupUserPostStatesTypeDescriptor`, ($self) => class CommunityGroupUserPostStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296571372)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296571372);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStatesTypeDescriptor.GenerateProperties($.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates, this, factory);
                    }, $bOtJXb ??= {"r":65537,"n":"","d":1604076,"h":0,"f":17825794}), 0, "CommunityGroupUserPostStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.User.Common\\States_CommunityGroupUserPostStates_LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserPostStatesTypeDescriptorBuilder.g.cs", "CommunityGroupUserPostStatesTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296571372)
            
            //--TRIMMABLE-BOUNDARY-START(12886505964)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886505964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886505964)
            
            //--TRIMMABLE-BOUNDARY-START(17181473260)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserPostStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181473260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.States.CommunityGroupPostStates?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$2.CommunityGroupPostStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181473260)
            
            //--TRIMMABLE-BOUNDARY-START(8591538668)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserPostStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591538668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates)))
                {
                    /*var*/ let result = $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591538668)
            
            static $h = 1604076;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886505964),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1604076,
      "h": 12886505964,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886505964),
//--TRIMMABLE-BOUNDARY-START(17181473260),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1473004,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1604076,
      "h": 17181473260,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181473260),
//--TRIMMABLE-BOUNDARY-START(8591538668),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1473004,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1604076,
      "h": 8591538668,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591538668)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296571372),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1604076,
      "h": 4296571372,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296571372)
  ],
  "h": 1604076
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserPostStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}States${separator}CommunityGroupUserPostStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1604076)
        
        

        //--TRIMMABLE-BOUNDARY-START(1866220)
        $asm.$cls(`$RoTr.LCCGUCS$1.CommunityGroupUserServiceStatesTypeDescriptor`, ($self) => class CommunityGroupUserServiceStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296833516)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296833516);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStatesTypeDescriptor.GenerateProperties($.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates, this, factory);
                    }, $QIDUFf ??= {"r":65537,"n":"","d":1866220,"h":0,"f":17825794}), 0, "CommunityGroupUserServiceStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.User.Common\\States_CommunityGroupUserServiceStates_LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserServiceStatesTypeDescriptorBuilder.g.cs", "CommunityGroupUserServiceStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296833516)
            
            //--TRIMMABLE-BOUNDARY-START(12886768108)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886768108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886768108)
            
            //--TRIMMABLE-BOUNDARY-START(17181735404)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserServiceStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181735404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.States.CommunityGroupServiceStates?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181735404)
            
            //--TRIMMABLE-BOUNDARY-START(8591800812)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserServiceStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591800812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates)))
                {
                    /*var*/ let result = $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591800812)
            
            static $h = 1866220;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886768108),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1866220,
      "h": 12886768108,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886768108),
//--TRIMMABLE-BOUNDARY-START(17181735404),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1735148,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1866220,
      "h": 17181735404,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181735404),
//--TRIMMABLE-BOUNDARY-START(8591800812),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1735148,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1866220,
      "h": 8591800812,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591800812)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296833516),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1866220,
      "h": 4296833516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296833516)
  ],
  "h": 1866220
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserServiceStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}States${separator}CommunityGroupUserServiceStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1866220)
        
        

        //--TRIMMABLE-BOUNDARY-START(227820)
        $asm.$cls(`$RoTr.LCCGUCM.CommunityGroupUserPostModel`, ($self) => class CommunityGroupUserPostModel extends $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates)
        {
            //--TRIMMABLE-BOUNDARY-START(38654933484)
            /*PostTypes */ get Type()
            {
                return 2305/*PostTypes.GroupUser*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38654933484)
            
            //--TRIMMABLE-BOUNDARY-START(25770031596)
            /*string? */ get ServiceId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885129708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "ServiceId", null);
            }
            /*string? */ set ServiceId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359966188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "ServiceId");
            }
            //--TRIMMABLE-BOUNDARY-END(25770031596)
            
            //--TRIMMABLE-BOUNDARY-START(4295195116)
            //default constructor overload
            $ctor$9()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295195116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295195116)
            
            //--TRIMMABLE-BOUNDARY-START(4295195116)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(4295195116)
            
            static $h = 227820;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38654933484),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475064300,
        "f": 50364417
      },
      "n": "Type",
      "d": 227820,
      "h": 38654933484,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38654933484),
//--TRIMMABLE-BOUNDARY-START(25770031596),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885129708,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34359966188,
        "f": 83886081
      },
      "n": "ServiceId",
      "d": 227820,
      "h": 25770031596,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770031596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295195116),
    {
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 227820,
      "h": 4295195116,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295195116)
  ],
  "h": 227820,
  "a": [
    {
      "t": $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates).$h,
      "c": Number(BigInt($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates).$h)|0x100000000n)
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostRatable, $.$YUlm.LCSCM.IShipmentAccount, $.$Iaui.LCFCM.IApplicationAccountModel, $.$LCOv.LCFCP.IPostNamedLocation, $.$PZCj.LCCGCM.ICommunityGroupModel, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostReactable, $.$LCOv.LCFCP.IPostSharable, $.$LCOv.LCFCP.IPostViewTrackable, $.$LCOv.LCFCP.IPostApplicationScope, $.$LCOv.LCFCP.IGroupAccountModel, $.$LCOv.LCFCP.IUserAccountModel, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Models${separator}CommunityGroupUserPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(227820)
        
        

        //--TRIMMABLE-BOUNDARY-START(489964)
        $asm.$cls(`$RoTr.LCCGUCM.CommunityGroupUserServiceModel`, ($self) => class CommunityGroupUserServiceModel extends $.$Iaui.LCFCM.ServiceModel$$$$($.$RoTr.LCCGUCM.CommunityGroupUserServiceTier, $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(30065261036)
            /*DataId*/ GroupAccountId;
            //--TRIMMABLE-BOUNDARY-END(30065261036)
            
            //--TRIMMABLE-BOUNDARY-START(34360228332)
            /*string? */ get ServiceLink()
            {
                return `/User/${$.$strNN(this.Name)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(34360228332)
            
            //--TRIMMABLE-BOUNDARY-START(8590424556)
            //default constructor overload
            $ctor$9()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590424556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590424556)
            
            //--TRIMMABLE-BOUNDARY-START(8590424556)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(8590424556)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30065261036)
                this.GroupAccountId = $.$default($.$fPer.LCFCD.DataId);
                //--TRIMMABLE-BOUNDARY-END(30065261036)
                
            }
            static $h = 489964;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ServiceModel$$$$($.$RoTr.LCCGUCM.CommunityGroupUserServiceTier, $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065261036),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180359148,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950162924,
        "f": 83886081
      },
      "n": "GroupAccountId",
      "d": 489964,
      "h": 30065261036,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065261036),
//--TRIMMABLE-BOUNDARY-START(34360228332),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770293740,
        "f": 50364417
      },
      "n": "ServiceLink",
      "d": 489964,
      "h": 34360228332,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360228332)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590424556),
    {
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 489964,
      "h": 8590424556,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590424556)
  ],
  "h": 489964
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$RoTr.LCCGUCM.CommunityGroupUserServiceTier), $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Models${separator}CommunityGroupUserServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(489964)
        
        

        //--TRIMMABLE-BOUNDARY-START(358892)
        $asm.$cls(`$RoTr.LCCGUCM.CommunityGroupUserPostModelTypeDescriptor`, ($self) => class CommunityGroupUserPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RoTr.LCCGUCM.CommunityGroupUserPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295326188)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295326188);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RoTr.LCCGUCM.CommunityGroupUserPostModelTypeDescriptor.GenerateProperties($.$RoTr.LCCGUCM.CommunityGroupUserPostModel, this, factory);
                    }, $vOBzpa ??= {"r":65537,"n":"","d":358892,"h":0,"f":17825794}), 0, "CommunityGroupUserPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.User.Common\\Models_CommunityGroupUserPostModel_LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserPostModelTypeDescriptorBuilder.g.cs", "CommunityGroupUserPostModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295326188)
            
            //--TRIMMABLE-BOUNDARY-START(12885260780)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885260780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RoTr.LCCGUCM.CommunityGroupUserPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RoTr.LCCGUCM.CommunityGroupUserPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$RoTr.LCCGUCM.CommunityGroupUserPostModel)).Type);
                        }, $TYIQSj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":358892,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RoTr.LCCGUCM.CommunityGroupUserPostModel.$type, $.$discardRef(), "ServiceId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "ServiceId";
                        $i3.DelaredOn = "LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserPostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RoTr.LCCGUCM.CommunityGroupUserPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$RoTr.LCCGUCM.CommunityGroupUserPostModel)).ServiceId);
                        }, $gUmbBi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":358892,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RoTr.LCCGUCM.CommunityGroupUserPostModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.ServiceId = value.AsReference($.$$.S.String);
                        }, $OcTNif ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":358892,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885260780)
            
            //--TRIMMABLE-BOUNDARY-START(17180228076)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180228076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel<LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserPostSettings, LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserPostStates>?*/ let targetBase = _target;
                $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$RoTr.LCCGUCS.CommunityGroupUserPostSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserPostStates)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _ServiceId = _target.ServiceId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ServiceId, ($v) => _ServiceId = $v, $.$$.S.String)))
                    {
                        _target.ServiceId = _ServiceId;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180228076)
            
            //--TRIMMABLE-BOUNDARY-START(8590293484)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590293484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$RoTr.LCCGUCM.CommunityGroupUserPostModel().$ctor$9();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RoTr.LCCGUCM.CommunityGroupUserPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCM.CommunityGroupUserPostModel)))
                {
                    /*var*/ let result = $.$RoTr.LCCGUCM.CommunityGroupUserPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCM.CommunityGroupUserPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RoTr.LCCGUCM.CommunityGroupUserPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCM.CommunityGroupUserPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590293484)
            
            static $h = 358892;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RoTr.LCCGUCM.CommunityGroupUserPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885260780),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 358892,
      "h": 12885260780,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885260780),
//--TRIMMABLE-BOUNDARY-START(17180228076),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 227820,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 358892,
      "h": 17180228076,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180228076),
//--TRIMMABLE-BOUNDARY-START(8590293484),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 227820,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 358892,
      "h": 8590293484,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590293484)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295326188),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 358892,
      "h": 4295326188,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295326188)
  ],
  "h": 358892
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RoTr.LCCGUCM.CommunityGroupUserPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Models${separator}CommunityGroupUserPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(358892)
        
        

        //--TRIMMABLE-BOUNDARY-START(621036)
        $asm.$cls(`$RoTr.LCCGUCM.CommunityGroupUserServiceModelTypeDescriptor`, ($self) => class CommunityGroupUserServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RoTr.LCCGUCM.CommunityGroupUserServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295588332)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295588332);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RoTr.LCCGUCM.CommunityGroupUserServiceModelTypeDescriptor.GenerateProperties($.$RoTr.LCCGUCM.CommunityGroupUserServiceModel, this, factory);
                    }, $eOqkUk ??= {"r":65537,"n":"","d":621036,"h":0,"f":17825794}), 0, "CommunityGroupUserServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Group.User.Common\\Models_CommunityGroupUserServiceModel_LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserServiceModelTypeDescriptorBuilder.g.cs", "CommunityGroupUserServiceModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295588332)
            
            //--TRIMMABLE-BOUNDARY-START(12885522924)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885522924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("GroupAccountId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RoTr.LCCGUCM.CommunityGroupUserServiceModel.$type, $.$discardRef(), "GroupAccountId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("GroupAccountId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "GroupAccountId";
                        $i1.DelaredOn = "LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserServiceModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RoTr.LCCGUCM.CommunityGroupUserServiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$RoTr.LCCGUCM.CommunityGroupUserServiceModel)).GroupAccountId);
                        }, $SNEJrh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":621036,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RoTr.LCCGUCM.CommunityGroupUserServiceModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.GroupAccountId = value.AsValue($.$fPer.LCFCD.DataId);
                        }, $aLOXsg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":621036,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceLink"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RoTr.LCCGUCM.CommunityGroupUserServiceModel.$type, $.$discardRef(), "ServiceLink", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceLink")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "ServiceLink";
                        $i3.DelaredOn = "LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserServiceModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RoTr.LCCGUCM.CommunityGroupUserServiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$RoTr.LCCGUCM.CommunityGroupUserServiceModel)).ServiceLink);
                        }, $HDRcod ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":621036,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCM.ServiceModelTypeDescriptor$$$$($.$RoTr.LCCGUCM.CommunityGroupUserServiceTier, $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885522924)
            
            //--TRIMMABLE-BOUNDARY-START(17180490220)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180490220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ServiceModel<LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserServiceTier, LivingThing.Core.Community.Group.User.Common.Settings.CommunityGroupUserServiceSettings, LivingThing.Core.Community.Group.User.Common.States.CommunityGroupUserServiceStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ServiceModelTypeDescriptor$$$$($.$RoTr.LCCGUCM.CommunityGroupUserServiceTier, $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ServiceModel$$$$($.$RoTr.LCCGUCM.CommunityGroupUserServiceTier, $.$RoTr.LCCGUCS.CommunityGroupUserServiceSettings, $.$RoTr.LCCGUCS$1.CommunityGroupUserServiceStates)));
                {
                    /*var*/ let _GroupAccountId = _target.GroupAccountId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("GroupAccountId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _GroupAccountId, ($v) => _GroupAccountId = $v, null, true)))
                    {
                        _target.GroupAccountId = $.$clone(_GroupAccountId);
                    }
                }
                {
                    /*var*/ let _ServiceLink = _target.ServiceLink;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceLink"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ServiceLink, ($v) => _ServiceLink = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180490220)
            
            //--TRIMMABLE-BOUNDARY-START(8590555628)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590555628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$RoTr.LCCGUCM.CommunityGroupUserServiceModel().$ctor$9();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RoTr.LCCGUCM.CommunityGroupUserServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCM.CommunityGroupUserServiceModel)))
                {
                    /*var*/ let result = $.$RoTr.LCCGUCM.CommunityGroupUserServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCM.CommunityGroupUserServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RoTr.LCCGUCM.CommunityGroupUserServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RoTr.LCCGUCM.CommunityGroupUserServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590555628)
            
            static $h = 621036;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RoTr.LCCGUCM.CommunityGroupUserServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885522924),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 621036,
      "h": 12885522924,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885522924),
//--TRIMMABLE-BOUNDARY-START(17180490220),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 489964,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 621036,
      "h": 17180490220,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180490220),
//--TRIMMABLE-BOUNDARY-START(8590555628),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 489964,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 621036,
      "h": 8590555628,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590555628)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295588332),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 621036,
      "h": 4295588332,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295588332)
  ],
  "h": 621036
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RoTr.LCCGUCM.CommunityGroupUserServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Group.User.Common.Models.CommunityGroupUserServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Group${separator}User${separator}Common${separator}Models${separator}CommunityGroupUserServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(621036)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Group.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(31212)
