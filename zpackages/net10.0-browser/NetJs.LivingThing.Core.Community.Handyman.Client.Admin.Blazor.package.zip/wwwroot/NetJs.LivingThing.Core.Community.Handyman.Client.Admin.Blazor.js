
//--TRIMMABLE-BOUNDARY-START(49227)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $xrPB, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $UcdF, $SXZI) {
    "use strict";
    let _;
    let $bfgXAf;
    let $NbnBte;
    let $LfoTrg;
    let $rrnHti;
    let $zABvxc;
    let $mfvYNa;
    let $VONPbl;
    let $sBZYIf;
    let $nTVLyj;
    let $tUKBLf;
    let $zPEVvf;
    let $eHmTej;
    let $shCDki;
    let $ctsqQi;
    let $OFdxlh;
    let $IcJfgf;
    let $vuDWTk;
    let $RhQqDe;
    let $duxKwd;
    let $iyufgh;
    let $bHtVhd;
    let $jPTrqb;
    let $tPTvNi;
    let $yCgeth;
    let $UFbuwf;
    let $NTwadj;
    let $OqrYRb;
    let $FzpHoi;
    let $pLGlfg;
    let $GqeyVh;
    let $hJldOa;
    let $cdwGyg;
    let $NiPUVc;
    let $nvmCYe;
    let $rJGKBc;
    let $oNoxld;
    let $zCkHSk;
    let $eiLUnb;
    let $mMwVGf;
    let $tgFRYd;
    let $xHAXTb;
    let $tkecSj;
    let $yYzKdd;
    let $FqnIWa;
    let $OPEnBd;
    let $DqIkfb;
    let $xSGYQi;
    let $pWlZVg;
    let $ZvMEoc;
    let $BqOJKb;
    let $nXOjtb;
    let $aKRrJk;
    let $CXWaJb;
    let $lbjXra;
    let $QalfNi;
    let $cuGLsc;
    let $prXqIk;
    let $tUSjmk;
    let $mWCaNi;
    let $FQpMFg;
    let $ulrTsf;
    let $NPEmBi;
    let $sPUDNf;
    let $jUrhll;
    let $jhIfkk;
    let $XRrWOg;
    let $hzlIpb;
    let $ipWwjh;
    let $tGLBCb;
    let $wpjJJh;
    let $ilIpEj;
    let $piaJHk;
    let $VOZpsi;
    let $dOUMmb;
    let $jTpGtj;
    let $lFYfYa;
    let $LApqgl;
    let $AwYQEa;
    let $YyYbhl;
    let $Cbqjmc;
    let $RSqzPc;
    let $qRIxPg;
    let $JRvVak;
    let $IUIFol;
    let $FnsiYg;
    let $XzBHte;
    let $uoOAxk;
    let $wAZbVe;
    let $HVfstd;
    let $PIYKDa;
    let $vjPRja;
    let $CZrcbe;
    let $hDyxhb;
    let $OFXdNd;
    let $FDHlRk;
    let $kKJeij;
    let $SuAXWg;
    let $NwdxCk;
    let $BGrYMf;
    let $phOHSe;
    let $jaBDRk;
    let $BesUel;
    let $KlRsPg;
    let $hPFYZb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Handyman.Client.Admin.Blazor", 
    {
  "h": 49227,
  "f": "LivingThing.Core.Community.Handyman.Client.Admin.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Handyman.Client.Admin.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Handyman.Client.Admin.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(835659)
        $asm.$cls(`$mpgO.LCCHCA.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295802955)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295802955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mpgO.LCCHCAP.Layers.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mpgO.LCCHCAP.LayersCustomAttributesProvider, $.$mpgO.LCCHCAP.LayersCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295802955)
            
            static $h = 835659;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295802955),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 835659,
      "h": 4295802955,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295802955)
  ],
  "h": 835659
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(835659)
        
        

        //--TRIMMABLE-BOUNDARY-START(901195)
        $asm.$cls(`$mpgO.LCCHCA.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295868491)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295868491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295868491)
            
            static $h = 901195;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295868491),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 901195,
      "h": 4295868491,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295868491)
  ],
  "h": 901195
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(901195)
        
        

        //--TRIMMABLE-BOUNDARY-START(1228875)
        $asm.$cls(`$mpgO.LCCHCAP.LayersCustomAttributesProvider`, ($self) => class LayersCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296196171)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296196171)
            
            //--TRIMMABLE-BOUNDARY-START(8591163467)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591163467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$mpgO.LCCHCAP.LayersCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$mpgO.LCCHCAP.LayersCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $OFdxlh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1228875,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $IcJfgf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1228875,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591163467)
            
            static $h = 1228875;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591163467),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1228875,
      "h": 8591163467,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591163467)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296196171),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1228875,
      "h": 4296196171,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296196171)
  ],
  "h": 1228875
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Pages.LayersCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Pages${separator}LayersCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1228875)
        
        

        //--TRIMMABLE-BOUNDARY-START(180299)
        $asm.$cls(`$mpgO._LCCHCAPS.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295147595)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295147595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "PlaceHolder", __arg0);
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295147595)
            
            static $h = 180299;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295147595),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 180299,
      "h": 4295147595,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295147595)
  ],
  "h": 180299
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Handyman.Client.Admin.Pages.SituationRoom.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Pages${separator}SituationRoom${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(180299)
        
        

        //--TRIMMABLE-BOUNDARY-START(245835)
        $asm.$cls(`$mpgO._LCCHCAPV.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295213131)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295213131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "Theme", $.$clone(__arg1));
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295213131)
            
            //--TRIMMABLE-BOUNDARY-START(8590180427)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg1, /*int*/ __seq2, /*global::System.String*/ __arg2, /*int*/ __seq3, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg3, /*int*/ __seq4, /*TValue*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg5, /*int*/ __seq6, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg6)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590180427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "Type", $.$box(__arg1, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq2, "PlaceHolder", __arg2);
                __builder.AddComponentParameter(__seq3, "Theme", $.$clone(__arg3));
                __builder.AddComponentParameter(__seq4, "Value", $.$box(__arg4, TValue));
                __builder.AddComponentParameter(__seq5, "ValueChanged", __arg5);
                __builder.AddComponentParameter(__seq6, "ValueExpression", __arg6);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590180427)
            
            static $h = 245835;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295213131),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 65309014
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 245835,
      "h": 4295213131,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295213131),
//--TRIMMABLE-BOUNDARY-START(8590180427),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 47614294
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 1310721
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 65309014
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq6",
          "p": 655361
        },
        {
          "n": "__arg6",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 245835,
      "h": 8590180427,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590180427)
  ],
  "h": 245835
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Handyman.Client.Admin.Pages.VerificationEditor.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Pages${separator}VerificationEditor${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(245835)
        
        

        //--TRIMMABLE-BOUNDARY-START(114763)
        $asm.$cls(`$mpgO._LCCHCAPC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295082059)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295082059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "ChildContent", __arg1);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295082059)
            
            static $h = 114763;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295082059),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 114763,
      "h": 4295082059,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295082059)
  ],
  "h": 114763
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Handyman.Client.Admin.Pages.CommunityHandymanAdminApp.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Pages${separator}CommunityHandymanAdminApp${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(114763)
        
        

        //--TRIMMABLE-BOUNDARY-START(1032267)
        $asm.$cls(`$mpgO.LCCHCA.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590966859)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590966859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$mpgO.LCCHCAE.HandymanAccountSuspension, "LivingThing.Core.Community.Handyman.Client.Admin", "Emails\\HandymanAccountSuspension", "Handyman Account Suspension", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Handyman/AccountSuspension" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$mpgO.LCCHCAE.HandymanAccountVerified, "LivingThing.Core.Community.Handyman.Client.Admin", "Emails\\HandymanAccountVerified", "Handyman Account Verified", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Handyman/AccountVerified" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$mpgO.LCCHCAE.HandymanCompleteYourRegistration, "LivingThing.Core.Community.Handyman.Client.Admin", "Emails\\HandymanCompleteYourRegistration", "Handyman Complete Your Registration", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Handyman/CompleteRegistration" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$mpgO.LCCHCAE.HandymanComposeEmail, "LivingThing.Core.Community.Handyman.Client.Admin", "Emails\\HandymanComposeEmail", "Handyman Compose Email", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Handyman/ComposeEmail" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$mpgO.LCCHCAE.HandymanCoupon, "LivingThing.Core.Community.Handyman.Client.Admin", "Emails\\HandymanCoupon", "Handyman Coupon", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Handyman/AccountRewardCoupon" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$mpgO.LCCHCAP.CommunityHandymanAdminApp, "LivingThing.Core.Community.Handyman.Client.Admin", "Pages\\CommunityHandymanAdminApp", "Community Handyman Admin App", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Admin/Handyman", "/Admin/Handyman/{*Page}" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$mpgO.LCCHCAP.SituationRoom, "LivingThing.Core.Community.Handyman.Client.Admin", "Pages\\SituationRoom", "Situation Room", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Admin/Handyman/SituationRoom" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590966859)
            
            //--TRIMMABLE-BOUNDARY-START(4295999563)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295999563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295999563)
            
            //--TRIMMABLE-BOUNDARY-START(4295999563)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295999563)
            
            static $h = 1032267;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590966859),
    {
      "r": 65537,
      "n": "Build",
      "d": 1032267,
      "h": 8590966859,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590966859)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295999563),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1032267,
      "h": 4295999563,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295999563)
  ],
  "h": 1032267
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1032267)
        
        

        //--TRIMMABLE-BOUNDARY-START(376907)
        $asm.$cls(`$mpgO.LCCHCA._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295344203)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295344203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$mpgO.LCCHCA.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295344203)
            
            static $h = 376907;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295344203),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 376907,
      "h": 4295344203,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295344203)
  ],
  "h": 376907
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(376907)
        
        

        //--TRIMMABLE-BOUNDARY-START(966731)
        $asm.$cls(`$mpgO.LCCHCA.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180835915)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$mpgO.LCCHCAE.HandymanAccountSuspension.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$mpgO.LCCHCAE.HandymanAccountSuspension().$ctor$4();
                    }, $bfgXAf ??= {"r":2752627,"n":"","d":966731,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$mpgO.LCCHCAE.HandymanAccountVerified.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$mpgO.LCCHCAE.HandymanAccountVerified().$ctor$4();
                    }, $NbnBte ??= {"r":2752627,"n":"","d":966731,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$mpgO.LCCHCAE.HandymanCompleteYourRegistration.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$mpgO.LCCHCAE.HandymanCompleteYourRegistration().$ctor$4();
                    }, $LfoTrg ??= {"r":2752627,"n":"","d":966731,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$mpgO.LCCHCAE.HandymanComposeEmail.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$mpgO.LCCHCAE.HandymanComposeEmail().$ctor$4();
                    }, $rrnHti ??= {"r":2752627,"n":"","d":966731,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$mpgO.LCCHCAE.HandymanCoupon.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$mpgO.LCCHCAE.HandymanCoupon().$ctor$4();
                    }, $zABvxc ??= {"r":2752627,"n":"","d":966731,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$mpgO.LCCHCAE.HandymanEmailLayout.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$mpgO.LCCHCAE.HandymanEmailLayout().$ctor$3();
                    }, $mfvYNa ??= {"r":2752627,"n":"","d":966731,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$mpgO.LCCHCAP.CommunityHandymanAdminApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$mpgO.LCCHCAP.CommunityHandymanAdminApp().$ctor$3();
                    }, $VONPbl ??= {"r":2752627,"n":"","d":966731,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$mpgO.LCCHCAP.SituationRoom.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$mpgO.LCCHCAP.SituationRoom().$ctor$3();
                    }, $sBZYIf ??= {"r":2752627,"n":"","d":966731,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$mpgO.LCCHCAP.VerificationEditor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$mpgO.LCCHCAP.VerificationEditor().$ctor$5();
                    }, $nTVLyj ??= {"r":2752627,"n":"","d":966731,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180835915)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295934027)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295934027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295934027)
            
            //--TRIMMABLE-BOUNDARY-START(4295934027)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295934027)
            
            static $h = 966731;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180835915),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885868619,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 966731,
      "h": 17180835915,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180835915)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295934027),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 966731,
      "h": 4295934027,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295934027)
  ],
  "h": 966731
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(966731)
        
        

        //--TRIMMABLE-BOUNDARY-START(1425483)
        $asm.$cls(`$mpgO.LCCHCA.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591360075)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591360075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$mpgO.LCCHCAS.CommunityHandymanServiceAccountVerificationCommand, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mpgO.LCCHCAS.CommunityHandymanServiceAccountVerificationCommand, x);
                }, $dOUMmb ??= {"r":$.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":1425483,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$UrvY.LCFCM.IMessageComposerProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$UrvY.LCFCM.IMessageComposerProvider$$($.$LCOv.LCFCPM$1.AccountModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$mpgO.LCCHCAS.CommunityHandymanUserMessageComposerProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$UrvY.LCFCM.IMessageComposerProvider$$($.$LCOv.LCFCPM$1.AccountModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mpgO.LCCHCAS.CommunityHandymanUserMessageComposerProvider, x);
                }, $jTpGtj ??= {"r":$.$UrvY.LCFCM.IMessageComposerProvider$$($.$LCOv.LCFCPM$1.AccountModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":1425483,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$UrvY.LCFCM.IMessageComposerProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mpgO.LCCHCAS.CommunityHandymanUserMessageComposerProvider, x);
                }, $lFYfYa ??= {"r":210396,"p":[{"n":"x","p":327718}],"n":"","d":1425483,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$UrvY.LCFCM.IMessageComposerProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$UrvY.LCFCM.IMessageComposerProvider$$($.$LCOv.LCFCPM$1.AccountModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$mpgO.LCCHCAS.CommunityHandymanAgentMessageComposerProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$UrvY.LCFCM.IMessageComposerProvider$$($.$LCOv.LCFCPM$1.AccountModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mpgO.LCCHCAS.CommunityHandymanAgentMessageComposerProvider, x);
                }, $LApqgl ??= {"r":$.$UrvY.LCFCM.IMessageComposerProvider$$($.$LCOv.LCFCPM$1.AccountModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":1425483,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$UrvY.LCFCM.IMessageComposerProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mpgO.LCCHCAS.CommunityHandymanAgentMessageComposerProvider, x);
                }, $AwYQEa ??= {"r":210396,"p":[{"n":"x","p":327718}],"n":"","d":1425483,"h":0,"f":17825794}));
                $.$hDPm.LCFCI.AdministrativeComponentProviderExtension.AddAdminPage($.$mpgO.LCCHCAP.CommunityHandymanAdminApp, services, "Handyman", "mdi mdi-handshake"/*MaterialDesignIconNames.Handshake*/);
                $.$mpgO.LCCHCA._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591360075)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mpgO.LCCHCA.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296392779)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296392779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296392779)
            
            //--TRIMMABLE-BOUNDARY-START(4296392779)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296392779)
            
            static $h = 1425483;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591360075),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1425483,
      "h": 8591360075,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591360075)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296392779),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1425483,
      "h": 4296392779,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296392779)
  ],
  "h": 1425483
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1425483)
        
        

        //--TRIMMABLE-BOUNDARY-START(1949771)
        $asm.$cls(`$mpgO.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296917067)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296917067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296917067)
            
            //--TRIMMABLE-BOUNDARY-START(4296917067)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296917067)
            
            static $h = 1949771;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296917067),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1949771,
      "h": 4296917067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296917067)
  ],
  "h": 1949771
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1949771)
        
        

        //--TRIMMABLE-BOUNDARY-START(2015307)
        $asm.$cls(`$mpgO.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296982603)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296982603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296982603)
            
            //--TRIMMABLE-BOUNDARY-START(4296982603)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296982603)
            
            static $h = 2015307;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296982603),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2015307,
      "h": 4296982603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296982603)
  ],
  "h": 2015307,
  "a": [
    {
      "t": 1949771,
      "c": 4296917067
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2015307)
        
        

        //--TRIMMABLE-BOUNDARY-START(1163339)
        $asm.$str(`$mpgO.LCCHCAP.Layers`, ($self) => class Layers extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Handymen = 1;
            static OnlineUsers = 2;
            static ServiceRequests = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1163339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Handymen": 1n,
                    "OnlineUsers": 2n,
                    "ServiceRequests": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296130635)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296130635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296130635)
            
            //--TRIMMABLE-BOUNDARY-START(4296130635)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296130635)
            
            static $h = 1163339;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886065227),
    {
      "t": 1163339,
      "n": "None",
      "d": 1163339,
      "h": 12886065227,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886065227),
//--TRIMMABLE-BOUNDARY-START(8591097931),
    {
      "t": 1163339,
      "n": "Handymen",
      "d": 1163339,
      "h": 8591097931,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591097931),
//--TRIMMABLE-BOUNDARY-START(17181032523),
    {
      "t": 1163339,
      "n": "OnlineUsers",
      "d": 1163339,
      "h": 17181032523,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181032523),
//--TRIMMABLE-BOUNDARY-START(21475999819),
    {
      "t": 1163339,
      "n": "ServiceRequests",
      "d": 1163339,
      "h": 21475999819,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475999819)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296130635),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1163339,
      "h": 4296130635,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296130635)
  ],
  "h": 1163339,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Pages.Layers`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Pages${separator}Layers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1163339)
        
        

        //--TRIMMABLE-BOUNDARY-START(311371)
        $asm.$cls(`$mpgO.LCCHCA._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590245963)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590245963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590245963)
            
            //--TRIMMABLE-BOUNDARY-START(4295278667)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295278667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295278667)
            
            //--TRIMMABLE-BOUNDARY-START(4295278667)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295278667)
            
            static $h = 311371;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590245963),
    {
      "r": 65537,
      "n": "Execute",
      "d": 311371,
      "h": 8590245963,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590245963)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295278667),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 311371,
      "h": 4295278667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295278667)
  ],
  "h": 311371
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(311371)
        
        

        //--TRIMMABLE-BOUNDARY-START(770123)
        $asm.$cls(`$mpgO.LCCHCAE.HandymanEmailLayout`, ($self) => class HandymanEmailLayout extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(38655475787)
            /*string */ get OptimizedComponentName()
            {
                return "handymanemaillayout";
            }
            //--TRIMMABLE-BOUNDARY-END(38655475787)
            
            //--TRIMMABLE-BOUNDARY-START(17180639307)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180639307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<div class=\"pd bg-primary\"><h1 class=\"mg-0\">HANDYMAN</h1></div>\r\n");
                __builder.OpenElement(1, "img");
                __builder.AddAttribute$5(2, "src", this.ResolvePath("img/handymanIllustration.jpg", true, true, false));
                __builder.AddAttribute$5(3, "class", "wf mgb-10");
                __builder.CloseElement();
                __builder.AddMarkupContent(4, "\r\n\r\n");
                __builder.AddContent$1(5, this.Body);
                __builder.AddMarkupContent(6, "\r\n\r\n");
                __builder.AddMarkupContent(7, "<div class=\"pd bg-primary mgt-10\"><p>Zoey Handyman\u2122</p>\r\n    <p>SAKE Innovation and Technologies\u00AE</p>\r\n    <p><a href=\"https://zoey.africa\">https://zoey.africa</a> | <a href=\"https://sake.org.ng\">https://sake.org.ng</a></p></div>");
            }
            //--TRIMMABLE-BOUNDARY-END(17180639307)
            
            //--TRIMMABLE-BOUNDARY-START(12885672011)
            /*RenderFragment?*/ Body = null;
            //--TRIMMABLE-BOUNDARY-END(12885672011)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590704715)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590704715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590704715)
            
            //--TRIMMABLE-BOUNDARY-START(8590704715)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590704715)
            
            static $h = 770123;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655475787),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360508491,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 770123,
      "h": 38655475787,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655475787),
//--TRIMMABLE-BOUNDARY-START(12885672011),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770573899,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245410379,
        "f": 83886081
      },
      "n": "Body",
      "d": 770123,
      "h": 12885672011,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885672011)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180639307),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 770123,
      "h": 17180639307,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180639307)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590704715),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 770123,
      "h": 8590704715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590704715)
  ],
  "h": 770123
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Emails.HandymanEmailLayout`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Emails${separator}HandymanEmailLayout`; }
        });
        //--TRIMMABLE-BOUNDARY-END(770123)
        
        

        //--TRIMMABLE-BOUNDARY-START(1294411)
        $asm.$cls(`$mpgO.LCCHCAP.SituationRoom`, ($self) => class SituationRoom extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(103080509515)
            /*string */ get OptimizedComponentName()
            {
                return "situationroom";
            }
            //--TRIMMABLE-BOUNDARY-END(103080509515)
            
            //--TRIMMABLE-BOUNDARY-START(68720771147)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720771147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$SXZI.LCCHCS.CommunityHandymanService, serviceProvider);
                this.MessagePipeFactory = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UrvY.LCFCM.IMessagePipeFactory, serviceProvider);
                this.ServiceFilters = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$UcdF.LCCHCS.ICommunityHandymanServiceFilter), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(68720771147)
            
            //--TRIMMABLE-BOUNDARY-START(81605673035)
            /*int*/ static locationRadius = 3000;
            //--TRIMMABLE-BOUNDARY-END(81605673035)
            
            //--TRIMMABLE-BOUNDARY-START(77310705739)
            /*SchemaAttribute<Layers>*/ layers = null;
            //--TRIMMABLE-BOUNDARY-END(77310705739)
            
            //--TRIMMABLE-BOUNDARY-START(128850313291)
            /*CommunityHandymanService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(128850313291)
            
            //--TRIMMABLE-BOUNDARY-START(85900640331)
            /*IMessagePipeFactory*/ MessagePipeFactory = null;
            //--TRIMMABLE-BOUNDARY-END(85900640331)
            
            //--TRIMMABLE-BOUNDARY-START(133145280587)
            /*IEnumerable<ICommunityHandymanServiceFilter>*/ ServiceFilters = null;
            //--TRIMMABLE-BOUNDARY-END(133145280587)
            
            //--TRIMMABLE-BOUNDARY-START(90195607627)
            /*Dictionary<string, CommunityHandymanServiceRequestDiscoContextModel>*/ ongoingServiceRequests = null;
            //--TRIMMABLE-BOUNDARY-END(90195607627)
            
            //--TRIMMABLE-BOUNDARY-START(98785542219)
            /*List<CommunityHandymanServiceAccountMetadataModel>*/ onlineUsers = null;
            //--TRIMMABLE-BOUNDARY-END(98785542219)
            
            //--TRIMMABLE-BOUNDARY-START(64425803851)
            /*IEnumerable<AccountModel>*/ handymen = null;
            //--TRIMMABLE-BOUNDARY-END(64425803851)
            
            //--TRIMMABLE-BOUNDARY-START(115965411403)
            /*AccountModel?*/ selectedHandyman = null;
            //--TRIMMABLE-BOUNDARY-END(115965411403)
            
            //--TRIMMABLE-BOUNDARY-START(124555345995)
            /*CommunityHandymanServiceAccountMetadataModel?*/ selectedUser = null;
            //--TRIMMABLE-BOUNDARY-END(124555345995)
            
            //--TRIMMABLE-BOUNDARY-START(120260378699)
            /*string?*/ selectedService = null;
            //--TRIMMABLE-BOUNDARY-END(120260378699)
            
            //--TRIMMABLE-BOUNDARY-START(73015738443)
            /*Layers*/ layer = 6;
            //--TRIMMABLE-BOUNDARY-END(73015738443)
            
            //--TRIMMABLE-BOUNDARY-START(107375476811)
            /*IMessagePipe?*/ pipe = null;
            //--TRIMMABLE-BOUNDARY-END(107375476811)
            
            //--TRIMMABLE-BOUNDARY-START(94490574923)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    let $t4, $r4;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490574923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.handymen = (($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$LCOv.LCFCPM$1.AccountModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$UcdF.LCCHC.HandymanUtility.SearchServiceAccount.OverrideWith(new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1196268653051967n | 8388608n | 4194304n | 2251799813685248n | 18014398509481984n | 140737488355328n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)).WithAttribute$1($.$$.S.String, "FeatureProperties", $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.GetFeatureKey(null), 0)), null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)))).Data;
                    /*var*/ let report = ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$UcdF.LCCHCS.ICommunityHandymanRemoteService, $.$UcdF.LCCHCM.CommunityHandymanSituationReportModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$UcdF.LCCHCS.ICommunityHandymanRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$UcdF.LCCHCM.CommunityHandymanSituationReportModel)))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LCCHCS$ICommunityHandymanRemoteService$GetSituationReport();
                    }, $YyYbhl ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$UcdF.LCCHCM.CommunityHandymanSituationReportModel)).$h,"p":[{"n":"server","p":6870720}],"n":"","d":1294411,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    let $en3 = report.PendingRequests.SCG$IEnumerable$$$GetEnumerator();
                    while ($en3.SC$1$IEnumerator$MoveNext())
                    {
                        let pr = $en3.SCG$IEnumerator$$$Current;
                        {
                            this.ongoingServiceRequests.Add(pr.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$WorkId, pr);
                        }
                    }
                    this.onlineUsers.AddRange(report.OnlineHandymen);
                    this.pipe = ($t4 = $.$UrvY.LCFCM.MessagePipeFactoryExtension.Join(this.MessagePipeFactory, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("__SituationRoom__"/*CommunityHandymanModel.SituationRoomPipeId*/), new $.$kVHt.LCFCH.WebSocketClientMetadata()), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    this.pipe.LCFCM$IMessagePipe$Subscribe($.$UcdF.LCCHCM.CommunityHandymanServiceAccountMetadataModel, new ($.$$.S.Action$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountMetadataModel))().$ctor(this,  (/*meta*/ meta) =>
                    {
                        /*var*/ let existing = $.$sl.SL.Enumerable.SingleOrDefault$1($.$UcdF.LCCHCM.CommunityHandymanServiceAccountMetadataModel, this.onlineUsers, new ($.$$.S.Func$$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountMetadataModel, $.$$.S.Boolean))().$ctor(this,  (/*o*/ o) =>
                        {
                            return o.ServiceAccount.Identifier.Equals$2(meta.ServiceAccount.Identifier);
                        }, $Cbqjmc ??= {"r":262145,"p":[{"n":"o","p":2152128}],"n":"","d":1294411,"h":0,"f":17825794}));
                        if (existing !== null)
                        {
                            existing.Location = meta.Location;
                            existing.Route = meta.Route;
                            existing.SearchRadius = meta.SearchRadius;
                            existing.LastSeenOnline = meta.LastSeenOnline;
                        }
                        else 
                        {
                            this.onlineUsers.Add(meta);
                        }
                        _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Handyman.Client.Admin.Blazor\\SituationRoom.razor.cs", "OnInitializedAsync", 74);
                    }, $RSqzPc ??= {"r":65537,"p":[{"n":"meta","p":2152128}],"n":"","d":1294411,"h":0,"f":17825794}));
                    this.pipe.LCFCM$IMessagePipe$Subscribe($.$UcdF.LCCHCM.CommunityHandymanServiceRequestDiscoContextModel, new ($.$$.S.Action$$($.$UcdF.LCCHCM.CommunityHandymanServiceRequestDiscoContextModel))().$ctor(this,  (/*request*/ request) =>
                    {
                        this.ongoingServiceRequests.set_Item($.$dspc(request.ServiceRequest.LCFCP$IPost$Identifier.Id, $.$$.S.Object, ($t) => $t.ToString), request);
                        _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Handyman.Client.Admin.Blazor\\SituationRoom.razor.cs", "OnInitializedAsync", 79);
                    }, $qRIxPg ??= {"r":65537,"p":[{"n":"request","p":3987136}],"n":"","d":1294411,"h":0,"f":17825794}));
                    ($t5 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94490574923)
            
            //--TRIMMABLE-BOUNDARY-START(111670444107)
            /*Task *//*async*/  Remove(/*CommunityHandymanServiceRequestDiscoContextModel*/ c)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670444107);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Confirm(`Cancel ${$.$strNN(c.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$WorkId)}?`, "This will remove this job.", "Yes", "No"), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    ($t7 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$UcdF.LCCHCS.ICommunityHandymanRemoteService, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$UcdF.LCCHCS.ICommunityHandymanRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LCCHCS$ICommunityHandymanRemoteService$Remove(c.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$WorkId);
                    }, $JRvVak ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"s","p":6870720}],"n":"","d":1294411,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    this.ongoingServiceRequests.Remove$1(c.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$WorkId);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111670444107)
            
            //--TRIMMABLE-BOUNDARY-START(25771098187)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771098187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.pipe?.S$IDisposable$Dispose();
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(25771098187)
            
            //--TRIMMABLE-BOUNDARY-START(21476130891)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476130891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "stack hf");
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataListFilter$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel), 2);
                __builder.AddComponentParameter(3, "Class", "bg-card");
                __builder.AddAttribute$3(4, "RightToolBars", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*right*/ right) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        /*var*/ let ft = right.GetAttribute($.$hDPm.LCFCCD$1.DataListFilter$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel), null, true);
                        $.$mpgO._LCCHCAPS.TypeInference.CreateInputEditor_0($.$mpgO.LCCHCAP.Layers, __builder2, 5, 6, "Layers", 7, this.layer, 8, $.$mac.MAC.EventCallback.Factory.Create$6($.$mpgO.LCCHCAP.Layers, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$mpgO.LCCHCAP.Layers, this, new ($.$$.S.Action$$($.$mpgO.LCCHCAP.Layers))().$ctor(this,  (/**/ __value) =>
                        {
                            return this.layer = __value;
                        }, $IUIFol ??= {"r":65537,"p":[{"n":"__value","p":1163339}],"n":"","d":1294411,"h":0,"f":17825794}), this.layer)), 9, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                        {
                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "layer"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                        }, $FnsiYg ??= {"r":38797349,"n":"","d":1294411,"h":0,"f":17825794})).Invoke()));
                    }, $XzBHte ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1294411,"h":0,"f":17825794});
                }), $uoOAxk ??= {"r":6881395,"p":[{"n":"right","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1294411,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$fPer.LCFCD.DataFilter)))().$ctor(this, ( (/*filter*/ filter) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        /*var*/ let filterAccountType = filter.Data.GetAttribute$3($.$typeNullable($.$UcdF.LCCHCM.CommunityHandymanServiceAccountType), "AccountType");
                        /*var*/ let name = filter.Data.GetAttribute$3($.$$.S.String, "FullName");
                        /*var*/ let location = filter.Data.GetAttribute$3($.$fPer.LCFCDG.INamedLocation, "NamedLocation");
                        __builder2.OpenElement(11, "div");
                        __builder2.AddAttribute$5(12, "class", "fill bg-dark-01");
                        __builder2.SetKey($.$box($.$$.S.HashCode.Combine$6($.$hDPm.LCFCI.ContainerContext$$($.$fPer.LCFCD.DataFilter), $.$mpgO.LCCHCAP.Layers, $.$clone(filter), this.layer), $.$$.S.Int32));
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM.LeafletMap, 13);
                        __builder2.AddAttribute$3(14, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            if (location !== null)
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCM.MapCircle, 15);
                                __builder3.AddComponentParameter(16, "Center", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDG.GeoLocation, $.$cast(location, $.$fPer.LCFCDG.GeoLocation)));
                                __builder3.AddComponentParameter(17, "Radius", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDM.Length, new $.$fPer.LCFCDM.Length().$ctor$3(3000/*locationRadius*/, 1/*LengthUnitTypes.m*/)));
                                __builder3.AddComponentParameter(18, "Color", "#00AEFF");
                                __builder3.CloseComponent();
                            }
                            if (((this.layer & (1/*Layers.Handymen*/)) == (1/*Layers.Handymen*/)))
                            {
                                let $en8 = $.$sl.SL.Enumerable.Where($.$LCOv.LCFCPM$1.AccountModel, this.handymen, new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.AccountModel, $.$$.S.Boolean))().$ctor(this,  (/*h*/ h) =>
                                {
                                    /*var*/ let ft = $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.From(h, null, null);
                                    /*string?*/ let __ca1__;
                                    /*LivingThing.Core.Community.Handyman.Common.Models.CommunityHandymanServiceAccountFeatureModel?*/ let __ca2__;
                                    /*string?*/ let __ca3__;
                                    return (filterAccountType === null || (ft?.AccountType ?? null) === filterAccountType) && (name === null || (((__ca1__ = h.Title) !== null ? $.$$.S.String.Contains$3.call(__ca1__, name) : false)) || (((__ca2__ = ft) !== null ? ((__ca3__ = __ca2__.FullName$1) !== null ? $.$$.S.String.Contains$2.call(__ca3__, name, 3/*StringComparison.InvariantCultureIgnoreCase*/) : false) : false))) && (location === null || (ft?.NamedLocation ?? null) === location);
                                }, $wAZbVe ??= {"r":262145,"p":[{"n":"h","p":7858612}],"n":"","d":1294411,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                                while ($en8.SC$1$IEnumerator$MoveNext())
                                {
                                    let _handyman = $en8.SCG$IEnumerator$$$Current;
                                    {
                                        /*var*/ let ft = $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.From(_handyman, null, null);
                                        /*var*/ let handyman = _handyman;
                                        __builder3.OpenComponent$1($.$hDPm.LCFCCM.MapMarker, 19);
                                        __builder3.AddComponentParameter(20, "Location", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDG.GeoLocation, $.$cast((ft?.NamedLocation ?? null), $.$fPer.LCFCDG.GeoLocation)));
                                        __builder3.AddComponentParameter(21, "Label", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, handyman.Title));
                                        __builder3.AddComponentParameter(22, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 64), $.$$.S.Int32));
                                        __builder3.AddComponentParameter(23, "Width", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 64), $.$$.S.Int32));
                                        __builder3.AddAttribute$3(24, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 25);
                                            __builder4.AddComponentParameter(26, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, handyman.Icon));
                                            __builder4.AddComponentParameter(27, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                            __builder4.AddComponentParameter(28, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 63), $.$$.S.Int32));
                                            __builder4.AddComponentParameter(29, "Width", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 63), $.$$.S.Int32));
                                            __builder4.AddComponentParameter(30, "Class", "round");
                                            __builder4.AddComponentParameter(31, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                            {
                                                return this.selectedHandyman = handyman;
                                            }, $HVfstd ??= {"r":65537,"n":"","d":1294411,"h":0,"f":17825794})));
                                            __builder4.CloseComponent();
                                        }), $PIYKDa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1294411,"h":0,"f":17825794}));
                                        __builder3.CloseComponent();
                                    }
                                }
                            }
                            if (((this.layer & (2/*Layers.OnlineUsers*/)) == (2/*Layers.OnlineUsers*/)))
                            {
                                let $en9 = $.$sl.SL.Enumerable.Where($.$UcdF.LCCHCM.CommunityHandymanServiceAccountMetadataModel, this.onlineUsers, new ($.$$.S.Func$$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountMetadataModel, $.$$.S.Boolean))().$ctor(this,  (/*h*/ h) =>
                                {
                                    /*var*/ let ft = $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.From(h.ServiceAccount, null, null);
                                    /*string?*/ let __ca4__;
                                    /*LivingThing.Core.Community.Handyman.Common.Models.CommunityHandymanServiceAccountFeatureModel?*/ let __ca5__;
                                    /*string?*/ let __ca6__;
                                    return (filterAccountType === null || (ft?.AccountType ?? null) === filterAccountType) && (name === null || (((__ca4__ = h.ServiceAccount.Title) !== null ? $.$$.S.String.Contains$3.call(__ca4__, name) : false)) || (((__ca5__ = ft) !== null ? ((__ca6__ = __ca5__.FullName$1) !== null ? $.$$.S.String.Contains$2.call(__ca6__, name, 3/*StringComparison.InvariantCultureIgnoreCase*/) : false) : false))) && (location === null || (ft?.NamedLocation ?? null) === location);
                                }, $vjPRja ??= {"r":262145,"p":[{"n":"h","p":2152128}],"n":"","d":1294411,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                                while ($en9.SC$1$IEnumerator$MoveNext())
                                {
                                    let _user = $en9.SCG$IEnumerator$$$Current;
                                    {
                                        /*var*/ let user = _user;
                                        __builder3.OpenComponent$1($.$hDPm.LCFCCM.MapMarker, 32);
                                        __builder3.AddComponentParameter(33, "Location", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDG.GeoLocation, user.Location));
                                        __builder3.AddComponentParameter(34, "Label", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, user.ServiceAccount.Title));
                                        __builder3.AddComponentParameter(35, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 64), $.$$.S.Int32));
                                        __builder3.AddComponentParameter(36, "Width", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 64), $.$$.S.Int32));
                                        __builder3.AddAttribute$3(37, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 38);
                                            __builder4.AddComponentParameter(39, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, user.ServiceAccount.Icon));
                                            __builder4.AddComponentParameter(40, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                            __builder4.AddComponentParameter(41, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 63), $.$$.S.Int32));
                                            __builder4.AddComponentParameter(42, "Width", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 63), $.$$.S.Int32));
                                            __builder4.AddComponentParameter(43, "Class", "round");
                                            __builder4.AddComponentParameter(44, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                            {
                                                return this.selectedUser = user;
                                            }, $CZrcbe ??= {"r":65537,"n":"","d":1294411,"h":0,"f":17825794})));
                                            __builder4.CloseComponent();
                                        }), $hDyxhb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1294411,"h":0,"f":17825794}));
                                        __builder3.AddAttribute$3(45, "Popup", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$1(46, $.$SXZI.LCCHCS$1.HandymanViews.ServiceAccountCard(user.ServiceAccount, this.Service, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                            {
                                                /*var*/ let svc;
                                                if (this.selectedService !== null && this.ongoingServiceRequests.TryGetValue(this.selectedService, $.$ref(() => svc, ($v) => svc = $v, $.$UcdF.LCCHCM.CommunityHandymanServiceRequestDiscoContextModel)))
                                                {
                                                    if ($.$sl.SL.Enumerable.Any($.$UcdF.LCCHCS.ICommunityHandymanServiceFilter, this.ServiceFilters, new ($.$$.S.Func$$$($.$UcdF.LCCHCS.ICommunityHandymanServiceFilter, $.$$.S.Boolean))().$ctor(this,  (/*i*/ i) =>
                                                    {
                                                        return i.LCCHCS$ICommunityHandymanServiceFilter$CanHandleServiceRequest(svc.ServiceRequest, user, this.Service.GlobalSettings);
                                                    }, $OFXdNd ??= {"r":262145,"p":[{"n":"i","p":7067328}],"n":"","d":1294411,"h":0,"f":17825794})))
                                                    {
                                                        __builder5.OpenElement(47, "span");
                                                        __builder5.AddAttribute$5(48, "class", "bg-primary pdx-2 pdy-1 mgl mgy-a flex fsz-12 corner");
                                                        __builder5.AddMarkupContent(49, "<i class=\"mdi mdi-check\"></i> ");
                                                        __builder5.AddContent$4(50, svc.ServiceRequest.LCFCP$IPost$Title);
                                                        __builder5.CloseElement();
                                                    }
                                                }
                                            }, $FDHlRk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1294411,"h":0,"f":17825794}), null, null, true));
                                        }), $kKJeij ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1294411,"h":0,"f":17825794}));
                                        __builder3.CloseComponent();
                                        if (user === this.selectedUser)
                                        {
                                            if (this.selectedUser.SearchRadius > 0)
                                            {
                                                __builder3.OpenComponent$1($.$hDPm.LCFCCM.MapCircle, 51);
                                                __builder3.AddComponentParameter(52, "Radius", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDM.Length, new $.$fPer.LCFCDM.Length().$ctor$3(this.selectedUser.SearchRadius, 7/*LengthUnitTypes.km*/)));
                                                __builder3.AddComponentParameter(53, "Center", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDG.GeoLocation, this.selectedUser.Location));
                                                __builder3.AddComponentParameter(54, "Color", "#00AEFF");
                                                __builder3.SetKey($.$box($.$$.S.HashCode.Combine$5($.$UcdF.LCCHCM.CommunityHandymanServiceAccountMetadataModel, $.$$.S.Double, $.$fPer.LCFCDG.GeoLocation, this.selectedUser, this.selectedUser.SearchRadius, this.selectedUser.Location), $.$$.S.Int32));
                                                __builder3.CloseComponent();
                                            }
                                            if ((this.selectedUser.Route?.Geometries ?? null) !== null)
                                            {
                                                __builder3.OpenComponent$1($.$hDPm.LCFCCM.MapPolyline, 55);
                                                __builder3.AddComponentParameter(56, "Points", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.GeoLocation), this.selectedUser.Route.Geometries));
                                                __builder3.AddComponentParameter(57, "Color", "#00AEFF");
                                                __builder3.SetKey($.$box($.$$.S.HashCode.Combine$5($.$UcdF.LCCHCM.CommunityHandymanServiceAccountMetadataModel, $.$fPer.LCFCDG.GeoLocation, $.$$.S.Int32, this.selectedUser, this.selectedUser.Location, 1000), $.$$.S.Int32));
                                                __builder3.CloseComponent();
                                                __builder3.AddMarkupContent(58, "\r\n                                    ");
                                                __builder3.OpenComponent$1($.$hDPm.LCFCCM.MapMarker, 59);
                                                __builder3.AddComponentParameter(60, "Location", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDG.GeoLocation, this.selectedUser.Route.End));
                                                __builder3.AddComponentParameter(61, "Label", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN(this.selectedUser.ServiceAccount.Title) + " Destination"));
                                                __builder3.SetKey($.$box($.$$.S.HashCode.Combine$5($.$UcdF.LCCHCM.CommunityHandymanServiceAccountMetadataModel, $.$fPer.LCFCDG.GeoLocation, $.$$.S.Int32, this.selectedUser, this.selectedUser.Location, 5000), $.$$.S.Int32));
                                                __builder3.CloseComponent();
                                            }
                                        }
                                    }
                                }
                            }
                            if (((this.layer & (4/*Layers.ServiceRequests*/)) == (4/*Layers.ServiceRequests*/)))
                            {
                                let $en11 = $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$UcdF.LCCHCM.CommunityHandymanServiceRequestDiscoContextModel), this.ongoingServiceRequests, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$UcdF.LCCHCM.CommunityHandymanServiceRequestDiscoContextModel), $.$$.S.Boolean))().$ctor(this,  (/*h*/ h) =>
                                {
                                    return location === null || ((h.Value.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$Route?.Start?.IsInCircle($.$cast(location, $.$fPer.LCFCDG.GeoLocation), 3000/*locationRadius*/) ?? null) ?? false) || ((h.Value.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$Route?.End?.IsInCircle($.$cast(location, $.$fPer.LCFCDG.GeoLocation), 3000/*locationRadius*/) ?? null) ?? false);
                                }, $SuAXWg ??= {"r":262145,"p":[{"n":"h","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$UcdF.LCCHCM.CommunityHandymanServiceRequestDiscoContextModel).$h}],"n":"","d":1294411,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                                while ($en11.SC$1$IEnumerator$MoveNext())
                                {
                                    let service = $en11.SCG$IEnumerator$$$Current;
                                    {
                                        if ((service.Value.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$Route?.Start ?? null) !== null)
                                        {
                                            __builder3.OpenComponent$1($.$hDPm.LCFCCM.MapMarker, 62);
                                            __builder3.AddComponentParameter(63, "Location", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDG.GeoLocation, service.Value.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$Route.Start));
                                            __builder3.AddComponentParameter(64, "Label", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, service.Value.ServiceRequest.LCFCP$IPost$Title));
                                            __builder3.AddAttribute$3(65, "Popup", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                            {
                                                __builder4.OpenElement(66, "div");
                                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 67, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                                {
                                                    return this.selectedService = service.Value.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$WorkId;
                                                }, $NwdxCk ??= {"r":65537,"n":"","d":1294411,"h":0,"f":17825794})));
                                                __builder4.AddContent$1(68, $.$SXZI.LCCHCS$1.HandymanViews.ServiceRequestCard(service.Value.ServiceRequest, this.Service, null, true, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    if (service.Value.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$Valuation !== null)
                                                    {
                                                        __builder5.OpenElement(69, "button");
                                                        __builder5.AddAttribute$5(70, "class", "bg-transparent mdi mdi-close");
                                                        __builder5.AddAttribute$7($.$macw.MACW.MouseEventArgs, 71, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                                        {
                                                            return this.Remove(service.Value);
                                                        }, $BGrYMf ??= {"r":178454529,"n":"","d":1294411,"h":0,"f":17825794})));
                                                        __builder5.CloseElement();
                                                        __builder5.AddMarkupContent(72, "\r\n                                    ");
                                                        __builder5.OpenElement(73, "span");
                                                        __builder5.AddAttribute$5(74, "class", "bg-primary pdx-2 pdy-1 mgl mgy-a flex fsz-12 corner");
                                                        __builder5.AddContent$3(75, service.Value.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$Valuation);
                                                        __builder5.CloseElement();
                                                    }
                                                }, $phOHSe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1294411,"h":0,"f":17825794}), false));
                                                __builder4.CloseElement();
                                            }), $jaBDRk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1294411,"h":0,"f":17825794}));
                                            __builder3.CloseComponent();
                                        }
                                        if (service.Value.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$WorkId === this.selectedService)
                                        {
                                            if ((service.Value.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$Route?.Geometries ?? null) !== null)
                                            {
                                                __builder3.OpenComponent$1($.$hDPm.LCFCCM.MapPolyline, 76);
                                                __builder3.AddComponentParameter(77, "Points", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.GeoLocation), service.Value.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$Route.Geometries));
                                                __builder3.AddComponentParameter(78, "Color", "#FFAE00");
                                                __builder3.SetKey($.$box($.$$.S.HashCode.Combine$5($.$$.S.String, $.$fPer.LCFCDG.GeoLocation, $.$$.S.Int32, this.selectedService, service.Value.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$Route.End, 2000), $.$$.S.Int32));
                                                __builder3.CloseComponent();
                                                __builder3.AddMarkupContent(79, "\r\n                                    ");
                                                __builder3.OpenComponent$1($.$hDPm.LCFCCM.MapMarker, 80);
                                                __builder3.AddComponentParameter(81, "Location", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDG.GeoLocation, service.Value.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$Route.End));
                                                __builder3.AddComponentParameter(82, "Label", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN(service.Value.ServiceRequest.LCFCP$IPost$Title) + " Delivery"));
                                                __builder3.SetKey($.$box($.$$.S.HashCode.Combine$5($.$$.S.String, $.$fPer.LCFCDG.GeoLocation, $.$$.S.Int32, this.selectedService, service.Value.ServiceRequest.LCCHCM$ICommunityHandymanServiceRequestModel$Route.End, 6000), $.$$.S.Int32));
                                                __builder3.CloseComponent();
                                            }
                                        }
                                    }
                                }
                            }
                        }), $BesUel ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1294411,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(83, "\r\n            <div class=\"bg-card pos-rel\"></div>");
                    }, $KlRsPg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1294411,"h":0,"f":17825794});
                }), $hPFYZb ??= {"r":6881395,"p":[{"n":"filter","p":$.$hDPm.LCFCI.ContainerContext$$($.$fPer.LCFCD.DataFilter).$h}],"n":"","d":1294411,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(21476130891)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17181163595)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181163595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181163595)
            
            //--TRIMMABLE-BOUNDARY-START(17181163595)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17181163595)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77310705739)
                this.layers = (() =>
                {
                    //new $.$fPer.LCFCA$1.SchemaAttribute$$($.$mpgO.LCCHCAP.Layers)()
                    const $t12 = $.$fPer.LCFCA$1.SchemaAttribute$$($.$mpgO.LCCHCAP.Layers);
                    const $i12 = new $t12();
                    $i12.$ctor$3();
                    $i12.Key = "Layers";
                    return $i12;
                })();
                //--TRIMMABLE-BOUNDARY-END(77310705739)
                
                //--TRIMMABLE-BOUNDARY-START(128850313291)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(128850313291)
                
                //--TRIMMABLE-BOUNDARY-START(85900640331)
                this.MessagePipeFactory = null;
                //--TRIMMABLE-BOUNDARY-END(85900640331)
                
                //--TRIMMABLE-BOUNDARY-START(133145280587)
                this.ServiceFilters = null;
                //--TRIMMABLE-BOUNDARY-END(133145280587)
                
                //--TRIMMABLE-BOUNDARY-START(90195607627)
                this.ongoingServiceRequests = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$UcdF.LCCHCM.CommunityHandymanServiceRequestDiscoContextModel))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(90195607627)
                
                //--TRIMMABLE-BOUNDARY-START(98785542219)
                this.onlineUsers = new ($.$$.SCG.List$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountMetadataModel))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(98785542219)
                
                //--TRIMMABLE-BOUNDARY-START(64425803851)
                this.handymen = new ($.$$.SCG.List$$($.$LCOv.LCFCPM$1.AccountModel))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(64425803851)
                
            }
            static $h = 1294411;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103080509515),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950967371,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1294411,
      "h": 103080509515,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(103080509515),
//--TRIMMABLE-BOUNDARY-START(128850313291),
    {
      "p": 3453188,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540901963,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325149771,
        "f": 83886081
      },
      "n": "Service",
      "d": 1294411,
      "h": 128850313291,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128850313291),
//--TRIMMABLE-BOUNDARY-START(85900640331),
    {
      "p": 407004,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361032779,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735215179,
        "f": 83886081
      },
      "n": "MessagePipeFactory",
      "d": 1294411,
      "h": 85900640331,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900640331),
//--TRIMMABLE-BOUNDARY-START(133145280587),
    {
      "p": $.$$.SCG.IEnumerable$$($.$UcdF.LCCHCS.ICommunityHandymanServiceFilter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130836555,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915084363,
        "f": 83886081
      },
      "n": "ServiceFilters",
      "d": 1294411,
      "h": 133145280587,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133145280587)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720771147),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1294411,
      "h": 68720771147,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720771147),
//--TRIMMABLE-BOUNDARY-START(94490574923),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1294411,
      "h": 94490574923,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(94490574923),
//--TRIMMABLE-BOUNDARY-START(111670444107),
    {
      "r": 178454529,
      "p": [
        {
          "n": "c",
          "p": 3987136
        }
      ],
      "n": "Remove",
      "d": 1294411,
      "h": 111670444107,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(111670444107),
//--TRIMMABLE-BOUNDARY-START(25771098187),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1294411,
      "h": 25771098187,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771098187),
//--TRIMMABLE-BOUNDARY-START(21476130891),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1294411,
      "h": 21476130891,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476130891)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81605673035),
    {
      "t": 655361,
      "n": "locationRadius",
      "d": 1294411,
      "h": 81605673035,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81605673035),
//--TRIMMABLE-BOUNDARY-START(77310705739),
    {
      "t": $.$fPer.LCFCA$1.SchemaAttribute$$($.$mpgO.LCCHCAP.Layers).$h,
      "n": "layers",
      "d": 1294411,
      "h": 77310705739,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77310705739),
//--TRIMMABLE-BOUNDARY-START(90195607627),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$UcdF.LCCHCM.CommunityHandymanServiceRequestDiscoContextModel).$h,
      "n": "ongoingServiceRequests",
      "d": 1294411,
      "h": 90195607627,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(90195607627),
//--TRIMMABLE-BOUNDARY-START(98785542219),
    {
      "t": $.$$.SCG.List$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountMetadataModel).$h,
      "n": "onlineUsers",
      "d": 1294411,
      "h": 98785542219,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98785542219),
//--TRIMMABLE-BOUNDARY-START(64425803851),
    {
      "t": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel).$h,
      "n": "handymen",
      "d": 1294411,
      "h": 64425803851,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425803851),
//--TRIMMABLE-BOUNDARY-START(115965411403),
    {
      "t": 7858612,
      "n": "selectedHandyman",
      "d": 1294411,
      "h": 115965411403,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(115965411403),
//--TRIMMABLE-BOUNDARY-START(124555345995),
    {
      "t": 2152128,
      "n": "selectedUser",
      "d": 1294411,
      "h": 124555345995,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124555345995),
//--TRIMMABLE-BOUNDARY-START(120260378699),
    {
      "t": 1310721,
      "n": "selectedService",
      "d": 1294411,
      "h": 120260378699,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120260378699),
//--TRIMMABLE-BOUNDARY-START(73015738443),
    {
      "t": 1163339,
      "n": "layer",
      "d": 1294411,
      "h": 73015738443,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015738443),
//--TRIMMABLE-BOUNDARY-START(107375476811),
    {
      "t": 341468,
      "n": "pipe",
      "d": 1294411,
      "h": 107375476811,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(107375476811)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181163595),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1294411,
      "h": 17181163595,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181163595)
  ],
  "h": 1294411,
  "a": [
    {
      "t": 917616,
      "c": 17180786800,
      "n": [
        {
          "n": "Roles",
          "v": "SuperAdmin,HandymanAdmin",
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/Handyman/SituationRoom",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Pages.SituationRoom`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Pages${separator}SituationRoom`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1294411)
        
        

        //--TRIMMABLE-BOUNDARY-START(1097803)
        $asm.$cls(`$mpgO.LCCHCAP.CommunityHandymanAdminApp`, ($self) => class CommunityHandymanAdminApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(176094756939)
            /*string?*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(176094756939)
            
            //--TRIMMABLE-BOUNDARY-START(193274626123)
            /*CommunityHandymanService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(193274626123)
            
            //--TRIMMABLE-BOUNDARY-START(163209855051)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(163209855051)
            
            //--TRIMMABLE-BOUNDARY-START(47245738059)
            /*CommunityHandymanAgentMessageComposerProvider*/ AgentMessageComposer = null;
            //--TRIMMABLE-BOUNDARY-END(47245738059)
            
            //--TRIMMABLE-BOUNDARY-START(266289070155)
            /*CommunityHandymanServiceAccountVerificationCommand*/ VerifyCommand = null;
            //--TRIMMABLE-BOUNDARY-END(266289070155)
            
            //--TRIMMABLE-BOUNDARY-START(158914887755)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(158914887755)
            
            //--TRIMMABLE-BOUNDARY-START(154619920459)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154619920459)
            
            //--TRIMMABLE-BOUNDARY-START(55835672651)
            /*CommunityHandymanServiceAccountFeatureCommandProvider?*/ featureCommandProvider = null;
            //--TRIMMABLE-BOUNDARY-END(55835672651)
            
            //--TRIMMABLE-BOUNDARY-START(257699135563)
            /*CommunityHandymanServiceAccountSuspendCommandProvider?*/ suspendCommandProvider = null;
            //--TRIMMABLE-BOUNDARY-END(257699135563)
            
            //--TRIMMABLE-BOUNDARY-START(60130639947)
            /*CommunityHandymanServiceAccountFeaturePropertyProvider?*/ featurePropertyProvider = null;
            //--TRIMMABLE-BOUNDARY-END(60130639947)
            
            //--TRIMMABLE-BOUNDARY-START(64425607243)
            /*CommunityHandymanAttachmentsPropertyProvider?*/ fileUploadPropertyProvider = null;
            //--TRIMMABLE-BOUNDARY-END(64425607243)
            
            //--TRIMMABLE-BOUNDARY-START(137440051275)
            /*T? */ GetProperty(TTable, T, /*IObservableDataDescriptor?*/ target, /*T?*/ prefered)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440051275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let dlf;
                if ($.$is(prefered, $.$hDPm.LCFCCD$1.DataListFeatures, { set $v($v){ dlf = $v; } }))
                {
                    dlf |= 65536n | 131072n;
                    return $.$cast($.$box(dlf, $.$hDPm.LCFCCD$1.DataListFeatures), T);
                }
                if (T.$type === $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$LCOv.LCFCPM$1.AccountModel)).$type)
                {
                    return $.$cast($.$cast($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$LCOv.LCFCPM$1.AccountModel)), [this.VerifyCommand, featureCommandProvider ??= new $.$mpgO.LCCHCAS.CommunityHandymanServiceAccountFeatureCommandProvider().$ctor$1(), suspendCommandProvider ??= new $.$mpgO.LCCHCAS.CommunityHandymanServiceAccountSuspendCommandProvider().$ctor$1()], [-1], null), $.$$.S.Object), T);
                }
                if (T.$type === $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCD.IDashboardTableDataPropertyAddOnViewProvider$$($.$LCOv.LCFCPM$1.AccountModel)).$type)
                {
                    return $.$cast($.$cast($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCCD.IDashboardTableDataPropertyAddOnViewProvider$$($.$LCOv.LCFCPM$1.AccountModel)), [featurePropertyProvider ??= new $.$mpgO.LCCHCAS.CommunityHandymanServiceAccountFeaturePropertyProvider().$ctor$1(), fileUploadPropertyProvider ??= new $.$mpgO.LCCHCAS.CommunityHandymanAttachmentsPropertyProvider().$ctor$1()], [-1], null), $.$$.S.Object), T);
                }
                return prefered;
            }
            //--TRIMMABLE-BOUNDARY-END(137440051275)
            
            //--TRIMMABLE-BOUNDARY-START(141735018571)
            /*ValueTask<object> */ GetPropertyValue(/*IObservableDataDescriptor*/ target, /*IPropertyDescriptor*/ property)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735018571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.S.Object, null);
            }
            //--TRIMMABLE-BOUNDARY-END(141735018571)
            
            //--TRIMMABLE-BOUNDARY-START(180389724235)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(180389724235)
            
            //--TRIMMABLE-BOUNDARY-START(180389724235)
            //--TRIMMABLE-BOUNDARY-START(42950770763)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950770763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(42950770763)
            
            //--TRIMMABLE-BOUNDARY-START(188979658827)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979658827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(188979658827)
            
            //--TRIMMABLE-BOUNDARY-END(180389724235)
            
            //--TRIMMABLE-BOUNDARY-START(167504822347)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504822347);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.UnitOfWork.LCFCI$IClientUnitOfWork$Rendering.LCFCC$IUIRenderingProvider$IsPreRendering)
                    {
                    }
                    ($t1 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167504822347)
            
            //--TRIMMABLE-BOUNDARY-START(150324953163)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324953163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(150324953163)
            
            //--TRIMMABLE-BOUNDARY-START(171799789643)
            /*string */ get OptimizedComponentName()
            {
                return "communityhandymanadminapp";
            }
            //--TRIMMABLE-BOUNDARY-END(171799789643)
            
            //--TRIMMABLE-BOUNDARY-START(261994102859)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994102859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch2 = parameter.Name;
                switch($switch2)
                {
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(261994102859)
            
            //--TRIMMABLE-BOUNDARY-START(146029985867)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029985867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$SXZI.LCCHCS.CommunityHandymanService, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
                this.AgentMessageComposer = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mpgO.LCCHCAS.CommunityHandymanAgentMessageComposerProvider, serviceProvider);
                this.VerifyCommand = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mpgO.LCCHCAS.CommunityHandymanServiceAccountVerificationCommand, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(146029985867)
            
            //--TRIMMABLE-BOUNDARY-START(51540705355)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540705355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    $.$mpgO._LCCHCAPC.TypeInference.CreateCascadingValue_0($.$mpgO.LCCHCAP.CommunityHandymanAdminApp, __builder2, 4, 5, this, 6, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.Application, 7);
                        __builder3.AddComponentParameter(8, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Admin/Handyman")));
                        __builder3.AddComponentParameter(9, "_ViewModel", "Service");
                        __builder3.AddComponentParameter(10, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ | 128/*ApplicationFeatures.ToolBarBorder*/ | 2048/*ApplicationFeatures.LeftSideBarBorder*/), $.$lJUR.LCFCS.ApplicationFeatures));
                        __builder3.AddAttribute$3(11, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(12, "<i class=\"mdi mdi-package cl-error\"></i>");
                            }, $NiPUVc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                        }), $nvmCYe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder4) =>
                        {
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 14);
                            __builder4.AddComponentParameter(15, "Name", "");
                            __builder4.AddComponentParameter(16, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("**"/*RoutePath.ZeroOrMorePathSegment*/)));
                            __builder4.AddComponentParameter(17, "Class", "pd");
                            __builder4.AddAttribute$3(18, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(19, "Dashboard");
                                }, $rJGKBc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $oNoxld ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(20, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(21, "<i class=\"mdi mdi-package\"></i>");
                                }, $zCkHSk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $eiLUnb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(22, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                }, $mMwVGf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $tgFRYd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(23, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 24);
                            __builder4.AddComponentParameter(25, "Name", "ServiceAccounts");
                            __builder4.AddComponentParameter(26, "Class", "pd");
                            __builder4.AddAttribute$3(27, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder5) =>
                                {
                                    __builder5.AddContent$4(28, "Service Accounts");
                                }, $xHAXTb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $tkecSj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(29, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(30, "<i class=\"mdi mdi-road-variant\"></i>");
                                }, $yYzKdd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $FqnIWa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(31, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPM$1.AccountModel), 32);
                                    __builder5.AddComponentParameter(33, "ItemName", "Service Account");
                                    __builder5.AddComponentParameter(34, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, $.$UcdF.LCCHC.HandymanUtility.SearchServiceAccount.OverrideWith(new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1196268653051967n | 8388608n | 4194304n | 2251799813685248n | 18014398509481984n | 140737488355328n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)).WithAttribute$1($.$$.S.String, "FeatureProperties", $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.GetFeatureKey(null), 0))));
                                    __builder5.AddComponentParameter(35, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, 7616/*DashboardTableFeatures.Default*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(36, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder5.AddAttribute$3(37, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*___*/ ___) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$LCOv.LCFCPM$1.AccountModel), 38);
                                            __builder6.AddComponentParameter(39, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 2147483647/*int.MaxValue*/), $.$$.S.Int32));
                                            __builder6.AddAttribute$3(40, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder7*/ __builder7) =>
                                                {
                                                    __builder7.AddContent$4(41, "Status");
                                                }, $OPEnBd ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                                            }), $DqIkfb ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                                            __builder6.AddAttribute$3(42, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder7*/ __builder7) =>
                                                {
                                                    /*var*/ let features = $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.From(item.Data, null, null);
                                                    if ((features?.Verified ?? null) ?? false)
                                                    {
                                                        __builder7.AddMarkupContent(43, "<i class=\"mdi mdi-check fsz-20 cl-success mgx-2\" title=\"Verified\"></i>");
                                                    }
                                                    if ((features?.Suspended ?? null) ?? false)
                                                    {
                                                        __builder7.AddMarkupContent(44, "<i class=\"mdi mdi-cancel fsz-20 cl-error mgx-2\" title=\"Suspended\"></i>");
                                                    }
                                                }, $xSGYQi ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                                            }), $pWlZVg ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                                            __builder6.CloseComponent();
                                        }, $ZvMEoc ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                                    }), $BqOJKb ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                }, $nXOjtb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $aKRrJk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(45, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 46);
                            __builder4.AddComponentParameter(47, "Name", "Situations");
                            __builder4.AddAttribute$3(48, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(49, "Situations");
                                }, $CXWaJb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $lbjXra ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(50, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(51, "<i class=\"mdi mdi-road-variant\"></i>");
                                }, $QalfNi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $cuGLsc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(52, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$mpgO.LCCHCAP.SituationRoom, 53);
                                    __builder5.CloseComponent();
                                }, $prXqIk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $tUSjmk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(54, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 55);
                            __builder4.AddComponentParameter(56, "Name", "Rewards");
                            __builder4.AddAttribute$3(57, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(58, "Rewards");
                                }, $mWCaNi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $FQpMFg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(59, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(60, "<i class=\"mdi mdi-gift\"></i>");
                                }, $ulrTsf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $NPEmBi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(61, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$UcdF.LCCHCM.CommunityHandymanRewardModel), 62);
                                    __builder5.AddComponentParameter(63, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder5.AddComponentParameter(64, "ItemName", "Rewards");
                                    __builder5.CloseComponent();
                                }, $sPUDNf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $jUrhll ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(65, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 66);
                            __builder4.AddComponentParameter(67, "Name", "Newsletters");
                            __builder4.AddComponentParameter(68, "Class", "pd");
                            __builder4.AddAttribute$3(69, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(70, "Newsletters");
                                }, $jhIfkk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $XRrWOg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(71, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(72, "<i class=\"mdi mdi-newspaper\"></i>");
                                }, $hzlIpb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $ipWwjh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(73, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenElement(74, "NewsletterComposer");
                                    __builder5.AddAttribute$5(75, "Provider", "AgentMessageComposer");
                                    __builder5.AddAttribute$5(76, "EmailLayoutRoute", "/Handyman/ComposeEmail"/*CommunityHandymanConstants.ComposeEmailPath*/);
                                    __builder5.CloseElement();
                                }, $tGLBCb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794});
                            }), $wpjJJh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1097803,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                        }), $ilIpEj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                    }, $piaJHk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794}));
                }), $VOZpsi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1097803,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(51540705355)
            
            //--TRIMMABLE-BOUNDARY-START(4308162218)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableProvider.GetProperty<TTable, TValue>(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor?, TValue?)
            LCFCCD$IDashboardTableProvider$GetProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4308162218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4308162218)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(34360836171)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360836171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360836171)
            
            //--TRIMMABLE-BOUNDARY-START(34360836171)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(34360836171)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(193274626123)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(193274626123)
                
                //--TRIMMABLE-BOUNDARY-START(163209855051)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(163209855051)
                
                //--TRIMMABLE-BOUNDARY-START(47245738059)
                this.AgentMessageComposer = null;
                //--TRIMMABLE-BOUNDARY-END(47245738059)
                
                //--TRIMMABLE-BOUNDARY-START(266289070155)
                this.VerifyCommand = null;
                //--TRIMMABLE-BOUNDARY-END(266289070155)
                
                //--TRIMMABLE-BOUNDARY-START(158914887755)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(158914887755)
                
            }
            static $h = 1097803;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(176094756939),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965214795,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236224299083,
        "f": 83886081
      },
      "n": "Page",
      "d": 1097803,
      "h": 176094756939,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176094756939),
//--TRIMMABLE-BOUNDARY-START(193274626123),
    {
      "p": 3453188,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555149387,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244814233675,
        "f": 83886081
      },
      "n": "Service",
      "d": 1097803,
      "h": 193274626123,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193274626123),
//--TRIMMABLE-BOUNDARY-START(163209855051),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785345611,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227634364491,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 1097803,
      "h": 163209855051,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209855051),
//--TRIMMABLE-BOUNDARY-START(47245738059),
    {
      "p": 1491019,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015541835,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201864560715,
        "f": 83886081
      },
      "n": "AgentMessageComposer",
      "d": 1097803,
      "h": 47245738059,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245738059),
//--TRIMMABLE-BOUNDARY-START(266289070155),
    {
      "p": 1818699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145083979,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253404168267,
        "f": 83886081
      },
      "n": "VerifyCommand",
      "d": 1097803,
      "h": 266289070155,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(266289070155),
//--TRIMMABLE-BOUNDARY-START(158914887755),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195411019,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044429899,
        "f": 83886081
      },
      "n": "Loading",
      "d": 1097803,
      "h": 158914887755,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914887755),
//--TRIMMABLE-BOUNDARY-START(154619920459),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605476427,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454495307,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 1097803,
      "h": 154619920459,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619920459),
//--TRIMMABLE-BOUNDARY-START(171799789643),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375280203,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1097803,
      "h": 171799789643,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(171799789643)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137440051275),
    {
      "r": (TTable, T) => T.$h,
      "p": [
        {
          "n": "target",
          "p": 40536406
        },
        {
          "n": "prefered",
          "p": (TTable, T) => T.$h
        }
      ],
      "g": [
        "TTable",
        "T"
      ],
      "n": "GetProperty",
      "d": 1097803,
      "h": 137440051275,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(137440051275),
//--TRIMMABLE-BOUNDARY-START(141735018571),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "target",
          "p": 40536406
        },
        {
          "n": "property",
          "p": 40733014
        }
      ],
      "n": "GetPropertyValue",
      "d": 1097803,
      "h": 141735018571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735018571),
//--TRIMMABLE-BOUNDARY-START(167504822347),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1097803,
      "h": 167504822347,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(167504822347),
//--TRIMMABLE-BOUNDARY-START(150324953163),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1097803,
      "h": 150324953163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324953163),
//--TRIMMABLE-BOUNDARY-START(261994102859),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1097803,
      "h": 261994102859,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(261994102859),
//--TRIMMABLE-BOUNDARY-START(146029985867),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1097803,
      "h": 146029985867,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029985867),
//--TRIMMABLE-BOUNDARY-START(51540705355),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1097803,
      "h": 51540705355,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540705355)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55835672651),
    {
      "t": 1622091,
      "n": "featureCommandProvider",
      "d": 1097803,
      "h": 55835672651,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835672651),
//--TRIMMABLE-BOUNDARY-START(257699135563),
    {
      "t": 1753163,
      "n": "suspendCommandProvider",
      "d": 1097803,
      "h": 257699135563,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(257699135563),
//--TRIMMABLE-BOUNDARY-START(60130639947),
    {
      "t": 1687627,
      "n": "featurePropertyProvider",
      "d": 1097803,
      "h": 60130639947,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130639947),
//--TRIMMABLE-BOUNDARY-START(64425607243),
    {
      "t": 1556555,
      "n": "fileUploadPropertyProvider",
      "d": 1097803,
      "h": 64425607243,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425607243)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360836171),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1097803,
      "h": 34360836171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360836171)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(180389724235),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 1097803,
        "h": 42950770763,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 1097803,
        "h": 188979658827,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 1097803,
      "h": 180389724235,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(180389724235)
  ],
  "h": 1097803,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/Handyman",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/Handyman/{*Page}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCCD.IDashboardTableProvider, $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Pages.CommunityHandymanAdminApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Pages${separator}CommunityHandymanAdminApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1097803)
        
        

        //--TRIMMABLE-BOUNDARY-START(507979)
        $asm.$cls(`$mpgO.LCCHCAE.HandymanAccountVerified`, ($self) => class HandymanAccountVerified extends $.$hDPm.LCFCCE$1.EmailTemplateBase
        {
            //--TRIMMABLE-BOUNDARY-START(34360246347)
            /*string */ get OptimizedComponentName()
            {
                return "handymanaccountverified";
            }
            //--TRIMMABLE-BOUNDARY-END(34360246347)
            
            //--TRIMMABLE-BOUNDARY-START(8590442571)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590442571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pdx pdy-10");
                __builder.OpenElement(2, "h1");
                __builder.AddAttribute$5(3, "class", "fsz-40");
                __builder.AddContent$4(4, "Bravo ");
                __builder.AddContent$4(5, this.Name);
                __builder.AddContent$4(6, ".");
                __builder.CloseElement();
                __builder.AddMarkupContent(7, "\r\n    ");
                __builder.AddMarkupContent(8, "<p>Your account is now verified with Handyman and you can start earning by delivering packages and services.</p>\r\n    ");
                __builder.AddMarkupContent(9, "<p>Simply open your app when you are ready to work, login and tap GoOnline. Let Handyman get you a package for pickup.</p>\r\n    ");
                __builder.AddMarkupContent(10, "<a class=\"d-i-block bg-primary pdx-10 pdy-3 fsz-30 corner\" href=\"https://handyman.zoey.africa/Handyman\">Start Delivery</a>");
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590442571)
            
            //--TRIMMABLE-BOUNDARY-START(30065279051)
            /*string? */ get Name()
            {
                return this.GetQuery("name", false);
            }
            //--TRIMMABLE-BOUNDARY-END(30065279051)
            
            //--TRIMMABLE-BOUNDARY-START(4295475275)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295475275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295475275)
            
            //--TRIMMABLE-BOUNDARY-START(4295475275)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295475275)
            
            static $h = 507979;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCE$1.EmailTemplateBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360246347),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770311755,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 507979,
      "h": 34360246347,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360246347),
//--TRIMMABLE-BOUNDARY-START(30065279051),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180377163,
        "f": 50331650
      },
      "n": "Name",
      "d": 507979,
      "h": 30065279051,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30065279051)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590442571),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 507979,
      "h": 8590442571,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590442571)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295475275),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 507979,
      "h": 4295475275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295475275)
  ],
  "h": 507979,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 770123,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Handyman/AccountVerified",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Emails.HandymanAccountVerified`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Emails${separator}HandymanAccountVerified`; }
        });
        //--TRIMMABLE-BOUNDARY-END(507979)
        
        

        //--TRIMMABLE-BOUNDARY-START(442443)
        $asm.$cls(`$mpgO.LCCHCAE.HandymanAccountSuspension`, ($self) => class HandymanAccountSuspension extends $.$hDPm.LCFCCE$1.EmailTemplateBase
        {
            //--TRIMMABLE-BOUNDARY-START(51540049995)
            /*string */ get OptimizedComponentName()
            {
                return "handymanaccountsuspension";
            }
            //--TRIMMABLE-BOUNDARY-END(51540049995)
            
            //--TRIMMABLE-BOUNDARY-START(8590377035)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590377035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pdx pdy-10");
                __builder.OpenElement(2, "h1");
                __builder.AddAttribute$5(3, "class", "fsz-40");
                __builder.AddContent$4(4, "Hi ");
                __builder.AddContent$4(5, this.Name);
                __builder.AddContent$4(6, ".");
                __builder.CloseElement();
                if (this.Suspended)
                {
                    __builder.OpenElement(7, "p");
                    __builder.AddMarkupContent(8, "\r\n            We are sorry to notify you that your handyman account is now suspended.\r\n");
                    if (this.Reason !== null)
                    {
                        __builder.AddContent$4(9, "Please find the reason below.");
                    }
                    __builder.CloseElement();
                    if (this.Reason !== null)
                    {
                        __builder.OpenElement(10, "p");
                        __builder.AddContent$4(11, "Reason: ");
                        __builder.AddContent$4(12, this.Reason);
                        __builder.CloseElement();
                    }
                    __builder.AddMarkupContent(13, "<p>To appeal and have this decision reversed, please contact Handyman Support. You can find our contact details in the Handyman app.</p>\r\n        ");
                    __builder.AddMarkupContent(14, "<a class=\"d-i-block bg-primary pdx-10 pdy-3 fsz-30 corner\" href=\"https://handyman.zoey.africa/Handyman/Support\">Contact Support</a>");
                }
                else 
                {
                    __builder.AddMarkupContent(15, "<p>We are glad to notify you that the restrictions on your Handyman account are now lifted and your account restored.</p>\r\n        ");
                    __builder.AddMarkupContent(16, "<p>You can now start working with Handyman.</p>\r\n        ");
                    __builder.AddMarkupContent(17, "<a class=\"d-i-block bg-primary pdx-10 pdy-3 fsz-30 corner\" href=\"https://handyman.zoey.africa/Handyman/Earn\">Start Now</a>");
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590377035)
            
            //--TRIMMABLE-BOUNDARY-START(47245082699)
            /*string? */ get Name()
            {
                return this.GetQuery("name", false);
            }
            //--TRIMMABLE-BOUNDARY-END(47245082699)
            
            //--TRIMMABLE-BOUNDARY-START(60129984587)
            /*bool */ get Suspended()
            {
                return this.GetQuery$1($.$$.S.Boolean, "suspended", false);
            }
            //--TRIMMABLE-BOUNDARY-END(60129984587)
            
            //--TRIMMABLE-BOUNDARY-START(55835017291)
            /*string? */ get Reason()
            {
                return this.GetQuery("reason", false);
            }
            //--TRIMMABLE-BOUNDARY-END(55835017291)
            
            //--TRIMMABLE-BOUNDARY-START(4295409739)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295409739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295409739)
            
            //--TRIMMABLE-BOUNDARY-START(4295409739)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295409739)
            
            static $h = 442443;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCE$1.EmailTemplateBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540049995),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770246219,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 442443,
      "h": 51540049995,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51540049995),
//--TRIMMABLE-BOUNDARY-START(47245082699),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180311627,
        "f": 50331650
      },
      "n": "Name",
      "d": 442443,
      "h": 47245082699,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47245082699),
//--TRIMMABLE-BOUNDARY-START(60129984587),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950115403,
        "f": 50331650
      },
      "n": "Suspended",
      "d": 442443,
      "h": 60129984587,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60129984587),
//--TRIMMABLE-BOUNDARY-START(55835017291),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360180811,
        "f": 50331650
      },
      "n": "Reason",
      "d": 442443,
      "h": 55835017291,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55835017291)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590377035),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 442443,
      "h": 8590377035,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590377035)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295409739),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 442443,
      "h": 4295409739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295409739)
  ],
  "h": 442443,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 770123,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Handyman/AccountSuspension",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Emails.HandymanAccountSuspension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Emails${separator}HandymanAccountSuspension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(442443)
        
        

        //--TRIMMABLE-BOUNDARY-START(639051)
        $asm.$cls(`$mpgO.LCCHCAE.HandymanComposeEmail`, ($self) => class HandymanComposeEmail extends $.$hDPm.LCFCCE$1.EmailTemplateBase
        {
            //--TRIMMABLE-BOUNDARY-START(34360377419)
            /*string */ get OptimizedComponentName()
            {
                return "handymancomposeemail";
            }
            //--TRIMMABLE-BOUNDARY-END(34360377419)
            
            //--TRIMMABLE-BOUNDARY-START(12885540939)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885540939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent(0, $.$mac.MAC.MarkupString.op_Explicit(this.Body));
            }
            //--TRIMMABLE-BOUNDARY-END(12885540939)
            
            //--TRIMMABLE-BOUNDARY-START(8590573643)
            /*string? */ get Body()
            {
                return this.GetQuery("Body", false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590573643)
            
            //--TRIMMABLE-BOUNDARY-START(4295606347)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295606347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295606347)
            
            //--TRIMMABLE-BOUNDARY-START(4295606347)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295606347)
            
            static $h = 639051;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCE$1.EmailTemplateBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360377419),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065410123,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 639051,
      "h": 34360377419,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360377419),
//--TRIMMABLE-BOUNDARY-START(8590573643),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475475531,
        "f": 50331650
      },
      "n": "Body",
      "d": 639051,
      "h": 8590573643,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8590573643)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885540939),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 639051,
      "h": 12885540939,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885540939)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295606347),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 639051,
      "h": 4295606347,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295606347)
  ],
  "h": 639051,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 770123,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Handyman/ComposeEmail",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Emails.HandymanComposeEmail`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Emails${separator}HandymanComposeEmail`; }
        });
        //--TRIMMABLE-BOUNDARY-END(639051)
        
        

        //--TRIMMABLE-BOUNDARY-START(573515)
        $asm.$cls(`$mpgO.LCCHCAE.HandymanCompleteYourRegistration`, ($self) => class HandymanCompleteYourRegistration extends $.$hDPm.LCFCCE$1.EmailTemplateBase
        {
            //--TRIMMABLE-BOUNDARY-START(21475409995)
            /*string */ get OptimizedComponentName()
            {
                return "handymancompleteyourregistration";
            }
            //--TRIMMABLE-BOUNDARY-END(21475409995)
            
            //--TRIMMABLE-BOUNDARY-START(8590508107)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590508107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<div class=\"pdx pdy-10\"><h1 class=\"fsz-40\">Start delivering on your way and make money flexibly.</h1>\r\n    <h2>Activate your account to start making money on trips with Handyman</h2>\r\n    <a class=\"d-i-block bg-primary pdx-10 pdy-3 fsz-30 corner\" href=\"https://handyman.zoey.africa/Handyman/Earn\">Activate</a>\r\n    <h1 class=\"mgt-15\">Complete your registration</h1>\r\n    <p>\r\n        All you have left is to complete your account verification,\r\n        choose your service region and let Handyman help you make money when you go on a trip.\r\n    </p>\r\n    <a class=\"d-i-block bg-primary pdx-10 pdy-3 fsz-30 corner\" href=\"https://handyman.zoey.africa/Handyman/Earn\">Start Now</a></div>");
            }
            //--TRIMMABLE-BOUNDARY-END(8590508107)
            
            //--TRIMMABLE-BOUNDARY-START(4295540811)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295540811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295540811)
            
            //--TRIMMABLE-BOUNDARY-START(4295540811)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295540811)
            
            static $h = 573515;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCE$1.EmailTemplateBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475409995),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180442699,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 573515,
      "h": 21475409995,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475409995)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590508107),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 573515,
      "h": 8590508107,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590508107)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295540811),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 573515,
      "h": 4295540811,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295540811)
  ],
  "h": 573515,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 770123,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Handyman/CompleteRegistration",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Emails.HandymanCompleteYourRegistration`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Emails${separator}HandymanCompleteYourRegistration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(573515)
        
        

        //--TRIMMABLE-BOUNDARY-START(704587)
        $asm.$cls(`$mpgO.LCCHCAE.HandymanCoupon`, ($self) => class HandymanCoupon extends $.$hDPm.LCFCCE$1.EmailTemplateBase
        {
            //--TRIMMABLE-BOUNDARY-START(64425214027)
            /*string */ get OptimizedComponentName()
            {
                return "handymancoupon";
            }
            //--TRIMMABLE-BOUNDARY-END(64425214027)
            
            //--TRIMMABLE-BOUNDARY-START(8590639179)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590639179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pdx pdy-10");
                __builder.OpenElement(2, "h1");
                __builder.AddAttribute$5(3, "class", "fsz-40");
                __builder.AddContent$4(4, "Hi ");
                __builder.AddContent$4(5, this.Name);
                __builder.AddContent$4(6, ".");
                __builder.CloseElement();
                __builder.AddMarkupContent(7, "\r\n    ");
                __builder.OpenElement(8, "p");
                __builder.AddContent$4(9, "Your referee ");
                __builder.AddContent$4(10, this.Referee);
                __builder.AddContent$4(11, " has sent their first package on Handyman.");
                __builder.CloseElement();
                __builder.AddMarkupContent(12, "\r\n    ");
                __builder.AddMarkupContent(13, "<p>\r\n        As promised, Handyman has issued you two coupon code carrying discount of 50%.\r\n        Save them somewhere and use on your next service request on handyman\r\n    </p>");
                for(/*int*/ let i = 0; i < this.Count; i++)
                {
                    __builder.OpenElement(14, "div");
                    __builder.AddAttribute$5(15, "class", "flex");
                    __builder.OpenElement(16, "h1");
                    __builder.AddAttribute$5(17, "class", "fsz-40");
                    __builder.AddContent$4(18, this.Coupon(i));
                    __builder.CloseElement();
                    __builder.AddMarkupContent(19, "\r\n            expires ");
                    __builder.AddContent$3(20, this.CouponExpiry(i));
                    __builder.CloseElement();
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590639179)
            
            //--TRIMMABLE-BOUNDARY-START(60130246731)
            /*string? */ get Name()
            {
                return this.GetQuery("name", false);
            }
            //--TRIMMABLE-BOUNDARY-END(60130246731)
            
            //--TRIMMABLE-BOUNDARY-START(68720181323)
            /*string? */ get Referee()
            {
                return this.GetQuery("referee", false);
            }
            //--TRIMMABLE-BOUNDARY-END(68720181323)
            
            //--TRIMMABLE-BOUNDARY-START(12885606475)
            /*int */ get Count()
            {
                return this.GetQuery$1($.$$.S.Int32, "count", true);
            }
            //--TRIMMABLE-BOUNDARY-END(12885606475)
            
            //--TRIMMABLE-BOUNDARY-START(17180573771)
            /*string? */ Coupon(/*int*/ i)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180573771);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetQuery(`coupon${$.$strNN(((i + 1) | 0))}`, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180573771)
            
            //--TRIMMABLE-BOUNDARY-START(21475541067)
            /*DateTime? */ CouponExpiry(/*int*/ i)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475541067);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetQuery$1($.$$.S.DateTime, `coupon${$.$strNN(((i + 1) | 0))}exp`, true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475541067)
            
            //--TRIMMABLE-BOUNDARY-START(4295671883)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295671883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295671883)
            
            //--TRIMMABLE-BOUNDARY-START(4295671883)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295671883)
            
            static $h = 704587;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCE$1.EmailTemplateBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425214027),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245344843,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 704587,
      "h": 64425214027,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64425214027),
//--TRIMMABLE-BOUNDARY-START(60130246731),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655410251,
        "f": 50331650
      },
      "n": "Name",
      "d": 704587,
      "h": 60130246731,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60130246731),
//--TRIMMABLE-BOUNDARY-START(68720181323),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835279435,
        "f": 50331650
      },
      "n": "Referee",
      "d": 704587,
      "h": 68720181323,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(68720181323),
//--TRIMMABLE-BOUNDARY-START(12885606475),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065475659,
        "f": 50331650
      },
      "n": "Count",
      "d": 704587,
      "h": 12885606475,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(12885606475)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590639179),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 704587,
      "h": 8590639179,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590639179),
//--TRIMMABLE-BOUNDARY-START(17180573771),
    {
      "r": 1310721,
      "p": [
        {
          "n": "i",
          "p": 655361
        }
      ],
      "n": "Coupon",
      "d": 704587,
      "h": 17180573771,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180573771),
//--TRIMMABLE-BOUNDARY-START(21475541067),
    {
      "r": $.$typeNullable($.$$.S.DateTime).$h,
      "p": [
        {
          "n": "i",
          "p": 655361
        }
      ],
      "n": "CouponExpiry",
      "d": 704587,
      "h": 21475541067,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475541067)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295671883),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 704587,
      "h": 4295671883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295671883)
  ],
  "h": 704587,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 770123,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Handyman/AccountRewardCoupon",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Emails.HandymanCoupon`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Emails${separator}HandymanCoupon`; }
        });
        //--TRIMMABLE-BOUNDARY-END(704587)
        
        

        //--TRIMMABLE-BOUNDARY-START(1622091)
        $asm.$cls(`$mpgO.LCCHCAS.CommunityHandymanServiceAccountFeatureCommandProvider`, ($self) => class CommunityHandymanServiceAccountFeatureCommandProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55836196939)
            /*string? */ get Title()
            {
                return "Service Account";
            }
            //--TRIMMABLE-BOUNDARY-END(55836196939)
            
            //--TRIMMABLE-BOUNDARY-START(17181491275)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(17181491275)
            
            //--TRIMMABLE-BOUNDARY-START(51541229643)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account-cog"/*MaterialDesignIconNames.AccountCog*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51541229643)
            
            //--TRIMMABLE-BOUNDARY-START(12886523979)
            /*bool */ CanCommand(/*OneOf<DashboardTable<AccountModel>, DashboardDetails<AccountModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<AccountModel>>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886523979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Count$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel), data) === 1;
            }
            //--TRIMMABLE-BOUNDARY-END(12886523979)
            
            //--TRIMMABLE-BOUNDARY-START(21476458571)
            /*ValueTask *//*async*/  Execute(/*OneOf<DashboardTable<AccountModel>, DashboardDetails<AccountModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<AccountModel>>*/ data)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476458571);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let account = $.$sl.SL.Enumerable.Single$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel), data).LCFCR$IReactiveObservable$$$Value;
                    /*var*/ let uow = source.Match($.$hDPm.LCFCI.IClientUnitOfWork, new ($.$$.S.Func$$$($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCI.IClientUnitOfWork))().$ctor(this,  (/**/ t) =>
                    {
                        return t.UnitOfWork;
                    }, $tUKBLf ??= {"r":63657642,"p":[{"n":"t","p":$.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPM$1.AccountModel).$h}],"n":"","d":1622091,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$hDPm.LCFCCD.DashboardDetails$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCI.IClientUnitOfWork))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.UnitOfWork;
                    }, $zPEVvf ??= {"r":63657642,"p":[{"n":"d","p":$.$hDPm.LCFCCD.DashboardDetails$$($.$LCOv.LCFCPM$1.AccountModel).$h}],"n":"","d":1622091,"h":0,"f":17825794}));
                    ($t1 = $.$vWqU.LCFCR.DataModelExtension.EnsureHasProperties($.$LCOv.LCFCPM$1.AccountModel, account, uow.LCFCI$IClientUnitOfWork$Server, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.GetFeatureKey(null) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    /*var*/ let feature = $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.From(account, null, null);
                    /*var*/ let provider = source.Match($.$hDPm.LCFCCD.IDashboardTableProvider, new ($.$$.S.Func$$$($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCCD.IDashboardTableProvider))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t.Provider;
                    }, $eHmTej ??= {"r":13194922,"p":[{"n":"t","p":$.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPM$1.AccountModel).$h}],"n":"","d":1622091,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$hDPm.LCFCCD.DashboardDetails$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCCD.IDashboardTableProvider))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.Provider;
                    }, $shCDki ??= {"r":13194922,"p":[{"n":"d","p":$.$hDPm.LCFCCD.DashboardDetails$$($.$LCOv.LCFCPM$1.AccountModel).$h}],"n":"","d":1622091,"h":0,"f":17825794}));
                    ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$hDPm.LCFCCD.DashboardDetails$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel), uow.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/**/ b, /**/ s) =>
                    {
                        b.AddAttribute$4(s++, "ViewModel", new ($.$fPer.LCFCD$1.LiteralValueDataDescriptor$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel))().$ctor$7(feature, null, null, null, false));
                        b.AddAttribute$4(s++, "Provider", provider);
                    }, $ctsqQi ??= {"r":65537,"p":[{"n":"b","p":7536755},{"n":"s","p":655361}],"n":"","d":1622091,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21476458571)
            
            //--TRIMMABLE-BOUNDARY-START(4307965610)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.CanCommand(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$CanCommand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4307965610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanCommand(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4307965610)
            
            //--TRIMMABLE-BOUNDARY-START(8602932906)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.Execute(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8602932906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8602932906)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8591556683)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591556683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591556683)
            
            //--TRIMMABLE-BOUNDARY-START(8591556683)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591556683)
            
            static $h = 1622091;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836196939),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246262347,
        "f": 50331649
      },
      "n": "Title",
      "d": 1622091,
      "h": 55836196939,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836196939),
//--TRIMMABLE-BOUNDARY-START(17181491275),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066393163,
        "f": 50331649
      },
      "n": "Description",
      "d": 1622091,
      "h": 17181491275,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181491275),
//--TRIMMABLE-BOUNDARY-START(51541229643),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656327755,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1622091,
      "h": 51541229643,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541229643)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886523979),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        }
      ],
      "n": "CanCommand",
      "d": 1622091,
      "h": 12886523979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886523979),
//--TRIMMABLE-BOUNDARY-START(21476458571),
    {
      "r": 181338113,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        }
      ],
      "n": "Execute",
      "d": 1622091,
      "h": 21476458571,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21476458571)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591556683),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1622091,
      "h": 8591556683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591556683)
  ],
  "h": 1622091
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$LCOv.LCFCPM$1.AccountModel), $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Services.CommunityHandymanServiceAccountFeatureCommandProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Services${separator}CommunityHandymanServiceAccountFeatureCommandProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1622091)
        
        

        //--TRIMMABLE-BOUNDARY-START(1753163)
        $asm.$cls(`$mpgO.LCCHCAS.CommunityHandymanServiceAccountSuspendCommandProvider`, ($self) => class CommunityHandymanServiceAccountSuspendCommandProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55836328011)
            /*string? */ get Title()
            {
                return "Suspend";
            }
            //--TRIMMABLE-BOUNDARY-END(55836328011)
            
            //--TRIMMABLE-BOUNDARY-START(17181622347)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(17181622347)
            
            //--TRIMMABLE-BOUNDARY-START(51541360715)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-cancel"/*MaterialDesignIconNames.Cancel*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51541360715)
            
            //--TRIMMABLE-BOUNDARY-START(12886655051)
            /*bool */ CanCommand(/*OneOf<DashboardTable<AccountModel>, DashboardDetails<AccountModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<AccountModel>>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886655051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(12886655051)
            
            //--TRIMMABLE-BOUNDARY-START(21476589643)
            /*ValueTask *//*async*/  Execute(/*OneOf<DashboardTable<AccountModel>, DashboardDetails<AccountModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<AccountModel>>*/ data)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476589643);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let uow = source.Match($.$hDPm.LCFCI.IClientUnitOfWork, new ($.$$.S.Func$$$($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCI.IClientUnitOfWork))().$ctor(this,  (/**/ t) =>
                    {
                        return t.UnitOfWork;
                    }, $vuDWTk ??= {"r":63657642,"p":[{"n":"t","p":$.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPM$1.AccountModel).$h}],"n":"","d":1753163,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$hDPm.LCFCCD.DashboardDetails$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCI.IClientUnitOfWork))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.UnitOfWork;
                    }, $RhQqDe ??= {"r":63657642,"p":[{"n":"d","p":$.$hDPm.LCFCCD.DashboardDetails$$($.$LCOv.LCFCPM$1.AccountModel).$h}],"n":"","d":1753163,"h":0,"f":17825794}));
                    let $en1 = data.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let a = $en1.SCG$IEnumerator$$$Current;
                        {
                            let $t2, $r2;
                            ($t2 = $.$vWqU.LCFCR.DataModelExtension.EnsureHasProperties($.$LCOv.LCFCPM$1.AccountModel, a.LCFCR$IReactiveObservable$$$Value, uow.LCFCI$IClientUnitOfWork$Server, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.GetFeatureKey(null) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            /*var*/ let feature = $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.From(a.LCFCR$IReactiveObservable$$$Value, null, null);
                            if (feature !== null)
                            {
                                feature.Suspended = !feature.Suspended;
                            }
                        }
                    }
                    ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$LCOv.LCFCPM$1.AccountModel, uow.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$sl.SL.Enumerable.ToArray($.$LCOv.LCFCPM$1.AccountModel, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel), $.$LCOv.LCFCPM$1.AccountModel, data, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel), $.$LCOv.LCFCPM$1.AccountModel))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.LCFCR$IReactiveObservable$$$Value;
                    }, $duxKwd ??= {"r":7858612,"p":[{"n":"d","p":$.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel).$h}],"n":"","d":1753163,"h":0,"f":17825794})))), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    let $en4 = data.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let a = $en4.SCG$IEnumerator$$$Current;
                        {
                            /*var*/ let feature = $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.From(a.LCFCR$IReactiveObservable$$$Value, null, null);
                            if (feature !== null && (a.LCFCR$IReactiveObservable$$$Value.User?.Email ?? null) !== null)
                            {
                                let $t5, $r5;
                                ($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$vWqU.LCFCCR.IEmailNotificationRemoteService, uow.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$vWqU.LCFCCR.IEmailNotificationRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*server*/ server) =>
                                {
                                    return server.LCFCCR$IEmailNotificationRemoteService$SendHTMLEmail("Handyman", feature.Suspended ? "Account Suspended" : "Account Suspension Lifted", "/Handyman/AccountSuspension"/*CommunityHandymanConstants.AccountSuspensionEmailPath*/, (() =>
                                    {
                                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)()
                                        const $t6 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String);
                                        const $i6 = new $t6();
                                        $i6.$ctor$1();
                                        $i6.set_Item("suspended", $.$$.S.Boolean.ToString.call(feature.Suspended));
                                        $i6.set_Item("name", feature.FullName$1);
                                        $i6.set_Item("reason", "");
                                        return $i6;
                                    })(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ a.LCFCR$IReactiveObservable$$$Value.User.Email ], null, null));
                                }, $iyufgh ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"server","p":7560616}],"n":"","d":1753163,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21476589643)
            
            //--TRIMMABLE-BOUNDARY-START(4307965610)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.CanCommand(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$CanCommand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4307965610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanCommand(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4307965610)
            
            //--TRIMMABLE-BOUNDARY-START(8602932906)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.Execute(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8602932906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8602932906)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8591687755)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591687755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591687755)
            
            //--TRIMMABLE-BOUNDARY-START(8591687755)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591687755)
            
            static $h = 1753163;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836328011),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246393419,
        "f": 50331649
      },
      "n": "Title",
      "d": 1753163,
      "h": 55836328011,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836328011),
//--TRIMMABLE-BOUNDARY-START(17181622347),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066524235,
        "f": 50331649
      },
      "n": "Description",
      "d": 1753163,
      "h": 17181622347,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181622347),
//--TRIMMABLE-BOUNDARY-START(51541360715),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656458827,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1753163,
      "h": 51541360715,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541360715)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886655051),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        }
      ],
      "n": "CanCommand",
      "d": 1753163,
      "h": 12886655051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886655051),
//--TRIMMABLE-BOUNDARY-START(21476589643),
    {
      "r": 181338113,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        }
      ],
      "n": "Execute",
      "d": 1753163,
      "h": 21476589643,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21476589643)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591687755),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1753163,
      "h": 8591687755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591687755)
  ],
  "h": 1753163
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$LCOv.LCFCPM$1.AccountModel), $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Services.CommunityHandymanServiceAccountSuspendCommandProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Services${separator}CommunityHandymanServiceAccountSuspendCommandProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1753163)
        
        

        //--TRIMMABLE-BOUNDARY-START(1491019)
        $asm.$cls(`$mpgO.LCCHCAS.CommunityHandymanAgentMessageComposerProvider`, ($self) => class CommunityHandymanAgentMessageComposerProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64426000459)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(64426000459)
            
            //--TRIMMABLE-BOUNDARY-START(8591425611)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591425611);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591425611)
            
            //--TRIMMABLE-BOUNDARY-START(68720967755)
            /*string? */ get Title()
            {
                return "Handyman Agent";
            }
            //--TRIMMABLE-BOUNDARY-END(68720967755)
            
            //--TRIMMABLE-BOUNDARY-START(12886392907)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(12886392907)
            
            //--TRIMMABLE-BOUNDARY-START(47246131275)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account-hard-hat"/*MaterialDesignIconNames.AccountHardHat*/);
            }
            //--TRIMMABLE-BOUNDARY-END(47246131275)
            
            //--TRIMMABLE-BOUNDARY-START(51541098571)
            /*string */ get LCFCM$IMessageComposerProvider$EmailLayoutRoute()
            {
                return "/Handyman/ComposeEmail"/*CommunityHandymanConstants.ComposeEmailPath*/;
            }
            //--TRIMMABLE-BOUNDARY-END(51541098571)
            
            //--TRIMMABLE-BOUNDARY-START(42951163979)
            /*Pager<AccountModel> */ GetContacts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951163979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$LCOv.LCFCPM$1.AccountModel, this.server, $.$UcdF.LCCHC.HandymanUtility.SearchServiceAccount.OverrideWith(new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1196268653051967n | 4194304n | 140737488355328n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null))), null);
            }
            //--TRIMMABLE-BOUNDARY-END(42951163979)
            
            //--TRIMMABLE-BOUNDARY-START(4295243228)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessageComposerProvider<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.GetContacts()
            LCFCM$IMessageComposerProvider$$$GetContacts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295243228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetContacts(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295243228)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 1491019;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720967755),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656196683,
        "f": 50331649
      },
      "n": "Title",
      "d": 1491019,
      "h": 68720967755,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720967755),
//--TRIMMABLE-BOUNDARY-START(12886392907),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476327499,
        "f": 50331649
      },
      "n": "Description",
      "d": 1491019,
      "h": 12886392907,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886392907),
//--TRIMMABLE-BOUNDARY-START(47246131275),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066262091,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1491019,
      "h": 47246131275,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246131275),
//--TRIMMABLE-BOUNDARY-START(51541098571),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131033163,
        "f": 50331650
      },
      "n": "{210396}.EmailLayoutRoute",
      "o": "LCFCM$IMessageComposerProvider$EmailLayoutRoute",
      "d": 1491019,
      "h": 51541098571,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51541098571)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951163979),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$LCOv.LCFCPM$1.AccountModel).$h,
      "n": "GetContacts",
      "d": 1491019,
      "h": 42951163979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951163979)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64426000459),
    {
      "t": 1309651,
      "n": "server",
      "d": 1491019,
      "h": 64426000459,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64426000459)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591425611),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1491019,
      "h": 8591425611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591425611)
  ],
  "h": 1491019
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$UrvY.LCFCM.IMessageComposerProvider$$($.$LCOv.LCFCPM$1.AccountModel), $.$UrvY.LCFCM.IMessageComposerProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Services.CommunityHandymanAgentMessageComposerProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Services${separator}CommunityHandymanAgentMessageComposerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1491019)
        
        

        //--TRIMMABLE-BOUNDARY-START(1884235)
        $asm.$cls(`$mpgO.LCCHCAS.CommunityHandymanUserMessageComposerProvider`, ($self) => class CommunityHandymanUserMessageComposerProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64426393675)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(64426393675)
            
            //--TRIMMABLE-BOUNDARY-START(8591818827)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591818827);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591818827)
            
            //--TRIMMABLE-BOUNDARY-START(68721360971)
            /*string? */ get Title()
            {
                return "Handyman User";
            }
            //--TRIMMABLE-BOUNDARY-END(68721360971)
            
            //--TRIMMABLE-BOUNDARY-START(12886786123)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(12886786123)
            
            //--TRIMMABLE-BOUNDARY-START(47246524491)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account"/*MaterialDesignIconNames.Account*/);
            }
            //--TRIMMABLE-BOUNDARY-END(47246524491)
            
            //--TRIMMABLE-BOUNDARY-START(51541491787)
            /*string */ get LCFCM$IMessageComposerProvider$EmailLayoutRoute()
            {
                return "/Handyman/ComposeEmail"/*CommunityHandymanConstants.ComposeEmailPath*/;
            }
            //--TRIMMABLE-BOUNDARY-END(51541491787)
            
            //--TRIMMABLE-BOUNDARY-START(42951557195)
            /*Pager<AccountModel> */ GetContacts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951557195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$LCOv.LCFCPM$1.AccountModel, this.server, $.$UcdF.LCCHC.HandymanUtility.SearchUserAccount.OverrideWith(new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1196268653051967n | 4194304n | 140737488355328n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null))), null);
            }
            //--TRIMMABLE-BOUNDARY-END(42951557195)
            
            //--TRIMMABLE-BOUNDARY-START(4295243228)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessageComposerProvider<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.GetContacts()
            LCFCM$IMessageComposerProvider$$$GetContacts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295243228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetContacts(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295243228)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 1884235;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68721360971),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656589899,
        "f": 50331649
      },
      "n": "Title",
      "d": 1884235,
      "h": 68721360971,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721360971),
//--TRIMMABLE-BOUNDARY-START(12886786123),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476720715,
        "f": 50331649
      },
      "n": "Description",
      "d": 1884235,
      "h": 12886786123,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886786123),
//--TRIMMABLE-BOUNDARY-START(47246524491),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066655307,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1884235,
      "h": 47246524491,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246524491),
//--TRIMMABLE-BOUNDARY-START(51541491787),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131426379,
        "f": 50331650
      },
      "n": "{210396}.EmailLayoutRoute",
      "o": "LCFCM$IMessageComposerProvider$EmailLayoutRoute",
      "d": 1884235,
      "h": 51541491787,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51541491787)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951557195),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$LCOv.LCFCPM$1.AccountModel).$h,
      "n": "GetContacts",
      "d": 1884235,
      "h": 42951557195,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951557195)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64426393675),
    {
      "t": 1309651,
      "n": "server",
      "d": 1884235,
      "h": 64426393675,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64426393675)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591818827),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1884235,
      "h": 8591818827,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591818827)
  ],
  "h": 1884235
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$UrvY.LCFCM.IMessageComposerProvider$$($.$LCOv.LCFCPM$1.AccountModel), $.$UrvY.LCFCM.IMessageComposerProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Services.CommunityHandymanUserMessageComposerProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Services${separator}CommunityHandymanUserMessageComposerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1884235)
        
        

        //--TRIMMABLE-BOUNDARY-START(1687627)
        $asm.$cls(`$mpgO.LCCHCAS.CommunityHandymanServiceAccountFeaturePropertyProvider`, ($self) => class CommunityHandymanServiceAccountFeaturePropertyProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68721164363)
            /*int*/ Order = 0;
            //--TRIMMABLE-BOUNDARY-END(68721164363)
            
            //--TRIMMABLE-BOUNDARY-START(73016131659)
            /*string? */ get Title()
            {
                return "Service Account";
            }
            //--TRIMMABLE-BOUNDARY-END(73016131659)
            
            //--TRIMMABLE-BOUNDARY-START(21476524107)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(21476524107)
            
            //--TRIMMABLE-BOUNDARY-START(64426197067)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account-cowboy-hat"/*MaterialDesignIconNames.AccountCowboyHat*/);
            }
            //--TRIMMABLE-BOUNDARY-END(64426197067)
            
            //--TRIMMABLE-BOUNDARY-START(17181556811)
            /*bool */ CanProvideView(/*IObservableDataDescriptor<AccountModel>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181556811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181556811)
            
            //--TRIMMABLE-BOUNDARY-START(60131229771)
            /*RenderFragment? */ GetView(/*ContainerContext<IObservableDataDescriptor<AccountModel>>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131229771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let detail = value.GetAttribute($.$hDPm.LCFCCD.DashboardDetails$$($.$LCOv.LCFCPM$1.AccountModel), null, true);
                /*var*/ let feature = $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.From(value.Data.LCFCR$IReactiveObservable$$$Value, null, null);
                /*var*/ let provider = detail.Provider;
                return $.$hDPm.LCFC.FragmentView.From$1($.$hDPm.LCFCCD.DashboardDetails$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel), (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("ViewModel", (() =>
                    {
                        //new $.$fPer.LCFCD$1.LiteralValueDataDescriptor$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel)()
                        const $t2 = $.$fPer.LCFCD$1.LiteralValueDataDescriptor$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel);
                        const $i2 = new $t2();
                        $i2.$ctor$7(feature, null, null, null, false);
                        $i2.Parent = value.Data;
                        return $i2;
                    })());
                    $i1.set_Item("Provider", provider);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(60131229771)
            
            //--TRIMMABLE-BOUNDARY-START(12898031274)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataPropertyAddOnViewProvider<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.Order.get
            get LCFCCD$IDashboardTableDataPropertyAddOnViewProvider$$$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17192998570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(12898031274)
            
            //--TRIMMABLE-BOUNDARY-START(4308096682)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataPropertyAddOnViewProvider<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.CanProvideView(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>)
            LCFCCD$IDashboardTableDataPropertyAddOnViewProvider$$$CanProvideView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4308096682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanProvideView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4308096682)
            
            //--TRIMMABLE-BOUNDARY-START(4360984234)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IViewProvider<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>.GetView(LivingThing.Core.Frameworks.Client.Interface.ContainerContext<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>)
            [`LCFCI$IViewProvider$LivingThing$Core$Frameworks$Common$DataDescriptor$IObservableDataDescriptor$LivingThing$Core$Frameworks$Common$Posts$Models$AccountModel$$GetView`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4360984234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4360984234)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(12886589515)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886589515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886589515)
            
            //--TRIMMABLE-BOUNDARY-START(12886589515)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886589515)
            
            static $h = 1687627;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68721164363),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246327883,
        "f": 50331649
      },
      "n": "Order",
      "d": 1687627,
      "h": 68721164363,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721164363),
//--TRIMMABLE-BOUNDARY-START(73016131659),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836262475,
        "f": 50331649
      },
      "n": "Title",
      "d": 1687627,
      "h": 73016131659,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016131659),
//--TRIMMABLE-BOUNDARY-START(21476524107),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066458699,
        "f": 50331649
      },
      "n": "Description",
      "d": 1687627,
      "h": 21476524107,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476524107),
//--TRIMMABLE-BOUNDARY-START(64426197067),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656393291,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1687627,
      "h": 64426197067,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426197067)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181556811),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": $.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel).$h
        }
      ],
      "n": "CanProvideView",
      "d": 1687627,
      "h": 17181556811,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181556811),
//--TRIMMABLE-BOUNDARY-START(60131229771),
    {
      "r": 6881395,
      "p": [
        {
          "n": "value",
          "p": $.$hDPm.LCFCI.ContainerContext$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        }
      ],
      "n": "GetView",
      "d": 1687627,
      "h": 60131229771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131229771)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886589515),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1687627,
      "h": 12886589515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886589515)
  ],
  "h": 1687627
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableDataPropertyAddOnViewProvider$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCI.IViewProvider$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel)), $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Services.CommunityHandymanServiceAccountFeaturePropertyProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Services${separator}CommunityHandymanServiceAccountFeaturePropertyProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1687627)
        
        

        //--TRIMMABLE-BOUNDARY-START(1556555)
        $asm.$cls(`$mpgO.LCCHCAS.CommunityHandymanAttachmentsPropertyProvider`, ($self) => class CommunityHandymanAttachmentsPropertyProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68721033291)
            /*int*/ Order = 0;
            //--TRIMMABLE-BOUNDARY-END(68721033291)
            
            //--TRIMMABLE-BOUNDARY-START(73016000587)
            /*string? */ get Title()
            {
                return "Attachments";
            }
            //--TRIMMABLE-BOUNDARY-END(73016000587)
            
            //--TRIMMABLE-BOUNDARY-START(21476393035)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(21476393035)
            
            //--TRIMMABLE-BOUNDARY-START(64426065995)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-file"/*MaterialDesignIconNames.File*/);
            }
            //--TRIMMABLE-BOUNDARY-END(64426065995)
            
            //--TRIMMABLE-BOUNDARY-START(17181425739)
            /*bool */ CanProvideView(/*IObservableDataDescriptor<AccountModel>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181425739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181425739)
            
            //--TRIMMABLE-BOUNDARY-START(60131098699)
            /*RenderFragment? */ GetView(/*ContainerContext<IObservableDataDescriptor<AccountModel>>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131098699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$hDPm.LCFCCR$2.ResourceBrowser, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("Features", $.$box(7/*ResourceBrowserFeatures.Default*/ & ~2/*ResourceBrowserFeatures.Addable*/ & ~4/*ResourceBrowserFeatures.AddFolder*/ & ~1/*ResourceBrowserFeatures.Prompt*/, $.$hDPm.LCFCCR$2.ResourceBrowserFeatures));
                    $i1.set_Item("SourceId", value.Data.LCFCR$IReactiveObservable$$$Value.UserId);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(60131098699)
            
            //--TRIMMABLE-BOUNDARY-START(12898031274)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataPropertyAddOnViewProvider<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.Order.get
            get LCFCCD$IDashboardTableDataPropertyAddOnViewProvider$$$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17192998570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(12898031274)
            
            //--TRIMMABLE-BOUNDARY-START(4308096682)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataPropertyAddOnViewProvider<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.CanProvideView(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>)
            LCFCCD$IDashboardTableDataPropertyAddOnViewProvider$$$CanProvideView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4308096682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanProvideView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4308096682)
            
            //--TRIMMABLE-BOUNDARY-START(4360984234)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IViewProvider<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>.GetView(LivingThing.Core.Frameworks.Client.Interface.ContainerContext<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>)
            [`LCFCI$IViewProvider$LivingThing$Core$Frameworks$Common$DataDescriptor$IObservableDataDescriptor$LivingThing$Core$Frameworks$Common$Posts$Models$AccountModel$$GetView`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4360984234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4360984234)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(12886458443)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886458443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886458443)
            
            //--TRIMMABLE-BOUNDARY-START(12886458443)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886458443)
            
            static $h = 1556555;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68721033291),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246196811,
        "f": 50331649
      },
      "n": "Order",
      "d": 1556555,
      "h": 68721033291,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721033291),
//--TRIMMABLE-BOUNDARY-START(73016000587),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836131403,
        "f": 50331649
      },
      "n": "Title",
      "d": 1556555,
      "h": 73016000587,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016000587),
//--TRIMMABLE-BOUNDARY-START(21476393035),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066327627,
        "f": 50331649
      },
      "n": "Description",
      "d": 1556555,
      "h": 21476393035,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476393035),
//--TRIMMABLE-BOUNDARY-START(64426065995),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656262219,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1556555,
      "h": 64426065995,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426065995)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181425739),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": $.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel).$h
        }
      ],
      "n": "CanProvideView",
      "d": 1556555,
      "h": 17181425739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181425739),
//--TRIMMABLE-BOUNDARY-START(60131098699),
    {
      "r": 6881395,
      "p": [
        {
          "n": "value",
          "p": $.$hDPm.LCFCI.ContainerContext$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        }
      ],
      "n": "GetView",
      "d": 1556555,
      "h": 60131098699,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131098699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886458443),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1556555,
      "h": 12886458443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886458443)
  ],
  "h": 1556555
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableDataPropertyAddOnViewProvider$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCI.IViewProvider$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel)), $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Services.CommunityHandymanAttachmentsPropertyProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Services${separator}CommunityHandymanAttachmentsPropertyProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1556555)
        
        

        //--TRIMMABLE-BOUNDARY-START(1359947)
        $asm.$cls(`$mpgO.LCCHCAP.VerificationEditor`, ($self) => class VerificationEditor extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$LCOv.LCFCPM$1.AccountModel)
        {
            //--TRIMMABLE-BOUNDARY-START(68720836683)
            /*string */ get OptimizedComponentName()
            {
                return "verificationeditor";
            }
            //--TRIMMABLE-BOUNDARY-END(68720836683)
            
            //--TRIMMABLE-BOUNDARY-START(60130902091)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130902091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Verifiers = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$LCOv.LCFCP.IAccountRequirementVerifier), serviceProvider);
                this.Integrations = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$SXZI.LCCHCS.ICommunityHandymanWorkIntegrationService), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(60130902091)
            
            //--TRIMMABLE-BOUNDARY-START(94490640459)
            /*IEnumerable<IAccountRequirementVerifier>*/ Verifiers = null;
            //--TRIMMABLE-BOUNDARY-END(94490640459)
            
            //--TRIMMABLE-BOUNDARY-START(64425869387)
            /*IEnumerable<ICommunityHandymanWorkIntegrationService>*/ Integrations = null;
            //--TRIMMABLE-BOUNDARY-END(64425869387)
            
            //--TRIMMABLE-BOUNDARY-START(4296327243)
            /*IEnumerable<IAccountRequirementVerifier> */ get _Verifiers()
            {
                return $.$sl.SL.Enumerable.Distinct$1($.$LCOv.LCFCP.IAccountRequirementVerifier, $.$sl.SL.Enumerable.Concat($.$LCOv.LCFCP.IAccountRequirementVerifier, this.Verifiers, $.$sl.SL.Enumerable.SelectMany$2($.$SXZI.LCCHCS.ICommunityHandymanWorkIntegrationService, $.$LCOv.LCFCP.IAccountRequirementVerifier, this.Integrations, new ($.$$.S.Func$$$($.$SXZI.LCCHCS.ICommunityHandymanWorkIntegrationService, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCP.IAccountRequirementVerifier)))().$ctor(this,  (/*i*/ i) =>
                {
                    return $.$sl.SL.Enumerable.Concat($.$LCOv.LCFCP.IAccountRequirementVerifier, (i.LCCHCS$ICommunityHandymanWorkIntegrationServiceBase$Requirements ?? $.$sl.SL.Enumerable.Empty($.$LCOv.LCFCP.IAccountRequirementVerifier)), $.$sl.SL.Enumerable.SelectMany$2($.$UcdF.LCCHCS.ICommunityHandymanWorkServiceCategory, $.$LCOv.LCFCP.IAccountRequirementVerifier, i.LCCHCS$ICommunityHandymanWorkIntegrationServiceBase$GetCategories(), new ($.$$.S.Func$$$($.$UcdF.LCCHCS.ICommunityHandymanWorkServiceCategory, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCP.IAccountRequirementVerifier)))().$ctor(this,  (/**/ c) =>
                    {
                        return c.LCCHCS$ICommunityHandymanWorkServiceCategory$Requirements ?? $.$sl.SL.Enumerable.Empty($.$LCOv.LCFCP.IAccountRequirementVerifier);
                    }, $bHtVhd ??= {"r":$.$$.SCG.IEnumerable$$($.$LCOv.LCFCP.IAccountRequirementVerifier).$h,"p":[{"n":"c","p":7263936}],"n":"","d":1359947,"h":0,"f":17825794})));
                }, $jPTrqb ??= {"r":$.$$.SCG.IEnumerable$$($.$LCOv.LCFCP.IAccountRequirementVerifier).$h,"p":[{"n":"i","p":4043012}],"n":"","d":1359947,"h":0,"f":17825794}))));
            }
            //--TRIMMABLE-BOUNDARY-END(4296327243)
            
            //--TRIMMABLE-BOUNDARY-START(73015803979)
            /*void */ Remove(/*AccountVerification*/ verification)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015803979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.AccountVerification>?*/ let __ca1__;
                this.ViewModel.Verifications = ((__ca1__ = this.ViewModel.Verifications) !== null ? $.$sl.SL.Enumerable.ToList($.$LCOv.LCFCPM$1.AccountVerification, $.$sl.SL.Enumerable.Except$1($.$LCOv.LCFCPM$1.AccountVerification, __ca1__, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.AccountVerification), [verification], null, null))) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(73015803979)
            
            //--TRIMMABLE-BOUNDARY-START(21476196427)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476196427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel.Verifications !== null)
                {
                    __builder.OpenComponent$1($.$macw.MACF.EditForm, 0);
                    __builder.AddComponentParameter(1, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                    __builder.AddComponentParameter(2, "class", "bg-card");
                    __builder.AddAttribute$3(3, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            let $en1 = this.ViewModel.Verifications.SCG$IEnumerable$$$GetEnumerator();
                            while ($en1.SC$1$IEnumerator$MoveNext())
                            {
                                let _verifyable = $en1.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let verifyable = _verifyable;
                                    __builder2.OpenElement(4, "div");
                                    __builder2.AddAttribute$5(5, "class", "bdb clickable selectable pdy-5 pdx-10 pos-rel");
                                    __builder2.OpenElement(6, "div");
                                    __builder2.AddAttribute$5(7, "class", "flex display animate");
                                    /*var*/ let verifier = $.$sl.SL.Enumerable.SingleOrDefault$1($.$LCOv.LCFCP.IAccountRequirementVerifier, this._Verifiers, new ($.$$.S.Func$$$($.$LCOv.LCFCP.IAccountRequirementVerifier, $.$$.S.Boolean))().$ctor(this,  (/**/ v) =>
                                    {
                                        /*string?*/ let __ca1__;
                                        return ((__ca1__ = verifyable.VerifierId) !== null ? $.$$.S.String.Equals$5.call(__ca1__, v.LCFCP$IAccountRequirementVerifier$Id) : false);
                                    }, $tPTvNi ??= {"r":262145,"p":[{"n":"v","p":977332}],"n":"","d":1359947,"h":0,"f":17825794}));
                                    __builder2.OpenElement(8, "h3");
                                    __builder2.AddAttribute$5(9, "class", "mg-0 fill");
                                    __builder2.AddContent$4(10, (verifier?.LCFC$IDisplayable$Title ?? null) ?? verifyable.VerifierId);
                                    __builder2.CloseElement();
                                    __builder2.AddMarkupContent(11, "\r\n                    ");
                                    __builder2.OpenElement(12, "div");
                                    $.$mpgO._LCCHCAPV.TypeInference.CreateInputEditor_0($.$LCOv.LCFCPM$1.AccountVerificationState, __builder2, 13, 14, 41n, 15, $.$fPer.LCFC.Theme.Primary, 16, verifyable.State, 17, $.$mac.MAC.EventCallback.Factory.Create$6($.$LCOv.LCFCPM$1.AccountVerificationState, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$LCOv.LCFCPM$1.AccountVerificationState, this, new ($.$$.S.Action$$($.$LCOv.LCFCPM$1.AccountVerificationState))().$ctor(this,  (/*__value*/ __value) =>
                                    {
                                        return verifyable.State = __value;
                                    }, $yCgeth ??= {"r":65537,"p":[{"n":"__value","p":8317364}],"n":"","d":1359947,"h":0,"f":17825794}), verifyable.State)), 18, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                    {
                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(verifyable), "State"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                    }, $UFbuwf ??= {"r":38797349,"n":"","d":1359947,"h":0,"f":17825794})).Invoke()));
                                    __builder2.CloseElement();
                                    __builder2.AddMarkupContent(19, "\r\n                    ");
                                    __builder2.OpenElement(20, "div");
                                    __builder2.AddAttribute$5(21, "class", "pos-abs r-0 t-0 fade-in-hover");
                                    __builder2.OpenElement(22, "button");
                                    __builder2.AddAttribute$5(23, "class", "mdi mdi-delete");
                                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 24, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                    {
                                        return this.Remove(verifyable);
                                    }, $NTwadj ??= {"r":65537,"n":"","d":1359947,"h":0,"f":17825794})));
                                    __builder2.CloseElement();
                                    __builder2.CloseElement();
                                    __builder2.CloseElement();
                                    if (verifyable.State === 1/*AccountVerificationState.Failed*/)
                                    {
                                        $.$mpgO._LCCHCAPV.TypeInference.CreateInputEditor_1($.$$.S.String, __builder2, 25, 26, "mgt", 27, 16n, 28, "Reason", 29, $.$fPer.LCFC.Theme.Primary, 30, verifyable.Reason, 31, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                        {
                                            return verifyable.Reason = __value;
                                        }, $OqrYRb ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1359947,"h":0,"f":17825794}), verifyable.Reason)), 32, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                        {
                                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(verifyable), "Reason"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                        }, $FzpHoi ??= {"r":38797349,"n":"","d":1359947,"h":0,"f":17825794})).Invoke()));
                                    }
                                    __builder2.CloseElement();
                                }
                            }
                        }, $pLGlfg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1359947,"h":0,"f":17825794});
                    }), $GqeyVh ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":1359947,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476196427)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17181229131)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181229131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181229131)
            
            //--TRIMMABLE-BOUNDARY-START(17181229131)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(17181229131)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(94490640459)
                this.Verifiers = null;
                //--TRIMMABLE-BOUNDARY-END(94490640459)
                
                //--TRIMMABLE-BOUNDARY-START(64425869387)
                this.Integrations = null;
                //--TRIMMABLE-BOUNDARY-END(64425869387)
                
            }
            static $h = 1359947;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$LCOv.LCFCPM$1.AccountModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720836683),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246000203,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1359947,
      "h": 68720836683,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68720836683),
//--TRIMMABLE-BOUNDARY-START(94490640459),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCP.IAccountRequirementVerifier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835934795,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195673163,
        "f": 83886081
      },
      "n": "Verifiers",
      "d": 1359947,
      "h": 94490640459,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94490640459),
//--TRIMMABLE-BOUNDARY-START(64425869387),
    {
      "p": $.$$.SCG.IEnumerable$$($.$SXZI.LCCHCS.ICommunityHandymanWorkIntegrationService).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656065611,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605738571,
        "f": 83886081
      },
      "n": "Integrations",
      "d": 1359947,
      "h": 64425869387,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425869387),
//--TRIMMABLE-BOUNDARY-START(4296327243),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCP.IAccountRequirementVerifier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066131019,
        "f": 50331650
      },
      "n": "_Verifiers",
      "d": 1359947,
      "h": 4296327243,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4296327243)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130902091),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1359947,
      "h": 60130902091,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130902091),
//--TRIMMABLE-BOUNDARY-START(73015803979),
    {
      "r": 65537,
      "p": [
        {
          "n": "verification",
          "p": 8251828
        }
      ],
      "n": "Remove",
      "d": 1359947,
      "h": 73015803979,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015803979),
//--TRIMMABLE-BOUNDARY-START(21476196427),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1359947,
      "h": 21476196427,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476196427)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181229131),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1359947,
      "h": 17181229131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181229131)
  ],
  "h": 1359947
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Pages.VerificationEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Pages${separator}VerificationEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1359947)
        
        

        //--TRIMMABLE-BOUNDARY-START(1818699)
        $asm.$cls(`$mpgO.LCCHCAS.CommunityHandymanServiceAccountVerificationCommand`, ($self) => class CommunityHandymanServiceAccountVerificationCommand extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81606197323)
            /*IClientUnitOfWork*/ unitOfWork = null;
            //--TRIMMABLE-BOUNDARY-END(81606197323)
            
            //--TRIMMABLE-BOUNDARY-START(12886720587)
            /*CommunityPhoneNumberRequirementVerifier*/ _phoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(12886720587)
            
            //--TRIMMABLE-BOUNDARY-START(8591753291)
            /*CommunityNINRequirementVerifier*/ _nin = null;
            //--TRIMMABLE-BOUNDARY-END(8591753291)
            
            //--TRIMMABLE-BOUNDARY-START(4296785995)
            /*CommunityLocationRegionRequirementVerifier*/ _location = null;
            //--TRIMMABLE-BOUNDARY-END(4296785995)
            
            //--TRIMMABLE-BOUNDARY-START(21476655179)
            $ctor$1(/*IClientUnitOfWork*/ unitOfWork, /*CommunityPhoneNumberRequirementVerifier*/ phoneNumber, /*CommunityNINRequirementVerifier*/ nin, /*CommunityLocationRegionRequirementVerifier*/ location)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476655179);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.unitOfWork = unitOfWork;
                    this._phoneNumber = phoneNumber;
                    this._nin = nin;
                    this._location = location;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476655179)
            
            //--TRIMMABLE-BOUNDARY-START(77311230027)
            /*string? */ get Title()
            {
                return "Verify";
            }
            //--TRIMMABLE-BOUNDARY-END(77311230027)
            
            //--TRIMMABLE-BOUNDARY-START(34361557067)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(34361557067)
            
            //--TRIMMABLE-BOUNDARY-START(73016262731)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-security"/*MaterialDesignIconNames.Security*/);
            }
            //--TRIMMABLE-BOUNDARY-END(73016262731)
            
            //--TRIMMABLE-BOUNDARY-START(25771622475)
            /*bool */ CanCommand(/*OneOf<DashboardTable<CommunityHandymanServiceAccountFeatureModel>, DashboardDetails<CommunityHandymanServiceAccountFeatureModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityHandymanServiceAccountFeatureModel>>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771622475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Count$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel), data) === 1;
            }
            //--TRIMMABLE-BOUNDARY-END(25771622475)
            
            //--TRIMMABLE-BOUNDARY-START(30066589771)
            /*bool */ CanCommand$1(/*OneOf<DashboardTable<AccountModel>, DashboardDetails<AccountModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<AccountModel>>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066589771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Count$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel), data) === 1;
            }
            //--TRIMMABLE-BOUNDARY-END(30066589771)
            
            //--TRIMMABLE-BOUNDARY-START(38656524363)
            /*ValueTask *//*async*/  Execute(/*OneOf<DashboardTable<CommunityHandymanServiceAccountFeatureModel>, DashboardDetails<CommunityHandymanServiceAccountFeatureModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityHandymanServiceAccountFeatureModel>>*/ data)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656524363);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let target = $.$sl.SL.Enumerable.Single$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel), data);
                    /*var*/ let account = $.$cast(target.LCFCR$IReactiveObservable$$$Value.Parent, $.$LCOv.LCFCPM$1.AccountModel);
                    ($t1 = $.$vWqU.LCFCR.DataModelExtension.EnsureHasProperties($.$LCOv.LCFCPM$1.AccountModel, account, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.GetFeatureKey(null) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$mpgO.LCCHCAP.VerificationEditor, this.unitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/**/ b, /*i*/ i) =>
                    {
                        b.AddAttribute$4(3, "ViewModel", account);
                    }, $hJldOa ??= {"r":65537,"p":[{"n":"b","p":7536755},{"n":"i","p":655361}],"n":"","d":1818699,"h":0,"f":17825794}), null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t3 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.ViewFeatures = 63207/*ViewFeatures.PromptDefault*/;
                        return $i3;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    /*var*/ let wasVerified = target.LCFCR$IReactiveObservable$$$Value.Verified;
                    target.LCFCR$IReactiveObservable$$$Value.Verified = $.$LCOv.LCFCPM$1.AccountRequirementVerifierExtension.IsVerified(account, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCP.IAccountRequirementVerifier), [this._phoneNumber, this._nin, this._location], [-1], null));
                    ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$LCOv.LCFCPM$1.AccountModel, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.AccountModel), [ account ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    if (!wasVerified && target.LCFCR$IReactiveObservable$$$Value.Verified && (account.User?.Email ?? null) !== null)
                    {
                        let $t5, $r5;
                        ($t5 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.SendHTMLEmail(this.unitOfWork.LCFCI$IClientUnitOfWork$Server, "Handyman", "Handyman Account Verified", "/Handyman/AccountVerified"/*CommunityHandymanConstants.AccountVerifiedEmailPath*/, (() =>
                        {
                            //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)()
                            const $t6 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String);
                            const $i6 = new $t6();
                            $i6.$ctor$1();
                            $i6.set_Item("name", target.LCFCR$IReactiveObservable$$$Value.FullName$1);
                            return $i6;
                        })(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ account.User.Email ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38656524363)
            
            //--TRIMMABLE-BOUNDARY-START(42951491659)
            /*ValueTask *//*async*/  Execute$1(/*OneOf<DashboardTable<AccountModel>, DashboardDetails<AccountModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<AccountModel>>*/ data)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t7, $r7;
                    let $t8, $r8;
                    let $t10, $r10;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951491659);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let account = $.$sl.SL.Enumerable.Single$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel), data).LCFCR$IReactiveObservable$$$Value;
                    ($t7 = $.$vWqU.LCFCR.DataModelExtension.EnsureHasProperties($.$LCOv.LCFCPM$1.AccountModel, account, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.GetFeatureKey(null) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    /*var*/ let feature = $.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel.From(account, null, null);
                    ($t8 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$mpgO.LCCHCAP.VerificationEditor, this.unitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*b*/ b, /*i*/ i) =>
                    {
                        b.AddAttribute$4(3, "ViewModel", account);
                    }, $cdwGyg ??= {"r":65537,"p":[{"n":"b","p":7536755},{"n":"i","p":655361}],"n":"","d":1818699,"h":0,"f":17825794}), null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t9 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.ViewFeatures = 63207/*ViewFeatures.PromptDefault*/;
                        return $i9;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    /*var*/ let wasVerified = feature.Verified;
                    feature.Verified = $.$LCOv.LCFCPM$1.AccountRequirementVerifierExtension.IsVerified(account, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCP.IAccountRequirementVerifier), [this._phoneNumber, this._nin, this._location], [-1], null));
                    ($t10 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$LCOv.LCFCPM$1.AccountModel, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.AccountModel), [ account ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    if (!wasVerified && feature.Verified && (account.User?.Email ?? null) !== null)
                    {
                        let $t11, $r11;
                        ($t11 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.SendHTMLEmail(this.unitOfWork.LCFCI$IClientUnitOfWork$Server, "Handyman", "Handyman Account Verified", "/Handyman/AccountVerified"/*CommunityHandymanConstants.AccountVerifiedEmailPath*/, (() =>
                        {
                            //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)()
                            const $t12 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String);
                            const $i12 = new $t12();
                            $i12.$ctor$1();
                            $i12.set_Item("name", feature.FullName$1);
                            return $i12;
                        })(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ account.User.Email ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42951491659)
            
            //--TRIMMABLE-BOUNDARY-START(4307965610)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.CanCommand(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$CanCommand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4307965610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanCommand$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4307965610)
            
            //--TRIMMABLE-BOUNDARY-START(8602932906)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.Execute(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8602932906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8602932906)
            
            //--TRIMMABLE-BOUNDARY-START(4307965610)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Handyman.Common.Models.CommunityHandymanServiceAccountFeatureModel>.CanCommand(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Handyman.Common.Models.CommunityHandymanServiceAccountFeatureModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Handyman.Common.Models.CommunityHandymanServiceAccountFeatureModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Handyman.Common.Models.CommunityHandymanServiceAccountFeatureModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$CanCommand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4307965610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanCommand(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4307965610)
            
            //--TRIMMABLE-BOUNDARY-START(8602932906)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Handyman.Common.Models.CommunityHandymanServiceAccountFeatureModel>.Execute(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Handyman.Common.Models.CommunityHandymanServiceAccountFeatureModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Handyman.Common.Models.CommunityHandymanServiceAccountFeatureModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Handyman.Common.Models.CommunityHandymanServiceAccountFeatureModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8602932906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8602932906)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 1818699;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311230027),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721295435,
        "f": 50331649
      },
      "n": "Title",
      "d": 1818699,
      "h": 77311230027,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311230027),
//--TRIMMABLE-BOUNDARY-START(34361557067),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541426251,
        "f": 50331649
      },
      "n": "Description",
      "d": 1818699,
      "h": 34361557067,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361557067),
//--TRIMMABLE-BOUNDARY-START(73016262731),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131360843,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1818699,
      "h": 73016262731,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016262731)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771622475),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel)).$h
        }
      ],
      "n": "CanCommand",
      "d": 1818699,
      "h": 25771622475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771622475),
//--TRIMMABLE-BOUNDARY-START(30066589771),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        }
      ],
      "n": "CanCommand",
      "o": "@$1",
      "d": 1818699,
      "h": 30066589771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066589771),
//--TRIMMABLE-BOUNDARY-START(38656524363),
    {
      "r": 181338113,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel)).$h
        }
      ],
      "n": "Execute",
      "d": 1818699,
      "h": 38656524363,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(38656524363),
//--TRIMMABLE-BOUNDARY-START(42951491659),
    {
      "r": 181338113,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$LCOv.LCFCPM$1.AccountModel)).$h
        }
      ],
      "n": "Execute",
      "o": "@$1",
      "d": 1818699,
      "h": 42951491659,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(42951491659)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81606197323),
    {
      "t": 63657642,
      "n": "unitOfWork",
      "d": 1818699,
      "h": 81606197323,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81606197323),
//--TRIMMABLE-BOUNDARY-START(12886720587),
    {
      "t": 14652864,
      "n": "_phoneNumber",
      "d": 1818699,
      "h": 12886720587,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886720587),
//--TRIMMABLE-BOUNDARY-START(8591753291),
    {
      "t": 14587328,
      "n": "_nin",
      "d": 1818699,
      "h": 8591753291,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591753291),
//--TRIMMABLE-BOUNDARY-START(4296785995),
    {
      "t": 14521792,
      "n": "_location",
      "d": 1818699,
      "h": 4296785995,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296785995)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476655179),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        },
        {
          "n": "phoneNumber",
          "p": 14652864
        },
        {
          "n": "nin",
          "p": 14587328
        },
        {
          "n": "location",
          "p": 14521792
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1818699,
      "h": 21476655179,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476655179)
  ],
  "h": 1818699
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$UcdF.LCCHCM.CommunityHandymanServiceAccountFeatureModel), $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Handyman.Client.Admin.Services.CommunityHandymanServiceAccountVerificationCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Handyman${separator}Client${separator}Admin${separator}Services${separator}CommunityHandymanServiceAccountVerificationCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1818699)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Article.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Handyman.Common", "NetJs.LivingThing.Core.Community.Handyman.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(49227)
