
//--TRIMMABLE-BOUNDARY-START(30690)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $xvUV) {
    "use strict";
    let _;
    let $jSwDak;
    let $aVKrKg;
    let $nxDyDa;
    let $pqtBCf;
    let $iHrrol;
    let $iJVlCb;
    let $Irwpqj;
    let $HDEGDi;
    let $IErdHg;
    let $DoKskc;
    let $xSujQb;
    let $WKarvh;
    let $qalIic;
    let $tbYYib;
    let $vNbhHf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Job.Client.Blazor", 
    {
  "h": 30690,
  "f": "LivingThing.Core.Community.Job.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Job.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Job.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(161762)
        $asm.$cls(`$sQJD.LCCJC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295129058)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295129058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$sQJD.LCCJC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295129058)
            
            static $h = 161762;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295129058),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 161762,
      "h": 4295129058,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295129058)
  ],
  "h": 161762
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(161762)
        
        

        //--TRIMMABLE-BOUNDARY-START(358370)
        $asm.$cls(`$sQJD.LCCJC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590292962)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590292962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$sQJD.LCCJCS.CommunityJobService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$xvUV.LCCJCM.CommunityJobPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$sQJD.LCCJCS.CommunityJobApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$sQJD.LCCJCS.CommunityJobApplication, x);
                }, $aVKrKg ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":358370,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$sQJD.LCCJCS.CommunityJobApplication, x);
                }, $nxDyDa ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":358370,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$xvUV.LCCJCM.CommunityJobPostModel, services, null);
                $.$sQJD.LCCJC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590292962)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sQJD.LCCJC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295325666)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295325666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295325666)
            
            //--TRIMMABLE-BOUNDARY-START(4295325666)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295325666)
            
            static $h = 358370;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590292962),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 358370,
      "h": 8590292962,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590292962)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295325666),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 358370,
      "h": 4295325666,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295325666)
  ],
  "h": 358370
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(358370)
        
        

        //--TRIMMABLE-BOUNDARY-START(227298)
        $asm.$cls(`$sQJD.LCCJC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180096482)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$sQJD.LCCJCP.CommunityJobApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$sQJD.LCCJCP.CommunityJobApp().$ctor$3();
                    }, $jSwDak ??= {"r":2752627,"n":"","d":227298,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180096482)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295194594)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295194594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295194594)
            
            //--TRIMMABLE-BOUNDARY-START(4295194594)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295194594)
            
            static $h = 227298;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180096482),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885129186,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 227298,
      "h": 17180096482,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180096482)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295194594),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 227298,
      "h": 4295194594,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295194594)
  ],
  "h": 227298
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(227298)
        
        

        //--TRIMMABLE-BOUNDARY-START(620514)
        $asm.$cls(`$sQJD.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295587810)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295587810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295587810)
            
            //--TRIMMABLE-BOUNDARY-START(4295587810)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295587810)
            
            static $h = 620514;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295587810),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 620514,
      "h": 4295587810,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295587810)
  ],
  "h": 620514,
  "a": [
    {
      "t": 554978,
      "c": 4295522274
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(620514)
        
        

        //--TRIMMABLE-BOUNDARY-START(554978)
        $asm.$cls(`$sQJD.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295522274)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295522274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295522274)
            
            //--TRIMMABLE-BOUNDARY-START(4295522274)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295522274)
            
            static $h = 554978;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295522274),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 554978,
      "h": 4295522274,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295522274)
  ],
  "h": 554978
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(554978)
        
        

        //--TRIMMABLE-BOUNDARY-START(96226)
        $asm.$cls(`$sQJD.LCCJC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590030818)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590030818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590030818)
            
            //--TRIMMABLE-BOUNDARY-START(4295063522)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295063522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295063522)
            
            //--TRIMMABLE-BOUNDARY-START(4295063522)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295063522)
            
            static $h = 96226;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590030818),
    {
      "r": 65537,
      "n": "Execute",
      "d": 96226,
      "h": 8590030818,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590030818)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295063522),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 96226,
      "h": 4295063522,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295063522)
  ],
  "h": 96226
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(96226)
        
        

        //--TRIMMABLE-BOUNDARY-START(292834)
        $asm.$cls(`$sQJD.LCCJCP.CommunityJobApp`, ($self) => class CommunityJobApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(60129834978)
            /*CommunityJobService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(60129834978)
            
            //--TRIMMABLE-BOUNDARY-START(21475129314)
            /*CommunityJobApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(21475129314)
            
            //--TRIMMABLE-BOUNDARY-START(55834867682)
            /*IUIRenderingProvider*/ Rendering = null;
            //--TRIMMABLE-BOUNDARY-END(55834867682)
            
            //--TRIMMABLE-BOUNDARY-START(25770096610)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770096610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "InitialViewIndex", "0");
                __builder.AddComponentParameter(2, "Name", "Job");
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(5, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 6);
                        __builder2.AddComponentParameter(7, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                        __builder2.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(9, wrap.View);
                        }), $pqtBCf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":292834,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $iHrrol ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":292834,"h":0,"f":17825794});
                }), $iJVlCb ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":292834,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/*splash*/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 11);
                        __builder2.AddComponentParameter(12, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, splash.ViewModel));
                        __builder2.AddComponentParameter(13, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, splash.Message));
                        __builder2.CloseComponent();
                    }, $Irwpqj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":292834,"h":0,"f":17825794});
                }), $HDEGDi ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":292834,"h":0,"f":17825794}));
                __builder.AddAttribute$3(14, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 15);
                    __builder2.AddComponentParameter(16, "Name", "");
                    __builder2.AddComponentParameter(17, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddAttribute$3(18, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(19, "Job");
                        }, $IErdHg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":292834,"h":0,"f":17825794});
                    }), $DoKskc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":292834,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(20, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(21, "<i class=\"mdi mdi-book\"></i>");
                        }, $xSujQb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":292834,"h":0,"f":17825794});
                    }), $WKarvh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":292834,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(22, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityApplicationUnderDevelopment, 23);
                            __builder3.AddComponentParameter(24, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCS.ICommunityClientApplication, this.Application));
                            __builder3.CloseComponent();
                        }, $qalIic ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":292834,"h":0,"f":17825794});
                    }), $tbYYib ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":292834,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $vNbhHf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":292834,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25770096610)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180162018)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180162018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180162018)
            
            //--TRIMMABLE-BOUNDARY-START(17180162018)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17180162018)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60129834978)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(60129834978)
                
                //--TRIMMABLE-BOUNDARY-START(21475129314)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(21475129314)
                
                //--TRIMMABLE-BOUNDARY-START(55834867682)
                this.Rendering = null;
                //--TRIMMABLE-BOUNDARY-END(55834867682)
                
            }
            static $h = 292834;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129834978),
    {
      "p": 489442,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539900386,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899638754,
        "f": 83886081
      },
      "n": "Service",
      "d": 292834,
      "h": 60129834978,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60129834978),
//--TRIMMABLE-BOUNDARY-START(21475129314),
    {
      "p": 423906,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360031202,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719769570,
        "f": 83886081
      },
      "n": "Application",
      "d": 292834,
      "h": 21475129314,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475129314),
//--TRIMMABLE-BOUNDARY-START(55834867682),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949965794,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309704162,
        "f": 83886081
      },
      "n": "Rendering",
      "d": 292834,
      "h": 55834867682,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834867682)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770096610),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 292834,
      "h": 25770096610,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770096610)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180162018),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 292834,
      "h": 17180162018,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180162018)
  ],
  "h": 292834
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Client.Pages.CommunityJobApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Client${separator}Pages${separator}CommunityJobApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(292834)
        
        

        //--TRIMMABLE-BOUNDARY-START(423906)
        $asm.$cls(`$sQJD.LCCJCS.CommunityJobApplication`, ($self) => class CommunityJobApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885325794)
            $ctor$5(/*CommunityJobService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885325794);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885325794)
            
            //--TRIMMABLE-BOUNDARY-START(137439377378)
            /*string */ get Name()
            {
                return "Job";
            }
            //--TRIMMABLE-BOUNDARY-END(137439377378)
            
            //--TRIMMABLE-BOUNDARY-START(158914213858)
            /*string */ get Title()
            {
                return "Job";
            }
            //--TRIMMABLE-BOUNDARY-END(158914213858)
            
            //--TRIMMABLE-BOUNDARY-START(21475260386)
            /*string */ get Description()
            {
                return "Job seekers meets employers. Find your dream job from the comfort of your phone.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475260386)
            
            //--TRIMMABLE-BOUNDARY-START(133144410082)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-racing-helmet"/*MaterialDesignIconNames.RacingHelmet*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144410082)
            
            //--TRIMMABLE-BOUNDARY-START(154619246562)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2E961B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619246562)
            
            //--TRIMMABLE-BOUNDARY-START(30065194978)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065194978)
            
            //--TRIMMABLE-BOUNDARY-START(17180293090)
            /*Type? */ get ApplicationViewType()
            {
                return $.$sQJD.LCCJCP.CommunityJobApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180293090)
            
            //--TRIMMABLE-BOUNDARY-START(128849442786)
            /*RenderFragment? */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849442786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$sQJD.LCCJCP.CommunityJobApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849442786)
            
            //--TRIMMABLE-BOUNDARY-START(25770227682)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770227682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770227682)
            
            //--TRIMMABLE-BOUNDARY-START(146029311970)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029311970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029311970)
            
            //--TRIMMABLE-BOUNDARY-START(141734344674)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734344674)
            
            //--TRIMMABLE-BOUNDARY-START(4295391202)
            /*CommunityJobService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295391202)
            
            //--TRIMMABLE-BOUNDARY-START(150324279266)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(150324279266)
            
            //--TRIMMABLE-BOUNDARY-START(163209181154)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(3840/*PostTypes.Job*/, 3841/*PostTypes.JobEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209181154)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 423906;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439377378),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604802530,
        "f": 50364417
      },
      "n": "Name",
      "d": 423906,
      "h": 137439377378,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439377378),
//--TRIMMABLE-BOUNDARY-START(158914213858),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964540898,
        "f": 50364417
      },
      "n": "Title",
      "d": 423906,
      "h": 158914213858,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914213858),
//--TRIMMABLE-BOUNDARY-START(21475260386),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834998754,
        "f": 50364417
      },
      "n": "Description",
      "d": 423906,
      "h": 21475260386,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475260386),
//--TRIMMABLE-BOUNDARY-START(133144410082),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014867938,
        "f": 50364417
      },
      "n": "Icon",
      "d": 423906,
      "h": 133144410082,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144410082),
//--TRIMMABLE-BOUNDARY-START(154619246562),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374606306,
        "f": 50364417
      },
      "n": "Theme",
      "d": 423906,
      "h": 154619246562,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619246562),
//--TRIMMABLE-BOUNDARY-START(30065194978),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424933346,
        "f": 50364417
      },
      "n": "Features",
      "d": 423906,
      "h": 30065194978,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065194978),
//--TRIMMABLE-BOUNDARY-START(17180293090),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245064162,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 423906,
      "h": 17180293090,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180293090),
//--TRIMMABLE-BOUNDARY-START(141734344674),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194737122,
        "f": 50364417
      },
      "n": "Order",
      "d": 423906,
      "h": 141734344674,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734344674),
//--TRIMMABLE-BOUNDARY-START(4295391202),
    {
      "p": 489442,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655129570,
        "f": 50331650
      },
      "n": "_Service",
      "d": 423906,
      "h": 4295391202,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295391202),
//--TRIMMABLE-BOUNDARY-START(150324279266),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784671714,
        "f": 50364417
      },
      "n": "Service",
      "d": 423906,
      "h": 150324279266,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324279266),
//--TRIMMABLE-BOUNDARY-START(163209181154),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554475490,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 423906,
      "h": 163209181154,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209181154)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849442786),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 423906,
      "h": 128849442786,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849442786),
//--TRIMMABLE-BOUNDARY-START(25770227682),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 423906,
      "h": 25770227682,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770227682),
//--TRIMMABLE-BOUNDARY-START(146029311970),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 423906,
      "h": 146029311970,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029311970)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885325794),
    {
      "p": [
        {
          "n": "service",
          "p": 489442
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 423906,
      "h": 12885325794,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885325794)
  ],
  "h": 423906
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$xvUV.LCCJCM.CommunityJobPostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Client.Services.CommunityJobApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Client${separator}Services${separator}CommunityJobApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(423906)
        
        

        //--TRIMMABLE-BOUNDARY-START(489442)
        $asm.$cls(`$sQJD.LCCJCS.CommunityJobService`, ($self) => class CommunityJobService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$xvUV.LCCJCM.CommunityJobPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295456738)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295456738);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295456738)
            
            static $h = 489442;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$xvUV.LCCJCM.CommunityJobPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295456738),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 489442,
      "h": 4295456738,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295456738)
  ],
  "h": 489442
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$xvUV.LCCJCM.CommunityJobPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$xvUV.LCCJCM.CommunityJobPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Client.Services.CommunityJobService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Client${separator}Services${separator}CommunityJobService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(489442)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Job.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(30690)
