
//--TRIMMABLE-BOUNDARY-START(50517)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $TPAEqd;
    let $Grsall;
    let $bjKtwa;
    let $rRBfNb;
    let $gcajMg;
    let $wFbCUd;
    let $VODzUj;
    let $wCJhsk;
    let $FFudkc;
    let $rHQwfk;
    let $hSJxwg;
    let $zSLodc;
    let $ibpqEk;
    let $nUORid;
    let $eAfETa;
    let $HTkJBj;
    let $zQDGxc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Job.Common", 
    {
  "h": 50517,
  "f": "LivingThing.Core.Community.Job.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Job.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Job.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(116053)
        $asm.$cls(`$xvUV.LCCJC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295083349)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295083349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xvUV.LCCJCM.CommunityJobModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xvUV.LCCJCM.CommunityJobModelCustomAttributesProvider, $.$xvUV.LCCJCM.CommunityJobModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xvUV.LCCJCM.CommunityJobPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xvUV.LCCJCM.CommunityJobPostModelCustomAttributesProvider, $.$xvUV.LCCJCM.CommunityJobPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xvUV.LCCJCS$1.CommunityJobSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xvUV.LCCJCS$1.CommunityJobSettingsCustomAttributesProvider, $.$xvUV.LCCJCS$1.CommunityJobSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xvUV.LCCJCS$2.CommunityJobStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xvUV.LCCJCS$2.CommunityJobStatesCustomAttributesProvider, $.$xvUV.LCCJCS$2.CommunityJobStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295083349)
            
            static $h = 116053;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295083349),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 116053,
      "h": 4295083349,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295083349)
  ],
  "h": 116053
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(116053)
        
        

        //--TRIMMABLE-BOUNDARY-START(574805)
        $asm.$cls(`$xvUV.LCCJCM.CommunityJobPostModelCustomAttributesProvider`, ($self) => class CommunityJobPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295542101)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295542101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295542101)
            
            static $h = 574805;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295542101),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 574805,
      "h": 4295542101,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295542101)
  ],
  "h": 574805
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Models${separator}CommunityJobPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(574805)
        
        

        //--TRIMMABLE-BOUNDARY-START(312661)
        $asm.$cls(`$xvUV.LCCJCM.CommunityJobModelCustomAttributesProvider`, ($self) => class CommunityJobModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295279957)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295279957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$xvUV.LCCJCS$1.CommunityJobSettings, $.$xvUV.LCCJCS$2.CommunityJobStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295279957)
            
            static $h = 312661;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295279957),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 312661,
      "h": 4295279957,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295279957)
  ],
  "h": 312661
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Models.CommunityJobModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Models${separator}CommunityJobModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(312661)
        
        

        //--TRIMMABLE-BOUNDARY-START(181589)
        $asm.$cls(`$xvUV.LCCJC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295148885)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295148885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$xvUV.LCCJCS.IComunityJobRemoteService, $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking().$ctor$3(impl);
                }, $VODzUj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":181589,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking().$ctor$3(impl);
                }, $wCJhsk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":181589,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking().$ctor$3(impl);
                }, $FFudkc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":181589,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking().$ctor$3(impl);
                }, $rHQwfk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":181589,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking().$ctor$3(impl);
                }, $hSJxwg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":181589,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking().$ctor$3(impl);
                }, $zSLodc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":181589,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking().$ctor$3(impl);
                }, $ibpqEk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":181589,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$xvUV.LCCJCS.IComunityJobRemoteService_Mocking().$ctor$3(impl);
                }, $nUORid ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":181589,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295148885)
            
            static $h = 181589;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295148885),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 181589,
      "h": 4295148885,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295148885)
  ],
  "h": 181589
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(181589)
        
        

        //--TRIMMABLE-BOUNDARY-START(1033557)
        $asm.$cls(`$xvUV.LCCJCS$1.CommunityJobSettingsCustomAttributesProvider`, ($self) => class CommunityJobSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296000853)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296000853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296000853)
            
            static $h = 1033557;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296000853),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1033557,
      "h": 4296000853,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296000853)
  ],
  "h": 1033557
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Settings.CommunityJobSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Settings${separator}CommunityJobSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1033557)
        
        

        //--TRIMMABLE-BOUNDARY-START(1492309)
        $asm.$cls(`$xvUV.LCCJC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296459605)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296459605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$xvUV.LCCJCM.CommunityJobModelTypeDescriptorBuilder.Register();
                $.$xvUV.LCCJCM.CommunityJobPostModelTypeDescriptorBuilder.Register();
                $.$xvUV.LCCJCS$1.CommunityJobSettingsTypeDescriptorBuilder.Register();
                $.$xvUV.LCCJCS$2.CommunityJobStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296459605)
            
            static $h = 1492309;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296459605),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1492309,
      "h": 4296459605,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296459605)
  ],
  "h": 1492309
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1492309)
        
        

        //--TRIMMABLE-BOUNDARY-START(1295701)
        $asm.$cls(`$xvUV.LCCJCS$2.CommunityJobStatesCustomAttributesProvider`, ($self) => class CommunityJobStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296262997)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296262997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296262997)
            
            static $h = 1295701;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296262997),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1295701,
      "h": 4296262997,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296262997)
  ],
  "h": 1295701
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.States.CommunityJobStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}States${separator}CommunityJobStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1295701)
        
        

        //--TRIMMABLE-BOUNDARY-START(1426773)
        $asm.$cls(`$xvUV.LCCJCS$2.CommunityJobStatesTypeDescriptorBuilder`, ($self) => class CommunityJobStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591361365)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591361365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xvUV.LCCJCS$2.CommunityJobStatesTypeDescriptor()
                        const $t1 = $.$xvUV.LCCJCS$2.CommunityJobStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Job.Common.States.CommunityJobStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $bjKtwa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1426773,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xvUV.LCCJCS$2.CommunityJobStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591361365)
            
            //--TRIMMABLE-BOUNDARY-START(4296394069)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296394069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296394069)
            
            //--TRIMMABLE-BOUNDARY-START(4296394069)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296394069)
            
            static $h = 1426773;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591361365),
    {
      "r": 65537,
      "n": "Register",
      "d": 1426773,
      "h": 8591361365,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591361365)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296394069),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1426773,
      "h": 4296394069,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296394069)
  ],
  "h": 1426773
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.States.CommunityJobStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}States${separator}CommunityJobStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1426773)
        
        

        //--TRIMMABLE-BOUNDARY-START(1164629)
        $asm.$cls(`$xvUV.LCCJCS$1.CommunityJobSettingsTypeDescriptorBuilder`, ($self) => class CommunityJobSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591099221)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591099221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xvUV.LCCJCS$1.CommunityJobSettingsTypeDescriptor()
                        const $t1 = $.$xvUV.LCCJCS$1.CommunityJobSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Job.Common.Settings.CommunityJobSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $TPAEqd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1164629,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xvUV.LCCJCS$1.CommunityJobSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591099221)
            
            //--TRIMMABLE-BOUNDARY-START(4296131925)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296131925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296131925)
            
            //--TRIMMABLE-BOUNDARY-START(4296131925)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296131925)
            
            static $h = 1164629;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591099221),
    {
      "r": 65537,
      "n": "Register",
      "d": 1164629,
      "h": 8591099221,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591099221)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296131925),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1164629,
      "h": 4296131925,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296131925)
  ],
  "h": 1164629
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Settings.CommunityJobSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Settings${separator}CommunityJobSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1164629)
        
        

        //--TRIMMABLE-BOUNDARY-START(705877)
        $asm.$cls(`$xvUV.LCCJCM.CommunityJobPostModelTypeDescriptorBuilder`, ($self) => class CommunityJobPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590640469)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590640469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xvUV.LCCJCM.CommunityJobPostModelTypeDescriptor()
                        const $t1 = $.$xvUV.LCCJCM.CommunityJobPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $eAfETa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":705877,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xvUV.LCCJCM.CommunityJobPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590640469)
            
            //--TRIMMABLE-BOUNDARY-START(4295673173)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295673173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295673173)
            
            //--TRIMMABLE-BOUNDARY-START(4295673173)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295673173)
            
            static $h = 705877;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590640469),
    {
      "r": 65537,
      "n": "Register",
      "d": 705877,
      "h": 8590640469,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590640469)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295673173),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 705877,
      "h": 4295673173,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295673173)
  ],
  "h": 705877
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Models${separator}CommunityJobPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(705877)
        
        

        //--TRIMMABLE-BOUNDARY-START(443733)
        $asm.$cls(`$xvUV.LCCJCM.CommunityJobModelTypeDescriptorBuilder`, ($self) => class CommunityJobModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590378325)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590378325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xvUV.LCCJCM.CommunityJobModelTypeDescriptor()
                        const $t1 = $.$xvUV.LCCJCM.CommunityJobModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Job.Common.Models.CommunityJobModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $gcajMg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":443733,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xvUV.LCCJCM.CommunityJobModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590378325)
            
            //--TRIMMABLE-BOUNDARY-START(4295411029)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295411029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295411029)
            
            //--TRIMMABLE-BOUNDARY-START(4295411029)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295411029)
            
            static $h = 443733;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590378325),
    {
      "r": 65537,
      "n": "Register",
      "d": 443733,
      "h": 8590378325,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590378325)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295411029),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 443733,
      "h": 4295411029,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295411029)
  ],
  "h": 443733
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Models.CommunityJobModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Models${separator}CommunityJobModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(443733)
        
        

        //--TRIMMABLE-BOUNDARY-START(771413)
        $asm.$cls(`$xvUV.LCCJC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590706005)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590706005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$xvUV.LCCJCM.CommunityJobPostModel, 3840/*PostTypes.Job*/);
                $.$xvUV.LCCJC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$xvUV.LCCJC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$xvUV.LCCJC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590706005)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$xvUV.LCCJC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295738709)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295738709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295738709)
            
            //--TRIMMABLE-BOUNDARY-START(4295738709)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295738709)
            
            static $h = 771413;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590706005),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 771413,
      "h": 8590706005,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590706005)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295738709),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 771413,
      "h": 4295738709,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295738709)
  ],
  "h": 771413
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(771413)
        
        

        //--TRIMMABLE-BOUNDARY-START(968021)
        $asm.$cls(`$xvUV.LCCJCS$1.CommunityJobSettings`, ($self) => class CommunityJobSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4295935317)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295935317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295935317)
            
            //--TRIMMABLE-BOUNDARY-START(4295935317)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295935317)
            
            static $h = 968021;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295935317),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 968021,
      "h": 4295935317,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295935317)
  ],
  "h": 968021
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Settings.CommunityJobSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Settings${separator}CommunityJobSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(968021)
        
        

        //--TRIMMABLE-BOUNDARY-START(1230165)
        $asm.$cls(`$xvUV.LCCJCS$2.CommunityJobStates`, ($self) => class CommunityJobStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296197461)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296197461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296197461)
            
            //--TRIMMABLE-BOUNDARY-START(4296197461)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296197461)
            
            static $h = 1230165;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296197461),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1230165,
      "h": 4296197461,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296197461)
  ],
  "h": 1230165
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.States.CommunityJobStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}States${separator}CommunityJobStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1230165)
        
        

        //--TRIMMABLE-BOUNDARY-START(1099093)
        $asm.$cls(`$xvUV.LCCJCS$1.CommunityJobSettingsTypeDescriptor`, ($self) => class CommunityJobSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xvUV.LCCJCS$1.CommunityJobSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296066389)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296066389);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xvUV.LCCJCS$1.CommunityJobSettingsTypeDescriptor.GenerateProperties($.$xvUV.LCCJCS$1.CommunityJobSettings, this, factory);
                    }, $Grsall ??= {"r":65537,"n":"","d":1099093,"h":0,"f":17825794}), 0, "CommunityJobSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Job.Common\\Settings_CommunityJobSettings_LivingThing.Core.Community.Job.Common.Settings.CommunityJobSettingsTypeDescriptorBuilder.g.cs", "CommunityJobSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296066389)
            
            //--TRIMMABLE-BOUNDARY-START(12886000981)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886000981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886000981)
            
            //--TRIMMABLE-BOUNDARY-START(17180968277)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Job.Common.Settings.CommunityJobSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180968277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180968277)
            
            //--TRIMMABLE-BOUNDARY-START(8591033685)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Job.Common.Settings.CommunityJobSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591033685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xvUV.LCCJCS$1.CommunityJobSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xvUV.LCCJCS$1.CommunityJobSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$xvUV.LCCJCS$1.CommunityJobSettings)))
                {
                    /*var*/ let result = $.$xvUV.LCCJCS$1.CommunityJobSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xvUV.LCCJCS$1.CommunityJobSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xvUV.LCCJCS$1.CommunityJobSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$xvUV.LCCJCS$1.CommunityJobSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591033685)
            
            static $h = 1099093;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xvUV.LCCJCS$1.CommunityJobSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886000981),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1099093,
      "h": 12886000981,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886000981),
//--TRIMMABLE-BOUNDARY-START(17180968277),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 968021,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1099093,
      "h": 17180968277,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180968277),
//--TRIMMABLE-BOUNDARY-START(8591033685),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 968021,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1099093,
      "h": 8591033685,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591033685)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296066389),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1099093,
      "h": 4296066389,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296066389)
  ],
  "h": 1099093
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xvUV.LCCJCS$1.CommunityJobSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Settings.CommunityJobSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Settings${separator}CommunityJobSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1099093)
        
        

        //--TRIMMABLE-BOUNDARY-START(1361237)
        $asm.$cls(`$xvUV.LCCJCS$2.CommunityJobStatesTypeDescriptor`, ($self) => class CommunityJobStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xvUV.LCCJCS$2.CommunityJobStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296328533)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296328533);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xvUV.LCCJCS$2.CommunityJobStatesTypeDescriptor.GenerateProperties($.$xvUV.LCCJCS$2.CommunityJobStates, this, factory);
                    }, $rRBfNb ??= {"r":65537,"n":"","d":1361237,"h":0,"f":17825794}), 0, "CommunityJobStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Job.Common\\States_CommunityJobStates_LivingThing.Core.Community.Job.Common.States.CommunityJobStatesTypeDescriptorBuilder.g.cs", "CommunityJobStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296328533)
            
            //--TRIMMABLE-BOUNDARY-START(12886263125)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886263125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886263125)
            
            //--TRIMMABLE-BOUNDARY-START(17181230421)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Job.Common.States.CommunityJobStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181230421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181230421)
            
            //--TRIMMABLE-BOUNDARY-START(8591295829)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Job.Common.States.CommunityJobStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591295829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xvUV.LCCJCS$2.CommunityJobStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xvUV.LCCJCS$2.CommunityJobStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$xvUV.LCCJCS$2.CommunityJobStates)))
                {
                    /*var*/ let result = $.$xvUV.LCCJCS$2.CommunityJobStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xvUV.LCCJCS$2.CommunityJobStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xvUV.LCCJCS$2.CommunityJobStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$xvUV.LCCJCS$2.CommunityJobStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591295829)
            
            static $h = 1361237;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xvUV.LCCJCS$2.CommunityJobStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886263125),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1361237,
      "h": 12886263125,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886263125),
//--TRIMMABLE-BOUNDARY-START(17181230421),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1230165,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1361237,
      "h": 17181230421,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181230421),
//--TRIMMABLE-BOUNDARY-START(8591295829),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1230165,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1361237,
      "h": 8591295829,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591295829)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296328533),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1361237,
      "h": 4296328533,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296328533)
  ],
  "h": 1361237
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xvUV.LCCJCS$2.CommunityJobStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.States.CommunityJobStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}States${separator}CommunityJobStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1361237)
        
        

        //--TRIMMABLE-BOUNDARY-START(509269)
        $asm.$cls(`$xvUV.LCCJCM.CommunityJobPostModel`, ($self) => class CommunityJobPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180378453)
            /*PostTypes */ get Type()
            {
                return 3840/*PostTypes.Job*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180378453)
            
            //--TRIMMABLE-BOUNDARY-START(4295476565)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295476565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295476565)
            
            //--TRIMMABLE-BOUNDARY-START(4295476565)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295476565)
            
            static $h = 509269;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180378453),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885411157,
        "f": 50364417
      },
      "n": "Type",
      "d": 509269,
      "h": 17180378453,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180378453)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295476565),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 509269,
      "h": 4295476565,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295476565)
  ],
  "h": 509269
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Models${separator}CommunityJobPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(509269)
        
        

        //--TRIMMABLE-BOUNDARY-START(836949)
        $asm.$cls(`$xvUV.LCCJCS.IComunityJobRemoteService`, ($self) => class IComunityJobRemoteService
        {
            static $h = 836949;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 836949,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.IReadDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Services.IComunityJobRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Services${separator}IComunityJobRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(836949)
        
        

        //--TRIMMABLE-BOUNDARY-START(902485)
        $asm.$cls(`$xvUV.LCCJCS.IComunityJobRemoteService_Mocking`, ($self) => class IComunityJobRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295869781)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295869781);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295869781)
            
            //--TRIMMABLE-BOUNDARY-START(8590837077)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Job$Common$Models$CommunityJobPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590837077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$xvUV.LCCJCM.CommunityJobPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$xvUV.LCCJCM.CommunityJobPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590837077)
            
            //--TRIMMABLE-BOUNDARY-START(17180771669)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Job$Common$Models$CommunityJobPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180771669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$xvUV.LCCJCM.CommunityJobPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$xvUV.LCCJCM.CommunityJobPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180771669)
            
            //--TRIMMABLE-BOUNDARY-START(21475738965)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Job$Common$Models$CommunityJobPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475738965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$xvUV.LCCJCM.CommunityJobPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$xvUV.LCCJCM.CommunityJobPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475738965)
            
            //--TRIMMABLE-BOUNDARY-START(25770706261)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Job$Common$Models$CommunityJobPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770706261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$xvUV.LCCJCM.CommunityJobPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$xvUV.LCCJCM.CommunityJobPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770706261)
            
            //--TRIMMABLE-BOUNDARY-START(12885804373)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885804373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$xvUV.LCCJCM.CommunityJobPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885804373)
            
            static $h = 902485;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295869781),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 902485,
      "h": 4295869781,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295869781)
  ],
  "h": 902485
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$xvUV.LCCJCS.IComunityJobRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.IReadDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Services.IComunityJobRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Services${separator}IComunityJobRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(902485)
        
        

        //--TRIMMABLE-BOUNDARY-START(640341)
        $asm.$cls(`$xvUV.LCCJCM.CommunityJobPostModelTypeDescriptor`, ($self) => class CommunityJobPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xvUV.LCCJCM.CommunityJobPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295607637)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295607637);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xvUV.LCCJCM.CommunityJobPostModelTypeDescriptor.GenerateProperties($.$xvUV.LCCJCM.CommunityJobPostModel, this, factory);
                    }, $HTkJBj ??= {"r":65537,"n":"","d":640341,"h":0,"f":17825794}), 0, "CommunityJobPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Job.Common\\Models_CommunityJobPostModel_LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModelTypeDescriptorBuilder.g.cs", "CommunityJobPostModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295607637)
            
            //--TRIMMABLE-BOUNDARY-START(12885542229)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885542229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xvUV.LCCJCM.CommunityJobPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xvUV.LCCJCM.CommunityJobPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$xvUV.LCCJCM.CommunityJobPostModel)).Type);
                        }, $zQDGxc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":640341,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885542229)
            
            //--TRIMMABLE-BOUNDARY-START(17180509525)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180509525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180509525)
            
            //--TRIMMABLE-BOUNDARY-START(8590574933)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590574933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xvUV.LCCJCM.CommunityJobPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xvUV.LCCJCM.CommunityJobPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$xvUV.LCCJCM.CommunityJobPostModel)))
                {
                    /*var*/ let result = $.$xvUV.LCCJCM.CommunityJobPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xvUV.LCCJCM.CommunityJobPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xvUV.LCCJCM.CommunityJobPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$xvUV.LCCJCM.CommunityJobPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590574933)
            
            static $h = 640341;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xvUV.LCCJCM.CommunityJobPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885542229),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 640341,
      "h": 12885542229,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885542229),
//--TRIMMABLE-BOUNDARY-START(17180509525),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 509269,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 640341,
      "h": 17180509525,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180509525),
//--TRIMMABLE-BOUNDARY-START(8590574933),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 509269,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 640341,
      "h": 8590574933,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590574933)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295607637),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 640341,
      "h": 4295607637,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295607637)
  ],
  "h": 640341
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xvUV.LCCJCM.CommunityJobPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Models.CommunityJobPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Models${separator}CommunityJobPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(640341)
        
        

        //--TRIMMABLE-BOUNDARY-START(247125)
        $asm.$cls(`$xvUV.LCCJCM.CommunityJobModel`, ($self) => class CommunityJobModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$xvUV.LCCJCS$1.CommunityJobSettings, $.$xvUV.LCCJCS$2.CommunityJobStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295214421)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295214421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295214421)
            
            //--TRIMMABLE-BOUNDARY-START(4295214421)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295214421)
            
            static $h = 247125;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$xvUV.LCCJCS$1.CommunityJobSettings, $.$xvUV.LCCJCS$2.CommunityJobStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295214421),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 247125,
      "h": 4295214421,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295214421)
  ],
  "h": 247125
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Models.CommunityJobModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Models${separator}CommunityJobModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(247125)
        
        

        //--TRIMMABLE-BOUNDARY-START(378197)
        $asm.$cls(`$xvUV.LCCJCM.CommunityJobModelTypeDescriptor`, ($self) => class CommunityJobModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xvUV.LCCJCM.CommunityJobModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295345493)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295345493);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xvUV.LCCJCM.CommunityJobModelTypeDescriptor.GenerateProperties($.$xvUV.LCCJCM.CommunityJobModel, this, factory);
                    }, $wFbCUd ??= {"r":65537,"n":"","d":378197,"h":0,"f":17825794}), 0, "CommunityJobModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Job.Common\\Models_CommunityJobModel_LivingThing.Core.Community.Job.Common.Models.CommunityJobModelTypeDescriptorBuilder.g.cs", "CommunityJobModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295345493)
            
            //--TRIMMABLE-BOUNDARY-START(12885280085)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885280085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$xvUV.LCCJCS$1.CommunityJobSettings, $.$xvUV.LCCJCS$2.CommunityJobStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885280085)
            
            //--TRIMMABLE-BOUNDARY-START(17180247381)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Job.Common.Models.CommunityJobModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180247381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Job.Common.Settings.CommunityJobSettings, LivingThing.Core.Community.Job.Common.States.CommunityJobStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$xvUV.LCCJCS$1.CommunityJobSettings, $.$xvUV.LCCJCS$2.CommunityJobStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$xvUV.LCCJCS$1.CommunityJobSettings, $.$xvUV.LCCJCS$2.CommunityJobStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180247381)
            
            //--TRIMMABLE-BOUNDARY-START(8590312789)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Job.Common.Models.CommunityJobModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590312789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xvUV.LCCJCM.CommunityJobModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xvUV.LCCJCM.CommunityJobModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$xvUV.LCCJCM.CommunityJobModel)))
                {
                    /*var*/ let result = $.$xvUV.LCCJCM.CommunityJobModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xvUV.LCCJCM.CommunityJobModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xvUV.LCCJCM.CommunityJobModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$xvUV.LCCJCM.CommunityJobModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590312789)
            
            static $h = 378197;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xvUV.LCCJCM.CommunityJobModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885280085),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 378197,
      "h": 12885280085,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885280085),
//--TRIMMABLE-BOUNDARY-START(17180247381),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 247125,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 378197,
      "h": 17180247381,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180247381),
//--TRIMMABLE-BOUNDARY-START(8590312789),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 247125,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 378197,
      "h": 8590312789,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590312789)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295345493),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 378197,
      "h": 4295345493,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295345493)
  ],
  "h": 378197
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xvUV.LCCJCM.CommunityJobModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Job.Common.Models.CommunityJobModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Job${separator}Common${separator}Models${separator}CommunityJobModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(378197)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(50517)
