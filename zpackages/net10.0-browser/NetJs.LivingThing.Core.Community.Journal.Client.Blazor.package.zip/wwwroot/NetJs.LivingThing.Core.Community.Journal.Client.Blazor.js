
//--TRIMMABLE-BOUNDARY-START(37806)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $sUMr) {
    "use strict";
    let _;
    let $gqsTHe;
    let $guabUi;
    let $nbTLld;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Journal.Client.Blazor", 
    {
  "h": 37806,
  "f": "LivingThing.Core.Community.Journal.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Journal.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Journal.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(168878)
        $asm.$cls(`$GETr.LCCJC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295136174)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295136174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$GETr.LCCJC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295136174)
            
            static $h = 168878;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295136174),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 168878,
      "h": 4295136174,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295136174)
  ],
  "h": 168878
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(168878)
        
        

        //--TRIMMABLE-BOUNDARY-START(234414)
        $asm.$cls(`$GETr.LCCJC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180103598)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$GETr.LCCJCP.CommunityJournalApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$GETr.LCCJCP.CommunityJournalApp().$ctor$6();
                    }, $gqsTHe ??= {"r":2752627,"n":"","d":234414,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180103598)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295201710)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295201710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295201710)
            
            //--TRIMMABLE-BOUNDARY-START(4295201710)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295201710)
            
            static $h = 234414;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180103598),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885136302,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 234414,
      "h": 17180103598,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180103598)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295201710),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 234414,
      "h": 4295201710,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295201710)
  ],
  "h": 234414
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(234414)
        
        

        //--TRIMMABLE-BOUNDARY-START(365486)
        $asm.$cls(`$GETr.LCCJC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590300078)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590300078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$GETr.LCCJCS.CommunityJournalService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$sUMr.LCCJCM.CommunityJournalPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$GETr.LCCJCS.CommunityJournalApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GETr.LCCJCS.CommunityJournalApplication, x);
                }, $guabUi ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":365486,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GETr.LCCJCS.CommunityJournalApplication, x);
                }, $nbTLld ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":365486,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$GETr.LCCJCS.CommunityJournalFeedProvider, services);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$sUMr.LCCJCM.CommunityJournalPostModel, services, null);
                $.$GETr.LCCJC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590300078)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$GETr.LCCJC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295332782)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295332782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295332782)
            
            //--TRIMMABLE-BOUNDARY-START(4295332782)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295332782)
            
            static $h = 365486;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590300078),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 365486,
      "h": 8590300078,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590300078)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295332782),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 365486,
      "h": 4295332782,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295332782)
  ],
  "h": 365486
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(365486)
        
        

        //--TRIMMABLE-BOUNDARY-START(627630)
        $asm.$cls(`$GETr.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295594926)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295594926);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295594926)
            
            //--TRIMMABLE-BOUNDARY-START(4295594926)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295594926)
            
            static $h = 627630;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295594926),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 627630,
      "h": 4295594926,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295594926)
  ],
  "h": 627630
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(627630)
        
        

        //--TRIMMABLE-BOUNDARY-START(693166)
        $asm.$cls(`$GETr.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295660462)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295660462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295660462)
            
            //--TRIMMABLE-BOUNDARY-START(4295660462)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295660462)
            
            static $h = 693166;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295660462),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 693166,
      "h": 4295660462,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295660462)
  ],
  "h": 693166,
  "a": [
    {
      "t": 627630,
      "c": 4295594926
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(693166)
        
        

        //--TRIMMABLE-BOUNDARY-START(103342)
        $asm.$cls(`$GETr.LCCJC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590037934)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590037934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590037934)
            
            //--TRIMMABLE-BOUNDARY-START(4295070638)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295070638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295070638)
            
            //--TRIMMABLE-BOUNDARY-START(4295070638)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295070638)
            
            static $h = 103342;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590037934),
    {
      "r": 65537,
      "n": "Execute",
      "d": 103342,
      "h": 8590037934,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590037934)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295070638),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 103342,
      "h": 4295070638,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295070638)
  ],
  "h": 103342
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(103342)
        
        

        //--TRIMMABLE-BOUNDARY-START(496558)
        $asm.$cls(`$GETr.LCCJCS.CommunityJournalFeedProvider`, ($self) => class CommunityJournalFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$sUMr.LCCJCM.CommunityJournalPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295463854)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295463854);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295463854)
            
            //--TRIMMABLE-BOUNDARY-START(8590431150)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityJournalPostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590431150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`created an journal ${$.$strNN(model.Title)}`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590431150)
            
            static $h = 496558;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$sUMr.LCCJCM.CommunityJournalPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590431150),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 775700
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 496558,
      "h": 8590431150,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590431150)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295463854),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 496558,
      "h": 4295463854,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295463854)
  ],
  "h": 496558
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Client.Services.CommunityJournalFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Client${separator}Services${separator}CommunityJournalFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(496558)
        
        

        //--TRIMMABLE-BOUNDARY-START(431022)
        $asm.$cls(`$GETr.LCCJCS.CommunityJournalApplication`, ($self) => class CommunityJournalApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(17180300206)
            $ctor$5(/*CommunityJournalService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180300206);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180300206)
            
            //--TRIMMABLE-BOUNDARY-START(150324286382)
            /*string */ get Name()
            {
                return "Journal";
            }
            //--TRIMMABLE-BOUNDARY-END(150324286382)
            
            //--TRIMMABLE-BOUNDARY-START(176094090158)
            /*string */ get Title()
            {
                return "Journal";
            }
            //--TRIMMABLE-BOUNDARY-END(176094090158)
            
            //--TRIMMABLE-BOUNDARY-START(25770234798)
            /*string */ get Description()
            {
                return "Zoey journal is a digital diary that enables you to record daily event online. Your diary is private by default, but you can choose to publicise it to allow others read and journey with you.";
            }
            //--TRIMMABLE-BOUNDARY-END(25770234798)
            
            //--TRIMMABLE-BOUNDARY-START(146029319086)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-newspaper-plus"/*MaterialDesignIconNames.NewspaperPlus*/);
            }
            //--TRIMMABLE-BOUNDARY-END(146029319086)
            
            //--TRIMMABLE-BOUNDARY-START(171799122862)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#894578";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(171799122862)
            
            //--TRIMMABLE-BOUNDARY-START(34360169390)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(34360169390)
            
            //--TRIMMABLE-BOUNDARY-START(21475267502)
            /*Type? */ get ApplicationViewType()
            {
                return $.$GETr.LCCJCP.CommunityJournalApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(21475267502)
            
            //--TRIMMABLE-BOUNDARY-START(141734351790)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734351790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$GETr.LCCJCP.CommunityJournalApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(141734351790)
            
            //--TRIMMABLE-BOUNDARY-START(30065202094)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065202094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(30065202094)
            
            //--TRIMMABLE-BOUNDARY-START(158914220974)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914220974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(158914220974)
            
            //--TRIMMABLE-BOUNDARY-START(154619253678)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(154619253678)
            
            //--TRIMMABLE-BOUNDARY-START(4295398318)
            /*CommunityJournalService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295398318)
            
            //--TRIMMABLE-BOUNDARY-START(163209188270)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(163209188270)
            
            //--TRIMMABLE-BOUNDARY-START(167504155566)
            /*IEnumerable<IApplicationSubService>?*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(167504155566)
            
            //--TRIMMABLE-BOUNDARY-START(180389057454)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(7680/*PostTypes.Journal*/, 7683/*PostTypes.JournalEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(180389057454)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 431022;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(150324286382),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899776942,
        "f": 50364417
      },
      "n": "Name",
      "d": 431022,
      "h": 150324286382,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324286382),
//--TRIMMABLE-BOUNDARY-START(176094090158),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849449902,
        "f": 50364417
      },
      "n": "Title",
      "d": 431022,
      "h": 176094090158,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176094090158),
//--TRIMMABLE-BOUNDARY-START(25770234798),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129973166,
        "f": 50364417
      },
      "n": "Description",
      "d": 431022,
      "h": 25770234798,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770234798),
//--TRIMMABLE-BOUNDARY-START(146029319086),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309842350,
        "f": 50364417
      },
      "n": "Icon",
      "d": 431022,
      "h": 146029319086,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029319086),
//--TRIMMABLE-BOUNDARY-START(171799122862),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259515310,
        "f": 50364417
      },
      "n": "Theme",
      "d": 431022,
      "h": 171799122862,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(171799122862),
//--TRIMMABLE-BOUNDARY-START(34360169390),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719907758,
        "f": 50364417
      },
      "n": "Features",
      "d": 431022,
      "h": 34360169390,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360169390),
//--TRIMMABLE-BOUNDARY-START(21475267502),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540038574,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 431022,
      "h": 21475267502,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475267502),
//--TRIMMABLE-BOUNDARY-START(154619253678),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489711534,
        "f": 50364417
      },
      "n": "Order",
      "d": 431022,
      "h": 154619253678,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619253678),
//--TRIMMABLE-BOUNDARY-START(4295398318),
    {
      "p": 562094,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950103982,
        "f": 50331650
      },
      "n": "_Service",
      "d": 431022,
      "h": 4295398318,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295398318),
//--TRIMMABLE-BOUNDARY-START(163209188270),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079646126,
        "f": 50364417
      },
      "n": "Service",
      "d": 431022,
      "h": 163209188270,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209188270),
//--TRIMMABLE-BOUNDARY-START(167504155566),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669580718,
        "f": 50364417
      },
      "n": "Services",
      "d": 431022,
      "h": 167504155566,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(167504155566),
//--TRIMMABLE-BOUNDARY-START(180389057454),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439384494,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 431022,
      "h": 180389057454,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389057454)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(141734351790),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 431022,
      "h": 141734351790,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(141734351790),
//--TRIMMABLE-BOUNDARY-START(30065202094),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 431022,
      "h": 30065202094,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065202094),
//--TRIMMABLE-BOUNDARY-START(158914220974),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 431022,
      "h": 158914220974,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914220974)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180300206),
    {
      "p": [
        {
          "n": "service",
          "p": 562094
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 431022,
      "h": 17180300206,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180300206)
  ],
  "h": 431022
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$sUMr.LCCJCM.CommunityJournalPostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Client.Services.CommunityJournalApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Client${separator}Services${separator}CommunityJournalApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(431022)
        
        

        //--TRIMMABLE-BOUNDARY-START(299950)
        $asm.$cls(`$GETr.LCCJCP.CommunityJournalApp`, ($self) => class CommunityJournalApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel, $.$sUMr.LCCJCM.CommunityJournalPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$sUMr.LCCJCM.CommunityJournalUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(55834874798)
            /*CommunityJournalService*/ JournalService = null;
            //--TRIMMABLE-BOUNDARY-END(55834874798)
            
            //--TRIMMABLE-BOUNDARY-START(51539907502)
            /*CommunityJournalApplication*/ JournalApplication = null;
            //--TRIMMABLE-BOUNDARY-END(51539907502)
            
            //--TRIMMABLE-BOUNDARY-START(17180169134)
            /*ICommunityClientApplication */ get Application()
            {
                return this.JournalApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(17180169134)
            
            //--TRIMMABLE-BOUNDARY-START(60129842094)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129842094);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.JournalService.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60129842094)
            
            //--TRIMMABLE-BOUNDARY-START(21475136430)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475136430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
            }
            //--TRIMMABLE-BOUNDARY-END(21475136430)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885201838)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885201838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885201838)
            
            //--TRIMMABLE-BOUNDARY-START(12885201838)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12885201838)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55834874798)
                this.JournalService = null;
                //--TRIMMABLE-BOUNDARY-END(55834874798)
                
                //--TRIMMABLE-BOUNDARY-START(51539907502)
                this.JournalApplication = null;
                //--TRIMMABLE-BOUNDARY-END(51539907502)
                
            }
            static $h = 299950;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel, $.$sUMr.LCCJCM.CommunityJournalPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$sUMr.LCCJCM.CommunityJournalUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834874798),
    {
      "p": 562094,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244940206,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309711278,
        "f": 83886081
      },
      "n": "JournalService",
      "d": 299950,
      "h": 55834874798,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834874798),
//--TRIMMABLE-BOUNDARY-START(51539907502),
    {
      "p": 431022,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655005614,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719776686,
        "f": 83886081
      },
      "n": "JournalApplication",
      "d": 299950,
      "h": 51539907502,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51539907502),
//--TRIMMABLE-BOUNDARY-START(17180169134),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065071022,
        "f": 50364420
      },
      "n": "Application",
      "d": 299950,
      "h": 17180169134,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(17180169134)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60129842094),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 299950,
      "h": 60129842094,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(60129842094),
//--TRIMMABLE-BOUNDARY-START(21475136430),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 299950,
      "h": 21475136430,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475136430)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885201838),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 299950,
      "h": 12885201838,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885201838)
  ],
  "h": 299950
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Client.Pages.CommunityJournalApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Client${separator}Pages${separator}CommunityJournalApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(299950)
        
        

        //--TRIMMABLE-BOUNDARY-START(562094)
        $asm.$cls(`$GETr.LCCJCS.CommunityJournalService`, ($self) => class CommunityJournalService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$sUMr.LCCJCM.CommunityJournalPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295529390)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295529390);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295529390)
            
            static $h = 562094;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$sUMr.LCCJCM.CommunityJournalPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295529390),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 562094,
      "h": 4295529390,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295529390)
  ],
  "h": 562094
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$sUMr.LCCJCM.CommunityJournalPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$sUMr.LCCJCM.CommunityJournalPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Client.Services.CommunityJournalService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Client${separator}Services${separator}CommunityJournalService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(562094)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Journal.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(37806)
