
//--TRIMMABLE-BOUNDARY-START(54804)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $ZApmYi;
    let $KdWhof;
    let $bIEZaj;
    let $mPvfNc;
    let $XITVRj;
    let $TKtQRh;
    let $dDkAWe;
    let $DQiVFb;
    let $jFTMrg;
    let $pieANf;
    let $spSyYg;
    let $UoGTrd;
    let $Enxaqf;
    let $zvWeqa;
    let $PuOOcl;
    let $sDXJxk;
    let $CxxVef;
    let $mJQljl;
    let $eJalLg;
    let $dfIyKj;
    let $yvdcbd;
    let $TLIZOi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Journal.Common", 
    {
  "h": 54804,
  "f": "LivingThing.Core.Community.Journal.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Journal.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Journal.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1955348)
        $asm.$cls(`$sUMr.LCCJC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296922644)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296922644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sUMr.LCCJCM.CommunityJournalCategoryModelTypeDescriptorBuilder.Register();
                $.$sUMr.LCCJCM.CommunityJournalModelTypeDescriptorBuilder.Register();
                $.$sUMr.LCCJCM.CommunityJournalPostModelTypeDescriptorBuilder.Register();
                $.$sUMr.LCCJCS$1.CommunityJournalSettingsTypeDescriptorBuilder.Register();
                $.$sUMr.LCCJCS$2.CommunityJournalStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296922644)
            
            static $h = 1955348;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296922644),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1955348,
      "h": 4296922644,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296922644)
  ],
  "h": 1955348
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1955348)
        
        

        //--TRIMMABLE-BOUNDARY-START(1496596)
        $asm.$cls(`$sUMr.LCCJCS$1.CommunityJournalSettingsCustomAttributesProvider`, ($self) => class CommunityJournalSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296463892)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296463892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296463892)
            
            static $h = 1496596;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296463892),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1496596,
      "h": 4296463892,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296463892)
  ],
  "h": 1496596
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Settings.CommunityJournalSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Settings${separator}CommunityJournalSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1496596)
        
        

        //--TRIMMABLE-BOUNDARY-START(1758740)
        $asm.$cls(`$sUMr.LCCJCS$2.CommunityJournalStatesCustomAttributesProvider`, ($self) => class CommunityJournalStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296726036)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296726036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296726036)
            
            static $h = 1758740;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296726036),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1758740,
      "h": 4296726036,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296726036)
  ],
  "h": 1758740
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.States.CommunityJournalStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}States${separator}CommunityJournalStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1758740)
        
        

        //--TRIMMABLE-BOUNDARY-START(120340)
        $asm.$cls(`$sUMr.LCCJC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295087636)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295087636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$sUMr.LCCJCM.CommunityJournalCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$sUMr.LCCJCM.CommunityJournalCategoryModelCustomAttributesProvider, $.$sUMr.LCCJCM.CommunityJournalCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$sUMr.LCCJCM.CommunityJournalModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$sUMr.LCCJCM.CommunityJournalModelCustomAttributesProvider, $.$sUMr.LCCJCM.CommunityJournalModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$sUMr.LCCJCM.CommunityJournalPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$sUMr.LCCJCM.CommunityJournalPostModelCustomAttributesProvider, $.$sUMr.LCCJCM.CommunityJournalPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$sUMr.LCCJCS$1.CommunityJournalSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$sUMr.LCCJCS$1.CommunityJournalSettingsCustomAttributesProvider, $.$sUMr.LCCJCS$1.CommunityJournalSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$sUMr.LCCJCS$2.CommunityJournalStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$sUMr.LCCJCS$2.CommunityJournalStatesCustomAttributesProvider, $.$sUMr.LCCJCS$2.CommunityJournalStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295087636)
            
            static $h = 120340;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295087636),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 120340,
      "h": 4295087636,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295087636)
  ],
  "h": 120340
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(120340)
        
        

        //--TRIMMABLE-BOUNDARY-START(579092)
        $asm.$cls(`$sUMr.LCCJCM.CommunityJournalModelCustomAttributesProvider`, ($self) => class CommunityJournalModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295546388)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295546388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$sUMr.LCCJCS$1.CommunityJournalSettings, $.$sUMr.LCCJCS$2.CommunityJournalStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295546388)
            
            static $h = 579092;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295546388),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 579092,
      "h": 4295546388,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295546388)
  ],
  "h": 579092
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Models.CommunityJournalModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Models${separator}CommunityJournalModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(579092)
        
        

        //--TRIMMABLE-BOUNDARY-START(841236)
        $asm.$cls(`$sUMr.LCCJCM.CommunityJournalPostModelCustomAttributesProvider`, ($self) => class CommunityJournalPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295808532)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295808532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295808532)
            
            static $h = 841236;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295808532),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 841236,
      "h": 4295808532,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295808532)
  ],
  "h": 841236
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Models${separator}CommunityJournalPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(841236)
        
        

        //--TRIMMABLE-BOUNDARY-START(1627668)
        $asm.$cls(`$sUMr.LCCJCS$1.CommunityJournalSettingsTypeDescriptorBuilder`, ($self) => class CommunityJournalSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591562260)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591562260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$sUMr.LCCJCS$1.CommunityJournalSettingsTypeDescriptor()
                        const $t1 = $.$sUMr.LCCJCS$1.CommunityJournalSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Journal.Common.Settings.CommunityJournalSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $bIEZaj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1627668,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$sUMr.LCCJCS$1.CommunityJournalSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591562260)
            
            //--TRIMMABLE-BOUNDARY-START(4296594964)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296594964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296594964)
            
            //--TRIMMABLE-BOUNDARY-START(4296594964)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296594964)
            
            static $h = 1627668;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591562260),
    {
      "r": 65537,
      "n": "Register",
      "d": 1627668,
      "h": 8591562260,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591562260)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296594964),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1627668,
      "h": 4296594964,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296594964)
  ],
  "h": 1627668
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Settings.CommunityJournalSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Settings${separator}CommunityJournalSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1627668)
        
        

        //--TRIMMABLE-BOUNDARY-START(1889812)
        $asm.$cls(`$sUMr.LCCJCS$2.CommunityJournalStatesTypeDescriptorBuilder`, ($self) => class CommunityJournalStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591824404)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591824404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$sUMr.LCCJCS$2.CommunityJournalStatesTypeDescriptor()
                        const $t1 = $.$sUMr.LCCJCS$2.CommunityJournalStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Journal.Common.States.CommunityJournalStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ZApmYi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1889812,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$sUMr.LCCJCS$2.CommunityJournalStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591824404)
            
            //--TRIMMABLE-BOUNDARY-START(4296857108)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296857108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296857108)
            
            //--TRIMMABLE-BOUNDARY-START(4296857108)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296857108)
            
            static $h = 1889812;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591824404),
    {
      "r": 65537,
      "n": "Register",
      "d": 1889812,
      "h": 8591824404,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591824404)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296857108),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1889812,
      "h": 4296857108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296857108)
  ],
  "h": 1889812
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.States.CommunityJournalStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}States${separator}CommunityJournalStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1889812)
        
        

        //--TRIMMABLE-BOUNDARY-START(448020)
        $asm.$cls(`$sUMr.LCCJCM.CommunityJournalCategoryModelTypeDescriptorBuilder`, ($self) => class CommunityJournalCategoryModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590382612)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590382612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$sUMr.LCCJCM.CommunityJournalCategoryModelTypeDescriptor()
                        const $t1 = $.$sUMr.LCCJCM.CommunityJournalCategoryModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Journal.Common.Models.CommunityJournalCategoryModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CxxVef ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":448020,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$sUMr.LCCJCM.CommunityJournalCategoryModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590382612)
            
            //--TRIMMABLE-BOUNDARY-START(4295415316)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295415316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295415316)
            
            //--TRIMMABLE-BOUNDARY-START(4295415316)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295415316)
            
            static $h = 448020;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590382612),
    {
      "r": 65537,
      "n": "Register",
      "d": 448020,
      "h": 8590382612,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590382612)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295415316),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 448020,
      "h": 4295415316,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295415316)
  ],
  "h": 448020
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Models.CommunityJournalCategoryModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Models${separator}CommunityJournalCategoryModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(448020)
        
        

        //--TRIMMABLE-BOUNDARY-START(972308)
        $asm.$cls(`$sUMr.LCCJCM.CommunityJournalPostModelTypeDescriptorBuilder`, ($self) => class CommunityJournalPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590906900)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590906900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$sUMr.LCCJCM.CommunityJournalPostModelTypeDescriptor()
                        const $t1 = $.$sUMr.LCCJCM.CommunityJournalPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dfIyKj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":972308,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$sUMr.LCCJCM.CommunityJournalPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590906900)
            
            //--TRIMMABLE-BOUNDARY-START(4295939604)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295939604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295939604)
            
            //--TRIMMABLE-BOUNDARY-START(4295939604)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295939604)
            
            static $h = 972308;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590906900),
    {
      "r": 65537,
      "n": "Register",
      "d": 972308,
      "h": 8590906900,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590906900)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295939604),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 972308,
      "h": 4295939604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295939604)
  ],
  "h": 972308
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Models${separator}CommunityJournalPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(972308)
        
        

        //--TRIMMABLE-BOUNDARY-START(316948)
        $asm.$cls(`$sUMr.LCCJCM.CommunityJournalCategoryModelCustomAttributesProvider`, ($self) => class CommunityJournalCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295284244)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295284244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel, $.$sUMr.LCCJCM.CommunityJournalPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295284244)
            
            static $h = 316948;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295284244),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 316948,
      "h": 4295284244,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295284244)
  ],
  "h": 316948
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Models.CommunityJournalCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Models${separator}CommunityJournalCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(316948)
        
        

        //--TRIMMABLE-BOUNDARY-START(710164)
        $asm.$cls(`$sUMr.LCCJCM.CommunityJournalModelTypeDescriptorBuilder`, ($self) => class CommunityJournalModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590644756)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590644756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$sUMr.LCCJCM.CommunityJournalModelTypeDescriptor()
                        const $t1 = $.$sUMr.LCCJCM.CommunityJournalModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Journal.Common.Models.CommunityJournalModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XITVRj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":710164,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$sUMr.LCCJCM.CommunityJournalModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590644756)
            
            //--TRIMMABLE-BOUNDARY-START(4295677460)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295677460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295677460)
            
            //--TRIMMABLE-BOUNDARY-START(4295677460)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295677460)
            
            static $h = 710164;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590644756),
    {
      "r": 65537,
      "n": "Register",
      "d": 710164,
      "h": 8590644756,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590644756)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295677460),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 710164,
      "h": 4295677460,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295677460)
  ],
  "h": 710164
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Models.CommunityJournalModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Models${separator}CommunityJournalModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(710164)
        
        

        //--TRIMMABLE-BOUNDARY-START(185876)
        $asm.$cls(`$sUMr.LCCJC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295153172)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295153172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$sUMr.LCCJCS.ICommunityJournalFeedRemoteService, $.$sUMr.LCCJCS.ICommunityJournalFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$sUMr.LCCJCS.ICommunityJournalFeedRemoteService_Mocking().$ctor$3(impl);
                }, $dDkAWe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":185876,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$sUMr.LCCJCS.ICommunityJournalFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$sUMr.LCCJCS.ICommunityJournalFeedRemoteService_Mocking().$ctor$3(impl);
                }, $DQiVFb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":185876,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$sUMr.LCCJCS.IComunityJournalRemoteService, $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking().$ctor$3(impl);
                }, $jFTMrg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":185876,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking().$ctor$3(impl);
                }, $pieANf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":185876,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking().$ctor$3(impl);
                }, $spSyYg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":185876,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking().$ctor$3(impl);
                }, $UoGTrd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":185876,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking().$ctor$3(impl);
                }, $Enxaqf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":185876,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking().$ctor$3(impl);
                }, $zvWeqa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":185876,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking().$ctor$3(impl);
                }, $PuOOcl ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":185876,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking().$ctor$3(impl);
                }, $sDXJxk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":185876,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295153172)
            
            static $h = 185876;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295153172),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 185876,
      "h": 4295153172,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295153172)
  ],
  "h": 185876
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(185876)
        
        

        //--TRIMMABLE-BOUNDARY-START(1103380)
        $asm.$cls(`$sUMr.LCCJC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591037972)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591037972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$sUMr.LCCJCM.CommunityJournalCategoryModel, 7681/*PostTypes.JournalCategory*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$sUMr.LCCJCM.CommunityJournalPostModel, 7682/*PostTypes.JournalPost*/);
                $.$sUMr.LCCJC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$sUMr.LCCJC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$sUMr.LCCJC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591037972)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sUMr.LCCJC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296070676)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296070676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296070676)
            
            //--TRIMMABLE-BOUNDARY-START(4296070676)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296070676)
            
            static $h = 1103380;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591037972),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1103380,
      "h": 8591037972,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591037972)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296070676),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1103380,
      "h": 4296070676,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296070676)
  ],
  "h": 1103380
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1103380)
        
        

        //--TRIMMABLE-BOUNDARY-START(1037844)
        $asm.$cls(`$sUMr.LCCJCM.CommunityJournalUserPreference`, ($self) => class CommunityJournalUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4296005140)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296005140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296005140)
            
            //--TRIMMABLE-BOUNDARY-START(4296005140)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296005140)
            
            static $h = 1037844;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296005140),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1037844,
      "h": 4296005140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296005140)
  ],
  "h": 1037844
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Models.CommunityJournalUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Models${separator}CommunityJournalUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1037844)
        
        

        //--TRIMMABLE-BOUNDARY-START(1693204)
        $asm.$cls(`$sUMr.LCCJCS$2.CommunityJournalStates`, ($self) => class CommunityJournalStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296660500)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296660500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296660500)
            
            //--TRIMMABLE-BOUNDARY-START(4296660500)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296660500)
            
            static $h = 1693204;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296660500),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1693204,
      "h": 4296660500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296660500)
  ],
  "h": 1693204
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.States.CommunityJournalStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}States${separator}CommunityJournalStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1693204)
        
        

        //--TRIMMABLE-BOUNDARY-START(1431060)
        $asm.$cls(`$sUMr.LCCJCS$1.CommunityJournalSettings`, ($self) => class CommunityJournalSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296398356)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296398356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296398356)
            
            //--TRIMMABLE-BOUNDARY-START(4296398356)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296398356)
            
            static $h = 1431060;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296398356),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1431060,
      "h": 4296398356,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296398356)
  ],
  "h": 1431060
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Settings.CommunityJournalSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Settings${separator}CommunityJournalSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1431060)
        
        

        //--TRIMMABLE-BOUNDARY-START(1824276)
        $asm.$cls(`$sUMr.LCCJCS$2.CommunityJournalStatesTypeDescriptor`, ($self) => class CommunityJournalStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$sUMr.LCCJCS$2.CommunityJournalStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296791572)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296791572);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$sUMr.LCCJCS$2.CommunityJournalStatesTypeDescriptor.GenerateProperties($.$sUMr.LCCJCS$2.CommunityJournalStates, this, factory);
                    }, $KdWhof ??= {"r":65537,"n":"","d":1824276,"h":0,"f":17825794}), 0, "CommunityJournalStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Journal.Common\\States_CommunityJournalStates_LivingThing.Core.Community.Journal.Common.States.CommunityJournalStatesTypeDescriptorBuilder.g.cs", "CommunityJournalStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296791572)
            
            //--TRIMMABLE-BOUNDARY-START(12886726164)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886726164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886726164)
            
            //--TRIMMABLE-BOUNDARY-START(17181693460)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Journal.Common.States.CommunityJournalStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181693460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181693460)
            
            //--TRIMMABLE-BOUNDARY-START(8591758868)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Journal.Common.States.CommunityJournalStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591758868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$sUMr.LCCJCS$2.CommunityJournalStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$sUMr.LCCJCS$2.CommunityJournalStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCS$2.CommunityJournalStates)))
                {
                    /*var*/ let result = $.$sUMr.LCCJCS$2.CommunityJournalStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCS$2.CommunityJournalStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$sUMr.LCCJCS$2.CommunityJournalStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCS$2.CommunityJournalStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591758868)
            
            static $h = 1824276;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$sUMr.LCCJCS$2.CommunityJournalStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886726164),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1824276,
      "h": 12886726164,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886726164),
//--TRIMMABLE-BOUNDARY-START(17181693460),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1693204,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1824276,
      "h": 17181693460,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181693460),
//--TRIMMABLE-BOUNDARY-START(8591758868),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1693204,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1824276,
      "h": 8591758868,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591758868)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296791572),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1824276,
      "h": 4296791572,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296791572)
  ],
  "h": 1824276
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$sUMr.LCCJCS$2.CommunityJournalStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.States.CommunityJournalStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}States${separator}CommunityJournalStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1824276)
        
        

        //--TRIMMABLE-BOUNDARY-START(1562132)
        $asm.$cls(`$sUMr.LCCJCS$1.CommunityJournalSettingsTypeDescriptor`, ($self) => class CommunityJournalSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$sUMr.LCCJCS$1.CommunityJournalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296529428)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296529428);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$sUMr.LCCJCS$1.CommunityJournalSettingsTypeDescriptor.GenerateProperties($.$sUMr.LCCJCS$1.CommunityJournalSettings, this, factory);
                    }, $mPvfNc ??= {"r":65537,"n":"","d":1562132,"h":0,"f":17825794}), 0, "CommunityJournalSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Journal.Common\\Settings_CommunityJournalSettings_LivingThing.Core.Community.Journal.Common.Settings.CommunityJournalSettingsTypeDescriptorBuilder.g.cs", "CommunityJournalSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296529428)
            
            //--TRIMMABLE-BOUNDARY-START(12886464020)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886464020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886464020)
            
            //--TRIMMABLE-BOUNDARY-START(17181431316)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Journal.Common.Settings.CommunityJournalSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181431316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181431316)
            
            //--TRIMMABLE-BOUNDARY-START(8591496724)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Journal.Common.Settings.CommunityJournalSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591496724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$sUMr.LCCJCS$1.CommunityJournalSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$sUMr.LCCJCS$1.CommunityJournalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCS$1.CommunityJournalSettings)))
                {
                    /*var*/ let result = $.$sUMr.LCCJCS$1.CommunityJournalSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCS$1.CommunityJournalSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$sUMr.LCCJCS$1.CommunityJournalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCS$1.CommunityJournalSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591496724)
            
            static $h = 1562132;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$sUMr.LCCJCS$1.CommunityJournalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886464020),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1562132,
      "h": 12886464020,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886464020),
//--TRIMMABLE-BOUNDARY-START(17181431316),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1431060,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1562132,
      "h": 17181431316,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181431316),
//--TRIMMABLE-BOUNDARY-START(8591496724),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1431060,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1562132,
      "h": 8591496724,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591496724)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296529428),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1562132,
      "h": 4296529428,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296529428)
  ],
  "h": 1562132
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$sUMr.LCCJCS$1.CommunityJournalSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Settings.CommunityJournalSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Settings${separator}CommunityJournalSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1562132)
        
        

        $asm.$typeProxy("$sUMr.LCCJCM.CommunityJournalCategoryModel", "$sUMr.LivingThing.Core.Community.Journal.Common.Models.CommunityJournalCategoryModel");
        //--TRIMMABLE-BOUNDARY-START(775700)
        $asm.$cls(`$sUMr.LCCJCM.CommunityJournalPostModel`, ($self) => class CommunityJournalPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295742996)
            $ctor$6()
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295742996);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.PostFlags |= 8n;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295742996)
            
            //--TRIMMABLE-BOUNDARY-START(17180644884)
            /*PostTypes */ get Type()
            {
                return 7682/*PostTypes.JournalPost*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180644884)
            
            //--TRIMMABLE-BOUNDARY-START(4295742996)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295742996)
            
            static $h = 775700;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180644884),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885677588,
        "f": 50364417
      },
      "n": "Type",
      "d": 775700,
      "h": 17180644884,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180644884)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295742996),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 775700,
      "h": 4295742996,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295742996)
  ],
  "h": 775700
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Models${separator}CommunityJournalPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(775700)
        
        

        //--TRIMMABLE-BOUNDARY-START(251412)
        $asm.$cls(`$sUMr.LCCJCM.CommunityJournalCategoryModel`, ($self) => class CommunityJournalCategoryModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$sUMr.LCCJCM.CommunityJournalPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180120596)
            /*PostTypes */ get Type()
            {
                return 7681/*PostTypes.JournalCategory*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180120596)
            
            //--TRIMMABLE-BOUNDARY-START(4295218708)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295218708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295218708)
            
            //--TRIMMABLE-BOUNDARY-START(4295218708)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295218708)
            
            static $h = 251412;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel, $.$sUMr.LCCJCM.CommunityJournalPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180120596),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885153300,
        "f": 50364417
      },
      "n": "Type",
      "d": 251412,
      "h": 17180120596,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180120596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295218708),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 251412,
      "h": 4295218708,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295218708)
  ],
  "h": 251412
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Models.CommunityJournalCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Models${separator}CommunityJournalCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(251412)
        
        

        //--TRIMMABLE-BOUNDARY-START(1168916)
        $asm.$cls(`$sUMr.LCCJCS.ICommunityJournalFeedRemoteService`, ($self) => class ICommunityJournalFeedRemoteService
        {
            static $h = 1168916;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1168916,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Services.ICommunityJournalFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Services${separator}ICommunityJournalFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1168916)
        
        

        //--TRIMMABLE-BOUNDARY-START(1299988)
        $asm.$cls(`$sUMr.LCCJCS.IComunityJournalRemoteService`, ($self) => class IComunityJournalRemoteService
        {
            static $h = 1299988;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1299988,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.IReadDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Services.IComunityJournalRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Services${separator}IComunityJournalRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1299988)
        
        

        //--TRIMMABLE-BOUNDARY-START(1234452)
        $asm.$cls(`$sUMr.LCCJCS.ICommunityJournalFeedRemoteService_Mocking`, ($self) => class ICommunityJournalFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296201748)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296201748);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296201748)
            
            //--TRIMMABLE-BOUNDARY-START(8591169044)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Journal$Common$Models$CommunityJournalPostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591169044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$sUMr.LCCJCM.CommunityJournalPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$sUMr.LCCJCM.CommunityJournalPostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591169044)
            
            static $h = 1234452;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296201748),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1234452,
      "h": 4296201748,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296201748)
  ],
  "h": 1234452
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$sUMr.LCCJCS.ICommunityJournalFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Services.ICommunityJournalFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Services${separator}ICommunityJournalFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1234452)
        
        

        //--TRIMMABLE-BOUNDARY-START(1365524)
        $asm.$cls(`$sUMr.LCCJCS.IComunityJournalRemoteService_Mocking`, ($self) => class IComunityJournalRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296332820)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296332820);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296332820)
            
            //--TRIMMABLE-BOUNDARY-START(8591300116)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Journal$Common$Models$CommunityJournalPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591300116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$sUMr.LCCJCM.CommunityJournalPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$sUMr.LCCJCM.CommunityJournalPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591300116)
            
            //--TRIMMABLE-BOUNDARY-START(17181234708)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Journal$Common$Models$CommunityJournalPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181234708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$sUMr.LCCJCM.CommunityJournalPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$sUMr.LCCJCM.CommunityJournalPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181234708)
            
            //--TRIMMABLE-BOUNDARY-START(21476202004)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Journal$Common$Models$CommunityJournalPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476202004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$sUMr.LCCJCM.CommunityJournalPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$sUMr.LCCJCM.CommunityJournalPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476202004)
            
            //--TRIMMABLE-BOUNDARY-START(25771169300)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Journal$Common$Models$CommunityJournalPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771169300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$sUMr.LCCJCM.CommunityJournalPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$sUMr.LCCJCM.CommunityJournalPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771169300)
            
            //--TRIMMABLE-BOUNDARY-START(12886267412)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886267412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$sUMr.LCCJCM.CommunityJournalPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886267412)
            
            static $h = 1365524;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296332820),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1365524,
      "h": 4296332820,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296332820)
  ],
  "h": 1365524
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$sUMr.LCCJCS.IComunityJournalRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.IReadDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Services.IComunityJournalRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Services${separator}IComunityJournalRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1365524)
        
        

        //--TRIMMABLE-BOUNDARY-START(382484)
        $asm.$cls(`$sUMr.LCCJCM.CommunityJournalCategoryModelTypeDescriptor`, ($self) => class CommunityJournalCategoryModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295349780)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295349780);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$sUMr.LCCJCM.CommunityJournalCategoryModelTypeDescriptor.GenerateProperties($.$sUMr.LCCJCM.CommunityJournalCategoryModel, this, factory);
                    }, $mJQljl ??= {"r":65537,"n":"","d":382484,"h":0,"f":17825794}), 0, "CommunityJournalCategoryModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Journal.Common\\Models_CommunityJournalCategoryModel_LivingThing.Core.Community.Journal.Common.Models.CommunityJournalCategoryModelTypeDescriptorBuilder.g.cs", "CommunityJournalCategoryModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295349780)
            
            //--TRIMMABLE-BOUNDARY-START(12885284372)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885284372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sUMr.LCCJCM.CommunityJournalCategoryModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Journal.Common.Models.CommunityJournalCategoryModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sUMr.LCCJCM.CommunityJournalCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$sUMr.LCCJCM.CommunityJournalCategoryModel)).Type);
                        }, $eJalLg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":382484,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel, $.$sUMr.LCCJCM.CommunityJournalPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885284372)
            
            //--TRIMMABLE-BOUNDARY-START(17180251668)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Journal.Common.Models.CommunityJournalCategoryModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180251668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.Journal.Common.Models.CommunityJournalCategoryModel, LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel, $.$sUMr.LCCJCM.CommunityJournalPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel, $.$sUMr.LCCJCM.CommunityJournalPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180251668)
            
            //--TRIMMABLE-BOUNDARY-START(8590317076)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Journal.Common.Models.CommunityJournalCategoryModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590317076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$sUMr.LCCJCM.CommunityJournalCategoryModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$sUMr.LCCJCM.CommunityJournalCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCM.CommunityJournalCategoryModel)))
                {
                    /*var*/ let result = $.$sUMr.LCCJCM.CommunityJournalCategoryModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCM.CommunityJournalCategoryModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$sUMr.LCCJCM.CommunityJournalCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCM.CommunityJournalCategoryModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590317076)
            
            static $h = 382484;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885284372),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 382484,
      "h": 12885284372,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885284372),
//--TRIMMABLE-BOUNDARY-START(17180251668),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 251412,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 382484,
      "h": 17180251668,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180251668),
//--TRIMMABLE-BOUNDARY-START(8590317076),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 251412,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 382484,
      "h": 8590317076,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590317076)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295349780),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 382484,
      "h": 4295349780,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295349780)
  ],
  "h": 382484
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Models.CommunityJournalCategoryModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Models${separator}CommunityJournalCategoryModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(382484)
        
        

        //--TRIMMABLE-BOUNDARY-START(906772)
        $asm.$cls(`$sUMr.LCCJCM.CommunityJournalPostModelTypeDescriptor`, ($self) => class CommunityJournalPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$sUMr.LCCJCM.CommunityJournalPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295874068)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295874068);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$sUMr.LCCJCM.CommunityJournalPostModelTypeDescriptor.GenerateProperties($.$sUMr.LCCJCM.CommunityJournalPostModel, this, factory);
                    }, $yvdcbd ??= {"r":65537,"n":"","d":906772,"h":0,"f":17825794}), 0, "CommunityJournalPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Journal.Common\\Models_CommunityJournalPostModel_LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModelTypeDescriptorBuilder.g.cs", "CommunityJournalPostModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295874068)
            
            //--TRIMMABLE-BOUNDARY-START(12885808660)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885808660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sUMr.LCCJCM.CommunityJournalPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sUMr.LCCJCM.CommunityJournalPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$sUMr.LCCJCM.CommunityJournalPostModel)).Type);
                        }, $TLIZOi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":906772,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885808660)
            
            //--TRIMMABLE-BOUNDARY-START(17180775956)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180775956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.Journal.Common.Models.CommunityJournalCategoryModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$sUMr.LCCJCM.CommunityJournalCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180775956)
            
            //--TRIMMABLE-BOUNDARY-START(8590841364)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590841364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$sUMr.LCCJCM.CommunityJournalPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$sUMr.LCCJCM.CommunityJournalPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCM.CommunityJournalPostModel)))
                {
                    /*var*/ let result = $.$sUMr.LCCJCM.CommunityJournalPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCM.CommunityJournalPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$sUMr.LCCJCM.CommunityJournalPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCM.CommunityJournalPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590841364)
            
            static $h = 906772;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$sUMr.LCCJCM.CommunityJournalPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885808660),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 906772,
      "h": 12885808660,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885808660),
//--TRIMMABLE-BOUNDARY-START(17180775956),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 775700,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 906772,
      "h": 17180775956,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180775956),
//--TRIMMABLE-BOUNDARY-START(8590841364),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 775700,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 906772,
      "h": 8590841364,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590841364)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295874068),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 906772,
      "h": 4295874068,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295874068)
  ],
  "h": 906772
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$sUMr.LCCJCM.CommunityJournalPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Models.CommunityJournalPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Models${separator}CommunityJournalPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(906772)
        
        

        //--TRIMMABLE-BOUNDARY-START(513556)
        $asm.$cls(`$sUMr.LCCJCM.CommunityJournalModel`, ($self) => class CommunityJournalModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$sUMr.LCCJCS$1.CommunityJournalSettings, $.$sUMr.LCCJCS$2.CommunityJournalStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295480852)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295480852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295480852)
            
            //--TRIMMABLE-BOUNDARY-START(4295480852)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295480852)
            
            static $h = 513556;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$sUMr.LCCJCS$1.CommunityJournalSettings, $.$sUMr.LCCJCS$2.CommunityJournalStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295480852),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 513556,
      "h": 4295480852,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295480852)
  ],
  "h": 513556
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Models.CommunityJournalModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Models${separator}CommunityJournalModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(513556)
        
        

        //--TRIMMABLE-BOUNDARY-START(644628)
        $asm.$cls(`$sUMr.LCCJCM.CommunityJournalModelTypeDescriptor`, ($self) => class CommunityJournalModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$sUMr.LCCJCM.CommunityJournalModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295611924)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295611924);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$sUMr.LCCJCM.CommunityJournalModelTypeDescriptor.GenerateProperties($.$sUMr.LCCJCM.CommunityJournalModel, this, factory);
                    }, $TKtQRh ??= {"r":65537,"n":"","d":644628,"h":0,"f":17825794}), 0, "CommunityJournalModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Journal.Common\\Models_CommunityJournalModel_LivingThing.Core.Community.Journal.Common.Models.CommunityJournalModelTypeDescriptorBuilder.g.cs", "CommunityJournalModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295611924)
            
            //--TRIMMABLE-BOUNDARY-START(12885546516)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885546516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$sUMr.LCCJCS$1.CommunityJournalSettings, $.$sUMr.LCCJCS$2.CommunityJournalStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885546516)
            
            //--TRIMMABLE-BOUNDARY-START(17180513812)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Journal.Common.Models.CommunityJournalModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180513812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Journal.Common.Settings.CommunityJournalSettings, LivingThing.Core.Community.Journal.Common.States.CommunityJournalStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$sUMr.LCCJCS$1.CommunityJournalSettings, $.$sUMr.LCCJCS$2.CommunityJournalStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$sUMr.LCCJCS$1.CommunityJournalSettings, $.$sUMr.LCCJCS$2.CommunityJournalStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180513812)
            
            //--TRIMMABLE-BOUNDARY-START(8590579220)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Journal.Common.Models.CommunityJournalModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590579220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$sUMr.LCCJCM.CommunityJournalModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$sUMr.LCCJCM.CommunityJournalModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCM.CommunityJournalModel)))
                {
                    /*var*/ let result = $.$sUMr.LCCJCM.CommunityJournalModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCM.CommunityJournalModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$sUMr.LCCJCM.CommunityJournalModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$sUMr.LCCJCM.CommunityJournalModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590579220)
            
            static $h = 644628;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$sUMr.LCCJCM.CommunityJournalModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885546516),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 644628,
      "h": 12885546516,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885546516),
//--TRIMMABLE-BOUNDARY-START(17180513812),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 513556,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 644628,
      "h": 17180513812,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180513812),
//--TRIMMABLE-BOUNDARY-START(8590579220),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 513556,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 644628,
      "h": 8590579220,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590579220)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295611924),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 644628,
      "h": 4295611924,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295611924)
  ],
  "h": 644628
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$sUMr.LCCJCM.CommunityJournalModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Journal.Common.Models.CommunityJournalModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Journal${separator}Common${separator}Models${separator}CommunityJournalModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(644628)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(54804)
