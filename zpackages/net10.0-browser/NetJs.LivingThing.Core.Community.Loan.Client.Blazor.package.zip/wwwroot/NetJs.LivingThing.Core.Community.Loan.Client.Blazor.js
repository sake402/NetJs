
//--TRIMMABLE-BOUNDARY-START(44526)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $Gokg) {
    "use strict";
    let _;
    let $HEjbpc;
    let $cmoNEk;
    let $psyxRk;
    let $dcrrfe;
    let $KjALre;
    let $Tzcvjg;
    let $wvYDyh;
    let $QEwEVh;
    let $NIkTrh;
    let $rdvXff;
    let $qWlWHi;
    let $UmgsWd;
    let $AZdlki;
    let $eACdaf;
    let $nusvvf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Loan.Client.Blazor", 
    {
  "h": 44526,
  "f": "LivingThing.Core.Community.Loan.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Loan.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Loan.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(175598)
        $asm.$cls(`$fMQq.LCCLC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295142894)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295142894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$fMQq.LCCLC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295142894)
            
            static $h = 175598;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295142894),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 175598,
      "h": 4295142894,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295142894)
  ],
  "h": 175598
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(175598)
        
        

        //--TRIMMABLE-BOUNDARY-START(372206)
        $asm.$cls(`$fMQq.LCCLC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590306798)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590306798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$fMQq.LCCLCS.CommunityLoanService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$Gokg.LCCLCM.CommunityLoanRequestPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$fMQq.LCCLCS.CommunityLoanApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fMQq.LCCLCS.CommunityLoanApplication, x);
                }, $cmoNEk ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":372206,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fMQq.LCCLCS.CommunityLoanApplication, x);
                }, $psyxRk ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":372206,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$Gokg.LCCLCM.CommunityLoanRequestPostModel, services, null);
                $.$fMQq.LCCLC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590306798)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fMQq.LCCLC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295339502)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295339502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295339502)
            
            //--TRIMMABLE-BOUNDARY-START(4295339502)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295339502)
            
            static $h = 372206;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590306798),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 372206,
      "h": 8590306798,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590306798)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295339502),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 372206,
      "h": 4295339502,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295339502)
  ],
  "h": 372206
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(372206)
        
        

        //--TRIMMABLE-BOUNDARY-START(241134)
        $asm.$cls(`$fMQq.LCCLC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180110318)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$fMQq.LCCLCP.CommunityLoanApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$fMQq.LCCLCP.CommunityLoanApp().$ctor$3();
                    }, $HEjbpc ??= {"r":2752627,"n":"","d":241134,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180110318)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295208430)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295208430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295208430)
            
            //--TRIMMABLE-BOUNDARY-START(4295208430)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295208430)
            
            static $h = 241134;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180110318),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885143022,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 241134,
      "h": 17180110318,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180110318)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295208430),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 241134,
      "h": 4295208430,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295208430)
  ],
  "h": 241134
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(241134)
        
        

        //--TRIMMABLE-BOUNDARY-START(568814)
        $asm.$cls(`$fMQq.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295536110)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295536110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295536110)
            
            //--TRIMMABLE-BOUNDARY-START(4295536110)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295536110)
            
            static $h = 568814;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295536110),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 568814,
      "h": 4295536110,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295536110)
  ],
  "h": 568814
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(568814)
        
        

        //--TRIMMABLE-BOUNDARY-START(634350)
        $asm.$cls(`$fMQq.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295601646)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295601646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295601646)
            
            //--TRIMMABLE-BOUNDARY-START(4295601646)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295601646)
            
            static $h = 634350;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295601646),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 634350,
      "h": 4295601646,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295601646)
  ],
  "h": 634350,
  "a": [
    {
      "t": 568814,
      "c": 4295536110
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(634350)
        
        

        //--TRIMMABLE-BOUNDARY-START(110062)
        $asm.$cls(`$fMQq.LCCLC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590044654)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590044654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590044654)
            
            //--TRIMMABLE-BOUNDARY-START(4295077358)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295077358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295077358)
            
            //--TRIMMABLE-BOUNDARY-START(4295077358)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295077358)
            
            static $h = 110062;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590044654),
    {
      "r": 65537,
      "n": "Execute",
      "d": 110062,
      "h": 8590044654,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590044654)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295077358),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 110062,
      "h": 4295077358,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295077358)
  ],
  "h": 110062
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(110062)
        
        

        //--TRIMMABLE-BOUNDARY-START(306670)
        $asm.$cls(`$fMQq.LCCLCP.CommunityLoanApp`, ($self) => class CommunityLoanApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(60129848814)
            /*CommunityLoanService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(60129848814)
            
            //--TRIMMABLE-BOUNDARY-START(21475143150)
            /*CommunityLoanApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(21475143150)
            
            //--TRIMMABLE-BOUNDARY-START(55834881518)
            /*IUIRenderingProvider*/ Rendering = null;
            //--TRIMMABLE-BOUNDARY-END(55834881518)
            
            //--TRIMMABLE-BOUNDARY-START(25770110446)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770110446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "InitialViewIndex", "0");
                __builder.AddComponentParameter(2, "Name", "Loan");
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(5, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 6);
                        __builder2.AddComponentParameter(7, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                        __builder2.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(9, wrap.View);
                        }), $dcrrfe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":306670,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $KjALre ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":306670,"h":0,"f":17825794});
                }), $Tzcvjg ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":306670,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/*splash*/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 11);
                        __builder2.AddComponentParameter(12, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, splash.ViewModel));
                        __builder2.AddComponentParameter(13, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, splash.Message));
                        __builder2.CloseComponent();
                    }, $wvYDyh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":306670,"h":0,"f":17825794});
                }), $QEwEVh ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":306670,"h":0,"f":17825794}));
                __builder.AddAttribute$3(14, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 15);
                    __builder2.AddComponentParameter(16, "Name", "");
                    __builder2.AddComponentParameter(17, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddAttribute$3(18, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(19, "Loan");
                        }, $NIkTrh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":306670,"h":0,"f":17825794});
                    }), $rdvXff ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":306670,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(20, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(21, "<i class=\"mdi mdi-book\"></i>");
                        }, $qWlWHi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":306670,"h":0,"f":17825794});
                    }), $UmgsWd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":306670,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(22, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityApplicationUnderDevelopment, 23);
                            __builder3.AddComponentParameter(24, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCS.ICommunityClientApplication, this.Application));
                            __builder3.CloseComponent();
                        }, $AZdlki ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":306670,"h":0,"f":17825794});
                    }), $eACdaf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":306670,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $nusvvf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":306670,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25770110446)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180175854)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180175854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180175854)
            
            //--TRIMMABLE-BOUNDARY-START(17180175854)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17180175854)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60129848814)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(60129848814)
                
                //--TRIMMABLE-BOUNDARY-START(21475143150)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(21475143150)
                
                //--TRIMMABLE-BOUNDARY-START(55834881518)
                this.Rendering = null;
                //--TRIMMABLE-BOUNDARY-END(55834881518)
                
            }
            static $h = 306670;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129848814),
    {
      "p": 503278,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539914222,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899652590,
        "f": 83886081
      },
      "n": "Service",
      "d": 306670,
      "h": 60129848814,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60129848814),
//--TRIMMABLE-BOUNDARY-START(21475143150),
    {
      "p": 437742,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360045038,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719783406,
        "f": 83886081
      },
      "n": "Application",
      "d": 306670,
      "h": 21475143150,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475143150),
//--TRIMMABLE-BOUNDARY-START(55834881518),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949979630,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309717998,
        "f": 83886081
      },
      "n": "Rendering",
      "d": 306670,
      "h": 55834881518,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834881518)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770110446),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 306670,
      "h": 25770110446,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770110446)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180175854),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 306670,
      "h": 17180175854,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180175854)
  ],
  "h": 306670
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Client.Pages.CommunityLoanApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Client${separator}Pages${separator}CommunityLoanApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(306670)
        
        

        //--TRIMMABLE-BOUNDARY-START(437742)
        $asm.$cls(`$fMQq.LCCLCS.CommunityLoanApplication`, ($self) => class CommunityLoanApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885339630)
            $ctor$5(/*CommunityLoanService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885339630);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885339630)
            
            //--TRIMMABLE-BOUNDARY-START(137439391214)
            /*string */ get Name()
            {
                return "Loan";
            }
            //--TRIMMABLE-BOUNDARY-END(137439391214)
            
            //--TRIMMABLE-BOUNDARY-START(158914227694)
            /*string */ get Title()
            {
                return "Loan";
            }
            //--TRIMMABLE-BOUNDARY-END(158914227694)
            
            //--TRIMMABLE-BOUNDARY-START(21475274222)
            /*string */ get Description()
            {
                return "Need quick fund, ask the community how much you need and wait for their response and terms.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475274222)
            
            //--TRIMMABLE-BOUNDARY-START(133144423918)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-cash"/*MaterialDesignIconNames.Cash*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144423918)
            
            //--TRIMMABLE-BOUNDARY-START(154619260398)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2EF69B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619260398)
            
            //--TRIMMABLE-BOUNDARY-START(30065208814)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065208814)
            
            //--TRIMMABLE-BOUNDARY-START(17180306926)
            /*Type? */ get ApplicationViewType()
            {
                return $.$fMQq.LCCLCP.CommunityLoanApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180306926)
            
            //--TRIMMABLE-BOUNDARY-START(128849456622)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849456622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$fMQq.LCCLCP.CommunityLoanApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849456622)
            
            //--TRIMMABLE-BOUNDARY-START(25770241518)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770241518);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770241518)
            
            //--TRIMMABLE-BOUNDARY-START(146029325806)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029325806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029325806)
            
            //--TRIMMABLE-BOUNDARY-START(141734358510)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734358510)
            
            //--TRIMMABLE-BOUNDARY-START(4295405038)
            /*CommunityLoanService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295405038)
            
            //--TRIMMABLE-BOUNDARY-START(150324293102)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(150324293102)
            
            //--TRIMMABLE-BOUNDARY-START(163209194990)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(3584/*PostTypes.Loan*/, 3586/*PostTypes.LoanEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209194990)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 437742;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439391214),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604816366,
        "f": 50364417
      },
      "n": "Name",
      "d": 437742,
      "h": 137439391214,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439391214),
//--TRIMMABLE-BOUNDARY-START(158914227694),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964554734,
        "f": 50364417
      },
      "n": "Title",
      "d": 437742,
      "h": 158914227694,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914227694),
//--TRIMMABLE-BOUNDARY-START(21475274222),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835012590,
        "f": 50364417
      },
      "n": "Description",
      "d": 437742,
      "h": 21475274222,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475274222),
//--TRIMMABLE-BOUNDARY-START(133144423918),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014881774,
        "f": 50364417
      },
      "n": "Icon",
      "d": 437742,
      "h": 133144423918,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144423918),
//--TRIMMABLE-BOUNDARY-START(154619260398),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374620142,
        "f": 50364417
      },
      "n": "Theme",
      "d": 437742,
      "h": 154619260398,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619260398),
//--TRIMMABLE-BOUNDARY-START(30065208814),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424947182,
        "f": 50364417
      },
      "n": "Features",
      "d": 437742,
      "h": 30065208814,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065208814),
//--TRIMMABLE-BOUNDARY-START(17180306926),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245077998,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 437742,
      "h": 17180306926,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180306926),
//--TRIMMABLE-BOUNDARY-START(141734358510),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194750958,
        "f": 50364417
      },
      "n": "Order",
      "d": 437742,
      "h": 141734358510,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734358510),
//--TRIMMABLE-BOUNDARY-START(4295405038),
    {
      "p": 503278,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655143406,
        "f": 50331650
      },
      "n": "_Service",
      "d": 437742,
      "h": 4295405038,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295405038),
//--TRIMMABLE-BOUNDARY-START(150324293102),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784685550,
        "f": 50364417
      },
      "n": "Service",
      "d": 437742,
      "h": 150324293102,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324293102),
//--TRIMMABLE-BOUNDARY-START(163209194990),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554489326,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 437742,
      "h": 163209194990,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209194990)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849456622),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 437742,
      "h": 128849456622,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849456622),
//--TRIMMABLE-BOUNDARY-START(25770241518),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 437742,
      "h": 25770241518,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770241518),
//--TRIMMABLE-BOUNDARY-START(146029325806),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 437742,
      "h": 146029325806,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029325806)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885339630),
    {
      "p": [
        {
          "n": "service",
          "p": 503278
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 437742,
      "h": 12885339630,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885339630)
  ],
  "h": 437742
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Client.Services.CommunityLoanApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Client${separator}Services${separator}CommunityLoanApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(437742)
        
        

        //--TRIMMABLE-BOUNDARY-START(503278)
        $asm.$cls(`$fMQq.LCCLCS.CommunityLoanService`, ($self) => class CommunityLoanService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$Gokg.LCCLCM.CommunityLoanRequestPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295470574)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295470574);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295470574)
            
            static $h = 503278;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$Gokg.LCCLCM.CommunityLoanRequestPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295470574),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 503278,
      "h": 4295470574,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295470574)
  ],
  "h": 503278
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$Gokg.LCCLCM.CommunityLoanRequestPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Client.Services.CommunityLoanService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Client${separator}Services${separator}CommunityLoanService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(503278)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Loan.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(44526)
