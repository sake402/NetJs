
//--TRIMMABLE-BOUNDARY-START(35067)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $KVfwGb;
    let $mWlwLa;
    let $BjZoHh;
    let $SrrJWd;
    let $SfkSVk;
    let $BPLBpd;
    let $vxvRCj;
    let $zHGPAd;
    let $AKclxk;
    let $ZWQfqk;
    let $gpqVxc;
    let $BKsrQg;
    let $cAuGde;
    let $dWgEzj;
    let $RQtdde;
    let $DIdUqg;
    let $FAIdIb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Loan.Common", 
    {
  "h": 35067,
  "f": "LivingThing.Core.Community.Loan.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Loan.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Loan.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(297211)
        $asm.$cls(`$Gokg.LCCLCM.CommunityLoanModelCustomAttributesProvider`, ($self) => class CommunityLoanModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295264507)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295264507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$Gokg.LCCLCS$1.CommunityLoanSettings, $.$Gokg.LCCLCS$2.CommunityLoanStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295264507)
            
            static $h = 297211;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295264507),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 297211,
      "h": 4295264507,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295264507)
  ],
  "h": 297211
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Models.CommunityLoanModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Models${separator}CommunityLoanModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(297211)
        
        

        //--TRIMMABLE-BOUNDARY-START(1280251)
        $asm.$cls(`$Gokg.LCCLCS$2.CommunityLoanStatesCustomAttributesProvider`, ($self) => class CommunityLoanStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296247547)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296247547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296247547)
            
            static $h = 1280251;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296247547),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1280251,
      "h": 4296247547,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296247547)
  ],
  "h": 1280251
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.States.CommunityLoanStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}States${separator}CommunityLoanStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1280251)
        
        

        //--TRIMMABLE-BOUNDARY-START(100603)
        $asm.$cls(`$Gokg.LCCLC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295067899)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295067899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$Gokg.LCCLCM.CommunityLoanModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$Gokg.LCCLCM.CommunityLoanModelCustomAttributesProvider, $.$Gokg.LCCLCM.CommunityLoanModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$Gokg.LCCLCM.CommunityLoanRequestPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$Gokg.LCCLCM.CommunityLoanRequestPostModelCustomAttributesProvider, $.$Gokg.LCCLCM.CommunityLoanRequestPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$Gokg.LCCLCS$1.CommunityLoanSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$Gokg.LCCLCS$1.CommunityLoanSettingsCustomAttributesProvider, $.$Gokg.LCCLCS$1.CommunityLoanSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$Gokg.LCCLCS$2.CommunityLoanStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$Gokg.LCCLCS$2.CommunityLoanStatesCustomAttributesProvider, $.$Gokg.LCCLCS$2.CommunityLoanStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295067899)
            
            static $h = 100603;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295067899),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 100603,
      "h": 4295067899,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295067899)
  ],
  "h": 100603
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(100603)
        
        

        //--TRIMMABLE-BOUNDARY-START(559355)
        $asm.$cls(`$Gokg.LCCLCM.CommunityLoanRequestPostModelCustomAttributesProvider`, ($self) => class CommunityLoanRequestPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295526651)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295526651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295526651)
            
            static $h = 559355;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295526651),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 559355,
      "h": 4295526651,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295526651)
  ],
  "h": 559355
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Models${separator}CommunityLoanRequestPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(559355)
        
        

        //--TRIMMABLE-BOUNDARY-START(1476859)
        $asm.$cls(`$Gokg.LCCLC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296444155)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296444155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Gokg.LCCLCM.CommunityLoanModelTypeDescriptorBuilder.Register();
                $.$Gokg.LCCLCM.CommunityLoanRequestPostModelTypeDescriptorBuilder.Register();
                $.$Gokg.LCCLCS$1.CommunityLoanSettingsTypeDescriptorBuilder.Register();
                $.$Gokg.LCCLCS$2.CommunityLoanStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296444155)
            
            static $h = 1476859;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296444155),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1476859,
      "h": 4296444155,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296444155)
  ],
  "h": 1476859
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1476859)
        
        

        //--TRIMMABLE-BOUNDARY-START(1018107)
        $asm.$cls(`$Gokg.LCCLCS$1.CommunityLoanSettingsCustomAttributesProvider`, ($self) => class CommunityLoanSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295985403)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295985403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295985403)
            
            static $h = 1018107;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295985403),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1018107,
      "h": 4295985403,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295985403)
  ],
  "h": 1018107
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Settings.CommunityLoanSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Settings${separator}CommunityLoanSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1018107)
        
        

        //--TRIMMABLE-BOUNDARY-START(1411323)
        $asm.$cls(`$Gokg.LCCLCS$2.CommunityLoanStatesTypeDescriptorBuilder`, ($self) => class CommunityLoanStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591345915)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591345915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$Gokg.LCCLCS$2.CommunityLoanStatesTypeDescriptor()
                        const $t1 = $.$Gokg.LCCLCS$2.CommunityLoanStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Loan.Common.States.CommunityLoanStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KVfwGb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1411323,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$Gokg.LCCLCS$2.CommunityLoanStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591345915)
            
            //--TRIMMABLE-BOUNDARY-START(4296378619)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296378619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296378619)
            
            //--TRIMMABLE-BOUNDARY-START(4296378619)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296378619)
            
            static $h = 1411323;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591345915),
    {
      "r": 65537,
      "n": "Register",
      "d": 1411323,
      "h": 8591345915,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591345915)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296378619),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1411323,
      "h": 4296378619,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296378619)
  ],
  "h": 1411323
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.States.CommunityLoanStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}States${separator}CommunityLoanStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1411323)
        
        

        //--TRIMMABLE-BOUNDARY-START(1149179)
        $asm.$cls(`$Gokg.LCCLCS$1.CommunityLoanSettingsTypeDescriptorBuilder`, ($self) => class CommunityLoanSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591083771)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591083771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$Gokg.LCCLCS$1.CommunityLoanSettingsTypeDescriptor()
                        const $t1 = $.$Gokg.LCCLCS$1.CommunityLoanSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Loan.Common.Settings.CommunityLoanSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $SfkSVk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1149179,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$Gokg.LCCLCS$1.CommunityLoanSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591083771)
            
            //--TRIMMABLE-BOUNDARY-START(4296116475)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296116475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296116475)
            
            //--TRIMMABLE-BOUNDARY-START(4296116475)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296116475)
            
            static $h = 1149179;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591083771),
    {
      "r": 65537,
      "n": "Register",
      "d": 1149179,
      "h": 8591083771,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591083771)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296116475),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1149179,
      "h": 4296116475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296116475)
  ],
  "h": 1149179
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Settings.CommunityLoanSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Settings${separator}CommunityLoanSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1149179)
        
        

        //--TRIMMABLE-BOUNDARY-START(428283)
        $asm.$cls(`$Gokg.LCCLCM.CommunityLoanModelTypeDescriptorBuilder`, ($self) => class CommunityLoanModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590362875)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590362875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$Gokg.LCCLCM.CommunityLoanModelTypeDescriptor()
                        const $t1 = $.$Gokg.LCCLCM.CommunityLoanModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Loan.Common.Models.CommunityLoanModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $BjZoHh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":428283,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$Gokg.LCCLCM.CommunityLoanModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590362875)
            
            //--TRIMMABLE-BOUNDARY-START(4295395579)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295395579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295395579)
            
            //--TRIMMABLE-BOUNDARY-START(4295395579)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295395579)
            
            static $h = 428283;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590362875),
    {
      "r": 65537,
      "n": "Register",
      "d": 428283,
      "h": 8590362875,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590362875)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295395579),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 428283,
      "h": 4295395579,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295395579)
  ],
  "h": 428283
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Models.CommunityLoanModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Models${separator}CommunityLoanModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(428283)
        
        

        //--TRIMMABLE-BOUNDARY-START(166139)
        $asm.$cls(`$Gokg.LCCLC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295133435)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295133435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$Gokg.LCCLCS.IComunityLoanRemoteService, $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking().$ctor$3(impl);
                }, $vxvRCj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":166139,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking().$ctor$3(impl);
                }, $zHGPAd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":166139,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking().$ctor$3(impl);
                }, $AKclxk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":166139,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking().$ctor$3(impl);
                }, $ZWQfqk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":166139,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking().$ctor$3(impl);
                }, $gpqVxc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":166139,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking().$ctor$3(impl);
                }, $BKsrQg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":166139,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking().$ctor$3(impl);
                }, $cAuGde ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":166139,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking().$ctor$3(impl);
                }, $dWgEzj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":166139,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295133435)
            
            static $h = 166139;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295133435),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 166139,
      "h": 4295133435,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295133435)
  ],
  "h": 166139
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(166139)
        
        

        //--TRIMMABLE-BOUNDARY-START(690427)
        $asm.$cls(`$Gokg.LCCLCM.CommunityLoanRequestPostModelTypeDescriptorBuilder`, ($self) => class CommunityLoanRequestPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590625019)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590625019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$Gokg.LCCLCM.CommunityLoanRequestPostModelTypeDescriptor()
                        const $t1 = $.$Gokg.LCCLCM.CommunityLoanRequestPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $RQtdde ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":690427,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$Gokg.LCCLCM.CommunityLoanRequestPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590625019)
            
            //--TRIMMABLE-BOUNDARY-START(4295657723)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295657723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295657723)
            
            //--TRIMMABLE-BOUNDARY-START(4295657723)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295657723)
            
            static $h = 690427;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590625019),
    {
      "r": 65537,
      "n": "Register",
      "d": 690427,
      "h": 8590625019,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590625019)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295657723),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 690427,
      "h": 4295657723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295657723)
  ],
  "h": 690427
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Models${separator}CommunityLoanRequestPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(690427)
        
        

        //--TRIMMABLE-BOUNDARY-START(755963)
        $asm.$cls(`$Gokg.LCCLC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590690555)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590690555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$Gokg.LCCLCM.CommunityLoanRequestPostModel, 3585/*PostTypes.LoanRequest*/);
                $.$Gokg.LCCLC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$Gokg.LCCLC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$Gokg.LCCLC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590690555)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Gokg.LCCLC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295723259)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295723259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295723259)
            
            //--TRIMMABLE-BOUNDARY-START(4295723259)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295723259)
            
            static $h = 755963;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590690555),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 755963,
      "h": 8590690555,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590690555)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295723259),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 755963,
      "h": 4295723259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295723259)
  ],
  "h": 755963
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(755963)
        
        

        //--TRIMMABLE-BOUNDARY-START(1214715)
        $asm.$cls(`$Gokg.LCCLCS$2.CommunityLoanStates`, ($self) => class CommunityLoanStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296182011)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296182011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296182011)
            
            //--TRIMMABLE-BOUNDARY-START(4296182011)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296182011)
            
            static $h = 1214715;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296182011),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1214715,
      "h": 4296182011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296182011)
  ],
  "h": 1214715
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.States.CommunityLoanStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}States${separator}CommunityLoanStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1214715)
        
        

        //--TRIMMABLE-BOUNDARY-START(952571)
        $asm.$cls(`$Gokg.LCCLCS$1.CommunityLoanSettings`, ($self) => class CommunityLoanSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4295919867)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295919867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295919867)
            
            //--TRIMMABLE-BOUNDARY-START(4295919867)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295919867)
            
            static $h = 952571;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295919867),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 952571,
      "h": 4295919867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295919867)
  ],
  "h": 952571
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Settings.CommunityLoanSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Settings${separator}CommunityLoanSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(952571)
        
        

        //--TRIMMABLE-BOUNDARY-START(1345787)
        $asm.$cls(`$Gokg.LCCLCS$2.CommunityLoanStatesTypeDescriptor`, ($self) => class CommunityLoanStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Gokg.LCCLCS$2.CommunityLoanStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296313083)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296313083);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$Gokg.LCCLCS$2.CommunityLoanStatesTypeDescriptor.GenerateProperties($.$Gokg.LCCLCS$2.CommunityLoanStates, this, factory);
                    }, $mWlwLa ??= {"r":65537,"n":"","d":1345787,"h":0,"f":17825794}), 0, "CommunityLoanStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Loan.Common\\States_CommunityLoanStates_LivingThing.Core.Community.Loan.Common.States.CommunityLoanStatesTypeDescriptorBuilder.g.cs", "CommunityLoanStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296313083)
            
            //--TRIMMABLE-BOUNDARY-START(12886247675)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886247675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886247675)
            
            //--TRIMMABLE-BOUNDARY-START(17181214971)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Loan.Common.States.CommunityLoanStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181214971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181214971)
            
            //--TRIMMABLE-BOUNDARY-START(8591280379)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Loan.Common.States.CommunityLoanStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591280379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$Gokg.LCCLCS$2.CommunityLoanStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$Gokg.LCCLCS$2.CommunityLoanStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$Gokg.LCCLCS$2.CommunityLoanStates)))
                {
                    /*var*/ let result = $.$Gokg.LCCLCS$2.CommunityLoanStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$Gokg.LCCLCS$2.CommunityLoanStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$Gokg.LCCLCS$2.CommunityLoanStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$Gokg.LCCLCS$2.CommunityLoanStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591280379)
            
            static $h = 1345787;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Gokg.LCCLCS$2.CommunityLoanStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886247675),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1345787,
      "h": 12886247675,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886247675),
//--TRIMMABLE-BOUNDARY-START(17181214971),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1214715,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1345787,
      "h": 17181214971,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181214971),
//--TRIMMABLE-BOUNDARY-START(8591280379),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1214715,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1345787,
      "h": 8591280379,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591280379)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296313083),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1345787,
      "h": 4296313083,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296313083)
  ],
  "h": 1345787
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$Gokg.LCCLCS$2.CommunityLoanStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.States.CommunityLoanStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}States${separator}CommunityLoanStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1345787)
        
        

        //--TRIMMABLE-BOUNDARY-START(1083643)
        $asm.$cls(`$Gokg.LCCLCS$1.CommunityLoanSettingsTypeDescriptor`, ($self) => class CommunityLoanSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Gokg.LCCLCS$1.CommunityLoanSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296050939)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296050939);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$Gokg.LCCLCS$1.CommunityLoanSettingsTypeDescriptor.GenerateProperties($.$Gokg.LCCLCS$1.CommunityLoanSettings, this, factory);
                    }, $BPLBpd ??= {"r":65537,"n":"","d":1083643,"h":0,"f":17825794}), 0, "CommunityLoanSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Loan.Common\\Settings_CommunityLoanSettings_LivingThing.Core.Community.Loan.Common.Settings.CommunityLoanSettingsTypeDescriptorBuilder.g.cs", "CommunityLoanSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296050939)
            
            //--TRIMMABLE-BOUNDARY-START(12885985531)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885985531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885985531)
            
            //--TRIMMABLE-BOUNDARY-START(17180952827)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Loan.Common.Settings.CommunityLoanSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180952827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180952827)
            
            //--TRIMMABLE-BOUNDARY-START(8591018235)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Loan.Common.Settings.CommunityLoanSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591018235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$Gokg.LCCLCS$1.CommunityLoanSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$Gokg.LCCLCS$1.CommunityLoanSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$Gokg.LCCLCS$1.CommunityLoanSettings)))
                {
                    /*var*/ let result = $.$Gokg.LCCLCS$1.CommunityLoanSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$Gokg.LCCLCS$1.CommunityLoanSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$Gokg.LCCLCS$1.CommunityLoanSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$Gokg.LCCLCS$1.CommunityLoanSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591018235)
            
            static $h = 1083643;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Gokg.LCCLCS$1.CommunityLoanSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885985531),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1083643,
      "h": 12885985531,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885985531),
//--TRIMMABLE-BOUNDARY-START(17180952827),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 952571,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1083643,
      "h": 17180952827,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180952827),
//--TRIMMABLE-BOUNDARY-START(8591018235),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 952571,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1083643,
      "h": 8591018235,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591018235)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296050939),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1083643,
      "h": 4296050939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296050939)
  ],
  "h": 1083643
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$Gokg.LCCLCS$1.CommunityLoanSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Settings.CommunityLoanSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Settings${separator}CommunityLoanSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1083643)
        
        

        //--TRIMMABLE-BOUNDARY-START(493819)
        $asm.$cls(`$Gokg.LCCLCM.CommunityLoanRequestPostModel`, ($self) => class CommunityLoanRequestPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180363003)
            /*PostTypes */ get Type()
            {
                return 3585/*PostTypes.LoanRequest*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180363003)
            
            //--TRIMMABLE-BOUNDARY-START(4295461115)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295461115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295461115)
            
            //--TRIMMABLE-BOUNDARY-START(4295461115)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295461115)
            
            static $h = 493819;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180363003),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885395707,
        "f": 50364417
      },
      "n": "Type",
      "d": 493819,
      "h": 17180363003,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180363003)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295461115),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 493819,
      "h": 4295461115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295461115)
  ],
  "h": 493819
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Models${separator}CommunityLoanRequestPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(493819)
        
        

        //--TRIMMABLE-BOUNDARY-START(821499)
        $asm.$cls(`$Gokg.LCCLCS.IComunityLoanRemoteService`, ($self) => class IComunityLoanRemoteService
        {
            static $h = 821499;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 821499,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.IReadDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Services.IComunityLoanRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Services${separator}IComunityLoanRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(821499)
        
        

        //--TRIMMABLE-BOUNDARY-START(887035)
        $asm.$cls(`$Gokg.LCCLCS.IComunityLoanRemoteService_Mocking`, ($self) => class IComunityLoanRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295854331)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295854331);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295854331)
            
            //--TRIMMABLE-BOUNDARY-START(8590821627)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Loan$Common$Models$CommunityLoanRequestPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590821627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$Gokg.LCCLCM.CommunityLoanRequestPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590821627)
            
            //--TRIMMABLE-BOUNDARY-START(17180756219)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Loan$Common$Models$CommunityLoanRequestPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180756219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$Gokg.LCCLCM.CommunityLoanRequestPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180756219)
            
            //--TRIMMABLE-BOUNDARY-START(21475723515)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Loan$Common$Models$CommunityLoanRequestPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475723515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$Gokg.LCCLCM.CommunityLoanRequestPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475723515)
            
            //--TRIMMABLE-BOUNDARY-START(25770690811)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Loan$Common$Models$CommunityLoanRequestPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770690811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$Gokg.LCCLCM.CommunityLoanRequestPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770690811)
            
            //--TRIMMABLE-BOUNDARY-START(12885788923)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885788923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$Gokg.LCCLCM.CommunityLoanRequestPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885788923)
            
            static $h = 887035;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295854331),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 887035,
      "h": 4295854331,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295854331)
  ],
  "h": 887035
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$Gokg.LCCLCS.IComunityLoanRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.IReadDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Services.IComunityLoanRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Services${separator}IComunityLoanRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(887035)
        
        

        //--TRIMMABLE-BOUNDARY-START(624891)
        $asm.$cls(`$Gokg.LCCLCM.CommunityLoanRequestPostModelTypeDescriptor`, ($self) => class CommunityLoanRequestPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295592187)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295592187);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$Gokg.LCCLCM.CommunityLoanRequestPostModelTypeDescriptor.GenerateProperties($.$Gokg.LCCLCM.CommunityLoanRequestPostModel, this, factory);
                    }, $DIdUqg ??= {"r":65537,"n":"","d":624891,"h":0,"f":17825794}), 0, "CommunityLoanRequestPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Loan.Common\\Models_CommunityLoanRequestPostModel_LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModelTypeDescriptorBuilder.g.cs", "CommunityLoanRequestPostModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295592187)
            
            //--TRIMMABLE-BOUNDARY-START(12885526779)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885526779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Gokg.LCCLCM.CommunityLoanRequestPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Gokg.LCCLCM.CommunityLoanRequestPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$Gokg.LCCLCM.CommunityLoanRequestPostModel)).Type);
                        }, $FAIdIb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":624891,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885526779)
            
            //--TRIMMABLE-BOUNDARY-START(17180494075)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180494075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180494075)
            
            //--TRIMMABLE-BOUNDARY-START(8590559483)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590559483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$Gokg.LCCLCM.CommunityLoanRequestPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$Gokg.LCCLCM.CommunityLoanRequestPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Gokg.LCCLCM.CommunityLoanRequestPostModel)))
                {
                    /*var*/ let result = $.$Gokg.LCCLCM.CommunityLoanRequestPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$Gokg.LCCLCM.CommunityLoanRequestPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$Gokg.LCCLCM.CommunityLoanRequestPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Gokg.LCCLCM.CommunityLoanRequestPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590559483)
            
            static $h = 624891;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885526779),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 624891,
      "h": 12885526779,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885526779),
//--TRIMMABLE-BOUNDARY-START(17180494075),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 493819,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 624891,
      "h": 17180494075,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180494075),
//--TRIMMABLE-BOUNDARY-START(8590559483),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 493819,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 624891,
      "h": 8590559483,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590559483)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295592187),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 624891,
      "h": 4295592187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295592187)
  ],
  "h": 624891
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$Gokg.LCCLCM.CommunityLoanRequestPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Models.CommunityLoanRequestPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Models${separator}CommunityLoanRequestPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(624891)
        
        

        //--TRIMMABLE-BOUNDARY-START(231675)
        $asm.$cls(`$Gokg.LCCLCM.CommunityLoanModel`, ($self) => class CommunityLoanModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$Gokg.LCCLCS$1.CommunityLoanSettings, $.$Gokg.LCCLCS$2.CommunityLoanStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295198971)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295198971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295198971)
            
            //--TRIMMABLE-BOUNDARY-START(4295198971)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295198971)
            
            static $h = 231675;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$Gokg.LCCLCS$1.CommunityLoanSettings, $.$Gokg.LCCLCS$2.CommunityLoanStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295198971),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 231675,
      "h": 4295198971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295198971)
  ],
  "h": 231675
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Models.CommunityLoanModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Models${separator}CommunityLoanModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(231675)
        
        

        //--TRIMMABLE-BOUNDARY-START(362747)
        $asm.$cls(`$Gokg.LCCLCM.CommunityLoanModelTypeDescriptor`, ($self) => class CommunityLoanModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Gokg.LCCLCM.CommunityLoanModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295330043)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295330043);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$Gokg.LCCLCM.CommunityLoanModelTypeDescriptor.GenerateProperties($.$Gokg.LCCLCM.CommunityLoanModel, this, factory);
                    }, $SrrJWd ??= {"r":65537,"n":"","d":362747,"h":0,"f":17825794}), 0, "CommunityLoanModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Loan.Common\\Models_CommunityLoanModel_LivingThing.Core.Community.Loan.Common.Models.CommunityLoanModelTypeDescriptorBuilder.g.cs", "CommunityLoanModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295330043)
            
            //--TRIMMABLE-BOUNDARY-START(12885264635)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885264635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$Gokg.LCCLCS$1.CommunityLoanSettings, $.$Gokg.LCCLCS$2.CommunityLoanStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885264635)
            
            //--TRIMMABLE-BOUNDARY-START(17180231931)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Loan.Common.Models.CommunityLoanModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180231931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Loan.Common.Settings.CommunityLoanSettings, LivingThing.Core.Community.Loan.Common.States.CommunityLoanStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$Gokg.LCCLCS$1.CommunityLoanSettings, $.$Gokg.LCCLCS$2.CommunityLoanStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$Gokg.LCCLCS$1.CommunityLoanSettings, $.$Gokg.LCCLCS$2.CommunityLoanStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180231931)
            
            //--TRIMMABLE-BOUNDARY-START(8590297339)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Loan.Common.Models.CommunityLoanModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590297339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$Gokg.LCCLCM.CommunityLoanModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$Gokg.LCCLCM.CommunityLoanModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Gokg.LCCLCM.CommunityLoanModel)))
                {
                    /*var*/ let result = $.$Gokg.LCCLCM.CommunityLoanModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$Gokg.LCCLCM.CommunityLoanModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$Gokg.LCCLCM.CommunityLoanModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Gokg.LCCLCM.CommunityLoanModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590297339)
            
            static $h = 362747;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Gokg.LCCLCM.CommunityLoanModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885264635),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 362747,
      "h": 12885264635,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885264635),
//--TRIMMABLE-BOUNDARY-START(17180231931),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 231675,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 362747,
      "h": 17180231931,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180231931),
//--TRIMMABLE-BOUNDARY-START(8590297339),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 231675,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 362747,
      "h": 8590297339,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590297339)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295330043),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 362747,
      "h": 4295330043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295330043)
  ],
  "h": 362747
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$Gokg.LCCLCM.CommunityLoanModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Loan.Common.Models.CommunityLoanModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Loan${separator}Common${separator}Models${separator}CommunityLoanModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(362747)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(35067)
