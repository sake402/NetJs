
//--TRIMMABLE-BOUNDARY-START(32726)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $ftPx) {
    "use strict";
    let _;
    let $vjcQMa;
    let $mOrgJg;
    let $fEMwsg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.LoanManagement.Client.Blazor", 
    {
  "h": 32726,
  "f": "LivingThing.Core.Community.LoanManagement.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.LoanManagement.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.LoanManagement.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(163798)
        $asm.$cls(`$Qqwn.LCCLC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295131094)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295131094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$Qqwn.LCCLC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295131094)
            
            static $h = 163798;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295131094),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 163798,
      "h": 4295131094,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295131094)
  ],
  "h": 163798
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(163798)
        
        

        //--TRIMMABLE-BOUNDARY-START(360406)
        $asm.$cls(`$Qqwn.LCCLC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590294998)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590294998);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$Qqwn.LCCLCS.CommunityLoanManagementService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$Qqwn.LCCLCS.CommunityLoanManagementApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Qqwn.LCCLCS.CommunityLoanManagementApplication, x);
                }, $mOrgJg ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":360406,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Qqwn.LCCLCS.CommunityLoanManagementApplication, x);
                }, $fEMwsg ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":360406,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel, services, null);
                $.$Qqwn.LCCLC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590294998)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Qqwn.LCCLC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295327702)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295327702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295327702)
            
            //--TRIMMABLE-BOUNDARY-START(4295327702)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295327702)
            
            static $h = 360406;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590294998),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 360406,
      "h": 8590294998,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590294998)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295327702),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 360406,
      "h": 4295327702,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295327702)
  ],
  "h": 360406
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(360406)
        
        

        //--TRIMMABLE-BOUNDARY-START(229334)
        $asm.$cls(`$Qqwn.LCCLC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180098518)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Qqwn.LCCLCP.CommunityLoanManagementApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Qqwn.LCCLCP.CommunityLoanManagementApp().$ctor$6();
                    }, $vjcQMa ??= {"r":2752627,"n":"","d":229334,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180098518)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295196630)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295196630);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295196630)
            
            //--TRIMMABLE-BOUNDARY-START(4295196630)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295196630)
            
            static $h = 229334;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180098518),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885131222,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 229334,
      "h": 17180098518,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180098518)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295196630),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 229334,
      "h": 4295196630,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295196630)
  ],
  "h": 229334
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(229334)
        
        

        //--TRIMMABLE-BOUNDARY-START(557014)
        $asm.$cls(`$Qqwn.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295524310)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295524310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295524310)
            
            //--TRIMMABLE-BOUNDARY-START(4295524310)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295524310)
            
            static $h = 557014;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295524310),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 557014,
      "h": 4295524310,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295524310)
  ],
  "h": 557014
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(557014)
        
        

        //--TRIMMABLE-BOUNDARY-START(622550)
        $asm.$cls(`$Qqwn.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295589846)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295589846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295589846)
            
            //--TRIMMABLE-BOUNDARY-START(4295589846)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295589846)
            
            static $h = 622550;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295589846),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 622550,
      "h": 4295589846,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295589846)
  ],
  "h": 622550,
  "a": [
    {
      "t": 557014,
      "c": 4295524310
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(622550)
        
        

        //--TRIMMABLE-BOUNDARY-START(98262)
        $asm.$cls(`$Qqwn.LCCLC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590032854)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590032854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590032854)
            
            //--TRIMMABLE-BOUNDARY-START(4295065558)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295065558);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295065558)
            
            //--TRIMMABLE-BOUNDARY-START(4295065558)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295065558)
            
            static $h = 98262;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590032854),
    {
      "r": 65537,
      "n": "Execute",
      "d": 98262,
      "h": 8590032854,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590032854)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295065558),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 98262,
      "h": 4295065558,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295065558)
  ],
  "h": 98262
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(98262)
        
        

        //--TRIMMABLE-BOUNDARY-START(425942)
        $asm.$cls(`$Qqwn.LCCLCS.CommunityLoanManagementApplication`, ($self) => class CommunityLoanManagementApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885327830)
            $ctor$5(/*CommunityLoanManagementService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885327830);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885327830)
            
            //--TRIMMABLE-BOUNDARY-START(137439379414)
            /*string */ get Name()
            {
                return "LoanManagement";
            }
            //--TRIMMABLE-BOUNDARY-END(137439379414)
            
            //--TRIMMABLE-BOUNDARY-START(158914215894)
            /*string */ get Title()
            {
                return "Package LoanManagement";
            }
            //--TRIMMABLE-BOUNDARY-END(158914215894)
            
            //--TRIMMABLE-BOUNDARY-START(21475262422)
            /*string */ get Description()
            {
                return "Post a LoanManagement agent, send, track and receive a package from the comfort of your phone.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475262422)
            
            //--TRIMMABLE-BOUNDARY-START(133144412118)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-package"/*MaterialDesignIconNames.Package*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144412118)
            
            //--TRIMMABLE-BOUNDARY-START(154619248598)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2E969B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619248598)
            
            //--TRIMMABLE-BOUNDARY-START(30065197014)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065197014)
            
            //--TRIMMABLE-BOUNDARY-START(17180295126)
            /*Type? */ get ApplicationViewType()
            {
                return $.$Qqwn.LCCLCP.CommunityLoanManagementApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180295126)
            
            //--TRIMMABLE-BOUNDARY-START(128849444822)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849444822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$Qqwn.LCCLCP.CommunityLoanManagementApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849444822)
            
            //--TRIMMABLE-BOUNDARY-START(25770229718)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770229718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770229718)
            
            //--TRIMMABLE-BOUNDARY-START(146029314006)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029314006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029314006)
            
            //--TRIMMABLE-BOUNDARY-START(141734346710)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734346710)
            
            //--TRIMMABLE-BOUNDARY-START(4295393238)
            /*CommunityLoanManagementService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295393238)
            
            //--TRIMMABLE-BOUNDARY-START(150324281302)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(150324281302)
            
            //--TRIMMABLE-BOUNDARY-START(163209183190)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(9984/*PostTypes.LoanManagement*/, 9988/*PostTypes.LoanManagementEnd*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209183190)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 425942;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439379414),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604804566,
        "f": 50364417
      },
      "n": "Name",
      "d": 425942,
      "h": 137439379414,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439379414),
//--TRIMMABLE-BOUNDARY-START(158914215894),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964542934,
        "f": 50364417
      },
      "n": "Title",
      "d": 425942,
      "h": 158914215894,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914215894),
//--TRIMMABLE-BOUNDARY-START(21475262422),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835000790,
        "f": 50364417
      },
      "n": "Description",
      "d": 425942,
      "h": 21475262422,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475262422),
//--TRIMMABLE-BOUNDARY-START(133144412118),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014869974,
        "f": 50364417
      },
      "n": "Icon",
      "d": 425942,
      "h": 133144412118,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144412118),
//--TRIMMABLE-BOUNDARY-START(154619248598),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374608342,
        "f": 50364417
      },
      "n": "Theme",
      "d": 425942,
      "h": 154619248598,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619248598),
//--TRIMMABLE-BOUNDARY-START(30065197014),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424935382,
        "f": 50364417
      },
      "n": "Features",
      "d": 425942,
      "h": 30065197014,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065197014),
//--TRIMMABLE-BOUNDARY-START(17180295126),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245066198,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 425942,
      "h": 17180295126,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180295126),
//--TRIMMABLE-BOUNDARY-START(141734346710),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194739158,
        "f": 50364417
      },
      "n": "Order",
      "d": 425942,
      "h": 141734346710,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734346710),
//--TRIMMABLE-BOUNDARY-START(4295393238),
    {
      "p": 491478,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655131606,
        "f": 50331650
      },
      "n": "_Service",
      "d": 425942,
      "h": 4295393238,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295393238),
//--TRIMMABLE-BOUNDARY-START(150324281302),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784673750,
        "f": 50364417
      },
      "n": "Service",
      "d": 425942,
      "h": 150324281302,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324281302),
//--TRIMMABLE-BOUNDARY-START(163209183190),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554477526,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 425942,
      "h": 163209183190,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209183190)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849444822),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 425942,
      "h": 128849444822,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849444822),
//--TRIMMABLE-BOUNDARY-START(25770229718),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 425942,
      "h": 25770229718,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770229718),
//--TRIMMABLE-BOUNDARY-START(146029314006),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 425942,
      "h": 146029314006,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029314006)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885327830),
    {
      "p": [
        {
          "n": "service",
          "p": 491478
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 425942,
      "h": 12885327830,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885327830)
  ],
  "h": 425942
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Client.Services.CommunityLoanManagementApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Client${separator}Services${separator}CommunityLoanManagementApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(425942)
        
        

        //--TRIMMABLE-BOUNDARY-START(294870)
        $asm.$cls(`$Qqwn.LCCLCP.CommunityLoanManagementApp`, ($self) => class CommunityLoanManagementApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$ftPx.LCCLCM.CommunityLoanManagementUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(55834869718)
            /*CommunityLoanManagementService*/ LoanManagementService = null;
            //--TRIMMABLE-BOUNDARY-END(55834869718)
            
            //--TRIMMABLE-BOUNDARY-START(51539902422)
            /*CommunityLoanManagementApplication*/ LoanManagementApplication = null;
            //--TRIMMABLE-BOUNDARY-END(51539902422)
            
            //--TRIMMABLE-BOUNDARY-START(17180164054)
            /*ICommunityClientApplication */ get Application()
            {
                return this.LoanManagementApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(17180164054)
            
            //--TRIMMABLE-BOUNDARY-START(21475131350)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475131350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
            }
            //--TRIMMABLE-BOUNDARY-END(21475131350)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885196758)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885196758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885196758)
            
            //--TRIMMABLE-BOUNDARY-START(12885196758)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12885196758)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55834869718)
                this.LoanManagementService = null;
                //--TRIMMABLE-BOUNDARY-END(55834869718)
                
                //--TRIMMABLE-BOUNDARY-START(51539902422)
                this.LoanManagementApplication = null;
                //--TRIMMABLE-BOUNDARY-END(51539902422)
                
            }
            static $h = 294870;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$ftPx.LCCLCM.CommunityLoanManagementUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834869718),
    {
      "p": 491478,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244935126,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014738902,
        "f": 83886081
      },
      "n": "LoanManagementService",
      "d": 294870,
      "h": 55834869718,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834869718),
//--TRIMMABLE-BOUNDARY-START(51539902422),
    {
      "p": 425942,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655000534,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424804310,
        "f": 83886081
      },
      "n": "LoanManagementApplication",
      "d": 294870,
      "h": 51539902422,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51539902422),
//--TRIMMABLE-BOUNDARY-START(17180164054),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065065942,
        "f": 50364420
      },
      "n": "Application",
      "d": 294870,
      "h": 17180164054,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(17180164054)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475131350),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 294870,
      "h": 21475131350,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475131350)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885196758),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 294870,
      "h": 12885196758,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885196758)
  ],
  "h": 294870
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Client.Pages.CommunityLoanManagementApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Client${separator}Pages${separator}CommunityLoanManagementApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(294870)
        
        

        //--TRIMMABLE-BOUNDARY-START(491478)
        $asm.$cls(`$Qqwn.LCCLCS.CommunityLoanManagementService`, ($self) => class CommunityLoanManagementService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295458774)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295458774);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295458774)
            
            static $h = 491478;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295458774),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 491478,
      "h": 4295458774,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295458774)
  ],
  "h": 491478
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Client.Services.CommunityLoanManagementService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Client${separator}Services${separator}CommunityLoanManagementService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(491478)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.LoanManagement.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(32726)
