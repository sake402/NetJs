
//--TRIMMABLE-BOUNDARY-START(39977)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $QpcJpi;
    let $AiSBya;
    let $TrfWna;
    let $vXXtai;
    let $WVbkkd;
    let $PKayXb;
    let $UHQLgd;
    let $TPiySa;
    let $bXxqib;
    let $QMkWxb;
    let $TIqLUg;
    let $kIAbeh;
    let $IySJCd;
    let $ynoHud;
    let $XrCyqa;
    let $InIpmh;
    let $MCOBMh;
    let $PnbLCk;
    let $nBEqJg;
    let $MBLaXi;
    let $qWayJe;
    let $ZrVRsb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.LoanManagement.Common", 
    {
  "h": 39977,
  "f": "LivingThing.Core.Community.LoanManagement.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.LoanManagement.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.LoanManagement.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(564265)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModelCustomAttributesProvider`, ($self) => class CommunityLoanManagementLoanCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295531561)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295531561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295531561)
            
            static $h = 564265;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295531561),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 564265,
      "h": 4295531561,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295531561)
  ],
  "h": 564265
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementLoanCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(564265)
        
        

        //--TRIMMABLE-BOUNDARY-START(105513)
        $asm.$cls(`$ftPx.LCCLC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295072809)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295072809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModelCustomAttributesProvider, $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModelCustomAttributesProvider, $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ftPx.LCCLCM.CommunityLoanManagementLoanModelCustomAttributesProvider, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ftPx.LCCLCM.CommunityLoanManagementModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ftPx.LCCLCM.CommunityLoanManagementModelCustomAttributesProvider, $.$ftPx.LCCLCM.CommunityLoanManagementModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ftPx.LCCLCS$1.CommunityLoanManagementSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ftPx.LCCLCS$1.CommunityLoanManagementSettingsCustomAttributesProvider, $.$ftPx.LCCLCS$1.CommunityLoanManagementSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ftPx.LCCLCS$2.CommunityLoanManagementStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ftPx.LCCLCS$2.CommunityLoanManagementStatesCustomAttributesProvider, $.$ftPx.LCCLCS$2.CommunityLoanManagementStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295072809)
            
            static $h = 105513;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295072809),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 105513,
      "h": 4295072809,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295072809)
  ],
  "h": 105513
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(105513)
        
        

        //--TRIMMABLE-BOUNDARY-START(1874985)
        $asm.$cls(`$ftPx.LCCLCS$2.CommunityLoanManagementStatesCustomAttributesProvider`, ($self) => class CommunityLoanManagementStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296842281)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296842281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296842281)
            
            static $h = 1874985;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296842281),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1874985,
      "h": 4296842281,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296842281)
  ],
  "h": 1874985
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.States.CommunityLoanManagementStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}States${separator}CommunityLoanManagementStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1874985)
        
        

        //--TRIMMABLE-BOUNDARY-START(826409)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementLoanModelCustomAttributesProvider`, ($self) => class CommunityLoanManagementLoanModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295793705)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295793705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295793705)
            
            static $h = 826409;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295793705),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 826409,
      "h": 4295793705,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295793705)
  ],
  "h": 826409
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementLoanModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(826409)
        
        

        //--TRIMMABLE-BOUNDARY-START(302121)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModelCustomAttributesProvider`, ($self) => class CommunityLoanManagementCustomerAccountFeatureModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295269417)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295269417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.DataFeatureModelCustomAttributesProvider$$($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295269417)
            
            static $h = 302121;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295269417),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 302121,
      "h": 4295269417,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295269417)
  ],
  "h": 302121
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementCustomerAccountFeatureModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementCustomerAccountFeatureModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(302121)
        
        

        //--TRIMMABLE-BOUNDARY-START(1088553)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementModelCustomAttributesProvider`, ($self) => class CommunityLoanManagementModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296055849)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296055849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$ftPx.LCCLCS$1.CommunityLoanManagementSettings, $.$ftPx.LCCLCS$2.CommunityLoanManagementStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296055849)
            
            static $h = 1088553;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296055849),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1088553,
      "h": 4296055849,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296055849)
  ],
  "h": 1088553
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1088553)
        
        

        //--TRIMMABLE-BOUNDARY-START(2071593)
        $asm.$cls(`$ftPx.LCCLC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297038889)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297038889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptorBuilder.Register();
                $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModelTypeDescriptorBuilder.Register();
                $.$ftPx.LCCLCM.CommunityLoanManagementLoanModelTypeDescriptorBuilder.Register();
                $.$ftPx.LCCLCM.CommunityLoanManagementModelTypeDescriptorBuilder.Register();
                $.$ftPx.LCCLCS$1.CommunityLoanManagementSettingsTypeDescriptorBuilder.Register();
                $.$ftPx.LCCLCS$2.CommunityLoanManagementStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297038889)
            
            static $h = 2071593;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297038889),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2071593,
      "h": 4297038889,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297038889)
  ],
  "h": 2071593
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2071593)
        
        

        //--TRIMMABLE-BOUNDARY-START(1612841)
        $asm.$cls(`$ftPx.LCCLCS$1.CommunityLoanManagementSettingsCustomAttributesProvider`, ($self) => class CommunityLoanManagementSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296580137)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296580137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296580137)
            
            static $h = 1612841;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296580137),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1612841,
      "h": 4296580137,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296580137)
  ],
  "h": 1612841
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Settings.CommunityLoanManagementSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Settings${separator}CommunityLoanManagementSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1612841)
        
        

        //--TRIMMABLE-BOUNDARY-START(957481)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementLoanModelTypeDescriptorBuilder`, ($self) => class CommunityLoanManagementLoanModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590892073)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590892073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ftPx.LCCLCM.CommunityLoanManagementLoanModelTypeDescriptor()
                        const $t1 = $.$ftPx.LCCLCM.CommunityLoanManagementLoanModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XrCyqa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":957481,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590892073)
            
            //--TRIMMABLE-BOUNDARY-START(4295924777)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295924777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295924777)
            
            //--TRIMMABLE-BOUNDARY-START(4295924777)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295924777)
            
            static $h = 957481;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590892073),
    {
      "r": 65537,
      "n": "Register",
      "d": 957481,
      "h": 8590892073,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590892073)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295924777),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 957481,
      "h": 4295924777,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295924777)
  ],
  "h": 957481
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementLoanModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(957481)
        
        

        //--TRIMMABLE-BOUNDARY-START(1219625)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementModelTypeDescriptorBuilder`, ($self) => class CommunityLoanManagementModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591154217)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591154217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ftPx.LCCLCM.CommunityLoanManagementModelTypeDescriptor()
                        const $t1 = $.$ftPx.LCCLCM.CommunityLoanManagementModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $TIqLUg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1219625,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ftPx.LCCLCM.CommunityLoanManagementModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591154217)
            
            //--TRIMMABLE-BOUNDARY-START(4296186921)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296186921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296186921)
            
            //--TRIMMABLE-BOUNDARY-START(4296186921)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296186921)
            
            static $h = 1219625;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591154217),
    {
      "r": 65537,
      "n": "Register",
      "d": 1219625,
      "h": 8591154217,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591154217)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296186921),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1219625,
      "h": 4296186921,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296186921)
  ],
  "h": 1219625
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1219625)
        
        

        //--TRIMMABLE-BOUNDARY-START(2006057)
        $asm.$cls(`$ftPx.LCCLCS$2.CommunityLoanManagementStatesTypeDescriptorBuilder`, ($self) => class CommunityLoanManagementStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591940649)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591940649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ftPx.LCCLCS$2.CommunityLoanManagementStatesTypeDescriptor()
                        const $t1 = $.$ftPx.LCCLCS$2.CommunityLoanManagementStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.LoanManagement.Common.States.CommunityLoanManagementStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $QpcJpi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2006057,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ftPx.LCCLCS$2.CommunityLoanManagementStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591940649)
            
            //--TRIMMABLE-BOUNDARY-START(4296973353)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296973353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296973353)
            
            //--TRIMMABLE-BOUNDARY-START(4296973353)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296973353)
            
            static $h = 2006057;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591940649),
    {
      "r": 65537,
      "n": "Register",
      "d": 2006057,
      "h": 8591940649,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591940649)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296973353),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2006057,
      "h": 4296973353,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296973353)
  ],
  "h": 2006057
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.States.CommunityLoanManagementStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}States${separator}CommunityLoanManagementStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2006057)
        
        

        //--TRIMMABLE-BOUNDARY-START(433193)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptorBuilder`, ($self) => class CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590367785)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590367785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptor()
                        const $t1 = $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementCustomerAccountFeatureModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $IySJCd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":433193,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590367785)
            
            //--TRIMMABLE-BOUNDARY-START(4295400489)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295400489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295400489)
            
            //--TRIMMABLE-BOUNDARY-START(4295400489)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295400489)
            
            static $h = 433193;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590367785),
    {
      "r": 65537,
      "n": "Register",
      "d": 433193,
      "h": 8590367785,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590367785)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295400489),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 433193,
      "h": 4295400489,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295400489)
  ],
  "h": 433193
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(433193)
        
        

        //--TRIMMABLE-BOUNDARY-START(171049)
        $asm.$cls(`$ftPx.LCCLC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295138345)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295138345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$ftPx.LCCLCS.IComunityLoanManagementRemoteService, $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking().$ctor$3(impl);
                }, $TrfWna ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":171049,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking().$ctor$3(impl);
                }, $vXXtai ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":171049,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking().$ctor$3(impl);
                }, $WVbkkd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":171049,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking().$ctor$3(impl);
                }, $PKayXb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":171049,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking().$ctor$3(impl);
                }, $UHQLgd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":171049,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking().$ctor$3(impl);
                }, $TPiySa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":171049,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking().$ctor$3(impl);
                }, $bXxqib ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":171049,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking().$ctor$3(impl);
                }, $QMkWxb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":171049,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295138345)
            
            static $h = 171049;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295138345),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 171049,
      "h": 4295138345,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295138345)
  ],
  "h": 171049
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(171049)
        
        

        //--TRIMMABLE-BOUNDARY-START(695337)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModelTypeDescriptorBuilder`, ($self) => class CommunityLoanManagementLoanCategoryModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590629929)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590629929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModelTypeDescriptor()
                        const $t1 = $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanCategoryModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $MBLaXi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":695337,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590629929)
            
            //--TRIMMABLE-BOUNDARY-START(4295662633)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295662633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295662633)
            
            //--TRIMMABLE-BOUNDARY-START(4295662633)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295662633)
            
            static $h = 695337;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590629929),
    {
      "r": 65537,
      "n": "Register",
      "d": 695337,
      "h": 8590629929,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590629929)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295662633),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 695337,
      "h": 4295662633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295662633)
  ],
  "h": 695337
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanCategoryModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementLoanCategoryModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(695337)
        
        

        //--TRIMMABLE-BOUNDARY-START(1743913)
        $asm.$cls(`$ftPx.LCCLCS$1.CommunityLoanManagementSettingsTypeDescriptorBuilder`, ($self) => class CommunityLoanManagementSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591678505)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591678505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ftPx.LCCLCS$1.CommunityLoanManagementSettingsTypeDescriptor()
                        const $t1 = $.$ftPx.LCCLCS$1.CommunityLoanManagementSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.LoanManagement.Common.Settings.CommunityLoanManagementSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $PnbLCk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1743913,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ftPx.LCCLCS$1.CommunityLoanManagementSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591678505)
            
            //--TRIMMABLE-BOUNDARY-START(4296711209)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296711209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296711209)
            
            //--TRIMMABLE-BOUNDARY-START(4296711209)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296711209)
            
            static $h = 1743913;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591678505),
    {
      "r": 65537,
      "n": "Register",
      "d": 1743913,
      "h": 8591678505,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591678505)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296711209),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1743913,
      "h": 4296711209,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296711209)
  ],
  "h": 1743913
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Settings.CommunityLoanManagementSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Settings${separator}CommunityLoanManagementSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1743913)
        
        

        //--TRIMMABLE-BOUNDARY-START(1350697)
        $asm.$cls(`$ftPx.LCCLC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591285289)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591285289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, 9985/*PostTypes.LoanManagementLoanCategory*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel, 9986/*PostTypes.LoanManagementLoan*/);
                $.$ftPx.LCCLC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$ftPx.LCCLC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$ftPx.LCCLC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591285289)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ftPx.LCCLC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296317993)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296317993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296317993)
            
            //--TRIMMABLE-BOUNDARY-START(4296317993)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296317993)
            
            static $h = 1350697;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591285289),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1350697,
      "h": 8591285289,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591285289)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296317993),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1350697,
      "h": 4296317993,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296317993)
  ],
  "h": 1350697
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1350697)
        
        

        //--TRIMMABLE-BOUNDARY-START(236585)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel`, ($self) => class CommunityLoanManagementCustomerAccountFeatureModel extends $.$Iaui.LCFCM.DataFeatureModel$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(8590171177)
            /*string*/ static FeatureKey = null;
            //--TRIMMABLE-BOUNDARY-END(8590171177)
            
            //--TRIMMABLE-BOUNDARY-START(17180105769)
            static /*CommunityLoanManagementCustomerAccountFeatureModel? */ From$1(/*AccountModel*/ account, /*bool?*/ createIfNotExist)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180105769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let feature = $.$Iaui.LCFCM.DataPropertiesExtensions.GetFeatures($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel, account, "$LoanManagement"/*FeatureKey*/, createIfNotExist);
                return feature;
            }
            //--TRIMMABLE-BOUNDARY-END(17180105769)
            
            //--TRIMMABLE-BOUNDARY-START(12885138473)
            static /*CommunityLoanManagementCustomerAccountFeatureModel? */ From(/*IDataModel*/ target, /*IDataModel?*/ context, /*bool?*/ createIfNotExist)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885138473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let feature = $.$Iaui.LCFCM.DataPropertiesExtensions.GetFeatures($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel, ($.$cast(target, $.$Iaui.LCFCM.DataModel)), "$LoanManagement"/*FeatureKey*/, createIfNotExist);
                return feature;
            }
            //--TRIMMABLE-BOUNDARY-END(12885138473)
            
            //--TRIMMABLE-BOUNDARY-START(21475073065)
            static /*string */ GetFeatureKey(/*IDataModel?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475073065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$strNN("$"/*DataFeatureModel.PrefixIdentifier*/) + "LoanManagement";
            }
            //--TRIMMABLE-BOUNDARY-END(21475073065)
            
            //--TRIMMABLE-BOUNDARY-START(8607009110)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementCustomerAccountFeatureModel>.GetFeatureKey(LivingThing.Core.Frameworks.Common.Data.IDataModel?)
            static LCFCD$IDataFeatureModel$$$GetFeatureKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8607009110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel.GetFeatureKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8607009110)
            
            //--TRIMMABLE-BOUNDARY-START(4312041814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementCustomerAccountFeatureModel>.From(LivingThing.Core.Frameworks.Common.Data.IDataModel, LivingThing.Core.Frameworks.Common.Data.IDataModel?, bool?)
            static LCFCD$IDataFeatureModel$$$From()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312041814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel.From(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312041814)
            
            //--TRIMMABLE-BOUNDARY-START(4295203881)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295203881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295203881)
            
            //--TRIMMABLE-BOUNDARY-START(4295203881)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295203881)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590171177)
                    this.FeatureKey = "$LoanManagement";
                    //--TRIMMABLE-BOUNDARY-END(8590171177)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 236585;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.DataFeatureModel$$($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180105769),
    {
      "r": 236585,
      "p": [
        {
          "n": "account",
          "p": 7858612
        },
        {
          "n": "createIfNotExist",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65
        }
      ],
      "n": "From",
      "o": "@$1",
      "d": 236585,
      "h": 17180105769,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180105769),
//--TRIMMABLE-BOUNDARY-START(12885138473),
    {
      "r": 236585,
      "p": [
        {
          "n": "target",
          "p": 17533270
        },
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        },
        {
          "n": "createIfNotExist",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65
        }
      ],
      "n": "From",
      "d": 236585,
      "h": 12885138473,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885138473),
//--TRIMMABLE-BOUNDARY-START(21475073065),
    {
      "r": 1310721,
      "p": [
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        }
      ],
      "n": "GetFeatureKey",
      "d": 236585,
      "h": 21475073065,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475073065)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590171177),
    {
      "t": 1310721,
      "n": "FeatureKey",
      "d": 236585,
      "h": 8590171177,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590171177)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295203881),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 236585,
      "h": 4295203881,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295203881)
  ],
  "h": 236585
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD.IDataFeatureModel$$($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementCustomerAccountFeatureModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementCustomerAccountFeatureModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(236585)
        
        

        //--TRIMMABLE-BOUNDARY-START(1285161)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementUserPreference`, ($self) => class CommunityLoanManagementUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4296252457)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296252457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296252457)
            
            //--TRIMMABLE-BOUNDARY-START(4296252457)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296252457)
            
            static $h = 1285161;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296252457),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1285161,
      "h": 4296252457,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296252457)
  ],
  "h": 1285161
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1285161)
        
        

        //--TRIMMABLE-BOUNDARY-START(1547305)
        $asm.$cls(`$ftPx.LCCLCS$1.CommunityLoanManagementSettings`, ($self) => class CommunityLoanManagementSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296514601)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296514601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296514601)
            
            //--TRIMMABLE-BOUNDARY-START(4296514601)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296514601)
            
            static $h = 1547305;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296514601),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1547305,
      "h": 4296514601,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296514601)
  ],
  "h": 1547305
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Settings.CommunityLoanManagementSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Settings${separator}CommunityLoanManagementSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1547305)
        
        

        //--TRIMMABLE-BOUNDARY-START(1809449)
        $asm.$cls(`$ftPx.LCCLCS$2.CommunityLoanManagementStates`, ($self) => class CommunityLoanManagementStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296776745)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296776745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296776745)
            
            //--TRIMMABLE-BOUNDARY-START(4296776745)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296776745)
            
            static $h = 1809449;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296776745),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1809449,
      "h": 4296776745,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296776745)
  ],
  "h": 1809449
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.States.CommunityLoanManagementStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}States${separator}CommunityLoanManagementStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1809449)
        
        

        //--TRIMMABLE-BOUNDARY-START(367657)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptor`, ($self) => class CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295334953)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295334953);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptor.GenerateProperties($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel, this, factory);
                    }, $ynoHud ??= {"r":65537,"n":"","d":367657,"h":0,"f":17825794}), 0, "CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.LoanManagement.Common\\Models_CommunityLoanManagementCustomerAccountFeatureModel_LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptorBuilder.g.cs", "CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295334953)
            
            //--TRIMMABLE-BOUNDARY-START(12885269545)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885269545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.DataFeatureModelTypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885269545)
            
            //--TRIMMABLE-BOUNDARY-START(17180236841)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementCustomerAccountFeatureModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180236841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.DataFeatureModel<LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementCustomerAccountFeatureModel>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.DataFeatureModelTypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.DataFeatureModel$$($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180236841)
            
            //--TRIMMABLE-BOUNDARY-START(8590302249)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementCustomerAccountFeatureModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590302249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel)))
                {
                    /*var*/ let result = $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590302249)
            
            static $h = 367657;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885269545),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 367657,
      "h": 12885269545,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885269545),
//--TRIMMABLE-BOUNDARY-START(17180236841),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 236585,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 367657,
      "h": 17180236841,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180236841),
//--TRIMMABLE-BOUNDARY-START(8590302249),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 236585,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 367657,
      "h": 8590302249,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590302249)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295334953),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 367657,
      "h": 4295334953,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295334953)
  ],
  "h": 367657
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementCustomerAccountFeatureModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementCustomerAccountFeatureModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(367657)
        
        

        //--TRIMMABLE-BOUNDARY-START(1940521)
        $asm.$cls(`$ftPx.LCCLCS$2.CommunityLoanManagementStatesTypeDescriptor`, ($self) => class CommunityLoanManagementStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ftPx.LCCLCS$2.CommunityLoanManagementStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296907817)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296907817);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ftPx.LCCLCS$2.CommunityLoanManagementStatesTypeDescriptor.GenerateProperties($.$ftPx.LCCLCS$2.CommunityLoanManagementStates, this, factory);
                    }, $AiSBya ??= {"r":65537,"n":"","d":1940521,"h":0,"f":17825794}), 0, "CommunityLoanManagementStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.LoanManagement.Common\\States_CommunityLoanManagementStates_LivingThing.Core.Community.LoanManagement.Common.States.CommunityLoanManagementStatesTypeDescriptorBuilder.g.cs", "CommunityLoanManagementStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296907817)
            
            //--TRIMMABLE-BOUNDARY-START(12886842409)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886842409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886842409)
            
            //--TRIMMABLE-BOUNDARY-START(17181809705)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.LoanManagement.Common.States.CommunityLoanManagementStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181809705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181809705)
            
            //--TRIMMABLE-BOUNDARY-START(8591875113)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.LoanManagement.Common.States.CommunityLoanManagementStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591875113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ftPx.LCCLCS$2.CommunityLoanManagementStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ftPx.LCCLCS$2.CommunityLoanManagementStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCS$2.CommunityLoanManagementStates)))
                {
                    /*var*/ let result = $.$ftPx.LCCLCS$2.CommunityLoanManagementStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCS$2.CommunityLoanManagementStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ftPx.LCCLCS$2.CommunityLoanManagementStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCS$2.CommunityLoanManagementStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591875113)
            
            static $h = 1940521;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ftPx.LCCLCS$2.CommunityLoanManagementStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886842409),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1940521,
      "h": 12886842409,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886842409),
//--TRIMMABLE-BOUNDARY-START(17181809705),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1809449,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1940521,
      "h": 17181809705,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181809705),
//--TRIMMABLE-BOUNDARY-START(8591875113),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1809449,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1940521,
      "h": 8591875113,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591875113)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296907817),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1940521,
      "h": 4296907817,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296907817)
  ],
  "h": 1940521
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ftPx.LCCLCS$2.CommunityLoanManagementStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.States.CommunityLoanManagementStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}States${separator}CommunityLoanManagementStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1940521)
        
        

        //--TRIMMABLE-BOUNDARY-START(1678377)
        $asm.$cls(`$ftPx.LCCLCS$1.CommunityLoanManagementSettingsTypeDescriptor`, ($self) => class CommunityLoanManagementSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ftPx.LCCLCS$1.CommunityLoanManagementSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296645673)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296645673);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ftPx.LCCLCS$1.CommunityLoanManagementSettingsTypeDescriptor.GenerateProperties($.$ftPx.LCCLCS$1.CommunityLoanManagementSettings, this, factory);
                    }, $nBEqJg ??= {"r":65537,"n":"","d":1678377,"h":0,"f":17825794}), 0, "CommunityLoanManagementSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.LoanManagement.Common\\Settings_CommunityLoanManagementSettings_LivingThing.Core.Community.LoanManagement.Common.Settings.CommunityLoanManagementSettingsTypeDescriptorBuilder.g.cs", "CommunityLoanManagementSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296645673)
            
            //--TRIMMABLE-BOUNDARY-START(12886580265)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886580265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886580265)
            
            //--TRIMMABLE-BOUNDARY-START(17181547561)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.LoanManagement.Common.Settings.CommunityLoanManagementSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181547561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181547561)
            
            //--TRIMMABLE-BOUNDARY-START(8591612969)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.LoanManagement.Common.Settings.CommunityLoanManagementSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591612969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ftPx.LCCLCS$1.CommunityLoanManagementSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ftPx.LCCLCS$1.CommunityLoanManagementSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCS$1.CommunityLoanManagementSettings)))
                {
                    /*var*/ let result = $.$ftPx.LCCLCS$1.CommunityLoanManagementSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCS$1.CommunityLoanManagementSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ftPx.LCCLCS$1.CommunityLoanManagementSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCS$1.CommunityLoanManagementSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591612969)
            
            static $h = 1678377;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ftPx.LCCLCS$1.CommunityLoanManagementSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886580265),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1678377,
      "h": 12886580265,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886580265),
//--TRIMMABLE-BOUNDARY-START(17181547561),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1547305,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1678377,
      "h": 17181547561,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181547561),
//--TRIMMABLE-BOUNDARY-START(8591612969),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1547305,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1678377,
      "h": 8591612969,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591612969)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296645673),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1678377,
      "h": 4296645673,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296645673)
  ],
  "h": 1678377
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ftPx.LCCLCS$1.CommunityLoanManagementSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Settings.CommunityLoanManagementSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Settings${separator}CommunityLoanManagementSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1678377)
        
        

        $asm.$typeProxy("$ftPx.LCCLCM.CommunityLoanManagementLoanModel", "$ftPx.LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel");
        //--TRIMMABLE-BOUNDARY-START(498729)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel`, ($self) => class CommunityLoanManagementLoanCategoryModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180367913)
            /*PostTypes */ get Type()
            {
                return 9985/*PostTypes.LoanManagementLoanCategory*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180367913)
            
            //--TRIMMABLE-BOUNDARY-START(4295466025)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295466025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295466025)
            
            //--TRIMMABLE-BOUNDARY-START(4295466025)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295466025)
            
            static $h = 498729;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180367913),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885400617,
        "f": 50364417
      },
      "n": "Type",
      "d": 498729,
      "h": 17180367913,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180367913)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295466025),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 498729,
      "h": 4295466025,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295466025)
  ],
  "h": 498729
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementLoanCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(498729)
        
        

        //--TRIMMABLE-BOUNDARY-START(760873)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementLoanModel`, ($self) => class CommunityLoanManagementLoanModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180630057)
            /*PostTypes */ get Type()
            {
                return 9986/*PostTypes.LoanManagementLoan*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180630057)
            
            //--TRIMMABLE-BOUNDARY-START(4295728169)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295728169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295728169)
            
            //--TRIMMABLE-BOUNDARY-START(4295728169)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295728169)
            
            static $h = 760873;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180630057),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885662761,
        "f": 50364417
      },
      "n": "Type",
      "d": 760873,
      "h": 17180630057,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180630057)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295728169),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 760873,
      "h": 4295728169,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295728169)
  ],
  "h": 760873
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementLoanModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(760873)
        
        

        //--TRIMMABLE-BOUNDARY-START(1416233)
        $asm.$cls(`$ftPx.LCCLCS.IComunityLoanManagementRemoteService`, ($self) => class IComunityLoanManagementRemoteService
        {
            static $h = 1416233;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1416233,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.ICreateDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.IReadDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.IReadManyDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.IUpdateDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.IDeleteDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Services.IComunityLoanManagementRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Services${separator}IComunityLoanManagementRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1416233)
        
        

        //--TRIMMABLE-BOUNDARY-START(1481769)
        $asm.$cls(`$ftPx.LCCLCS.IComunityLoanManagementRemoteService_Mocking`, ($self) => class IComunityLoanManagementRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296449065)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296449065);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296449065)
            
            //--TRIMMABLE-BOUNDARY-START(8591416361)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$LoanManagement$Common$Models$CommunityLoanManagementLoanModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591416361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591416361)
            
            //--TRIMMABLE-BOUNDARY-START(17181350953)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$LoanManagement$Common$Models$CommunityLoanManagementLoanModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181350953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181350953)
            
            //--TRIMMABLE-BOUNDARY-START(21476318249)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$LoanManagement$Common$Models$CommunityLoanManagementLoanModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476318249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.WireTransportModel$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476318249)
            
            //--TRIMMABLE-BOUNDARY-START(25771285545)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$LoanManagement$Common$Models$CommunityLoanManagementLoanModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771285545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771285545)
            
            //--TRIMMABLE-BOUNDARY-START(12886383657)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886383657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886383657)
            
            static $h = 1481769;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296449065),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1481769,
      "h": 4296449065,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296449065)
  ],
  "h": 1481769
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$ftPx.LCCLCS.IComunityLoanManagementRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.ICreateDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.IReadDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.IReadManyDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.IUpdateDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD.IDeleteDataService$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Services.IComunityLoanManagementRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Services${separator}IComunityLoanManagementRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1481769)
        
        

        //--TRIMMABLE-BOUNDARY-START(891945)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementLoanModelTypeDescriptor`, ($self) => class CommunityLoanManagementLoanModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295859241)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295859241);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ftPx.LCCLCM.CommunityLoanManagementLoanModelTypeDescriptor.GenerateProperties($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel, this, factory);
                    }, $InIpmh ??= {"r":65537,"n":"","d":891945,"h":0,"f":17825794}), 0, "CommunityLoanManagementLoanModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.LoanManagement.Common\\Models_CommunityLoanManagementLoanModel_LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModelTypeDescriptorBuilder.g.cs", "CommunityLoanManagementLoanModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295859241)
            
            //--TRIMMABLE-BOUNDARY-START(12885793833)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885793833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ftPx.LCCLCM.CommunityLoanManagementLoanModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel)).Type);
                        }, $MCOBMh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":891945,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885793833)
            
            //--TRIMMABLE-BOUNDARY-START(17180761129)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180761129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanCategoryModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180761129)
            
            //--TRIMMABLE-BOUNDARY-START(8590826537)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590826537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel)))
                {
                    /*var*/ let result = $.$ftPx.LCCLCM.CommunityLoanManagementLoanModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590826537)
            
            static $h = 891945;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885793833),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 891945,
      "h": 12885793833,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885793833),
//--TRIMMABLE-BOUNDARY-START(17180761129),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 760873,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 891945,
      "h": 17180761129,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180761129),
//--TRIMMABLE-BOUNDARY-START(8590826537),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 760873,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 891945,
      "h": 8590826537,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590826537)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295859241),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 891945,
      "h": 4295859241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295859241)
  ],
  "h": 891945
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementLoanModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(891945)
        
        

        //--TRIMMABLE-BOUNDARY-START(629801)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModelTypeDescriptor`, ($self) => class CommunityLoanManagementLoanCategoryModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295597097)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295597097);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModelTypeDescriptor.GenerateProperties($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, this, factory);
                    }, $qWayJe ??= {"r":65537,"n":"","d":629801,"h":0,"f":17825794}), 0, "CommunityLoanManagementLoanCategoryModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.LoanManagement.Common\\Models_CommunityLoanManagementLoanCategoryModel_LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanCategoryModelTypeDescriptorBuilder.g.cs", "CommunityLoanManagementLoanCategoryModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295597097)
            
            //--TRIMMABLE-BOUNDARY-START(12885531689)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885531689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanCategoryModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel)).Type);
                        }, $ZrVRsb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":629801,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885531689)
            
            //--TRIMMABLE-BOUNDARY-START(17180498985)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanCategoryModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180498985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanCategoryModel, LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, $.$ftPx.LCCLCM.CommunityLoanManagementLoanModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180498985)
            
            //--TRIMMABLE-BOUNDARY-START(8590564393)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanCategoryModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590564393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel)))
                {
                    /*var*/ let result = $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590564393)
            
            static $h = 629801;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885531689),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 629801,
      "h": 12885531689,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885531689),
//--TRIMMABLE-BOUNDARY-START(17180498985),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 498729,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 629801,
      "h": 17180498985,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180498985),
//--TRIMMABLE-BOUNDARY-START(8590564393),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 498729,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 629801,
      "h": 8590564393,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590564393)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295597097),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 629801,
      "h": 4295597097,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295597097)
  ],
  "h": 629801
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementLoanCategoryModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementLoanCategoryModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementLoanCategoryModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(629801)
        
        

        //--TRIMMABLE-BOUNDARY-START(1023017)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementModel`, ($self) => class CommunityLoanManagementModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$ftPx.LCCLCS$1.CommunityLoanManagementSettings, $.$ftPx.LCCLCS$2.CommunityLoanManagementStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295990313)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295990313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295990313)
            
            //--TRIMMABLE-BOUNDARY-START(4295990313)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295990313)
            
            static $h = 1023017;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$ftPx.LCCLCS$1.CommunityLoanManagementSettings, $.$ftPx.LCCLCS$2.CommunityLoanManagementStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295990313),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1023017,
      "h": 4295990313,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295990313)
  ],
  "h": 1023017
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1023017)
        
        

        //--TRIMMABLE-BOUNDARY-START(1154089)
        $asm.$cls(`$ftPx.LCCLCM.CommunityLoanManagementModelTypeDescriptor`, ($self) => class CommunityLoanManagementModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296121385)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296121385);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ftPx.LCCLCM.CommunityLoanManagementModelTypeDescriptor.GenerateProperties($.$ftPx.LCCLCM.CommunityLoanManagementModel, this, factory);
                    }, $kIAbeh ??= {"r":65537,"n":"","d":1154089,"h":0,"f":17825794}), 0, "CommunityLoanManagementModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.LoanManagement.Common\\Models_CommunityLoanManagementModel_LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementModelTypeDescriptorBuilder.g.cs", "CommunityLoanManagementModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296121385)
            
            //--TRIMMABLE-BOUNDARY-START(12886055977)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886055977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$ftPx.LCCLCS$1.CommunityLoanManagementSettings, $.$ftPx.LCCLCS$2.CommunityLoanManagementStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886055977)
            
            //--TRIMMABLE-BOUNDARY-START(17181023273)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181023273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.LoanManagement.Common.Settings.CommunityLoanManagementSettings, LivingThing.Core.Community.LoanManagement.Common.States.CommunityLoanManagementStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$ftPx.LCCLCS$1.CommunityLoanManagementSettings, $.$ftPx.LCCLCS$2.CommunityLoanManagementStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$ftPx.LCCLCS$1.CommunityLoanManagementSettings, $.$ftPx.LCCLCS$2.CommunityLoanManagementStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181023273)
            
            //--TRIMMABLE-BOUNDARY-START(8591088681)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591088681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ftPx.LCCLCM.CommunityLoanManagementModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ftPx.LCCLCM.CommunityLoanManagementModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCM.CommunityLoanManagementModel)))
                {
                    /*var*/ let result = $.$ftPx.LCCLCM.CommunityLoanManagementModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCM.CommunityLoanManagementModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ftPx.LCCLCM.CommunityLoanManagementModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ftPx.LCCLCM.CommunityLoanManagementModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591088681)
            
            static $h = 1154089;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886055977),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1154089,
      "h": 12886055977,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886055977),
//--TRIMMABLE-BOUNDARY-START(17181023273),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1023017,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1154089,
      "h": 17181023273,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181023273),
//--TRIMMABLE-BOUNDARY-START(8591088681),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1023017,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1154089,
      "h": 8591088681,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591088681)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296121385),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1154089,
      "h": 4296121385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296121385)
  ],
  "h": 1154089
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ftPx.LCCLCM.CommunityLoanManagementModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.LoanManagement.Common.Models.CommunityLoanManagementModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}LoanManagement${separator}Common${separator}Models${separator}CommunityLoanManagementModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1154089)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(39977)
