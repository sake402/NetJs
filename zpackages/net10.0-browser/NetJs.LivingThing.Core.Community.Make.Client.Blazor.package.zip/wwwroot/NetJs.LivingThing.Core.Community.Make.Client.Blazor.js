
//--TRIMMABLE-BOUNDARY-START(17929)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $mMXL) {
    "use strict";
    let _;
    let $GZgxnj;
    let $pUXDqg;
    let $ePxZFg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Make.Client.Blazor", 
    {
  "h": 17929,
  "f": "LivingThing.Core.Community.Make.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Make.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Make.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(149001)
        $asm.$cls(`$IUsF.LCCMC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295116297)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295116297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$IUsF.LCCMC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295116297)
            
            static $h = 149001;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295116297),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 149001,
      "h": 4295116297,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295116297)
  ],
  "h": 149001
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(149001)
        
        

        //--TRIMMABLE-BOUNDARY-START(214537)
        $asm.$cls(`$IUsF.LCCMC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180083721)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$IUsF.LCCMCP.CommunityMakeApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$IUsF.LCCMCP.CommunityMakeApp().$ctor$6();
                    }, $GZgxnj ??= {"r":2752627,"n":"","d":214537,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180083721)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295181833)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295181833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295181833)
            
            //--TRIMMABLE-BOUNDARY-START(4295181833)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295181833)
            
            static $h = 214537;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180083721),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885116425,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 214537,
      "h": 17180083721,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180083721)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295181833),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 214537,
      "h": 4295181833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295181833)
  ],
  "h": 214537
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(214537)
        
        

        //--TRIMMABLE-BOUNDARY-START(345609)
        $asm.$cls(`$IUsF.LCCMC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590280201)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590280201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$IUsF.LCCMCS.CommunityMakeService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$mMXL.LCCMCM.CommunityMakePostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$IUsF.LCCMCS.CommunityMakeApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IUsF.LCCMCS.CommunityMakeApplication, x);
                }, $pUXDqg ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":345609,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IUsF.LCCMCS.CommunityMakeApplication, x);
                }, $ePxZFg ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":345609,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$IUsF.LCCMCS.CommunityMakeFeedProvider, services);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$mMXL.LCCMCM.CommunityMakePostModel, services, null);
                $.$IUsF.LCCMC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590280201)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$IUsF.LCCMC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295312905)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295312905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295312905)
            
            //--TRIMMABLE-BOUNDARY-START(4295312905)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295312905)
            
            static $h = 345609;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590280201),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 345609,
      "h": 8590280201,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590280201)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295312905),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 345609,
      "h": 4295312905,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295312905)
  ],
  "h": 345609
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(345609)
        
        

        //--TRIMMABLE-BOUNDARY-START(607753)
        $asm.$cls(`$IUsF.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295575049)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295575049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295575049)
            
            //--TRIMMABLE-BOUNDARY-START(4295575049)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295575049)
            
            static $h = 607753;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295575049),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 607753,
      "h": 4295575049,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295575049)
  ],
  "h": 607753
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(607753)
        
        

        //--TRIMMABLE-BOUNDARY-START(673289)
        $asm.$cls(`$IUsF.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295640585)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295640585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295640585)
            
            //--TRIMMABLE-BOUNDARY-START(4295640585)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295640585)
            
            static $h = 673289;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295640585),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 673289,
      "h": 4295640585,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295640585)
  ],
  "h": 673289,
  "a": [
    {
      "t": 607753,
      "c": 4295575049
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(673289)
        
        

        //--TRIMMABLE-BOUNDARY-START(83465)
        $asm.$cls(`$IUsF.LCCMC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590018057)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590018057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590018057)
            
            //--TRIMMABLE-BOUNDARY-START(4295050761)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295050761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295050761)
            
            //--TRIMMABLE-BOUNDARY-START(4295050761)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295050761)
            
            static $h = 83465;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590018057),
    {
      "r": 65537,
      "n": "Execute",
      "d": 83465,
      "h": 8590018057,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590018057)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295050761),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 83465,
      "h": 4295050761,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295050761)
  ],
  "h": 83465
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(83465)
        
        

        //--TRIMMABLE-BOUNDARY-START(476681)
        $asm.$cls(`$IUsF.LCCMCS.CommunityMakeFeedProvider`, ($self) => class CommunityMakeFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$mMXL.LCCMCM.CommunityMakePostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295443977)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295443977);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295443977)
            
            //--TRIMMABLE-BOUNDARY-START(8590411273)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityMakePostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590411273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`created an article`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590411273)
            
            static $h = 476681;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$mMXL.LCCMCM.CommunityMakePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590411273),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 750398
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 476681,
      "h": 8590411273,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590411273)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295443977),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 476681,
      "h": 4295443977,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295443977)
  ],
  "h": 476681
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Client.Services.CommunityMakeFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Client${separator}Services${separator}CommunityMakeFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(476681)
        
        

        //--TRIMMABLE-BOUNDARY-START(411145)
        $asm.$cls(`$IUsF.LCCMCS.CommunityMakeApplication`, ($self) => class CommunityMakeApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885313033)
            $ctor$5(/*CommunityMakeService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885313033);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885313033)
            
            //--TRIMMABLE-BOUNDARY-START(137439364617)
            /*string */ get Name()
            {
                return "Make";
            }
            //--TRIMMABLE-BOUNDARY-END(137439364617)
            
            //--TRIMMABLE-BOUNDARY-START(158914201097)
            /*string */ get Title()
            {
                return "Make";
            }
            //--TRIMMABLE-BOUNDARY-END(158914201097)
            
            //--TRIMMABLE-BOUNDARY-START(21475247625)
            /*string */ get Description()
            {
                return "Post a Make agent, send, track and receive a package from the comfort of your phone.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475247625)
            
            //--TRIMMABLE-BOUNDARY-START(133144397321)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-package"/*MaterialDesignIconNames.Package*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144397321)
            
            //--TRIMMABLE-BOUNDARY-START(154619233801)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2E969B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619233801)
            
            //--TRIMMABLE-BOUNDARY-START(30065182217)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065182217)
            
            //--TRIMMABLE-BOUNDARY-START(17180280329)
            /*Type? */ get ApplicationViewType()
            {
                return $.$IUsF.LCCMCP.CommunityMakeApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180280329)
            
            //--TRIMMABLE-BOUNDARY-START(128849430025)
            /*RenderFragment? */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849430025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$IUsF.LCCMCP.CommunityMakeApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849430025)
            
            //--TRIMMABLE-BOUNDARY-START(25770214921)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770214921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770214921)
            
            //--TRIMMABLE-BOUNDARY-START(146029299209)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029299209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029299209)
            
            //--TRIMMABLE-BOUNDARY-START(141734331913)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734331913)
            
            //--TRIMMABLE-BOUNDARY-START(4295378441)
            /*CommunityMakeService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295378441)
            
            //--TRIMMABLE-BOUNDARY-START(150324266505)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(150324266505)
            
            //--TRIMMABLE-BOUNDARY-START(163209168393)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(7936/*PostTypes.Make*/, 7939/*PostTypes.MakeEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209168393)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 411145;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439364617),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604789769,
        "f": 50364417
      },
      "n": "Name",
      "d": 411145,
      "h": 137439364617,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439364617),
//--TRIMMABLE-BOUNDARY-START(158914201097),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964528137,
        "f": 50364417
      },
      "n": "Title",
      "d": 411145,
      "h": 158914201097,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914201097),
//--TRIMMABLE-BOUNDARY-START(21475247625),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834985993,
        "f": 50364417
      },
      "n": "Description",
      "d": 411145,
      "h": 21475247625,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475247625),
//--TRIMMABLE-BOUNDARY-START(133144397321),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014855177,
        "f": 50364417
      },
      "n": "Icon",
      "d": 411145,
      "h": 133144397321,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144397321),
//--TRIMMABLE-BOUNDARY-START(154619233801),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374593545,
        "f": 50364417
      },
      "n": "Theme",
      "d": 411145,
      "h": 154619233801,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619233801),
//--TRIMMABLE-BOUNDARY-START(30065182217),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424920585,
        "f": 50364417
      },
      "n": "Features",
      "d": 411145,
      "h": 30065182217,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065182217),
//--TRIMMABLE-BOUNDARY-START(17180280329),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245051401,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 411145,
      "h": 17180280329,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180280329),
//--TRIMMABLE-BOUNDARY-START(141734331913),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194724361,
        "f": 50364417
      },
      "n": "Order",
      "d": 411145,
      "h": 141734331913,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734331913),
//--TRIMMABLE-BOUNDARY-START(4295378441),
    {
      "p": 542217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655116809,
        "f": 50331650
      },
      "n": "_Service",
      "d": 411145,
      "h": 4295378441,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295378441),
//--TRIMMABLE-BOUNDARY-START(150324266505),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784658953,
        "f": 50364417
      },
      "n": "Service",
      "d": 411145,
      "h": 150324266505,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324266505),
//--TRIMMABLE-BOUNDARY-START(163209168393),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554462729,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 411145,
      "h": 163209168393,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209168393)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849430025),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 411145,
      "h": 128849430025,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849430025),
//--TRIMMABLE-BOUNDARY-START(25770214921),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 411145,
      "h": 25770214921,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770214921),
//--TRIMMABLE-BOUNDARY-START(146029299209),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 411145,
      "h": 146029299209,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029299209)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885313033),
    {
      "p": [
        {
          "n": "service",
          "p": 542217
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 411145,
      "h": 12885313033,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885313033)
  ],
  "h": 411145
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$mMXL.LCCMCM.CommunityMakePostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Client.Services.CommunityMakeApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Client${separator}Services${separator}CommunityMakeApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(411145)
        
        

        //--TRIMMABLE-BOUNDARY-START(280073)
        $asm.$cls(`$IUsF.LCCMCP.CommunityMakeApp`, ($self) => class CommunityMakeApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel, $.$mMXL.LCCMCM.CommunityMakePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$mMXL.LCCMCM.CommunityMakeUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(68719756809)
            /*CommunityMakeService*/ MakeService = null;
            //--TRIMMABLE-BOUNDARY-END(68719756809)
            
            //--TRIMMABLE-BOUNDARY-START(64424789513)
            /*CommunityMakeApplication*/ MakeApplication = null;
            //--TRIMMABLE-BOUNDARY-END(64424789513)
            
            //--TRIMMABLE-BOUNDARY-START(17180149257)
            /*ICommunityClientApplication */ get Application()
            {
                return this.MakeApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(17180149257)
            
            //--TRIMMABLE-BOUNDARY-START(73014724105)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014724105);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.MakeService.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73014724105)
            
            //--TRIMMABLE-BOUNDARY-START(77309691401)
            /*string */ get OptimizedComponentName()
            {
                return "communitymakeapp communitydefaultpages";
            }
            //--TRIMMABLE-BOUNDARY-END(77309691401)
            
            //--TRIMMABLE-BOUNDARY-START(60129822217)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129822217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.MakeService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IUsF.LCCMCS.CommunityMakeService, serviceProvider);
                this.MakeApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IUsF.LCCMCS.CommunityMakeApplication, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(60129822217)
            
            //--TRIMMABLE-BOUNDARY-START(21475116553)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475116553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
            }
            //--TRIMMABLE-BOUNDARY-END(21475116553)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885181961)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885181961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885181961)
            
            //--TRIMMABLE-BOUNDARY-START(12885181961)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12885181961)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(68719756809)
                this.MakeService = null;
                //--TRIMMABLE-BOUNDARY-END(68719756809)
                
                //--TRIMMABLE-BOUNDARY-START(64424789513)
                this.MakeApplication = null;
                //--TRIMMABLE-BOUNDARY-END(64424789513)
                
            }
            static $h = 280073;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel, $.$mMXL.LCCMCM.CommunityMakePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$mMXL.LCCMCM.CommunityMakeUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719756809),
    {
      "p": 542217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244920329,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489560585,
        "f": 83886081
      },
      "n": "MakeService",
      "d": 280073,
      "h": 68719756809,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719756809),
//--TRIMMABLE-BOUNDARY-START(64424789513),
    {
      "p": 411145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654985737,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899625993,
        "f": 83886081
      },
      "n": "MakeApplication",
      "d": 280073,
      "h": 64424789513,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64424789513),
//--TRIMMABLE-BOUNDARY-START(17180149257),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065051145,
        "f": 50364420
      },
      "n": "Application",
      "d": 280073,
      "h": 17180149257,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(17180149257),
//--TRIMMABLE-BOUNDARY-START(77309691401),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834854921,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 280073,
      "h": 77309691401,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77309691401)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73014724105),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 280073,
      "h": 73014724105,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(73014724105),
//--TRIMMABLE-BOUNDARY-START(60129822217),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 280073,
      "h": 60129822217,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60129822217),
//--TRIMMABLE-BOUNDARY-START(21475116553),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 280073,
      "h": 21475116553,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475116553)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885181961),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 280073,
      "h": 12885181961,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885181961)
  ],
  "h": 280073
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Client.Pages.CommunityMakeApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Client${separator}Pages${separator}CommunityMakeApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(280073)
        
        

        //--TRIMMABLE-BOUNDARY-START(542217)
        $asm.$cls(`$IUsF.LCCMCS.CommunityMakeService`, ($self) => class CommunityMakeService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$mMXL.LCCMCM.CommunityMakePostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295509513)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295509513);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295509513)
            
            static $h = 542217;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$mMXL.LCCMCM.CommunityMakePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295509513),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 542217,
      "h": 4295509513,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295509513)
  ],
  "h": 542217
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$mMXL.LCCMCM.CommunityMakePostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$mMXL.LCCMCM.CommunityMakePostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Client.Services.CommunityMakeService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Client${separator}Services${separator}CommunityMakeService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(542217)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Make.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(17929)
