
//--TRIMMABLE-BOUNDARY-START(29502)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $EexaLe;
    let $pkDEza;
    let $xvBMCd;
    let $fGVFbk;
    let $rdjyAg;
    let $MpKrjh;
    let $kZHKfh;
    let $RoRZCd;
    let $ubZQbc;
    let $CmqxUf;
    let $aStqGh;
    let $vtxmmb;
    let $UcRuif;
    let $VDWdzb;
    let $gnSnqj;
    let $XPaVeg;
    let $WBpuOb;
    let $WfkAsk;
    let $xxgGCk;
    let $EPPYqd;
    let $lDpXgk;
    let $kqcAtc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Make.Common", 
    {
  "h": 29502,
  "f": "LivingThing.Core.Community.Make.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Make.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Make.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(291646)
        $asm.$cls(`$mMXL.LCCMCM.CommunityMakeCategoryModelCustomAttributesProvider`, ($self) => class CommunityMakeCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295258942)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295258942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel, $.$mMXL.LCCMCM.CommunityMakePostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295258942)
            
            static $h = 291646;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295258942),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 291646,
      "h": 4295258942,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295258942)
  ],
  "h": 291646
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Models.CommunityMakeCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Models${separator}CommunityMakeCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(291646)
        
        

        //--TRIMMABLE-BOUNDARY-START(815934)
        $asm.$cls(`$mMXL.LCCMCM.CommunityMakePostModelCustomAttributesProvider`, ($self) => class CommunityMakePostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295783230)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295783230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295783230)
            
            static $h = 815934;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295783230),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 815934,
      "h": 4295783230,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295783230)
  ],
  "h": 815934
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Models${separator}CommunityMakePostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(815934)
        
        

        //--TRIMMABLE-BOUNDARY-START(553790)
        $asm.$cls(`$mMXL.LCCMCM.CommunityMakeModelCustomAttributesProvider`, ($self) => class CommunityMakeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295521086)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295521086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$mMXL.LCCMCS$1.CommunityMakeSettings, $.$mMXL.LCCMCS$2.CommunityMakeStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295521086)
            
            static $h = 553790;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295521086),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 553790,
      "h": 4295521086,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295521086)
  ],
  "h": 553790
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Models.CommunityMakeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Models${separator}CommunityMakeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(553790)
        
        

        //--TRIMMABLE-BOUNDARY-START(1733438)
        $asm.$cls(`$mMXL.LCCMCS$2.CommunityMakeStatesCustomAttributesProvider`, ($self) => class CommunityMakeStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296700734)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296700734);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296700734)
            
            static $h = 1733438;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296700734),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1733438,
      "h": 4296700734,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296700734)
  ],
  "h": 1733438
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.States.CommunityMakeStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}States${separator}CommunityMakeStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1733438)
        
        

        //--TRIMMABLE-BOUNDARY-START(1930046)
        $asm.$cls(`$mMXL.LCCMC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296897342)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296897342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mMXL.LCCMCM.CommunityMakeCategoryModelTypeDescriptorBuilder.Register();
                $.$mMXL.LCCMCM.CommunityMakeModelTypeDescriptorBuilder.Register();
                $.$mMXL.LCCMCM.CommunityMakePostModelTypeDescriptorBuilder.Register();
                $.$mMXL.LCCMCS$1.CommunityMakeSettingsTypeDescriptorBuilder.Register();
                $.$mMXL.LCCMCS$2.CommunityMakeStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296897342)
            
            static $h = 1930046;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296897342),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1930046,
      "h": 4296897342,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296897342)
  ],
  "h": 1930046
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1930046)
        
        

        //--TRIMMABLE-BOUNDARY-START(1864510)
        $asm.$cls(`$mMXL.LCCMCS$2.CommunityMakeStatesTypeDescriptorBuilder`, ($self) => class CommunityMakeStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591799102)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591799102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mMXL.LCCMCS$2.CommunityMakeStatesTypeDescriptor()
                        const $t1 = $.$mMXL.LCCMCS$2.CommunityMakeStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Make.Common.States.CommunityMakeStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $xvBMCd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1864510,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mMXL.LCCMCS$2.CommunityMakeStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591799102)
            
            //--TRIMMABLE-BOUNDARY-START(4296831806)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296831806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296831806)
            
            //--TRIMMABLE-BOUNDARY-START(4296831806)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296831806)
            
            static $h = 1864510;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591799102),
    {
      "r": 65537,
      "n": "Register",
      "d": 1864510,
      "h": 8591799102,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591799102)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296831806),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1864510,
      "h": 4296831806,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296831806)
  ],
  "h": 1864510
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.States.CommunityMakeStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}States${separator}CommunityMakeStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1864510)
        
        

        //--TRIMMABLE-BOUNDARY-START(422718)
        $asm.$cls(`$mMXL.LCCMCM.CommunityMakeCategoryModelTypeDescriptorBuilder`, ($self) => class CommunityMakeCategoryModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590357310)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590357310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mMXL.LCCMCM.CommunityMakeCategoryModelTypeDescriptor()
                        const $t1 = $.$mMXL.LCCMCM.CommunityMakeCategoryModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Make.Common.Models.CommunityMakeCategoryModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $EPPYqd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":422718,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mMXL.LCCMCM.CommunityMakeCategoryModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590357310)
            
            //--TRIMMABLE-BOUNDARY-START(4295390014)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295390014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295390014)
            
            //--TRIMMABLE-BOUNDARY-START(4295390014)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295390014)
            
            static $h = 422718;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590357310),
    {
      "r": 65537,
      "n": "Register",
      "d": 422718,
      "h": 8590357310,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590357310)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295390014),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 422718,
      "h": 4295390014,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295390014)
  ],
  "h": 422718
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Models.CommunityMakeCategoryModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Models${separator}CommunityMakeCategoryModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(422718)
        
        

        //--TRIMMABLE-BOUNDARY-START(95038)
        $asm.$cls(`$mMXL.LCCMC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295062334)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295062334);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mMXL.LCCMCM.CommunityMakeCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mMXL.LCCMCM.CommunityMakeCategoryModelCustomAttributesProvider, $.$mMXL.LCCMCM.CommunityMakeCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mMXL.LCCMCM.CommunityMakeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mMXL.LCCMCM.CommunityMakeModelCustomAttributesProvider, $.$mMXL.LCCMCM.CommunityMakeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mMXL.LCCMCM.CommunityMakePostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mMXL.LCCMCM.CommunityMakePostModelCustomAttributesProvider, $.$mMXL.LCCMCM.CommunityMakePostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mMXL.LCCMCS$1.CommunityMakeSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mMXL.LCCMCS$1.CommunityMakeSettingsCustomAttributesProvider, $.$mMXL.LCCMCS$1.CommunityMakeSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mMXL.LCCMCS$2.CommunityMakeStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mMXL.LCCMCS$2.CommunityMakeStatesCustomAttributesProvider, $.$mMXL.LCCMCS$2.CommunityMakeStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295062334)
            
            static $h = 95038;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295062334),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 95038,
      "h": 4295062334,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295062334)
  ],
  "h": 95038
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(95038)
        
        

        //--TRIMMABLE-BOUNDARY-START(947006)
        $asm.$cls(`$mMXL.LCCMCM.CommunityMakePostModelTypeDescriptorBuilder`, ($self) => class CommunityMakePostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590881598)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590881598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mMXL.LCCMCM.CommunityMakePostModelTypeDescriptor()
                        const $t1 = $.$mMXL.LCCMCM.CommunityMakePostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $WBpuOb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":947006,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mMXL.LCCMCM.CommunityMakePostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590881598)
            
            //--TRIMMABLE-BOUNDARY-START(4295914302)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295914302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295914302)
            
            //--TRIMMABLE-BOUNDARY-START(4295914302)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295914302)
            
            static $h = 947006;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590881598),
    {
      "r": 65537,
      "n": "Register",
      "d": 947006,
      "h": 8590881598,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590881598)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295914302),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 947006,
      "h": 4295914302,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295914302)
  ],
  "h": 947006
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Models${separator}CommunityMakePostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(947006)
        
        

        //--TRIMMABLE-BOUNDARY-START(1602366)
        $asm.$cls(`$mMXL.LCCMCS$1.CommunityMakeSettingsTypeDescriptorBuilder`, ($self) => class CommunityMakeSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591536958)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591536958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mMXL.LCCMCS$1.CommunityMakeSettingsTypeDescriptor()
                        const $t1 = $.$mMXL.LCCMCS$1.CommunityMakeSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Make.Common.Settings.CommunityMakeSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $EexaLe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1602366,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mMXL.LCCMCS$1.CommunityMakeSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591536958)
            
            //--TRIMMABLE-BOUNDARY-START(4296569662)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296569662);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296569662)
            
            //--TRIMMABLE-BOUNDARY-START(4296569662)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296569662)
            
            static $h = 1602366;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591536958),
    {
      "r": 65537,
      "n": "Register",
      "d": 1602366,
      "h": 8591536958,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591536958)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296569662),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1602366,
      "h": 4296569662,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296569662)
  ],
  "h": 1602366
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Settings.CommunityMakeSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Settings${separator}CommunityMakeSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1602366)
        
        

        //--TRIMMABLE-BOUNDARY-START(160574)
        $asm.$cls(`$mMXL.LCCMC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295127870)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295127870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$mMXL.LCCMCS.ICommunityMakeFeedRemoteService, $.$mMXL.LCCMCS.ICommunityMakeFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$mMXL.LCCMCS.ICommunityMakeFeedRemoteService_Mocking().$ctor$3(impl);
                }, $kZHKfh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160574,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$mMXL.LCCMCS.ICommunityMakeFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mMXL.LCCMCS.ICommunityMakeFeedRemoteService_Mocking().$ctor$3(impl);
                }, $RoRZCd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160574,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$mMXL.LCCMCS.IComunityMakeRemoteService, $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking().$ctor$3(impl);
                }, $ubZQbc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160574,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking().$ctor$3(impl);
                }, $CmqxUf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160574,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking().$ctor$3(impl);
                }, $aStqGh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160574,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking().$ctor$3(impl);
                }, $vtxmmb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160574,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking().$ctor$3(impl);
                }, $UcRuif ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160574,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking().$ctor$3(impl);
                }, $VDWdzb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160574,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking().$ctor$3(impl);
                }, $gnSnqj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160574,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking().$ctor$3(impl);
                }, $XPaVeg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":160574,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295127870)
            
            static $h = 160574;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295127870),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 160574,
      "h": 4295127870,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295127870)
  ],
  "h": 160574
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(160574)
        
        

        //--TRIMMABLE-BOUNDARY-START(1471294)
        $asm.$cls(`$mMXL.LCCMCS$1.CommunityMakeSettingsCustomAttributesProvider`, ($self) => class CommunityMakeSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296438590)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296438590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296438590)
            
            static $h = 1471294;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296438590),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1471294,
      "h": 4296438590,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296438590)
  ],
  "h": 1471294
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Settings.CommunityMakeSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Settings${separator}CommunityMakeSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1471294)
        
        

        //--TRIMMABLE-BOUNDARY-START(684862)
        $asm.$cls(`$mMXL.LCCMCM.CommunityMakeModelTypeDescriptorBuilder`, ($self) => class CommunityMakeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590619454)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590619454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mMXL.LCCMCM.CommunityMakeModelTypeDescriptor()
                        const $t1 = $.$mMXL.LCCMCM.CommunityMakeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Make.Common.Models.CommunityMakeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $rdjyAg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":684862,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mMXL.LCCMCM.CommunityMakeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590619454)
            
            //--TRIMMABLE-BOUNDARY-START(4295652158)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295652158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295652158)
            
            //--TRIMMABLE-BOUNDARY-START(4295652158)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295652158)
            
            static $h = 684862;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590619454),
    {
      "r": 65537,
      "n": "Register",
      "d": 684862,
      "h": 8590619454,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590619454)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295652158),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 684862,
      "h": 4295652158,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295652158)
  ],
  "h": 684862
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Models.CommunityMakeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Models${separator}CommunityMakeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(684862)
        
        

        //--TRIMMABLE-BOUNDARY-START(1078078)
        $asm.$cls(`$mMXL.LCCMC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591012670)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591012670);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$mMXL.LCCMCM.CommunityMakeCategoryModel, 7937/*PostTypes.MakeCategory*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$mMXL.LCCMCM.CommunityMakePostModel, 7938/*PostTypes.MakePost*/);
                $.$mMXL.LCCMC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$mMXL.LCCMC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$mMXL.LCCMC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591012670)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mMXL.LCCMC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296045374)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296045374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296045374)
            
            //--TRIMMABLE-BOUNDARY-START(4296045374)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296045374)
            
            static $h = 1078078;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591012670),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1078078,
      "h": 8591012670,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591012670)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296045374),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1078078,
      "h": 4296045374,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296045374)
  ],
  "h": 1078078
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1078078)
        
        

        //--TRIMMABLE-BOUNDARY-START(1012542)
        $asm.$cls(`$mMXL.LCCMCM.CommunityMakeUserPreference`, ($self) => class CommunityMakeUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4295979838)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295979838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295979838)
            
            //--TRIMMABLE-BOUNDARY-START(4295979838)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295979838)
            
            static $h = 1012542;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295979838),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1012542,
      "h": 4295979838,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295979838)
  ],
  "h": 1012542
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Models.CommunityMakeUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Models${separator}CommunityMakeUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1012542)
        
        

        //--TRIMMABLE-BOUNDARY-START(1667902)
        $asm.$cls(`$mMXL.LCCMCS$2.CommunityMakeStates`, ($self) => class CommunityMakeStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296635198)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296635198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296635198)
            
            //--TRIMMABLE-BOUNDARY-START(4296635198)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296635198)
            
            static $h = 1667902;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296635198),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1667902,
      "h": 4296635198,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296635198)
  ],
  "h": 1667902
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.States.CommunityMakeStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}States${separator}CommunityMakeStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1667902)
        
        

        //--TRIMMABLE-BOUNDARY-START(1405758)
        $asm.$cls(`$mMXL.LCCMCS$1.CommunityMakeSettings`, ($self) => class CommunityMakeSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296373054)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296373054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296373054)
            
            //--TRIMMABLE-BOUNDARY-START(4296373054)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296373054)
            
            static $h = 1405758;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296373054),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1405758,
      "h": 4296373054,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296373054)
  ],
  "h": 1405758
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Settings.CommunityMakeSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Settings${separator}CommunityMakeSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1405758)
        
        

        //--TRIMMABLE-BOUNDARY-START(1536830)
        $asm.$cls(`$mMXL.LCCMCS$1.CommunityMakeSettingsTypeDescriptor`, ($self) => class CommunityMakeSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mMXL.LCCMCS$1.CommunityMakeSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296504126)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296504126);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mMXL.LCCMCS$1.CommunityMakeSettingsTypeDescriptor.GenerateProperties($.$mMXL.LCCMCS$1.CommunityMakeSettings, this, factory);
                    }, $pkDEza ??= {"r":65537,"n":"","d":1536830,"h":0,"f":17825794}), 0, "CommunityMakeSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Make.Common\\Settings_CommunityMakeSettings_LivingThing.Core.Community.Make.Common.Settings.CommunityMakeSettingsTypeDescriptorBuilder.g.cs", "CommunityMakeSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296504126)
            
            //--TRIMMABLE-BOUNDARY-START(12886438718)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886438718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886438718)
            
            //--TRIMMABLE-BOUNDARY-START(17181406014)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Make.Common.Settings.CommunityMakeSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181406014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181406014)
            
            //--TRIMMABLE-BOUNDARY-START(8591471422)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Make.Common.Settings.CommunityMakeSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591471422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mMXL.LCCMCS$1.CommunityMakeSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mMXL.LCCMCS$1.CommunityMakeSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCS$1.CommunityMakeSettings)))
                {
                    /*var*/ let result = $.$mMXL.LCCMCS$1.CommunityMakeSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCS$1.CommunityMakeSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mMXL.LCCMCS$1.CommunityMakeSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCS$1.CommunityMakeSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591471422)
            
            static $h = 1536830;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mMXL.LCCMCS$1.CommunityMakeSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886438718),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1536830,
      "h": 12886438718,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886438718),
//--TRIMMABLE-BOUNDARY-START(17181406014),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1405758,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1536830,
      "h": 17181406014,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181406014),
//--TRIMMABLE-BOUNDARY-START(8591471422),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1405758,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1536830,
      "h": 8591471422,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591471422)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296504126),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1536830,
      "h": 4296504126,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296504126)
  ],
  "h": 1536830
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mMXL.LCCMCS$1.CommunityMakeSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Settings.CommunityMakeSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Settings${separator}CommunityMakeSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1536830)
        
        

        //--TRIMMABLE-BOUNDARY-START(1798974)
        $asm.$cls(`$mMXL.LCCMCS$2.CommunityMakeStatesTypeDescriptor`, ($self) => class CommunityMakeStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mMXL.LCCMCS$2.CommunityMakeStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296766270)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296766270);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mMXL.LCCMCS$2.CommunityMakeStatesTypeDescriptor.GenerateProperties($.$mMXL.LCCMCS$2.CommunityMakeStates, this, factory);
                    }, $fGVFbk ??= {"r":65537,"n":"","d":1798974,"h":0,"f":17825794}), 0, "CommunityMakeStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Make.Common\\States_CommunityMakeStates_LivingThing.Core.Community.Make.Common.States.CommunityMakeStatesTypeDescriptorBuilder.g.cs", "CommunityMakeStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296766270)
            
            //--TRIMMABLE-BOUNDARY-START(12886700862)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886700862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886700862)
            
            //--TRIMMABLE-BOUNDARY-START(17181668158)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Make.Common.States.CommunityMakeStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181668158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181668158)
            
            //--TRIMMABLE-BOUNDARY-START(8591733566)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Make.Common.States.CommunityMakeStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591733566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mMXL.LCCMCS$2.CommunityMakeStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mMXL.LCCMCS$2.CommunityMakeStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCS$2.CommunityMakeStates)))
                {
                    /*var*/ let result = $.$mMXL.LCCMCS$2.CommunityMakeStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCS$2.CommunityMakeStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mMXL.LCCMCS$2.CommunityMakeStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCS$2.CommunityMakeStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591733566)
            
            static $h = 1798974;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mMXL.LCCMCS$2.CommunityMakeStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886700862),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1798974,
      "h": 12886700862,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886700862),
//--TRIMMABLE-BOUNDARY-START(17181668158),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1667902,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1798974,
      "h": 17181668158,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181668158),
//--TRIMMABLE-BOUNDARY-START(8591733566),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1667902,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1798974,
      "h": 8591733566,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591733566)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296766270),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1798974,
      "h": 4296766270,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296766270)
  ],
  "h": 1798974
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mMXL.LCCMCS$2.CommunityMakeStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.States.CommunityMakeStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}States${separator}CommunityMakeStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1798974)
        
        

        $asm.$typeProxy("$mMXL.LCCMCM.CommunityMakeCategoryModel", "$mMXL.LivingThing.Core.Community.Make.Common.Models.CommunityMakeCategoryModel");
        //--TRIMMABLE-BOUNDARY-START(750398)
        $asm.$cls(`$mMXL.LCCMCM.CommunityMakePostModel`, ($self) => class CommunityMakePostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180619582)
            /*PostTypes */ get Type()
            {
                return 7938/*PostTypes.MakePost*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180619582)
            
            //--TRIMMABLE-BOUNDARY-START(4295717694)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295717694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295717694)
            
            //--TRIMMABLE-BOUNDARY-START(4295717694)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295717694)
            
            static $h = 750398;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180619582),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885652286,
        "f": 50364417
      },
      "n": "Type",
      "d": 750398,
      "h": 17180619582,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180619582)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295717694),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 750398,
      "h": 4295717694,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295717694)
  ],
  "h": 750398
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Models${separator}CommunityMakePostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(750398)
        
        

        //--TRIMMABLE-BOUNDARY-START(226110)
        $asm.$cls(`$mMXL.LCCMCM.CommunityMakeCategoryModel`, ($self) => class CommunityMakeCategoryModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$mMXL.LCCMCM.CommunityMakePostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180095294)
            /*PostTypes */ get Type()
            {
                return 7937/*PostTypes.MakeCategory*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180095294)
            
            //--TRIMMABLE-BOUNDARY-START(4295193406)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295193406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295193406)
            
            //--TRIMMABLE-BOUNDARY-START(4295193406)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295193406)
            
            static $h = 226110;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel, $.$mMXL.LCCMCM.CommunityMakePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180095294),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885127998,
        "f": 50364417
      },
      "n": "Type",
      "d": 226110,
      "h": 17180095294,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180095294)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295193406),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 226110,
      "h": 4295193406,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295193406)
  ],
  "h": 226110
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Models.CommunityMakeCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Models${separator}CommunityMakeCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(226110)
        
        

        //--TRIMMABLE-BOUNDARY-START(1143614)
        $asm.$cls(`$mMXL.LCCMCS.ICommunityMakeFeedRemoteService`, ($self) => class ICommunityMakeFeedRemoteService
        {
            static $h = 1143614;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1143614,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Services.ICommunityMakeFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Services${separator}ICommunityMakeFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1143614)
        
        

        //--TRIMMABLE-BOUNDARY-START(1274686)
        $asm.$cls(`$mMXL.LCCMCS.IComunityMakeRemoteService`, ($self) => class IComunityMakeRemoteService
        {
            static $h = 1274686;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1274686,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.ICreateDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.IReadDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Services.IComunityMakeRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Services${separator}IComunityMakeRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1274686)
        
        

        //--TRIMMABLE-BOUNDARY-START(1209150)
        $asm.$cls(`$mMXL.LCCMCS.ICommunityMakeFeedRemoteService_Mocking`, ($self) => class ICommunityMakeFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296176446)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296176446);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296176446)
            
            //--TRIMMABLE-BOUNDARY-START(8591143742)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Make$Common$Models$CommunityMakePostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591143742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$mMXL.LCCMCM.CommunityMakePostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$mMXL.LCCMCM.CommunityMakePostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591143742)
            
            static $h = 1209150;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296176446),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1209150,
      "h": 4296176446,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296176446)
  ],
  "h": 1209150
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$mMXL.LCCMCS.ICommunityMakeFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Services.ICommunityMakeFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Services${separator}ICommunityMakeFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1209150)
        
        

        //--TRIMMABLE-BOUNDARY-START(1340222)
        $asm.$cls(`$mMXL.LCCMCS.IComunityMakeRemoteService_Mocking`, ($self) => class IComunityMakeRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296307518)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296307518);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296307518)
            
            //--TRIMMABLE-BOUNDARY-START(8591274814)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Make$Common$Models$CommunityMakePostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591274814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$mMXL.LCCMCM.CommunityMakePostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$mMXL.LCCMCM.CommunityMakePostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591274814)
            
            //--TRIMMABLE-BOUNDARY-START(17181209406)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Make$Common$Models$CommunityMakePostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181209406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$mMXL.LCCMCM.CommunityMakePostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$mMXL.LCCMCM.CommunityMakePostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181209406)
            
            //--TRIMMABLE-BOUNDARY-START(21476176702)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Make$Common$Models$CommunityMakePostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476176702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$mMXL.LCCMCM.CommunityMakePostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.WireTransportModel$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$mMXL.LCCMCM.CommunityMakePostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476176702)
            
            //--TRIMMABLE-BOUNDARY-START(25771143998)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Make$Common$Models$CommunityMakePostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771143998);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$mMXL.LCCMCM.CommunityMakePostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$mMXL.LCCMCM.CommunityMakePostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771143998)
            
            //--TRIMMABLE-BOUNDARY-START(12886242110)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886242110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$mMXL.LCCMCM.CommunityMakePostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886242110)
            
            static $h = 1340222;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296307518),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1340222,
      "h": 4296307518,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296307518)
  ],
  "h": 1340222
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$mMXL.LCCMCS.IComunityMakeRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.ICreateDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.IReadDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Services.IComunityMakeRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Services${separator}IComunityMakeRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1340222)
        
        

        //--TRIMMABLE-BOUNDARY-START(881470)
        $asm.$cls(`$mMXL.LCCMCM.CommunityMakePostModelTypeDescriptor`, ($self) => class CommunityMakePostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mMXL.LCCMCM.CommunityMakePostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295848766)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295848766);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mMXL.LCCMCM.CommunityMakePostModelTypeDescriptor.GenerateProperties($.$mMXL.LCCMCM.CommunityMakePostModel, this, factory);
                    }, $WfkAsk ??= {"r":65537,"n":"","d":881470,"h":0,"f":17825794}), 0, "CommunityMakePostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Make.Common\\Models_CommunityMakePostModel_LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModelTypeDescriptorBuilder.g.cs", "CommunityMakePostModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295848766)
            
            //--TRIMMABLE-BOUNDARY-START(12885783358)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885783358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mMXL.LCCMCM.CommunityMakePostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mMXL.LCCMCM.CommunityMakePostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$mMXL.LCCMCM.CommunityMakePostModel)).Type);
                        }, $xxgGCk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":881470,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885783358)
            
            //--TRIMMABLE-BOUNDARY-START(17180750654)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180750654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.Make.Common.Models.CommunityMakeCategoryModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180750654)
            
            //--TRIMMABLE-BOUNDARY-START(8590816062)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590816062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mMXL.LCCMCM.CommunityMakePostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mMXL.LCCMCM.CommunityMakePostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCM.CommunityMakePostModel)))
                {
                    /*var*/ let result = $.$mMXL.LCCMCM.CommunityMakePostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCM.CommunityMakePostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mMXL.LCCMCM.CommunityMakePostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCM.CommunityMakePostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590816062)
            
            static $h = 881470;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mMXL.LCCMCM.CommunityMakePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885783358),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 881470,
      "h": 12885783358,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885783358),
//--TRIMMABLE-BOUNDARY-START(17180750654),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 750398,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 881470,
      "h": 17180750654,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180750654),
//--TRIMMABLE-BOUNDARY-START(8590816062),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 750398,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 881470,
      "h": 8590816062,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590816062)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295848766),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 881470,
      "h": 4295848766,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295848766)
  ],
  "h": 881470
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mMXL.LCCMCM.CommunityMakePostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Models${separator}CommunityMakePostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(881470)
        
        

        //--TRIMMABLE-BOUNDARY-START(357182)
        $asm.$cls(`$mMXL.LCCMCM.CommunityMakeCategoryModelTypeDescriptor`, ($self) => class CommunityMakeCategoryModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295324478)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295324478);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mMXL.LCCMCM.CommunityMakeCategoryModelTypeDescriptor.GenerateProperties($.$mMXL.LCCMCM.CommunityMakeCategoryModel, this, factory);
                    }, $lDpXgk ??= {"r":65537,"n":"","d":357182,"h":0,"f":17825794}), 0, "CommunityMakeCategoryModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Make.Common\\Models_CommunityMakeCategoryModel_LivingThing.Core.Community.Make.Common.Models.CommunityMakeCategoryModelTypeDescriptorBuilder.g.cs", "CommunityMakeCategoryModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295324478)
            
            //--TRIMMABLE-BOUNDARY-START(12885259070)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885259070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mMXL.LCCMCM.CommunityMakeCategoryModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Make.Common.Models.CommunityMakeCategoryModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mMXL.LCCMCM.CommunityMakeCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$mMXL.LCCMCM.CommunityMakeCategoryModel)).Type);
                        }, $kqcAtc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":357182,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel, $.$mMXL.LCCMCM.CommunityMakePostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885259070)
            
            //--TRIMMABLE-BOUNDARY-START(17180226366)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Make.Common.Models.CommunityMakeCategoryModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180226366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.Make.Common.Models.CommunityMakeCategoryModel, LivingThing.Core.Community.Make.Common.Models.CommunityMakePostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel, $.$mMXL.LCCMCM.CommunityMakePostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel, $.$mMXL.LCCMCM.CommunityMakePostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180226366)
            
            //--TRIMMABLE-BOUNDARY-START(8590291774)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Make.Common.Models.CommunityMakeCategoryModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590291774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mMXL.LCCMCM.CommunityMakeCategoryModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mMXL.LCCMCM.CommunityMakeCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCM.CommunityMakeCategoryModel)))
                {
                    /*var*/ let result = $.$mMXL.LCCMCM.CommunityMakeCategoryModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCM.CommunityMakeCategoryModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mMXL.LCCMCM.CommunityMakeCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCM.CommunityMakeCategoryModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590291774)
            
            static $h = 357182;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885259070),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 357182,
      "h": 12885259070,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885259070),
//--TRIMMABLE-BOUNDARY-START(17180226366),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 226110,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 357182,
      "h": 17180226366,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180226366),
//--TRIMMABLE-BOUNDARY-START(8590291774),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 226110,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 357182,
      "h": 8590291774,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590291774)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295324478),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 357182,
      "h": 4295324478,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295324478)
  ],
  "h": 357182
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mMXL.LCCMCM.CommunityMakeCategoryModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Models.CommunityMakeCategoryModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Models${separator}CommunityMakeCategoryModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(357182)
        
        

        //--TRIMMABLE-BOUNDARY-START(488254)
        $asm.$cls(`$mMXL.LCCMCM.CommunityMakeModel`, ($self) => class CommunityMakeModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$mMXL.LCCMCS$1.CommunityMakeSettings, $.$mMXL.LCCMCS$2.CommunityMakeStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295455550)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295455550);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295455550)
            
            //--TRIMMABLE-BOUNDARY-START(4295455550)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295455550)
            
            static $h = 488254;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$mMXL.LCCMCS$1.CommunityMakeSettings, $.$mMXL.LCCMCS$2.CommunityMakeStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295455550),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 488254,
      "h": 4295455550,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295455550)
  ],
  "h": 488254
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Models.CommunityMakeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Models${separator}CommunityMakeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(488254)
        
        

        //--TRIMMABLE-BOUNDARY-START(619326)
        $asm.$cls(`$mMXL.LCCMCM.CommunityMakeModelTypeDescriptor`, ($self) => class CommunityMakeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mMXL.LCCMCM.CommunityMakeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295586622)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295586622);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mMXL.LCCMCM.CommunityMakeModelTypeDescriptor.GenerateProperties($.$mMXL.LCCMCM.CommunityMakeModel, this, factory);
                    }, $MpKrjh ??= {"r":65537,"n":"","d":619326,"h":0,"f":17825794}), 0, "CommunityMakeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Make.Common\\Models_CommunityMakeModel_LivingThing.Core.Community.Make.Common.Models.CommunityMakeModelTypeDescriptorBuilder.g.cs", "CommunityMakeModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295586622)
            
            //--TRIMMABLE-BOUNDARY-START(12885521214)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885521214);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$mMXL.LCCMCS$1.CommunityMakeSettings, $.$mMXL.LCCMCS$2.CommunityMakeStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885521214)
            
            //--TRIMMABLE-BOUNDARY-START(17180488510)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Make.Common.Models.CommunityMakeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180488510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Make.Common.Settings.CommunityMakeSettings, LivingThing.Core.Community.Make.Common.States.CommunityMakeStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$mMXL.LCCMCS$1.CommunityMakeSettings, $.$mMXL.LCCMCS$2.CommunityMakeStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$mMXL.LCCMCS$1.CommunityMakeSettings, $.$mMXL.LCCMCS$2.CommunityMakeStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180488510)
            
            //--TRIMMABLE-BOUNDARY-START(8590553918)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Make.Common.Models.CommunityMakeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590553918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mMXL.LCCMCM.CommunityMakeModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mMXL.LCCMCM.CommunityMakeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCM.CommunityMakeModel)))
                {
                    /*var*/ let result = $.$mMXL.LCCMCM.CommunityMakeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCM.CommunityMakeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mMXL.LCCMCM.CommunityMakeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mMXL.LCCMCM.CommunityMakeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590553918)
            
            static $h = 619326;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mMXL.LCCMCM.CommunityMakeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885521214),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 619326,
      "h": 12885521214,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885521214),
//--TRIMMABLE-BOUNDARY-START(17180488510),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 488254,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 619326,
      "h": 17180488510,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180488510),
//--TRIMMABLE-BOUNDARY-START(8590553918),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 488254,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 619326,
      "h": 8590553918,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590553918)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295586622),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 619326,
      "h": 4295586622,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295586622)
  ],
  "h": 619326
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mMXL.LCCMCM.CommunityMakeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Make.Common.Models.CommunityMakeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Make${separator}Common${separator}Models${separator}CommunityMakeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(619326)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(29502)
