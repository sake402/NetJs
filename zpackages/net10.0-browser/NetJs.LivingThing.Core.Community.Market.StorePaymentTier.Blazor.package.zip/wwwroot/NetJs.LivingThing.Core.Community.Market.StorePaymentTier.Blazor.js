
//--TRIMMABLE-BOUNDARY-START(48305)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm, $Fjop, $ljzt, $TLYN, $hDPm, $sZVd, $wtdm, $lJUR, $dgLE, $oUrI) {
    "use strict";
    let _;
    let $adHYYa;
    let $PIyyAe;
    let $bqgTZd;
    let $Gdggrg;
    let $Ewvqea;
    let $ENvTEk;
    let $LAZhfi;
    let $RbQFmk;
    let $wQGbOj;
    let $VWwOkf;
    let $IkTgQh;
    let $UScYla;
    let $dbxonf;
    let $lOeszi;
    let $lAGeed;
    let $ljitXg;
    let $DtvoVj;
    let $wWQwdc;
    let $dmgnbj;
    let $BDQiCi;
    let $AWbQAe;
    let $tjTvNi;
    let $Eydvxb;
    let $otuolb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Market.StorePaymentTier.Blazor", 
    {
  "h": 48305,
  "f": "LivingThing.Core.Community.Market.StorePaymentTier.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Market.StorePaymentTier.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Market.StorePaymentTier.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(244913)
        $asm.$cls(`$JkHl.LCCMS._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295212209)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295212209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$JkHl.LCCMS.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295212209)
            
            static $h = 244913;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295212209),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 244913,
      "h": 4295212209,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295212209)
  ],
  "h": 244913
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Market.StorePaymentTier._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Market${separator}StorePaymentTier${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(244913)
        
        

        //--TRIMMABLE-BOUNDARY-START(113841)
        $asm.$cls(`$JkHl._LCCMSC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295081137)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295081137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295081137)
            
            static $h = 113841;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295081137),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 113841,
      "h": 4295081137,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295081137)
  ],
  "h": 113841
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Market.StorePaymentTier.CommunityMarketShoppingPaymentTierView.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Market${separator}StorePaymentTier${separator}CommunityMarketShoppingPaymentTierView${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(113841)
        
        

        //--TRIMMABLE-BOUNDARY-START(507057)
        $asm.$cls(`$JkHl.LCCMS.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180376241)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$JkHl.LCCMS.CommunityMarketShoppingPaymentTierView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$JkHl.LCCMS.CommunityMarketShoppingPaymentTierView().$ctor$3();
                    }, $adHYYa ??= {"r":2752627,"n":"","d":507057,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180376241)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295474353)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295474353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295474353)
            
            //--TRIMMABLE-BOUNDARY-START(4295474353)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295474353)
            
            static $h = 507057;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180376241),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885408945,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 507057,
      "h": 17180376241,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180376241)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295474353),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 507057,
      "h": 4295474353,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295474353)
  ],
  "h": 507057
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Market.StorePaymentTier.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Market${separator}StorePaymentTier${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(507057)
        
        

        //--TRIMMABLE-BOUNDARY-START(572593)
        $asm.$cls(`$JkHl.LCCMS.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590507185)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590507185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$nYKj.LCFCP.IPaymentTierProvider, $.$JkHl.LCCMS.CommunityMarketShoppingPaymentTierProvider, services);
                $.$JkHl.LCCMS._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590507185)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$JkHl.LCCMS.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295539889)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295539889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295539889)
            
            //--TRIMMABLE-BOUNDARY-START(4295539889)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295539889)
            
            static $h = 572593;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590507185),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 572593,
      "h": 8590507185,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590507185)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295539889),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 572593,
      "h": 4295539889,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295539889)
  ],
  "h": 572593
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Market.StorePaymentTier.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Market${separator}StorePaymentTier${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(572593)
        
        

        //--TRIMMABLE-BOUNDARY-START(441521)
        $asm.$cls(`$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider`, ($self) => class CommunityMarketShoppingStoreCatalogueOrderProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(219043773617)
            /*IClientUnitOfWork*/ unitOfWork = null;
            //--TRIMMABLE-BOUNDARY-END(219043773617)
            
            //--TRIMMABLE-BOUNDARY-START(188979002545)
            /*CommunityMarketShoppingPaymentTierProvider*/ provider = null;
            //--TRIMMABLE-BOUNDARY-END(188979002545)
            
            //--TRIMMABLE-BOUNDARY-START(210453839025)
            /*CommunityMarketProductStoreModel*/ Store = null;
            //--TRIMMABLE-BOUNDARY-END(210453839025)
            
            //--TRIMMABLE-BOUNDARY-START(55835016369)
            /*CatalogueOrderProviderFeatures */ get Features()
            {
                return 1/*CatalogueOrderProviderFeatures.Default*/ & ~1/*CatalogueOrderProviderFeatures.Payment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(55835016369)
            
            //--TRIMMABLE-BOUNDARY-START(42950114481)
            /*Pager<IContact>? */ get Customers()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(42950114481)
            
            //--TRIMMABLE-BOUNDARY-START(30065212593)
            /*Pager<ICatalogueCategoryModel>? */ get Categories()
            {
                return $.$fPer.LCFCD.Paging.Cast$1($.$Fjop.LCCMCM.CommunityMarketCategoryModel, $.$AvdQ.LCFCP.ICatalogueCategoryModel, $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$Fjop.LCCMCM.CommunityMarketCategoryModel, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Store.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 4194304n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), null));
            }
            //--TRIMMABLE-BOUNDARY-END(30065212593)
            
            //--TRIMMABLE-BOUNDARY-START(25770245297)
            /*Pager<ICatalogueCategoryModel>?*/ Brands = null;
            //--TRIMMABLE-BOUNDARY-END(25770245297)
            
            //--TRIMMABLE-BOUNDARY-START(184684035249)
            /*Pager<IProductCatalogueModel>? */ get Products()
            {
                return $.$fPer.LCFCD.Paging.Cast$1($.$Fjop.LCCMCM.CommunityMarketProductModel, $.$AvdQ.LCFCP.IProductCatalogueModel, $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$Fjop.LCCMCM.CommunityMarketProductModel, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Store.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 4194304n | 65536n | 8388608n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), null));
            }
            //--TRIMMABLE-BOUNDARY-END(184684035249)
            
            //--TRIMMABLE-BOUNDARY-START(193273969841)
            /*Pager<IServiceCatalogueModel>?*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(193273969841)
            
            //--TRIMMABLE-BOUNDARY-START(206158871729)
            /*ICatalogueSettings? */ get Settings()
            {
                return this.Store.Settings;
            }
            //--TRIMMABLE-BOUNDARY-END(206158871729)
            
            //--TRIMMABLE-BOUNDARY-START(214748806321)
            /*string? */ get Title()
            {
                return this.Store.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(214748806321)
            
            //--TRIMMABLE-BOUNDARY-START(47245081777)
            /*string? */ get Description()
            {
                return this.Store.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(47245081777)
            
            //--TRIMMABLE-BOUNDARY-START(171799133361)
            /*IconDescriptor */ get Icon()
            {
                return $.$Iaui.LCFCM.ResourceModel.op_Implicit(this.Store.Icon);
            }
            //--TRIMMABLE-BOUNDARY-END(171799133361)
            
            //--TRIMMABLE-BOUNDARY-START(176094100657)
            /*string? */ get Name()
            {
                return this.Store.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(176094100657)
            
            //--TRIMMABLE-BOUNDARY-START(180389067953)
            /*CommunityMarketProductOrderModel?*/ Order = null;
            //--TRIMMABLE-BOUNDARY-END(180389067953)
            
            //--TRIMMABLE-BOUNDARY-START(21475278001)
            $ctor$1(/*IClientUnitOfWork*/ unitOfWork, /*CommunityMarketShoppingPaymentTierProvider*/ provider, /*CommunityMarketProductStoreModel*/ store)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475278001);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.unitOfWork = unitOfWork;
                    this.provider = provider;
                    this.Store = store;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475278001)
            
            //--TRIMMABLE-BOUNDARY-START(34360179889)
            /*Task<ICatalogueOrderModel> *//*async*/  CreateOrder(/*PaymentMethod*/ payment, /*IContact?*/ customer, /*IEnumerable<ICatalogueOrderItemModel>*/ items)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$AvdQ.LCFCP.ICatalogueOrderModel), $.$AvdQ.LCFCP.ICatalogueOrderModel, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360179889);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $en1 = $.$sl.SL.Enumerable.Cast($.$Fjop.LCCMCM.CommunityMarketProductOrderItemModel, items).SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let item = $en1.SCG$IEnumerator$$$Current;
                        {
                            item.Product.UnitQuantity += item.UnitQuantity;
                            item.Product.PackQuantity += item.PackQuantity;
                        }
                    }
                    this.Order = (() =>
                    {
                        //new $.$Fjop.LCCMCM.CommunityMarketProductOrderModel()
                        const $t2 = $.$Fjop.LCCMCM.CommunityMarketProductOrderModel;
                        const $i2 = new $t2();
                        $i2.$ctor$6();
                        $i2.UniqueId = $.$fPer.LCFCS$6.StringExtension.GetRandomString(16, true, true, false);
                        $i2.ParentId = this.Store.Identifier;
                        $i2.PaymentMode = payment;
                        $i2.OrderItems = $.$sl.SL.Enumerable.Cast($.$Fjop.LCCMCM.CommunityMarketProductOrderItemModel, items);
                        $i2.Customer = $.$cast(((customer?.LCFC$INamed$Name ?? null) !== null ? customer : null), $.$Fjop.LCCMCM.CommunityMarketProductStoreCustomerModel);
                        return $i2;
                    })();
                    ($t3 = $.$hDPm.LCFCI.ViewPresenterExtensions.GoBack($.$hDPm.LCFCI.ViewConfiguration, this.unitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, this.Order);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360179889)
            
            //--TRIMMABLE-BOUNDARY-START(38655147185)
            /*IEditableCatalogueOrderItemModel */ CreateOrderItem(/*ICatalogueModel*/ catalogue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655147185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let product = $.$cast(catalogue, $.$Fjop.LCCMCM.CommunityMarketProductModel);
                return (() =>
                {
                    //new $.$Fjop.LCCMCM.CommunityMarketProductOrderItemModel()
                    const $t4 = $.$Fjop.LCCMCM.CommunityMarketProductOrderItemModel;
                    const $i4 = new $t4();
                    $i4.$ctor$6();
                    $i4.Name = product.Name;
                    $i4.ParentId = this.Store.Identifier;
                    $i4.Product = product;
                    $i4.UnitCost = product.UnitCost;
                    $i4.UnitQuantity = -1;
                    return $i4;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(38655147185)
            
            //--TRIMMABLE-BOUNDARY-START(51540049073)
            /*Task<IPaymentOrderTransactionModel?> *//*async*/  Execute(/*PaymentTierReceiptContext*/ receipt)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel), $.$fPer.LCFC.IPaymentOrderTransactionModel, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540049073);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Order.PaymentReference = receipt.PaymentReference;
                    this.Order.DatePaid = $.$$.S.DateTime.UtcNow;
                    this.Order.DeliveryLocation = this.provider.DeliveryLocation;
                    /*var*/ let _order = $.$sl.SL.Enumerable.Single$1($.$Fjop.LCCMCM.CommunityMarketProductOrderModel, (($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$Fjop.LCCMCM.CommunityMarketProductOrderModel, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Fjop.LCCMCM.CommunityMarketProductOrderModel), [ this.Order ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)))).Data);
                    ($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$Fjop.LCCMCM.CommunityMarketProductModel, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$sl.SL.Enumerable.ToArray($.$Fjop.LCCMCM.CommunityMarketProductModel, $.$sl.SL.Enumerable.Select$1($.$Fjop.LCCMCM.CommunityMarketProductOrderItemModel, $.$Fjop.LCCMCM.CommunityMarketProductModel, this.Order.OrderItems, new ($.$$.S.Func$$$($.$Fjop.LCCMCM.CommunityMarketProductOrderItemModel, $.$Fjop.LCCMCM.CommunityMarketProductModel))().$ctor(this,  (/*it*/ it) =>
                    {
                        return it.Product;
                    }, $PIyyAe ??= {"r":1553995,"p":[{"n":"it","p":1881675}],"n":"","d":441521,"h":0,"f":17825794})))), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    this.Order = _order;
                    return $.$$.N.AsyncResolver.Result($asnycContext, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51540049073)
            
            //--TRIMMABLE-BOUNDARY-START(34361589479)
            //Generated interface implemetation for LivingThing.Core.ProductsServices.Client.Shared.ICatalogueOrderProvider.Features.get
            get LCPCS$1$ICatalogueOrderProvider$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181720295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(34361589479)
            
            //--TRIMMABLE-BOUNDARY-START(25771654887)
            //Generated interface implemetation for LivingThing.Core.ProductsServices.Client.Shared.ICatalogueOrderProvider.Customers.get
            get LCPCS$1$ICatalogueOrderProvider$Customers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886752999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Customers;
            }
            //--TRIMMABLE-BOUNDARY-END(25771654887)
            
            //--TRIMMABLE-BOUNDARY-START(8591785703)
            //Generated interface implemetation for LivingThing.Core.ProductsServices.Client.Shared.ICatalogueOrderProvider.CreateOrderItem(LivingThing.Core.Frameworks.Common.Product.ICatalogueModel)
            LCPCS$1$ICatalogueOrderProvider$CreateOrderItem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591785703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateOrderItem(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591785703)
            
            //--TRIMMABLE-BOUNDARY-START(4296818407)
            //Generated interface implemetation for LivingThing.Core.ProductsServices.Client.Shared.ICatalogueOrderProvider.CreateOrder(LivingThing.Core.Frameworks.Common.Payment.PaymentMethod, LivingThing.Core.Frameworks.Common.Contacts.IContact?, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Product.ICatalogueOrderItemModel>)
            LCPCS$1$ICatalogueOrderProvider$CreateOrder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296818407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateOrder(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296818407)
            
            //--TRIMMABLE-BOUNDARY-START(25772143552)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider.Categories.get
            get LCFCP$ICatalogueProvider$Categories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592274368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Categories;
            }
            //--TRIMMABLE-BOUNDARY-END(25772143552)
            
            //--TRIMMABLE-BOUNDARY-START(17182208960)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider.Brands.get
            get LCFCP$ICatalogueProvider$Brands()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297307072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Brands;
            }
            //--TRIMMABLE-BOUNDARY-END(17182208960)
            
            //--TRIMMABLE-BOUNDARY-START(34362078144)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider.Products.get
            get LCFCP$ICatalogueProvider$Products()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721816512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Products;
            }
            //--TRIMMABLE-BOUNDARY-END(34362078144)
            
            //--TRIMMABLE-BOUNDARY-START(42952012736)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider.Services.get
            get LCFCP$ICatalogueProvider$Services()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016783808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services;
            }
            //--TRIMMABLE-BOUNDARY-END(42952012736)
            
            //--TRIMMABLE-BOUNDARY-START(51541947328)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider.Settings.get
            get LCFCP$ICatalogueProvider$Settings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311751104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Settings;
            }
            //--TRIMMABLE-BOUNDARY-END(51541947328)
            
            //--TRIMMABLE-BOUNDARY-START(8590935832)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.Execute(LivingThing.Core.Frameworks.Common.Payment.PaymentTierReceiptContext)
            LCFCP$IPaymentTierProvider$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590935832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590935832)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            static $h = 441521;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(210453839025),
    {
      "p": 3847755,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914231473,
        "f": 50331656
      },
      "n": "Store",
      "d": 441521,
      "h": 210453839025,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(210453839025),
//--TRIMMABLE-BOUNDARY-START(55835016369),
    {
      "p": 933607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784689329,
        "f": 50331649
      },
      "n": "Features",
      "d": 441521,
      "h": 55835016369,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835016369),
//--TRIMMABLE-BOUNDARY-START(42950114481),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$fPer.LCFCC$2.IContact).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604820145,
        "f": 50331649
      },
      "n": "Customers",
      "d": 441521,
      "h": 42950114481,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950114481),
//--TRIMMABLE-BOUNDARY-START(30065212593),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ICatalogueCategoryModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014885553,
        "f": 50331649
      },
      "n": "Categories",
      "d": 441521,
      "h": 30065212593,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065212593),
//--TRIMMABLE-BOUNDARY-START(25770245297),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ICatalogueCategoryModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424950961,
        "f": 50331649
      },
      "n": "Brands",
      "d": 441521,
      "h": 25770245297,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770245297),
//--TRIMMABLE-BOUNDARY-START(184684035249),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.IProductCatalogueModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144427697,
        "f": 50331649
      },
      "n": "Products",
      "d": 441521,
      "h": 184684035249,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184684035249),
//--TRIMMABLE-BOUNDARY-START(193273969841),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.IServiceCatalogueModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734362289,
        "f": 50331649
      },
      "n": "Services",
      "d": 441521,
      "h": 193273969841,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193273969841),
//--TRIMMABLE-BOUNDARY-START(206158871729),
    {
      "p": 2536384,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324296881,
        "f": 50331649
      },
      "n": "Settings",
      "d": 441521,
      "h": 206158871729,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206158871729),
//--TRIMMABLE-BOUNDARY-START(214748806321),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504166065,
        "f": 50331649
      },
      "n": "Title",
      "d": 441521,
      "h": 214748806321,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214748806321),
//--TRIMMABLE-BOUNDARY-START(47245081777),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194754737,
        "f": 50331649
      },
      "n": "Description",
      "d": 441521,
      "h": 47245081777,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245081777),
//--TRIMMABLE-BOUNDARY-START(171799133361),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374623921,
        "f": 50331649
      },
      "n": "Icon",
      "d": 441521,
      "h": 171799133361,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799133361),
//--TRIMMABLE-BOUNDARY-START(176094100657),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964558513,
        "f": 50331649
      },
      "n": "Name",
      "d": 441521,
      "h": 176094100657,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176094100657),
//--TRIMMABLE-BOUNDARY-START(180389067953),
    {
      "p": 2209355,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554493105,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201863904433,
        "f": 83886082
      },
      "n": "Order",
      "d": 441521,
      "h": 180389067953,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(180389067953)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360179889),
    {
      "r": $.$$.STT.Task$$($.$AvdQ.LCFCP.ICatalogueOrderModel).$h,
      "p": [
        {
          "n": "payment",
          "p": 1459992
        },
        {
          "n": "customer",
          "p": 5081430
        },
        {
          "n": "items",
          "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel).$h
        }
      ],
      "n": "CreateOrder",
      "d": 441521,
      "h": 34360179889,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(34360179889),
//--TRIMMABLE-BOUNDARY-START(38655147185),
    {
      "r": 2929600,
      "p": [
        {
          "n": "catalogue",
          "p": 1946560
        }
      ],
      "n": "CreateOrderItem",
      "d": 441521,
      "h": 38655147185,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655147185),
//--TRIMMABLE-BOUNDARY-START(51540049073),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel).$h,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Execute",
      "d": 441521,
      "h": 51540049073,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(51540049073)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(219043773617),
    {
      "t": 63657642,
      "n": "unitOfWork",
      "d": 441521,
      "h": 219043773617,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(219043773617),
//--TRIMMABLE-BOUNDARY-START(188979002545),
    {
      "t": 310449,
      "n": "provider",
      "d": 441521,
      "h": 188979002545,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(188979002545)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475278001),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        },
        {
          "n": "provider",
          "p": 310449
        },
        {
          "n": "store",
          "p": 3847755
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 441521,
      "h": 21475278001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475278001)
  ],
  "h": 441521
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$dgLE.LCPCS$1.ICatalogueOrderProvider, $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Market.StorePaymentTier.CommunityMarketShoppingStoreCatalogueOrderProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Market${separator}StorePaymentTier${separator}CommunityMarketShoppingStoreCatalogueOrderProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(441521)
        
        

        //--TRIMMABLE-BOUNDARY-START(310449)
        $asm.$cls(`$JkHl.LCCMS.CommunityMarketShoppingPaymentTierProvider`, ($self) => class CommunityMarketShoppingPaymentTierProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655016113)
            /*ThemePack*/ static DefaultTheme = null;
            //--TRIMMABLE-BOUNDARY-END(38655016113)
            
            //--TRIMMABLE-BOUNDARY-START(180388936881)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(180388936881)
            
            //--TRIMMABLE-BOUNDARY-START(167504034993)
            /*ILocationProvider*/ locationProvider = null;
            //--TRIMMABLE-BOUNDARY-END(167504034993)
            
            //--TRIMMABLE-BOUNDARY-START(184683904177)
            /*IEnumerable<IMarketService>*/ services = null;
            //--TRIMMABLE-BOUNDARY-END(184683904177)
            
            //--TRIMMABLE-BOUNDARY-START(30065081521)
            $ctor$1(/*IServerRemoteService*/ server, /*ILocationProvider*/ locationProvider, /*IEnumerable<IMarketService>*/ services)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065081521);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.server = server;
                    this.locationProvider = locationProvider;
                    this.services = services;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065081521)
            
            //--TRIMMABLE-BOUNDARY-START(193273838769)
            /*Pager<IPaymentTier>? */ get ServiceTiers()
            {
                return $.$fPer.LCFCD.Paging.GetPager($.$nYKj.LCFCP.IPaymentTier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$nYKj.LCFCP.IPaymentTier), [(() =>
                {
                    //new $.$AvdQ.LCFCP.ServiceTierModel()
                    const $t1 = $.$AvdQ.LCFCP.ServiceTierModel;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Name = "Zoey Stores";
                    $i1.Icon = (() =>
                    {
                        //new $.$fPer.LCFC.IconDescriptor()
                        const $t2 = $.$fPer.LCFC.IconDescriptor;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.Icon = "mdi mdi-store"/*MaterialDesignIconNames.Store*/;
                        $i2.Theme = $.$JkHl.LCCMS.CommunityMarketShoppingPaymentTierProvider.DefaultTheme.Primary;
                        return $i2;
                    })();
                    $i1.ServiceTierName = "Store";
                    $i1.ServiceTiers = $.$fPer.LCFCD.Paging.Select($.$Fjop.LCCMCM.CommunityMarketProductStoreModel, $.$AvdQ.LCFCP.ServiceTierModel, $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$Fjop.LCCMCM.CommunityMarketProductStoreModel, this.server, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1196268653051967n | 4194304n | 131072n | 524288n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), null), new ($.$$.S.Func$$$($.$Fjop.LCCMCM.CommunityMarketProductStoreModel, $.$AvdQ.LCFCP.ServiceTierModel))().$ctor(this,  (/*store*/ store) =>
                    {
                        return (() =>
                        {
                            //new $.$AvdQ.LCFCP.ServiceTierModel()
                            const $t3 = $.$AvdQ.LCFCP.ServiceTierModel;
                            const $i3 = new $t3();
                            $i3.$ctor$1();
                            $i3.Tag = store;
                            $i3.Name = store.Name;
                            $i3.Icon = $.$Iaui.LCFCM.ResourceModel.op_Implicit(store.Icon ?? $.$Iaui.LCFCM.ResourceModel.op_Implicit$1((() =>
                            {
                                //new $.$fPer.LCFC.IconDescriptor()
                                const $t4 = $.$fPer.LCFC.IconDescriptor;
                                const $i4 = new $t4();
                                $i4.$ctor$2();
                                $i4.Icon = "mdi mdi-store"/*MaterialDesignIconNames.Store*/;
                                $i4.Theme = $.$JkHl.LCCMS.CommunityMarketShoppingPaymentTierProvider.DefaultTheme.Primary;
                                return $i4;
                            })()));
                            $i3.UserInformation = $.$JkHl.LCCMS.CommunityMarketShoppingPaymentTierView.$type;
                            return $i3;
                        })();
                    }, $bqgTZd ??= {"r":4764608,"p":[{"n":"store","p":3847755}],"n":"","d":310449,"h":0,"f":17825794}));
                    return $i1;
                })(), (() =>
                {
                    //new $.$AvdQ.LCFCP.ServiceTierModel()
                    const $t5 = $.$AvdQ.LCFCP.ServiceTierModel;
                    const $i5 = new $t5();
                    $i5.$ctor$1();
                    $i5.Name = "Near Me";
                    $i5.Icon = (() =>
                    {
                        //new $.$fPer.LCFC.IconDescriptor()
                        const $t6 = $.$fPer.LCFC.IconDescriptor;
                        const $i6 = new $t6();
                        $i6.$ctor$2();
                        $i6.Icon = "mdi mdi-map-marker-radius"/*MaterialDesignIconNames.MapMarkerRadius*/;
                        $i6.Theme = $.$JkHl.LCCMS.CommunityMarketShoppingPaymentTierProvider.DefaultTheme.Primary;
                        return $i6;
                    })();
                    $i5.ServiceTierName = "Store";
                    $i5.ServiceTiers = $.$fPer.LCFCD.Paging.Select($.$Fjop.LCCMCM.CommunityMarketProductStoreModel, $.$AvdQ.LCFCP.ServiceTierModel, $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager$1($.$Fjop.LCCMCM.CommunityMarketProductStoreModel, this.server, new ($.$$.S.Func$$($.$$.STT.Task$$($.$fPer.LCFCD.DataFilter)))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFCD.DataFilter), $.$fPer.LCFCD.DataFilter, async ($asnycContext) => 
                        {
                            let $t7, $r7;
                            /*var*/ let location = ($t7 = this.locationProvider.LCFCS$3$ILocationProvider$GetCurrentUserLocationAsync(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                            /*var*/ let rectangle = location.CenterWithRectangle(1000, 1000);
                            return $.$$.N.AsyncResolver.Result($asnycContext, new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741853/*PostFilterTypes.Search*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, new $.$LCOv.LCFCPM$1.PostSearchModel().$ctor$1().HasAttributes(new ($.$$.S.Action$$($.$LCOv.LCFCPM$1.PostSearchModel.CommunityPostSearchAttributeBuilder))().$ctor(this,  (/*a*/ a) =>
                            {
                                a.WithLocationRange(4194304/*PostPropertyQueryFilterType.PropertyValueLocationRange*/, "Location", rectangle.Item1, rectangle.Item2);
                            }, $Gdggrg ??= {"r":65537,"p":[{"n":"a","p":20310452}],"n":"","d":310449,"h":0,"f":17825794}), 0, 0), 0));
                        });
                    }, $Ewvqea ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.DataFilter).$h,"n":"","d":310449,"h":0,"f":17829890}), null), new ($.$$.S.Func$$$($.$Fjop.LCCMCM.CommunityMarketProductStoreModel, $.$AvdQ.LCFCP.ServiceTierModel))().$ctor(this,  (/*store*/ store) =>
                    {
                        return (() =>
                        {
                            //new $.$AvdQ.LCFCP.ServiceTierModel()
                            const $t8 = $.$AvdQ.LCFCP.ServiceTierModel;
                            const $i8 = new $t8();
                            $i8.$ctor$1();
                            $i8.Tag = store;
                            $i8.Name = store.Name;
                            $i8.Icon = $.$Iaui.LCFCM.ResourceModel.op_Implicit(store.Icon ?? $.$Iaui.LCFCM.ResourceModel.op_Implicit$1((() =>
                            {
                                //new $.$fPer.LCFC.IconDescriptor()
                                const $t9 = $.$fPer.LCFC.IconDescriptor;
                                const $i9 = new $t9();
                                $i9.$ctor$2();
                                $i9.Icon = "mdi mdi-store"/*MaterialDesignIconNames.Store*/;
                                $i9.Theme = $.$JkHl.LCCMS.CommunityMarketShoppingPaymentTierProvider.DefaultTheme.Primary;
                                return $i9;
                            })()));
                            $i8.UserInformation = $.$JkHl.LCCMS.CommunityMarketShoppingPaymentTierView.$type;
                            return $i8;
                        })();
                    }, $ENvTEk ??= {"r":4764608,"p":[{"n":"store","p":3847755}],"n":"","d":310449,"h":0,"f":17825794}));
                    return $i5;
                })()], [-1], null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(193273838769)
            
            //--TRIMMABLE-BOUNDARY-START(253403380913)
            /*string? */ get Title()
            {
                return "Zoey Shop";
            }
            //--TRIMMABLE-BOUNDARY-END(253403380913)
            
            //--TRIMMABLE-BOUNDARY-START(188978871473)
            /*string? */ get ServiceTierName()
            {
                return "Category";
            }
            //--TRIMMABLE-BOUNDARY-END(188978871473)
            
            //--TRIMMABLE-BOUNDARY-START(47244950705)
            /*string? */ get Description()
            {
                return `Shopping ${$.$strNN(($.$$.S.String.Join$5(", ", $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider), $.$$.S.String, this.StoresProvider, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider), $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.Value.Store.Description;
                }, $LAZhfi ??= {"r":1310721,"p":[{"n":"s","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider).$h}],"n":"","d":310449,"h":0,"f":17825794})))))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(47244950705)
            
            //--TRIMMABLE-BOUNDARY-START(163209067697)
            /*IconDescriptor */ get Icon()
            {
                return (() =>
                {
                    //new $.$fPer.LCFC.IconDescriptor()
                    const $t10 = $.$fPer.LCFC.IconDescriptor;
                    const $i10 = new $t10();
                    $i10.$ctor$2();
                    $i10.Icon = "mdi mdi-store"/*MaterialDesignIconNames.Store*/;
                    $i10.Theme = $.$JkHl.LCCMS.CommunityMarketShoppingPaymentTierProvider.DefaultTheme.Primary;
                    return $i10;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(163209067697)
            
            //--TRIMMABLE-BOUNDARY-START(171799002289)
            /*string? */ get Name()
            {
                return "Shop";
            }
            //--TRIMMABLE-BOUNDARY-END(171799002289)
            
            //--TRIMMABLE-BOUNDARY-START(249108413617)
            /*Dictionary<string, CommunityMarketShoppingStoreCatalogueOrderProvider>*/ StoresProvider = null;
            //--TRIMMABLE-BOUNDARY-END(249108413617)
            
            //--TRIMMABLE-BOUNDARY-START(34360048817)
            /*CommunityMarketShoppingStoreCatalogueOrderProvider?*/ CurrentStoreCatalogueProvider = null;
            //--TRIMMABLE-BOUNDARY-END(34360048817)
            
            //--TRIMMABLE-BOUNDARY-START(244813446321)
            /*IShippingService?*/ ShippingService = null;
            //--TRIMMABLE-BOUNDARY-END(244813446321)
            
            //--TRIMMABLE-BOUNDARY-START(240518479025)
            /*Money*/ ShippingCost;
            //--TRIMMABLE-BOUNDARY-END(240518479025)
            
            //--TRIMMABLE-BOUNDARY-START(42949983409)
            /*GeoLocation?*/ DeliveryLocation = null;
            //--TRIMMABLE-BOUNDARY-END(42949983409)
            
            //--TRIMMABLE-BOUNDARY-START(158914100401)
            /*ValueTask<ValueRange<Money>> */ GetCost(/*IPaymentTier?*/ tier, /*object?*/ tierUserInfomation, /*object?*/ serviceUserInfomation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914100401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.StoresProvider.Count > 0)
                {
                    /*var*/ let amount = $.$fPer.LCFCDM.Money.op_Addition(this.ShippingCost, $.$sl.SL.Enumerable.Aggregate$2($.$fPer.LCFCDM.Money, $.$sl.SL.Enumerable.Select$1($.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider, $.$fPer.LCFCDM.Money, this.StoresProvider.Values, new ($.$$.S.Func$$$($.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider, $.$fPer.LCFCDM.Money))().$ctor(this,  (/*a*/ a) =>
                    {
                        return ((a.Order)?.LCFCP$ICatalogueOrderModel$Amount ?? null) ?? new $.$fPer.LCFCDM.Money();
                    }, $RbQFmk ??= {"r":27822422,"p":[{"n":"a","p":441521}],"n":"","d":310449,"h":0,"f":17825794})), new ($.$$.S.Func$$$$($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money))().$ctor(this,  (/*a*/ a, /*b*/ b) =>
                    {
                        return $.$fPer.LCFCDM.Money.op_Addition(a, b);
                    }, $wQGbOj ??= {"r":27822422,"p":[{"n":"a","p":27822422},{"n":"b","p":27822422}],"n":"","d":310449,"h":0,"f":17825794})));
                    if (amount.Unit === 0/*MoneyUnitTypes.None*/)
                    {
                        amount = new $.$fPer.LCFCDM.Money().$ctor$3(amount.Value, 1/*MoneyUnitTypes.Naira*/);
                    }
                    return $.$$.STT.ValueTask.FromResult($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money), new ($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))().$ctor$3($.$clone(amount), $.$clone(amount)));
                }
                return $.$$.STT.ValueTask.FromResult($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money), new ($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))().$ctor$3(new $.$fPer.LCFCDM.Money().$ctor$3(0, 1/*MoneyUnitTypes.Naira*/), new $.$fPer.LCFCDM.Money().$ctor$3(0, 1/*MoneyUnitTypes.Naira*/)));
            }
            //--TRIMMABLE-BOUNDARY-END(158914100401)
            
            //--TRIMMABLE-BOUNDARY-START(176093969585)
            /*Dictionary<IContact, Money>? */ get PayeeSplit()
            {
                return $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider), $.$fPer.LCFCC$2.IContact, $.$fPer.LCFCDM.Money, this.StoresProvider, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider), $.$fPer.LCFCC$2.IContact))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return sp.Value.Store.Account.User;
                }, $VWwOkf ??= {"r":5081430,"p":[{"n":"sp","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider).$h}],"n":"","d":310449,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider), $.$fPer.LCFCDM.Money))().$ctor(this,  (/**/ sp) =>
                {
                    return sp.Value.Order.Amount;
                }, $IkTgQh ??= {"r":27822422,"p":[{"n":"sp","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider).$h}],"n":"","d":310449,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(176093969585)
            
            //--TRIMMABLE-BOUNDARY-START(51539918001)
            /*Task<IPaymentOrderTransactionModel?> *//*async*/  Execute(/*PaymentTierReceiptContext*/ receipt)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel), $.$fPer.LCFC.IPaymentOrderTransactionModel, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539918001);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*IEnumerable<IShipmentModel>?*/ let shipments = null;
                    let $en11 = this.StoresProvider.Values.GetEnumerator();
                    while ($en11.MoveNext())
                    {
                        let provider = $en11.Current;
                        {
                            provider.Order.PickupLocation = provider.Store.Location;
                            provider.Order.DeliveryLocation = this.DeliveryLocation;
                            provider.Order.PaymentReference = receipt.PaymentReference;
                            if (this.ShippingService !== null)
                            {
                                provider.Order.Delivery = 2/*ShipmentDeliveryType.HomeDelivery*/;
                            }
                        }
                    }
                    if (this.ShippingService !== null)
                    {
                        let $t12, $r12;
                        shipments = ($t12 = this.ShippingService.LCSCS$IShippingService$CreateShipmentAsync($.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.Select$1($.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider, $.$Fjop.LCCMCM.CommunityMarketProductOrderModel, this.StoresProvider.Values, new ($.$$.S.Func$$$($.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider, $.$Fjop.LCCMCM.CommunityMarketProductOrderModel))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.Order;
                        }, $UScYla ??= {"r":2209355,"p":[{"n":"s","p":441521}],"n":"","d":310449,"h":0,"f":17825794})), $.$$.SCG.IEnumerable$$($.$Fjop.LCCMCM.CommunityMarketProductOrderModel), $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel)), "Order"), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                    }
                    /*int*/ let i = 0;
                    /*var*/ let transaction = (() =>
                    {
                        //new $.$fPer.LCFC.PaymentOrderTransactionModel()
                        const $t13 = $.$fPer.LCFC.PaymentOrderTransactionModel;
                        const $i13 = new $t13();
                        $i13.$ctor$1();
                        $i13.Amount = receipt.AmountPaid;
                        return $i13;
                    })();
                    let $en14 = this.StoresProvider.GetEnumerator();
                    while ($en14.MoveNext())
                    {
                        let prv = $en14.Current;
                        {
                            let $t15, $r15;
                            if (shipments !== null)
                            {
                                prv.Value.Order.ShipmentId = $.$fPer.LCFCD.DataId.op_Implicit$1($.$sl.SL.Enumerable.ElementAt$1($.$YUlm.LCSCM.IShipmentModel, shipments, i).LCSCM$IShipmentModel$ShippingServiceId);
                            }
                            ($t15 = prv.Value.Execute($.$clone(receipt)), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                            $.$fPer.LCFCD.DynamicDataContainerExtension.Add($.$$.S.Object, transaction, prv.Value.Order.Identifier, `${$.$strNN("CommunityMarketProductOrderModel")}[${$.$strNN(i)}]`);
                            i++;
                        }
                    }
                    this.ShippingService = null;
                    this.ShippingCost = new $.$fPer.LCFCDM.Money();
                    this.DeliveryLocation = null;
                    return $.$$.N.AsyncResolver.Result($asnycContext, transaction);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51539918001)
            
            //--TRIMMABLE-BOUNDARY-START(34360739608)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.ServiceTierName.get
            get LCFCP$IPaymentTierProvider$ServiceTierName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130543384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceTierName;
            }
            //--TRIMMABLE-BOUNDARY-END(34360739608)
            
            //--TRIMMABLE-BOUNDARY-START(42950674200)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.ServiceTiers.get
            get LCFCP$IPaymentTierProvider$ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425510680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceTiers;
            }
            //--TRIMMABLE-BOUNDARY-END(42950674200)
            
            //--TRIMMABLE-BOUNDARY-START(8590935832)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.Execute(LivingThing.Core.Frameworks.Common.Payment.PaymentTierReceiptContext)
            LCFCP$IPaymentTierProvider$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590935832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590935832)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(4295837464)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierCostProvider.GetCost(LivingThing.Core.Frameworks.Common.Payment.IPaymentTier?, object?, object?)
            LCFCP$IPaymentTierCostProvider$GetCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295837464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCost(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295837464)
            
            //--TRIMMABLE-BOUNDARY-START(8591132440)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierSplitPaymentProvider.PayeeSplit.get
            get LCFCP$IPaymentTierSplitPaymentProvider$PayeeSplit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886099736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PayeeSplit;
            }
            //--TRIMMABLE-BOUNDARY-END(8591132440)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(249108413617)
                this.StoresProvider = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(249108413617)
                
                //--TRIMMABLE-BOUNDARY-START(240518479025)
                this.ShippingCost = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(240518479025)
                
            }
            //--TRIMMABLE-BOUNDARY-START(25770114225)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770114225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(38655016113)
                    this.DefaultTheme = (() =>
                    {
                        //new $.$vWqU.LCFCC.ThemePack()
                        const $t16 = $.$vWqU.LCFCC.ThemePack;
                        const $i16 = new $t16();
                        $i16.$ctor$1();
                        $i16.Primary = (() =>
                        {
                            //new $.$fPer.LCFC.Theme()
                            const $t17 = $.$fPer.LCFC.Theme;
                            const $i17 = new $t17();
                            $i17.$ctor$2();
                            $i17.BackgroundColor = "#F95738";
                            $i17.ForegroundColor = "#FFF";
                            return $i17;
                        })();
                        return $i16;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(38655016113)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770114225)
            
            static $h = 310449;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(193273838769),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259394737,
        "f": 50331649
      },
      "n": "ServiceTiers",
      "d": 310449,
      "h": 193273838769,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193273838769),
//--TRIMMABLE-BOUNDARY-START(253403380913),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619133105,
        "f": 50331649
      },
      "n": "Title",
      "d": 310449,
      "h": 253403380913,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253403380913),
//--TRIMMABLE-BOUNDARY-START(188978871473),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669460145,
        "f": 50331649
      },
      "n": "ServiceTierName",
      "d": 310449,
      "h": 188978871473,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188978871473),
//--TRIMMABLE-BOUNDARY-START(47244950705),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309721777,
        "f": 50331649
      },
      "n": "Description",
      "d": 310449,
      "h": 47244950705,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244950705),
//--TRIMMABLE-BOUNDARY-START(163209067697),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899656369,
        "f": 50331649
      },
      "n": "Icon",
      "d": 310449,
      "h": 163209067697,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163209067697),
//--TRIMMABLE-BOUNDARY-START(171799002289),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489590961,
        "f": 50331649
      },
      "n": "Name",
      "d": 310449,
      "h": 171799002289,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799002289),
//--TRIMMABLE-BOUNDARY-START(249108413617),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029198513,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236223511729,
        "f": 83886088
      },
      "n": "StoresProvider",
      "d": 310449,
      "h": 249108413617,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(249108413617),
//--TRIMMABLE-BOUNDARY-START(34360048817),
    {
      "p": 441521,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129852593,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201863773361,
        "f": 83886088
      },
      "n": "CurrentStoreCatalogueProvider",
      "d": 310449,
      "h": 34360048817,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(34360048817),
//--TRIMMABLE-BOUNDARY-START(244813446321),
    {
      "p": 2459769,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439263921,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227633577137,
        "f": 83886088
      },
      "n": "ShippingService",
      "d": 310449,
      "h": 244813446321,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(244813446321),
//--TRIMMABLE-BOUNDARY-START(240518479025),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849329329,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219043642545,
        "f": 83886088
      },
      "n": "ShippingCost",
      "d": 310449,
      "h": 240518479025,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(240518479025),
//--TRIMMABLE-BOUNDARY-START(42949983409),
    {
      "p": 13928790,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719787185,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210453707953,
        "f": 83886088
      },
      "n": "DeliveryLocation",
      "d": 310449,
      "h": 42949983409,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(42949983409),
//--TRIMMABLE-BOUNDARY-START(176093969585),
    {
      "p": $.$$.SCG.Dictionary$$$($.$fPer.LCFCC$2.IContact, $.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079525553,
        "f": 50331649
      },
      "n": "PayeeSplit",
      "d": 310449,
      "h": 176093969585,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176093969585)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(158914100401),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)).$h,
      "p": [
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "tierUserInfomation",
          "p": 131073
        },
        {
          "n": "serviceUserInfomation",
          "p": 131073
        }
      ],
      "n": "GetCost",
      "d": 310449,
      "h": 158914100401,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914100401),
//--TRIMMABLE-BOUNDARY-START(51539918001),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel).$h,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Execute",
      "d": 310449,
      "h": 51539918001,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(51539918001)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655016113),
    {
      "t": 9854376,
      "n": "DefaultTheme",
      "d": 310449,
      "h": 38655016113,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655016113),
//--TRIMMABLE-BOUNDARY-START(180388936881),
    {
      "t": 1309651,
      "n": "server",
      "d": 310449,
      "h": 180388936881,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(180388936881),
//--TRIMMABLE-BOUNDARY-START(167504034993),
    {
      "t": 61442390,
      "n": "locationProvider",
      "d": 310449,
      "h": 167504034993,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(167504034993),
//--TRIMMABLE-BOUNDARY-START(184683904177),
    {
      "t": $.$$.SCG.IEnumerable$$($.$Fjop.LCCMCS.IMarketService).$h,
      "n": "services",
      "d": 310449,
      "h": 184683904177,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(184683904177)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065081521),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "locationProvider",
          "p": 61442390
        },
        {
          "n": "services",
          "p": $.$$.SCG.IEnumerable$$($.$Fjop.LCCMCS.IMarketService).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 310449,
      "h": 30065081521,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065081521)
  ],
  "h": 310449
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$nYKj.LCFCP.IPaymentTierCostProvider, $.$nYKj.LCFCP.IPaymentTierSplitPaymentProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Market.StorePaymentTier.CommunityMarketShoppingPaymentTierProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Market${separator}StorePaymentTier${separator}CommunityMarketShoppingPaymentTierProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(310449)
        
        

        //--TRIMMABLE-BOUNDARY-START(638129)
        $asm.$cls(`$JkHl.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295605425)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295605425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295605425)
            
            //--TRIMMABLE-BOUNDARY-START(4295605425)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295605425)
            
            static $h = 638129;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295605425),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 638129,
      "h": 4295605425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295605425)
  ],
  "h": 638129
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(638129)
        
        

        //--TRIMMABLE-BOUNDARY-START(703665)
        $asm.$cls(`$JkHl.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295670961)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295670961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295670961)
            
            //--TRIMMABLE-BOUNDARY-START(4295670961)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295670961)
            
            static $h = 703665;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295670961),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 703665,
      "h": 4295670961,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295670961)
  ],
  "h": 703665,
  "a": [
    {
      "t": 638129,
      "c": 4295605425
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(703665)
        
        

        //--TRIMMABLE-BOUNDARY-START(179377)
        $asm.$cls(`$JkHl.LCCMS._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590113969)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590113969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590113969)
            
            //--TRIMMABLE-BOUNDARY-START(4295146673)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295146673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295146673)
            
            //--TRIMMABLE-BOUNDARY-START(4295146673)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295146673)
            
            static $h = 179377;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590113969),
    {
      "r": 65537,
      "n": "Execute",
      "d": 179377,
      "h": 8590113969,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590113969)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295146673),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 179377,
      "h": 4295146673,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295146673)
  ],
  "h": 179377
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Market.StorePaymentTier._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Market${separator}StorePaymentTier${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(179377)
        
        

        //--TRIMMABLE-BOUNDARY-START(375985)
        $asm.$cls(`$JkHl.LCCMS.CommunityMarketShoppingPaymentTierView`, ($self) => class CommunityMarketShoppingPaymentTierView extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(133144362161)
            /*string */ get OptimizedComponentName()
            {
                return "communitymarketshoppingpaymenttierview";
            }
            //--TRIMMABLE-BOUNDARY-END(133144362161)
            
            //--TRIMMABLE-BOUNDARY-START(227633642673)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633642673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Pay":
                    this.Pay = $.$cast(parameter.Value, $.$hDPm.LCFCC$1.IBaseComponent);
                    return true;
                    case "Service":
                    this.Service = $.$cast(parameter.Value, $.$JkHl.LCCMS.CommunityMarketShoppingPaymentTierProvider);
                    return true;
                    case "Tier":
                    this.Tier = $.$cast(parameter.Value, $.$AvdQ.LCFCP.ServiceTierModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(227633642673)
            
            //--TRIMMABLE-BOUNDARY-START(107374558385)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374558385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ShippingServices = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$YUlm.LCSCS.IShippingService), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(107374558385)
            
            //--TRIMMABLE-BOUNDARY-START(214748740785)
            /*IEnumerable<IShippingService>*/ ShippingServices = null;
            //--TRIMMABLE-BOUNDARY-END(214748740785)
            
            //--TRIMMABLE-BOUNDARY-START(137439329457)
            /*IBaseComponent?*/ Pay = null;
            //--TRIMMABLE-BOUNDARY-END(137439329457)
            
            //--TRIMMABLE-BOUNDARY-START(154619198641)
            /*CommunityMarketShoppingPaymentTierProvider*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(154619198641)
            
            //--TRIMMABLE-BOUNDARY-START(223338675377)
            /*ServiceTierModel?*/ Tier = null;
            //--TRIMMABLE-BOUNDARY-END(223338675377)
            
            //--TRIMMABLE-BOUNDARY-START(120259460273)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(120259460273)
            
            //--TRIMMABLE-BOUNDARY-START(115964492977)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(115964492977)
            
            //--TRIMMABLE-BOUNDARY-START(124554427569)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554427569);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let store;
                    if ($.$is((this.Tier?.Tag ?? null), $.$Fjop.LCCMCM.CommunityMarketProductStoreModel, { set $v($v){ store = $v; } }))
                    {
                        let $t2, $r2;
                        /*var*/ let provider = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider, this.Service.StoresProvider, $.$dspc(store.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString));
                        if (provider === null)
                        {
                            provider = new $.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider().$ctor$1(this.UnitOfWork, this.Service, store);
                            this.Service.StoresProvider.set_Item($.$dspc(store.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString), provider);
                        }
                        this.Service.CurrentStoreCatalogueProvider = provider;
                        ($t2 = this.Open(provider), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(124554427569)
            
            //--TRIMMABLE-BOUNDARY-START(141734296753)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(141734296753)
            
            //--TRIMMABLE-BOUNDARY-START(141734296753)
            //--TRIMMABLE-BOUNDARY-START(38655081649)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655081649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38655081649)
            
            //--TRIMMABLE-BOUNDARY-START(150324231345)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324231345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(150324231345)
            
            //--TRIMMABLE-BOUNDARY-END(141734296753)
            
            //--TRIMMABLE-BOUNDARY-START(210453773489)
            /*Task *//*async*/  Setup(/*IShippingService*/ shipping)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(210453773489);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Service.ShippingCost = new $.$fPer.LCFCDM.Money();
                    if (this.Service.ShippingService === shipping)
                    {
                        this.Service.ShippingService = null;
                    }
                    else 
                    {
                        if (this.Service.DeliveryLocation !== null)
                        {
                            let $t4, $r4;
                            this.Service.ShippingService = shipping;
                            ($t4 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                            {
                                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                                {
                                    /*Money*/ let cost = new $.$fPer.LCFCDM.Money();
                                    let $en5 = this.Service.StoresProvider.Values.GetEnumerator();
                                    while ($en5.MoveNext())
                                    {
                                        let provider = $en5.Current;
                                        {
                                            if (provider.Store.Location !== null)
                                            {
                                                let $t6, $r6;
                                                cost = $.$fPer.LCFCDM.Money.op_Addition(cost, ($t6 = shipping.LCSCS$IShippingService$EstimateCost(provider.Store.Location, this.Service.DeliveryLocation), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6))));
                                            }
                                        }
                                    }
                                    this.Service.ShippingCost = $.$clone(cost);
                                });
                            }, $dbxonf ??= {"r":181338113,"n":"","d":375985,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                            {
                                return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                            }, $lOeszi ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":375985,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        }
                    }
                    _ = (this.Pay ?? this).LCFCC$1$IBaseComponent$StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Market.StorePaymentTier.Blazor\\CommunityMarketShoppingPaymentTierView.razor.cs", "Setup", 81);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(210453773489)
            
            //--TRIMMABLE-BOUNDARY-START(128849394865)
            /*Task *//*async*/  Open(/*CommunityMarketShoppingStoreCatalogueOrderProvider*/ provider)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128849394865);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t7 = $.$hDPm.LCFCI.ViewPresenterExtensions.View$1($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/*c*/ c) =>
                    {
                        return this.StoreBrowser(provider);
                    }, $lAGeed ??= {"r":6881395,"p":[{"n":"c","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":375985,"h":0,"f":17825794}), null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(128849394865)
            
            //--TRIMMABLE-BOUNDARY-START(111669525681)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669525681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(111669525681)
            
            //--TRIMMABLE-BOUNDARY-START(42950048945)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950048945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "h3");
                __builder.AddAttribute$5(1, "class", "mgt-0 mgb");
                __builder.AddContent$4(2, "Shopping from ");
                __builder.AddContent$4(3, $.$$.S.String.Join$5(", ", $.$sl.SL.Enumerable.Select$1($.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider, $.$$.S.String, this.Service.StoresProvider.Values, new ($.$$.S.Func$$$($.$JkHl.LCCMS.CommunityMarketShoppingStoreCatalogueOrderProvider, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Title;
                }, $ljitXg ??= {"r":1310721,"p":[{"n":"c","p":441521}],"n":"","d":375985,"h":0,"f":17825794}))));
                __builder.CloseElement();
                __builder.AddMarkupContent(4, "\r\n");
                __builder.OpenElement(5, "div");
                __builder.AddAttribute$5(6, "class", "corner bg-primary-01 bd pd pos-rel");
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 7);
                __builder.AddComponentParameter(8, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(9, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(10, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    let $en8 = this.Service.StoresProvider.GetEnumerator();
                    while ($en8.MoveNext())
                    {
                        let _provider = $en8.Current;
                        {
                            /*var*/ let provider = _provider;
                            __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 11);
                            __builder2.AddComponentParameter(12, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, provider.Value.Title));
                            __builder2.AddComponentParameter(13, "IconDescriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, provider.Value.Icon));
                            __builder2.AddComponentParameter(14, "Description", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, provider.Value.Description));
                            __builder2.AddComponentParameter(15, "NavigateIcon", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                            __builder2.AddComponentParameter(16, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures, 0/*DataListDefaultItemTemplateFeatures.Default*/ | 1/*DataListDefaultItemTemplateFeatures.RoundedImage*/), $.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures));
                            __builder2.AddComponentParameter(17, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                            {
                                return this.Open(provider.Value);
                            }, $DtvoVj ??= {"r":178454529,"n":"","d":375985,"h":0,"f":17825794})));
                            __builder2.AddAttribute$3(18, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenElement(19, "div");
                                __builder3.AddAttribute$5(20, "class", "flex mgy-1");
                                if (this.Service.DeliveryLocation !== null && provider.Value.Store.Location === null && (provider.Value.Store.Settings?.Location ?? null) === null)
                                {
                                    __builder3.AddMarkupContent(21, "<small class=\"cl-error fill mgr mgy-a\">\r\n                            This store has not specified a location. Cannot deliver from.\r\n                        </small>");
                                }
                                __builder3.AddMarkupContent(22, "<div class=\"fill\"></div>\r\n                    ");
                                __builder3.OpenElement(23, "div");
                                __builder3.OpenElement(24, "button");
                                __builder3.AddAttribute$5(25, "type", "button");
                                __builder3.AddAttribute$5(26, "class", "mdi mdi-delete fsz-11 mgl-a bg-error pd-1 corner nowrap");
                                __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 27, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                {
                                    return this.Service.StoresProvider.Remove$1(provider.Key);
                                }, $wWQwdc ??= {"r":65537,"n":"","d":375985,"h":0,"f":17825794})));
                                __builder3.AddContent$4(28, "Remove");
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                            }), $dmgnbj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":375985,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            if (provider.Value.Order !== null)
                            {
                                __builder2.OpenElement(29, "div");
                                __builder2.AddAttribute$5(30, "class", "mahx-2 scroll bg-card mgb");
                                __builder2.AddContent$1(31, $.$dgLE.LCPCS$1.CatalogueOrderViews.OrderItems(this, provider.Value, provider.Value.Order.Items, false, false));
                                __builder2.CloseElement();
                            }
                        }
                    }
                    if ($.$sl.SL.Enumerable.Any$1($.$YUlm.LCSCS.IShippingService, this.ShippingServices))
                    {
                        $.$JkHl._LCCMSC.TypeInference.CreateInputEditor_0($.$fPer.LCFCDG.GeoLocation, __builder2, 32, 33, "mgy bg-card", 34, "Delivery Location", 35, this.Service.DeliveryLocation, 36, $.$mac.MAC.EventCallback.Factory.Create$6($.$fPer.LCFCDG.GeoLocation, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$fPer.LCFCDG.GeoLocation, this, new ($.$$.S.Action$$($.$fPer.LCFCDG.GeoLocation))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            return this.Service.DeliveryLocation = __value;
                        }, $BDQiCi ??= {"r":65537,"p":[{"n":"__value","p":13928790}],"n":"","d":375985,"h":0,"f":17825794}), this.Service.DeliveryLocation)), 37, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                        {
                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Service"), "DeliveryLocation"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                        }, $AWbQAe ??= {"r":38797349,"n":"","d":375985,"h":0,"f":17825794})).Invoke()));
                        if (this.Service.DeliveryLocation !== null)
                        {
                            __builder2.OpenElement(38, "div");
                            __builder2.AddAttribute$5(39, "class", "bg-card pd mgt");
                            __builder2.OpenElement(40, "b");
                            __builder2.AddMarkupContent(41, "\r\n                        Add Handyman Delivery\r\n");
                            if (this.Service.DeliveryLocation !== null)
                            {
                                __builder2.OpenElement(42, "small");
                                __builder2.AddAttribute$5(43, "class", "cl-primary");
                                __builder2.AddContent$4(44, "(");
                                __builder2.AddContent$3(45, this.Service.DeliveryLocation);
                                __builder2.AddContent$4(46, ")");
                                __builder2.CloseElement();
                            }
                            __builder2.CloseElement();
                            let $en9 = this.ShippingServices.SCG$IEnumerable$$$GetEnumerator();
                            while ($en9.SC$1$IEnumerator$MoveNext())
                            {
                                let shipping = $en9.SCG$IEnumerator$$$Current;
                                {
                                    __builder2.OpenElement(47, "div");
                                    __builder2.AddAttribute$5(48, "class", "flex pdy-2 bdb");
                                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 49, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, $.$hDPm.LCFCC$1.BaseComponent.NoStateChanged$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                    {
                                        return this.Setup(shipping);
                                    }, $tjTvNi ??= {"r":178454529,"n":"","d":375985,"h":0,"f":17825794}))));
                                    __builder2.OpenElement(50, "i");
                                    __builder2.AddAttribute$5(51, "class", $.$strNN($.$strNN($.$strNN("mgy-a" + " mdi") + " ") + $.$strNN((this.Service.ShippingService === shipping ? "mdi-checkbox-outline cl-primary" : "mdi-checkbox-blank-outline"))) + " fsz-30");
                                    __builder2.CloseElement();
                                    __builder2.AddMarkupContent(52, "\r\n                            ");
                                    __builder2.OpenElement(53, "div");
                                    __builder2.AddAttribute$5(54, "class", "miwx-04 mawx-04 mihx-04 mahx-04 mgy-a mgl clip");
                                    __builder2.OpenComponent$1($.$hDPm.LCFCCI.Icon, 55);
                                    __builder2.AddComponentParameter(56, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, shipping.LCFC$IDisplayable$Icon));
                                    __builder2.AddComponentParameter(57, "MediaHeight", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 40), $.$$.S.Int32));
                                    __builder2.AddComponentParameter(58, "MediaWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 40), $.$$.S.Int32));
                                    __builder2.AddComponentParameter(59, "IconSize", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 40), $.$$.S.Int32));
                                    __builder2.AddComponentParameter(60, "MediaFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                    __builder2.AddComponentParameter(61, "Class", "round mgy-a");
                                    __builder2.CloseComponent();
                                    __builder2.CloseElement();
                                    __builder2.AddMarkupContent(62, "\r\n                            ");
                                    __builder2.OpenElement(63, "div");
                                    __builder2.AddAttribute$5(64, "class", "stack mgy-a mgl fill clip");
                                    __builder2.OpenElement(65, "h3");
                                    __builder2.AddAttribute$5(66, "class", "mg-0");
                                    __builder2.AddContent$4(67, shipping.LCFC$IDisplayable$Title);
                                    __builder2.CloseElement();
                                    __builder2.AddMarkupContent(68, "\r\n                                ");
                                    __builder2.OpenElement(69, "span");
                                    __builder2.AddAttribute$5(70, "class", "nowrap");
                                    __builder2.AddContent$4(71, shipping.LCFC$IDescribable$Description);
                                    __builder2.CloseElement();
                                    __builder2.CloseElement();
                                    if (this.Service.ShippingService === shipping && $.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, this.Service.ShippingCost))
                                    {
                                        __builder2.OpenElement(72, "h3");
                                        __builder2.AddAttribute$5(73, "class", "mgy-a");
                                        __builder2.AddContent$3(74, this.Service.ShippingCost);
                                        __builder2.CloseElement();
                                    }
                                    __builder2.CloseElement();
                                }
                            }
                            __builder2.CloseElement();
                        }
                    }
                }), $Eydvxb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":375985,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(42950048945)
            
            //--TRIMMABLE-BOUNDARY-START(219043708081)
            /*RenderFragment */ StoreBrowser(/*CommunityMarketShoppingStoreCatalogueOrderProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043708081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$dgLE.LCPCS$1.CatalogueOrder, 75);
                    __builder2.AddComponentParameter(76, "Class", "fill");
                    __builder2.AddComponentParameter(77, "Provider", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$dgLE.LCPCS$1.ICatalogueOrderProvider, provider));
                    __builder2.AddComponentParameter(78, "Order", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$AvdQ.LCFCP.ICatalogueOrderModel, provider.Order));
                    __builder2.AddComponentParameter(79, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `Shopping \"${$.$strNN(provider.Store.Title)}\" store`));
                    __builder2.CloseComponent();
                }, $otuolb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":375985,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(219043708081)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(30065147057)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065147057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065147057)
            
            //--TRIMMABLE-BOUNDARY-START(30065147057)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(30065147057)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(214748740785)
                this.ShippingServices = null;
                //--TRIMMABLE-BOUNDARY-END(214748740785)
                
                //--TRIMMABLE-BOUNDARY-START(137439329457)
                this.Pay = null;
                //--TRIMMABLE-BOUNDARY-END(137439329457)
                
                //--TRIMMABLE-BOUNDARY-START(154619198641)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(154619198641)
                
                //--TRIMMABLE-BOUNDARY-START(120259460273)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(120259460273)
                
            }
            static $h = 375985;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133144362161),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719852721,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 375985,
      "h": 133144362161,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144362161),
//--TRIMMABLE-BOUNDARY-START(214748740785),
    {
      "p": $.$$.SCG.IEnumerable$$($.$YUlm.LCSCS.IShippingService).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489656497,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197568871601,
        "f": 83886081
      },
      "n": "ShippingServices",
      "d": 375985,
      "h": 214748740785,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214748740785),
//--TRIMMABLE-BOUNDARY-START(137439329457),
    {
      "p": 25515690,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309787313,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180389002417,
        "f": 83886081
      },
      "n": "Pay",
      "d": 375985,
      "h": 137439329457,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439329457),
//--TRIMMABLE-BOUNDARY-START(154619198641),
    {
      "p": 310449,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899721905,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188978937009,
        "f": 83886081
      },
      "n": "Service",
      "d": 375985,
      "h": 154619198641,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619198641),
//--TRIMMABLE-BOUNDARY-START(223338675377),
    {
      "p": 4764608,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079591089,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206158806193,
        "f": 83886081
      },
      "n": "Tier",
      "d": 375985,
      "h": 223338675377,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223338675377),
//--TRIMMABLE-BOUNDARY-START(120259460273),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129918129,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799067825,
        "f": 83886081
      },
      "n": "Loading",
      "d": 375985,
      "h": 120259460273,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259460273),
//--TRIMMABLE-BOUNDARY-START(115964492977),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539983537,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209133233,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 375985,
      "h": 115964492977,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964492977)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(227633642673),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 375985,
      "h": 227633642673,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(227633642673),
//--TRIMMABLE-BOUNDARY-START(107374558385),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 375985,
      "h": 107374558385,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107374558385),
//--TRIMMABLE-BOUNDARY-START(124554427569),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 375985,
      "h": 124554427569,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(124554427569),
//--TRIMMABLE-BOUNDARY-START(210453773489),
    {
      "r": 178454529,
      "p": [
        {
          "n": "shipping",
          "p": 2459769
        }
      ],
      "n": "Setup",
      "d": 375985,
      "h": 210453773489,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(210453773489),
//--TRIMMABLE-BOUNDARY-START(128849394865),
    {
      "r": 178454529,
      "p": [
        {
          "n": "provider",
          "p": 441521
        }
      ],
      "n": "Open",
      "d": 375985,
      "h": 128849394865,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(128849394865),
//--TRIMMABLE-BOUNDARY-START(111669525681),
    {
      "r": 181338113,
      "n": "Load",
      "d": 375985,
      "h": 111669525681,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669525681),
//--TRIMMABLE-BOUNDARY-START(42950048945),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 375985,
      "h": 42950048945,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(42950048945),
//--TRIMMABLE-BOUNDARY-START(219043708081),
    {
      "r": 6881395,
      "p": [
        {
          "n": "provider",
          "p": 441521
        }
      ],
      "n": "StoreBrowser",
      "d": 375985,
      "h": 219043708081,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(219043708081)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065147057),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 375985,
      "h": 30065147057,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065147057)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(141734296753),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 375985,
        "h": 38655081649,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 375985,
        "h": 150324231345,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 375985,
      "h": 141734296753,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(141734296753)
  ],
  "h": 375985
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Market.StorePaymentTier.CommunityMarketShoppingPaymentTierView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Market${separator}StorePaymentTier${separator}CommunityMarketShoppingPaymentTierView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(375985)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Market.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Shipping.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(48305)
