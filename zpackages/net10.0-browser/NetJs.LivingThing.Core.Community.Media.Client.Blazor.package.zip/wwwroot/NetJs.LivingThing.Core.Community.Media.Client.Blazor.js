
//--TRIMMABLE-BOUNDARY-START(37346)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $OSmP) {
    "use strict";
    let _;
    let $sCvBHd;
    let $juYCUi;
    let $jNwqEf;
    let $NVRTfb;
    let $sSzDpd;
    let $BbpVie;
    let $zgHRZh;
    let $gmOUsj;
    let $vxlpth;
    let $gBaNah;
    let $hBhADf;
    let $PtPzJd;
    let $zzmITj;
    let $czzLef;
    let $mbGnpc;
    let $LsOXbe;
    let $ZisFag;
    let $bdGxEe;
    let $dEsAbe;
    let $JFSPWf;
    let $kkwoEd;
    let $enHIJk;
    let $gPmMpe;
    let $SHsUQc;
    let $VXBiVh;
    let $gKsQDi;
    let $QPjGlc;
    let $yOtpmg;
    let $afzBSh;
    let $xhpMKe;
    let $wmunub;
    let $yGASea;
    let $EqHzPh;
    let $UFvEqj;
    let $YLaWml;
    let $cXMhGh;
    let $bhPwvj;
    let $BfZbCc;
    let $NNeRZc;
    let $QNyhXa;
    let $BxHgLi;
    let $RMkwYb;
    let $PoJHvd;
    let $ujASNk;
    let $VEhqkd;
    let $OCXgib;
    let $ZDiCtd;
    let $atyAgj;
    let $EWMnzb;
    let $GkJNSj;
    let $nqrtwc;
    let $xKbbvj;
    let $qpYEgh;
    let $UFkyfe;
    let $umKlca;
    let $KAVuJd;
    let $lQnWfg;
    let $NBizse;
    let $oxplZf;
    let $isjZYg;
    let $kNyszk;
    let $CNiQBk;
    let $zkTgsh;
    let $ENFttf;
    let $FiDPtj;
    let $deKSll;
    let $UKRzva;
    let $MXcKoh;
    let $xSvPff;
    let $VZUirh;
    let $gkPSEb;
    let $tfGAhj;
    let $zDsLBe;
    let $lzNKXd;
    let $NaNNek;
    let $asBeBg;
    let $enBfvf;
    let $XLfysc;
    let $ocFGca;
    let $PxBYPi;
    let $ASMIKf;
    let $hazPIe;
    let $prIXUd;
    let $ECvqOc;
    let $pWJaUj;
    let $aEgyQb;
    let $IrjMea;
    let $OsDmUh;
    let $xBpEyh;
    let $DzZBCa;
    let $giAImh;
    let $PmZMIe;
    let $lOdSWi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Media.Client.Blazor", 
    {
  "h": 37346,
  "f": "LivingThing.Core.Community.Media.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Media.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Media.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(299490)
        $asm.$cls(`$QxAa.LCCMC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295266786)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295266786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$QxAa.LCCMC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295266786)
            
            static $h = 299490;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295266786),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 299490,
      "h": 4295266786,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295266786)
  ],
  "h": 299490
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(299490)
        
        

        //--TRIMMABLE-BOUNDARY-START(102882)
        $asm.$cls(`$QxAa._LCCMCSM.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295070178)
            static /*void */ CreateDataList_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295070178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "Features", $.$box(__arg1, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq2, "ChildContent", __arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295070178)
            
            static $h = 102882;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295070178),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 14505642
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_0",
      "d": 102882,
      "h": 4295070178,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295070178)
  ],
  "h": 102882
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Media.Client.Shared.MediaPage.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Shared${separator}MediaPage${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(102882)
        
        

        //--TRIMMABLE-BOUNDARY-START(168418)
        $asm.$cls(`$QxAa._LCCMCSM$1.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295135714)
            static /*void */ CreateCommunityPostHeader_0(TPostModel, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*TPostModel*/ __arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295135714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCSP.CommunityPostHeader$$(TPostModel), seq);
                __builder.AddComponentParameter(__seq0, "Title", __arg0);
                __builder.AddComponentParameter(__seq1, "ViewModel", $.$box(__arg1, TPostModel));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295135714)
            
            static $h = 168418;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295135714),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TPostModel) => TPostModel.$h
        }
      ],
      "g": [
        "TPostModel"
      ],
      "n": "CreateCommunityPostHeader_0",
      "d": 168418,
      "h": 4295135714,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295135714)
  ],
  "h": 168418
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Media.Client.Shared.MediaPlayerPage.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Shared${separator}MediaPlayerPage${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(168418)
        
        

        //--TRIMMABLE-BOUNDARY-START(365026)
        $asm.$cls(`$QxAa.LCCMC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180234210)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QxAa.LCCMCP.CommunityMediaApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QxAa.LCCMCP.CommunityMediaApp().$ctor$6();
                    }, $juYCUi ??= {"r":2752627,"n":"","d":365026,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QxAa.LCCMCS$1.MediaCard.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QxAa.LCCMCS$1.MediaCard().$ctor$5();
                    }, $jNwqEf ??= {"r":2752627,"n":"","d":365026,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QxAa.LCCMCS$1.MediaPage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QxAa.LCCMCS$1.MediaPage().$ctor$3();
                    }, $NVRTfb ??= {"r":2752627,"n":"","d":365026,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QxAa.LCCMCS$1.MediaPlayerPage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QxAa.LCCMCS$1.MediaPlayerPage().$ctor$4();
                    }, $sSzDpd ??= {"r":2752627,"n":"","d":365026,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QxAa.LCCMCS$1.PagePlayer.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QxAa.LCCMCS$1.PagePlayer().$ctor$5();
                    }, $BbpVie ??= {"r":2752627,"n":"","d":365026,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QxAa.LCCMCS$1.PlaylistMenu.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QxAa.LCCMCS$1.PlaylistMenu().$ctor$5();
                    }, $zgHRZh ??= {"r":2752627,"n":"","d":365026,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180234210)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295332322)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295332322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295332322)
            
            //--TRIMMABLE-BOUNDARY-START(4295332322)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295332322)
            
            static $h = 365026;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180234210),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885266914,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 365026,
      "h": 17180234210,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180234210)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295332322),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 365026,
      "h": 4295332322,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295332322)
  ],
  "h": 365026
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(365026)
        
        

        //--TRIMMABLE-BOUNDARY-START(758242)
        $asm.$cls(`$QxAa.LCCMCS.MediaProvider`, ($self) => class MediaProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590692834)
            /*CommunityMediaApplication*/ application = null;
            //--TRIMMABLE-BOUNDARY-END(8590692834)
            
            //--TRIMMABLE-BOUNDARY-START(4295725538)
            $ctor$1(/*CommunityMediaApplication*/ appllication)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295725538);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.application = appllication;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295725538)
            
            //--TRIMMABLE-BOUNDARY-START(12885660130)
            /*RenderFragment */ GetMedias(/*PostBaseModel*/ parent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885660130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenComponent$1($.$mac.MAC.CascadingValue$$($.$ahDc.LCCCS.ICommunityClientApplication), 1);
                    builder.AddAttribute$4(2, "Value", this.application);
                    builder.AddAttribute$3(3, "ChildContent", $.$hDPm.LCFC.FragmentView.From$1($.$QxAa.LCCMCP.CommunityMediaApp, (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                        const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.set_Item("ParentScope", parent);
                        return $i1;
                    })(), null, null));
                    builder.CloseComponent();
                }, $sCvBHd ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":758242,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(12885660130)
            
            //--TRIMMABLE-BOUNDARY-START(4312896960)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityMediaProvider.GetMedias(LivingThing.Core.Frameworks.Common.Posts.Models.PostBaseModel)
            LCCCS$ICommunityMediaProvider$GetMedias()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312896960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetMedias(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312896960)
            
            static $h = 758242;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885660130),
    {
      "r": 6881395,
      "p": [
        {
          "n": "parent",
          "p": 16771508
        }
      ],
      "n": "GetMedias",
      "d": 758242,
      "h": 12885660130,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885660130)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590692834),
    {
      "t": 561634,
      "n": "application",
      "d": 758242,
      "h": 8590692834,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590692834)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295725538),
    {
      "p": [
        {
          "n": "appllication",
          "p": 561634
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 758242,
      "h": 4295725538,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295725538)
  ],
  "h": 758242
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityMediaProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.Services.MediaProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Services${separator}MediaProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(758242)
        
        

        //--TRIMMABLE-BOUNDARY-START(496098)
        $asm.$cls(`$QxAa.LCCMC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590430690)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590430690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$QxAa.LCCMCS.CommunityMediaService, $.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$OSmP.LCCMCM.CommunityMediaPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$QxAa.LCCMCS.CommunityMediaApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QxAa.LCCMCS.CommunityMediaApplication, x);
                }, $gmOUsj ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":496098,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QxAa.LCCMCS.CommunityMediaApplication, x);
                }, $vxlpth ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":496098,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$OSmP.LCCMCM.CommunityMediaPostModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$OSmP.LCCMCM.CommunityMediaAlbumModel, services, null);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCS.ICommunityMediaProvider, $.$QxAa.LCCMCS.MediaProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$QxAa.LCCMCS.CommunityMediaFeedProvider, services);
                $.$QxAa.LCCMC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590430690)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$QxAa.LCCMC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295463394)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295463394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295463394)
            
            //--TRIMMABLE-BOUNDARY-START(4295463394)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295463394)
            
            static $h = 496098;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590430690),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 496098,
      "h": 8590430690,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590430690)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295463394),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 496098,
      "h": 4295463394,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295463394)
  ],
  "h": 496098
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(496098)
        
        

        //--TRIMMABLE-BOUNDARY-START(1348066)
        $asm.$cls(`$QxAa.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296315362)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296315362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296315362)
            
            //--TRIMMABLE-BOUNDARY-START(4296315362)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296315362)
            
            static $h = 1348066;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296315362),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1348066,
      "h": 4296315362,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296315362)
  ],
  "h": 1348066,
  "a": [
    {
      "t": 1282530,
      "c": 4296249826
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1348066)
        
        

        //--TRIMMABLE-BOUNDARY-START(1282530)
        $asm.$cls(`$QxAa.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296249826)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296249826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296249826)
            
            //--TRIMMABLE-BOUNDARY-START(4296249826)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296249826)
            
            static $h = 1282530;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296249826),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1282530,
      "h": 4296249826,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296249826)
  ],
  "h": 1282530
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1282530)
        
        

        //--TRIMMABLE-BOUNDARY-START(889314)
        $asm.$cls(`$QxAa.LCCMCS$1.MediaList`, ($self) => class MediaList extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590823906)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590823906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590823906)
            
            //--TRIMMABLE-BOUNDARY-START(4295856610)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295856610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295856610)
            
            //--TRIMMABLE-BOUNDARY-START(4295856610)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295856610)
            
            static $h = 889314;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590823906),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 889314,
      "h": 8590823906,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590823906)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295856610),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 889314,
      "h": 4295856610,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295856610)
  ],
  "h": 889314
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.Shared.MediaList`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Shared${separator}MediaList`; }
        });
        //--TRIMMABLE-BOUNDARY-END(889314)
        
        

        //--TRIMMABLE-BOUNDARY-START(1151458)
        $asm.$cls(`$QxAa.LCCMCS$1.PlaylistList`, ($self) => class PlaylistList extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8591086050)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591086050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8591086050)
            
            //--TRIMMABLE-BOUNDARY-START(4296118754)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296118754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296118754)
            
            //--TRIMMABLE-BOUNDARY-START(4296118754)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296118754)
            
            static $h = 1151458;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591086050),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1151458,
      "h": 8591086050,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591086050)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296118754),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1151458,
      "h": 4296118754,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296118754)
  ],
  "h": 1151458
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.Shared.PlaylistList`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Shared${separator}PlaylistList`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1151458)
        
        

        //--TRIMMABLE-BOUNDARY-START(233954)
        $asm.$cls(`$QxAa.LCCMC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590168546)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590168546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590168546)
            
            //--TRIMMABLE-BOUNDARY-START(4295201250)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295201250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295201250)
            
            //--TRIMMABLE-BOUNDARY-START(4295201250)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295201250)
            
            static $h = 233954;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590168546),
    {
      "r": 65537,
      "n": "Execute",
      "d": 233954,
      "h": 8590168546,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590168546)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295201250),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 233954,
      "h": 4295201250,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295201250)
  ],
  "h": 233954
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(233954)
        
        

        //--TRIMMABLE-BOUNDARY-START(954850)
        $asm.$cls(`$QxAa.LCCMCS$1.MediaPage`, ($self) => class MediaPage extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(64425464290)
            /*CommunityMediaService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(64425464290)
            
            //--TRIMMABLE-BOUNDARY-START(60130496994)
            /*PostBaseModel*/ Parent = null;
            //--TRIMMABLE-BOUNDARY-END(60130496994)
            
            //--TRIMMABLE-BOUNDARY-START(21475791330)
            /*bool */ FilterPageType(/*PostTypes*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475791330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (a === 2816/*PostTypes.Media*/ || !$.$$.S.String.StartsWith$3.call($.$$.S.Enum.ToStringT($.$LCOv.LCFCPM$1.PostTypes, $.$$.S.UInt32, a), "Media"))
                {
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(21475791330)
            
            //--TRIMMABLE-BOUNDARY-START(55835529698)
            /*string */ get OptimizedComponentName()
            {
                return "mediapage";
            }
            //--TRIMMABLE-BOUNDARY-END(55835529698)
            
            //--TRIMMABLE-BOUNDARY-START(85900300770)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900300770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Parent":
                    this.Parent = $.$cast(parameter.Value, $.$LCOv.LCFCPM$1.PostBaseModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(85900300770)
            
            //--TRIMMABLE-BOUNDARY-START(51540562402)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540562402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QxAa.LCCMCS.CommunityMediaService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(51540562402)
            
            //--TRIMMABLE-BOUNDARY-START(17180824034)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180824034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 0);
                __builder.AddComponentParameter(1, "Name", "Media");
                __builder.AddComponentParameter(2, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/ | ((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box.IsMobile ?? false) ? 4/*ApplicationPageAccessibility.Tab*/ : 0/*ApplicationPageAccessibility.None*/)), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                __builder.AddAttribute$3(3, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$4(4, "Media");
                    }, $EWMnzb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":954850,"h":0,"f":17825794});
                }), $GkJNSj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":954850,"h":0,"f":17825794}));
                __builder.AddAttribute$3(5, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(6, "<i class=\"mdi mdi-audio-video\"></i>");
                    }, $nqrtwc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":954850,"h":0,"f":17825794});
                }), $xKbbvj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":954850,"h":0,"f":17825794}));
                __builder.AddAttribute$3(7, "FloatingButtons", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 8);
                        __builder2.AddComponentParameter(9, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.AddComponentParameter(10, "PageLink", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$fPer.LCFCR$3.RoutePath.AsRelativeToRoot("Media/Create")));
                        __builder2.AddComponentParameter(11, "PageParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Parent));
                        __builder2.AddComponentParameter(12, "Class", "mdi mdi-plus");
                        __builder2.AddComponentParameter(13, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 132178/*ButtonFeatures.FloatingButton*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.CloseComponent();
                    }, $qpYEgh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":954850,"h":0,"f":17825794});
                }), $UFkyfe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":954850,"h":0,"f":17825794}));
                __builder.AddAttribute$3(14, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        if (this.Parent !== null)
                        {
                            __builder2.OpenElement(15, "h2");
                            __builder2.AddContent$4(16, this.Parent.Title);
                            __builder2.AddContent$4(17, " MEDIA");
                            __builder2.CloseElement();
                        }
                        /*var*/ let types = $.$sl.SL.Enumerable.Where($.$LCOv.LCFCPM$1.PostTypes, $.$$.S.Enum.GetValues$1($.$LCOv.LCFCPM$1.PostTypes), new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.PostTypes, $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                        {
                            return $.$$.S.Enum.ToStringT($.$LCOv.LCFCPM$1.PostTypes, $.$$.S.UInt32, e) !== "Media" && $.$$.S.String.StartsWith$3.call($.$$.S.Enum.ToStringT($.$LCOv.LCFCPM$1.PostTypes, $.$$.S.UInt32, e), "Media");
                        }, $umKlca ??= {"r":262145,"p":[{"n":"e","p":21096884}],"n":"","d":954850,"h":0,"f":17825794}));
                        $.$QxAa._LCCMCSM.TypeInference.CreateDataList_0($.$LCOv.LCFCPM$1.PostTypes, __builder2, 18, 19, types, 20, 35184372092928n | 33554432n, 21, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.PostTypes, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.PostTypes))))().$ctor(this,  (/*media*/ media) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                /*var*/ let d = $.$fPer.LCFCT.EnumExtensions.GetDisplayable($.$box(media.Model, $.$LCOv.LCFCPM$1.PostTypes));
                                __builder3.OpenElement(22, "div");
                                __builder3.AddAttribute$5(23, "class", "bg-card pd corner shadow wx-1 hx-1 stack text-center mg-1");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCI.Icon, 24);
                                __builder3.AddComponentParameter(25, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, d.LCFC$IDisplayable$Icon));
                                __builder3.AddComponentParameter(26, "Class", "mgx-a fsz-40");
                                __builder3.CloseComponent();
                                __builder3.AddMarkupContent(27, "\r\n                    ");
                                __builder3.OpenElement(28, "h3");
                                __builder3.AddAttribute$5(29, "class", "mgb-0");
                                __builder3.AddContent$4(30, $.$$.S.String.Replace$3.call(d.LCFC$IDisplayable$Title, "Media ", ""));
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                            }, $KAVuJd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":954850,"h":0,"f":17825794});
                        }, $lQnWfg ??= {"r":6881395,"p":[{"n":"media","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.PostTypes, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.PostTypes)).$h}],"n":"","d":954850,"h":0,"f":17825794}));
                        let $en2 = types.SCG$IEnumerable$$$GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let type = $en2.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let _type = $.$$.S.String.Replace$3.call($.$$.S.Enum.ToStringT($.$LCOv.LCFCPM$1.PostTypes, $.$$.S.UInt32, type), "Media", "");
                                __builder2.OpenComponent$1($.$ahDc.LCCCSP.CommunityCarouselPosts$$($.$OSmP.LCCMCM.CommunityMediaPostModel), 31);
                                __builder2.AddComponentParameter(32, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `Recent ${$.$strNN(_type)}`));
                                __builder2.AddComponentParameter(33, "Filter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$12((this.Parent?.Identifier ?? null) ?? new $.$fPer.LCFCD.DataId().$ctor$2()).WithFilterEnum$2($.$LCOv.LCFCPM$1.PostFilterTypes, $.$LCOv.LCFCPM$1.PostTypes, 1073741840/*PostFilterTypes.InParent*/, type)));
                                __builder2.AddAttribute$3(34, "TitleTemplate", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(35, "div");
                                    __builder3.AddAttribute$5(36, "class", "row pdb mgt-10");
                                    __builder3.OpenElement(37, "div");
                                    __builder3.AddAttribute$5(38, "class", "col-10");
                                    __builder3.OpenElement(39, "h3");
                                    __builder3.AddAttribute$5(40, "class", "mg-0");
                                    __builder3.AddContent$4(41, "Recent ");
                                    __builder3.AddContent$4(42, _type);
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(43, "\r\n                            ");
                                    __builder3.OpenElement(44, "div");
                                    __builder3.AddAttribute$5(45, "class", "col-a");
                                    __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 46);
                                    __builder3.AddComponentParameter(47, "href", `${$.$strNN(_type)}`);
                                    __builder3.AddAttribute$3(48, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.AddMarkupContent(49, "More >>");
                                    }), $NBizse ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":954850,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }), $oxplZf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":954850,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                            }
                        }
                    }, $isjZYg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":954850,"h":0,"f":17825794});
                }), $kNyszk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":954850,"h":0,"f":17825794}));
                __builder.AddAttribute$3(50, "ChildPages", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$ahDc.LCCCSP.CommunityPostListPagesFromEnum$$($.$OSmP.LCCMCM.CommunityMediaPostModel), 51);
                    __builder2.AddComponentParameter(52, "PrefixType", "Media");
                    __builder2.AddComponentParameter(53, "FilterType", new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.PostTypes, $.$$.S.Boolean))().$ctor(this, (this.FilterPageType)));
                    __builder2.AddComponentParameter(54, "Parent", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.PostBaseModel, this.Parent));
                    __builder2.CloseComponent();
                }), $CNiQBk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":954850,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17180824034)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885856738)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885856738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885856738)
            
            //--TRIMMABLE-BOUNDARY-START(12885856738)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885856738)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64425464290)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(64425464290)
                
            }
            static $h = 954850;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425464290),
    {
      "p": 692706,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245595106,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605333474,
        "f": 83886081
      },
      "n": "Service",
      "d": 954850,
      "h": 64425464290,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425464290),
//--TRIMMABLE-BOUNDARY-START(60130496994),
    {
      "p": 16771508,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655660514,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015398882,
        "f": 83886081
      },
      "n": "Parent",
      "d": 954850,
      "h": 60130496994,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130496994),
//--TRIMMABLE-BOUNDARY-START(55835529698),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065725922,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 954850,
      "h": 55835529698,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55835529698)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475791330),
    {
      "r": 262145,
      "p": [
        {
          "n": "a",
          "p": 21096884
        }
      ],
      "n": "FilterPageType",
      "d": 954850,
      "h": 21475791330,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475791330),
//--TRIMMABLE-BOUNDARY-START(85900300770),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 954850,
      "h": 85900300770,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900300770),
//--TRIMMABLE-BOUNDARY-START(51540562402),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 954850,
      "h": 51540562402,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540562402),
//--TRIMMABLE-BOUNDARY-START(17180824034),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 954850,
      "h": 17180824034,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180824034)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885856738),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 954850,
      "h": 12885856738,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885856738)
  ],
  "h": 954850
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.Shared.MediaPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Shared${separator}MediaPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(954850)
        
        

        //--TRIMMABLE-BOUNDARY-START(627170)
        $asm.$cls(`$QxAa.LCCMCS.CommunityMediaFeedProvider`, ($self) => class CommunityMediaFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$OSmP.LCCMCM.CommunityMediaPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295594466)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295594466);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295594466)
            
            //--TRIMMABLE-BOUNDARY-START(12885529058)
            /*RenderFragment */ GetFeedCustomIconsView(/*CommunityPostFeedContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885529058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (context.Post.LCFCP$IPost$Type === 2819/*PostTypes.MediaAudio*/ || context.Post.LCFCP$IPost$Type === 2820/*PostTypes.MediaVideo*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$1($.$QxAa.LCCMCS$1.MediaPlayerPage, (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                        const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.set_Item("Media", context.Post);
                        return $i1;
                    })(), null, null);
                }
                return super.GetFeedCustomIconsView($.$clone(context));
            }
            //--TRIMMABLE-BOUNDARY-END(12885529058)
            
            //--TRIMMABLE-BOUNDARY-START(8590561762)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityMediaPostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590561762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`published a ${$.$strNN($.$$.S.String.Replace$3.call($.$$.S.Enum.ToStringT($.$LCOv.LCFCPM$1.PostTypes, $.$$.S.UInt32, model.Type), "Media", ""))}`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590561762)
            
            static $h = 627170;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$OSmP.LCCMCM.CommunityMediaPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885529058),
    {
      "r": 6881395,
      "p": [
        {
          "n": "context",
          "p": 5477824
        }
      ],
      "n": "GetFeedCustomIconsView",
      "d": 627170,
      "h": 12885529058,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885529058),
//--TRIMMABLE-BOUNDARY-START(8590561762),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 1022127
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 627170,
      "h": 8590561762,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590561762)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295594466),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 627170,
      "h": 4295594466,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295594466)
  ],
  "h": 627170
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.Services.CommunityMediaFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Services${separator}CommunityMediaFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(627170)
        
        

        //--TRIMMABLE-BOUNDARY-START(1020386)
        $asm.$cls(`$QxAa.LCCMCS$1.MediaPlayerPage`, ($self) => class MediaPlayerPage extends $.$lJUR.LCFCS.ApplicationPageBase$$($.$OSmP.LCCMCM.CommunityMediaPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(81605399010)
            /*string */ get OptimizedComponentName()
            {
                return "mediaplayerpage";
            }
            //--TRIMMABLE-BOUNDARY-END(81605399010)
            
            //--TRIMMABLE-BOUNDARY-START(128850039266)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850039266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Media":
                    this.Media = $.$cast(parameter.Value, $.$OSmP.LCCMCM.CommunityMediaPostModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(128850039266)
            
            //--TRIMMABLE-BOUNDARY-START(68720497122)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720497122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QxAa.LCCMCS.CommunityMediaService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(68720497122)
            
            //--TRIMMABLE-BOUNDARY-START(98785268194)
            /*CommunityMediaService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(98785268194)
            
            //--TRIMMABLE-BOUNDARY-START(73015464418)
            /*CommunityMediaPostModel*/ Media = null;
            //--TRIMMABLE-BOUNDARY-END(73015464418)
            
            //--TRIMMABLE-BOUNDARY-START(120260104674)
            /*void */ SetProgress(/*int*/ v)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260104674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Service.SetPlayPosition(v);
            }
            //--TRIMMABLE-BOUNDARY-END(120260104674)
            
            //--TRIMMABLE-BOUNDARY-START(124555071970)
            /*void */ SetProgress$1(/*TimeSpan*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555071970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Service.SetPlayPosition$1(value);
            }
            //--TRIMMABLE-BOUNDARY-END(124555071970)
            
            //--TRIMMABLE-BOUNDARY-START(90195333602)
            /*void */ PlayerProgressChanged(/*object*/ sender, /*PlayerProgress*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195333602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Media.Client.Blazor\\MediaPlayerPage.razor.cs", "PlayerProgressChanged", 37);
            }
            //--TRIMMABLE-BOUNDARY-END(90195333602)
            
            //--TRIMMABLE-BOUNDARY-START(21475856866)
            /*IMediaMoment */ get CurrentMoment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655726050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let moments = this.Media.Moments;
                if (moments !== null)
                {
                    /*var*/ let progress = this.Service.PlayProgress;
                    /*var*/ let nn = progress.Position / progress.Duration;
                    return $.$sl.SL.Enumerable.ElementAtOrDefault$1($.$fPer.LCFCD.IMediaMoment, moments, $.$cast((nn * $.$sl.SL.Enumerable.Count$1($.$fPer.LCFCD.IMediaMoment, moments)), $.$$.S.Int32));
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(21475856866)
            
            //--TRIMMABLE-BOUNDARY-START(30065791458)
            /*bool*/ disposed = false;
            //--TRIMMABLE-BOUNDARY-END(30065791458)
            
            //--TRIMMABLE-BOUNDARY-START(94490300898)
            /*ConditionalRender*/ progressBarWrapper = null;
            //--TRIMMABLE-BOUNDARY-END(94490300898)
            
            //--TRIMMABLE-BOUNDARY-START(77310431714)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310431714);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    if (this.Media === null)
                    {
                        this.Media = this.Parameter;
                    }
                    if (this.Media.Type === 2819/*PostTypes.MediaAudio*/)
                    {
                        _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                            {
                                while(!this.disposed)
                                {
                                    let $t3, $r3;
                                    ($t3 = $.$$.STT.Task.Delay$1(1000), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                    if (this.progressBarWrapper !== null && this.Media.Equals$1(this.Service.CurrentMedia) && this.Service.PlayProgress.IsPlaying)
                                    {
                                        let $t4, $r4;
                                        ($t4 = this.progressBarWrapper.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Media.Client.Blazor\\MediaPlayerPage.razor.cs", "OnInitializedAsync", 76), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                    }
                                }
                            });
                        }, $zkTgsh ??= {"r":178454529,"n":"","d":1020386,"h":0,"f":17829890}));
                    }
                    this.Service.add_OnPlayProgress(new ($.$$.S.EventHandler$$($.$fPer.LCFCS$3.PlayerProgress))().$ctor(this, this.PlayerProgressChanged));
                    super.OnInitialized();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77310431714)
            
            //--TRIMMABLE-BOUNDARY-START(85900366306)
            /*ValueTask *//*async*/  Play()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900366306);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.Service.CurrentMedia !== null && !$.$dsp(this.Service.CurrentMedia, $.$$.S.Object, ($t) => $t.Equals$1, this.Media))
                    {
                        let $t5, $r5;
                        ($t5 = this.Service.StopMedia(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                    if (this.Service.PlayProgress.IsStopped)
                    {
                        let $t6, $r6;
                        ($t6 = this.Service.Play(this.Media), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    }
                    else if (this.Service.PlayProgress.IsPlaying)
                    {
                        let $t7, $r7;
                        ($t7 = this.Service.PauseMedia(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    }
                    else 
                    {
                        let $t8, $r8;
                        ($t8 = this.Service.PlayMedia(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85900366306)
            
            //--TRIMMABLE-BOUNDARY-START(25770824162)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770824162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Service.remove_OnPlayProgress(new ($.$$.S.EventHandler$$($.$fPer.LCFCS$3.PlayerProgress))().$ctor(this, this.PlayerProgressChanged));
                this.disposed = true;
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(25770824162)
            
            //--TRIMMABLE-BOUNDARY-START(17180889570)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180889570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Media.Type === 2819/*PostTypes.MediaAudio*/)
                {
                    if (this.Context !== null)
                    {
                        __builder.OpenElement(0, "ApplicationPageConfigureT");
                        __builder.AddAttribute$5(1, "T", "CommunityMediaPostModel");
                        __builder.AddAttribute$5(2, "BackgroundTheme", "Theme.OfCard(0.7f)");
                        __builder.OpenComponent$1($.$hDPm.LCFCCB.Background, 3);
                        __builder.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 5);
                            __builder2.AddComponentParameter(6, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, this.Media.Icon));
                            __builder2.AddComponentParameter(7, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ResolvePath("img/mic.jfif", true, false, false)));
                            __builder2.AddComponentParameter(8, "Editable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), false), $.$$.S.Boolean));
                            __builder2.AddComponentParameter(9, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box !== null ? $.$cast(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box.Height, $.$$.S.Int32) : null), $.$$.S.Int32));
                            __builder2.AddComponentParameter(10, "_Width", "UnitOfWork.UI.Box?.Width");
                            __builder2.AddComponentParameter(11, "Class", "hf wf");
                            __builder2.AddComponentParameter(12, "Style", "filter:blur(20px)");
                            __builder2.CloseComponent();
                        }), $ENFttf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1020386,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                    if (this.Context !== null)
                    {
                        __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 13);
                        __builder.AddComponentParameter(14, "Class", "d-block");
                        __builder.AddComponentParameter(15, "href", this.Context === null ? this.Media.Link : null);
                        __builder.AddAttribute$3(16, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(17, "div");
                            __builder2.AddAttribute$5(18, "class", "hx-4 flex mg-a corner-2 clip miwx-25");
                            if (this.CurrentMoment !== null)
                            {
                                __builder2.OpenComponent$1($.$hDPm.LCFCCI.Icon, 19);
                                __builder2.AddComponentParameter(20, "MediaHeight", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 400), $.$$.S.Int32));
                                __builder2.AddComponentParameter(21, "_MediaWidth", "Box != null ? (int)Box.Width : null");
                                __builder2.AddComponentParameter(22, "MediaFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 16/*MediaFeatures.EnterFullScreen*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                __builder2.AddComponentParameter(23, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, this.CurrentMoment.LCFC$IDisplayable$Icon));
                                __builder2.SetKey(this.CurrentMoment);
                                __builder2.CloseComponent();
                            }
                            else 
                            {
                                __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 24);
                                __builder2.AddComponentParameter(25, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, this.Media.Icon));
                                __builder2.AddComponentParameter(26, "Editable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), false), $.$$.S.Boolean));
                                __builder2.AddComponentParameter(27, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 400), $.$$.S.Int32));
                                __builder2.AddComponentParameter(28, "_Width", "Box != null ? (int)Box.Width : null");
                                __builder2.AddComponentParameter(29, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ResolvePath("img/mic.jfif", true, false, false)));
                                __builder2.AddComponentParameter(30, "Class", "mg-a mawp-10 corner-2");
                                __builder2.CloseComponent();
                            }
                            __builder2.CloseElement();
                        }), $FiDPtj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1020386,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                    }
                    if (this.Context !== null)
                    {
                        __builder.OpenElement(31, "div");
                        __builder.AddAttribute$5(32, "class", "pd");
                        __builder.OpenElement(33, "div");
                        __builder.AddAttribute$5(34, "class", "row");
                        __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 35);
                        __builder.AddComponentParameter(36, "href", this.Media.Account.Link);
                        __builder.AddComponentParameter(37, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Media.Account));
                        __builder.AddComponentParameter(38, "Class", "col-a d-block stack");
                        __builder.AddAttribute$3(39, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityUserAvatar, 40);
                            __builder2.AddComponentParameter(41, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IUserAccountModel, this.Media.Account));
                            __builder2.AddComponentParameter(42, "Class", "hx-07 wx-07 round mgy-a");
                            __builder2.CloseComponent();
                        }), $deKSll ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1020386,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                        __builder.AddMarkupContent(43, "\r\n                ");
                        __builder.OpenElement(44, "div");
                        __builder.AddAttribute$5(45, "class", "text-left mgl mgy-a");
                        __builder.OpenComponent$1($.$hDPm.LCFCCM$1.MarkDown, 46);
                        __builder.AddComponentParameter(47, "Tag", "h2");
                        __builder.AddComponentParameter(48, "Class", "mg-0");
                        __builder.AddComponentParameter(49, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Media.Name));
                        __builder.AddComponentParameter(50, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            return this.Media.Name = __value;
                        }, $UKRzva ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1020386,"h":0,"f":17825794}), this.Media.Name))));
                        __builder.AddComponentParameter(51, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                        {
                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Media"), "Name"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                        }, $MXcKoh ??= {"r":38797349,"n":"","d":1020386,"h":0,"f":17825794})).Invoke())));
                        __builder.CloseComponent();
                        __builder.AddMarkupContent(52, "\r\n                    ");
                        __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 53);
                        __builder.AddComponentParameter(54, "href", this.Media.Account.Link);
                        __builder.AddComponentParameter(55, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Media.Account));
                        __builder.AddComponentParameter(56, "Class", "mg-0 op-8");
                        __builder.AddAttribute$3(57, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.AddContent$4(58, this.Media.Account.Title);
                        }), $xSvPff ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1020386,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.AddMarkupContent(59, "\r\n            ");
                        __builder.OpenComponent$1($.$hDPm.LCFCCM$1.MarkDown, 60);
                        __builder.AddComponentParameter(61, "Tag", "p");
                        __builder.AddComponentParameter(62, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Media.Post));
                        __builder.AddComponentParameter(63, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            return this.Media.Post = __value;
                        }, $VZUirh ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1020386,"h":0,"f":17825794}), this.Media.Post))));
                        __builder.AddComponentParameter(64, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                        {
                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Media"), "Post"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                        }, $gkPSEb ??= {"r":38797349,"n":"","d":1020386,"h":0,"f":17825794})).Invoke())));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                    if (this.Media.Equals$1(this.Service.CurrentMedia))
                    {
                        __builder.OpenComponent$1($.$hDPm.LCFCC$1.ConditionalRender, 65);
                        __builder.AddAttribute$3(66, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 67);
                            __builder2.AddComponentParameter(68, "Class", "mgt-5");
                            __builder2.AddComponentParameter(69, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, this.Service.PlayProgress.Progress), $.$$.S.Int32));
                            __builder2.AddComponentParameter(70, "ProgressChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.Int32), $.$mac.MAC.EventCallback.Factory.Create$8($.$$.S.Int32, this, new ($.$$.S.Action$$($.$$.S.Int32))().$ctor(this, this.SetProgress))));
                            __builder2.AddComponentParameter(71, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Gray));
                            __builder2.AddComponentParameter(72, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                            __builder2.AddAttribute$3(73, "Label", new ($.$mac.MAC.RenderFragment$$($.$$.S.Int32))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(74, "b");
                                    __builder3.AddAttribute$5(75, "class", "cl-text");
                                    __builder3.AddContent$3(76, new $.$$.S.TimeSpan().$ctor$6(0, $.trunc($.$cast(this.Service.PlayProgress.Position, $.$$.S.Int32) / 60), $.$cast(this.Service.PlayProgress.Position, $.$$.S.Int32) % 60));
                                    __builder3.AddMarkupContent(77, "\r\n                        /\r\n                        ");
                                    __builder3.AddContent$3(78, new $.$$.S.TimeSpan().$ctor$6(0, $.trunc($.$cast(this.Service.PlayProgress.Duration, $.$$.S.Int32) / 60), $.$cast(this.Service.PlayProgress.Duration, $.$$.S.Int32) % 60));
                                    __builder3.CloseElement();
                                }, $tfGAhj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1020386,"h":0,"f":17825794});
                            }), $zDsLBe ??= {"r":6881395,"p":[{"n":"context","p":655361}],"n":"","d":1020386,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }), $lzNKXd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1020386,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                    }
                    __builder.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 79);
                    __builder.AddComponentParameter(80, "Class", "mgy");
                    __builder.AddAttribute$3(81, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 82);
                            __builder2.AddComponentParameter(83, "Fill", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                            __builder2.CloseComponent();
                            if (this.Service.CurrentPlaylist !== null)
                            {
                                __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 84);
                                __builder2.AddAttribute$3(85, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 86);
                                        __builder3.AddComponentParameter(87, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                                        __builder3.AddComponentParameter(88, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                        __builder3.AddComponentParameter(89, "Class", "mdi mdi-skip-previous mgx-1");
                                        __builder3.AddComponentParameter(90, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.Service, this.Service.Previous))));
                                        __builder3.CloseComponent();
                                    }, $NaNNek ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1020386,"h":0,"f":17825794});
                                }), $asBeBg ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1020386,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                            }
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 91);
                            __builder2.AddAttribute$3(92, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 93);
                                    __builder3.AddComponentParameter(94, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                    __builder3.AddComponentParameter(95, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/ | 1024/*ButtonFeatures.Large*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder3.AddComponentParameter(96, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi mdi-${$.$strNN((this.Service.PlayProgress.IsPlaying && this.Media.Equals$1(this.Service.CurrentMedia) ? "pause" : "play"))} mgx-1`));
                                    __builder3.AddComponentParameter(97, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Play))));
                                    __builder3.CloseComponent();
                                }, $enBfvf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1020386,"h":0,"f":17825794});
                            }), $XLfysc ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1020386,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            if (this.Service.CurrentPlaylist !== null)
                            {
                                __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 98);
                                __builder2.AddAttribute$3(99, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 100);
                                        __builder3.AddComponentParameter(101, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                                        __builder3.AddComponentParameter(102, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                        __builder3.AddComponentParameter(103, "Class", "mdi mdi-skip-next mgx-1");
                                        __builder3.AddComponentParameter(104, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.Service, this.Service.Next))));
                                        __builder3.CloseComponent();
                                    }, $ocFGca ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1020386,"h":0,"f":17825794});
                                }), $PxBYPi ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1020386,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                            }
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 105);
                            __builder2.AddComponentParameter(106, "Fill", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                            __builder2.CloseComponent();
                        }, $ASMIKf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1020386,"h":0,"f":17825794});
                    }), $hazPIe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1020386,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                    if (this.Context !== null)
                    {
                        /*var*/ let moments = this.Media.Moments;
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Data.IMediaMoment>*/ let __ca1__;
                        if ((__ca1__ = moments) !== null ? $.$sl.SL.Enumerable.Any$1($.$fPer.LCFCD.IMediaMoment, __ca1__) : false)
                        {
                            __builder.OpenElement(107, "div");
                            __builder.AddAttribute$5(108, "class", "bg-card bd pd mgt-10 corner shadow");
                            __builder.OpenElement(109, "h3");
                            __builder.AddAttribute$5(110, "class", "mgt-0");
                            __builder.AddContent$3(111, $.$box($.$sl.SL.Enumerable.Count$1($.$fPer.LCFCD.IMediaMoment, moments), $.$$.S.Int32));
                            __builder.AddContent$4(112, " moments in this media");
                            __builder.CloseElement();
                            __builder.AddMarkupContent(113, "\r\n                ");
                            __builder.OpenComponent$1($.$hDPm.LCFCCC$2.Carousel, 114);
                            __builder.AddComponentParameter(115, "StepWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 400), $.$$.S.Int32));
                            __builder.AddComponentParameter(116, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.OfGray(0.5)));
                            __builder.AddAttribute$3(117, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.BoxSize)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                                {
                                    __builder2.OpenElement(118, "div");
                                    __builder2.AddAttribute$5(119, "class", "stack");
                                    __builder2.OpenElement(120, "div");
                                    __builder2.AddAttribute$5(121, "class", "flex");
                                    let $en9 = moments.SCG$IEnumerable$$$GetEnumerator();
                                    while ($en9.SC$1$IEnumerator$MoveNext())
                                    {
                                        let moment = $en9.SCG$IEnumerator$$$Current;
                                        {
                                            __builder2.OpenElement(122, "div");
                                            __builder2.AddAttribute$5(123, "class", $.$strNN($.$strNN("stack" + " text-center") + " ") + $.$strNN((this.CurrentMoment === moment ? "bd bd-primary bdw-2 corner sd sd-primary" : "")));
                                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 124, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                            {
                                                return this.SetProgress$1(moment.LCFCD$IMediaMoment$Mark);
                                            }, $prIXUd ??= {"r":65537,"n":"","d":1020386,"h":0,"f":17825794})));
                                            __builder2.SetKey(moment);
                                            __builder2.OpenElement(125, "div");
                                            __builder2.AddAttribute$5(126, "class", "corner hx-1 wx-1");
                                            __builder2.OpenComponent$1($.$hDPm.LCFCCI.Icon, 127);
                                            __builder2.AddComponentParameter(128, "MediaWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                                            __builder2.AddComponentParameter(129, "MediaHeight", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                                            __builder2.AddComponentParameter(130, "MediaFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                            __builder2.AddComponentParameter(131, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, moment.LCFC$IDisplayable$Icon));
                                            __builder2.CloseComponent();
                                            __builder2.CloseElement();
                                            __builder2.AddMarkupContent(132, "\r\n                                    ");
                                            __builder2.OpenElement(133, "b");
                                            __builder2.AddContent$4(134, moment.LCFCD$IMediaMoment$Mark.ToString$2("c"));
                                            __builder2.CloseElement();
                                            __builder2.CloseElement();
                                        }
                                    }
                                    __builder2.CloseElement();
                                    __builder2.AddMarkupContent(135, "\r\n                        ");
                                    __builder2.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 136);
                                    __builder2.AddComponentParameter(137, "Class", "mgt-5");
                                    __builder2.AddComponentParameter(138, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, this.Service.PlayProgress.Progress), $.$$.S.Int32));
                                    __builder2.AddComponentParameter(139, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Gray));
                                    __builder2.AddComponentParameter(140, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                    __builder2.CloseComponent();
                                    __builder2.CloseElement();
                                }, $ECvqOc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1020386,"h":0,"f":17825794});
                            }), $pWJaUj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.BoxSize).$h}],"n":"","d":1020386,"h":0,"f":17825794}));
                            __builder.CloseComponent();
                            __builder.CloseElement();
                        }
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>*/ let __ca2__;
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel?>*/ let __ca3__;
                        /*var*/ let pictures = ((__ca2__ = this.Media.Resources) !== null ? ((__ca3__ = $.$sl.SL.Enumerable.Except$1($.$Iaui.LCFCM.ResourceModel, __ca2__, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.ResourceModel), [this.Media.Icon], null, null))) !== null ? $.$sl.SL.Enumerable.Where($.$Iaui.LCFCM.ResourceModel, __ca3__, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ResourceModel, $.$$.S.Boolean))().$ctor(this,  (/*m*/ m) =>
                        {
                            return m.IsImage;
                        }, $aEgyQb ??= {"r":262145,"p":[{"n":"m","p":15279446}],"n":"","d":1020386,"h":0,"f":17825794})) : null) : null);
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel?>?*/ let __ca4__;
                        if ((__ca4__ = pictures) !== null ? $.$sl.SL.Enumerable.Any$1($.$Iaui.LCFCM.ResourceModel, __ca4__) : false)
                        {
                            __builder.AddMarkupContent(141, "<h3 class=\"mgx mgt-10\">Attached Pictures</h3>\r\n            ");
                            __builder.OpenComponent$1($.$hDPm.LCFCCM$3.MediaGroup, 142);
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>?*/ let __ca5__;
                            __builder.AddComponentParameter(143, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), ((__ca5__ = this.Media.Resources) !== null ? $.$sl.SL.Enumerable.Where($.$Iaui.LCFCM.ResourceModel, __ca5__, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ResourceModel, $.$$.S.Boolean))().$ctor(this,  (/*m*/ m) =>
                            {
                                return m.IsImage;
                            }, $IrjMea ??= {"r":262145,"p":[{"n":"m","p":15279446}],"n":"","d":1020386,"h":0,"f":17825794})) : null)));
                            __builder.AddComponentParameter(144, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$12(this.Media.Identifier)));
                            __builder.AddComponentParameter(145, "MediaFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/ | 16/*MediaFeatures.EnterFullScreen*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                            __builder.AddComponentParameter(146, "MediaGroupFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaGroupFeatures, (0/*MediaGroupFeatures.Default*/) & ~1/*MediaGroupFeatures.LimitItems*/), $.$hDPm.LCFCCM$3.MediaGroupFeatures));
                            __builder.AddComponentParameter(147, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder.AddAttribute$3(148, "FullScreenView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCM$3.MediaContext))().$ctor(this, ( (/*view*/ view) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                                {
                                    __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunityMedia, 149);
                                    __builder2.AddComponentParameter(150, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, view.Resource));
                                    __builder2.AddComponentParameter(151, "MediaView", (view.View));
                                    __builder2.CloseComponent();
                                }, $OsDmUh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1020386,"h":0,"f":17825794});
                            }), $xBpEyh ??= {"r":6881395,"p":[{"n":"view","p":35083946}],"n":"","d":1020386,"h":0,"f":17825794}));
                            __builder.CloseComponent();
                        }
                    }
                }
                else if (this.Media.Type === 2820/*PostTypes.MediaVideo*/)
                {
                    if (this.Context !== null)
                    {
                        __builder.OpenElement(152, "ApplicationPageConfigureT");
                        __builder.AddAttribute$5(153, "T", "CommunityMediaPostModel");
                        __builder.AddAttribute$5(154, "RemoveApplicationFeatures", "ApplicationFeatures.ToolBar");
                        __builder.CloseElement();
                    }
                    __builder.OpenElement(155, "video");
                    __builder.AddAttribute$5(156, "width", "100%");
                    __builder.AddAttribute$6(157, "controls");
                    let $en10 = this.Media.MediaUrls.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let src = $en10.SCG$IEnumerator$$$Current;
                        {
                            __builder.OpenElement(158, "source");
                            __builder.AddAttribute$5(159, "src", src);
                            __builder.CloseElement();
                        }
                    }
                    __builder.CloseElement();
                    if (this.Context !== null)
                    {
                        __builder.OpenElement(160, "div");
                        __builder.AddAttribute$5(161, "class", "pd");
                        __builder.OpenElement(162, "div");
                        __builder.AddAttribute$5(163, "class", "row");
                        __builder.OpenElement(164, "div");
                        __builder.AddAttribute$5(165, "class", "col-10");
                        __builder.OpenElement(166, "h3");
                        __builder.AddAttribute$5(167, "class", "mg-0");
                        __builder.AddContent$4(168, this.Media.Title);
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.AddMarkupContent(169, "\r\n                ");
                        __builder.OpenElement(170, "div");
                        __builder.AddAttribute$5(171, "class", "col-a");
                        __builder.OpenElement(172, "span");
                        __builder.AddAttribute$5(173, "class", "nowrap");
                        __builder.AddContent$4(174, $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.Media.DateCreated).ToLongDateString());
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.AddMarkupContent(175, "\r\n            ");
                        __builder.OpenComponent$1($.$hDPm.LCFCCM$1.MarkDown, 176);
                        __builder.AddComponentParameter(177, "Tag", "p");
                        __builder.AddComponentParameter(178, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Media.Post));
                        __builder.AddComponentParameter(179, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            return this.Media.Post = __value;
                        }, $DzZBCa ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1020386,"h":0,"f":17825794}), this.Media.Post))));
                        __builder.AddComponentParameter(180, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                        {
                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Media"), "Post"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                        }, $giAImh ??= {"r":38797349,"n":"","d":1020386,"h":0,"f":17825794})).Invoke())));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                }
                else if (this.Media.Type === 2818/*PostTypes.MediaGallery*/)
                {
                    if (this.Context !== null)
                    {
                        $.$QxAa._LCCMCSM$1.TypeInference.CreateCommunityPostHeader_0($.$OSmP.LCCMCM.CommunityMediaPostModel, __builder, 181, 182, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$LCOv.LCFCPM$1.PostTypes, $.$$.S.UInt32, this.Media.Type)), 183, this.Media);
                    }
                    __builder.OpenComponent$1($.$hDPm.LCFCCM$3.MediaGroup, 184);
                    __builder.AddComponentParameter(185, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), this.Media.Resources));
                    __builder.AddComponentParameter(186, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$12(this.Media.Identifier)));
                    __builder.AddComponentParameter(187, "MediaFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/ | 16/*MediaFeatures.EnterFullScreen*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                    __builder.AddComponentParameter(188, "MediaGroupFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaGroupFeatures, (0/*MediaGroupFeatures.Default*/) & ~1/*MediaGroupFeatures.LimitItems*/), $.$hDPm.LCFCCM$3.MediaGroupFeatures));
                    __builder.AddComponentParameter(189, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder.AddAttribute$3(190, "FullScreenView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCM$3.MediaContext))().$ctor(this, ( (/*view*/ view) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunityMedia, 191);
                            __builder2.AddComponentParameter(192, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, view.Resource));
                            __builder2.AddComponentParameter(193, "MediaView", (view.View));
                            __builder2.CloseComponent();
                        }, $PmZMIe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1020386,"h":0,"f":17825794});
                    }), $lOdSWi ??= {"r":6881395,"p":[{"n":"view","p":35083946}],"n":"","d":1020386,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                if (this.Context !== null)
                {
                    __builder.OpenComponent$1($.$ahDc.LCCCSP.CommunityPostToolBar, 194);
                    __builder.AddComponentParameter(195, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IPost, this.Media));
                    __builder.AddComponentParameter(196, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSP.CommunityToolBarFeatures, -2147483137/*CommunityToolBarFeatures.Default*/), $.$ahDc.LCCCSP.CommunityToolBarFeatures));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180889570)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885922274)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885922274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885922274)
            
            //--TRIMMABLE-BOUNDARY-START(12885922274)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12885922274)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(98785268194)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(98785268194)
                
            }
            static $h = 1020386;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationPageBase$$($.$OSmP.LCCMCM.CommunityMediaPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605399010),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835595234,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1020386,
      "h": 81605399010,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81605399010),
//--TRIMMABLE-BOUNDARY-START(98785268194),
    {
      "p": 692706,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425529826,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965137378,
        "f": 83886081
      },
      "n": "Service",
      "d": 1020386,
      "h": 98785268194,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98785268194),
//--TRIMMABLE-BOUNDARY-START(73015464418),
    {
      "p": 1022127,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245660642,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375202786,
        "f": 83886081
      },
      "n": "Media",
      "d": 1020386,
      "h": 73015464418,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015464418),
//--TRIMMABLE-BOUNDARY-START(21475856866),
    {
      "p": 19695958,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655726050,
        "f": 50331650
      },
      "n": "CurrentMoment",
      "d": 1020386,
      "h": 21475856866,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21475856866)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128850039266),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1020386,
      "h": 128850039266,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128850039266),
//--TRIMMABLE-BOUNDARY-START(68720497122),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1020386,
      "h": 68720497122,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720497122),
//--TRIMMABLE-BOUNDARY-START(120260104674),
    {
      "r": 65537,
      "p": [
        {
          "n": "v",
          "p": 655361
        }
      ],
      "n": "SetProgress",
      "d": 1020386,
      "h": 120260104674,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120260104674),
//--TRIMMABLE-BOUNDARY-START(124555071970),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 186646529
        }
      ],
      "n": "SetProgress",
      "o": "@$1",
      "d": 1020386,
      "h": 124555071970,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124555071970),
//--TRIMMABLE-BOUNDARY-START(90195333602),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "arg",
          "p": 62687574
        }
      ],
      "n": "PlayerProgressChanged",
      "d": 1020386,
      "h": 90195333602,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90195333602),
//--TRIMMABLE-BOUNDARY-START(77310431714),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1020386,
      "h": 77310431714,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(77310431714),
//--TRIMMABLE-BOUNDARY-START(85900366306),
    {
      "r": 181338113,
      "n": "Play",
      "d": 1020386,
      "h": 85900366306,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(85900366306),
//--TRIMMABLE-BOUNDARY-START(25770824162),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1020386,
      "h": 25770824162,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770824162),
//--TRIMMABLE-BOUNDARY-START(17180889570),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1020386,
      "h": 17180889570,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180889570)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065791458),
    {
      "t": 262145,
      "n": "disposed",
      "d": 1020386,
      "h": 30065791458,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065791458),
//--TRIMMABLE-BOUNDARY-START(94490300898),
    {
      "t": 11163306,
      "n": "progressBarWrapper",
      "d": 1020386,
      "h": 94490300898,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(94490300898)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885922274),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1020386,
      "h": 12885922274,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885922274)
  ],
  "h": 1020386
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.Shared.MediaPlayerPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Shared${separator}MediaPlayerPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1020386)
        
        

        //--TRIMMABLE-BOUNDARY-START(823778)
        $asm.$cls(`$QxAa.LCCMCS$1.MediaCard`, ($self) => class MediaCard extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OSmP.LCCMCM.CommunityMediaPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(21475660258)
            /*string */ get OptimizedComponentName()
            {
                return "mediacard";
            }
            //--TRIMMABLE-BOUNDARY-END(21475660258)
            
            //--TRIMMABLE-BOUNDARY-START(8590758370)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590758370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 0);
                __builder.AddComponentParameter(1, "Class", "d-block");
                __builder.AddComponentParameter(2, "href", "Player");
                __builder.AddComponentParameter(3, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.ViewModel));
                __builder.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(5, "div");
                    __builder2.AddAttribute$5(6, "class", "mg-1 hx-15 bd corner-2 clip");
                    __builder2.OpenElement(7, "div");
                    __builder2.AddAttribute$5(8, "class", `position pos-rel hf ${$.$strNN(this.Class)}`);
                    __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 9);
                    __builder2.AddComponentParameter(10, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, this.ViewModel.Icon));
                    __builder2.AddComponentParameter(11, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ResolvePath("img/mic.jfif", true, false, false)));
                    __builder2.AddComponentParameter(12, "Class", "mahp-10 d-block mg-a mawp-10");
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(13, "\r\n                ");
                    __builder2.AddMarkupContent(14, "<div class=\"at toptotop lefttoleft wp-100 hf flex\"><button class=\"mdi mdi-play mg-a fsz-100 op-7 bd-0 bg-transparent bg-accessible round\"></button></div>\r\n                ");
                    __builder2.OpenElement(15, "div");
                    __builder2.AddAttribute$5(16, "class", "at bottomtobottom wp-100 text-center bg-black-06");
                    __builder2.OpenElement(17, "div");
                    __builder2.AddAttribute$5(18, "class", "pd-1");
                    __builder2.OpenElement(19, "h4");
                    __builder2.AddAttribute$5(20, "class", "mg-0 nowrap");
                    __builder2.AddContent$4(21, this.ViewModel.Title);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(22, "\r\n                        ");
                    __builder2.OpenElement(23, "span");
                    __builder2.AddAttribute$5(24, "class", "nowrap");
                    __builder2.AddContent$4(25, $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.ViewModel.DateCreated).ToString$3("MMM dd, yyyy"));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(26, "\r\n                        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 27);
                    __builder2.AddComponentParameter(28, "Class", "pd-0 mgt-1");
                    __builder2.AddComponentParameter(29, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575140/*MenuFeatures.Default*/ | 8192/*MenuFeatures.Right*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                    __builder2.AddAttribute$3(30, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 31);
                            __builder3.AddComponentParameter(32, "Fill", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                            __builder3.CloseComponent();
                            if (this.ViewModel.Duration !== 0)
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 33);
                                __builder3.AddAttribute$3(34, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.AddContent$3(35, $.$box(this.ViewModel.Duration, $.$$.S.Int32));
                                        __builder4.AddMarkupContent(36, " min\r\n                                ");
                                    }, $RMkwYb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":823778,"h":0,"f":17825794});
                                }), $PoJHvd ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":823778,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }
                            if (this.ViewModel.ViewsCount !== 0)
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 37);
                                __builder3.AddAttribute$3(38, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenElement(39, "span");
                                        __builder4.AddMarkupContent(40, "<i class=\"mdi mdi-headphones\"></i>");
                                        __builder4.AddContent$3(41, $.$box(this.ViewModel.ViewsCount, $.$$.S.Int32));
                                        __builder4.CloseElement();
                                    }, $ujASNk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":823778,"h":0,"f":17825794});
                                }), $VEhqkd ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":823778,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }
                        }, $OCXgib ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":823778,"h":0,"f":17825794});
                    }), $ZDiCtd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":823778,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }), $atyAgj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":823778,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590758370)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295791074)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295791074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295791074)
            
            //--TRIMMABLE-BOUNDARY-START(4295791074)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295791074)
            
            static $h = 823778;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OSmP.LCCMCM.CommunityMediaPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475660258),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180692962,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 823778,
      "h": 21475660258,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475660258)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590758370),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 823778,
      "h": 8590758370,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590758370)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295791074),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 823778,
      "h": 4295791074,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295791074)
  ],
  "h": 823778
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.Shared.MediaCard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Shared${separator}MediaCard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(823778)
        
        

        //--TRIMMABLE-BOUNDARY-START(561634)
        $asm.$cls(`$QxAa.LCCMCS.CommunityMediaApplication`, ($self) => class CommunityMediaApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885463522)
            $ctor$5(/*CommunityMediaService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885463522);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885463522)
            
            //--TRIMMABLE-BOUNDARY-START(163209318882)
            /*string */ get Name()
            {
                return "Media";
            }
            //--TRIMMABLE-BOUNDARY-END(163209318882)
            
            //--TRIMMABLE-BOUNDARY-START(184684155362)
            /*string */ get Title()
            {
                return "Media";
            }
            //--TRIMMABLE-BOUNDARY-END(184684155362)
            
            //--TRIMMABLE-BOUNDARY-START(30065332706)
            /*string */ get Description()
            {
                return "Create medias, listen, watch and enjoy.";
            }
            //--TRIMMABLE-BOUNDARY-END(30065332706)
            
            //--TRIMMABLE-BOUNDARY-START(158914351586)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-audio-video"/*MaterialDesignIconNames.AudioVideo*/);
            }
            //--TRIMMABLE-BOUNDARY-END(158914351586)
            
            //--TRIMMABLE-BOUNDARY-START(180389188066)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#FE163B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(180389188066)
            
            //--TRIMMABLE-BOUNDARY-START(38655267298)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 97/*ApplicationServiceFeatures.DefaultInDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38655267298)
            
            //--TRIMMABLE-BOUNDARY-START(17180430818)
            /*Type? */ get ApplicationViewType()
            {
                return $.$QxAa.LCCMCP.CommunityMediaApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180430818)
            
            //--TRIMMABLE-BOUNDARY-START(154619384290)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619384290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$QxAa.LCCMCP.CommunityMediaApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(154619384290)
            
            //--TRIMMABLE-BOUNDARY-START(34360300002)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360300002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(34360300002)
            
            //--TRIMMABLE-BOUNDARY-START(171799253474)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799253474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(171799253474)
            
            //--TRIMMABLE-BOUNDARY-START(167504286178)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(167504286178)
            
            //--TRIMMABLE-BOUNDARY-START(4295528930)
            /*CommunityMediaService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295528930)
            
            //--TRIMMABLE-BOUNDARY-START(176094220770)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(176094220770)
            
            //--TRIMMABLE-BOUNDARY-START(188979122658)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(2816/*PostTypes.Media*/, 2821/*PostTypes.MediaEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(188979122658)
            
            //--TRIMMABLE-BOUNDARY-START(25770365410)
            /*string */ get CreateLink()
            {
                return "Media/EditPost";
            }
            //--TRIMMABLE-BOUNDARY-END(25770365410)
            
            //--TRIMMABLE-BOUNDARY-START(21475398114)
            /*string */ get CreateLabel()
            {
                return "Post a Media";
            }
            //--TRIMMABLE-BOUNDARY-END(21475398114)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            //--TRIMMABLE-BOUNDARY-START(25772137952)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.ICreatorApplicationProxy.CreateLink.get
            get LCFCA$ICreatorApplicationProxy$CreateLink()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592268768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLink;
            }
            //--TRIMMABLE-BOUNDARY-END(25772137952)
            
            //--TRIMMABLE-BOUNDARY-START(17182203360)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.ICreatorApplicationProxy.CreateLabel.get
            get LCFCA$ICreatorApplicationProxy$CreateLabel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297301472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLabel;
            }
            //--TRIMMABLE-BOUNDARY-END(17182203360)
            
            static $h = 561634;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(163209318882),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374744034,
        "f": 50364417
      },
      "n": "Name",
      "d": 561634,
      "h": 163209318882,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209318882),
//--TRIMMABLE-BOUNDARY-START(184684155362),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734482402,
        "f": 50364417
      },
      "n": "Title",
      "d": 561634,
      "h": 184684155362,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(184684155362),
//--TRIMMABLE-BOUNDARY-START(30065332706),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604940258,
        "f": 50364417
      },
      "n": "Description",
      "d": 561634,
      "h": 30065332706,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065332706),
//--TRIMMABLE-BOUNDARY-START(158914351586),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784809442,
        "f": 50364417
      },
      "n": "Icon",
      "d": 561634,
      "h": 158914351586,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914351586),
//--TRIMMABLE-BOUNDARY-START(180389188066),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144547810,
        "f": 50364417
      },
      "n": "Theme",
      "d": 561634,
      "h": 180389188066,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389188066),
//--TRIMMABLE-BOUNDARY-START(38655267298),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194874850,
        "f": 50364417
      },
      "n": "Features",
      "d": 561634,
      "h": 38655267298,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655267298),
//--TRIMMABLE-BOUNDARY-START(17180430818),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835136482,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 561634,
      "h": 17180430818,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180430818),
//--TRIMMABLE-BOUNDARY-START(167504286178),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964678626,
        "f": 50364417
      },
      "n": "Order",
      "d": 561634,
      "h": 167504286178,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(167504286178),
//--TRIMMABLE-BOUNDARY-START(4295528930),
    {
      "p": 692706,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245201890,
        "f": 50331650
      },
      "n": "_Service",
      "d": 561634,
      "h": 4295528930,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295528930),
//--TRIMMABLE-BOUNDARY-START(176094220770),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554613218,
        "f": 50364417
      },
      "n": "Service",
      "d": 561634,
      "h": 176094220770,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176094220770),
//--TRIMMABLE-BOUNDARY-START(188979122658),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324416994,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 561634,
      "h": 188979122658,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(188979122658),
//--TRIMMABLE-BOUNDARY-START(25770365410),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015005666,
        "f": 50331649
      },
      "n": "CreateLink",
      "d": 561634,
      "h": 25770365410,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770365410),
//--TRIMMABLE-BOUNDARY-START(21475398114),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425071074,
        "f": 50331649
      },
      "n": "CreateLabel",
      "d": 561634,
      "h": 21475398114,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475398114)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(154619384290),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 561634,
      "h": 154619384290,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(154619384290),
//--TRIMMABLE-BOUNDARY-START(34360300002),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 561634,
      "h": 34360300002,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360300002),
//--TRIMMABLE-BOUNDARY-START(171799253474),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 561634,
      "h": 171799253474,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171799253474)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885463522),
    {
      "p": [
        {
          "n": "service",
          "p": 692706
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 561634,
      "h": 12885463522,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885463522)
  ],
  "h": 561634
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$OSmP.LCCMCM.CommunityMediaPostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication, $.$ahDc.LCCCS.ICommunityCreatorApplication, $.$ahDc.LCCCS.ICommunityClientApplication, $.$sZVd.LCFCA.IClientApplication, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.ICreatorApplicationProxy, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.Services.CommunityMediaApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Services${separator}CommunityMediaApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(561634)
        
        

        //--TRIMMABLE-BOUNDARY-START(430562)
        $asm.$cls(`$QxAa.LCCMCP.CommunityMediaApp`, ($self) => class CommunityMediaApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$OSmP.LCCMCM.CommunityMediaPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(154619253218)
            /*string */ get OptimizedComponentName()
            {
                return "communitymediaapp communitydefaultpages";
            }
            //--TRIMMABLE-BOUNDARY-END(154619253218)
            
            //--TRIMMABLE-BOUNDARY-START(137439384034)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439384034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.MediaAppService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QxAa.LCCMCS.CommunityMediaService, serviceProvider);
                this.MediaApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QxAa.LCCMCS.CommunityMediaApplication, serviceProvider);
                this.PlaylistProviders = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$fPer.LCFCS$3.IMediaPlaylistProvider), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(137439384034)
            
            //--TRIMMABLE-BOUNDARY-START(146029318626)
            /*CommunityMediaService*/ MediaAppService = null;
            //--TRIMMABLE-BOUNDARY-END(146029318626)
            
            //--TRIMMABLE-BOUNDARY-START(141734351330)
            /*CommunityMediaApplication*/ MediaApplication = null;
            //--TRIMMABLE-BOUNDARY-END(141734351330)
            
            //--TRIMMABLE-BOUNDARY-START(158914220514)
            /*IEnumerable<IMediaPlaylistProvider>*/ PlaylistProviders = null;
            //--TRIMMABLE-BOUNDARY-END(158914220514)
            
            //--TRIMMABLE-BOUNDARY-START(25770234338)
            /*ICommunityClientApplication */ get Application()
            {
                return this.MediaApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(25770234338)
            
            //--TRIMMABLE-BOUNDARY-START(38655136226)
            /*CommunityPostView */ get CardView()
            {
                return 4/*CommunityPostView.CardMediaFirst*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38655136226)
            
            //--TRIMMABLE-BOUNDARY-START(42950103522)
            /*int? */ get CardWidthHint()
            {
                return 250;
            }
            //--TRIMMABLE-BOUNDARY-END(42950103522)
            
            //--TRIMMABLE-BOUNDARY-START(34360168930)
            /*int? */ get CardSpaceHint()
            {
                return 20;
            }
            //--TRIMMABLE-BOUNDARY-END(34360168930)
            
            //--TRIMMABLE-BOUNDARY-START(188978991586)
            /*UseDefaultPage */ get UsePage()
            {
                return 65535/*UseDefaultPage.Default*/ & ~2/*UseDefaultPage.PostView*/;
            }
            //--TRIMMABLE-BOUNDARY-END(188978991586)
            
            //--TRIMMABLE-BOUNDARY-START(47245070818)
            /*IEnumerable<IDataListItemContext<IPostMedia>> */ Filter(/*IEnumerable<IDataListItemContext<IPostMedia>>*/ models, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245070818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.StartsWith$3.call(key, "lang:"))
                {
                    /*var*/ let lang = $.$$.S.String.Substring$1.call(key, 5);
                    return $.$sl.SL.Enumerable.Where($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia), models, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia), $.$$.S.Boolean))().$ctor(this,  (/*m*/ m) =>
                    {
                        return $.$$.S.String.Equals$2.call(m.LCFCCD$1$IDataListItemContext$$$Data.LCFCD$IMediaModel$Language, lang, 3/*StringComparison.InvariantCultureIgnoreCase*/);
                    }, $gBaNah ??= {"r":262145,"p":[{"n":"m","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia).$h}],"n":"","d":430562,"h":0,"f":17825794}));
                }
                if ($.$$.S.String.StartsWith$3.call(key, "group:"))
                {
                    /*var*/ let group = $.$$.S.String.Substring$1.call(key, 6);
                    return $.$sl.SL.Enumerable.Where($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia), models, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia), $.$$.S.Boolean))().$ctor(this,  (/*m*/ m) =>
                    {
                        return $.$$.S.String.Equals$2.call(m.LCFCCD$1$IDataListItemContext$$$Data.LCFCD$IMediaModel$Group, group, 3/*StringComparison.InvariantCultureIgnoreCase*/);
                    }, $hBhADf ??= {"r":262145,"p":[{"n":"m","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia).$h}],"n":"","d":430562,"h":0,"f":17825794}));
                }
                if ($.$$.S.String.StartsWith$3.call(key, "genre:"))
                {
                    /*var*/ let genre = $.$$.S.String.Substring$1.call(key, 6);
                    return $.$sl.SL.Enumerable.Where($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia), models, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia), $.$$.S.Boolean))().$ctor(this,  (/*m*/ m) =>
                    {
                        return $.$$.S.String.Equals$2.call(m.LCFCCD$1$IDataListItemContext$$$Data.LCFCD$IMediaModel$Genre, genre, 3/*StringComparison.InvariantCultureIgnoreCase*/);
                    }, $PtPzJd ??= {"r":262145,"p":[{"n":"m","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia).$h}],"n":"","d":430562,"h":0,"f":17825794}));
                }
                return $.$sl.SL.Enumerable.Where($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia), models, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia), $.$$.S.Boolean))().$ctor(this,  (/*m*/ m) =>
                {
                    return $.$$.S.String.Contains$2.call((m.LCFCCD$1$IDataListItemContext$$$Data).LCFC$IDisplayable$Title, key, 3/*StringComparison.InvariantCultureIgnoreCase*/);
                }, $zzmITj ??= {"r":262145,"p":[{"n":"m","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia).$h}],"n":"","d":430562,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(47245070818)
            
            //--TRIMMABLE-BOUNDARY-START(150324285922)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324285922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Assets$1.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResolvePath("LivingThing.Core.Community.Media.Client.Blazor.js", true, false, false) ], null, null));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(150324285922)
            
            //--TRIMMABLE-BOUNDARY-START(30065201634)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065201634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
            }
            //--TRIMMABLE-BOUNDARY-END(30065201634)
            
            //--TRIMMABLE-BOUNDARY-START(21475267042)
            /*RenderFragment */ get AppendPages()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(1, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$OSmP.LCCMCM.CommunityMediaPostModel), 2);
                    __builder2.AddComponentParameter(3, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("***"/*RoutePath.OneOrMorePathSegment*/)));
                    __builder2.AddComponentParameter(4, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 2147483647/*int.MaxValue*/), $.$$.S.Int32));
                    __builder2.AddComponentParameter(5, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/ | 1024/*ApplicationPageFeatures.RenderPageWhileViewModelIsLoading*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddComponentParameter(6, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OSmP.LCCMCM.CommunityMediaPostModel)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~12/*CommunityLayoutFeatures.PadX*/, null, null, true);
                    }), $czzLef ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$OSmP.LCCMCM.CommunityMediaPostModel).$h}],"n":"","d":430562,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(7, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OSmP.LCCMCM.CommunityMediaPostModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(8, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$OSmP.LCCMCM.CommunityMediaPostModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$OSmP.LCCMCM.CommunityMediaPostModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                return (e).LCFC$IDisplayable$Title;
                            }, $mbGnpc ??= {"r":131073,"p":[{"n":"e","p":1022127}],"n":"","d":430562,"h":0,"f":17825794}), true));
                        }, $LsOXbe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":430562,"h":0,"f":17825794});
                    }), $ZisFag ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OSmP.LCCMCM.CommunityMediaPostModel)).$h}],"n":"","d":430562,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(9, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OSmP.LCCMCM.CommunityMediaPostModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(10, "<i class=\"mdi mdi-audio-video\"></i>");
                        }, $bdGxEe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":430562,"h":0,"f":17825794});
                    }), $dEsAbe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OSmP.LCCMCM.CommunityMediaPostModel)).$h}],"n":"","d":430562,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(11, "FloatingButtons", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OSmP.LCCMCM.CommunityMediaPostModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.AddContent$1(12, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$OSmP.LCCMCM.CommunityMediaPostModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$OSmP.LCCMCM.CommunityMediaPostModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return this.EditPostButton($.$OSmP.LCCMCM.CommunityMediaPostModel, e);
                            }, $JFSPWf ??= {"r":6881395,"p":[{"n":"e","p":1022127}],"n":"","d":430562,"h":0,"f":17825794}), null, true));
                        }, $kkwoEd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":430562,"h":0,"f":17825794});
                    }), $enHIJk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OSmP.LCCMCM.CommunityMediaPostModel)).$h}],"n":"","d":430562,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(13, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OSmP.LCCMCM.CommunityMediaPostModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$QxAa.LCCMCS$1.MediaPlayerPage, 14);
                            __builder3.CloseComponent();
                        }, $gPmMpe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":430562,"h":0,"f":17825794});
                    }), $SHsUQc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OSmP.LCCMCM.CommunityMediaPostModel)).$h}],"n":"","d":430562,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(15, "\r\n    ");
                }, $VXBiVh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":430562,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(21475267042)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4312946346)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListPostFilterController<LivingThing.Core.Frameworks.Common.Posts.IPostMedia>.Filter(System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.IDataListItemContext<LivingThing.Core.Frameworks.Common.Posts.IPostMedia>>, string?)
            LCFCCD$1$IDataListPostFilterController$LivingThing$Core$Frameworks$Common$Posts$IPostMedia$Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312946346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312946346)
            
            //--TRIMMABLE-BOUNDARY-START(17180299746)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180299746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180299746)
            
            //--TRIMMABLE-BOUNDARY-START(17180299746)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(17180299746)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(146029318626)
                this.MediaAppService = null;
                //--TRIMMABLE-BOUNDARY-END(146029318626)
                
                //--TRIMMABLE-BOUNDARY-START(141734351330)
                this.MediaApplication = null;
                //--TRIMMABLE-BOUNDARY-END(141734351330)
                
                //--TRIMMABLE-BOUNDARY-START(158914220514)
                this.PlaylistProviders = null;
                //--TRIMMABLE-BOUNDARY-END(158914220514)
                
            }
            static $h = 430562;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$OSmP.LCCMCM.CommunityMediaPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(154619253218),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964547554,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 430562,
      "h": 154619253218,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619253218),
//--TRIMMABLE-BOUNDARY-START(146029318626),
    {
      "p": 692706,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374612962,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094089698,
        "f": 83886081
      },
      "n": "MediaAppService",
      "d": 430562,
      "h": 146029318626,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029318626),
//--TRIMMABLE-BOUNDARY-START(141734351330),
    {
      "p": 561634,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784678370,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504155106,
        "f": 83886081
      },
      "n": "MediaApplication",
      "d": 430562,
      "h": 141734351330,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141734351330),
//--TRIMMABLE-BOUNDARY-START(158914220514),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCS$3.IMediaPlaylistProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554482146,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184684024290,
        "f": 83886081
      },
      "n": "PlaylistProviders",
      "d": 430562,
      "h": 158914220514,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914220514),
//--TRIMMABLE-BOUNDARY-START(25770234338),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424940002,
        "f": 50364420
      },
      "n": "Application",
      "d": 430562,
      "h": 25770234338,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(25770234338),
//--TRIMMABLE-BOUNDARY-START(38655136226),
    {
      "p": 31299008,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604809186,
        "f": 50364420
      },
      "n": "CardView",
      "d": 430562,
      "h": 38655136226,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(38655136226),
//--TRIMMABLE-BOUNDARY-START(42950103522),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194743778,
        "f": 50364420
      },
      "n": "CardWidthHint",
      "d": 430562,
      "h": 42950103522,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(42950103522),
//--TRIMMABLE-BOUNDARY-START(34360168930),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014874594,
        "f": 50364420
      },
      "n": "CardSpaceHint",
      "d": 430562,
      "h": 34360168930,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(34360168930),
//--TRIMMABLE-BOUNDARY-START(188978991586),
    {
      "p": 34379200,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144416738,
        "f": 50364420
      },
      "n": "UsePage",
      "d": 430562,
      "h": 188978991586,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(188978991586),
//--TRIMMABLE-BOUNDARY-START(21475267042),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835005410,
        "f": 50364420
      },
      "n": "AppendPages",
      "d": 430562,
      "h": 21475267042,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(21475267042)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137439384034),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 430562,
      "h": 137439384034,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137439384034),
//--TRIMMABLE-BOUNDARY-START(47245070818),
    {
      "r": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia)).$h,
      "p": [
        {
          "n": "models",
          "p": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCP.IPostMedia)).$h
        },
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "Filter",
      "d": 430562,
      "h": 47245070818,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245070818),
//--TRIMMABLE-BOUNDARY-START(150324285922),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 430562,
      "h": 150324285922,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(150324285922),
//--TRIMMABLE-BOUNDARY-START(30065201634),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 430562,
      "h": 30065201634,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30065201634)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180299746),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 430562,
      "h": 17180299746,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180299746)
  ],
  "h": 430562
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$LCOv.LCFCP.IPostMedia), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$LCOv.LCFCP.IPostMedia), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.Pages.CommunityMediaApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Pages${separator}CommunityMediaApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(430562)
        
        

        //--TRIMMABLE-BOUNDARY-START(692706)
        $asm.$cls(`$QxAa.LCCMCS.CommunityMediaService`, ($self) => class CommunityMediaService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$OSmP.LCCMCM.CommunityMediaPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(21475529186)
            $ctor$6(/*CommunityRootService*/ service, /*IMediaPlayer*/ mediaPlayer)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475529186);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MediaPlayer = mediaPlayer;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475529186)
            
            //--TRIMMABLE-BOUNDARY-START(77310104034)
            /*IMediaPlayer*/ MediaPlayer = null;
            //--TRIMMABLE-BOUNDARY-END(77310104034)
            
            //--TRIMMABLE-BOUNDARY-START(38655398370)
            /*IMediaPlaylist*/ CurrentPlaylist = null;
            //--TRIMMABLE-BOUNDARY-END(38655398370)
            
            //--TRIMMABLE-BOUNDARY-START(34360431074)
            /*IMediaModel*/ CurrentMedia = null;
            //--TRIMMABLE-BOUNDARY-END(34360431074)
            
            //--TRIMMABLE-BOUNDARY-START(111669842402)
            /*PlayerProgress*/ PlayProgress;
            //--TRIMMABLE-BOUNDARY-END(111669842402)
            
            //--TRIMMABLE-BOUNDARY-START(98784940514)
            /*ValueTask *//*async*/  Play$1(/*IMediaPlaylist*/ playlist, /*IMediaModel*/ media)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784940514);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CurrentPlaylist = playlist;
                    this.CurrentMedia = media;
                    ($t1 = this.MediaPlayer.LCFCS$3$IMediaPlayer$Play$1(media, false, this), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(98784940514)
            
            //--TRIMMABLE-BOUNDARY-START(94489973218)
            /*ValueTask *//*async*/  Play(/*IMediaModel*/ media)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489973218);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CurrentMedia = media;
                    ($t2 = this.MediaPlayer.LCFCS$3$IMediaPlayer$Play$1(media, false, this), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94489973218)
            
            //--TRIMMABLE-BOUNDARY-START(103079907810)
            /*ValueTask */ PlayMedia()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079907810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MediaPlayer.LCFCS$3$IMediaPlayer$Play();
            }
            //--TRIMMABLE-BOUNDARY-END(103079907810)
            
            //--TRIMMABLE-BOUNDARY-START(90195005922)
            /*ValueTask */ PauseMedia()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195005922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MediaPlayer.LCFCS$3$IMediaPlayer$Pause();
            }
            //--TRIMMABLE-BOUNDARY-END(90195005922)
            
            //--TRIMMABLE-BOUNDARY-START(107374875106)
            /*ValueTask */ PlayPauseMedia()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374875106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((this.PlayProgress.Flags & (1/*MediaPlayerPlayingFlags.Paused*/)) == (1/*MediaPlayerPlayingFlags.Paused*/)))
                {
                    return this.PlayMedia();
                }
                else 
                {
                    return this.PauseMedia();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374875106)
            
            //--TRIMMABLE-BOUNDARY-START(167504417250)
            /*ValueTask *//*async*/  StopMedia()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504417250);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = this.MediaPlayer.LCFCS$3$IMediaPlayer$Stop(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    this.CurrentMedia = null;
                    this.PlayProgress = new $.$fPer.LCFCS$3.PlayerProgress();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167504417250)
            
            //--TRIMMABLE-BOUNDARY-START(158914482658)
            /*ValueTask */ SetPlayPosition(/*int*/ percentage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914482658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MediaPlayer.LCFCS$3$IMediaPlayer$Set($.$cast((this.PlayProgress.Duration * percentage / 100), $.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(158914482658)
            
            //--TRIMMABLE-BOUNDARY-START(163209449954)
            /*ValueTask */ SetPlayPosition$1(/*TimeSpan*/ where)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209449954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MediaPlayer.LCFCS$3$IMediaPlayer$Set($.$cast(where.TotalSeconds, $.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(163209449954)
            
            //--TRIMMABLE-BOUNDARY-START(115964809698)
            /*ValueTask */ Previous()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964809698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CurrentPlaylist !== null)
                {
                    /*var*/ let array = $.$sl.SL.Enumerable.ToArray($.$fPer.LCFCD.IMediaModel, this.CurrentPlaylist.LCFCS$3$IMediaPlaylist$Medias);
                    /*int*/ let currentIndex = $.$$.S.Array.IndexOf$5($.$fPer.LCFCD.IMediaModel, array, this.CurrentMedia);
                    if (currentIndex >= 0)
                    {
                        currentIndex--;
                        if (currentIndex < 0)
                        {
                            currentIndex = ((array.length - 1) | 0);
                        }
                        if (currentIndex < array.length)
                        {
                            this.CurrentMedia = $.$$.System.Array.$ReadT1.call(array, currentIndex);
                            return this.Play(this.CurrentMedia);
                        }
                    }
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(115964809698)
            
            //--TRIMMABLE-BOUNDARY-START(81605071330)
            /*ValueTask */ Next()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605071330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CurrentPlaylist !== null)
                {
                    /*var*/ let array = $.$sl.SL.Enumerable.ToArray($.$fPer.LCFCD.IMediaModel, this.CurrentPlaylist.LCFCS$3$IMediaPlaylist$Medias);
                    /*int*/ let currentIndex = $.$$.S.Array.IndexOf$5($.$fPer.LCFCD.IMediaModel, array, this.CurrentMedia);
                    if (currentIndex >= 0)
                    {
                        currentIndex++;
                        currentIndex %= array.length;
                        if (currentIndex < array.length)
                        {
                            this.CurrentMedia = $.$$.System.Array.$ReadT1.call(array, currentIndex);
                            return this.Play(this.CurrentMedia);
                        }
                    }
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(81605071330)
            
            //--TRIMMABLE-BOUNDARY-START(85900038626)
            /*EventHandler<PlayerProgress>*/ OnPlayProgress = null;
            //--TRIMMABLE-BOUNDARY-END(85900038626)
            
            //--TRIMMABLE-BOUNDARY-START(85900038626)
            //--TRIMMABLE-BOUNDARY-START(30065463778)
            add_OnPlayProgress(/*EventHandler<PlayerProgress>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065463778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnPlayProgress = $.$$.S.Delegate.Combine$2(this.OnPlayProgress, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30065463778)
            
            //--TRIMMABLE-BOUNDARY-START(124554744290)
            remove_OnPlayProgress(/*EventHandler<PlayerProgress>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554744290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnPlayProgress = $.$$.S.Delegate.Remove(this.OnPlayProgress, value);
            }
            //--TRIMMABLE-BOUNDARY-END(124554744290)
            
            //--TRIMMABLE-BOUNDARY-END(85900038626)
            
            //--TRIMMABLE-BOUNDARY-START(128849711586)
            /*void */ Report(/*PlayerProgress*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849711586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PlayProgress = $.$clone(value);
                if (this.PlayProgress.Duration !== 0 && this.PlayProgress.Position === this.PlayProgress.Duration)
                {
                    if (this.CurrentPlaylist !== null)
                    {
                        this.Next();
                    }
                    else 
                    {
                        this.StopMedia();
                    }
                }
                this.OnPlayProgress?.Invoke(this, $.$clone(value));
            }
            //--TRIMMABLE-BOUNDARY-END(128849711586)
            
            //--TRIMMABLE-BOUNDARY-START(4392288257)
            //Generated interface implemetation for System.IProgress<LivingThing.Core.Frameworks.Common.Services.PlayerProgress>.Report(LivingThing.Core.Frameworks.Common.Services.PlayerProgress)
            S$IProgress$LivingThing$Core$Frameworks$Common$Services$PlayerProgress$Report()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4392288257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Report(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4392288257)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(111669842402)
                this.PlayProgress = $.$default($.$fPer.LCFCS$3.PlayerProgress);
                //--TRIMMABLE-BOUNDARY-END(111669842402)
                
            }
            static $h = 692706;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$OSmP.LCCMCM.CommunityMediaPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310104034),
    {
      "p": 61704534,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425202146,
        "f": 50331650
      },
      "n": "MediaPlayer",
      "d": 692706,
      "h": 77310104034,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(77310104034),
//--TRIMMABLE-BOUNDARY-START(38655398370),
    {
      "p": 61770070,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835267554,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029580770,
        "f": 83886082
      },
      "n": "CurrentPlaylist",
      "d": 692706,
      "h": 38655398370,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655398370),
//--TRIMMABLE-BOUNDARY-START(34360431074),
    {
      "p": 19564886,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245332962,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439646178,
        "f": 83886082
      },
      "n": "CurrentMedia",
      "d": 692706,
      "h": 34360431074,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360431074),
//--TRIMMABLE-BOUNDARY-START(111669842402),
    {
      "p": 62687574,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015136738,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619515362,
        "f": 83886082
      },
      "n": "PlayProgress",
      "d": 692706,
      "h": 111669842402,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669842402)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98784940514),
    {
      "r": 181338113,
      "p": [
        {
          "n": "playlist",
          "p": 61770070
        },
        {
          "n": "media",
          "p": 19564886
        }
      ],
      "n": "Play",
      "o": "@$1",
      "d": 692706,
      "h": 98784940514,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(98784940514),
//--TRIMMABLE-BOUNDARY-START(94489973218),
    {
      "r": 181338113,
      "p": [
        {
          "n": "media",
          "p": 19564886
        }
      ],
      "n": "Play",
      "d": 692706,
      "h": 94489973218,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(94489973218),
//--TRIMMABLE-BOUNDARY-START(103079907810),
    {
      "r": 181338113,
      "n": "PlayMedia",
      "d": 692706,
      "h": 103079907810,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079907810),
//--TRIMMABLE-BOUNDARY-START(90195005922),
    {
      "r": 181338113,
      "n": "PauseMedia",
      "d": 692706,
      "h": 90195005922,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195005922),
//--TRIMMABLE-BOUNDARY-START(107374875106),
    {
      "r": 181338113,
      "n": "PlayPauseMedia",
      "d": 692706,
      "h": 107374875106,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374875106),
//--TRIMMABLE-BOUNDARY-START(167504417250),
    {
      "r": 181338113,
      "n": "StopMedia",
      "d": 692706,
      "h": 167504417250,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(167504417250),
//--TRIMMABLE-BOUNDARY-START(158914482658),
    {
      "r": 181338113,
      "p": [
        {
          "n": "percentage",
          "p": 655361
        }
      ],
      "n": "SetPlayPosition",
      "d": 692706,
      "h": 158914482658,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914482658),
//--TRIMMABLE-BOUNDARY-START(163209449954),
    {
      "r": 181338113,
      "p": [
        {
          "n": "where",
          "p": 186646529
        }
      ],
      "n": "SetPlayPosition",
      "o": "@$1",
      "d": 692706,
      "h": 163209449954,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209449954),
//--TRIMMABLE-BOUNDARY-START(115964809698),
    {
      "r": 181338113,
      "n": "Previous",
      "d": 692706,
      "h": 115964809698,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964809698),
//--TRIMMABLE-BOUNDARY-START(81605071330),
    {
      "r": 181338113,
      "n": "Next",
      "d": 692706,
      "h": 81605071330,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605071330),
//--TRIMMABLE-BOUNDARY-START(128849711586),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 62687574
        }
      ],
      "n": "Report",
      "d": 692706,
      "h": 128849711586,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128849711586)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475529186),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        },
        {
          "n": "mediaPlayer",
          "p": 61704534
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 692706,
      "h": 21475529186,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475529186)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(85900038626),
    {
      "e": $.$$.S.EventHandler$$($.$fPer.LCFCS$3.PlayerProgress).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$fPer.LCFCS$3.PlayerProgress).$h
          }
        ],
        "n": "add_OnPlayProgress",
        "d": 692706,
        "h": 30065463778,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$fPer.LCFCS$3.PlayerProgress).$h
          }
        ],
        "n": "remove_OnPlayProgress",
        "d": 692706,
        "h": 124554744290,
        "f": 285212673
      },
      "n": "OnPlayProgress",
      "d": 692706,
      "h": 85900038626,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(85900038626)
  ],
  "h": 692706
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$OSmP.LCCMCM.CommunityMediaPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$OSmP.LCCMCM.CommunityMediaPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable, $.$$.S.IProgress$$($.$fPer.LCFCS$3.PlayerProgress) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.Services.CommunityMediaService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Services${separator}CommunityMediaService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(692706)
        
        

        //--TRIMMABLE-BOUNDARY-START(1085922)
        $asm.$cls(`$QxAa.LCCMCS$1.PagePlayer`, ($self) => class PagePlayer extends $.$hDPm.LCFCC$1.BaseInjectedComponent$$($.$QxAa.LCCMCS.CommunityMediaService)
        {
            //--TRIMMABLE-BOUNDARY-START(25770889698)
            /*void */ SetProgress(/*int*/ v)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770889698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ViewModel.SetPlayPosition(v);
            }
            //--TRIMMABLE-BOUNDARY-END(25770889698)
            
            //--TRIMMABLE-BOUNDARY-START(21475922402)
            /*string */ get OptimizedComponentName()
            {
                return "pageplayer";
            }
            //--TRIMMABLE-BOUNDARY-END(21475922402)
            
            //--TRIMMABLE-BOUNDARY-START(8591020514)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591020514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel.CurrentMedia !== null)
                {
                    __builder.OpenElement(0, "div");
                    __builder.AddAttribute$5(1, "class", "stack shadow-3 pos-rel bg-card");
                    __builder.OpenElement(2, "div");
                    __builder.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 3);
                    __builder.AddComponentParameter(4, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, $.$cast($.$$.S.Math.Min$2(this.ViewModel.PlayProgress.Position * 100 / $.$$.S.Math.Max$2(this.ViewModel.PlayProgress.Duration, 0.01), 100), $.$$.S.Int32)), $.$$.S.Int32));
                    __builder.AddComponentParameter(5, "ProgressChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.Int32), $.$mac.MAC.EventCallback.Factory.Create$8($.$$.S.Int32, this, new ($.$$.S.Action$$($.$$.S.Int32))().$ctor(this, this.SetProgress))));
                    __builder.AddComponentParameter(6, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Gray));
                    __builder.AddComponentParameter(7, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder.AddComponentParameter(8, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 5), $.$$.S.Int32));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(9, "\r\n        ");
                    __builder.OpenElement(10, "div");
                    __builder.AddAttribute$5(11, "class", "row pdx mgt-1");
                    __builder.OpenElement(12, "div");
                    __builder.AddAttribute$5(13, "class", "col-10");
                    __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 14);
                    __builder.AddComponentParameter(15, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ViewModel.CurrentMedia.LCFC$IDisplayable$Title));
                    __builder.AddComponentParameter(16, "_Description", "ViewModel.CurrentMedia.Account.Title");
                    __builder.AddComponentParameter(17, "Icon", "ViewModel.CurrentMedia.Icon");
                    __builder.AddComponentParameter(18, "Media", this.ResolvePath("img/mic.jfif", true, false, false));
                    __builder.AddComponentParameter(19, "img-class", "hx-05 wx-05 clip round");
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(20, "\r\n            ");
                    __builder.OpenElement(21, "div");
                    __builder.AddAttribute$5(22, "class", "stack");
                    __builder.OpenElement(23, "span");
                    __builder.AddAttribute$5(24, "class", "text-right op-8");
                    __builder.AddContent$3(25, new $.$$.S.TimeSpan().$ctor$6(0, $.trunc($.$cast(this.ViewModel.PlayProgress.Position, $.$$.S.Int32) / 60), $.$cast(this.ViewModel.PlayProgress.Position, $.$$.S.Int32) % 60));
                    __builder.AddMarkupContent(26, " \r\n                    / ");
                    __builder.AddContent$3(27, new $.$$.S.TimeSpan().$ctor$6(0, $.trunc($.$cast(this.ViewModel.PlayProgress.Duration, $.$$.S.Int32) / 60), $.$cast(this.ViewModel.PlayProgress.Duration, $.$$.S.Int32) % 60));
                    __builder.CloseElement();
                    __builder.AddMarkupContent(28, "\r\n                ");
                    __builder.OpenElement(29, "div");
                    __builder.AddAttribute$5(30, "class", "mg-a");
                    __builder.OpenElement(31, "div");
                    __builder.AddAttribute$5(32, "class", "flex");
                    __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 33);
                    __builder.AddComponentParameter(34, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder.AddComponentParameter(35, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder.AddComponentParameter(36, "Class", "mdi mdi-skip-previous mgx-1");
                    __builder.AddComponentParameter(37, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.ViewModel, this.ViewModel.Previous))));
                    __builder.CloseComponent();
                    __builder.AddMarkupContent(38, "\r\n                        ");
                    __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 39);
                    __builder.AddComponentParameter(40, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder.AddComponentParameter(41, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder.AddComponentParameter(42, "Class", "mdi mdi-stop mgx-1");
                    __builder.AddComponentParameter(43, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.ViewModel, this.ViewModel.StopMedia))));
                    __builder.CloseComponent();
                    __builder.AddMarkupContent(44, "\r\n                        ");
                    __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 45);
                    __builder.AddComponentParameter(46, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder.AddComponentParameter(47, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder.AddComponentParameter(48, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi mdi-${$.$strNN((this.ViewModel.PlayProgress.IsPlaying ? "pause" : "play"))} mgx-1`));
                    __builder.AddComponentParameter(49, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.ViewModel, this.ViewModel.PlayPauseMedia))));
                    __builder.CloseComponent();
                    __builder.AddMarkupContent(50, "\r\n                        ");
                    __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 51);
                    __builder.AddComponentParameter(52, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder.AddComponentParameter(53, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder.AddComponentParameter(54, "Class", "mdi mdi-skip-next mgx-1");
                    __builder.AddComponentParameter(55, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.ViewModel, this.ViewModel.Next))));
                    __builder.CloseComponent();
                    __builder.AddMarkupContent(56, "\r\n                        ");
                    __builder.OpenComponent$1($.$QxAa.LCCMCS$1.PlaylistMenu, 57);
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591020514)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296053218)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296053218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296053218)
            
            //--TRIMMABLE-BOUNDARY-START(4296053218)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296053218)
            
            static $h = 1085922;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseInjectedComponent$$($.$QxAa.LCCMCS.CommunityMediaService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475922402),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180955106,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1085922,
      "h": 21475922402,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475922402)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770889698),
    {
      "r": 65537,
      "p": [
        {
          "n": "v",
          "p": 655361
        }
      ],
      "n": "SetProgress",
      "d": 1085922,
      "h": 25770889698,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770889698),
//--TRIMMABLE-BOUNDARY-START(8591020514),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1085922,
      "h": 8591020514,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591020514)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296053218),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1085922,
      "h": 4296053218,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296053218)
  ],
  "h": 1085922
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.Shared.PagePlayer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Shared${separator}PagePlayer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1085922)
        
        

        //--TRIMMABLE-BOUNDARY-START(1216994)
        $asm.$cls(`$QxAa.LCCMCS$1.PlaylistMenu`, ($self) => class PlaylistMenu extends $.$hDPm.LCFCC$1.BaseInjectedComponent$$($.$QxAa.LCCMCS.CommunityMediaService)
        {
            //--TRIMMABLE-BOUNDARY-START(25771020770)
            /*string */ get OptimizedComponentName()
            {
                return "playlistmenu";
            }
            //--TRIMMABLE-BOUNDARY-END(25771020770)
            
            //--TRIMMABLE-BOUNDARY-START(21476053474)
            /*ValueTask<bool> */ OnSelected(/*DataListSelection<IMediaModel>*/ selection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476053474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ViewModel.Play($.$sl.SL.Enumerable.First$1($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$fPer.LCFCD.IMediaModel), selection.SelectedItems).LCFCCD$1$IDataListItemContext$$$Data);
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(21476053474)
            
            //--TRIMMABLE-BOUNDARY-START(8591151586)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591151586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$3.Popup, 0);
                __builder.AddComponentParameter(1, "VerticalPosition", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCP$4.PositionY, 2/*PositionY.BottomToTop*/), $.$hDPm.LCFCCP$4.PositionY));
                __builder.AddComponentParameter(2, "pop-class", "bg-dark-09 shadow-2 corner-2 wp-100 z-5");
                __builder.AddAttribute$3(3, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(4, "<button title=\"Playlist\" class=\"lt transparent mdi mdi-playlist-music-outline round mgx-1 fsz-27 hx-03 wx-03 pd-0 bd-0\"></button>");
                    }, $gKsQDi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1216994,"h":0,"f":17825794});
                }), $QPjGlc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1216994,"h":0,"f":17825794}));
                __builder.AddAttribute$3(5, "Pop", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCP$3.PopupContext))().$ctor(this, ( (/*_*/ _0) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        if (this.ViewModel.CurrentPlaylist !== null)
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$fPer.LCFCD.IMediaModel), 6);
                            __builder2.AddComponentParameter(7, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaModel), this.ViewModel.CurrentPlaylist.LCFCS$3$IMediaPlaylist$Medias));
                            __builder2.AddComponentParameter(8, "Selectable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                            __builder2.AddComponentParameter(9, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder2.AddComponentParameter(10, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                            __builder2.AddAttribute$3(11, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fPer.LCFCD.IMediaModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fPer.LCFCD.IMediaModel))))().$ctor(this, ( (/*media*/ media) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(12, "div");
                                    __builder3.AddAttribute$5(13, "class", "row pd-1");
                                    __builder3.AddMarkupContent(14, "<div class=\"col-1\"><button class=\"lt transparent mdi mdi-play round mgx-1 fsz-20 bd-0\"></button></div>\r\n                    ");
                                    __builder3.OpenElement(15, "div");
                                    __builder3.AddAttribute$5(16, "class", "col-8");
                                    __builder3.OpenElement(17, "h3");
                                    __builder3.AddAttribute$5(18, "class", "mg-0");
                                    __builder3.AddContent$4(19, media.Model.LCFC$IDisplayable$Title);
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(20, "\r\n                    ");
                                    __builder3.OpenElement(21, "div");
                                    __builder3.AddAttribute$5(22, "class", "col-1");
                                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder3, 23, "onclick", true);
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCP$3.Popup, 24);
                                    __builder3.AddComponentParameter(25, "Placement", "PopupPlacement.Horizontal");
                                    __builder3.AddAttribute$3(26, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddMarkupContent(27, "<button class=\"lt transparent mdi mdi-menu round mgx-1 fsz-20 bd-0\"></button>");
                                        }, $yOtpmg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1216994,"h":0,"f":17825794});
                                    }), $afzBSh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1216994,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(28, "Pop", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCP$3.PopupContext))().$ctor(this, ( (/*__*/ __) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 29);
                                            __builder4.AddComponentParameter(30, "Class", "shadow bg-dark");
                                            __builder4.AddComponentParameter(31, "Selectable", "true");
                                            __builder4.AddAttribute$3(32, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*___*/ ___) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 33);
                                                    __builder5.AddComponentParameter(34, "Class", "nowrap");
                                                    __builder5.AddAttribute$3(35, "IconLeft", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*____*/ ____) =>
                                                    {
                                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                        {
                                                            __builder6.AddMarkupContent(36, "<i class=\"mdi mdi-plus mgr\"></i>");
                                                        }, $xhpMKe ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1216994,"h":0,"f":17825794});
                                                    }), $wmunub ??= {"r":6881395,"p":[{"n":"____","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1216994,"h":0,"f":17825794}));
                                                    __builder5.AddAttribute$3(37, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*____*/ ____) =>
                                                    {
                                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                        {
                                                            __builder6.AddMarkupContent(38, "\r\n                                            Add to a Playlist\r\n                                        ");
                                                        }, $yGASea ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1216994,"h":0,"f":17825794});
                                                    }), $EqHzPh ??= {"r":6881395,"p":[{"n":"____","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1216994,"h":0,"f":17825794}));
                                                    __builder5.CloseComponent();
                                                }, $UFvEqj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1216994,"h":0,"f":17825794});
                                            }), $YLaWml ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1216994,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                        }, $cXMhGh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1216994,"h":0,"f":17825794});
                                    }), $bhPwvj ??= {"r":6881395,"p":[{"n":"__","p":39540394}],"n":"","d":1216994,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }, $BfZbCc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1216994,"h":0,"f":17825794});
                            }), $NNeRZc ??= {"r":6881395,"p":[{"n":"media","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fPer.LCFCD.IMediaModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fPer.LCFCD.IMediaModel)).$h}],"n":"","d":1216994,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }
                    }, $QNyhXa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1216994,"h":0,"f":17825794});
                }), $BxHgLi ??= {"r":6881395,"p":[{"n":"_","p":39540394}],"n":"","d":1216994,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8591151586)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Frameworks.Common.Data.IMediaModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Frameworks.Common.Data.IMediaModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Frameworks$Common$Data$IMediaModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(4296184290)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296184290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296184290)
            
            //--TRIMMABLE-BOUNDARY-START(4296184290)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296184290)
            
            static $h = 1216994;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseInjectedComponent$$($.$QxAa.LCCMCS.CommunityMediaService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771020770),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181086178,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1216994,
      "h": 25771020770,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25771020770)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476053474),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$fPer.LCFCD.IMediaModel).$h
        }
      ],
      "n": "OnSelected",
      "d": 1216994,
      "h": 21476053474,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476053474),
//--TRIMMABLE-BOUNDARY-START(8591151586),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1216994,
      "h": 8591151586,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591151586)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296184290),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1216994,
      "h": 4296184290,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296184290)
  ],
  "h": 1216994
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$fPer.LCFCD.IMediaModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$fPer.LCFCD.IMediaModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Client.Shared.PlaylistMenu`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Client${separator}Shared${separator}PlaylistMenu`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1216994)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Media.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(37346)
