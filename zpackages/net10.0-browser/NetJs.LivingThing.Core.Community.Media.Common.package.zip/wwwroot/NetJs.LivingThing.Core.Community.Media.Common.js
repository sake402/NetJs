
//--TRIMMABLE-BOUNDARY-START(39087)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $CuWiDj;
    let $aYXQEb;
    let $eOfIIj;
    let $RorMle;
    let $jEZnXf;
    let $Gcvjrf;
    let $DTQfLc;
    let $CJoKHg;
    let $BbWBmi;
    let $lAquJd;
    let $gYwswg;
    let $qzVYgi;
    let $ZGrTgh;
    let $BmfJSe;
    let $gLDgai;
    let $YpUAYd;
    let $BXKHNj;
    let $HYRCfj;
    let $RXtrNh;
    let $JUhfre;
    let $XAwDje;
    let $LAopPb;
    let $mMUQGa;
    let $XdETJd;
    let $wAayKi;
    let $vgpKei;
    let $UyVlIi;
    let $coSWWb;
    let $KhBSNf;
    let $LDEeng;
    let $xlQQDk;
    let $SmSjei;
    let $uRTBGh;
    let $NdUuAe;
    let $wJjgEf;
    let $gjURCg;
    let $TeGwdl;
    let $ZIkvOk;
    let $cqzzwc;
    let $YkLuvi;
    let $TmSKFj;
    let $BpBQyi;
    let $fgfkPf;
    let $Clcygg;
    let $MdeFEg;
    let $bghXTh;
    let $zcfrkj;
    let $lovFwi;
    let $mpPVPe;
    let $lNzgZd;
    let $ZpBmgj;
    let $wXoKDg;
    let $NSfaya;
    let $PjqFHc;
    let $yOfFqk;
    let $XgFFNc;
    let $suNygi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Media.Common", 
    {
  "h": 39087,
  "f": "LivingThing.Core.Community.Media.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Media.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Media.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(694447)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaModelCustomAttributesProvider`, ($self) => class CommunityMediaModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295661743)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295661743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$OSmP.LCCMCS$1.CommunityMediaSettings, $.$OSmP.LCCMCS$2.CommunityMediaStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295661743)
            
            static $h = 694447;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295661743),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 694447,
      "h": 4295661743,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295661743)
  ],
  "h": 694447
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(694447)
        
        

        //--TRIMMABLE-BOUNDARY-START(170159)
        $asm.$cls(`$OSmP.LCCMC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295137455)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295137455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295137455)
            
            static $h = 170159;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295137455),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 170159,
      "h": 4295137455,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295137455)
  ],
  "h": 170159
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(170159)
        
        

        //--TRIMMABLE-BOUNDARY-START(956591)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaPlayStateCustomAttributesProvider`, ($self) => class CommunityMediaPlayStateCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295923887)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295923887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295923887)
            
            static $h = 956591;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295923887),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 956591,
      "h": 4295923887,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295923887)
  ],
  "h": 956591
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaPlayStateCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaPlayStateCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(956591)
        
        

        //--TRIMMABLE-BOUNDARY-START(1743023)
        $asm.$cls(`$OSmP.LCCMCS$1.CommunityMediaSettingsCustomAttributesProvider`, ($self) => class CommunityMediaSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296710319)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296710319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296710319)
            
            static $h = 1743023;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296710319),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1743023,
      "h": 4296710319,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296710319)
  ],
  "h": 1743023
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Settings.CommunityMediaSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Settings${separator}CommunityMediaSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1743023)
        
        

        //--TRIMMABLE-BOUNDARY-START(2005167)
        $asm.$cls(`$OSmP.LCCMCS$2.CommunityMediaStatesCustomAttributesProvider`, ($self) => class CommunityMediaStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296972463)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296972463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296972463)
            
            static $h = 2005167;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296972463),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2005167,
      "h": 4296972463,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296972463)
  ],
  "h": 2005167
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.States.CommunityMediaStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}States${separator}CommunityMediaStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2005167)
        
        

        //--TRIMMABLE-BOUNDARY-START(2201775)
        $asm.$cls(`$OSmP.LCCMC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297169071)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297169071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OSmP.LCCMCM.CommunityMediaAlbumModelTypeDescriptorBuilder.Register();
                $.$OSmP.LCCMCM.CommunityMediaModelTypeDescriptorBuilder.Register();
                $.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptorBuilder.Register();
                $.$OSmP.LCCMCS$1.CommunityMediaSettingsTypeDescriptorBuilder.Register();
                $.$OSmP.LCCMCS$2.CommunityMediaStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297169071)
            
            static $h = 2201775;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297169071),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2201775,
      "h": 4297169071,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297169071)
  ],
  "h": 2201775
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2201775)
        
        

        //--TRIMMABLE-BOUNDARY-START(104623)
        $asm.$cls(`$OSmP.LCCMC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295071919)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295071919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OSmP.LCCMCM.CommunityMediaAlbumModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OSmP.LCCMCM.CommunityMediaAlbumModelCustomAttributesProvider, $.$OSmP.LCCMCM.CommunityMediaAlbumModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OSmP.LCCMCM.CommunityMediaModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OSmP.LCCMCM.CommunityMediaModelCustomAttributesProvider, $.$OSmP.LCCMCM.CommunityMediaModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OSmP.LCCMCM.CommunityMediaPlayState.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OSmP.LCCMCM.CommunityMediaPlayStateCustomAttributesProvider, $.$OSmP.LCCMCM.CommunityMediaPlayStateCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OSmP.LCCMCM.CommunityMediaPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelCustomAttributesProvider, $.$OSmP.LCCMCM.CommunityMediaPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OSmP.LCCMCS$1.CommunityMediaSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OSmP.LCCMCS$1.CommunityMediaSettingsCustomAttributesProvider, $.$OSmP.LCCMCS$1.CommunityMediaSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OSmP.LCCMCS$2.CommunityMediaStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OSmP.LCCMCS$2.CommunityMediaStatesCustomAttributesProvider, $.$OSmP.LCCMCS$2.CommunityMediaStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295071919)
            
            static $h = 104623;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295071919),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 104623,
      "h": 4295071919,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295071919)
  ],
  "h": 104623
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(104623)
        
        

        //--TRIMMABLE-BOUNDARY-START(432303)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaAlbumModelCustomAttributesProvider`, ($self) => class CommunityMediaAlbumModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295399599)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295399599)
            
            //--TRIMMABLE-BOUNDARY-START(8590366895)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590366895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OSmP.LCCMCM.CommunityMediaAlbumModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Medias", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OSmP.LCCMCM.CommunityMediaAlbumModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $CuWiDj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":432303,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $aYXQEb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":432303,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$OSmP.LCCMCM.CommunityMediaPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590366895)
            
            static $h = 432303;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590366895),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 432303,
      "h": 8590366895,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590366895)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295399599),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 432303,
      "h": 4295399599,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295399599)
  ],
  "h": 432303
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaAlbumModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(432303)
        
        

        //--TRIMMABLE-BOUNDARY-START(2136239)
        $asm.$cls(`$OSmP.LCCMCS$2.CommunityMediaStatesTypeDescriptorBuilder`, ($self) => class CommunityMediaStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592070831)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592070831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OSmP.LCCMCS$2.CommunityMediaStatesTypeDescriptor()
                        const $t1 = $.$OSmP.LCCMCS$2.CommunityMediaStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Media.Common.States.CommunityMediaStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $jEZnXf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2136239,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OSmP.LCCMCS$2.CommunityMediaStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592070831)
            
            //--TRIMMABLE-BOUNDARY-START(4297103535)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297103535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297103535)
            
            //--TRIMMABLE-BOUNDARY-START(4297103535)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297103535)
            
            static $h = 2136239;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592070831),
    {
      "r": 65537,
      "n": "Register",
      "d": 2136239,
      "h": 8592070831,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592070831)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297103535),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2136239,
      "h": 4297103535,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297103535)
  ],
  "h": 2136239
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.States.CommunityMediaStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}States${separator}CommunityMediaStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2136239)
        
        

        //--TRIMMABLE-BOUNDARY-START(235695)
        $asm.$cls(`$OSmP.LCCMC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295202991)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295202991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$OSmP.LCCMCS.ICommunityMediaFeedRemoteService, $.$OSmP.LCCMCS.ICommunityMediaFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OSmP.LCCMCS.ICommunityMediaFeedRemoteService_Mocking().$ctor$3(impl);
                }, $ZGrTgh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$OSmP.LCCMCS.ICommunityMediaFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OSmP.LCCMCS.ICommunityMediaFeedRemoteService_Mocking().$ctor$3(impl);
                }, $BmfJSe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$OSmP.LCCMCS.IComunityMediaRemoteService, $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking().$ctor$3(impl);
                }, $gLDgai ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking().$ctor$3(impl);
                }, $YpUAYd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking().$ctor$3(impl);
                }, $BXKHNj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking().$ctor$3(impl);
                }, $HYRCfj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking().$ctor$3(impl);
                }, $RXtrNh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking().$ctor$3(impl);
                }, $JUhfre ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking().$ctor$3(impl);
                }, $XAwDje ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking().$ctor$3(impl);
                }, $LAopPb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking().$ctor$3(impl);
                }, $mMUQGa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking().$ctor$3(impl);
                }, $XdETJd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking().$ctor$3(impl);
                }, $wAayKi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking().$ctor$3(impl);
                }, $vgpKei ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking().$ctor$3(impl);
                }, $UyVlIi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking().$ctor$3(impl);
                }, $coSWWb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking().$ctor$3(impl);
                }, $KhBSNf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":235695,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295202991)
            
            static $h = 235695;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295202991),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 235695,
      "h": 4295202991,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295202991)
  ],
  "h": 235695
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(235695)
        
        

        //--TRIMMABLE-BOUNDARY-START(1874095)
        $asm.$cls(`$OSmP.LCCMCS$1.CommunityMediaSettingsTypeDescriptorBuilder`, ($self) => class CommunityMediaSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591808687)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591808687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OSmP.LCCMCS$1.CommunityMediaSettingsTypeDescriptor()
                        const $t1 = $.$OSmP.LCCMCS$1.CommunityMediaSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Media.Common.Settings.CommunityMediaSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $eOfIIj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1874095,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OSmP.LCCMCS$1.CommunityMediaSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591808687)
            
            //--TRIMMABLE-BOUNDARY-START(4296841391)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296841391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296841391)
            
            //--TRIMMABLE-BOUNDARY-START(4296841391)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296841391)
            
            static $h = 1874095;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591808687),
    {
      "r": 65537,
      "n": "Register",
      "d": 1874095,
      "h": 8591808687,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591808687)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296841391),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1874095,
      "h": 4296841391,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296841391)
  ],
  "h": 1874095
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Settings.CommunityMediaSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Settings${separator}CommunityMediaSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1874095)
        
        

        //--TRIMMABLE-BOUNDARY-START(1087663)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaPostModelCustomAttributesProvider`, ($self) => class CommunityMediaPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296054959)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296054959)
            
            //--TRIMMABLE-BOUNDARY-START(8591022255)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591022255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OSmP.LCCMCM.CommunityMediaPostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(8, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("SetType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            $i3.Order = (-2147483648);
                            $i3.Description = "Tell us the type of media you are creating";
                            $i3.InputType = $.$cast(25n, $.$fPer.LCFC.InputType);
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=AudioVideo"], [-1], null);
                            $i3.OptionsReader = ($.$OSmP.LCCMCM.CommunityMediaTypeReader.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Duration", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("MediaUrls", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Resources", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            $i6.Order = (4001);
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=AudioVideo"], [-1], null);
                            $i6.Description = "Upload your media files";
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Genre", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Group", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Language", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Moments", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OSmP.LCCMCM.CommunityMediaPostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $lAquJd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1087663,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $gYwswg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1087663,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591022255)
            
            static $h = 1087663;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591022255),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1087663,
      "h": 8591022255,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591022255)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296054959),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1087663,
      "h": 4296054959,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296054959)
  ],
  "h": 1087663
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1087663)
        
        

        //--TRIMMABLE-BOUNDARY-START(825519)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaModelTypeDescriptorBuilder`, ($self) => class CommunityMediaModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590760111)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590760111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OSmP.LCCMCM.CommunityMediaModelTypeDescriptor()
                        const $t1 = $.$OSmP.LCCMCM.CommunityMediaModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Media.Common.Models.CommunityMediaModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $DTQfLc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":825519,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OSmP.LCCMCM.CommunityMediaModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590760111)
            
            //--TRIMMABLE-BOUNDARY-START(4295792815)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295792815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295792815)
            
            //--TRIMMABLE-BOUNDARY-START(4295792815)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295792815)
            
            static $h = 825519;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590760111),
    {
      "r": 65537,
      "n": "Register",
      "d": 825519,
      "h": 8590760111,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590760111)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295792815),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 825519,
      "h": 4295792815,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295792815)
  ],
  "h": 825519
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(825519)
        
        

        //--TRIMMABLE-BOUNDARY-START(1218735)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptorBuilder`, ($self) => class CommunityMediaPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591153327)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591153327);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor()
                        const $t1 = $.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $YkLuvi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1218735,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OSmP.LCCMCM.CommunityMediaPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591153327)
            
            //--TRIMMABLE-BOUNDARY-START(4296186031)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296186031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296186031)
            
            //--TRIMMABLE-BOUNDARY-START(4296186031)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296186031)
            
            static $h = 1218735;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591153327),
    {
      "r": 65537,
      "n": "Register",
      "d": 1218735,
      "h": 8591153327,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591153327)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296186031),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1218735,
      "h": 4296186031,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296186031)
  ],
  "h": 1218735
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1218735)
        
        

        //--TRIMMABLE-BOUNDARY-START(563375)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaAlbumModelTypeDescriptorBuilder`, ($self) => class CommunityMediaAlbumModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590497967)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590497967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OSmP.LCCMCM.CommunityMediaAlbumModelTypeDescriptor()
                        const $t1 = $.$OSmP.LCCMCM.CommunityMediaAlbumModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $gjURCg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":563375,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OSmP.LCCMCM.CommunityMediaAlbumModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590497967)
            
            //--TRIMMABLE-BOUNDARY-START(4295530671)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295530671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295530671)
            
            //--TRIMMABLE-BOUNDARY-START(4295530671)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295530671)
            
            static $h = 563375;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590497967),
    {
      "r": 65537,
      "n": "Register",
      "d": 563375,
      "h": 8590497967,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590497967)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295530671),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 563375,
      "h": 4295530671,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295530671)
  ],
  "h": 563375
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaAlbumModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(563375)
        
        

        //--TRIMMABLE-BOUNDARY-START(1349807)
        $asm.$cls(`$OSmP.LCCMC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591284399)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591284399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OSmP.LCCMCM.CommunityMediaPostModel, 2816/*PostTypes.Media*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OSmP.LCCMCM.CommunityMediaAlbumModel, 2817/*PostTypes.MediaAlbum*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OSmP.LCCMCM.CommunityMediaPostModel, 2819/*PostTypes.MediaAudio*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OSmP.LCCMCM.CommunityMediaPostModel, 2820/*PostTypes.MediaVideo*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OSmP.LCCMCM.CommunityMediaPostModel, 2818/*PostTypes.MediaGallery*/);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFCA$1.ISchemaOptionReader$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$OSmP.LCCMCM.CommunityMediaAlbumCategoryReader, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$OSmP.LCCMCM.CommunityMediaAlbumCategoryReader, x);
                }, $qzVYgi ??= {"r":$.$fPer.LCFCA$1.ISchemaOptionReader$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":1349807,"h":0,"f":17825794}));
                $.$OSmP.LCCMC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$OSmP.LCCMC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$OSmP.LCCMC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591284399)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$OSmP.LCCMC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296317103)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296317103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296317103)
            
            //--TRIMMABLE-BOUNDARY-START(4296317103)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296317103)
            
            static $h = 1349807;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591284399),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1349807,
      "h": 8591284399,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591284399)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296317103),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1349807,
      "h": 4296317103,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296317103)
  ],
  "h": 1349807
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1349807)
        
        

        //--TRIMMABLE-BOUNDARY-START(891055)
        $asm.$str(`$OSmP.LCCMCM.CommunityMediaPlayState`, ($self) => class CommunityMediaPlayState extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Stopped = 0;
            static Playing = 1;
            static Paused = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(891055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Stopped": 0n,
                    "Playing": 1n,
                    "Paused": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295858351)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295858351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295858351)
            
            //--TRIMMABLE-BOUNDARY-START(4295858351)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295858351)
            
            static $h = 891055;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180760239),
    {
      "t": 891055,
      "n": "Stopped",
      "d": 891055,
      "h": 17180760239,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180760239),
//--TRIMMABLE-BOUNDARY-START(12885792943),
    {
      "t": 891055,
      "n": "Playing",
      "d": 891055,
      "h": 12885792943,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885792943),
//--TRIMMABLE-BOUNDARY-START(8590825647),
    {
      "t": 891055,
      "n": "Paused",
      "d": 891055,
      "h": 8590825647,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590825647)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295858351),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 891055,
      "h": 4295858351,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295858351)
  ],
  "h": 891055
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaPlayState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaPlayState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(891055)
        
        

        //--TRIMMABLE-BOUNDARY-START(1939631)
        $asm.$cls(`$OSmP.LCCMCS$2.CommunityMediaStates`, ($self) => class CommunityMediaStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296906927)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296906927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296906927)
            
            //--TRIMMABLE-BOUNDARY-START(4296906927)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296906927)
            
            static $h = 1939631;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296906927),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1939631,
      "h": 4296906927,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296906927)
  ],
  "h": 1939631
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.States.CommunityMediaStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}States${separator}CommunityMediaStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1939631)
        
        

        //--TRIMMABLE-BOUNDARY-START(1677487)
        $asm.$cls(`$OSmP.LCCMCS$1.CommunityMediaSettings`, ($self) => class CommunityMediaSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296644783)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296644783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296644783)
            
            //--TRIMMABLE-BOUNDARY-START(4296644783)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296644783)
            
            static $h = 1677487;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296644783),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1677487,
      "h": 4296644783,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296644783)
  ],
  "h": 1677487
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Settings.CommunityMediaSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Settings${separator}CommunityMediaSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1677487)
        
        

        //--TRIMMABLE-BOUNDARY-START(1284271)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaTypeReader`, ($self) => class CommunityMediaTypeReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591218863)
            /*Pager<ISelectOption<PostTypes?>> */ GetOptions(/*object*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591218863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCP.PostUtility.GetPostTypeOptions(this, "Media", null);
            }
            //--TRIMMABLE-BOUNDARY-END(8591218863)
            
            //--TRIMMABLE-BOUNDARY-START(4297034070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaOptionReader<LivingThing.Core.Frameworks.Common.Posts.Models.PostTypes?>.GetOptions(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            [`LCFCA$1$ISchemaOptionReader$LivingThing$Core$Frameworks$Common$Posts$Models$PostTypes$LivingThing$Core$Frameworks$Common$Posts$Models$PostTypes$$GetOptions`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297034070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOptions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297034070)
            
            //--TRIMMABLE-BOUNDARY-START(4296251567)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296251567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296251567)
            
            //--TRIMMABLE-BOUNDARY-START(4296251567)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296251567)
            
            static $h = 1284271;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591218863),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes))).$h,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "GetOptions",
      "d": 1284271,
      "h": 8591218863,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591218863)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296251567),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1284271,
      "h": 4296251567,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296251567)
  ],
  "h": 1284271
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaTypeReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaTypeReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1284271)
        
        

        //--TRIMMABLE-BOUNDARY-START(2070703)
        $asm.$cls(`$OSmP.LCCMCS$2.CommunityMediaStatesTypeDescriptor`, ($self) => class CommunityMediaStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OSmP.LCCMCS$2.CommunityMediaStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4297037999)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297037999);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OSmP.LCCMCS$2.CommunityMediaStatesTypeDescriptor.GenerateProperties($.$OSmP.LCCMCS$2.CommunityMediaStates, this, factory);
                    }, $Gcvjrf ??= {"r":65537,"n":"","d":2070703,"h":0,"f":17825794}), 0, "CommunityMediaStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Media.Common\\States_CommunityMediaStates_LivingThing.Core.Community.Media.Common.States.CommunityMediaStatesTypeDescriptorBuilder.g.cs", "CommunityMediaStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297037999)
            
            //--TRIMMABLE-BOUNDARY-START(12886972591)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886972591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886972591)
            
            //--TRIMMABLE-BOUNDARY-START(17181939887)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Media.Common.States.CommunityMediaStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181939887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181939887)
            
            //--TRIMMABLE-BOUNDARY-START(8592005295)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Media.Common.States.CommunityMediaStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592005295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OSmP.LCCMCS$2.CommunityMediaStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OSmP.LCCMCS$2.CommunityMediaStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCS$2.CommunityMediaStates)))
                {
                    /*var*/ let result = $.$OSmP.LCCMCS$2.CommunityMediaStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCS$2.CommunityMediaStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OSmP.LCCMCS$2.CommunityMediaStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCS$2.CommunityMediaStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592005295)
            
            static $h = 2070703;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OSmP.LCCMCS$2.CommunityMediaStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886972591),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2070703,
      "h": 12886972591,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886972591),
//--TRIMMABLE-BOUNDARY-START(17181939887),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1939631,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2070703,
      "h": 17181939887,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181939887),
//--TRIMMABLE-BOUNDARY-START(8592005295),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1939631,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2070703,
      "h": 8592005295,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592005295)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297037999),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2070703,
      "h": 4297037999,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297037999)
  ],
  "h": 2070703
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OSmP.LCCMCS$2.CommunityMediaStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.States.CommunityMediaStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}States${separator}CommunityMediaStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2070703)
        
        

        //--TRIMMABLE-BOUNDARY-START(1808559)
        $asm.$cls(`$OSmP.LCCMCS$1.CommunityMediaSettingsTypeDescriptor`, ($self) => class CommunityMediaSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OSmP.LCCMCS$1.CommunityMediaSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296775855)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296775855);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OSmP.LCCMCS$1.CommunityMediaSettingsTypeDescriptor.GenerateProperties($.$OSmP.LCCMCS$1.CommunityMediaSettings, this, factory);
                    }, $RorMle ??= {"r":65537,"n":"","d":1808559,"h":0,"f":17825794}), 0, "CommunityMediaSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Media.Common\\Settings_CommunityMediaSettings_LivingThing.Core.Community.Media.Common.Settings.CommunityMediaSettingsTypeDescriptorBuilder.g.cs", "CommunityMediaSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296775855)
            
            //--TRIMMABLE-BOUNDARY-START(12886710447)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886710447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886710447)
            
            //--TRIMMABLE-BOUNDARY-START(17181677743)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Media.Common.Settings.CommunityMediaSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181677743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181677743)
            
            //--TRIMMABLE-BOUNDARY-START(8591743151)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Media.Common.Settings.CommunityMediaSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591743151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OSmP.LCCMCS$1.CommunityMediaSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OSmP.LCCMCS$1.CommunityMediaSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCS$1.CommunityMediaSettings)))
                {
                    /*var*/ let result = $.$OSmP.LCCMCS$1.CommunityMediaSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCS$1.CommunityMediaSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OSmP.LCCMCS$1.CommunityMediaSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCS$1.CommunityMediaSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591743151)
            
            static $h = 1808559;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OSmP.LCCMCS$1.CommunityMediaSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886710447),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1808559,
      "h": 12886710447,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886710447),
//--TRIMMABLE-BOUNDARY-START(17181677743),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1677487,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1808559,
      "h": 17181677743,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181677743),
//--TRIMMABLE-BOUNDARY-START(8591743151),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1677487,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1808559,
      "h": 8591743151,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591743151)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296775855),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1808559,
      "h": 4296775855,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296775855)
  ],
  "h": 1808559
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OSmP.LCCMCS$1.CommunityMediaSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Settings.CommunityMediaSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Settings${separator}CommunityMediaSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1808559)
        
        

        $asm.$typeProxy("$OSmP.LCCMCM.CommunityMediaPostModel", "$OSmP.LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel");
        //--TRIMMABLE-BOUNDARY-START(366767)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaAlbumModel`, ($self) => class CommunityMediaAlbumModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$OSmP.LCCMCM.CommunityMediaPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(47245007023)
            /*PostTypes */ get Type()
            {
                return 2817/*PostTypes.MediaAlbum*/;
            }
            //--TRIMMABLE-BOUNDARY-END(47245007023)
            
            //--TRIMMABLE-BOUNDARY-START(30065137839)
            /*IEnumerable<IMediaModel>*/ Medias = null;
            //--TRIMMABLE-BOUNDARY-END(30065137839)
            
            //--TRIMMABLE-BOUNDARY-START(38655072431)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655072431);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655072431)
            
            //--TRIMMABLE-BOUNDARY-START(42950039727)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950039727);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950039727)
            
            //--TRIMMABLE-BOUNDARY-START(34360105135)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360105135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Name", "Title", null, null, null, null);
                super.ModifyDescriptor(propertyBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(34360105135)
            
            //--TRIMMABLE-BOUNDARY-START(8651704662)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IMediaPlaylist.Medias.get
            get LCFCS$3$IMediaPlaylist$Medias()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12946671958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Medias;
            }
            //--TRIMMABLE-BOUNDARY-END(8651704662)
            
            //--TRIMMABLE-BOUNDARY-START(8590301359)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590301359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590301359)
            
            //--TRIMMABLE-BOUNDARY-START(8590301359)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(8590301359)
            
            static $h = 366767;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$OSmP.LCCMCM.CommunityMediaPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245007023),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770170543,
        "f": 50364417
      },
      "n": "Type",
      "d": 366767,
      "h": 47245007023,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245007023),
//--TRIMMABLE-BOUNDARY-START(30065137839),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180235951,
        "f": 50331649
      },
      "n": "Medias",
      "d": 366767,
      "h": 30065137839,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065137839)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655072431),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 366767,
      "h": 38655072431,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655072431),
//--TRIMMABLE-BOUNDARY-START(42950039727),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": 366767,
      "h": 42950039727,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950039727),
//--TRIMMABLE-BOUNDARY-START(34360105135),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 366767,
      "h": 34360105135,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360105135)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590301359),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 366767,
      "h": 8590301359,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590301359)
  ],
  "h": 366767
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCS$3.IMediaPlaylist, $.$LCOv.LCFCP.IPostNestedCategory ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaAlbumModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(366767)
        
        

        //--TRIMMABLE-BOUNDARY-START(1022127)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaPostModel`, ($self) => class CommunityMediaPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(253404092591)
            /*PostTypes */ get Type()
            {
                return this.SetType ?? 2816/*PostTypes.Media*/;
            }
            //--TRIMMABLE-BOUNDARY-END(253404092591)
            
            //--TRIMMABLE-BOUNDARY-START(244814157999)
            /*PostTypes? */ get SetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375204527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.SetType;
            }
            /*PostTypes? */ set SetType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519190703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.SetType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(244814157999)
            
            //--TRIMMABLE-BOUNDARY-START(25770825903)
            /*int */ get Duration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655727791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, 0, "Duration", null);
            }
            /*int */ set Duration(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569517743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Int32, value, "Duration");
            }
            //--TRIMMABLE-BOUNDARY-END(25770825903)
            
            //--TRIMMABLE-BOUNDARY-START(158914812079)
            /*IEnumerable<string> */ get MediaUrls()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605400751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>*/ let __ca1__;
                return _ = ((__ca1__ = this.Resources) !== null ? $.$sl.SL.Enumerable.Select$1($.$Iaui.LCFCM.ResourceModel, $.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ResourceModel, $.$$.S.String))().$ctor(this,  (/*r*/ r) =>
                {
                    return r.FullPath;
                }, $LDEeng ??= {"r":1310721,"p":[{"n":"r","p":15279446}],"n":"","d":1022127,"h":0,"f":17825794})) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(158914812079)
            
            //--TRIMMABLE-BOUNDARY-START(188979583151)
            /*IEnumerable<ResourceModel> */ get Resources()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785269935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.Resources;
            }
            /*IEnumerable<ResourceModel> */ set Resources(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929256111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.Resources = value;
            }
            //--TRIMMABLE-BOUNDARY-END(188979583151)
            
            //--TRIMMABLE-BOUNDARY-START(176094681263)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176094681263);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176094681263)
            
            //--TRIMMABLE-BOUNDARY-START(184684615855)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184684615855);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684615855)
            
            //--TRIMMABLE-BOUNDARY-START(180389648559)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(180389648559);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389648559)
            
            //--TRIMMABLE-BOUNDARY-START(249109125295)
            /*bool */ ShouldEditSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(249109125295);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249109125295)
            
            //--TRIMMABLE-BOUNDARY-START(128850041007)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$2(this, null, "Media", null, true);
            }
            //--TRIMMABLE-BOUNDARY-END(128850041007)
            
            //--TRIMMABLE-BOUNDARY-START(133145008303)
            /*string */ get LCFCD$IMediaModel$BannerUrl()
            {
                return (this.Icon?.FullPath ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(133145008303)
            
            //--TRIMMABLE-BOUNDARY-START(30065793199)
            /*string*/ Genre = null;
            //--TRIMMABLE-BOUNDARY-END(30065793199)
            
            //--TRIMMABLE-BOUNDARY-START(120260106415)
            /*string*/ Group = null;
            //--TRIMMABLE-BOUNDARY-END(120260106415)
            
            //--TRIMMABLE-BOUNDARY-START(124555073711)
            /*string*/ Language = null;
            //--TRIMMABLE-BOUNDARY-END(124555073711)
            
            //--TRIMMABLE-BOUNDARY-START(137439975599)
            /*TimeSpan?*/ LCFCD$IMediaModel$Duration = null;
            //--TRIMMABLE-BOUNDARY-END(137439975599)
            
            //--TRIMMABLE-BOUNDARY-START(167504746671)
            /*IEnumerable<IMediaMoment>*/ moments = null;
            //--TRIMMABLE-BOUNDARY-END(167504746671)
            
            //--TRIMMABLE-BOUNDARY-START(171799713967)
            /*IEnumerable<IMediaMoment> */ get Moments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195335343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.moments !== null)
                {
                    return this.moments;
                }
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>*/ let __ca2__;
                if ((__ca2__ = this.Resources) !== null ? $.$sl.SL.Enumerable.Any($.$Iaui.LCFCM.ResourceModel, __ca2__, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ResourceModel, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                {
                    /*string?*/ let __ca3__;
                    return (((__ca3__ = r.Name) !== null ? $.$$.S.String.StartsWith$3.call(__ca3__, "~/moment") : false)) && r.IsImage;
                }, $xlQQDk ??= {"r":262145,"p":[{"n":"r","p":15279446}],"n":"","d":1022127,"h":0,"f":17825794})) : false)
                {
                    return this.moments ??= $.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.ToList($.$fPer.LCFCD.MediaMoment, $.$sl.SL.Enumerable.OrderBy$1($.$fPer.LCFCD.MediaMoment, $.$$.S.TimeSpan, $.$sl.SL.Enumerable.Distinct$1($.$fPer.LCFCD.MediaMoment, $.$sl.SL.Enumerable.Where($.$fPer.LCFCD.MediaMoment, $.$sl.SL.Enumerable.Select$1($.$Iaui.LCFCM.ResourceModel, $.$fPer.LCFCD.MediaMoment, $.$sl.SL.Enumerable.Where($.$Iaui.LCFCM.ResourceModel, this.Resources, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ResourceModel, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                    {
                        /*string?*/ let __ca4__;
                        return (((__ca4__ = r.Name) !== null ? $.$$.S.String.StartsWith$3.call(__ca4__, "~/moment") : false)) && r.IsImage;
                    }, $SmSjei ??= {"r":262145,"p":[{"n":"r","p":15279446}],"n":"","d":1022127,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$Iaui.LCFCM.ResourceModel, $.$fPer.LCFCD.MediaMoment))().$ctor(this,  (/*r*/ r) =>
                    {
                        /*var*/ let interval = 2;
                        /*TimeSpan?*/ let time = null;
                        /*var*/ let smoment = $.$$.SI.Path.GetFileNameWithoutExtension$1($.$$.S.String.Substring$1.call(r.Name, 8));
                        if ($.$$.S.String.Contains$1.call(smoment, /*-*/ 45))
                        {
                            /*var*/ let split = $.$$.S.String.Split$1.call(smoment, /*-*/ 45, 0);
                            smoment = $.$$.System.Array.$ReadT1.call(split, 0);
                            if ($.$$.S.String.EndsWith.call($.$$.System.Array.$ReadT1.call(split, 1), /*s*/ 115))
                            {
                                time = $.$$.S.TimeSpan.FromSeconds$2(BigInt($.$$.S.Int32.Parse$7($.$$.S.String.TrimEnd$1.call($.$$.System.Array.$ReadT1.call(split, 1), /*s*/ 115))));
                            }
                            else 
                            {
                                $.$$.S.Int32.TryParse$6($.$$.System.Array.$ReadT1.call(split, 1), $.$ref(() => interval, ($v) => interval = $v, $.$$.S.Int32));
                            }
                        }
                        /*int*/ let imoment = 0;
                        if (time !== null || $.$$.S.Int32.TryParse$6(smoment, $.$ref(() => imoment, ($v) => imoment = $v, $.$$.S.Int32)))
                        {
                            return (() =>
                            {
                                //new $.$fPer.LCFCD.MediaMoment()
                                const $t3 = $.$fPer.LCFCD.MediaMoment;
                                const $i3 = new $t3();
                                $i3.$ctor$2();
                                $i3.Name = r.Name;
                                $i3.Title = this.Name;
                                $i3.Icon = $.$Iaui.LCFCM.ResourceModel.op_Implicit(r);
                                $i3.Mark = time ?? $.$$.S.TimeSpan.FromMinutes$2(BigInt((((imoment - 1) | 0)) * interval));
                                return $i3;
                            })();
                        }
                        return null;
                    }, $uRTBGh ??= {"r":30443862,"p":[{"n":"r","p":15279446}],"n":"","d":1022127,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$fPer.LCFCD.MediaMoment, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t !== null;
                    }, $NdUuAe ??= {"r":262145,"p":[{"n":"t","p":30443862}],"n":"","d":1022127,"h":0,"f":17825794}))), new ($.$$.S.Func$$$($.$fPer.LCFCD.MediaMoment, $.$$.S.TimeSpan))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t.Mark;
                    }, $wJjgEf ??= {"r":186646529,"p":[{"n":"t","p":30443862}],"n":"","d":1022127,"h":0,"f":17825794}))), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.MediaMoment), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaMoment));
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(171799713967)
            
            //--TRIMMABLE-BOUNDARY-START(163209779375)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209779375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.ModifyDescriptor(propertyBuilder);
                if (propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Schema === 1/*SchemaType.Form*/)
                {
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Resources", "Media Files", null, null, null, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209779375)
            
            //--TRIMMABLE-BOUNDARY-START(257699059887)
            /*ValueTask<bool> */ Validate$1(/*IObservableDataDescriptor*/ step, /*SchemaContext*/ schema, /*out IEnumerable<string>?*/ errors)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699059887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>*/ let __ca5__;
                if (step.LCFCD$1$IObservableDataDescriptor$Name === "Resources" && !(((__ca5__ = this.Resources) !== null ? $.$sl.SL.Enumerable.Any$1($.$Iaui.LCFCM.ResourceModel, __ca5__) : false)))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Requires at least one ${$.$strNN(step.LCFCD$1$IObservableDataDescriptor$Label)}`);
                }
                return super.Validate$1(step, $.$clone(schema), errors);
            }
            //--TRIMMABLE-BOUNDARY-END(257699059887)
            
            //--TRIMMABLE-BOUNDARY-START(8591960500)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostMedia.Resources.get
            get LCFCP$IPostMedia$Resources()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886927796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Resources;
            }
            //--TRIMMABLE-BOUNDARY-END(8591960500)
            
            //--TRIMMABLE-BOUNDARY-START(38674270550)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IMediaModel.Genre.get
            get LCFCD$IMediaModel$Genre()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12904466774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Genre;
            }
            //--TRIMMABLE-BOUNDARY-END(38674270550)
            
            //--TRIMMABLE-BOUNDARY-START(47264205142)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IMediaModel.Group.get
            get LCFCD$IMediaModel$Group()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77328976214);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Group;
            }
            //--TRIMMABLE-BOUNDARY-END(47264205142)
            
            //--TRIMMABLE-BOUNDARY-START(55854139734)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IMediaModel.Language.get
            get LCFCD$IMediaModel$Language()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81623943510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Language;
            }
            //--TRIMMABLE-BOUNDARY-END(55854139734)
            
            //--TRIMMABLE-BOUNDARY-START(64444074326)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IMediaModel.MediaUrls.get
            get LCFCD$IMediaModel$MediaUrls()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85918910806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MediaUrls;
            }
            //--TRIMMABLE-BOUNDARY-END(64444074326)
            
            //--TRIMMABLE-BOUNDARY-START(73034008918)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IMediaModel.Moments.get
            get LCFCD$IMediaModel$Moments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90213878102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Moments;
            }
            //--TRIMMABLE-BOUNDARY-END(73034008918)
            
            //--TRIMMABLE-BOUNDARY-START(8593271220)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesCount.get
            get LCFCP$IPostReplyable$RepliesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478173108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593271220)
            
            //--TRIMMABLE-BOUNDARY-START(17183205812)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesDepth.get
            get LCFCP$IPostReplyable$RepliesDepth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773140404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesDepth;
            }
            //--TRIMMABLE-BOUNDARY-END(17183205812)
            
            //--TRIMMABLE-BOUNDARY-START(8593992116)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSubscribable.SubscribersCount.get
            get LCFCP$IPostSubscribable$SubscribersCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888959412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SubscribersCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593992116)
            
            //--TRIMMABLE-BOUNDARY-START(8594319796)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostViewTrackable.ViewsCount.get
            get LCFCP$IPostViewTrackable$ViewsCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889287092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ViewsCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8594319796)
            
            //--TRIMMABLE-BOUNDARY-START(8593009076)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReactable.Reactions.get
            get LCFCP$IPostReactable$Reactions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887976372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reactions;
            }
            //--TRIMMABLE-BOUNDARY-END(8593009076)
            
            //--TRIMMABLE-BOUNDARY-START(21475858607)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475858607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475858607)
            
            //--TRIMMABLE-BOUNDARY-START(21475858607)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(21475858607)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(137439975599)
                this.LCFCD$IMediaModel$Duration = null;
                //--TRIMMABLE-BOUNDARY-END(137439975599)
                
            }
            static $h = 1022127;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(253404092591),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965139119,
        "f": 50364417
      },
      "n": "Type",
      "d": 1022127,
      "h": 253404092591,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(253404092591),
//--TRIMMABLE-BOUNDARY-START(244814157999),
    {
      "p": $.$typeNullable($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375204527,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240519190703,
        "f": 83918849
      },
      "n": "SetType",
      "d": 1022127,
      "h": 244814157999,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            },
            {
              "n": "Order",
              "v": -2147483648,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Tell us the type of media you are creating",
              "t": 1310721
            },
            {
              "n": "InputType",
              "v": 25,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "//Icon=AudioVideo"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            },
            {
              "n": "OptionsReader",
              "v": 1284271,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(244814157999),
//--TRIMMABLE-BOUNDARY-START(25770825903),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655727791,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569517743,
        "f": 83886081
      },
      "n": "Duration",
      "d": 1022127,
      "h": 25770825903,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770825903),
//--TRIMMABLE-BOUNDARY-START(158914812079),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605400751,
        "f": 50331649
      },
      "n": "MediaUrls",
      "d": 1022127,
      "h": 158914812079,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914812079),
//--TRIMMABLE-BOUNDARY-START(188979583151),
    {
      "p": $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785269935,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231929256111,
        "f": 83918849
      },
      "n": "Resources",
      "d": 1022127,
      "h": 188979583151,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            },
            {
              "n": "Order",
              "v": 4001,
              "t": 655361
            },
            {
              "n": "Options",
              "v": [
                "//Icon=AudioVideo"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            },
            {
              "n": "Description",
              "v": "Upload your media files",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188979583151),
//--TRIMMABLE-BOUNDARY-START(128850041007),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015466159,
        "f": 50364417
      },
      "n": "Link",
      "d": 1022127,
      "h": 128850041007,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128850041007),
//--TRIMMABLE-BOUNDARY-START(133145008303),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029910191,
        "f": 50331650
      },
      "n": "{19564886}.BannerUrl",
      "o": "LCFCD$IMediaModel$BannerUrl",
      "d": 1022127,
      "h": 133145008303,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(133145008303),
//--TRIMMABLE-BOUNDARY-START(30065793199),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245662383,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206159452335,
        "f": 83886081
      },
      "n": "Genre",
      "d": 1022127,
      "h": 30065793199,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065793199),
//--TRIMMABLE-BOUNDARY-START(120260106415),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835596975,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214749386927,
        "f": 83886081
      },
      "n": "Group",
      "d": 1022127,
      "h": 120260106415,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120260106415),
//--TRIMMABLE-BOUNDARY-START(124555073711),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425531567,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223339321519,
        "f": 83886081
      },
      "n": "Language",
      "d": 1022127,
      "h": 124555073711,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124555073711),
//--TRIMMABLE-BOUNDARY-START(137439975599),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619844783,
        "f": 50331650
      },
      "n": "{19564886}.Duration",
      "o": "LCFCD$IMediaModel$Duration",
      "d": 1022127,
      "h": 137439975599,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(137439975599),
//--TRIMMABLE-BOUNDARY-START(171799713967),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaMoment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195335343,
        "f": 50331649
      },
      "n": "Moments",
      "d": 1022127,
      "h": 171799713967,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171799713967)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(176094681263),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 1022127,
      "h": 176094681263,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094681263),
//--TRIMMABLE-BOUNDARY-START(184684615855),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": 1022127,
      "h": 184684615855,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184684615855),
//--TRIMMABLE-BOUNDARY-START(180389648559),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 1022127,
      "h": 180389648559,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389648559),
//--TRIMMABLE-BOUNDARY-START(249109125295),
    {
      "r": 262145,
      "n": "ShouldEditSummary",
      "d": 1022127,
      "h": 249109125295,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(249109125295),
//--TRIMMABLE-BOUNDARY-START(163209779375),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 1022127,
      "h": 163209779375,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163209779375),
//--TRIMMABLE-BOUNDARY-START(257699059887),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "step",
          "p": 40536406
        },
        {
          "n": "schema",
          "p": 2394454
        },
        {
          "n": "errors",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 2
        }
      ],
      "n": "Validate",
      "o": "@$1",
      "d": 1022127,
      "h": 257699059887,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(257699059887)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(167504746671),
    {
      "t": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaMoment).$h,
      "n": "moments",
      "d": 1022127,
      "h": 167504746671,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(167504746671)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475858607),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1022127,
      "h": 21475858607,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475858607)
  ],
  "h": 1022127
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$LCOv.LCFCP.IPostMedia, $.$fPer.LCFCD.IMediaModel, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostSharable, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostViewTrackable, $.$LCOv.LCFCP.IPostReactable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1022127)
        
        

        //--TRIMMABLE-BOUNDARY-START(1415343)
        $asm.$cls(`$OSmP.LCCMCS.ICommunityMediaFeedRemoteService`, ($self) => class ICommunityMediaFeedRemoteService
        {
            static $h = 1415343;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1415343,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Services.ICommunityMediaFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Services${separator}ICommunityMediaFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1415343)
        
        

        //--TRIMMABLE-BOUNDARY-START(1546415)
        $asm.$cls(`$OSmP.LCCMCS.IComunityMediaRemoteService`, ($self) => class IComunityMediaRemoteService
        {
            static $h = 1546415;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1546415,
  "a": [
    {
      "t": 3537875,
      "c": 8593472467,
      "a": [
        {
          "v": [$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$h
          ],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.IReadDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Services.IComunityMediaRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Services${separator}IComunityMediaRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1546415)
        
        

        //--TRIMMABLE-BOUNDARY-START(301231)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaAlbumCategoryReader`, ($self) => class CommunityMediaAlbumCategoryReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885203119)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(12885203119)
            
            //--TRIMMABLE-BOUNDARY-START(4295268527)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295268527);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295268527)
            
            //--TRIMMABLE-BOUNDARY-START(8590235823)
            /*Pager<ISelectOption<CommunityMediaAlbumModel>> */ GetOptions(/*object*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590235823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.Select($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$fPer.LCFC.ISelectOption$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$OSmP.LCCMCM.CommunityMediaAlbumModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)), null), new ($.$$.S.Func$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$fPer.LCFC.ISelectOption$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel)))().$ctor(this,  (/*album*/ album) =>
                {
                    return (() =>
                    {
                        //new $.$fPer.LCFC.SelectOption$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel)()
                        const $t1 = $.$fPer.LCFC.SelectOption$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel);
                        const $i1 = new $t1();
                        $i1.$ctor$3(album);
                        $i1.Title = `${$.$strNN(album.Title)}(${$.$strNN(album.Identifier.ToString())})`;
                        return $i1;
                    })();
                }, $BbWBmi ??= {"r":$.$fPer.LCFC.ISelectOption$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$h,"p":[{"n":"album","p":366767}],"n":"","d":301231,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590235823)
            
            //--TRIMMABLE-BOUNDARY-START(4297034070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaOptionReader<LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel>.GetOptions(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaOptionReader$LivingThing$Core$Community$Media$Common$Models$CommunityMediaAlbumModel$GetOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297034070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOptions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297034070)
            
            static $h = 301231;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590235823),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel)).$h,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "GetOptions",
      "d": 301231,
      "h": 8590235823,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590235823)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885203119),
    {
      "t": 1309651,
      "n": "Server",
      "d": 301231,
      "h": 12885203119,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885203119)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295268527),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 301231,
      "h": 4295268527,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295268527)
  ],
  "h": 301231
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumCategoryReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaAlbumCategoryReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(301231)
        
        

        //--TRIMMABLE-BOUNDARY-START(1480879)
        $asm.$cls(`$OSmP.LCCMCS.ICommunityMediaFeedRemoteService_Mocking`, ($self) => class ICommunityMediaFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296448175)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296448175);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296448175)
            
            //--TRIMMABLE-BOUNDARY-START(8591415471)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Media$Common$Models$CommunityMediaPostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591415471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OSmP.LCCMCM.CommunityMediaPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaPostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591415471)
            
            static $h = 1480879;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296448175),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1480879,
      "h": 4296448175,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296448175)
  ],
  "h": 1480879
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$OSmP.LCCMCS.ICommunityMediaFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Services.ICommunityMediaFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Services${separator}ICommunityMediaFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1480879)
        
        

        //--TRIMMABLE-BOUNDARY-START(2267311)
        $asm.$cls(`$OSmP.LCFCR.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297234607)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297234607);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297234607)
            
            //--TRIMMABLE-BOUNDARY-START(8592201903)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Media$Common$Models$CommunityMediaAlbumModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592201903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592201903)
            
            //--TRIMMABLE-BOUNDARY-START(17182136495)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Media$Common$Models$CommunityMediaAlbumModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182136495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OSmP.LCCMCM.CommunityMediaAlbumModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17182136495)
            
            //--TRIMMABLE-BOUNDARY-START(21477103791)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Media$Common$Models$CommunityMediaAlbumModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477103791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$fPer.LCFCD.WireTransportModel$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OSmP.LCCMCM.CommunityMediaAlbumModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21477103791)
            
            //--TRIMMABLE-BOUNDARY-START(25772071087)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Media$Common$Models$CommunityMediaAlbumModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772071087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25772071087)
            
            //--TRIMMABLE-BOUNDARY-START(12887169199)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887169199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OSmP.LCCMCM.CommunityMediaAlbumModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12887169199)
            
            static $h = 2267311;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297234607),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2267311,
      "h": 4297234607,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297234607)
  ],
  "h": 2267311
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$fPer.LCFCD.ICreateDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$fPer.LCFCD.IReadDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityMediaAlbumModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2267311)
        
        

        //--TRIMMABLE-BOUNDARY-START(1611951)
        $asm.$cls(`$OSmP.LCCMCS.IComunityMediaRemoteService_Mocking`, ($self) => class IComunityMediaRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296579247)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296579247);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296579247)
            
            //--TRIMMABLE-BOUNDARY-START(8591546543)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Media$Common$Models$CommunityMediaPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591546543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OSmP.LCCMCM.CommunityMediaPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591546543)
            
            //--TRIMMABLE-BOUNDARY-START(17181481135)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Media$Common$Models$CommunityMediaPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181481135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OSmP.LCCMCM.CommunityMediaPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181481135)
            
            //--TRIMMABLE-BOUNDARY-START(21476448431)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Media$Common$Models$CommunityMediaPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476448431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OSmP.LCCMCM.CommunityMediaPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OSmP.LCCMCM.CommunityMediaPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476448431)
            
            //--TRIMMABLE-BOUNDARY-START(25771415727)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Media$Common$Models$CommunityMediaPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771415727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OSmP.LCCMCM.CommunityMediaPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771415727)
            
            //--TRIMMABLE-BOUNDARY-START(12886513839)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886513839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OSmP.LCCMCM.CommunityMediaPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886513839)
            
            static $h = 1611951;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296579247),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1611951,
      "h": 4296579247,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296579247)
  ],
  "h": 1611951
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$OSmP.LCCMCS.IComunityMediaRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.IReadDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Services.IComunityMediaRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Services${separator}IComunityMediaRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1611951)
        
        

        //--TRIMMABLE-BOUNDARY-START(1153199)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor`, ($self) => class CommunityMediaPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OSmP.LCCMCM.CommunityMediaPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296120495)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296120495);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor.GenerateProperties($.$OSmP.LCCMCM.CommunityMediaPostModel, this, factory);
                    }, $TmSKFj ??= {"r":65537,"n":"","d":1153199,"h":0,"f":17825794}), 0, "CommunityMediaPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Media.Common\\Models_CommunityMediaPostModel_LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModelTypeDescriptorBuilder.g.cs", "CommunityMediaPostModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296120495)
            
            //--TRIMMABLE-BOUNDARY-START(12886055087)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886055087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SetType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OSmP.LCCMCM.CommunityMediaPostModel.$type, $.$discardRef(), "SetType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SetType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$LCOv.LCFCPM$1.PostTypes), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "SetType";
                        $i1.DelaredOn = "LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$OSmP.LCCMCM.CommunityMediaPostModel)).SetType);
                        }, $BpBQyi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1153199,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SetType = value.AsNullableValue($.$LCOv.LCFCPM$1.PostTypes);
                        }, $fgfkPf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1153199,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Resources"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OSmP.LCCMCM.CommunityMediaPostModel.$type, $.$discardRef(), "Resources", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Resources")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Resources";
                        $i3.DelaredOn = "LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), ($.$cast(target, $.$OSmP.LCCMCM.CommunityMediaPostModel)).Resources);
                        }, $Clcygg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1153199,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Resources = value.AsReference($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel));
                        }, $MdeFEg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1153199,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OSmP.LCCMCM.CommunityMediaPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Type";
                        $i5.DelaredOn = "LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$OSmP.LCCMCM.CommunityMediaPostModel)).Type);
                        }, $bghXTh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1153199,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Duration"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OSmP.LCCMCM.CommunityMediaPostModel.$type, $.$discardRef(), "Duration", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Duration")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Duration";
                        $i7.DelaredOn = "LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$OSmP.LCCMCM.CommunityMediaPostModel)).Duration);
                        }, $zcfrkj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1153199,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Duration = value.AsInt();
                        }, $lovFwi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1153199,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MediaUrls"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OSmP.LCCMCM.CommunityMediaPostModel.$type, $.$discardRef(), "MediaUrls", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MediaUrls")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "MediaUrls";
                        $i9.DelaredOn = "LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$OSmP.LCCMCM.CommunityMediaPostModel)).MediaUrls);
                        }, $mpPVPe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1153199,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OSmP.LCCMCM.CommunityMediaPostModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Link";
                        $i11.DelaredOn = "LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$OSmP.LCCMCM.CommunityMediaPostModel)).Link);
                        }, $lNzgZd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1153199,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Genre"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OSmP.LCCMCM.CommunityMediaPostModel.$type, $.$discardRef(), "Genre", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Genre")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Genre";
                        $i13.DelaredOn = "LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$OSmP.LCCMCM.CommunityMediaPostModel)).Genre);
                        }, $ZpBmgj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1153199,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Genre = value.AsReference($.$$.S.String);
                        }, $wXoKDg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1153199,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Group"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OSmP.LCCMCM.CommunityMediaPostModel.$type, $.$discardRef(), "Group", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Group")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Group";
                        $i15.DelaredOn = "LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$OSmP.LCCMCM.CommunityMediaPostModel)).Group);
                        }, $NSfaya ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1153199,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Group = value.AsReference($.$$.S.String);
                        }, $PjqFHc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1153199,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Language"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OSmP.LCCMCM.CommunityMediaPostModel.$type, $.$discardRef(), "Language", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Language")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Language";
                        $i17.DelaredOn = "LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$OSmP.LCCMCM.CommunityMediaPostModel)).Language);
                        }, $yOfFqk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1153199,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Language = value.AsReference($.$$.S.String);
                        }, $XgFFNc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1153199,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Moments"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OSmP.LCCMCM.CommunityMediaPostModel.$type, $.$discardRef(), "Moments", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Moments")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaMoment), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "Moments";
                        $i19.DelaredOn = "LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaMoment), ($.$cast(target, $.$OSmP.LCCMCM.CommunityMediaPostModel)).Moments);
                        }, $suNygi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1153199,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886055087)
            
            //--TRIMMABLE-BOUNDARY-START(17181022383)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181022383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _SetType = _target.SetType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SetType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$LCOv.LCFCPM$1.PostTypes), () => _SetType, ($v) => _SetType = $v, null, true)))
                    {
                        _target.SetType = _SetType;
                    }
                }
                {
                    /*var*/ let _Resources = _target.Resources;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Resources"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), $.$Iaui.LCFCM.ResourceModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), $.$Iaui.LCFCM.ResourceModel, property, $.$ref(() => _Resources, ($v) => _Resources = $v, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel))))
                    {
                        _target.Resources = _Resources;
                        if (_Resources !== null)
                        {
                            let $en26 = _Resources.SCG$IEnumerable$$$GetEnumerator();
                            while ($en26.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en26.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$Iaui.LCFCM.ResourceModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), $.$Iaui.LCFCM.ResourceModel, property, $.$ref(() => _Resources, ($v) => _Resources = $v, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel)));
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Duration = _target.Duration;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Duration"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Duration, ($v) => _Duration = $v, $.$$.S.Int32)))
                    {
                        _target.Duration = _Duration;
                    }
                }
                {
                    /*var*/ let _MediaUrls = _target.MediaUrls;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MediaUrls"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _MediaUrls, ($v) => _MediaUrls = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        if (_MediaUrls !== null)
                        {
                            let $en34 = _MediaUrls.SCG$IEnumerable$$$GetEnumerator();
                            while ($en34.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en34.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _MediaUrls, ($v) => _MediaUrls = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Genre = _target.Genre;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Genre"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Genre, ($v) => _Genre = $v, $.$$.S.String)))
                    {
                        _target.Genre = _Genre;
                    }
                }
                {
                    /*var*/ let _Group = _target.Group;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Group"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Group, ($v) => _Group = $v, $.$$.S.String)))
                    {
                        _target.Group = _Group;
                    }
                }
                {
                    /*var*/ let _Language = _target.Language;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Language"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Language, ($v) => _Language = $v, $.$$.S.String)))
                    {
                        _target.Language = _Language;
                    }
                }
                {
                    /*var*/ let _Moments = _target.Moments;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Moments"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaMoment)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaMoment), $.$fPer.LCFCD.IMediaMoment));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaMoment), $.$fPer.LCFCD.IMediaMoment, property, $.$ref(() => _Moments, ($v) => _Moments = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaMoment))))
                    {
                        if (_Moments !== null)
                        {
                            let $en43 = _Moments.SCG$IEnumerable$$$GetEnumerator();
                            while ($en43.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en43.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$fPer.LCFCD.IMediaMoment)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaMoment), $.$fPer.LCFCD.IMediaMoment, property, $.$ref(() => _Moments, ($v) => _Moments = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaMoment)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181022383)
            
            //--TRIMMABLE-BOUNDARY-START(8591087791)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591087791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OSmP.LCCMCM.CommunityMediaPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OSmP.LCCMCM.CommunityMediaPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCM.CommunityMediaPostModel)))
                {
                    /*var*/ let result = $.$OSmP.LCCMCM.CommunityMediaPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCM.CommunityMediaPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OSmP.LCCMCM.CommunityMediaPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCM.CommunityMediaPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591087791)
            
            static $h = 1153199;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OSmP.LCCMCM.CommunityMediaPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886055087),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1153199,
      "h": 12886055087,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886055087),
//--TRIMMABLE-BOUNDARY-START(17181022383),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1022127,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1153199,
      "h": 17181022383,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181022383),
//--TRIMMABLE-BOUNDARY-START(8591087791),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1022127,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1153199,
      "h": 8591087791,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591087791)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296120495),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1153199,
      "h": 4296120495,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296120495)
  ],
  "h": 1153199
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OSmP.LCCMCM.CommunityMediaPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1153199)
        
        

        //--TRIMMABLE-BOUNDARY-START(497839)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaAlbumModelTypeDescriptor`, ($self) => class CommunityMediaAlbumModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295465135)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295465135);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OSmP.LCCMCM.CommunityMediaAlbumModelTypeDescriptor.GenerateProperties($.$OSmP.LCCMCM.CommunityMediaAlbumModel, this, factory);
                    }, $TeGwdl ??= {"r":65537,"n":"","d":497839,"h":0,"f":17825794}), 0, "CommunityMediaAlbumModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Media.Common\\Models_CommunityMediaAlbum_LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModelTypeDescriptorBuilder.g.cs", "CommunityMediaAlbumModelTypeDescriptor", 42);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295465135)
            
            //--TRIMMABLE-BOUNDARY-START(12885399727)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885399727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OSmP.LCCMCM.CommunityMediaAlbumModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaAlbumModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$OSmP.LCCMCM.CommunityMediaAlbumModel)).Type);
                        }, $ZIkvOk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":497839,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Medias"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OSmP.LCCMCM.CommunityMediaAlbumModel.$type, $.$discardRef(), "Medias", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Medias")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Medias";
                        $i3.DelaredOn = "LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OSmP.LCCMCM.CommunityMediaAlbumModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaModel), ($.$cast(target, $.$OSmP.LCCMCM.CommunityMediaAlbumModel)).Medias);
                        }, $cqzzwc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":497839,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$OSmP.LCCMCM.CommunityMediaPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885399727)
            
            //--TRIMMABLE-BOUNDARY-START(17180367023)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180367023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel, LivingThing.Core.Community.Media.Common.Models.CommunityMediaPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$OSmP.LCCMCM.CommunityMediaPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel, $.$OSmP.LCCMCM.CommunityMediaPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Medias = _target.Medias;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Medias"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaModel), $.$fPer.LCFCD.IMediaModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaModel), $.$fPer.LCFCD.IMediaModel, property, $.$ref(() => _Medias, ($v) => _Medias = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaModel))))
                    {
                        if (_Medias !== null)
                        {
                            let $en10 = _Medias.SCG$IEnumerable$$$GetEnumerator();
                            while ($en10.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en10.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$fPer.LCFCD.IMediaModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaModel), $.$fPer.LCFCD.IMediaModel, property, $.$ref(() => _Medias, ($v) => _Medias = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IMediaModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180367023)
            
            //--TRIMMABLE-BOUNDARY-START(8590432431)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590432431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OSmP.LCCMCM.CommunityMediaAlbumModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OSmP.LCCMCM.CommunityMediaAlbumModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCM.CommunityMediaAlbumModel)))
                {
                    /*var*/ let result = $.$OSmP.LCCMCM.CommunityMediaAlbumModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCM.CommunityMediaAlbumModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OSmP.LCCMCM.CommunityMediaAlbumModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCM.CommunityMediaAlbumModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590432431)
            
            static $h = 497839;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885399727),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 497839,
      "h": 12885399727,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885399727),
//--TRIMMABLE-BOUNDARY-START(17180367023),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 366767,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 497839,
      "h": 17180367023,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180367023),
//--TRIMMABLE-BOUNDARY-START(8590432431),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 366767,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 497839,
      "h": 8590432431,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590432431)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295465135),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 497839,
      "h": 4295465135,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295465135)
  ],
  "h": 497839
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OSmP.LCCMCM.CommunityMediaAlbumModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaAlbumModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaAlbumModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(497839)
        
        

        //--TRIMMABLE-BOUNDARY-START(628911)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaModel`, ($self) => class CommunityMediaModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$OSmP.LCCMCS$1.CommunityMediaSettings, $.$OSmP.LCCMCS$2.CommunityMediaStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295596207)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295596207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295596207)
            
            //--TRIMMABLE-BOUNDARY-START(4295596207)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295596207)
            
            static $h = 628911;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$OSmP.LCCMCS$1.CommunityMediaSettings, $.$OSmP.LCCMCS$2.CommunityMediaStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295596207),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 628911,
      "h": 4295596207,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295596207)
  ],
  "h": 628911
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(628911)
        
        

        //--TRIMMABLE-BOUNDARY-START(759983)
        $asm.$cls(`$OSmP.LCCMCM.CommunityMediaModelTypeDescriptor`, ($self) => class CommunityMediaModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OSmP.LCCMCM.CommunityMediaModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295727279)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295727279);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OSmP.LCCMCM.CommunityMediaModelTypeDescriptor.GenerateProperties($.$OSmP.LCCMCM.CommunityMediaModel, this, factory);
                    }, $CJoKHg ??= {"r":65537,"n":"","d":759983,"h":0,"f":17825794}), 0, "CommunityMediaModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Media.Common\\Models_CommunityMediaModel_LivingThing.Core.Community.Media.Common.Models.CommunityMediaModelTypeDescriptorBuilder.g.cs", "CommunityMediaModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295727279)
            
            //--TRIMMABLE-BOUNDARY-START(12885661871)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885661871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$OSmP.LCCMCS$1.CommunityMediaSettings, $.$OSmP.LCCMCS$2.CommunityMediaStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885661871)
            
            //--TRIMMABLE-BOUNDARY-START(17180629167)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Media.Common.Models.CommunityMediaModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180629167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Media.Common.Settings.CommunityMediaSettings, LivingThing.Core.Community.Media.Common.States.CommunityMediaStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$OSmP.LCCMCS$1.CommunityMediaSettings, $.$OSmP.LCCMCS$2.CommunityMediaStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$OSmP.LCCMCS$1.CommunityMediaSettings, $.$OSmP.LCCMCS$2.CommunityMediaStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180629167)
            
            //--TRIMMABLE-BOUNDARY-START(8590694575)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Media.Common.Models.CommunityMediaModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590694575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OSmP.LCCMCM.CommunityMediaModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OSmP.LCCMCM.CommunityMediaModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCM.CommunityMediaModel)))
                {
                    /*var*/ let result = $.$OSmP.LCCMCM.CommunityMediaModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCM.CommunityMediaModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OSmP.LCCMCM.CommunityMediaModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OSmP.LCCMCM.CommunityMediaModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590694575)
            
            static $h = 759983;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OSmP.LCCMCM.CommunityMediaModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885661871),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 759983,
      "h": 12885661871,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885661871),
//--TRIMMABLE-BOUNDARY-START(17180629167),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 628911,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 759983,
      "h": 17180629167,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180629167),
//--TRIMMABLE-BOUNDARY-START(8590694575),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 628911,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 759983,
      "h": 8590694575,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590694575)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295727279),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 759983,
      "h": 4295727279,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295727279)
  ],
  "h": 759983
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OSmP.LCCMCM.CommunityMediaModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Media.Common.Models.CommunityMediaModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Media${separator}Common${separator}Models${separator}CommunityMediaModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(759983)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(39087)
