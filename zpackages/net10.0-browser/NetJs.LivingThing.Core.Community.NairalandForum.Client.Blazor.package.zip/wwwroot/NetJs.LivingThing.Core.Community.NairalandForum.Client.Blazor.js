
//--TRIMMABLE-BOUNDARY-START(24928)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $hkBT) {
    "use strict";
    let _;
    let $WjEJHb;
    let $dQApQe;
    let $SgFAoe;
    let $dMrBgi;
    let $qLjpud;
    let $uJzaLk;
    let $OVUaRh;
    let $dPMaIg;
    let $izWFqh;
    let $XUsbgf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.NairalandForum.Client.Blazor", 
    {
  "h": 24928,
  "f": "LivingThing.Core.Community.NairalandForum.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.NairalandForum.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.NairalandForum.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(156000)
        $asm.$cls(`$Vfzz.LCCNC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295123296)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295123296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$Vfzz.LCCNC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295123296)
            
            static $h = 156000;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295123296),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 156000,
      "h": 4295123296,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295123296)
  ],
  "h": 156000
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(156000)
        
        

        //--TRIMMABLE-BOUNDARY-START(287072)
        $asm.$cls(`$Vfzz.LCCNC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590221664)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590221664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$Vfzz.LCCNCP.CommunityNairalandForumApp, "LivingThing.Core.Community.NairalandForum.Client", "Pages\\CommunityNairalandForumApp", "Community Nairaland Forum App", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Nairaland/{*PageRoute}" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590221664)
            
            //--TRIMMABLE-BOUNDARY-START(4295254368)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295254368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295254368)
            
            //--TRIMMABLE-BOUNDARY-START(4295254368)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295254368)
            
            static $h = 287072;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590221664),
    {
      "r": 65537,
      "n": "Build",
      "d": 287072,
      "h": 8590221664,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590221664)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295254368),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 287072,
      "h": 4295254368,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295254368)
  ],
  "h": 287072
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(287072)
        
        

        //--TRIMMABLE-BOUNDARY-START(221536)
        $asm.$cls(`$Vfzz.LCCNC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180090720)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Vfzz.LCCNCP.CommunityNairalandForumApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Vfzz.LCCNCP.CommunityNairalandForumApp().$ctor$6();
                    }, $WjEJHb ??= {"r":2752627,"n":"","d":221536,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180090720)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295188832)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295188832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295188832)
            
            //--TRIMMABLE-BOUNDARY-START(4295188832)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295188832)
            
            static $h = 221536;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180090720),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885123424,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 221536,
      "h": 17180090720,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180090720)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295188832),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 221536,
      "h": 4295188832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295188832)
  ],
  "h": 221536
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(221536)
        
        

        //--TRIMMABLE-BOUNDARY-START(418144)
        $asm.$cls(`$Vfzz.LCCNC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590352736)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590352736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$Vfzz.LCCNCS.CommunityNairalandForumService, $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$Vfzz.LCCNCS.CommunityNairalandForumApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Vfzz.LCCNCS.CommunityNairalandForumApplication, x);
                }, $dQApQe ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":418144,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Vfzz.LCCNCS.CommunityNairalandForumApplication, x);
                }, $SgFAoe ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":418144,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, services, null);
                $.$Vfzz.LCCNC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590352736)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Vfzz.LCCNC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295385440)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295385440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295385440)
            
            //--TRIMMABLE-BOUNDARY-START(4295385440)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295385440)
            
            static $h = 418144;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590352736),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 418144,
      "h": 8590352736,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590352736)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295385440),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 418144,
      "h": 4295385440,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295385440)
  ],
  "h": 418144
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(418144)
        
        

        //--TRIMMABLE-BOUNDARY-START(680288)
        $asm.$cls(`$Vfzz.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295647584)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295647584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295647584)
            
            //--TRIMMABLE-BOUNDARY-START(4295647584)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295647584)
            
            static $h = 680288;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295647584),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 680288,
      "h": 4295647584,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295647584)
  ],
  "h": 680288
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(680288)
        
        

        //--TRIMMABLE-BOUNDARY-START(745824)
        $asm.$cls(`$Vfzz.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295713120)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295713120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295713120)
            
            //--TRIMMABLE-BOUNDARY-START(4295713120)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295713120)
            
            static $h = 745824;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295713120),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 745824,
      "h": 4295713120,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295713120)
  ],
  "h": 745824,
  "a": [
    {
      "t": 680288,
      "c": 4295647584
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(745824)
        
        

        //--TRIMMABLE-BOUNDARY-START(90464)
        $asm.$cls(`$Vfzz.LCCNC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590025056)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590025056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590025056)
            
            //--TRIMMABLE-BOUNDARY-START(4295057760)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295057760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295057760)
            
            //--TRIMMABLE-BOUNDARY-START(4295057760)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295057760)
            
            static $h = 90464;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590025056),
    {
      "r": 65537,
      "n": "Execute",
      "d": 90464,
      "h": 8590025056,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590025056)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295057760),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 90464,
      "h": 4295057760,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295057760)
  ],
  "h": 90464
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(90464)
        
        

        //--TRIMMABLE-BOUNDARY-START(549216)
        $asm.$cls(`$Vfzz.LCCNCS.CommunityNairalandForumFeedProvider`, ($self) => class CommunityNairalandForumFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295516512)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295516512);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295516512)
            
            //--TRIMMABLE-BOUNDARY-START(8590483808)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityNairalandForumDiscussionModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590483808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`created an article`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590483808)
            
            static $h = 549216;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590483808),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 469626
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 549216,
      "h": 8590483808,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590483808)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295516512),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 549216,
      "h": 4295516512,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295516512)
  ],
  "h": 549216
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Client.Services.CommunityNairalandForumFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Client${separator}Services${separator}CommunityNairalandForumFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(549216)
        
        

        //--TRIMMABLE-BOUNDARY-START(352608)
        $asm.$cls(`$Vfzz.LCCNCP.CommunityNairalandForumApp`, ($self) => class CommunityNairalandForumApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(98784600416)
            /*CommunityNairalandForumService*/ NairalandForumService = null;
            //--TRIMMABLE-BOUNDARY-END(98784600416)
            
            //--TRIMMABLE-BOUNDARY-START(94489633120)
            /*CommunityNairalandForumApplication*/ NairalandForumApplication = null;
            //--TRIMMABLE-BOUNDARY-END(94489633120)
            
            //--TRIMMABLE-BOUNDARY-START(17180221792)
            /*ICommunityClientApplication */ get Application()
            {
                return this.NairalandForumApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(17180221792)
            
            //--TRIMMABLE-BOUNDARY-START(141734273376)
            /*UseDefaultPage */ get UsePage()
            {
                return 65535/*UseDefaultPage.Default*/ & ~4/*UseDefaultPage.CategoriesView*/ & ~1024/*UseDefaultPage.Profile*/ & ~64/*UseDefaultPage.EditCategory*/ & ~16/*UseDefaultPage.EditPost*/ & ~32/*UseDefaultPage.EditPostButton*/ & ~128/*UseDefaultPage.EditCategoryButton*/;
            }
            //--TRIMMABLE-BOUNDARY-END(141734273376)
            
            //--TRIMMABLE-BOUNDARY-START(115964469600)
            /*bool*/ readMore = false;
            //--TRIMMABLE-BOUNDARY-END(115964469600)
            
            //--TRIMMABLE-BOUNDARY-START(120259436896)
            /*void */ ReadMore()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259436896);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.readMore = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259436896)
            
            //--TRIMMABLE-BOUNDARY-START(103079567712)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079567712);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    _ = this.Assets$1.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResolvePath("LivingThing.Core.Community.NairalandForum.Client.Blazor.css", true, false, false) ], null, null));
                    ($t1 = this.NairalandForumService.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103079567712)
            
            //--TRIMMABLE-BOUNDARY-START(107374535008)
            /*string */ get OptimizedComponentName()
            {
                return "communitynairalandforumapp communitydefaultpages";
            }
            //--TRIMMABLE-BOUNDARY-END(107374535008)
            
            //--TRIMMABLE-BOUNDARY-START(90194665824)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194665824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.NairalandForumService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Vfzz.LCCNCS.CommunityNairalandForumService, serviceProvider);
                this.NairalandForumApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Vfzz.LCCNCS.CommunityNairalandForumApplication, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(90194665824)
            
            //--TRIMMABLE-BOUNDARY-START(21475189088)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475189088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
                __builder.AddMarkupContent(1, "\r\n");
                __builder.AddMarkupContent(2, "<div class=\"pos-abs z-10 b-0 l-0 bg-dark pd-1\">Powered from <a class=\"lt cl-primary\" href=\"https://www.nairaland.com/\">nairaland.com</a></div>");
            }
            //--TRIMMABLE-BOUNDARY-END(21475189088)
            
            //--TRIMMABLE-BOUNDARY-START(85899698528)
            /*RenderFragment */ get Home()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(3, "div");
                    __builder2.AddAttribute$5(4, "class", "bg-error-01 mgt pd");
                    __builder2.AddMarkupContent(5, "<p class=\"mgt-0\">\r\n            Hello. Welcome to Zoey Nairaland Presenter.\r\n        </p>\r\n        ");
                    __builder2.OpenElement(6, "p");
                    __builder2.AddMarkupContent(7, "\r\n            While Zoey has its own Zoey Forum system built on modern principles and technologies,\r\n            we felt there is already a lot of content on Nairaland and Nairaland upgrade to modern UI is way long overdue.\r\n            Request for this has been made by the community for years and yet not done...\r\n");
                    if (!this.readMore)
                    {
                        __builder2.OpenElement(8, "a");
                        __builder2.AddAttribute$5(9, "class", "f-right");
                        __builder2.AddAttribute$5(10, "target", "_blank");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 11, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ReadMore)));
                        __builder2.AddContent$4(12, "more");
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    if (this.readMore)
                    {
                        __builder2.AddMarkupContent(13, "<p>\r\n                Zoey Nairaland is an effort to apply Zoey's own modern UI system to Nairaland,\r\n                making it easier for you to read what you love on Nairaland.\r\n            </p>\r\n            ");
                        __builder2.AddMarkupContent(14, "<p>\r\n                For now Zoey Nairaland is readonly and content that users create on Nairaland will appear on Zoey for reading.\r\n                There could be a time gap of about 5 minutes for new contents on Nairaland to appear on Zoey.\r\n            </p>\r\n            ");
                        __builder2.AddMarkupContent(15, "<p>\r\n                You might encounter some issues(after all it was all slapped together in some 6 hours), but we will keep improving this application to make it a better Nairaland presentation.\r\n            </p>\r\n            ");
                        __builder2.AddMarkupContent(16, "<p class=\"mgb-0\"><b>\r\n                    DISCLAIMER: Zoey Nairaland has no affiliate with the original Nairaland.\r\n                </b></p>");
                    }
                    __builder2.CloseElement();
                }, $dMrBgi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":352608,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(85899698528)
            
            //--TRIMMABLE-BOUNDARY-START(111669502304)
            /*RenderFragment */ get PrependPages()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(17, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), 18);
                    __builder2.AddComponentParameter(19, "Name", "Post");
                    __builder2.AddComponentParameter(20, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Post/" + $.$strNN("***"/*RoutePath.OneOrMorePathSegment*/))));
                    __builder2.AddComponentParameter(21, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~12/*CommunityLayoutFeatures.PadX*/, null, null, true);
                    }), $qLjpud ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel).$h}],"n":"","d":352608,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(22, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            /*int*/ let i = 0;
                            __builder3.OpenComponent$1($.$hDPm.LCFCCR$1.RemoteDataDetail$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel), 23);
                            __builder3.AddComponentParameter(24, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$12(new $.$fPer.LCFCD.DataId().$ctor$3(context.Data.LCFCS$IApplicationPageContext$RouteMatch.Variable, null))));
                            __builder3.AddAttribute$3(25, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel)))().$ctor(this, ( (/*thread*/ thread) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$ahDc.LCCCST$1.CommunityThreadPage$$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel), 26);
                                    __builder4.AddComponentParameter(27, "Filter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$12(new $.$fPer.LCFCD.DataId().$ctor$3(context.Data.LCFCS$IApplicationPageContext$RouteMatch.Variable, null))));
                                    __builder4.AddComponentParameter(28, "Thread", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, thread.Data));
                                    __builder4.CloseComponent();
                                }, $uJzaLk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":352608,"h":0,"f":17825794});
                            }), $OVUaRh ??= {"r":6881395,"p":[{"n":"thread","p":$.$hDPm.LCFCI.ContainerContext$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel).$h}],"n":"","d":352608,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $dPMaIg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":352608,"h":0,"f":17825794});
                    }), $izWFqh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel)).$h}],"n":"","d":352608,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(29, "\r\n    ");
                }, $XUsbgf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":352608,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(111669502304)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885254496)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885254496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885254496)
            
            //--TRIMMABLE-BOUNDARY-START(12885254496)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12885254496)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(98784600416)
                this.NairalandForumService = null;
                //--TRIMMABLE-BOUNDARY-END(98784600416)
                
                //--TRIMMABLE-BOUNDARY-START(94489633120)
                this.NairalandForumApplication = null;
                //--TRIMMABLE-BOUNDARY-END(94489633120)
                
            }
            static $h = 352608;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98784600416),
    {
      "p": 614752,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834927456,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439306080,
        "f": 83886081
      },
      "n": "NairalandForumService",
      "d": 352608,
      "h": 98784600416,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98784600416),
//--TRIMMABLE-BOUNDARY-START(94489633120),
    {
      "p": 483680,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244992864,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849371488,
        "f": 83886081
      },
      "n": "NairalandForumApplication",
      "d": 352608,
      "h": 94489633120,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94489633120),
//--TRIMMABLE-BOUNDARY-START(17180221792),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065123680,
        "f": 50364420
      },
      "n": "Application",
      "d": 352608,
      "h": 17180221792,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(17180221792),
//--TRIMMABLE-BOUNDARY-START(141734273376),
    {
      "p": 34379200,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604731232,
        "f": 50364420
      },
      "n": "UsePage",
      "d": 352608,
      "h": 141734273376,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(141734273376),
//--TRIMMABLE-BOUNDARY-START(107374535008),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424862048,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 352608,
      "h": 107374535008,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107374535008),
//--TRIMMABLE-BOUNDARY-START(85899698528),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655058272,
        "f": 50364420
      },
      "n": "Home",
      "d": 352608,
      "h": 85899698528,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(85899698528),
//--TRIMMABLE-BOUNDARY-START(111669502304),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014796640,
        "f": 50364420
      },
      "n": "PrependPages",
      "d": 352608,
      "h": 111669502304,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(111669502304)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(120259436896),
    {
      "r": 65537,
      "n": "ReadMore",
      "d": 352608,
      "h": 120259436896,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120259436896),
//--TRIMMABLE-BOUNDARY-START(103079567712),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 352608,
      "h": 103079567712,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(103079567712),
//--TRIMMABLE-BOUNDARY-START(90194665824),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 352608,
      "h": 90194665824,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90194665824),
//--TRIMMABLE-BOUNDARY-START(21475189088),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 352608,
      "h": 21475189088,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475189088)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(115964469600),
    {
      "t": 262145,
      "n": "readMore",
      "d": 352608,
      "h": 115964469600,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(115964469600)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885254496),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 352608,
      "h": 12885254496,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885254496)
  ],
  "h": 352608,
  "a": [
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Nairaland/{*PageRoute}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Client.Pages.CommunityNairalandForumApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Client${separator}Pages${separator}CommunityNairalandForumApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(352608)
        
        

        //--TRIMMABLE-BOUNDARY-START(483680)
        $asm.$cls(`$Vfzz.LCCNCS.CommunityNairalandForumApplication`, ($self) => class CommunityNairalandForumApplication extends $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(12885385568)
            $ctor$3(/*CommunityNairalandForumService*/ service)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885385568);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885385568)
            
            //--TRIMMABLE-BOUNDARY-START(137439437152)
            /*string */ get Name()
            {
                return "Nairaland";
            }
            //--TRIMMABLE-BOUNDARY-END(137439437152)
            
            //--TRIMMABLE-BOUNDARY-START(158914273632)
            /*string */ get Title()
            {
                return "Nairaland";
            }
            //--TRIMMABLE-BOUNDARY-END(158914273632)
            
            //--TRIMMABLE-BOUNDARY-START(21475320160)
            /*string */ get Description()
            {
                return "This application attempts to redesign the original Nairaland Forum UI, making it intuitive and easier to read.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475320160)
            
            //--TRIMMABLE-BOUNDARY-START(133144469856)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-package"/*MaterialDesignIconNames.Package*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144469856)
            
            //--TRIMMABLE-BOUNDARY-START(154619306336)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2E962B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619306336)
            
            //--TRIMMABLE-BOUNDARY-START(30065254752)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 97/*ApplicationServiceFeatures.DefaultInDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065254752)
            
            //--TRIMMABLE-BOUNDARY-START(17180352864)
            /*Type? */ get ApplicationViewType()
            {
                return $.$Vfzz.LCCNCP.CommunityNairalandForumApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180352864)
            
            //--TRIMMABLE-BOUNDARY-START(128849502560)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849502560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$Vfzz.LCCNCP.CommunityNairalandForumApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849502560)
            
            //--TRIMMABLE-BOUNDARY-START(25770287456)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770287456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770287456)
            
            //--TRIMMABLE-BOUNDARY-START(146029371744)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029371744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029371744)
            
            //--TRIMMABLE-BOUNDARY-START(141734404448)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734404448)
            
            //--TRIMMABLE-BOUNDARY-START(4295450976)
            /*CommunityNairalandForumService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295450976)
            
            //--TRIMMABLE-BOUNDARY-START(150324339040)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(150324339040)
            
            //--TRIMMABLE-BOUNDARY-START(163209240928)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(6912/*PostTypes.Nairaland*/, 6916/*PostTypes.NairalandEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209240928)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 483680;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439437152),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604862304,
        "f": 50364417
      },
      "n": "Name",
      "d": 483680,
      "h": 137439437152,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439437152),
//--TRIMMABLE-BOUNDARY-START(158914273632),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964600672,
        "f": 50364417
      },
      "n": "Title",
      "d": 483680,
      "h": 158914273632,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914273632),
//--TRIMMABLE-BOUNDARY-START(21475320160),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835058528,
        "f": 50364417
      },
      "n": "Description",
      "d": 483680,
      "h": 21475320160,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475320160),
//--TRIMMABLE-BOUNDARY-START(133144469856),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014927712,
        "f": 50364417
      },
      "n": "Icon",
      "d": 483680,
      "h": 133144469856,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144469856),
//--TRIMMABLE-BOUNDARY-START(154619306336),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374666080,
        "f": 50364417
      },
      "n": "Theme",
      "d": 483680,
      "h": 154619306336,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619306336),
//--TRIMMABLE-BOUNDARY-START(30065254752),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424993120,
        "f": 50364417
      },
      "n": "Features",
      "d": 483680,
      "h": 30065254752,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065254752),
//--TRIMMABLE-BOUNDARY-START(17180352864),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245123936,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 483680,
      "h": 17180352864,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180352864),
//--TRIMMABLE-BOUNDARY-START(141734404448),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194796896,
        "f": 50364417
      },
      "n": "Order",
      "d": 483680,
      "h": 141734404448,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734404448),
//--TRIMMABLE-BOUNDARY-START(4295450976),
    {
      "p": 614752,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655189344,
        "f": 50331650
      },
      "n": "_Service",
      "d": 483680,
      "h": 4295450976,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295450976),
//--TRIMMABLE-BOUNDARY-START(150324339040),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784731488,
        "f": 50364417
      },
      "n": "Service",
      "d": 483680,
      "h": 150324339040,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324339040),
//--TRIMMABLE-BOUNDARY-START(163209240928),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554535264,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 483680,
      "h": 163209240928,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209240928)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849502560),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 483680,
      "h": 128849502560,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849502560),
//--TRIMMABLE-BOUNDARY-START(25770287456),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 483680,
      "h": 25770287456,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770287456),
//--TRIMMABLE-BOUNDARY-START(146029371744),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 483680,
      "h": 146029371744,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029371744)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885385568),
    {
      "p": [
        {
          "n": "service",
          "p": 614752
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 483680,
      "h": 12885385568,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885385568)
  ],
  "h": 483680
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel, $.$hkBT.LCCNCM.CommunityNairalandForumSearchModel), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Client.Services.CommunityNairalandForumApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Client${separator}Services${separator}CommunityNairalandForumApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(483680)
        
        

        //--TRIMMABLE-BOUNDARY-START(614752)
        $asm.$cls(`$Vfzz.LCCNCS.CommunityNairalandForumService`, ($self) => class CommunityNairalandForumService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295582048)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295582048);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295582048)
            
            //--TRIMMABLE-BOUNDARY-START(17180483936)
            /*bool */ get LoadCategories()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180483936)
            
            static $h = 614752;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180483936),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885516640,
        "f": 50364417
      },
      "n": "LoadCategories",
      "d": 614752,
      "h": 17180483936,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180483936)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295582048),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 614752,
      "h": 4295582048,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295582048)
  ],
  "h": 614752
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Client.Services.CommunityNairalandForumService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Client${separator}Services${separator}CommunityNairalandForumService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(614752)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.NairalandForum.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(24928)
