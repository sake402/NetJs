
//--TRIMMABLE-BOUNDARY-START(10874)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $STxRRa;
    let $fqdebd;
    let $BpgpJi;
    let $GygpKj;
    let $qQFonh;
    let $Hwtiuh;
    let $zXKsYg;
    let $iBmLqj;
    let $KOOKBb;
    let $aDlida;
    let $XwQpwi;
    let $beLyBf;
    let $HVBmlj;
    let $KXzOFg;
    let $iLevwk;
    let $cBfYig;
    let $dQvJGa;
    let $aIOYfb;
    let $SOhlKk;
    let $VSFkSj;
    let $SnTuRc;
    let $RYORYe;
    let $kjfTsk;
    let $ExlqUj;
    let $KeBfoi;
    let $KmDnbe;
    let $BkZDjf;
    let $dVJmwh;
    let $xFmDBf;
    let $oLiwVj;
    let $OjoHck;
    let $Wtlwfc;
    let $RLaEHc;
    let $Skzdfg;
    let $zYtrLf;
    let $aPGghc;
    let $GAONVh;
    let $djNQOc;
    let $dakVxe;
    let $tePYif;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.NairalandForum.Common", 
    {
  "h": 10874,
  "f": "LivingThing.Core.Community.NairalandForum.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.NairalandForum.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.NairalandForum.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2370170)
        $asm.$cls(`$hkBT.LCCNCS$2.CommunityNairalandForumStatesCustomAttributesProvider`, ($self) => class CommunityNairalandForumStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297337466)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297337466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297337466)
            
            static $h = 2370170;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297337466),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2370170,
      "h": 4297337466,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297337466)
  ],
  "h": 2370170
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.States.CommunityNairalandForumStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}States${separator}CommunityNairalandForumStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2370170)
        
        

        //--TRIMMABLE-BOUNDARY-START(2108026)
        $asm.$cls(`$hkBT.LCCNCS$1.CommunityNairalandForumSettingsCustomAttributesProvider`, ($self) => class CommunityNairalandForumSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297075322)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297075322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297075322)
            
            static $h = 2108026;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297075322),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2108026,
      "h": 4297075322,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297075322)
  ],
  "h": 2108026
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Settings.CommunityNairalandForumSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Settings${separator}CommunityNairalandForumSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2108026)
        
        

        //--TRIMMABLE-BOUNDARY-START(797306)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumModelCustomAttributesProvider`, ($self) => class CommunityNairalandForumModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295764602)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295764602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$hkBT.LCCNCS$1.CommunityNairalandForumSettings, $.$hkBT.LCCNCS$2.CommunityNairalandForumStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295764602)
            
            static $h = 797306;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295764602),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 797306,
      "h": 4295764602,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295764602)
  ],
  "h": 797306
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(797306)
        
        

        //--TRIMMABLE-BOUNDARY-START(2566778)
        $asm.$cls(`$hkBT.LCCNC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297534074)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297534074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModelTypeDescriptorBuilder.Register();
                $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelTypeDescriptorBuilder.Register();
                $.$hkBT.LCCNCM.CommunityNairalandForumModelTypeDescriptorBuilder.Register();
                $.$hkBT.LCCNCM.CommunityNairalandForumPostModelTypeDescriptorBuilder.Register();
                $.$hkBT.LCCNCM.CommunityNairalandForumSearchModelTypeDescriptorBuilder.Register();
                $.$hkBT.LCCNCS$1.CommunityNairalandForumSettingsTypeDescriptorBuilder.Register();
                $.$hkBT.LCCNCS$2.CommunityNairalandForumStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297534074)
            
            static $h = 2566778;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297534074),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2566778,
      "h": 4297534074,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297534074)
  ],
  "h": 2566778
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2566778)
        
        

        //--TRIMMABLE-BOUNDARY-START(2501242)
        $asm.$cls(`$hkBT.LCCNCS$2.CommunityNairalandForumStatesTypeDescriptorBuilder`, ($self) => class CommunityNairalandForumStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592435834)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592435834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hkBT.LCCNCS$2.CommunityNairalandForumStatesTypeDescriptor()
                        const $t1 = $.$hkBT.LCCNCS$2.CommunityNairalandForumStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.NairalandForum.Common.States.CommunityNairalandForumStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Hwtiuh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2501242,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hkBT.LCCNCS$2.CommunityNairalandForumStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592435834)
            
            //--TRIMMABLE-BOUNDARY-START(4297468538)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297468538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297468538)
            
            //--TRIMMABLE-BOUNDARY-START(4297468538)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297468538)
            
            static $h = 2501242;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592435834),
    {
      "r": 65537,
      "n": "Register",
      "d": 2501242,
      "h": 8592435834,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592435834)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297468538),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2501242,
      "h": 4297468538,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297468538)
  ],
  "h": 2501242
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.States.CommunityNairalandForumStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}States${separator}CommunityNairalandForumStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2501242)
        
        

        //--TRIMMABLE-BOUNDARY-START(1059450)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumPostModelCustomAttributesProvider`, ($self) => class CommunityNairalandForumPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296026746)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296026746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296026746)
            
            static $h = 1059450;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296026746),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1059450,
      "h": 4296026746,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296026746)
  ],
  "h": 1059450
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1059450)
        
        

        //--TRIMMABLE-BOUNDARY-START(2239098)
        $asm.$cls(`$hkBT.LCCNCS$1.CommunityNairalandForumSettingsTypeDescriptorBuilder`, ($self) => class CommunityNairalandForumSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592173690)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592173690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hkBT.LCCNCS$1.CommunityNairalandForumSettingsTypeDescriptor()
                        const $t1 = $.$hkBT.LCCNCS$1.CommunityNairalandForumSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.NairalandForum.Common.Settings.CommunityNairalandForumSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $GygpKj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2239098,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hkBT.LCCNCS$1.CommunityNairalandForumSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592173690)
            
            //--TRIMMABLE-BOUNDARY-START(4297206394)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297206394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297206394)
            
            //--TRIMMABLE-BOUNDARY-START(4297206394)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297206394)
            
            static $h = 2239098;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592173690),
    {
      "r": 65537,
      "n": "Register",
      "d": 2239098,
      "h": 8592173690,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592173690)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297206394),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2239098,
      "h": 4297206394,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297206394)
  ],
  "h": 2239098
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Settings.CommunityNairalandForumSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Settings${separator}CommunityNairalandForumSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2239098)
        
        

        //--TRIMMABLE-BOUNDARY-START(1387130)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumSearchModelCustomAttributesProvider`, ($self) => class CommunityNairalandForumSearchModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296354426)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296354426)
            
            //--TRIMMABLE-BOUNDARY-START(8591321722)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591321722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$hkBT.LCCNCM.CommunityNairalandForumSearchModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Category", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.InputType = $.$cast(21n, $.$fPer.LCFC.InputType);
                            $i3.OptionsReader = ($.$hkBT.LCCNCM.CommunityNairalandForumSearchCategoryProvider.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$hkBT.LCCNCM.CommunityNairalandForumSearchModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $fqdebd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1387130,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $BpgpJi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1387130,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591321722)
            
            static $h = 1387130;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591321722),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1387130,
      "h": 8591321722,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591321722)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296354426),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1387130,
      "h": 4296354426,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296354426)
  ],
  "h": 1387130
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumSearchModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumSearchModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1387130)
        
        

        //--TRIMMABLE-BOUNDARY-START(76410)
        $asm.$cls(`$hkBT.LCCNC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295043706)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295043706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModelCustomAttributesProvider, $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelCustomAttributesProvider, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hkBT.LCCNCM.CommunityNairalandForumModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumModelCustomAttributesProvider, $.$hkBT.LCCNCM.CommunityNairalandForumModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hkBT.LCCNCM.CommunityNairalandForumPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumPostModelCustomAttributesProvider, $.$hkBT.LCCNCM.CommunityNairalandForumPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hkBT.LCCNCM.CommunityNairalandForumSearchModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumSearchModelCustomAttributesProvider, $.$hkBT.LCCNCM.CommunityNairalandForumSearchModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hkBT.LCCNCS$1.CommunityNairalandForumSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hkBT.LCCNCS$1.CommunityNairalandForumSettingsCustomAttributesProvider, $.$hkBT.LCCNCS$1.CommunityNairalandForumSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hkBT.LCCNCS$2.CommunityNairalandForumStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hkBT.LCCNCS$2.CommunityNairalandForumStatesCustomAttributesProvider, $.$hkBT.LCCNCS$2.CommunityNairalandForumStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295043706)
            
            static $h = 76410;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295043706),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 76410,
      "h": 4295043706,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295043706)
  ],
  "h": 76410
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(76410)
        
        

        //--TRIMMABLE-BOUNDARY-START(928378)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumModelTypeDescriptorBuilder`, ($self) => class CommunityNairalandForumModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590862970)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590862970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumModelTypeDescriptor()
                        const $t1 = $.$hkBT.LCCNCM.CommunityNairalandForumModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iBmLqj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":928378,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hkBT.LCCNCM.CommunityNairalandForumModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590862970)
            
            //--TRIMMABLE-BOUNDARY-START(4295895674)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295895674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295895674)
            
            //--TRIMMABLE-BOUNDARY-START(4295895674)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295895674)
            
            static $h = 928378;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590862970),
    {
      "r": 65537,
      "n": "Register",
      "d": 928378,
      "h": 8590862970,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590862970)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295895674),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 928378,
      "h": 4295895674,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295895674)
  ],
  "h": 928378
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(928378)
        
        

        //--TRIMMABLE-BOUNDARY-START(535162)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelCustomAttributesProvider`, ($self) => class CommunityNairalandForumDiscussionModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295502458)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295502458)
            
            //--TRIMMABLE-BOUNDARY-START(8590469754)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590469754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("IsThread", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $aDlida ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":535162,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $XwQpwi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":535162,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590469754)
            
            static $h = 535162;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590469754),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 535162,
      "h": 8590469754,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590469754)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295502458),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 535162,
      "h": 4295502458,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295502458)
  ],
  "h": 535162
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumDiscussionModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(535162)
        
        

        //--TRIMMABLE-BOUNDARY-START(1321594)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumSearchModel`, ($self) => class CommunityNairalandForumSearchModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886223482)
            /*int*/ Category = 0;
            //--TRIMMABLE-BOUNDARY-END(12886223482)
            
            //--TRIMMABLE-BOUNDARY-START(25771125370)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771125370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.Int32.GetHashCode.call(this.Category);
            }
            //--TRIMMABLE-BOUNDARY-END(25771125370)
            
            //--TRIMMABLE-BOUNDARY-START(8591256186)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591256186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591256186)
            
            //--TRIMMABLE-BOUNDARY-START(8591256186)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591256186)
            
            static $h = 1321594;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886223482),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476158074,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34361059962,
        "f": 83886081
      },
      "n": "Category",
      "d": 1321594,
      "h": 12886223482,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 21,
              "t": 47614294
            },
            {
              "n": "OptionsReader",
              "v": 1256058,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886223482)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771125370),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1321594,
      "h": 25771125370,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771125370)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591256186),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1321594,
      "h": 8591256186,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591256186)
  ],
  "h": 1321594
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumSearchModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumSearchModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1321594)
        
        

        //--TRIMMABLE-BOUNDARY-START(1518202)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumSearchModelTypeDescriptorBuilder`, ($self) => class CommunityNairalandForumSearchModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591452794)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591452794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchModelTypeDescriptor()
                        const $t1 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumSearchModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ExlqUj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1518202,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hkBT.LCCNCM.CommunityNairalandForumSearchModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591452794)
            
            //--TRIMMABLE-BOUNDARY-START(4296485498)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296485498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296485498)
            
            //--TRIMMABLE-BOUNDARY-START(4296485498)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296485498)
            
            static $h = 1518202;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591452794),
    {
      "r": 65537,
      "n": "Register",
      "d": 1518202,
      "h": 8591452794,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591452794)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296485498),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1518202,
      "h": 4296485498,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296485498)
  ],
  "h": 1518202
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumSearchModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumSearchModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1518202)
        
        

        //--TRIMMABLE-BOUNDARY-START(1583738)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumSearchOptions`, ($self) => class CommunityNairalandForumSearchOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55836158586)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(55836158586)
            
            //--TRIMMABLE-BOUNDARY-START(51541191290)
            /*int*/ Key = 0;
            //--TRIMMABLE-BOUNDARY-END(51541191290)
            
            //--TRIMMABLE-BOUNDARY-START(60131125882)
            /*IEnumerable<CommunityNairalandForumSearchOptions>*/ static Options = null;
            //--TRIMMABLE-BOUNDARY-END(60131125882)
            
            //--TRIMMABLE-BOUNDARY-START(21476420218)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476420218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476420218)
            
            //--TRIMMABLE-BOUNDARY-START(21476420218)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21476420218)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55836158586)
                this.Name = "";
                //--TRIMMABLE-BOUNDARY-END(55836158586)
                
            }
            //--TRIMMABLE-BOUNDARY-START(17181452922)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181452922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(60131125882)
                    this.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions), [(() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t1 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Name = "-- All Sections --";
                        $i1.Key = 0;
                        return $i1;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t2 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Name = "Adverts";
                        $i2.Key = 32;
                        return $i2;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t3 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i3 = new $t3();
                        $i3.$ctor$1();
                        $i3.Name = "Agriculture";
                        $i3.Key = 85;
                        return $i3;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t4 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i4 = new $t4();
                        $i4.$ctor$1();
                        $i4.Name = "Art, Graphics & Video";
                        $i4.Key = 45;
                        return $i4;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t5 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i5 = new $t5();
                        $i5.$ctor$1();
                        $i5.Name = "Autos";
                        $i5.Key = 26;
                        return $i5;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t6 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i6 = new $t6();
                        $i6.$ctor$1();
                        $i6.Name = "Business";
                        $i6.Key = 24;
                        return $i6;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t7 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i7 = new $t7();
                        $i7.$ctor$1();
                        $i7.Name = "Business To Business";
                        $i7.Key = 49;
                        return $i7;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t8 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i8 = new $t8();
                        $i8.$ctor$1();
                        $i8.Name = "Car Talk";
                        $i8.Key = 78;
                        return $i8;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t9 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i9 = new $t9();
                        $i9.$ctor$1();
                        $i9.Name = "Career";
                        $i9.Key = 35;
                        return $i9;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t10 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i10 = new $t10();
                        $i10.$ctor$1();
                        $i10.Name = "Celebrities";
                        $i10.Key = 46;
                        return $i10;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t11 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i11 = new $t11();
                        $i11.$ctor$1();
                        $i11.Name = "Certification And Training Adverts";
                        $i11.Key = 62;
                        return $i11;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t12 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i12 = new $t12();
                        $i12.$ctor$1();
                        $i12.Name = "Computer Market";
                        $i12.Key = 74;
                        return $i12;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t13 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i13 = new $t13();
                        $i13.$ctor$1();
                        $i13.Name = "Computers";
                        $i13.Key = 22;
                        return $i13;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t14 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i14 = new $t14();
                        $i14.$ctor$1();
                        $i14.Name = "Crime";
                        $i14.Key = 1;
                        return $i14;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t15 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i15 = new $t15();
                        $i15.$ctor$1();
                        $i15.Name = "Culture";
                        $i15.Key = 55;
                        return $i15;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t16 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i16 = new $t16();
                        $i16.$ctor$1();
                        $i16.Name = "Dating And Meet-up Zone";
                        $i16.Key = 38;
                        return $i16;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t17 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i17 = new $t17();
                        $i17.$ctor$1();
                        $i17.Name = "Diaries";
                        $i17.Key = 31;
                        return $i17;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t18 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i18 = new $t18();
                        $i18.$ctor$1();
                        $i18.Name = "Education";
                        $i18.Key = 13;
                        return $i18;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t19 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i19 = new $t19();
                        $i19.$ctor$1();
                        $i19.Name = "Educational Services";
                        $i19.Key = 57;
                        return $i19;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t20 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i20 = new $t20();
                        $i20.$ctor$1();
                        $i20.Name = "Entertainment";
                        $i20.Key = 12;
                        return $i20;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t21 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i21 = new $t21();
                        $i21.$ctor$1();
                        $i21.Name = "Ethnic, Racial, Or Sectarian Politics";
                        $i21.Key = 40;
                        return $i21;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t22 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i22 = new $t22();
                        $i22.$ctor$1();
                        $i22.Name = "European Football (EPL, UEFA, La Liga)";
                        $i22.Key = 66;
                        return $i22;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t23 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i23 = new $t23();
                        $i23.$ctor$1();
                        $i23.Name = "Events";
                        $i23.Key = 7;
                        return $i23;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t24 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i24 = new $t24();
                        $i24.$ctor$1();
                        $i24.Name = "Family";
                        $i24.Key = 5;
                        return $i24;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t25 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i25 = new $t25();
                        $i25.$ctor$1();
                        $i25.Name = "Fashion";
                        $i25.Key = 37;
                        return $i25;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t26 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i26 = new $t26();
                        $i26.$ctor$1();
                        $i26.Name = "Fashion/Clothing Market";
                        $i26.Key = 39;
                        return $i26;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t27 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i27 = new $t27();
                        $i27.$ctor$1();
                        $i27.Name = "Food";
                        $i27.Key = 41;
                        return $i27;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t28 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i28 = new $t28();
                        $i28.$ctor$1();
                        $i28.Name = "Foreign Affairs";
                        $i28.Key = 61;
                        return $i28;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t29 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i29 = new $t29();
                        $i29.$ctor$1();
                        $i29.Name = "Forum Games";
                        $i29.Key = 33;
                        return $i29;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t30 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i30 = new $t30();
                        $i30.$ctor$1();
                        $i30.Name = "Gaming";
                        $i30.Key = 10;
                        return $i30;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t31 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i31 = new $t31();
                        $i31.$ctor$1();
                        $i31.Name = "Graphics/Video Market";
                        $i31.Key = 51;
                        return $i31;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t32 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i32 = new $t32();
                        $i32.$ctor$1();
                        $i32.Name = "Health";
                        $i32.Key = 19;
                        return $i32;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t33 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i33 = new $t33();
                        $i33.$ctor$1();
                        $i33.Name = "Home Page";
                        $i33.Key = 23;
                        return $i33;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t34 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i34 = new $t34();
                        $i34.$ctor$1();
                        $i34.Name = "Investment";
                        $i34.Key = 81;
                        return $i34;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t35 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i35 = new $t35();
                        $i35.$ctor$1();
                        $i35.Name = "Investment Ads";
                        $i35.Key = 82;
                        return $i35;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t36 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i36 = new $t36();
                        $i36.$ctor$1();
                        $i36.Name = "Islam for Muslims";
                        $i36.Key = 44;
                        return $i36;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t37 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i37 = new $t37();
                        $i37.$ctor$1();
                        $i37.Name = "Jobs/Vacancies";
                        $i37.Key = 29;
                        return $i37;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t38 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i38 = new $t38();
                        $i38.$ctor$1();
                        $i38.Name = "Jokes Etc";
                        $i38.Key = 15;
                        return $i38;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t39 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i39 = new $t39();
                        $i39.$ctor$1();
                        $i39.Name = "Literature";
                        $i39.Key = 11;
                        return $i39;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t40 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i40 = new $t40();
                        $i40.$ctor$1();
                        $i40.Name = "Literature/Writing Ads";
                        $i40.Key = 42;
                        return $i40;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t41 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i41 = new $t41();
                        $i41.$ctor$1();
                        $i41.Name = "Moderators";
                        $i41.Key = 65;
                        return $i41;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t42 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i42 = new $t42();
                        $i42.$ctor$1();
                        $i42.Name = "Music Business";
                        $i42.Key = 59;
                        return $i42;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t43 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i43 = new $t43();
                        $i43.$ctor$1();
                        $i43.Name = "Music/Radio";
                        $i43.Key = 3;
                        return $i43;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t44 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i44 = new $t44();
                        $i44.$ctor$1();
                        $i44.Name = "Nairaland / General";
                        $i44.Key = 9;
                        return $i44;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t45 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i45 = new $t45();
                        $i45.$ctor$1();
                        $i45.Name = "Nairaland Ads";
                        $i45.Key = 80;
                        return $i45;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t46 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i46 = new $t46();
                        $i46.$ctor$1();
                        $i46.Name = "NYSC";
                        $i46.Key = 79;
                        return $i46;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t47 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i47 = new $t47();
                        $i47.$ctor$1();
                        $i47.Name = "Pets";
                        $i47.Key = 84;
                        return $i47;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t48 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i48 = new $t48();
                        $i48.$ctor$1();
                        $i48.Name = "Phone/Internet Market";
                        $i48.Key = 75;
                        return $i48;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t49 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i49 = new $t49();
                        $i49.$ctor$1();
                        $i49.Name = "Phones";
                        $i49.Key = 16;
                        return $i49;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t50 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i50 = new $t50();
                        $i50.$ctor$1();
                        $i50.Name = "Poems For Review";
                        $i50.Key = 36;
                        return $i50;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t51 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i51 = new $t51();
                        $i51.$ctor$1();
                        $i51.Name = "Politics";
                        $i51.Key = 20;
                        return $i51;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t52 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i52 = new $t52();
                        $i52.$ctor$1();
                        $i52.Name = "Programming";
                        $i52.Key = 34;
                        return $i52;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t53 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i53 = new $t53();
                        $i53.$ctor$1();
                        $i53.Name = "Properties";
                        $i53.Key = 47;
                        return $i53;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t54 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i54 = new $t54();
                        $i54.$ctor$1();
                        $i54.Name = "Rap Battles";
                        $i54.Key = 60;
                        return $i54;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t55 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i55 = new $t55();
                        $i55.$ctor$1();
                        $i55.Name = "Recycle Bin";
                        $i55.Key = 53;
                        return $i55;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t56 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i56 = new $t56();
                        $i56.$ctor$1();
                        $i56.Name = "Religion";
                        $i56.Key = 17;
                        return $i56;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t57 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i57 = new $t57();
                        $i57.$ctor$1();
                        $i57.Name = "Romance";
                        $i57.Key = 21;
                        return $i57;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t58 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i58 = new $t58();
                        $i58.$ctor$1();
                        $i58.Name = "Satellite TV Technology";
                        $i58.Key = 58;
                        return $i58;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t59 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i59 = new $t59();
                        $i59.$ctor$1();
                        $i59.Name = "Science/Technology";
                        $i59.Key = 8;
                        return $i59;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t60 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i60 = new $t60();
                        $i60.$ctor$1();
                        $i60.Name = "Sexuality";
                        $i60.Key = 28;
                        return $i60;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t61 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i61 = new $t61();
                        $i61.$ctor$1();
                        $i61.Name = "Software/Programmer Market";
                        $i61.Key = 76;
                        return $i61;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t62 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i62 = new $t62();
                        $i62.$ctor$1();
                        $i62.Name = "Sports";
                        $i62.Key = 14;
                        return $i62;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t63 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i63 = new $t63();
                        $i63.$ctor$1();
                        $i63.Name = "Technology Market";
                        $i63.Key = 54;
                        return $i63;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t64 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i64 = new $t64();
                        $i64.$ctor$1();
                        $i64.Name = "Top Pages";
                        $i64.Key = 83;
                        return $i64;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t65 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i65 = new $t65();
                        $i65.$ctor$1();
                        $i65.Name = "Travel";
                        $i65.Key = 2;
                        return $i65;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t66 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i66 = new $t66();
                        $i66.$ctor$1();
                        $i66.Name = "Travel Ads";
                        $i66.Key = 77;
                        return $i66;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t67 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i67 = new $t67();
                        $i67.$ctor$1();
                        $i67.Name = "TV/Movies";
                        $i67.Key = 4;
                        return $i67;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t68 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i68 = new $t68();
                        $i68.$ctor$1();
                        $i68.Name = "Video Games And Gadgets For Sale";
                        $i68.Key = 71;
                        return $i68;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t69 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i69 = new $t69();
                        $i69.$ctor$1();
                        $i69.Name = "Web Market";
                        $i69.Key = 52;
                        return $i69;
                    })(), (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions()
                        const $t70 = $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions;
                        const $i70 = new $t70();
                        $i70.$ctor$1();
                        $i70.Name = "Webmasters";
                        $i70.Key = 30;
                        return $i70;
                    })()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(60131125882)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181452922)
            
            static $h = 1583738;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836158586),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656289402,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310995066,
        "f": 83886081
      },
      "n": "Name",
      "d": 1583738,
      "h": 55836158586,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836158586),
//--TRIMMABLE-BOUNDARY-START(51541191290),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066354810,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68721060474,
        "f": 83886081
      },
      "n": "Key",
      "d": 1583738,
      "h": 51541191290,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541191290),
//--TRIMMABLE-BOUNDARY-START(60131125882),
    {
      "p": $.$$.SCG.IEnumerable$$($.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246223994,
        "f": 50331681
      },
      "n": "Options",
      "d": 1583738,
      "h": 60131125882,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(60131125882)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476420218),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1583738,
      "h": 21476420218,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476420218)
  ],
  "h": 1583738
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumSearchOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumSearchOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1583738)
        
        

        //--TRIMMABLE-BOUNDARY-START(1190522)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumPostModelTypeDescriptorBuilder`, ($self) => class CommunityNairalandForumPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591125114)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591125114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumPostModelTypeDescriptor()
                        const $t1 = $.$hkBT.LCCNCM.CommunityNairalandForumPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dVJmwh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1190522,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hkBT.LCCNCM.CommunityNairalandForumPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591125114)
            
            //--TRIMMABLE-BOUNDARY-START(4296157818)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296157818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296157818)
            
            //--TRIMMABLE-BOUNDARY-START(4296157818)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296157818)
            
            static $h = 1190522;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591125114),
    {
      "r": 65537,
      "n": "Register",
      "d": 1190522,
      "h": 8591125114,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591125114)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296157818),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1190522,
      "h": 4296157818,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296157818)
  ],
  "h": 1190522
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1190522)
        
        

        //--TRIMMABLE-BOUNDARY-START(141946)
        $asm.$cls(`$hkBT.LCCNC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295109242)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295109242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$hkBT.LCCNCS.ICommunityNairalandForumFeedRemoteService, $.$hkBT.LCCNCS.ICommunityNairalandForumFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$hkBT.LCCNCS.ICommunityNairalandForumFeedRemoteService_Mocking().$ctor$3(impl);
                }, $beLyBf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":141946,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel), $.$hkBT.LCCNCS.ICommunityNairalandForumFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$hkBT.LCCNCS.ICommunityNairalandForumFeedRemoteService_Mocking().$ctor$3(impl);
                }, $HVBmlj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":141946,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$hkBT.LCCNCS.IComunityNairalandForumRemoteService, $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking().$ctor$3(impl);
                }, $KXzOFg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":141946,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking().$ctor$3(impl);
                }, $iLevwk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":141946,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking().$ctor$3(impl);
                }, $cBfYig ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":141946,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking().$ctor$3(impl);
                }, $dQvJGa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":141946,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking().$ctor$3(impl);
                }, $aIOYfb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":141946,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking().$ctor$3(impl);
                }, $SOhlKk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":141946,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking().$ctor$3(impl);
                }, $VSFkSj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":141946,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking().$ctor$3(impl);
                }, $SnTuRc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":141946,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295109242)
            
            static $h = 141946;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295109242),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 141946,
      "h": 4295109242,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295109242)
  ],
  "h": 141946
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(141946)
        
        

        //--TRIMMABLE-BOUNDARY-START(273018)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumCategoryModelCustomAttributesProvider`, ($self) => class CommunityNairalandForumCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295240314)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295240314)
            
            //--TRIMMABLE-BOUNDARY-START(8590207610)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590207610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["/Icon=Forum"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $RYORYe ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":273018,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $kjfTsk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":273018,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590207610)
            
            static $h = 273018;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590207610),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 273018,
      "h": 8590207610,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590207610)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295240314),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 273018,
      "h": 4295240314,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295240314)
  ],
  "h": 273018
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(273018)
        
        

        //--TRIMMABLE-BOUNDARY-START(404090)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumCategoryModelTypeDescriptorBuilder`, ($self) => class CommunityNairalandForumCategoryModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590338682)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590338682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModelTypeDescriptor()
                        const $t1 = $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumCategoryModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Wtlwfc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":404090,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590338682)
            
            //--TRIMMABLE-BOUNDARY-START(4295371386)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295371386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295371386)
            
            //--TRIMMABLE-BOUNDARY-START(4295371386)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295371386)
            
            static $h = 404090;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590338682),
    {
      "r": 65537,
      "n": "Register",
      "d": 404090,
      "h": 8590338682,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590338682)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295371386),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 404090,
      "h": 4295371386,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295371386)
  ],
  "h": 404090
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumCategoryModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumCategoryModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(404090)
        
        

        //--TRIMMABLE-BOUNDARY-START(666234)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelTypeDescriptorBuilder`, ($self) => class CommunityNairalandForumDiscussionModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590600826)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590600826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelTypeDescriptor()
                        const $t1 = $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $aPGghc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":666234,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590600826)
            
            //--TRIMMABLE-BOUNDARY-START(4295633530)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295633530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295633530)
            
            //--TRIMMABLE-BOUNDARY-START(4295633530)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295633530)
            
            static $h = 666234;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590600826),
    {
      "r": 65537,
      "n": "Register",
      "d": 666234,
      "h": 8590600826,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590600826)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295633530),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 666234,
      "h": 4295633530,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295633530)
  ],
  "h": 666234
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumDiscussionModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(666234)
        
        

        //--TRIMMABLE-BOUNDARY-START(1714810)
        $asm.$cls(`$hkBT.LCCNC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591649402)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591649402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$hkBT.LCCNCM.CommunityNairalandForumPostModel, 6915/*PostTypes.NairalandPost*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, 6914/*PostTypes.NairalandDiscussion*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, 6913/*PostTypes.NairalandCategory*/);
                $.$hkBT.LCCNC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$hkBT.LCCNC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$hkBT.LCCNC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591649402)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hkBT.LCCNC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296682106)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296682106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296682106)
            
            //--TRIMMABLE-BOUNDARY-START(4296682106)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296682106)
            
            static $h = 1714810;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591649402),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1714810,
      "h": 8591649402,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591649402)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296682106),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1714810,
      "h": 4296682106,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296682106)
  ],
  "h": 1714810
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1714810)
        
        

        //--TRIMMABLE-BOUNDARY-START(1649274)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumUserPreference`, ($self) => class CommunityNairalandForumUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4296616570)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296616570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296616570)
            
            //--TRIMMABLE-BOUNDARY-START(4296616570)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296616570)
            
            static $h = 1649274;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296616570),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1649274,
      "h": 4296616570,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296616570)
  ],
  "h": 1649274
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1649274)
        
        

        //--TRIMMABLE-BOUNDARY-START(2042490)
        $asm.$cls(`$hkBT.LCCNCS$1.CommunityNairalandForumSettings`, ($self) => class CommunityNairalandForumSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297009786)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297009786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297009786)
            
            //--TRIMMABLE-BOUNDARY-START(4297009786)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297009786)
            
            static $h = 2042490;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297009786),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2042490,
      "h": 4297009786,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297009786)
  ],
  "h": 2042490
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Settings.CommunityNairalandForumSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Settings${separator}CommunityNairalandForumSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2042490)
        
        

        //--TRIMMABLE-BOUNDARY-START(2304634)
        $asm.$cls(`$hkBT.LCCNCS$2.CommunityNairalandForumStates`, ($self) => class CommunityNairalandForumStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4297271930)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297271930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297271930)
            
            //--TRIMMABLE-BOUNDARY-START(4297271930)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297271930)
            
            static $h = 2304634;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297271930),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2304634,
      "h": 4297271930,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297271930)
  ],
  "h": 2304634
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.States.CommunityNairalandForumStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}States${separator}CommunityNairalandForumStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2304634)
        
        

        //--TRIMMABLE-BOUNDARY-START(1452666)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumSearchModelTypeDescriptor`, ($self) => class CommunityNairalandForumSearchModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumSearchModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296419962)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296419962);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hkBT.LCCNCM.CommunityNairalandForumSearchModelTypeDescriptor.GenerateProperties($.$hkBT.LCCNCM.CommunityNairalandForumSearchModel, this, factory);
                    }, $KeBfoi ??= {"r":65537,"n":"","d":1452666,"h":0,"f":17825794}), 0, "CommunityNairalandForumSearchModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.NairalandForum.Common\\Models_CommunityNairalandForumSearchModel_LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumSearchModelTypeDescriptorBuilder.g.cs", "CommunityNairalandForumSearchModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296419962)
            
            //--TRIMMABLE-BOUNDARY-START(12886354554)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886354554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Category"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$hkBT.LCCNCM.CommunityNairalandForumSearchModel.$type, $.$discardRef(), "Category", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Category")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Category";
                        $i1.DelaredOn = "LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumSearchModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumSearchModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$hkBT.LCCNCM.CommunityNairalandForumSearchModel)).Category);
                        }, $KmDnbe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1452666,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumSearchModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Category = value.AsInt();
                        }, $BkZDjf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1452666,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886354554)
            
            //--TRIMMABLE-BOUNDARY-START(17181321850)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumSearchModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181321850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Category = _target.Category;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Category"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Category, ($v) => _Category = $v, $.$$.S.Int32)))
                    {
                        _target.Category = _Category;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181321850)
            
            //--TRIMMABLE-BOUNDARY-START(8591387258)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumSearchModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591387258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hkBT.LCCNCM.CommunityNairalandForumSearchModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hkBT.LCCNCM.CommunityNairalandForumSearchModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumSearchModel)))
                {
                    /*var*/ let result = $.$hkBT.LCCNCM.CommunityNairalandForumSearchModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumSearchModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hkBT.LCCNCM.CommunityNairalandForumSearchModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumSearchModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591387258)
            
            static $h = 1452666;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumSearchModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886354554),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1452666,
      "h": 12886354554,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886354554),
//--TRIMMABLE-BOUNDARY-START(17181321850),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1321594,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1452666,
      "h": 17181321850,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181321850),
//--TRIMMABLE-BOUNDARY-START(8591387258),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1321594,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1452666,
      "h": 8591387258,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591387258)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296419962),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1452666,
      "h": 4296419962,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296419962)
  ],
  "h": 1452666
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumSearchModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumSearchModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumSearchModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1452666)
        
        

        //--TRIMMABLE-BOUNDARY-START(1256058)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumSearchCategoryProvider`, ($self) => class CommunityNairalandForumSearchCategoryProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591190650)
            /*Pager<ISelectOption<int>> */ GetOptions(/*object?*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591190650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.GetPager($.$fPer.LCFC.ISelectOption$$($.$$.S.Int32), $.$sl.SL.Enumerable.Select$1($.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions, $.$fPer.LCFC.ISelectOption$$($.$$.S.Int32), $.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions.Options, new ($.$$.S.Func$$$($.$hkBT.LCCNCM.CommunityNairalandForumSearchOptions, $.$fPer.LCFC.ISelectOption$$($.$$.S.Int32)))().$ctor(this,  (/**/ o) =>
                {
                    return (() =>
                    {
                        //new $.$fPer.LCFC.SelectOption$$($.$$.S.Int32)()
                        const $t1 = $.$fPer.LCFC.SelectOption$$($.$$.S.Int32);
                        const $i1 = new $t1();
                        $i1.$ctor$3(o.Key);
                        $i1.Title = o.Name;
                        return $i1;
                    })();
                }, $STxRRa ??= {"r":$.$fPer.LCFC.ISelectOption$$($.$$.S.Int32).$h,"p":[{"n":"o","p":1583738}],"n":"","d":1256058,"h":0,"f":17825794})), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8591190650)
            
            //--TRIMMABLE-BOUNDARY-START(4297034070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaOptionReader<int>.GetOptions(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaOptionReader$System$Int32$GetOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297034070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOptions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297034070)
            
            //--TRIMMABLE-BOUNDARY-START(4296223354)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296223354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296223354)
            
            //--TRIMMABLE-BOUNDARY-START(4296223354)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296223354)
            
            static $h = 1256058;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591190650),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$$.S.Int32)).$h,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "GetOptions",
      "d": 1256058,
      "h": 8591190650,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591190650)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296223354),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1256058,
      "h": 4296223354,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296223354)
  ],
  "h": 1256058
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$$.S.Int32) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumSearchCategoryProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumSearchCategoryProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1256058)
        
        

        //--TRIMMABLE-BOUNDARY-START(2435706)
        $asm.$cls(`$hkBT.LCCNCS$2.CommunityNairalandForumStatesTypeDescriptor`, ($self) => class CommunityNairalandForumStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCS$2.CommunityNairalandForumStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4297403002)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297403002);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hkBT.LCCNCS$2.CommunityNairalandForumStatesTypeDescriptor.GenerateProperties($.$hkBT.LCCNCS$2.CommunityNairalandForumStates, this, factory);
                    }, $zXKsYg ??= {"r":65537,"n":"","d":2435706,"h":0,"f":17825794}), 0, "CommunityNairalandForumStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.NairalandForum.Common\\States_CommunityNairalandForumStates_LivingThing.Core.Community.NairalandForum.Common.States.CommunityNairalandForumStatesTypeDescriptorBuilder.g.cs", "CommunityNairalandForumStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297403002)
            
            //--TRIMMABLE-BOUNDARY-START(12887337594)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887337594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887337594)
            
            //--TRIMMABLE-BOUNDARY-START(17182304890)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.States.CommunityNairalandForumStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182304890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182304890)
            
            //--TRIMMABLE-BOUNDARY-START(8592370298)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.States.CommunityNairalandForumStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592370298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hkBT.LCCNCS$2.CommunityNairalandForumStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hkBT.LCCNCS$2.CommunityNairalandForumStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCS$2.CommunityNairalandForumStates)))
                {
                    /*var*/ let result = $.$hkBT.LCCNCS$2.CommunityNairalandForumStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCS$2.CommunityNairalandForumStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hkBT.LCCNCS$2.CommunityNairalandForumStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCS$2.CommunityNairalandForumStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592370298)
            
            static $h = 2435706;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCS$2.CommunityNairalandForumStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887337594),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2435706,
      "h": 12887337594,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887337594),
//--TRIMMABLE-BOUNDARY-START(17182304890),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2304634,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2435706,
      "h": 17182304890,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182304890),
//--TRIMMABLE-BOUNDARY-START(8592370298),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2304634,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2435706,
      "h": 8592370298,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592370298)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297403002),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2435706,
      "h": 4297403002,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297403002)
  ],
  "h": 2435706
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hkBT.LCCNCS$2.CommunityNairalandForumStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.States.CommunityNairalandForumStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}States${separator}CommunityNairalandForumStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2435706)
        
        

        //--TRIMMABLE-BOUNDARY-START(2173562)
        $asm.$cls(`$hkBT.LCCNCS$1.CommunityNairalandForumSettingsTypeDescriptor`, ($self) => class CommunityNairalandForumSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCS$1.CommunityNairalandForumSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297140858)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297140858);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hkBT.LCCNCS$1.CommunityNairalandForumSettingsTypeDescriptor.GenerateProperties($.$hkBT.LCCNCS$1.CommunityNairalandForumSettings, this, factory);
                    }, $qQFonh ??= {"r":65537,"n":"","d":2173562,"h":0,"f":17825794}), 0, "CommunityNairalandForumSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.NairalandForum.Common\\Settings_CommunityNairalandForumSettings_LivingThing.Core.Community.NairalandForum.Common.Settings.CommunityNairalandForumSettingsTypeDescriptorBuilder.g.cs", "CommunityNairalandForumSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297140858)
            
            //--TRIMMABLE-BOUNDARY-START(12887075450)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887075450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887075450)
            
            //--TRIMMABLE-BOUNDARY-START(17182042746)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.Settings.CommunityNairalandForumSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182042746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182042746)
            
            //--TRIMMABLE-BOUNDARY-START(8592108154)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.Settings.CommunityNairalandForumSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592108154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hkBT.LCCNCS$1.CommunityNairalandForumSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hkBT.LCCNCS$1.CommunityNairalandForumSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCS$1.CommunityNairalandForumSettings)))
                {
                    /*var*/ let result = $.$hkBT.LCCNCS$1.CommunityNairalandForumSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCS$1.CommunityNairalandForumSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hkBT.LCCNCS$1.CommunityNairalandForumSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCS$1.CommunityNairalandForumSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592108154)
            
            static $h = 2173562;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCS$1.CommunityNairalandForumSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887075450),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2173562,
      "h": 12887075450,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887075450),
//--TRIMMABLE-BOUNDARY-START(17182042746),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2042490,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2173562,
      "h": 17182042746,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182042746),
//--TRIMMABLE-BOUNDARY-START(8592108154),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2042490,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2173562,
      "h": 8592108154,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592108154)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297140858),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2173562,
      "h": 4297140858,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297140858)
  ],
  "h": 2173562
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hkBT.LCCNCS$1.CommunityNairalandForumSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Settings.CommunityNairalandForumSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Settings${separator}CommunityNairalandForumSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2173562)
        
        

        //--TRIMMABLE-BOUNDARY-START(993914)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumPostModel`, ($self) => class CommunityNairalandForumPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295961210)
            $ctor$6()
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295961210);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = "_";
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295961210)
            
            //--TRIMMABLE-BOUNDARY-START(68720470650)
            /*PostTypes */ get Type()
            {
                return 6915/*PostTypes.NairalandPost*/;
            }
            //--TRIMMABLE-BOUNDARY-END(68720470650)
            
            //--TRIMMABLE-BOUNDARY-START(55835568762)
            /*bool */ ShouldEditName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835568762);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835568762)
            
            //--TRIMMABLE-BOUNDARY-START(38655699578)
            /*bool */ RequiresName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655699578);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655699578)
            
            //--TRIMMABLE-BOUNDARY-START(60130536058)
            /*bool */ ShouldEditSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130536058);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130536058)
            
            //--TRIMMABLE-BOUNDARY-START(42950666874)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950666874);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950666874)
            
            //--TRIMMABLE-BOUNDARY-START(51540601466)
            /*bool */ ShouldEditIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540601466);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540601466)
            
            //--TRIMMABLE-BOUNDARY-START(34360732282)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360732282);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360732282)
            
            //--TRIMMABLE-BOUNDARY-START(64425503354)
            /*bool */ ShouldEditTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425503354);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425503354)
            
            //--TRIMMABLE-BOUNDARY-START(47245634170)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245634170);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245634170)
            
            //--TRIMMABLE-BOUNDARY-START(25770797690)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$1(this, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Nairaland", "Post"], null, null), null, false, true);
            }
            //--TRIMMABLE-BOUNDARY-END(25770797690)
            
            //--TRIMMABLE-BOUNDARY-START(30065764986)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065764986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Schema === 1/*SchemaType.Form*/)
                {
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Post", "Reply", "Reply to Forum Question", "mdi mdi-message-reply-text-outline"/*MaterialDesignIconNames.MessageReplyTextOutline*/, null, null);
                }
                super.ModifyDescriptor(propertyBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(30065764986)
            
            //--TRIMMABLE-BOUNDARY-START(73015437946)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015437946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 1/*SchemaType.Form*/)
                {
                    descriptors = $.$LCOv.LCFCPM$1.PostBaseModel.Exclude(descriptors, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "PostFlags" ], null, null));
                }
                return super.UpdateDescriptors(descriptors, $.$clone(schema));
            }
            //--TRIMMABLE-BOUNDARY-END(73015437946)
            
            //--TRIMMABLE-BOUNDARY-START(8594254260)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThreadPost.ParentId.get
            get LCFCP$IPostThreadPost$ParentId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889221556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParentId;
            }
            //--TRIMMABLE-BOUNDARY-END(8594254260)
            
            //--TRIMMABLE-BOUNDARY-START(21479156148)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThreadPost.ParentId.set
            set LCFCP$IPostThreadPost$ParentId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889221556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ParentId = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21479156148)
            
            //--TRIMMABLE-BOUNDARY-START(8593271220)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesCount.get
            get LCFCP$IPostReplyable$RepliesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478173108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593271220)
            
            //--TRIMMABLE-BOUNDARY-START(17183205812)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesDepth.get
            get LCFCP$IPostReplyable$RepliesDepth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773140404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesDepth;
            }
            //--TRIMMABLE-BOUNDARY-END(17183205812)
            
            //--TRIMMABLE-BOUNDARY-START(4295961210)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295961210)
            
            static $h = 993914;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720470650),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475830394,
        "f": 50364417
      },
      "n": "Type",
      "d": 993914,
      "h": 68720470650,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68720470650),
//--TRIMMABLE-BOUNDARY-START(25770797690),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885895802,
        "f": 50364417
      },
      "n": "Link",
      "d": 993914,
      "h": 25770797690,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770797690)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835568762),
    {
      "r": 262145,
      "n": "ShouldEditName",
      "d": 993914,
      "h": 55835568762,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835568762),
//--TRIMMABLE-BOUNDARY-START(38655699578),
    {
      "r": 262145,
      "n": "RequiresName",
      "d": 993914,
      "h": 38655699578,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655699578),
//--TRIMMABLE-BOUNDARY-START(60130536058),
    {
      "r": 262145,
      "n": "ShouldEditSummary",
      "d": 993914,
      "h": 60130536058,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130536058),
//--TRIMMABLE-BOUNDARY-START(42950666874),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 993914,
      "h": 42950666874,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950666874),
//--TRIMMABLE-BOUNDARY-START(51540601466),
    {
      "r": 262145,
      "n": "ShouldEditIcon",
      "d": 993914,
      "h": 51540601466,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540601466),
//--TRIMMABLE-BOUNDARY-START(34360732282),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 993914,
      "h": 34360732282,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360732282),
//--TRIMMABLE-BOUNDARY-START(64425503354),
    {
      "r": 262145,
      "n": "ShouldEditTags",
      "d": 993914,
      "h": 64425503354,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425503354),
//--TRIMMABLE-BOUNDARY-START(47245634170),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": 993914,
      "h": 47245634170,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245634170),
//--TRIMMABLE-BOUNDARY-START(30065764986),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 993914,
      "h": 30065764986,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065764986),
//--TRIMMABLE-BOUNDARY-START(73015437946),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": 993914,
      "h": 73015437946,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015437946)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295961210),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 993914,
      "h": 4295961210,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295961210)
  ],
  "h": 993914
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostThreadPost, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostReplyable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(993914)
        
        

        //--TRIMMABLE-BOUNDARY-START(1911418)
        $asm.$cls(`$hkBT.LCCNCS.IComunityNairalandForumRemoteService`, ($self) => class IComunityNairalandForumRemoteService
        {
            static $h = 1911418;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1911418,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.IReadDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Services.IComunityNairalandForumRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Services${separator}IComunityNairalandForumRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1911418)
        
        

        //--TRIMMABLE-BOUNDARY-START(1976954)
        $asm.$cls(`$hkBT.LCCNCS.IComunityNairalandForumRemoteService_Mocking`, ($self) => class IComunityNairalandForumRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296944250)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296944250);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296944250)
            
            //--TRIMMABLE-BOUNDARY-START(8591911546)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$NairalandForum$Common$Models$CommunityNairalandForumPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591911546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$hkBT.LCCNCM.CommunityNairalandForumPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591911546)
            
            //--TRIMMABLE-BOUNDARY-START(17181846138)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$NairalandForum$Common$Models$CommunityNairalandForumPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181846138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$hkBT.LCCNCM.CommunityNairalandForumPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181846138)
            
            //--TRIMMABLE-BOUNDARY-START(21476813434)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$NairalandForum$Common$Models$CommunityNairalandForumPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476813434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$hkBT.LCCNCM.CommunityNairalandForumPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476813434)
            
            //--TRIMMABLE-BOUNDARY-START(25771780730)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$NairalandForum$Common$Models$CommunityNairalandForumPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771780730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$hkBT.LCCNCM.CommunityNairalandForumPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771780730)
            
            //--TRIMMABLE-BOUNDARY-START(12886878842)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886878842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$hkBT.LCCNCM.CommunityNairalandForumPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886878842)
            
            static $h = 1976954;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296944250),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1976954,
      "h": 4296944250,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296944250)
  ],
  "h": 1976954
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$hkBT.LCCNCS.IComunityNairalandForumRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.IReadDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Services.IComunityNairalandForumRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Services${separator}IComunityNairalandForumRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1976954)
        
        

        //--TRIMMABLE-BOUNDARY-START(1124986)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumPostModelTypeDescriptor`, ($self) => class CommunityNairalandForumPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296092282)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296092282);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hkBT.LCCNCM.CommunityNairalandForumPostModelTypeDescriptor.GenerateProperties($.$hkBT.LCCNCM.CommunityNairalandForumPostModel, this, factory);
                    }, $xFmDBf ??= {"r":65537,"n":"","d":1124986,"h":0,"f":17825794}), 0, "CommunityNairalandForumPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.NairalandForum.Common\\Models_CommunityNairalandForumPostModel_LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModelTypeDescriptorBuilder.g.cs", "CommunityNairalandForumPostModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296092282)
            
            //--TRIMMABLE-BOUNDARY-START(12886026874)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886026874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel)).Type);
                        }, $oLiwVj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1124986,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Link";
                        $i3.DelaredOn = "LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumPostModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel)).Link);
                        }, $OjoHck ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1124986,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886026874)
            
            //--TRIMMABLE-BOUNDARY-START(17180994170)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180994170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180994170)
            
            //--TRIMMABLE-BOUNDARY-START(8591059578)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591059578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hkBT.LCCNCM.CommunityNairalandForumPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel)))
                {
                    /*var*/ let result = $.$hkBT.LCCNCM.CommunityNairalandForumPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591059578)
            
            static $h = 1124986;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886026874),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1124986,
      "h": 12886026874,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886026874),
//--TRIMMABLE-BOUNDARY-START(17180994170),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 993914,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1124986,
      "h": 17180994170,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180994170),
//--TRIMMABLE-BOUNDARY-START(8591059578),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 993914,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1124986,
      "h": 8591059578,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591059578)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296092282),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1124986,
      "h": 4296092282,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296092282)
  ],
  "h": 1124986
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1124986)
        
        

        $asm.$typeProxy("$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel", "$hkBT.LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModel");
        //--TRIMMABLE-BOUNDARY-START(207482)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumCategoryModel`, ($self) => class CommunityNairalandForumCategoryModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel)
        {
            //--TRIMMABLE-BOUNDARY-START(42949880442)
            /*PostTypes */ get Type()
            {
                return 6913/*PostTypes.NairalandCategory*/;
            }
            //--TRIMMABLE-BOUNDARY-END(42949880442)
            
            //--TRIMMABLE-BOUNDARY-START(38654913146)
            /*bool */ ShouldSerializeTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654913146);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654913146)
            
            //--TRIMMABLE-BOUNDARY-START(34359945850)
            /*bool */ ShouldSerializeIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359945850);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359945850)
            
            //--TRIMMABLE-BOUNDARY-START(30064978554)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064978554);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064978554)
            
            //--TRIMMABLE-BOUNDARY-START(25770011258)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$1(this, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Nairaland", "Category"], null, null), null, false, true);
            }
            //--TRIMMABLE-BOUNDARY-END(25770011258)
            
            //--TRIMMABLE-BOUNDARY-START(8594188724)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThreadCategory.ThreadsCount.get
            get LCFCP$IPostThreadCategory$ThreadsCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889156020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ThreadsCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8594188724)
            
            //--TRIMMABLE-BOUNDARY-START(4295174778)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295174778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295174778)
            
            //--TRIMMABLE-BOUNDARY-START(4295174778)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295174778)
            
            static $h = 207482;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42949880442),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475043962,
        "f": 50364417
      },
      "n": "Type",
      "d": 207482,
      "h": 42949880442,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42949880442),
//--TRIMMABLE-BOUNDARY-START(25770011258),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885109370,
        "f": 50364417
      },
      "n": "Link",
      "d": 207482,
      "h": 25770011258,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770011258)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38654913146),
    {
      "r": 262145,
      "n": "ShouldSerializeTags",
      "d": 207482,
      "h": 38654913146,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654913146),
//--TRIMMABLE-BOUNDARY-START(34359945850),
    {
      "r": 262145,
      "n": "ShouldSerializeIcon",
      "d": 207482,
      "h": 34359945850,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359945850),
//--TRIMMABLE-BOUNDARY-START(30064978554),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": 207482,
      "h": 30064978554,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30064978554)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295174778),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 207482,
      "h": 4295174778,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295174778)
  ],
  "h": 207482,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "/Icon=Forum"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostThreadCategory, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostNestedCategory, $.$LCOv.LCFCP.IPostByAdminOnly ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(207482)
        
        

        //--TRIMMABLE-BOUNDARY-START(469626)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel`, ($self) => class CommunityNairalandForumDiscussionModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295436922)
            $ctor$6()
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295436922);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = null;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295436922)
            
            //--TRIMMABLE-BOUNDARY-START(90194782842)
            /*PostTypes */ get Type()
            {
                return 6914/*PostTypes.NairalandDiscussion*/;
            }
            //--TRIMMABLE-BOUNDARY-END(90194782842)
            
            //--TRIMMABLE-BOUNDARY-START(81604848250)
            /*bool */ ShouldEditName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604848250);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604848250)
            
            //--TRIMMABLE-BOUNDARY-START(73014913658)
            /*bool */ RequiresName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014913658);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014913658)
            
            //--TRIMMABLE-BOUNDARY-START(85899815546)
            /*bool */ ShouldEditSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899815546);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899815546)
            
            //--TRIMMABLE-BOUNDARY-START(77309880954)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309880954);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309880954)
            
            //--TRIMMABLE-BOUNDARY-START(64424979066)
            /*IPost */ get LCFCP$IPostThread$LastPost()
            {
                return this.LastPost;
            }
            //--TRIMMABLE-BOUNDARY-END(64424979066)
            
            //--TRIMMABLE-BOUNDARY-START(42950142586)
            /*IPost */ get LCFCP$IPostCategorizable$Category()
            {
                return this.Category;
            }
            //--TRIMMABLE-BOUNDARY-END(42950142586)
            
            //--TRIMMABLE-BOUNDARY-START(34360207994)
            /*bool */ get IsThread()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(34360207994)
            
            //--TRIMMABLE-BOUNDARY-START(68719946362)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719946362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Name", "Title", null, null, null, null);
                if (propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Schema === 1/*SchemaType.Form*/)
                {
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Post", "Question", "Enter your questions here", null, null, null);
                }
                super.ModifyDescriptor(propertyBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(68719946362)
            
            //--TRIMMABLE-BOUNDARY-START(38655175290)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$1(this, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Nairaland", "Discussion"], null, null), null, false, false);
            }
            //--TRIMMABLE-BOUNDARY-END(38655175290)
            
            //--TRIMMABLE-BOUNDARY-START(8594123188)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThread.IsThread.get
            get LCFCP$IPostThread$IsThread()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479025076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsThread;
            }
            //--TRIMMABLE-BOUNDARY-END(8594123188)
            
            //--TRIMMABLE-BOUNDARY-START(8594254260)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThreadPost.ParentId.get
            get LCFCP$IPostThreadPost$ParentId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889221556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParentId;
            }
            //--TRIMMABLE-BOUNDARY-END(8594254260)
            
            //--TRIMMABLE-BOUNDARY-START(21479156148)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThreadPost.ParentId.set
            set LCFCP$IPostThreadPost$ParentId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889221556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ParentId = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21479156148)
            
            //--TRIMMABLE-BOUNDARY-START(8594385332)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostVotable.VotesCount.get
            get LCFCP$IPostVotable$VotesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479287220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.VotesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8594385332)
            
            //--TRIMMABLE-BOUNDARY-START(17184319924)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostVotable.VotesCount.set
            set LCFCP$IPostVotable$VotesCount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479287220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.VotesCount = value;
            }
            //--TRIMMABLE-BOUNDARY-END(17184319924)
            
            //--TRIMMABLE-BOUNDARY-START(8593992116)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSubscribable.SubscribersCount.get
            get LCFCP$IPostSubscribable$SubscribersCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888959412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SubscribersCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593992116)
            
            //--TRIMMABLE-BOUNDARY-START(4295436922)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295436922)
            
            static $h = 469626;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90194782842),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065240698,
        "f": 50364417
      },
      "n": "Type",
      "d": 469626,
      "h": 90194782842,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90194782842),
//--TRIMMABLE-BOUNDARY-START(64424979066),
    {
      "p": 1173940,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130011770,
        "f": 50331650
      },
      "n": "{4188596}.LastPost",
      "o": "LCFCP$IPostThread$LastPost",
      "d": 469626,
      "h": 64424979066,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64424979066),
//--TRIMMABLE-BOUNDARY-START(42950142586),
    {
      "p": 1173940,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540077178,
        "f": 50331650
      },
      "n": "{1632692}.Category",
      "o": "LCFCP$IPostCategorizable$Category",
      "d": 469626,
      "h": 42950142586,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(42950142586),
//--TRIMMABLE-BOUNDARY-START(34360207994),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885371514,
        "f": 50331649
      },
      "n": "IsThread",
      "d": 469626,
      "h": 34360207994,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360207994),
//--TRIMMABLE-BOUNDARY-START(38655175290),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475306106,
        "f": 50364417
      },
      "n": "Link",
      "d": 469626,
      "h": 38655175290,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655175290)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81604848250),
    {
      "r": 262145,
      "n": "ShouldEditName",
      "d": 469626,
      "h": 81604848250,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604848250),
//--TRIMMABLE-BOUNDARY-START(73014913658),
    {
      "r": 262145,
      "n": "RequiresName",
      "d": 469626,
      "h": 73014913658,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73014913658),
//--TRIMMABLE-BOUNDARY-START(85899815546),
    {
      "r": 262145,
      "n": "ShouldEditSummary",
      "d": 469626,
      "h": 85899815546,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85899815546),
//--TRIMMABLE-BOUNDARY-START(77309880954),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 469626,
      "h": 77309880954,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77309880954),
//--TRIMMABLE-BOUNDARY-START(68719946362),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 469626,
      "h": 68719946362,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68719946362)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295436922),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 469626,
      "h": 4295436922,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295436922)
  ],
  "h": 469626
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostThread, $.$LCOv.LCFCP.IPostThreadPost, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostVotable, $.$LCOv.LCFCP.IPostCategorizable, $.$LCOv.LCFCP.IPostSubscribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumDiscussionModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(469626)
        
        

        //--TRIMMABLE-BOUNDARY-START(1780346)
        $asm.$cls(`$hkBT.LCCNCS.ICommunityNairalandForumFeedRemoteService`, ($self) => class ICommunityNairalandForumFeedRemoteService
        {
            static $h = 1780346;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1780346,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Services.ICommunityNairalandForumFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Services${separator}ICommunityNairalandForumFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1780346)
        
        

        //--TRIMMABLE-BOUNDARY-START(1845882)
        $asm.$cls(`$hkBT.LCCNCS.ICommunityNairalandForumFeedRemoteService_Mocking`, ($self) => class ICommunityNairalandForumFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296813178)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296813178);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296813178)
            
            //--TRIMMABLE-BOUNDARY-START(8591780474)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$NairalandForum$Common$Models$CommunityNairalandForumDiscussionModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591780474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591780474)
            
            static $h = 1845882;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296813178),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1845882,
      "h": 4296813178,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296813178)
  ],
  "h": 1845882
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$hkBT.LCCNCS.ICommunityNairalandForumFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Services.ICommunityNairalandForumFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Services${separator}ICommunityNairalandForumFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1845882)
        
        

        //--TRIMMABLE-BOUNDARY-START(731770)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumModel`, ($self) => class CommunityNairalandForumModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$hkBT.LCCNCS$1.CommunityNairalandForumSettings, $.$hkBT.LCCNCS$2.CommunityNairalandForumStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295699066)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295699066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295699066)
            
            //--TRIMMABLE-BOUNDARY-START(4295699066)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295699066)
            
            static $h = 731770;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$hkBT.LCCNCS$1.CommunityNairalandForumSettings, $.$hkBT.LCCNCS$2.CommunityNairalandForumStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295699066),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 731770,
      "h": 4295699066,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295699066)
  ],
  "h": 731770
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(731770)
        
        

        //--TRIMMABLE-BOUNDARY-START(338554)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumCategoryModelTypeDescriptor`, ($self) => class CommunityNairalandForumCategoryModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295305850)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295305850);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModelTypeDescriptor.GenerateProperties($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, this, factory);
                    }, $RLaEHc ??= {"r":65537,"n":"","d":338554,"h":0,"f":17825794}), 0, "CommunityNairalandForumCategoryModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.NairalandForum.Common\\Models_CommunityNairalandForumCategoryModel_LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumCategoryModelTypeDescriptorBuilder.g.cs", "CommunityNairalandForumCategoryModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295305850)
            
            //--TRIMMABLE-BOUNDARY-START(12885240442)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885240442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumCategoryModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel)).Type);
                        }, $Skzdfg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":338554,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Link";
                        $i3.DelaredOn = "LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumCategoryModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel)).Link);
                        }, $zYtrLf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":338554,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885240442)
            
            //--TRIMMABLE-BOUNDARY-START(17180207738)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumCategoryModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180207738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumCategoryModel, LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180207738)
            
            //--TRIMMABLE-BOUNDARY-START(8590273146)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumCategoryModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590273146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel)))
                {
                    /*var*/ let result = $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590273146)
            
            static $h = 338554;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885240442),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 338554,
      "h": 12885240442,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885240442),
//--TRIMMABLE-BOUNDARY-START(17180207738),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 207482,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 338554,
      "h": 17180207738,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180207738),
//--TRIMMABLE-BOUNDARY-START(8590273146),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 207482,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 338554,
      "h": 8590273146,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590273146)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295305850),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 338554,
      "h": 4295305850,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295305850)
  ],
  "h": 338554
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumCategoryModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumCategoryModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(338554)
        
        

        //--TRIMMABLE-BOUNDARY-START(600698)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelTypeDescriptor`, ($self) => class CommunityNairalandForumDiscussionModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295567994)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295567994);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelTypeDescriptor.GenerateProperties($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, this, factory);
                    }, $GAONVh ??= {"r":65537,"n":"","d":600698,"h":0,"f":17825794}), 0, "CommunityNairalandForumDiscussionModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.NairalandForum.Common\\Models_CommunityNairalandForumDiscussionModel_LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModelTypeDescriptorBuilder.g.cs", "CommunityNairalandForumDiscussionModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295567994)
            
            //--TRIMMABLE-BOUNDARY-START(12885502586)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885502586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel)).Type);
                        }, $djNQOc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":600698,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsThread"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel.$type, $.$discardRef(), "IsThread", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsThread")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "IsThread";
                        $i3.DelaredOn = "LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel)).IsThread);
                        }, $dakVxe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":600698,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Link";
                        $i5.DelaredOn = "LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel)).Link);
                        }, $tePYif ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":600698,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885502586)
            
            //--TRIMMABLE-BOUNDARY-START(17180469882)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180469882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumCategoryModel, LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$hkBT.LCCNCM.CommunityNairalandForumCategoryModel, $.$hkBT.LCCNCM.CommunityNairalandForumPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _IsThread = _target.IsThread;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsThread"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsThread, ($v) => _IsThread = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180469882)
            
            //--TRIMMABLE-BOUNDARY-START(8590535290)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590535290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel)))
                {
                    /*var*/ let result = $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590535290)
            
            static $h = 600698;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885502586),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 600698,
      "h": 12885502586,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885502586),
//--TRIMMABLE-BOUNDARY-START(17180469882),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 469626,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 600698,
      "h": 17180469882,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180469882),
//--TRIMMABLE-BOUNDARY-START(8590535290),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 469626,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 600698,
      "h": 8590535290,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590535290)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295567994),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 600698,
      "h": 4295567994,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295567994)
  ],
  "h": 600698
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumDiscussionModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumDiscussionModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumDiscussionModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(600698)
        
        

        //--TRIMMABLE-BOUNDARY-START(862842)
        $asm.$cls(`$hkBT.LCCNCM.CommunityNairalandForumModelTypeDescriptor`, ($self) => class CommunityNairalandForumModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295830138)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295830138);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hkBT.LCCNCM.CommunityNairalandForumModelTypeDescriptor.GenerateProperties($.$hkBT.LCCNCM.CommunityNairalandForumModel, this, factory);
                    }, $KOOKBb ??= {"r":65537,"n":"","d":862842,"h":0,"f":17825794}), 0, "CommunityNairalandForumModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.NairalandForum.Common\\Models_CommunityNairalandForumModel_LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumModelTypeDescriptorBuilder.g.cs", "CommunityNairalandForumModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295830138)
            
            //--TRIMMABLE-BOUNDARY-START(12885764730)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885764730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$hkBT.LCCNCS$1.CommunityNairalandForumSettings, $.$hkBT.LCCNCS$2.CommunityNairalandForumStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885764730)
            
            //--TRIMMABLE-BOUNDARY-START(17180732026)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180732026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.NairalandForum.Common.Settings.CommunityNairalandForumSettings, LivingThing.Core.Community.NairalandForum.Common.States.CommunityNairalandForumStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$hkBT.LCCNCS$1.CommunityNairalandForumSettings, $.$hkBT.LCCNCS$2.CommunityNairalandForumStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$hkBT.LCCNCS$1.CommunityNairalandForumSettings, $.$hkBT.LCCNCS$2.CommunityNairalandForumStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180732026)
            
            //--TRIMMABLE-BOUNDARY-START(8590797434)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590797434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hkBT.LCCNCM.CommunityNairalandForumModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hkBT.LCCNCM.CommunityNairalandForumModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumModel)))
                {
                    /*var*/ let result = $.$hkBT.LCCNCM.CommunityNairalandForumModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hkBT.LCCNCM.CommunityNairalandForumModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hkBT.LCCNCM.CommunityNairalandForumModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590797434)
            
            static $h = 862842;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885764730),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 862842,
      "h": 12885764730,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885764730),
//--TRIMMABLE-BOUNDARY-START(17180732026),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 731770,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 862842,
      "h": 17180732026,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180732026),
//--TRIMMABLE-BOUNDARY-START(8590797434),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 731770,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 862842,
      "h": 8590797434,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590797434)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295830138),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 862842,
      "h": 4295830138,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295830138)
  ],
  "h": 862842
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hkBT.LCCNCM.CommunityNairalandForumModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NairalandForum.Common.Models.CommunityNairalandForumModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NairalandForum${separator}Common${separator}Models${separator}CommunityNairalandForumModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(862842)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(10874)
