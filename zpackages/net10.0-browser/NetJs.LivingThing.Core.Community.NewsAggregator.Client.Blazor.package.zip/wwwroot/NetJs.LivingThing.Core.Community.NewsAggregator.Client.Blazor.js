
//--TRIMMABLE-BOUNDARY-START(20385)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $anJf) {
    "use strict";
    let _;
    let $oNwISd;
    let $helDil;
    let $klESch;
    let $lwKWvh;
    let $wQSuAf;
    let $iQTdrj;
    let $ASPdZk;
    let $pvgrPj;
    let $Xvekpe;
    let $vuNAAg;
    let $YfscYk;
    let $VKVWya;
    let $NVYTYc;
    let $NJkEqb;
    let $msqFab;
    let $UdfcYh;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.NewsAggregator.Client.Blazor", 
    {
  "h": 20385,
  "f": "LivingThing.Core.Community.NewsAggregator.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.NewsAggregator.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.NewsAggregator.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(151457)
        $asm.$cls(`$GeIp.LCCNC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295118753)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295118753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$GeIp.LCCNC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295118753)
            
            static $h = 151457;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295118753),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 151457,
      "h": 4295118753,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295118753)
  ],
  "h": 151457
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(151457)
        
        

        //--TRIMMABLE-BOUNDARY-START(216993)
        $asm.$cls(`$GeIp.LCCNC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180086177)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$GeIp.LCCNCP.CommunityNewsAggregatorApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$GeIp.LCCNCP.CommunityNewsAggregatorApp().$ctor$6();
                    }, $oNwISd ??= {"r":2752627,"n":"","d":216993,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180086177)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295184289)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295184289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295184289)
            
            //--TRIMMABLE-BOUNDARY-START(4295184289)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295184289)
            
            static $h = 216993;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180086177),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885118881,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 216993,
      "h": 17180086177,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180086177)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295184289),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 216993,
      "h": 4295184289,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295184289)
  ],
  "h": 216993
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(216993)
        
        

        //--TRIMMABLE-BOUNDARY-START(348065)
        $asm.$cls(`$GeIp.LCCNC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590282657)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590282657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$GeIp.LCCNCS.CommunityNewsAggregatorService, $.$LCOv.LCFCPMC.NoCategoryPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorUserPreference), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$GeIp.LCCNCS.CommunityNewsAggregatorApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GeIp.LCCNCS.CommunityNewsAggregatorApplication, x);
                }, $helDil ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":348065,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GeIp.LCCNCS.CommunityNewsAggregatorApplication, x);
                }, $klESch ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":348065,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorUserPreference)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GeIp.LCCNCS.CommunityNewsAggregatorApplication, x);
                }, $lwKWvh ??= {"r":$.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorUserPreference).$h,"p":[{"n":"x","p":327718}],"n":"","d":348065,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityTabFeedProvider, $.$GeIp.LCCNCS.CommunityNewsAggregatorTabFeedProvider, services);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, services, null);
                $.$GeIp.LCCNC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590282657)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$GeIp.LCCNC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295315361)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295315361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295315361)
            
            //--TRIMMABLE-BOUNDARY-START(4295315361)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295315361)
            
            static $h = 348065;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590282657),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 348065,
      "h": 8590282657,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590282657)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295315361),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 348065,
      "h": 4295315361,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295315361)
  ],
  "h": 348065
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(348065)
        
        

        //--TRIMMABLE-BOUNDARY-START(610209)
        $asm.$cls(`$GeIp.LCCNCS.CommunityNewsAggregatorTabFeedProvider`, ($self) => class CommunityNewsAggregatorTabFeedProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(85899956129)
            /*string? */ get Title()
            {
                return "News";
            }
            //--TRIMMABLE-BOUNDARY-END(85899956129)
            
            //--TRIMMABLE-BOUNDARY-START(8590544801)
            /*string? */ get Description()
            {
                return "Red News from various sources";
            }
            //--TRIMMABLE-BOUNDARY-END(8590544801)
            
            //--TRIMMABLE-BOUNDARY-START(68720086945)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-newspaper-plus"/*MaterialDesignIconNames.NewspaperPlus*/);
            }
            //--TRIMMABLE-BOUNDARY-END(68720086945)
            
            //--TRIMMABLE-BOUNDARY-START(73015054241)
            /*string? */ get Name()
            {
                return "News";
            }
            //--TRIMMABLE-BOUNDARY-END(73015054241)
            
            //--TRIMMABLE-BOUNDARY-START(77310021537)
            /*int */ get Order()
            {
                return 5;
            }
            //--TRIMMABLE-BOUNDARY-END(77310021537)
            
            //--TRIMMABLE-BOUNDARY-START(81604988833)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$GeIp.LCCNCS.CommunityNewsAggregatorApplication.NewsTheme);
            }
            //--TRIMMABLE-BOUNDARY-END(81604988833)
            
            //--TRIMMABLE-BOUNDARY-START(64425119649)
            /*RenderFragment? */ GetFeeds()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425119649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$ahDc.LCCCSP.CommunityPosts$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("Title", "Breaking News");
                    $i1.set_Item("CardWidthHint", $.$box(250, $.$$.S.Int32));
                    $i1.set_Item("CardSpaceHint", $.$box(20, $.$$.S.Int32));
                    $i1.set_Item("CardView", $.$box(4/*CommunityPostView.CardMediaFirst*/, $.$ahDc.LCCCSP.CommunityPostView));
                    $i1.set_Item("Features", $.$box(35184372092928n | 17592186044416n, $.$hDPm.LCFCCD$1.DataListFeatures));
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(64425119649)
            
            //--TRIMMABLE-BOUNDARY-START(12890904000)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Feeds.ICommunityTabFeedProvider.GetFeeds()
            LCCCF$ICommunityTabFeedProvider$GetFeeds()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890904000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFeeds(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12890904000)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(8610351446)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOrderedData.Order.get
            get LCFCD$IOrderedData$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12905318742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(8610351446)
            
            //--TRIMMABLE-BOUNDARY-START(4295577505)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295577505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295577505)
            
            //--TRIMMABLE-BOUNDARY-START(4295577505)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295577505)
            
            static $h = 610209;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85899956129),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130152353,
        "f": 50331649
      },
      "n": "Title",
      "d": 610209,
      "h": 85899956129,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899956129),
//--TRIMMABLE-BOUNDARY-START(8590544801),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180479393,
        "f": 50331649
      },
      "n": "Description",
      "d": 610209,
      "h": 8590544801,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590544801),
//--TRIMMABLE-BOUNDARY-START(68720086945),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770413985,
        "f": 50331649
      },
      "n": "Icon",
      "d": 610209,
      "h": 68720086945,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720086945),
//--TRIMMABLE-BOUNDARY-START(73015054241),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360348577,
        "f": 50331649
      },
      "n": "Name",
      "d": 610209,
      "h": 73015054241,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015054241),
//--TRIMMABLE-BOUNDARY-START(77310021537),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950283169,
        "f": 50331649
      },
      "n": "Order",
      "d": 610209,
      "h": 77310021537,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310021537),
//--TRIMMABLE-BOUNDARY-START(81604988833),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540217761,
        "f": 50331649
      },
      "n": "Theme",
      "d": 610209,
      "h": 81604988833,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604988833)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425119649),
    {
      "r": 6881395,
      "n": "GetFeeds",
      "d": 610209,
      "h": 64425119649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425119649)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295577505),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 610209,
      "h": 4295577505,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295577505)
  ],
  "h": 610209
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityTabFeedProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IThemable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Client.Services.CommunityNewsAggregatorTabFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Client${separator}Services${separator}CommunityNewsAggregatorTabFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(610209)
        
        

        //--TRIMMABLE-BOUNDARY-START(741281)
        $asm.$cls(`$GeIp.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295708577)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295708577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295708577)
            
            //--TRIMMABLE-BOUNDARY-START(4295708577)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295708577)
            
            static $h = 741281;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295708577),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 741281,
      "h": 4295708577,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295708577)
  ],
  "h": 741281,
  "a": [
    {
      "t": 675745,
      "c": 4295643041
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(741281)
        
        

        //--TRIMMABLE-BOUNDARY-START(675745)
        $asm.$cls(`$GeIp.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295643041)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295643041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295643041)
            
            //--TRIMMABLE-BOUNDARY-START(4295643041)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295643041)
            
            static $h = 675745;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295643041),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 675745,
      "h": 4295643041,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295643041)
  ],
  "h": 675745
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(675745)
        
        

        //--TRIMMABLE-BOUNDARY-START(85921)
        $asm.$cls(`$GeIp.LCCNC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590020513)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590020513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590020513)
            
            //--TRIMMABLE-BOUNDARY-START(4295053217)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295053217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295053217)
            
            //--TRIMMABLE-BOUNDARY-START(4295053217)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295053217)
            
            static $h = 85921;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590020513),
    {
      "r": 65537,
      "n": "Execute",
      "d": 85921,
      "h": 8590020513,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590020513)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295053217),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 85921,
      "h": 4295053217,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295053217)
  ],
  "h": 85921
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(85921)
        
        

        //--TRIMMABLE-BOUNDARY-START(479137)
        $asm.$cls(`$GeIp.LCCNCS.CommunityNewsAggregatorFeedProvider`, ($self) => class CommunityNewsAggregatorFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295446433)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295446433);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295446433)
            
            //--TRIMMABLE-BOUNDARY-START(8590413729)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityNewsAggregatorNewsModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590413729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`published a news`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590413729)
            
            static $h = 479137;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590413729),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 483061
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 479137,
      "h": 8590413729,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590413729)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295446433),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 479137,
      "h": 4295446433,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295446433)
  ],
  "h": 479137
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Client.Services.CommunityNewsAggregatorFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Client${separator}Services${separator}CommunityNewsAggregatorFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(479137)
        
        

        //--TRIMMABLE-BOUNDARY-START(413601)
        $asm.$cls(`$GeIp.LCCNCS.CommunityNewsAggregatorApplication`, ($self) => class CommunityNewsAggregatorApplication extends $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorUserPreference, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(146029301665)
            /*Theme*/ static NewsTheme;
            //--TRIMMABLE-BOUNDARY-END(146029301665)
            
            //--TRIMMABLE-BOUNDARY-START(17180282785)
            $ctor$3(/*CommunityNewsAggregatorService*/ service)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180282785);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180282785)
            
            //--TRIMMABLE-BOUNDARY-START(141734334369)
            /*string */ get Name()
            {
                return "News";
            }
            //--TRIMMABLE-BOUNDARY-END(141734334369)
            
            //--TRIMMABLE-BOUNDARY-START(167504138145)
            /*string */ get Title()
            {
                return "News";
            }
            //--TRIMMABLE-BOUNDARY-END(167504138145)
            
            //--TRIMMABLE-BOUNDARY-START(25770217377)
            /*string */ get Description()
            {
                return "Read breaking and recent news from various online sources.";
            }
            //--TRIMMABLE-BOUNDARY-END(25770217377)
            
            //--TRIMMABLE-BOUNDARY-START(137439367073)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-newspaper"/*MaterialDesignIconNames.Newspaper*/);
            }
            //--TRIMMABLE-BOUNDARY-END(137439367073)
            
            //--TRIMMABLE-BOUNDARY-START(163209170849)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$GeIp.LCCNCS.CommunityNewsAggregatorApplication.NewsTheme);
            }
            //--TRIMMABLE-BOUNDARY-END(163209170849)
            
            //--TRIMMABLE-BOUNDARY-START(34360151969)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 97/*ApplicationServiceFeatures.DefaultInDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(34360151969)
            
            //--TRIMMABLE-BOUNDARY-START(21475250081)
            /*Type? */ get ApplicationViewType()
            {
                return $.$GeIp.LCCNCP.CommunityNewsAggregatorApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(21475250081)
            
            //--TRIMMABLE-BOUNDARY-START(133144399777)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144399777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$GeIp.LCCNCP.CommunityNewsAggregatorApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(133144399777)
            
            //--TRIMMABLE-BOUNDARY-START(30065184673)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065184673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(30065184673)
            
            //--TRIMMABLE-BOUNDARY-START(154619236257)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619236257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(154619236257)
            
            //--TRIMMABLE-BOUNDARY-START(150324268961)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(150324268961)
            
            //--TRIMMABLE-BOUNDARY-START(4295380897)
            /*CommunityNewsAggregatorService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295380897)
            
            //--TRIMMABLE-BOUNDARY-START(158914203553)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(158914203553)
            
            //--TRIMMABLE-BOUNDARY-START(171799105441)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(8192/*PostTypes.NewsAggregator*/, 8195/*PostTypes.NewsAggregatorEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(171799105441)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            //--TRIMMABLE-BOUNDARY-START(12885315489)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885315489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(146029301665)
                    this.NewsTheme = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t1 = $.$fPer.LCFC.Theme;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.BackgroundColor = "#2E969B";
                        $i1.ForegroundColor = "#FFF";
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(146029301665)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885315489)
            
            static $h = 413601;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorUserPreference, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(141734334369),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899759521,
        "f": 50364417
      },
      "n": "Name",
      "d": 413601,
      "h": 141734334369,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734334369),
//--TRIMMABLE-BOUNDARY-START(167504138145),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259497889,
        "f": 50364417
      },
      "n": "Title",
      "d": 413601,
      "h": 167504138145,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(167504138145),
//--TRIMMABLE-BOUNDARY-START(25770217377),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129955745,
        "f": 50364417
      },
      "n": "Description",
      "d": 413601,
      "h": 25770217377,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770217377),
//--TRIMMABLE-BOUNDARY-START(137439367073),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309824929,
        "f": 50364417
      },
      "n": "Icon",
      "d": 413601,
      "h": 137439367073,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439367073),
//--TRIMMABLE-BOUNDARY-START(163209170849),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669563297,
        "f": 50364417
      },
      "n": "Theme",
      "d": 413601,
      "h": 163209170849,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209170849),
//--TRIMMABLE-BOUNDARY-START(34360151969),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719890337,
        "f": 50364417
      },
      "n": "Features",
      "d": 413601,
      "h": 34360151969,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360151969),
//--TRIMMABLE-BOUNDARY-START(21475250081),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540021153,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 413601,
      "h": 21475250081,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475250081),
//--TRIMMABLE-BOUNDARY-START(150324268961),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489694113,
        "f": 50364417
      },
      "n": "Order",
      "d": 413601,
      "h": 150324268961,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324268961),
//--TRIMMABLE-BOUNDARY-START(4295380897),
    {
      "p": 544673,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950086561,
        "f": 50331650
      },
      "n": "_Service",
      "d": 413601,
      "h": 4295380897,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295380897),
//--TRIMMABLE-BOUNDARY-START(158914203553),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079628705,
        "f": 50364417
      },
      "n": "Service",
      "d": 413601,
      "h": 158914203553,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914203553),
//--TRIMMABLE-BOUNDARY-START(171799105441),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849432481,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 413601,
      "h": 171799105441,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(171799105441)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(133144399777),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 413601,
      "h": 133144399777,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(133144399777),
//--TRIMMABLE-BOUNDARY-START(30065184673),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 413601,
      "h": 30065184673,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065184673),
//--TRIMMABLE-BOUNDARY-START(154619236257),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 413601,
      "h": 154619236257,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154619236257)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(146029301665),
    {
      "t": 65309014,
      "n": "NewsTheme",
      "d": 413601,
      "h": 146029301665,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029301665)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180282785),
    {
      "p": [
        {
          "n": "service",
          "p": 544673
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 413601,
      "h": 17180282785,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180282785)
  ],
  "h": 413601
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Client.Services.CommunityNewsAggregatorApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Client${separator}Services${separator}CommunityNewsAggregatorApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(413601)
        
        

        //--TRIMMABLE-BOUNDARY-START(282529)
        $asm.$cls(`$GeIp.LCCNCP.CommunityNewsAggregatorApp`, ($self) => class CommunityNewsAggregatorApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(158914072481)
            /*CommunityNewsAggregatorService*/ NewsAggregatorService = null;
            //--TRIMMABLE-BOUNDARY-END(158914072481)
            
            //--TRIMMABLE-BOUNDARY-START(154619105185)
            /*CommunityNewsAggregatorApplication*/ NewsAggregatorApplication = null;
            //--TRIMMABLE-BOUNDARY-END(154619105185)
            
            //--TRIMMABLE-BOUNDARY-START(21475119009)
            /*ICommunityClientApplication */ get Application()
            {
                return this.NewsAggregatorApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(21475119009)
            
            //--TRIMMABLE-BOUNDARY-START(34360020897)
            /*CommunityPostView */ get CardView()
            {
                return 4/*CommunityPostView.CardMediaFirst*/;
            }
            //--TRIMMABLE-BOUNDARY-END(34360020897)
            
            //--TRIMMABLE-BOUNDARY-START(38654988193)
            /*int? */ get CardWidthHint()
            {
                return 250;
            }
            //--TRIMMABLE-BOUNDARY-END(38654988193)
            
            //--TRIMMABLE-BOUNDARY-START(30065053601)
            /*int? */ get CardSpaceHint()
            {
                return 20;
            }
            //--TRIMMABLE-BOUNDARY-END(30065053601)
            
            //--TRIMMABLE-BOUNDARY-START(184683876257)
            /*UseDefaultPage */ get UsePage()
            {
                return super.UsePage & ~2/*UseDefaultPage.PostView*/ & ~2048/*UseDefaultPage.Trending*/ & ~16/*UseDefaultPage.EditPost*/ & ~32/*UseDefaultPage.EditPostButton*/ & ~64/*UseDefaultPage.EditCategory*/ & ~128/*UseDefaultPage.EditCategoryButton*/ & ~512/*UseDefaultPage.Help*/ & ~1024/*UseDefaultPage.Profile*/;
            }
            //--TRIMMABLE-BOUNDARY-END(184683876257)
            
            //--TRIMMABLE-BOUNDARY-START(146029170593)
            /*string? */ get HomePageTitle()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029170593)
            
            //--TRIMMABLE-BOUNDARY-START(163209039777)
            /*string */ get OptimizedComponentName()
            {
                return "communitynewsaggregatorapp communitydefaultpages";
            }
            //--TRIMMABLE-BOUNDARY-END(163209039777)
            
            //--TRIMMABLE-BOUNDARY-START(150324137889)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324137889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.NewsAggregatorService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GeIp.LCCNCS.CommunityNewsAggregatorService, serviceProvider);
                this.NewsAggregatorApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GeIp.LCCNCS.CommunityNewsAggregatorApplication, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(150324137889)
            
            //--TRIMMABLE-BOUNDARY-START(25770086305)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770086305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
            }
            //--TRIMMABLE-BOUNDARY-END(25770086305)
            
            //--TRIMMABLE-BOUNDARY-START(141734203297)
            /*RenderFragment */ get Home()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(1, "div");
                    __builder2.AddAttribute$5(2, "Class", "mgt pd");
                    __builder2.AddAttribute$5(3, "style", "background-color:" + $.$strNN(($.$strNN(this.NewsAggregatorApplication.Theme.BackgroundColor) + "10")));
                    __builder2.AddMarkupContent(4, "<p class=\"mgt-0\">\r\n            While Zoey has its own <a href=\"/Article\">Article</a> system built on modern principles and technologies,\r\n            we also want to give you the flexibility of having all your news in one place, instead of hunting for them around the net.\r\n        </p>\r\n        ");
                    __builder2.AddMarkupContent(5, "<p>We neither copy, own nor claim to own a copyright to any of the content presented in this Zoey section.</p>\r\n        ");
                    __builder2.AddMarkupContent(6, "<p>Do you want your news feed to appear here too? Please contact us.</p>\r\n        ");
                    __builder2.AddMarkupContent(7, "<p>\r\n            Zoey News Aggregator is powered by the following news RSS services.\r\n        </p>\r\n        ");
                    __builder2.OpenElement(8, "div");
                    __builder2.AddAttribute$5(9, "class", "grid colm-05 gap-1");
                    if (this.NewsAggregatorService.Settings !== null)
                    {
                        let $en1 = this.NewsAggregatorService.Settings.Channels.SCG$IEnumerable$$$GetEnumerator();
                        while ($en1.SC$1$IEnumerator$MoveNext())
                        {
                            let channel = $en1.SCG$IEnumerator$$$Current;
                            {
                                __builder2.OpenElement(10, "div");
                                __builder2.AddAttribute$5(11, "class", "text-center clip");
                                __builder2.OpenElement(12, "a");
                                __builder2.AddAttribute$5(13, "href", channel.OfficialLink);
                                __builder2.AddAttribute$5(14, "target", "_blank");
                                __builder2.AddAttribute$5(15, "class", "hx-05 bd corner-5 clip d-block bd");
                                __builder2.OpenElement(16, "img");
                                __builder2.AddAttribute$5(17, "src", this.ResolvePath(channel.ChannelIcon, true, false, false));
                                __builder2.AddAttribute$5(18, "class", "mawf mahf");
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(19, "\r\n                        ");
                                __builder2.OpenElement(20, "p");
                                __builder2.AddAttribute$5(21, "class", "mgb-0 mgt");
                                __builder2.AddContent$4(22, channel.ChannelName);
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                            }
                        }
                    }
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(23, "\r\n");
                }, $ASPdZk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":282529,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(141734203297)
            
            //--TRIMMABLE-BOUNDARY-START(17180151713)
            /*RenderFragment */ get AppendPages()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(24, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), 25);
                    __builder2.AddComponentParameter(26, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`News/${$.$strNN("***"/*RoutePath.OneOrMorePathSegment*/)}`)));
                    __builder2.AddComponentParameter(27, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~15/*CommunityLayoutFeatures.Pad*/, null, null, true);
                    }), $pvgrPj ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$h}],"n":"","d":282529,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(28, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(29, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e.Title;
                            }, $Xvekpe ??= {"r":131073,"p":[{"n":"e","p":483061}],"n":"","d":282529,"h":0,"f":17825794}), true));
                        }, $vuNAAg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":282529,"h":0,"f":17825794});
                    }), $YfscYk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel)).$h}],"n":"","d":282529,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(30, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(31, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return this.GetIframe(e);
                            }, $VKVWya ??= {"r":6881395,"p":[{"n":"e","p":483061}],"n":"","d":282529,"h":0,"f":17825794}), null, true));
                        }, $NVYTYc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":282529,"h":0,"f":17825794});
                    }), $NJkEqb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel)).$h}],"n":"","d":282529,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(32, "\r\n    ");
                }, $msqFab ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":282529,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(17180151713)
            
            //--TRIMMABLE-BOUNDARY-START(137439236001)
            /*RenderFragment */ GetIframe(/*CommunityNewsAggregatorNewsModel*/ news)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439236001);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(33, "iframe");
                        __builder2.AddAttribute$5(34, "src", news.AttributionSource.Link);
                        __builder2.AddAttribute$5(35, "class", "wf hf bd-0 bg-white");
                        __builder2.AddAttribute$5(36, "sandbox", "allow-scripts allow-same-origin");
                        __builder2.CloseElement();
                    }, $UdfcYh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":282529,"h":0,"f":17825794});
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439236001)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885184417)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885184417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885184417)
            
            //--TRIMMABLE-BOUNDARY-START(12885184417)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12885184417)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(158914072481)
                this.NewsAggregatorService = null;
                //--TRIMMABLE-BOUNDARY-END(158914072481)
                
                //--TRIMMABLE-BOUNDARY-START(154619105185)
                this.NewsAggregatorApplication = null;
                //--TRIMMABLE-BOUNDARY-END(154619105185)
                
            }
            static $h = 282529;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(158914072481),
    {
      "p": 544673,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964399521,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180388908961,
        "f": 83886081
      },
      "n": "NewsAggregatorService",
      "d": 282529,
      "h": 158914072481,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914072481),
//--TRIMMABLE-BOUNDARY-START(154619105185),
    {
      "p": 413601,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374464929,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171798974369,
        "f": 83886081
      },
      "n": "NewsAggregatorApplication",
      "d": 282529,
      "h": 154619105185,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619105185),
//--TRIMMABLE-BOUNDARY-START(21475119009),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834857377,
        "f": 50364420
      },
      "n": "Application",
      "d": 282529,
      "h": 21475119009,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(21475119009),
//--TRIMMABLE-BOUNDARY-START(34360020897),
    {
      "p": 31299008,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014726561,
        "f": 50364420
      },
      "n": "CardView",
      "d": 282529,
      "h": 34360020897,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(34360020897),
//--TRIMMABLE-BOUNDARY-START(38654988193),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604661153,
        "f": 50364420
      },
      "n": "CardWidthHint",
      "d": 282529,
      "h": 38654988193,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(38654988193),
//--TRIMMABLE-BOUNDARY-START(30065053601),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424791969,
        "f": 50364420
      },
      "n": "CardSpaceHint",
      "d": 282529,
      "h": 30065053601,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(30065053601),
//--TRIMMABLE-BOUNDARY-START(184683876257),
    {
      "p": 34379200,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144268705,
        "f": 50364420
      },
      "n": "UsePage",
      "d": 282529,
      "h": 184683876257,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(184683876257),
//--TRIMMABLE-BOUNDARY-START(146029170593),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784530337,
        "f": 50364420
      },
      "n": "HomePageTitle",
      "d": 282529,
      "h": 146029170593,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(146029170593),
//--TRIMMABLE-BOUNDARY-START(163209039777),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554334113,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 282529,
      "h": 163209039777,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209039777),
//--TRIMMABLE-BOUNDARY-START(141734203297),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194595745,
        "f": 50364420
      },
      "n": "Home",
      "d": 282529,
      "h": 141734203297,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(141734203297),
//--TRIMMABLE-BOUNDARY-START(17180151713),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244922785,
        "f": 50364420
      },
      "n": "AppendPages",
      "d": 282529,
      "h": 17180151713,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(17180151713)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(150324137889),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 282529,
      "h": 150324137889,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324137889),
//--TRIMMABLE-BOUNDARY-START(25770086305),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 282529,
      "h": 25770086305,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770086305),
//--TRIMMABLE-BOUNDARY-START(137439236001),
    {
      "r": 6881395,
      "p": [
        {
          "n": "news",
          "p": 483061
        }
      ],
      "n": "GetIframe",
      "d": 282529,
      "h": 137439236001,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137439236001)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885184417),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 282529,
      "h": 12885184417,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885184417)
  ],
  "h": 282529
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Client.Pages.CommunityNewsAggregatorApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Client${separator}Pages${separator}CommunityNewsAggregatorApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(282529)
        
        

        //--TRIMMABLE-BOUNDARY-START(544673)
        $asm.$cls(`$GeIp.LCCNCS.CommunityNewsAggregatorService`, ($self) => class CommunityNewsAggregatorService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8590479265)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590479265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590479265)
            
            //--TRIMMABLE-BOUNDARY-START(12885446561)
            /*ApplicationServiceFeatures */ get Features()
            {
                return super.Features & ~32/*ApplicationServiceFeatures.RequiresRootServiceToLoad*/;
            }
            //--TRIMMABLE-BOUNDARY-END(12885446561)
            
            //--TRIMMABLE-BOUNDARY-START(47245184929)
            /*CommunityNewsAggregatorGlobalSettings?*/ Settings = null;
            //--TRIMMABLE-BOUNDARY-END(47245184929)
            
            //--TRIMMABLE-BOUNDARY-START(34360283041)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360283041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t1, $r1;
                        let $t2, $r2;
                        ($t1 = super.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        this.Settings = ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService, $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings)))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server.LCCNCS$ICommunityNewsAggregatorRemoteService$GetGlobalSettings();
                        }, $wQSuAf ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings)).$h,"p":[{"n":"server","p":1072885}],"n":"","d":544673,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    });
                }, $iQTdrj ??= {"r":181338113,"n":"","d":544673,"h":0,"f":17829890}), false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(34360283041)
            
            static $h = 544673;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885446561),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475381153,
        "f": 50364417
      },
      "n": "Features",
      "d": 544673,
      "h": 12885446561,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885446561),
//--TRIMMABLE-BOUNDARY-START(47245184929),
    {
      "p": 1203957,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065315745,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950217633,
        "f": 83886082
      },
      "n": "Settings",
      "d": 544673,
      "h": 47245184929,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245184929)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360283041),
    {
      "r": 181338113,
      "n": "Load",
      "d": 544673,
      "h": 34360283041,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360283041)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590479265),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 544673,
      "h": 8590479265,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590479265)
  ],
  "h": 544673
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Client.Services.CommunityNewsAggregatorService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Client${separator}Services${separator}CommunityNewsAggregatorService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(544673)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.NewsAggregator.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(20385)
