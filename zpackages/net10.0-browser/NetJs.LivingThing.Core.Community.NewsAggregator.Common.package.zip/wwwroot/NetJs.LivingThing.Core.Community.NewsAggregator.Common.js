
//--TRIMMABLE-BOUNDARY-START(24309)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $Engdcd;
    let $Fepzgl;
    let $KbegUc;
    let $DmHLef;
    let $vrFfFe;
    let $QMiBIc;
    let $sFKIal;
    let $ppipMc;
    let $iyvWBi;
    let $nhKhHe;
    let $Nyopug;
    let $ErTgsg;
    let $pZmUOk;
    let $dWlCgd;
    let $qaacWb;
    let $WYbTog;
    let $KgaMCh;
    let $pvTGgb;
    let $kSQZCf;
    let $kOwJKa;
    let $fIosUc;
    let $nFMZFe;
    let $mHepEb;
    let $xmolqa;
    let $KClvPa;
    let $bUzrVc;
    let $hGxyZf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.NewsAggregator.Common", 
    {
  "h": 24309,
  "f": "LivingThing.Core.Community.NewsAggregator.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.NewsAggregator.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.NewsAggregator.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1793781)
        $asm.$cls(`$anJf.LCCNCS$2.CommunityNewsAggregatorStatesCustomAttributesProvider`, ($self) => class CommunityNewsAggregatorStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296761077)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296761077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296761077)
            
            static $h = 1793781;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296761077),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1793781,
      "h": 4296761077,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296761077)
  ],
  "h": 1793781
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.States.CommunityNewsAggregatorStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}States${separator}CommunityNewsAggregatorStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1793781)
        
        

        //--TRIMMABLE-BOUNDARY-START(1531637)
        $asm.$cls(`$anJf.LCCNCS$1.CommunityNewsAggregatorSettingsCustomAttributesProvider`, ($self) => class CommunityNewsAggregatorSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296498933)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296498933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296498933)
            
            static $h = 1531637;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296498933),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1531637,
      "h": 4296498933,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296498933)
  ],
  "h": 1531637
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Settings${separator}CommunityNewsAggregatorSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1531637)
        
        

        //--TRIMMABLE-BOUNDARY-START(89845)
        $asm.$cls(`$anJf.LCCNC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295057141)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295057141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$anJf.LCCNCM.CommunityNewsAggregatorModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$anJf.LCCNCM.CommunityNewsAggregatorModelCustomAttributesProvider, $.$anJf.LCCNCM.CommunityNewsAggregatorModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModelCustomAttributesProvider, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettingsCustomAttributesProvider, $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$anJf.LCCNCS$1.CommunityNewsAggregatorSettingsCustomAttributesProvider, $.$anJf.LCCNCS$1.CommunityNewsAggregatorSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$anJf.LCCNCS$2.CommunityNewsAggregatorStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$anJf.LCCNCS$2.CommunityNewsAggregatorStatesCustomAttributesProvider, $.$anJf.LCCNCS$2.CommunityNewsAggregatorStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295057141)
            
            static $h = 89845;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295057141),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 89845,
      "h": 4295057141,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295057141)
  ],
  "h": 89845
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(89845)
        
        

        //--TRIMMABLE-BOUNDARY-START(286453)
        $asm.$cls(`$anJf.LCCNCM.CommunityNewsAggregatorModelCustomAttributesProvider`, ($self) => class CommunityNewsAggregatorModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295253749)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295253749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings, $.$anJf.LCCNCS$2.CommunityNewsAggregatorStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295253749)
            
            static $h = 286453;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295253749),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 286453,
      "h": 4295253749,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295253749)
  ],
  "h": 286453
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Models${separator}CommunityNewsAggregatorModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(286453)
        
        

        //--TRIMMABLE-BOUNDARY-START(1990389)
        $asm.$cls(`$anJf.LCCNC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296957685)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296957685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$anJf.LCCNCM.CommunityNewsAggregatorModelTypeDescriptorBuilder.Register();
                $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModelTypeDescriptorBuilder.Register();
                $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettingsTypeDescriptorBuilder.Register();
                $.$anJf.LCCNCS$1.CommunityNewsAggregatorSettingsTypeDescriptorBuilder.Register();
                $.$anJf.LCCNCS$2.CommunityNewsAggregatorStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296957685)
            
            static $h = 1990389;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296957685),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1990389,
      "h": 4296957685,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296957685)
  ],
  "h": 1990389
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1990389)
        
        

        //--TRIMMABLE-BOUNDARY-START(1269493)
        $asm.$cls(`$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettingsCustomAttributesProvider`, ($self) => class CommunityNewsAggregatorGlobalSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296236789)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296236789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentGlobalSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296236789)
            
            static $h = 1269493;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296236789),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1269493,
      "h": 4296236789,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296236789)
  ],
  "h": 1269493
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorGlobalSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Settings${separator}CommunityNewsAggregatorGlobalSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1269493)
        
        

        //--TRIMMABLE-BOUNDARY-START(745205)
        $asm.$cls(`$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor`, ($self) => class CommunityNewsAggregatorRSSChannelDescriptor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68720221941)
            /*string*/ ChannelName = null;
            //--TRIMMABLE-BOUNDARY-END(68720221941)
            
            //--TRIMMABLE-BOUNDARY-START(197569240821)
            /*string*/ OfficialLink = null;
            //--TRIMMABLE-BOUNDARY-END(197569240821)
            
            //--TRIMMABLE-BOUNDARY-START(64425254645)
            /*string*/ ChannelIcon = null;
            //--TRIMMABLE-BOUNDARY-END(64425254645)
            
            //--TRIMMABLE-BOUNDARY-START(73015189237)
            /*string*/ ChannelUrl = null;
            //--TRIMMABLE-BOUNDARY-END(73015189237)
            
            //--TRIMMABLE-BOUNDARY-START(60130287349)
            /*string*/ Channel = null;
            //--TRIMMABLE-BOUNDARY-END(60130287349)
            
            //--TRIMMABLE-BOUNDARY-START(188979306229)
            /*string*/ Item$1 = null;
            //--TRIMMABLE-BOUNDARY-END(188979306229)
            
            //--TRIMMABLE-BOUNDARY-START(309238390517)
            /*string*/ Summary = null;
            //--TRIMMABLE-BOUNDARY-END(309238390517)
            
            //--TRIMMABLE-BOUNDARY-START(77310156533)
            /*string*/ Content = null;
            //--TRIMMABLE-BOUNDARY-END(77310156533)
            
            //--TRIMMABLE-BOUNDARY-START(193274273525)
            /*string*/ Link = null;
            //--TRIMMABLE-BOUNDARY-END(193274273525)
            
            //--TRIMMABLE-BOUNDARY-START(201864208117)
            /*string*/ PubishDate = null;
            //--TRIMMABLE-BOUNDARY-END(201864208117)
            
            //--TRIMMABLE-BOUNDARY-START(313533357813)
            /*string*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(313533357813)
            
            //--TRIMMABLE-BOUNDARY-START(184684338933)
            /*string*/ Icon = null;
            //--TRIMMABLE-BOUNDARY-END(184684338933)
            
            //--TRIMMABLE-BOUNDARY-START(317828325109)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828325109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ChannelName;
            }
            //--TRIMMABLE-BOUNDARY-END(317828325109)
            
            //--TRIMMABLE-BOUNDARY-START(55835320053)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835320053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835320053)
            
            //--TRIMMABLE-BOUNDARY-START(55835320053)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(55835320053)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60130287349)
                this.Channel = "channel";
                //--TRIMMABLE-BOUNDARY-END(60130287349)
                
                //--TRIMMABLE-BOUNDARY-START(188979306229)
                this.Item$1 = "item";
                //--TRIMMABLE-BOUNDARY-END(188979306229)
                
                //--TRIMMABLE-BOUNDARY-START(309238390517)
                this.Summary = "description";
                //--TRIMMABLE-BOUNDARY-END(309238390517)
                
                //--TRIMMABLE-BOUNDARY-START(77310156533)
                this.Content = "content:encoded";
                //--TRIMMABLE-BOUNDARY-END(77310156533)
                
                //--TRIMMABLE-BOUNDARY-START(193274273525)
                this.Link = "link";
                //--TRIMMABLE-BOUNDARY-END(193274273525)
                
                //--TRIMMABLE-BOUNDARY-START(201864208117)
                this.PubishDate = "pubDate";
                //--TRIMMABLE-BOUNDARY-END(201864208117)
                
                //--TRIMMABLE-BOUNDARY-START(313533357813)
                this.Title = "title";
                //--TRIMMABLE-BOUNDARY-END(313533357813)
                
                //--TRIMMABLE-BOUNDARY-START(184684338933)
                this.Icon = "enclosure";
                //--TRIMMABLE-BOUNDARY-END(184684338933)
                
            }
            static $h = 745205;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720221941),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079960309,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227634011893,
        "f": 83886081
      },
      "n": "ChannelName",
      "d": 745205,
      "h": 68720221941,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720221941),
//--TRIMMABLE-BOUNDARY-START(197569240821),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619567861,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279173619445,
        "f": 83886081
      },
      "n": "OfficialLink",
      "d": 745205,
      "h": 197569240821,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569240821),
//--TRIMMABLE-BOUNDARY-START(64425254645),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490025717,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044077301,
        "f": 83886081
      },
      "n": "ChannelIcon",
      "d": 745205,
      "h": 64425254645,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 14,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425254645),
//--TRIMMABLE-BOUNDARY-START(73015189237),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669894901,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236223946485,
        "f": 83886081
      },
      "n": "ChannelUrl",
      "d": 745205,
      "h": 73015189237,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015189237),
//--TRIMMABLE-BOUNDARY-START(60130287349),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900091125,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454142709,
        "f": 83886081
      },
      "n": "Channel",
      "d": 745205,
      "h": 60130287349,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130287349),
//--TRIMMABLE-BOUNDARY-START(188979306229),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439698677,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261993750261,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 745205,
      "h": 188979306229,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188979306229),
//--TRIMMABLE-BOUNDARY-START(309238390517),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799437045,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353488629,
        "f": 83886081
      },
      "n": "Summary",
      "d": 745205,
      "h": 309238390517,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309238390517),
//--TRIMMABLE-BOUNDARY-START(77310156533),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259829493,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244813881077,
        "f": 83886081
      },
      "n": "Content",
      "d": 745205,
      "h": 77310156533,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310156533),
//--TRIMMABLE-BOUNDARY-START(193274273525),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029633269,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270583684853,
        "f": 83886081
      },
      "n": "Link",
      "d": 745205,
      "h": 193274273525,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274273525),
//--TRIMMABLE-BOUNDARY-START(201864208117),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209502453,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763554037,
        "f": 83886081
      },
      "n": "PubishDate",
      "d": 745205,
      "h": 201864208117,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864208117),
//--TRIMMABLE-BOUNDARY-START(313533357813),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389371637,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943423221,
        "f": 83886081
      },
      "n": "Title",
      "d": 745205,
      "h": 313533357813,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(313533357813),
//--TRIMMABLE-BOUNDARY-START(184684338933),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849764085,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253403815669,
        "f": 83886081
      },
      "n": "Icon",
      "d": 745205,
      "h": 184684338933,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184684338933)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(317828325109),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 745205,
      "h": 317828325109,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(317828325109)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835320053),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 745205,
      "h": 55835320053,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835320053)
  ],
  "h": 745205
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorRSSChannelDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Models${separator}CommunityNewsAggregatorRSSChannelDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(745205)
        
        

        //--TRIMMABLE-BOUNDARY-START(155381)
        $asm.$cls(`$anJf.LCCNC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295122677)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295122677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$anJf.LCCNCS.ICommunityNewsAggregatorFeedRemoteService, $.$anJf.LCCNCS.ICommunityNewsAggregatorFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$anJf.LCCNCS.ICommunityNewsAggregatorFeedRemoteService_Mocking().$ctor$3(impl);
                }, $Engdcd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":155381,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$anJf.LCCNCS.ICommunityNewsAggregatorFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$anJf.LCCNCS.ICommunityNewsAggregatorFeedRemoteService_Mocking().$ctor$3(impl);
                }, $Fepzgl ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":155381,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService, $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking().$ctor$3(impl);
                }, $KbegUc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":155381,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking().$ctor$3(impl);
                }, $DmHLef ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":155381,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking().$ctor$3(impl);
                }, $vrFfFe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":155381,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking().$ctor$3(impl);
                }, $QMiBIc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":155381,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking().$ctor$3(impl);
                }, $sFKIal ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":155381,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking().$ctor$3(impl);
                }, $ppipMc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":155381,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking().$ctor$3(impl);
                }, $iyvWBi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":155381,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking().$ctor$3(impl);
                }, $nhKhHe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":155381,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295122677)
            
            static $h = 155381;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295122677),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 155381,
      "h": 4295122677,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295122677)
  ],
  "h": 155381
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(155381)
        
        

        //--TRIMMABLE-BOUNDARY-START(417525)
        $asm.$cls(`$anJf.LCCNCM.CommunityNewsAggregatorModelTypeDescriptorBuilder`, ($self) => class CommunityNewsAggregatorModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590352117)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590352117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$anJf.LCCNCM.CommunityNewsAggregatorModelTypeDescriptor()
                        const $t1 = $.$anJf.LCCNCM.CommunityNewsAggregatorModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Nyopug ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":417525,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$anJf.LCCNCM.CommunityNewsAggregatorModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590352117)
            
            //--TRIMMABLE-BOUNDARY-START(4295384821)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295384821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295384821)
            
            //--TRIMMABLE-BOUNDARY-START(4295384821)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295384821)
            
            static $h = 417525;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590352117),
    {
      "r": 65537,
      "n": "Register",
      "d": 417525,
      "h": 8590352117,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590352117)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295384821),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 417525,
      "h": 4295384821,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295384821)
  ],
  "h": 417525
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Models${separator}CommunityNewsAggregatorModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(417525)
        
        

        //--TRIMMABLE-BOUNDARY-START(1662709)
        $asm.$cls(`$anJf.LCCNCS$1.CommunityNewsAggregatorSettingsTypeDescriptorBuilder`, ($self) => class CommunityNewsAggregatorSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591597301)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591597301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$anJf.LCCNCS$1.CommunityNewsAggregatorSettingsTypeDescriptor()
                        const $t1 = $.$anJf.LCCNCS$1.CommunityNewsAggregatorSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $pZmUOk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1662709,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591597301)
            
            //--TRIMMABLE-BOUNDARY-START(4296630005)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296630005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296630005)
            
            //--TRIMMABLE-BOUNDARY-START(4296630005)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296630005)
            
            static $h = 1662709;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591597301),
    {
      "r": 65537,
      "n": "Register",
      "d": 1662709,
      "h": 8591597301,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591597301)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296630005),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1662709,
      "h": 4296630005,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296630005)
  ],
  "h": 1662709
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Settings${separator}CommunityNewsAggregatorSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1662709)
        
        

        //--TRIMMABLE-BOUNDARY-START(1400565)
        $asm.$cls(`$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettingsTypeDescriptorBuilder`, ($self) => class CommunityNewsAggregatorGlobalSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591335157)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591335157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettingsTypeDescriptor()
                        const $t1 = $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorGlobalSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $kSQZCf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1400565,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591335157)
            
            //--TRIMMABLE-BOUNDARY-START(4296367861)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296367861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296367861)
            
            //--TRIMMABLE-BOUNDARY-START(4296367861)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296367861)
            
            static $h = 1400565;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591335157),
    {
      "r": 65537,
      "n": "Register",
      "d": 1400565,
      "h": 8591335157,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591335157)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296367861),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1400565,
      "h": 4296367861,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296367861)
  ],
  "h": 1400565
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorGlobalSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Settings${separator}CommunityNewsAggregatorGlobalSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1400565)
        
        

        //--TRIMMABLE-BOUNDARY-START(548597)
        $asm.$cls(`$anJf.LCCNCM.CommunityNewsAggregatorNewsModelCustomAttributesProvider`, ($self) => class CommunityNewsAggregatorNewsModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295515893)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295515893)
            
            //--TRIMMABLE-BOUNDARY-START(8590483189)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590483189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Account", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $qaacWb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":548597,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $WYbTog ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":548597,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590483189)
            
            static $h = 548597;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590483189),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 548597,
      "h": 8590483189,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590483189)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295515893),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 548597,
      "h": 4295515893,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295515893)
  ],
  "h": 548597
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Models${separator}CommunityNewsAggregatorNewsModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(548597)
        
        

        //--TRIMMABLE-BOUNDARY-START(1924853)
        $asm.$cls(`$anJf.LCCNCS$2.CommunityNewsAggregatorStatesTypeDescriptorBuilder`, ($self) => class CommunityNewsAggregatorStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591859445)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591859445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$anJf.LCCNCS$2.CommunityNewsAggregatorStatesTypeDescriptor()
                        const $t1 = $.$anJf.LCCNCS$2.CommunityNewsAggregatorStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.NewsAggregator.Common.States.CommunityNewsAggregatorStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KgaMCh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1924853,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$anJf.LCCNCS$2.CommunityNewsAggregatorStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591859445)
            
            //--TRIMMABLE-BOUNDARY-START(4296892149)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296892149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296892149)
            
            //--TRIMMABLE-BOUNDARY-START(4296892149)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296892149)
            
            static $h = 1924853;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591859445),
    {
      "r": 65537,
      "n": "Register",
      "d": 1924853,
      "h": 8591859445,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591859445)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296892149),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1924853,
      "h": 4296892149,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296892149)
  ],
  "h": 1924853
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.States.CommunityNewsAggregatorStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}States${separator}CommunityNewsAggregatorStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1924853)
        
        

        //--TRIMMABLE-BOUNDARY-START(679669)
        $asm.$cls(`$anJf.LCCNCM.CommunityNewsAggregatorNewsModelTypeDescriptorBuilder`, ($self) => class CommunityNewsAggregatorNewsModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590614261)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590614261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModelTypeDescriptor()
                        const $t1 = $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $mHepEb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":679669,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590614261)
            
            //--TRIMMABLE-BOUNDARY-START(4295646965)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295646965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295646965)
            
            //--TRIMMABLE-BOUNDARY-START(4295646965)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295646965)
            
            static $h = 679669;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590614261),
    {
      "r": 65537,
      "n": "Register",
      "d": 679669,
      "h": 8590614261,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590614261)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295646965),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 679669,
      "h": 4295646965,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295646965)
  ],
  "h": 679669
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Models${separator}CommunityNewsAggregatorNewsModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(679669)
        
        

        //--TRIMMABLE-BOUNDARY-START(876277)
        $asm.$cls(`$anJf.LCCNC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590810869)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590810869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, 8193/*PostTypes.NewsAggregatorNews*/);
                $.$anJf.LCCNC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$anJf.LCCNC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$anJf.LCCNC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590810869)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$anJf.LCCNC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295843573)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295843573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295843573)
            
            //--TRIMMABLE-BOUNDARY-START(4295843573)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295843573)
            
            static $h = 876277;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590810869),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 876277,
      "h": 8590810869,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590810869)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295843573),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 876277,
      "h": 4295843573,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295843573)
  ],
  "h": 876277
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(876277)
        
        

        //--TRIMMABLE-BOUNDARY-START(810741)
        $asm.$cls(`$anJf.LCCNCM.CommunityNewsAggregatorUserPreference`, ($self) => class CommunityNewsAggregatorUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4295778037)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295778037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295778037)
            
            //--TRIMMABLE-BOUNDARY-START(4295778037)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295778037)
            
            static $h = 810741;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295778037),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 810741,
      "h": 4295778037,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295778037)
  ],
  "h": 810741
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Models${separator}CommunityNewsAggregatorUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(810741)
        
        

        //--TRIMMABLE-BOUNDARY-START(1203957)
        $asm.$cls(`$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings`, ($self) => class CommunityNewsAggregatorGlobalSettings extends $.$Iaui.LCFCMS.ComponentGlobalSettings
        {
            //--TRIMMABLE-BOUNDARY-START(12886105845)
            /*IEnumerable<CommunityNewsAggregatorRSSChannelDescriptor>*/ Channels = null;
            //--TRIMMABLE-BOUNDARY-END(12886105845)
            
            //--TRIMMABLE-BOUNDARY-START(8591138549)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591138549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591138549)
            
            //--TRIMMABLE-BOUNDARY-START(8591138549)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8591138549)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12886105845)
                this.Channels = $.$sl.SL.Enumerable.Empty($.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor);
                //--TRIMMABLE-BOUNDARY-END(12886105845)
                
            }
            static $h = 1203957;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentGlobalSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886105845),
    {
      "p": $.$$.SCG.IEnumerable$$($.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476040437,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065975029,
        "f": 83886081
      },
      "n": "Channels",
      "d": 1203957,
      "h": 12886105845,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886105845)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591138549),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1203957,
      "h": 8591138549,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591138549)
  ],
  "h": 1203957
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IGlobalSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorGlobalSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Settings${separator}CommunityNewsAggregatorGlobalSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1203957)
        
        

        //--TRIMMABLE-BOUNDARY-START(1466101)
        $asm.$cls(`$anJf.LCCNCS$1.CommunityNewsAggregatorSettings`, ($self) => class CommunityNewsAggregatorSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296433397)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296433397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296433397)
            
            //--TRIMMABLE-BOUNDARY-START(4296433397)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296433397)
            
            static $h = 1466101;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296433397),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1466101,
      "h": 4296433397,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296433397)
  ],
  "h": 1466101
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Settings${separator}CommunityNewsAggregatorSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1466101)
        
        

        //--TRIMMABLE-BOUNDARY-START(1728245)
        $asm.$cls(`$anJf.LCCNCS$2.CommunityNewsAggregatorStates`, ($self) => class CommunityNewsAggregatorStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296695541)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296695541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296695541)
            
            //--TRIMMABLE-BOUNDARY-START(4296695541)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296695541)
            
            static $h = 1728245;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296695541),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1728245,
      "h": 4296695541,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296695541)
  ],
  "h": 1728245
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.States.CommunityNewsAggregatorStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}States${separator}CommunityNewsAggregatorStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1728245)
        
        

        //--TRIMMABLE-BOUNDARY-START(1335029)
        $asm.$cls(`$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettingsTypeDescriptor`, ($self) => class CommunityNewsAggregatorGlobalSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296302325)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296302325);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettingsTypeDescriptor.GenerateProperties($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings, this, factory);
                    }, $kOwJKa ??= {"r":65537,"n":"","d":1335029,"h":0,"f":17825794}), 0, "CommunityNewsAggregatorGlobalSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.NewsAggregator.Common\\Settings_CommunityNewsAggregatorGlobalSettings_LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorGlobalSettingsTypeDescriptorBuilder.g.cs", "CommunityNewsAggregatorGlobalSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296302325)
            
            //--TRIMMABLE-BOUNDARY-START(12886236917)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886236917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Channels"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings.$type, $.$discardRef(), "Channels", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Channels")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Channels";
                        $i1.DelaredOn = "LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorGlobalSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor), ($.$cast(target, $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings)).Channels);
                        }, $fIosUc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1335029,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Channels = value.AsReference($.$$.SCG.IEnumerable$$($.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor));
                        }, $nFMZFe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1335029,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCMS.ComponentGlobalSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886236917)
            
            //--TRIMMABLE-BOUNDARY-START(17181204213)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorGlobalSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181204213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentGlobalSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentGlobalSettings));
                {
                    /*var*/ let _Channels = _target.Channels;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Channels"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor), $.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor), $.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor, property, $.$ref(() => _Channels, ($v) => _Channels = $v, $.$$.SCG.IEnumerable$$($.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor))))
                    {
                        _target.Channels = _Channels;
                        if (_Channels !== null)
                        {
                            let $en6 = _Channels.SCG$IEnumerable$$$GetEnumerator();
                            while ($en6.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en6.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor), $.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor, property, $.$ref(() => _Channels, ($v) => _Channels = $v, $.$$.SCG.IEnumerable$$($.$anJf.LCCNCM.CommunityNewsAggregatorRSSChannelDescriptor)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181204213)
            
            //--TRIMMABLE-BOUNDARY-START(8591269621)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorGlobalSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591269621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings)))
                {
                    /*var*/ let result = $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591269621)
            
            static $h = 1335029;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886236917),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1335029,
      "h": 12886236917,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886236917),
//--TRIMMABLE-BOUNDARY-START(17181204213),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1203957,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1335029,
      "h": 17181204213,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181204213),
//--TRIMMABLE-BOUNDARY-START(8591269621),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1203957,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1335029,
      "h": 8591269621,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591269621)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296302325),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1335029,
      "h": 4296302325,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296302325)
  ],
  "h": 1335029
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorGlobalSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Settings${separator}CommunityNewsAggregatorGlobalSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1335029)
        
        

        //--TRIMMABLE-BOUNDARY-START(1597173)
        $asm.$cls(`$anJf.LCCNCS$1.CommunityNewsAggregatorSettingsTypeDescriptor`, ($self) => class CommunityNewsAggregatorSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296564469)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296564469);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$anJf.LCCNCS$1.CommunityNewsAggregatorSettingsTypeDescriptor.GenerateProperties($.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings, this, factory);
                    }, $dWlCgd ??= {"r":65537,"n":"","d":1597173,"h":0,"f":17825794}), 0, "CommunityNewsAggregatorSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.NewsAggregator.Common\\Settings_CommunityNewsAggregatorSettings_LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorSettingsTypeDescriptorBuilder.g.cs", "CommunityNewsAggregatorSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296564469)
            
            //--TRIMMABLE-BOUNDARY-START(12886499061)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886499061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886499061)
            
            //--TRIMMABLE-BOUNDARY-START(17181466357)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181466357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181466357)
            
            //--TRIMMABLE-BOUNDARY-START(8591531765)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591531765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings)))
                {
                    /*var*/ let result = $.$anJf.LCCNCS$1.CommunityNewsAggregatorSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591531765)
            
            static $h = 1597173;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886499061),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1597173,
      "h": 12886499061,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886499061),
//--TRIMMABLE-BOUNDARY-START(17181466357),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1466101,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1597173,
      "h": 17181466357,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181466357),
//--TRIMMABLE-BOUNDARY-START(8591531765),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1466101,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1597173,
      "h": 8591531765,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591531765)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296564469),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1597173,
      "h": 4296564469,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296564469)
  ],
  "h": 1597173
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Settings${separator}CommunityNewsAggregatorSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1597173)
        
        

        //--TRIMMABLE-BOUNDARY-START(1859317)
        $asm.$cls(`$anJf.LCCNCS$2.CommunityNewsAggregatorStatesTypeDescriptor`, ($self) => class CommunityNewsAggregatorStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$anJf.LCCNCS$2.CommunityNewsAggregatorStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296826613)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296826613);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$anJf.LCCNCS$2.CommunityNewsAggregatorStatesTypeDescriptor.GenerateProperties($.$anJf.LCCNCS$2.CommunityNewsAggregatorStates, this, factory);
                    }, $pvTGgb ??= {"r":65537,"n":"","d":1859317,"h":0,"f":17825794}), 0, "CommunityNewsAggregatorStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.NewsAggregator.Common\\States_CommunityNewsAggregatorStates_LivingThing.Core.Community.NewsAggregator.Common.States.CommunityNewsAggregatorStatesTypeDescriptorBuilder.g.cs", "CommunityNewsAggregatorStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296826613)
            
            //--TRIMMABLE-BOUNDARY-START(12886761205)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886761205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886761205)
            
            //--TRIMMABLE-BOUNDARY-START(17181728501)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NewsAggregator.Common.States.CommunityNewsAggregatorStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181728501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181728501)
            
            //--TRIMMABLE-BOUNDARY-START(8591793909)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NewsAggregator.Common.States.CommunityNewsAggregatorStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591793909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$anJf.LCCNCS$2.CommunityNewsAggregatorStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$anJf.LCCNCS$2.CommunityNewsAggregatorStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCS$2.CommunityNewsAggregatorStates)))
                {
                    /*var*/ let result = $.$anJf.LCCNCS$2.CommunityNewsAggregatorStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCS$2.CommunityNewsAggregatorStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$anJf.LCCNCS$2.CommunityNewsAggregatorStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCS$2.CommunityNewsAggregatorStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591793909)
            
            static $h = 1859317;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$anJf.LCCNCS$2.CommunityNewsAggregatorStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886761205),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1859317,
      "h": 12886761205,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886761205),
//--TRIMMABLE-BOUNDARY-START(17181728501),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1728245,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1859317,
      "h": 17181728501,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181728501),
//--TRIMMABLE-BOUNDARY-START(8591793909),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1728245,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1859317,
      "h": 8591793909,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591793909)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296826613),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1859317,
      "h": 4296826613,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296826613)
  ],
  "h": 1859317
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$anJf.LCCNCS$2.CommunityNewsAggregatorStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.States.CommunityNewsAggregatorStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}States${separator}CommunityNewsAggregatorStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1859317)
        
        

        //--TRIMMABLE-BOUNDARY-START(483061)
        $asm.$cls(`$anJf.LCCNCM.CommunityNewsAggregatorNewsModel`, ($self) => class CommunityNewsAggregatorNewsModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(42950156021)
            /*PostTypes */ get Type()
            {
                return 8193/*PostTypes.NewsAggregatorNews*/;
            }
            //--TRIMMABLE-BOUNDARY-END(42950156021)
            
            //--TRIMMABLE-BOUNDARY-START(38655188725)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$2(this, null, "News/Post", null, true);
            }
            //--TRIMMABLE-BOUNDARY-END(38655188725)
            
            //--TRIMMABLE-BOUNDARY-START(8590417653)
            /*AccountBaseModel? */ get Account()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180352245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.account !== null)
                {
                    return this.account;
                }
                if (this.AttributionSource.Name !== null)
                {
                    this.account = (() =>
                    {
                        //new $.$LCOv.LCFCPM$1.AccountModel()
                        const $t1 = $.$LCOv.LCFCPM$1.AccountModel;
                        const $i1 = new $t1();
                        $i1.$ctor$8();
                        $i1.Name = this.AttributionSource.Name;
                        $i1.Icon = $.$Iaui.LCFCM.ResourceModel.op_Implicit$2(this.AttributionSource.Icon);
                        return $i1;
                    })();
                }
                return this.account;
            }
            //--TRIMMABLE-BOUNDARY-END(8590417653)
            
            //--TRIMMABLE-BOUNDARY-START(4295450357)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295450357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295450357)
            
            //--TRIMMABLE-BOUNDARY-START(4295450357)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295450357)
            
            static $h = 483061;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950156021),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360221429,
        "f": 50364417
      },
      "n": "Type",
      "d": 483061,
      "h": 42950156021,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950156021),
//--TRIMMABLE-BOUNDARY-START(38655188725),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770286837,
        "f": 50364417
      },
      "n": "Link",
      "d": 483061,
      "h": 38655188725,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655188725),
//--TRIMMABLE-BOUNDARY-START(8590417653),
    {
      "p": 6220212,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180352245,
        "f": 50364417
      },
      "n": "Account",
      "d": 483061,
      "h": 8590417653,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590417653)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295450357),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 483061,
      "h": 4295450357,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295450357)
  ],
  "h": 483061
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Models${separator}CommunityNewsAggregatorNewsModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(483061)
        
        

        //--TRIMMABLE-BOUNDARY-START(941813)
        $asm.$cls(`$anJf.LCCNCS.ICommunityNewsAggregatorFeedRemoteService`, ($self) => class ICommunityNewsAggregatorFeedRemoteService
        {
            static $h = 941813;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 941813,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Services.ICommunityNewsAggregatorFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Services${separator}ICommunityNewsAggregatorFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(941813)
        
        

        //--TRIMMABLE-BOUNDARY-START(1072885)
        $asm.$cls(`$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService`, ($self) => class ICommunityNewsAggregatorRemoteService
        {
            static $h = 1072885;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296040181),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings)).$h,
      "n": "GetGlobalSettings",
      "o": "LCCNCS$ICommunityNewsAggregatorRemoteService$GetGlobalSettings",
      "d": 1072885,
      "h": 4296040181,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296040181)
  ],
  "h": 1072885,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.ICreateDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.IReadDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.IReadManyDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.IUpdateDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.IDeleteDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Services.ICommunityNewsAggregatorRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Services${separator}ICommunityNewsAggregatorRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1072885)
        
        

        //--TRIMMABLE-BOUNDARY-START(1007349)
        $asm.$cls(`$anJf.LCCNCS.ICommunityNewsAggregatorFeedRemoteService_Mocking`, ($self) => class ICommunityNewsAggregatorFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295974645)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295974645);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295974645)
            
            //--TRIMMABLE-BOUNDARY-START(8590941941)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$NewsAggregator$Common$Models$CommunityNewsAggregatorNewsModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590941941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590941941)
            
            static $h = 1007349;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295974645),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1007349,
      "h": 4295974645,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295974645)
  ],
  "h": 1007349
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$anJf.LCCNCS.ICommunityNewsAggregatorFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Services.ICommunityNewsAggregatorFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Services${separator}ICommunityNewsAggregatorFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1007349)
        
        

        //--TRIMMABLE-BOUNDARY-START(1138421)
        $asm.$cls(`$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService_Mocking`, ($self) => class ICommunityNewsAggregatorRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296105717)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296105717);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296105717)
            
            //--TRIMMABLE-BOUNDARY-START(8591073013)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorGlobalSettings>> */ LCCNCS$ICommunityNewsAggregatorRemoteService$GetGlobalSettings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591073013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings).$type;
                    $i1.MethodName = "GetGlobalSettings";
                    return $i1;
                })();
                return this.InvokeAsync($.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorGlobalSettings), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591073013)
            
            //--TRIMMABLE-BOUNDARY-START(12886040309)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$NewsAggregator$Common$Models$CommunityNewsAggregatorNewsModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886040309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type;
                    $i2.MethodName = "Create";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886040309)
            
            //--TRIMMABLE-BOUNDARY-START(21475974901)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$NewsAggregator$Common$Models$CommunityNewsAggregatorNewsModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475974901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type;
                    $i3.MethodName = "ReadMany";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475974901)
            
            //--TRIMMABLE-BOUNDARY-START(25770942197)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$NewsAggregator$Common$Models$CommunityNewsAggregatorNewsModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770942197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type;
                    $i4.MethodName = "ReadSingle";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.WireTransportModel$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770942197)
            
            //--TRIMMABLE-BOUNDARY-START(30065909493)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$NewsAggregator$Common$Models$CommunityNewsAggregatorNewsModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065909493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type;
                    $i5.MethodName = "Update";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30065909493)
            
            //--TRIMMABLE-BOUNDARY-START(17181007605)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181007605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type;
                    $i6.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i6.MethodName = "Delete";
                    return $i6;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181007605)
            
            static $h = 1138421;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296105717),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1138421,
      "h": 4296105717,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296105717)
  ],
  "h": 1138421
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$anJf.LCCNCS.ICommunityNewsAggregatorRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.ICreateDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.IReadDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.IReadManyDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.IUpdateDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD.IDeleteDataService$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Services.ICommunityNewsAggregatorRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Services${separator}ICommunityNewsAggregatorRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1138421)
        
        

        //--TRIMMABLE-BOUNDARY-START(614133)
        $asm.$cls(`$anJf.LCCNCM.CommunityNewsAggregatorNewsModelTypeDescriptor`, ($self) => class CommunityNewsAggregatorNewsModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295581429)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295581429);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModelTypeDescriptor.GenerateProperties($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, this, factory);
                    }, $xmolqa ??= {"r":65537,"n":"","d":614133,"h":0,"f":17825794}), 0, "CommunityNewsAggregatorNewsModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.NewsAggregator.Common\\Models_CommunityNewsAggregatorNewsModel_LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModelTypeDescriptorBuilder.g.cs", "CommunityNewsAggregatorNewsModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295581429)
            
            //--TRIMMABLE-BOUNDARY-START(12885516021)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885516021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel)).Type);
                        }, $KClvPa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":614133,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Link";
                        $i3.DelaredOn = "LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel)).Link);
                        }, $bUzrVc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":614133,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Account"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel.$type, $.$discardRef(), "Account", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Account")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.AccountBaseModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Account";
                        $i5.DelaredOn = "LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$LCOv.LCFCPM$1.AccountBaseModel, ($.$cast(target, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel)).Account);
                        }, $hGxyZf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":614133,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885516021)
            
            //--TRIMMABLE-BOUNDARY-START(17180483317)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180483317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Account = _target.Account;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Account"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.AccountBaseModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Account, ($v) => _Account = $v, $.$LCOv.LCFCPM$1.AccountBaseModel)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180483317)
            
            //--TRIMMABLE-BOUNDARY-START(8590548725)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590548725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel)))
                {
                    /*var*/ let result = $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590548725)
            
            static $h = 614133;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885516021),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 614133,
      "h": 12885516021,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885516021),
//--TRIMMABLE-BOUNDARY-START(17180483317),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 483061,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 614133,
      "h": 17180483317,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180483317),
//--TRIMMABLE-BOUNDARY-START(8590548725),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 483061,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 614133,
      "h": 8590548725,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590548725)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295581429),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 614133,
      "h": 4295581429,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295581429)
  ],
  "h": 614133
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$anJf.LCCNCM.CommunityNewsAggregatorNewsModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorNewsModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Models${separator}CommunityNewsAggregatorNewsModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(614133)
        
        

        //--TRIMMABLE-BOUNDARY-START(220917)
        $asm.$cls(`$anJf.LCCNCM.CommunityNewsAggregatorModel`, ($self) => class CommunityNewsAggregatorModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings, $.$anJf.LCCNCS$2.CommunityNewsAggregatorStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295188213)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295188213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295188213)
            
            //--TRIMMABLE-BOUNDARY-START(4295188213)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295188213)
            
            static $h = 220917;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings, $.$anJf.LCCNCS$2.CommunityNewsAggregatorStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295188213),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 220917,
      "h": 4295188213,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295188213)
  ],
  "h": 220917
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Models${separator}CommunityNewsAggregatorModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(220917)
        
        

        //--TRIMMABLE-BOUNDARY-START(351989)
        $asm.$cls(`$anJf.LCCNCM.CommunityNewsAggregatorModelTypeDescriptor`, ($self) => class CommunityNewsAggregatorModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$anJf.LCCNCM.CommunityNewsAggregatorModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295319285)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295319285);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$anJf.LCCNCM.CommunityNewsAggregatorModelTypeDescriptor.GenerateProperties($.$anJf.LCCNCM.CommunityNewsAggregatorModel, this, factory);
                    }, $ErTgsg ??= {"r":65537,"n":"","d":351989,"h":0,"f":17825794}), 0, "CommunityNewsAggregatorModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.NewsAggregator.Common\\Models_CommunityNewsAggregatorModel_LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorModelTypeDescriptorBuilder.g.cs", "CommunityNewsAggregatorModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295319285)
            
            //--TRIMMABLE-BOUNDARY-START(12885253877)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885253877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings, $.$anJf.LCCNCS$2.CommunityNewsAggregatorStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885253877)
            
            //--TRIMMABLE-BOUNDARY-START(17180221173)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180221173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.NewsAggregator.Common.Settings.CommunityNewsAggregatorSettings, LivingThing.Core.Community.NewsAggregator.Common.States.CommunityNewsAggregatorStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings, $.$anJf.LCCNCS$2.CommunityNewsAggregatorStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$anJf.LCCNCS$1.CommunityNewsAggregatorSettings, $.$anJf.LCCNCS$2.CommunityNewsAggregatorStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180221173)
            
            //--TRIMMABLE-BOUNDARY-START(8590286581)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590286581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$anJf.LCCNCM.CommunityNewsAggregatorModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$anJf.LCCNCM.CommunityNewsAggregatorModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCM.CommunityNewsAggregatorModel)))
                {
                    /*var*/ let result = $.$anJf.LCCNCM.CommunityNewsAggregatorModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCM.CommunityNewsAggregatorModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$anJf.LCCNCM.CommunityNewsAggregatorModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$anJf.LCCNCM.CommunityNewsAggregatorModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590286581)
            
            static $h = 351989;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$anJf.LCCNCM.CommunityNewsAggregatorModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885253877),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 351989,
      "h": 12885253877,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885253877),
//--TRIMMABLE-BOUNDARY-START(17180221173),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 220917,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 351989,
      "h": 17180221173,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180221173),
//--TRIMMABLE-BOUNDARY-START(8590286581),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 220917,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 351989,
      "h": 8590286581,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590286581)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295319285),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 351989,
      "h": 4295319285,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295319285)
  ],
  "h": 351989
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$anJf.LCCNCM.CommunityNewsAggregatorModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.NewsAggregator.Common.Models.CommunityNewsAggregatorModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}NewsAggregator${separator}Common${separator}Models${separator}CommunityNewsAggregatorModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(351989)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(24309)
