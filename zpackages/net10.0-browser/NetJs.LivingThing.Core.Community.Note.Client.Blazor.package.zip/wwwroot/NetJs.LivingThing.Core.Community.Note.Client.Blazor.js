
//--TRIMMABLE-BOUNDARY-START(17475)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $fbjj) {
    "use strict";
    let _;
    let $JpiDli;
    let $YRbNfb;
    let $hFxYoe;
    let $RIUpyk;
    let $kQrQTe;
    let $ZuqPTk;
    let $VXisNc;
    let $NhYXPg;
    let $FpFuua;
    let $dcMijc;
    let $UoNWqf;
    let $uoezCa;
    let $NTLmdg;
    let $XvVdGa;
    let $raDKTk;
    let $eJGWqk;
    let $dMqXij;
    let $gvKDOj;
    let $WqMvLc;
    let $tHnVNh;
    let $toUDMj;
    let $dPtILi;
    let $HHOEof;
    let $axWWLh;
    let $GVBHZb;
    let $rDlVKf;
    let $cFIbMg;
    let $WXfLob;
    let $vMBNek;
    let $NYFOYg;
    let $PWafBi;
    let $VEUfri;
    let $vcGlUi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Note.Client.Blazor", 
    {
  "h": 17475,
  "f": "LivingThing.Core.Community.Note.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Note.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Note.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(148547)
        $asm.$cls(`$UQAj.LCCNC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295115843)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295115843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$UQAj.LCCNC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295115843)
            
            static $h = 148547;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295115843),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 148547,
      "h": 4295115843,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295115843)
  ],
  "h": 148547
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(148547)
        
        

        //--TRIMMABLE-BOUNDARY-START(279619)
        $asm.$cls(`$UQAj.LCCNC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590214211)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590214211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$UQAj.LCCNCP.Home, "LivingThing.Core.Community.Note.Client", "Pages\\Home", "Home", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Note" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("Zoey", 1, "NoteHome", "Notes", "mdi mdi-home"/*MaterialDesignIconNames.Home*/, 8659143824n | 524288n | 32768n | 65536n, null, null, null, null, null, null, null, null, null, null, null, null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590214211)
            
            //--TRIMMABLE-BOUNDARY-START(4295246915)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295246915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295246915)
            
            //--TRIMMABLE-BOUNDARY-START(4295246915)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295246915)
            
            static $h = 279619;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590214211),
    {
      "r": 65537,
      "n": "Build",
      "d": 279619,
      "h": 8590214211,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590214211)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295246915),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 279619,
      "h": 4295246915,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295246915)
  ],
  "h": 279619
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(279619)
        
        

        //--TRIMMABLE-BOUNDARY-START(476227)
        $asm.$cls(`$UQAj.LCCNC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590410819)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590410819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$UQAj.LCCNC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$UQAj.LCCNCS.CommunityNoteService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$fbjj.LCCNCM.CommunityNotePostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCS.ICommunityPostAddOnProvider, $.$UQAj.LCCNCS.CommunityNoteAddOnProvider, services);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$fbjj.LCCNCM.CommunityNotePostModel, services, null);
                $.$UQAj.LCCNC._Startup.AddGeneratedComponentOptimizers(services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$fbjj.LCCNCM.CommunityNotePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$UQAj.LCCNCS.CommunityNoteApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UQAj.LCCNCS.CommunityNoteApplication, x);
                }, $ZuqPTk ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":476227,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UQAj.LCCNCS.CommunityNoteApplication, x);
                }, $VXisNc ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":476227,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$fbjj.LCCNCM.CommunityNotePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UQAj.LCCNCS.CommunityNoteApplication, x);
                }, $NhYXPg ??= {"r":$.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$fbjj.LCCNCM.CommunityNotePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference).$h,"p":[{"n":"x","p":327718}],"n":"","d":476227,"h":0,"f":17825794}));
                $.$UQAj.LCCNC.NavigationMenuBuilder.Build();
            }
            //--TRIMMABLE-BOUNDARY-END(8590410819)
            
            //--TRIMMABLE-BOUNDARY-START(12885378115)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885378115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_CommunityNoteAddOnProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$UQAj.LCCNCS.CommunityNoteAddOnProvider().$ctor$1();
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCS.ICommunityPostAddOnProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$UQAj.LCCNC.ServiceRegistrar, Get_CommunityNoteAddOnProvider, $FpFuua ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_CommunityNoteAddOnProvider","d":476227,"h":0,"f":16777250})));
                /*static object*/  function Get_CommunityNoteApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$UQAj.LCCNCS.CommunityNoteApplication().$ctor$3(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$UQAj.LCCNCS.CommunityNoteService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UQAj.LCCNCS.CommunityNoteService, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$UQAj.LCCNCS.CommunityNoteApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$UQAj.LCCNC.ServiceRegistrar, Get_CommunityNoteApplication, $dcMijc ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_CommunityNoteApplication","d":476227,"h":0,"f":16777250})));
                /*static object*/  function Get_IClientApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UQAj.LCCNCS.CommunityNoteApplication, x);
                    }), $UoNWqf ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":476227,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$sZVd.LCFCA.IClientApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$UQAj.LCCNC.ServiceRegistrar, Get_IClientApplication, $uoezCa ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IClientApplication","d":476227,"h":0,"f":16777250})));
                /*static object*/  function Get_ICommunityClientApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UQAj.LCCNCS.CommunityNoteApplication, x);
                    }), $NTLmdg ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":476227,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCS.ICommunityClientApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$UQAj.LCCNC.ServiceRegistrar, Get_ICommunityClientApplication, $XvVdGa ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ICommunityClientApplication","d":476227,"h":0,"f":16777250})));
                /*static object*/  function Get_ICommunityClientApplication_NoCategoryPostModel_CommunityNotePostModel_GenericPostModel_ApplicationBaseUserPreference_(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UQAj.LCCNCS.CommunityNoteApplication, x);
                    }), $raDKTk ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":476227,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$fbjj.LCCNCM.CommunityNotePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference).$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$UQAj.LCCNC.ServiceRegistrar, Get_ICommunityClientApplication_NoCategoryPostModel_CommunityNotePostModel_GenericPostModel_ApplicationBaseUserPreference_, $eJGWqk ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ICommunityClientApplication_NoCategoryPostModel_CommunityNotePostModel_GenericPostModel_ApplicationBaseUserPreference_","d":476227,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12885378115)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$UQAj.LCCNC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295443523)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295443523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295443523)
            
            //--TRIMMABLE-BOUNDARY-START(4295443523)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295443523)
            
            static $h = 476227;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590410819),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 476227,
      "h": 8590410819,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590410819),
//--TRIMMABLE-BOUNDARY-START(12885378115),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 476227,
      "h": 12885378115,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885378115)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295443523),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 476227,
      "h": 4295443523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295443523)
  ],
  "h": 476227
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(476227)
        
        

        //--TRIMMABLE-BOUNDARY-START(214083)
        $asm.$cls(`$UQAj.LCCNC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180083267)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$UQAj.LCCNCP.CommunityNoteApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$UQAj.LCCNCP.CommunityNoteApp().$ctor$3();
                    }, $JpiDli ??= {"r":2752627,"n":"","d":214083,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$UQAj.LCCNCP.Home.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$UQAj.LCCNCP.Home().$ctor$4();
                    }, $YRbNfb ??= {"r":2752627,"n":"","d":214083,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180083267)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295181379)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295181379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295181379)
            
            //--TRIMMABLE-BOUNDARY-START(4295181379)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295181379)
            
            static $h = 214083;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180083267),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885115971,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 214083,
      "h": 17180083267,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180083267)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295181379),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 214083,
      "h": 4295181379,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295181379)
  ],
  "h": 214083
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(214083)
        
        

        //--TRIMMABLE-BOUNDARY-START(541763)
        $asm.$cls(`$UQAj.LCCNCS.CommunityNoteAddOnProvider`, ($self) => class CommunityNoteAddOnProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64425051203)
            /*string */ get Name()
            {
                return "Notes";
            }
            //--TRIMMABLE-BOUNDARY-END(64425051203)
            
            //--TRIMMABLE-BOUNDARY-START(68720018499)
            /*string */ get Title()
            {
                return "Personal Notes";
            }
            //--TRIMMABLE-BOUNDARY-END(68720018499)
            
            //--TRIMMABLE-BOUNDARY-START(17180410947)
            /*string */ get Description()
            {
                return "Add a private personal notes to this post";
            }
            //--TRIMMABLE-BOUNDARY-END(17180410947)
            
            //--TRIMMABLE-BOUNDARY-START(60130083907)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-pen"/*MaterialDesignIconNames.Pen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(60130083907)
            
            //--TRIMMABLE-BOUNDARY-START(8590476355)
            /*bool */ CanAddOn(/*IPost*/ post)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590476355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return post.LCFCP$IPost$Identifier.HasValue && !(post !== null && ($.$is(post, $.$fbjj.LCCNCM.CommunityNotePostModel)));
            }
            //--TRIMMABLE-BOUNDARY-END(8590476355)
            
            //--TRIMMABLE-BOUNDARY-START(12885443651)
            /*ValueTask */ Clicked(/*IPost*/ post)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885443651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12885443651)
            
            //--TRIMMABLE-BOUNDARY-START(55835116611)
            /*RenderFragment */ GetAddOnView(/*IPost*/ parent, /*RenderFragment?*/ bodyPreview, /*CommunityAddOnsFeatures*/ addOnFeatures)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835116611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                {
                    builder.OpenComponent$1($.$ahDc.LCCCSA$2.CommunityAddOns$$($.$fbjj.LCCNCM.CommunityNotePostModel), 1);
                    builder.AddAttribute$5(2, "Title", "Personal Notes");
                    builder.AddAttribute$5(3, "Description", "Only you can see this");
                    builder.AddAttribute$4(4, "Parent", $.$cast(parent, $.$LCOv.LCFCPM$1.PostBaseModel));
                    builder.AddAttribute$5(5, "Class", "pdx");
                    builder.AddAttribute$4(6, "Features", $.$box(addOnFeatures, $.$ahDc.LCCCSA$2.CommunityAddOnsFeatures));
                    builder.AddAttribute$3(7, "InitialParentPreview", bodyPreview);
                    builder.CloseComponent();
                }, $dMqXij ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":541763,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(55835116611)
            
            //--TRIMMABLE-BOUNDARY-START(4313093568)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityPostAddOnProvider.CanAddOn(LivingThing.Core.Frameworks.Common.Posts.IPost)
            LCCCS$ICommunityPostAddOnProvider$CanAddOn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313093568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanAddOn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313093568)
            
            //--TRIMMABLE-BOUNDARY-START(8608060864)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityPostAddOnProvider.Clicked(LivingThing.Core.Frameworks.Common.Posts.IPost)
            LCCCS$ICommunityPostAddOnProvider$Clicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8608060864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clicked(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8608060864)
            
            //--TRIMMABLE-BOUNDARY-START(17197995456)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityPostAddOnProvider.GetAddOnView(LivingThing.Core.Frameworks.Common.Posts.IPost, Microsoft.AspNetCore.Components.RenderFragment?, LivingThing.Core.Community.Client.Shared.AddOns.CommunityAddOnsFeatures)
            LCCCS$ICommunityPostAddOnProvider$GetAddOnView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17197995456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAddOnView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17197995456)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(4295509059)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295509059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295509059)
            
            //--TRIMMABLE-BOUNDARY-START(4295509059)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295509059)
            
            static $h = 541763;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425051203),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950214723,
        "f": 50331649
      },
      "n": "Name",
      "d": 541763,
      "h": 64425051203,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425051203),
//--TRIMMABLE-BOUNDARY-START(68720018499),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540149315,
        "f": 50331649
      },
      "n": "Title",
      "d": 541763,
      "h": 68720018499,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720018499),
//--TRIMMABLE-BOUNDARY-START(17180410947),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770345539,
        "f": 50331649
      },
      "n": "Description",
      "d": 541763,
      "h": 17180410947,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180410947),
//--TRIMMABLE-BOUNDARY-START(60130083907),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360280131,
        "f": 50331649
      },
      "n": "Icon",
      "d": 541763,
      "h": 60130083907,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130083907)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590476355),
    {
      "r": 262145,
      "p": [
        {
          "n": "post",
          "p": 1173940
        }
      ],
      "n": "CanAddOn",
      "d": 541763,
      "h": 8590476355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590476355),
//--TRIMMABLE-BOUNDARY-START(12885443651),
    {
      "r": 181338113,
      "p": [
        {
          "n": "post",
          "p": 1173940
        }
      ],
      "n": "Clicked",
      "d": 541763,
      "h": 12885443651,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885443651),
//--TRIMMABLE-BOUNDARY-START(55835116611),
    {
      "r": 6881395,
      "p": [
        {
          "n": "parent",
          "p": 1173940
        },
        {
          "n": "bodyPreview",
          "p": 6881395
        },
        {
          "n": "addOnFeatures",
          "p": 22844864
        }
      ],
      "n": "GetAddOnView",
      "d": 541763,
      "h": 55835116611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835116611)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295509059),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 541763,
      "h": 4295509059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295509059)
  ],
  "h": 541763
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityPostAddOnProvider, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Client.Services.CommunityNoteAddOnProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Client${separator}Services${separator}CommunityNoteAddOnProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(541763)
        
        

        //--TRIMMABLE-BOUNDARY-START(803907)
        $asm.$cls(`$UQAj.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295771203)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295771203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295771203)
            
            //--TRIMMABLE-BOUNDARY-START(4295771203)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295771203)
            
            static $h = 803907;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295771203),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 803907,
      "h": 4295771203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295771203)
  ],
  "h": 803907
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(803907)
        
        

        //--TRIMMABLE-BOUNDARY-START(869443)
        $asm.$cls(`$UQAj.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295836739)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295836739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295836739)
            
            //--TRIMMABLE-BOUNDARY-START(4295836739)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295836739)
            
            static $h = 869443;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295836739),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 869443,
      "h": 4295836739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295836739)
  ],
  "h": 869443,
  "a": [
    {
      "t": 803907,
      "c": 4295771203
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(869443)
        
        

        //--TRIMMABLE-BOUNDARY-START(83011)
        $asm.$cls(`$UQAj.LCCNC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590017603)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590017603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590017603)
            
            //--TRIMMABLE-BOUNDARY-START(4295050307)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295050307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295050307)
            
            //--TRIMMABLE-BOUNDARY-START(4295050307)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295050307)
            
            static $h = 83011;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590017603),
    {
      "r": 65537,
      "n": "Execute",
      "d": 83011,
      "h": 8590017603,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590017603)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295050307),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 83011,
      "h": 4295050307,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295050307)
  ],
  "h": 83011
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(83011)
        
        

        //--TRIMMABLE-BOUNDARY-START(345155)
        $asm.$cls(`$UQAj.LCCNCP.CommunityNoteApp`, ($self) => class CommunityNoteApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(25770148931)
            /*CommunityNoteService*/ NoteService = null;
            //--TRIMMABLE-BOUNDARY-END(25770148931)
            
            //--TRIMMABLE-BOUNDARY-START(12885247043)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885247043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "Name", "Note");
                __builder.AddComponentParameter(2, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), new $.$fPer.LCFCR$3.RoutePath().$ctor$3($.$fPer.LCFC.Stringy.op_Implicit$3("Note"))));
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.NoteService));
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(5, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 6);
                        __builder2.AddComponentParameter(7, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                        __builder2.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(9, wrap.View);
                        }), $gvKDOj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":345155,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $WqMvLc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":345155,"h":0,"f":17825794});
                }), $tHnVNh ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":345155,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/*splash*/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 11);
                        __builder2.AddComponentParameter(12, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, splash.ViewModel));
                        __builder2.AddComponentParameter(13, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, splash.Message));
                        __builder2.CloseComponent();
                    }, $toUDMj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":345155,"h":0,"f":17825794});
                }), $dPtILi ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":345155,"h":0,"f":17825794}));
                __builder.AddAttribute$3(14, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 15);
                    __builder2.AddComponentParameter(16, "Name", "");
                    __builder2.AddComponentParameter(17, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~12/*CommunityLayoutFeatures.PadX*/, null, null, true);
                    }), $HHOEof ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object).$h}],"n":"","d":345155,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(18, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityAppIntro, 19);
                            __builder3.AddComponentParameter(20, "Class", "pdx");
                            __builder3.AddComponentParameter(21, "Title", "My");
                            __builder3.AddComponentParameter(22, "SubTitle", "Notes");
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(23, "\r\n            ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$fbjj.LCCNCM.CommunityNotePostModel), 24);
                            __builder3.AddComponentParameter(25, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 536870912n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddComponentParameter(26, "SideBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/ & ~32/*SideBarFeatures.ContentScroll*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                            __builder3.AddComponentParameter(27, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                            __builder3.AddComponentParameter(28, "Class", "pdb");
                            __builder3.AddComponentParameter(29, "li-class", "pd bg-card corner mgt");
                            __builder3.AddAttribute$3(30, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fbjj.LCCNCM.CommunityNotePostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fbjj.LCCNCM.CommunityNotePostModel))))().$ctor(this, ( (/*note*/ note) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$ahDc.LCCCSA$2.CommunityAddOn$$($.$fbjj.LCCNCM.CommunityNotePostModel), 31);
                                    __builder4.AddComponentParameter(32, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fbjj.LCCNCM.CommunityNotePostModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fbjj.LCCNCM.CommunityNotePostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fbjj.LCCNCM.CommunityNotePostModel)).op_Implicit$1(note)));
                                    __builder4.CloseComponent();
                                }, $axWWLh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":345155,"h":0,"f":17825794});
                            }), $GVBHZb ??= {"r":6881395,"p":[{"n":"note","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fbjj.LCCNCM.CommunityNotePostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fbjj.LCCNCM.CommunityNotePostModel)).$h}],"n":"","d":345155,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(33, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                            }), $rDlVKf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":345155,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $cFIbMg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":345155,"h":0,"f":17825794});
                    }), $WXfLob ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":345155,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(34, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$fbjj.LCCNCM.CommunityNotePostModel), 35);
                    __builder2.AddComponentParameter(36, "Name", "Note");
                    __builder2.AddComponentParameter(37, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, new $.$fPer.LCFCR$3.RoutePath().$ctor$3($.$fPer.LCFC.Stringy.op_Implicit$3("***"/*RoutePath.OneOrMorePathSegment*/))));
                    __builder2.AddComponentParameter(38, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/ & ~2/*ApplicationPageFeatures.BottomTab*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(39, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$fbjj.LCCNCM.CommunityNotePostModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(40, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$fbjj.LCCNCM.CommunityNotePostModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$fbjj.LCCNCM.CommunityNotePostModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(41, "\r\n                        ");
                                    __builder4.OpenElement(42, "ApplicationPageConfigureToolBarT");
                                    __builder4.AddAttribute$5(43, "T", "CommunityNotePostModel");
                                    __builder4.OpenElement(44, "Icon");
                                    __builder4.AddAttribute$5(45, "Context", "_");
                                    __builder4.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityPostUserInfo, 46);
                                    __builder4.AddComponentParameter(47, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IPost, e));
                                    __builder4.CloseComponent();
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(48, "\r\n                        ");
                                    __builder4.OpenComponent$1($.$ahDc.LCCCSA$2.CommunityAddOn$$($.$fbjj.LCCNCM.CommunityNotePostModel), 49);
                                    __builder4.AddComponentParameter(50, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fbjj.LCCNCM.CommunityNotePostModel, e));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(51, "\r\n                    ");
                                }, $vMBNek ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":345155,"h":0,"f":17825794});
                            }, $NYFOYg ??= {"r":6881395,"p":[{"n":"e","p":342315}],"n":"","d":345155,"h":0,"f":17825794}), null, true));
                        }, $PWafBi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":345155,"h":0,"f":17825794});
                    }), $VEUfri ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$fbjj.LCCNCM.CommunityNotePostModel)).$h}],"n":"","d":345155,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $vcGlUi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":345155,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12885247043)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590279747)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590279747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590279747)
            
            //--TRIMMABLE-BOUNDARY-START(8590279747)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590279747)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25770148931)
                this.NoteService = null;
                //--TRIMMABLE-BOUNDARY-END(25770148931)
                
            }
            static $h = 345155;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770148931),
    {
      "p": 738371,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475181635,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360083523,
        "f": 83886081
      },
      "n": "NoteService",
      "d": 345155,
      "h": 25770148931,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770148931)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885247043),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 345155,
      "h": 12885247043,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885247043)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590279747),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 345155,
      "h": 8590279747,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590279747)
  ],
  "h": 345155
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Client.Pages.CommunityNoteApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Client${separator}Pages${separator}CommunityNoteApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(345155)
        
        

        //--TRIMMABLE-BOUNDARY-START(410691)
        $asm.$cls(`$UQAj.LCCNCP.Home`, ($self) => class Home extends $.$lJUR.LCFCS.ApplicationLayoutPage
        {
            //--TRIMMABLE-BOUNDARY-START(21475247171)
            /*string */ get OptimizedComponentName()
            {
                return "home applicationlayoutpage";
            }
            //--TRIMMABLE-BOUNDARY-END(21475247171)
            
            //--TRIMMABLE-BOUNDARY-START(8590345283)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590345283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCS$1.CommunityAppIntro, 0);
                __builder.AddComponentParameter(1, "Class", "pdx");
                __builder.AddComponentParameter(2, "Title", "My");
                __builder.AddComponentParameter(3, "SubTitle", "Notes");
                __builder.CloseComponent();
                __builder.AddMarkupContent(4, "\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$fbjj.LCCNCM.CommunityNotePostModel), 5);
                __builder.AddComponentParameter(6, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 536870912n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(7, "SideBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/ & ~32/*SideBarFeatures.ContentScroll*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                __builder.AddComponentParameter(8, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                __builder.AddComponentParameter(9, "Class", "pdb");
                __builder.AddComponentParameter(10, "li-class", "pd bg-card corner mgt");
                __builder.AddAttribute$3(11, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fbjj.LCCNCM.CommunityNotePostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fbjj.LCCNCM.CommunityNotePostModel))))().$ctor(this, ( (/*note*/ note) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSA$2.CommunityAddOn$$($.$fbjj.LCCNCM.CommunityNotePostModel), 12);
                        __builder2.AddComponentParameter(13, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fbjj.LCCNCM.CommunityNotePostModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fbjj.LCCNCM.CommunityNotePostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fbjj.LCCNCM.CommunityNotePostModel)).op_Implicit$1(note)));
                        __builder2.CloseComponent();
                    }, $hFxYoe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":410691,"h":0,"f":17825794});
                }), $RIUpyk ??= {"r":6881395,"p":[{"n":"note","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fbjj.LCCNCM.CommunityNotePostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fbjj.LCCNCM.CommunityNotePostModel)).$h}],"n":"","d":410691,"h":0,"f":17825794}));
                __builder.AddAttribute$3(14, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                }), $kQrQTe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":410691,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590345283)
            
            //--TRIMMABLE-BOUNDARY-START(4295377987)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295377987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295377987)
            
            //--TRIMMABLE-BOUNDARY-START(4295377987)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295377987)
            
            static $h = 410691;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationLayoutPage; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475247171),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180279875,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 410691,
      "h": 21475247171,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475247171)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590345283),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 410691,
      "h": 8590345283,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590345283)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295377987),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 410691,
      "h": 4295377987,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295377987)
  ],
  "h": 410691,
  "a": [
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "Zoey",
          "t": 1310721
        },
        {
          "v": 1,
          "t": 655361
        },
        {
          "v": "NoteHome",
          "t": 1310721
        },
        {
          "v": "Notes",
          "t": 1310721
        },
        {
          "v": "mdi mdi-home",
          "t": 1310721
        },
        {
          "v": 8659766416,
          "t": 67786410
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 7640512,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Note",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$lJUR.LCFCS.IApplicationLayoutPage, $.$lJUR.LCFCS.IApplicationLayoutConfiguration, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Client.Pages.Home`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Client${separator}Pages${separator}Home`; }
        });
        //--TRIMMABLE-BOUNDARY-END(410691)
        
        

        //--TRIMMABLE-BOUNDARY-START(672835)
        $asm.$cls(`$UQAj.LCCNCS.CommunityNotePostFeedProvider`, ($self) => class CommunityNotePostFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$fbjj.LCCNCM.CommunityNotePostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295640131)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295640131);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295640131)
            
            //--TRIMMABLE-BOUNDARY-START(8590607427)
            /*CommunityFeedModel */ ConvertFeed(/*CommunityNotePostModel*/ post)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590607427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let feed = super.ConvertFeed(post);
                feed.ToolBarFeatures &= ~32/*CommunityToolBarFeatures.AddOn*/;
                return feed;
            }
            //--TRIMMABLE-BOUNDARY-END(8590607427)
            
            //--TRIMMABLE-BOUNDARY-START(12885574723)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityNotePostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885574723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1("Noted", false);
            }
            //--TRIMMABLE-BOUNDARY-END(12885574723)
            
            static $h = 672835;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$fbjj.LCCNCM.CommunityNotePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590607427),
    {
      "r": 4822464,
      "p": [
        {
          "n": "post",
          "p": 342315
        }
      ],
      "n": "ConvertFeed",
      "d": 672835,
      "h": 8590607427,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590607427),
//--TRIMMABLE-BOUNDARY-START(12885574723),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 342315
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 672835,
      "h": 12885574723,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885574723)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295640131),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 672835,
      "h": 4295640131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295640131)
  ],
  "h": 672835
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Client.Services.CommunityNotePostFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Client${separator}Services${separator}CommunityNotePostFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(672835)
        
        

        //--TRIMMABLE-BOUNDARY-START(738371)
        $asm.$cls(`$UQAj.LCCNCS.CommunityNoteService`, ($self) => class CommunityNoteService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$fbjj.LCCNCM.CommunityNotePostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295705667)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295705667);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295705667)
            
            static $h = 738371;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$fbjj.LCCNCM.CommunityNotePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295705667),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 738371,
      "h": 4295705667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295705667)
  ],
  "h": 738371
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$fbjj.LCCNCM.CommunityNotePostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$fbjj.LCCNCM.CommunityNotePostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Client.Services.CommunityNoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Client${separator}Services${separator}CommunityNoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(738371)
        
        

        //--TRIMMABLE-BOUNDARY-START(607299)
        $asm.$cls(`$UQAj.LCCNCS.CommunityNoteApplication`, ($self) => class CommunityNoteApplication extends $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$fbjj.LCCNCM.CommunityNotePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(12885509187)
            $ctor$3(/*CommunityNoteService*/ service)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885509187);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885509187)
            
            //--TRIMMABLE-BOUNDARY-START(137439560771)
            /*string */ get Name()
            {
                return "Note";
            }
            //--TRIMMABLE-BOUNDARY-END(137439560771)
            
            //--TRIMMABLE-BOUNDARY-START(154619429955)
            /*string */ get Title()
            {
                return "Note";
            }
            //--TRIMMABLE-BOUNDARY-END(154619429955)
            
            //--TRIMMABLE-BOUNDARY-START(21475443779)
            /*string */ get Description()
            {
                return "Note";
            }
            //--TRIMMABLE-BOUNDARY-END(21475443779)
            
            //--TRIMMABLE-BOUNDARY-START(133144593475)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-note"/*MaterialDesignIconNames.Note*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144593475)
            
            //--TRIMMABLE-BOUNDARY-START(150324462659)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#1E568B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(150324462659)
            
            //--TRIMMABLE-BOUNDARY-START(30065378371)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065378371)
            
            //--TRIMMABLE-BOUNDARY-START(17180476483)
            /*Type? */ get ApplicationViewType()
            {
                return $.$UQAj.LCCNCP.CommunityNoteApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180476483)
            
            //--TRIMMABLE-BOUNDARY-START(128849626179)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849626179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$UQAj.LCCNCP.CommunityNoteApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849626179)
            
            //--TRIMMABLE-BOUNDARY-START(25770411075)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770411075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770411075)
            
            //--TRIMMABLE-BOUNDARY-START(141734528067)
            /*int */ get Order()
            {
                return 1000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734528067)
            
            //--TRIMMABLE-BOUNDARY-START(4295574595)
            /*CommunityNoteService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295574595)
            
            //--TRIMMABLE-BOUNDARY-START(146029495363)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(146029495363)
            
            //--TRIMMABLE-BOUNDARY-START(158914397251)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(6656/*PostTypes.Note*/, 6657/*PostTypes.NoteEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(158914397251)
            
            static $h = 607299;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$fbjj.LCCNCM.CommunityNotePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439560771),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604985923,
        "f": 50364417
      },
      "n": "Name",
      "d": 607299,
      "h": 137439560771,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439560771),
//--TRIMMABLE-BOUNDARY-START(154619429955),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964724291,
        "f": 50364417
      },
      "n": "Title",
      "d": 607299,
      "h": 154619429955,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619429955),
//--TRIMMABLE-BOUNDARY-START(21475443779),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835182147,
        "f": 50364417
      },
      "n": "Description",
      "d": 607299,
      "h": 21475443779,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475443779),
//--TRIMMABLE-BOUNDARY-START(133144593475),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015051331,
        "f": 50364417
      },
      "n": "Icon",
      "d": 607299,
      "h": 133144593475,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144593475),
//--TRIMMABLE-BOUNDARY-START(150324462659),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374789699,
        "f": 50364417
      },
      "n": "Theme",
      "d": 607299,
      "h": 150324462659,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324462659),
//--TRIMMABLE-BOUNDARY-START(30065378371),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425116739,
        "f": 50364417
      },
      "n": "Features",
      "d": 607299,
      "h": 30065378371,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065378371),
//--TRIMMABLE-BOUNDARY-START(17180476483),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245247555,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 607299,
      "h": 17180476483,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180476483),
//--TRIMMABLE-BOUNDARY-START(141734528067),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194920515,
        "f": 50364417
      },
      "n": "Order",
      "d": 607299,
      "h": 141734528067,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734528067),
//--TRIMMABLE-BOUNDARY-START(4295574595),
    {
      "p": 738371,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655312963,
        "f": 50331650
      },
      "n": "_Service",
      "d": 607299,
      "h": 4295574595,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295574595),
//--TRIMMABLE-BOUNDARY-START(146029495363),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784855107,
        "f": 50364417
      },
      "n": "Service",
      "d": 607299,
      "h": 146029495363,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029495363),
//--TRIMMABLE-BOUNDARY-START(158914397251),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554658883,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 607299,
      "h": 158914397251,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914397251)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849626179),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 607299,
      "h": 128849626179,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849626179),
//--TRIMMABLE-BOUNDARY-START(25770411075),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 607299,
      "h": 25770411075,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770411075)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885509187),
    {
      "p": [
        {
          "n": "service",
          "p": 738371
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 607299,
      "h": 12885509187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885509187)
  ],
  "h": 607299
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$fbjj.LCCNCM.CommunityNotePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$sZVd.LCFCA.IClientApplication, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$ahDc.LCCCS.ICommunityUserDashboardApplicationPage, $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$LCOv.LCFCPM$1.AccountModel), $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Client.Services.CommunityNoteApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Client${separator}Services${separator}CommunityNoteApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(607299)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Note.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(17475)
