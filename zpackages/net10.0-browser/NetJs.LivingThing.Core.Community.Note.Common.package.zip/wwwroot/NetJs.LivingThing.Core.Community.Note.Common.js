
//--TRIMMABLE-BOUNDARY-START(14635)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $gTQcac;
    let $LuKRjg;
    let $slmllc;
    let $avwrrb;
    let $lTzEfa;
    let $uUuMQi;
    let $DrEAeb;
    let $gzgBwj;
    let $JVqngg;
    let $ukYFbh;
    let $XNQtcg;
    let $zXRZxf;
    let $KbLiCj;
    let $ofiXGb;
    let $jsYJXk;
    let $tpHVkc;
    let $GgWiXj;
    let $mpLlvg;
    let $CVUprh;
    let $NFJweg;
    let $LlHvFb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Note.Common", 
    {
  "h": 14635,
  "f": "LivingThing.Core.Community.Note.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Note.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Note.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(211243)
        $asm.$cls(`$fbjj.LCCNC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295178539)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295178539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fbjj.LCCNCM.CommunityNotePostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fbjj.LCCNCM.CommunityNotePostModelCustomAttributesProvider, $.$fbjj.LCCNCM.CommunityNotePostModelCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295178539)
            
            static $h = 211243;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295178539),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 211243,
      "h": 4295178539,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295178539)
  ],
  "h": 211243
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(211243)
        
        

        //--TRIMMABLE-BOUNDARY-START(801067)
        $asm.$cls(`$fbjj.LCCNC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295768363)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295768363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4295768363)
            
            static $h = 801067;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295768363),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 801067,
      "h": 4295768363,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295768363)
  ],
  "h": 801067
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(801067)
        
        

        //--TRIMMABLE-BOUNDARY-START(276779)
        $asm.$cls(`$fbjj.LCCNC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295244075)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295244075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$fbjj.LCCCCS.ICommunityNotePostFeedRemoteService, $.$fbjj.LCCCCS.ICommunityNotePostFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fbjj.LCCCCS.ICommunityNotePostFeedRemoteService_Mocking().$ctor$3(impl);
                }, $slmllc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":276779,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fbjj.LCCCCS.ICommunityNotePostFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fbjj.LCCCCS.ICommunityNotePostFeedRemoteService_Mocking().$ctor$3(impl);
                }, $avwrrb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":276779,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fbjj.LCCNCS.ICommunityNoteRemoteService, $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking().$ctor$3(impl);
                }, $lTzEfa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":276779,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking().$ctor$3(impl);
                }, $uUuMQi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":276779,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking().$ctor$3(impl);
                }, $DrEAeb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":276779,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking().$ctor$3(impl);
                }, $gzgBwj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":276779,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking().$ctor$3(impl);
                }, $JVqngg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":276779,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking().$ctor$3(impl);
                }, $ukYFbh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":276779,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking().$ctor$3(impl);
                }, $XNQtcg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":276779,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking().$ctor$3(impl);
                }, $zXRZxf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":276779,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295244075)
            
            static $h = 276779;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295244075),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 276779,
      "h": 4295244075,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295244075)
  ],
  "h": 276779
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(276779)
        
        

        //--TRIMMABLE-BOUNDARY-START(407851)
        $asm.$cls(`$fbjj.LCCNCM.CommunityNotePostModelCustomAttributesProvider`, ($self) => class CommunityNotePostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295375147)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295375147)
            
            //--TRIMMABLE-BOUNDARY-START(8590342443)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590342443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$fbjj.LCCNCM.CommunityNotePostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("ParentLink", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CanAddOn", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("AddOnParent", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("AddOnActivityDescription", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$fbjj.LCCNCM.CommunityNotePostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $gTQcac ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":407851,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $LuKRjg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":407851,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590342443)
            
            static $h = 407851;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590342443),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 407851,
      "h": 8590342443,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590342443)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295375147),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 407851,
      "h": 4295375147,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295375147)
  ],
  "h": 407851
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Common${separator}Models${separator}CommunityNotePostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(407851)
        
        

        //--TRIMMABLE-BOUNDARY-START(538923)
        $asm.$cls(`$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptorBuilder`, ($self) => class CommunityNotePostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590473515)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590473515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptor()
                        const $t1 = $.$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KbLiCj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":538923,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fbjj.LCCNCM.CommunityNotePostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590473515)
            
            //--TRIMMABLE-BOUNDARY-START(4295506219)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295506219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295506219)
            
            //--TRIMMABLE-BOUNDARY-START(4295506219)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295506219)
            
            static $h = 538923;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590473515),
    {
      "r": 65537,
      "n": "Register",
      "d": 538923,
      "h": 8590473515,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590473515)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295506219),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 538923,
      "h": 4295506219,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295506219)
  ],
  "h": 538923
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Common${separator}Models${separator}CommunityNotePostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(538923)
        
        

        //--TRIMMABLE-BOUNDARY-START(604459)
        $asm.$cls(`$fbjj.LCCNC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885506347)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885506347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885506347)
            
            //--TRIMMABLE-BOUNDARY-START(8590539051)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590539051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fbjj.LCCNC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$fbjj.LCCNCM.CommunityNotePostModel, 6656/*PostTypes.Note*/);
                $.$fbjj.LCCNC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$fbjj.LCCNC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$fbjj.LCCNC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590539051)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fbjj.LCCNC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295571755)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295571755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295571755)
            
            //--TRIMMABLE-BOUNDARY-START(4295571755)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295571755)
            
            static $h = 604459;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885506347),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 604459,
      "h": 12885506347,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885506347),
//--TRIMMABLE-BOUNDARY-START(8590539051),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 604459,
      "h": 8590539051,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590539051)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295571755),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 604459,
      "h": 4295571755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295571755)
  ],
  "h": 604459
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(604459)
        
        

        //--TRIMMABLE-BOUNDARY-START(342315)
        $asm.$cls(`$fbjj.LCCNCM.CommunityNotePostModel`, ($self) => class CommunityNotePostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(133144328491)
            /*PostTypes */ get Type()
            {
                return this.SetType ?? 6656/*PostTypes.Note*/;
            }
            //--TRIMMABLE-BOUNDARY-END(133144328491)
            
            //--TRIMMABLE-BOUNDARY-START(120259426603)
            /*bool */ ShouldEditName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259426603);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259426603)
            
            //--TRIMMABLE-BOUNDARY-START(94489622827)
            /*bool */ RequiresName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489622827);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489622827)
            
            //--TRIMMABLE-BOUNDARY-START(124554393899)
            /*bool */ ShouldEditSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554393899);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554393899)
            
            //--TRIMMABLE-BOUNDARY-START(98784590123)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784590123);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784590123)
            
            //--TRIMMABLE-BOUNDARY-START(128849361195)
            /*bool */ ShouldEditTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128849361195);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849361195)
            
            //--TRIMMABLE-BOUNDARY-START(103079557419)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079557419);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079557419)
            
            //--TRIMMABLE-BOUNDARY-START(115964459307)
            /*bool */ ShouldEditIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964459307);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964459307)
            
            //--TRIMMABLE-BOUNDARY-START(90194655531)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194655531);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194655531)
            
            //--TRIMMABLE-BOUNDARY-START(137439295787)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439295787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 1/*SchemaType.Form*/)
                {
                    descriptors = $.$LCOv.LCFCPM$1.PostBaseModel.Exclude(descriptors, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "Summary", "PostFlags" ], null, null));
                }
                return super.UpdateDescriptors(descriptors, $.$clone(schema));
            }
            //--TRIMMABLE-BOUNDARY-END(137439295787)
            
            //--TRIMMABLE-BOUNDARY-START(81604720939)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604720939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Schema === 1/*SchemaType.Form*/)
                {
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Name", "Note Title", null, null, null, null);
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Post", "Note", "Note Content", null, 11n, 1000);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604720939)
            
            //--TRIMMABLE-BOUNDARY-START(77309753643)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$2(this, null, "Note/Post", null, true);
            }
            //--TRIMMABLE-BOUNDARY-END(77309753643)
            
            //--TRIMMABLE-BOUNDARY-START(85899688235)
            /*string */ get ParentLink()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424851755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let targetLink = this.MetadataParentLink;
                if (targetLink !== null)
                {
                    return `${$.$strNN(targetLink)}#${$.$strNN($.$dspc(this.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}`;
                }
                if (this.ParentId.HasValue)
                {
                    return `Community/Post/${$.$strNN($.$dspc(this.ParentId.Id, $.$$.S.Object, ($t) => $t.ToString))}#${$.$strNN(this.Identifier.ToString())}`;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(85899688235)
            
            //--TRIMMABLE-BOUNDARY-START(21475178795)
            /*bool */ get CanAddOn()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(21475178795)
            
            //--TRIMMABLE-BOUNDARY-START(17180211499)
            /*PostBaseModel*/ AddOnParent = null;
            //--TRIMMABLE-BOUNDARY-END(17180211499)
            
            //--TRIMMABLE-BOUNDARY-START(12885244203)
            /*string */ get AddOnActivityDescription()
            {
                return "added a note";
            }
            //--TRIMMABLE-BOUNDARY-END(12885244203)
            
            //--TRIMMABLE-BOUNDARY-START(38656010676)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostAddOn.CanAddOn.get
            get LCFCP$IPostAddOn$CanAddOn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886206900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanAddOn;
            }
            //--TRIMMABLE-BOUNDARY-END(38656010676)
            
            //--TRIMMABLE-BOUNDARY-START(21476141492)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostAddOn.AddOnActivityDescription.get
            get LCFCP$IPostAddOn$AddOnActivityDescription()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296272308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddOnActivityDescription;
            }
            //--TRIMMABLE-BOUNDARY-END(21476141492)
            
            //--TRIMMABLE-BOUNDARY-START(30066076084)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostAddOn.AddOnParent.get
            get LCFCP$IPostAddOn$AddOnParent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591239604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddOnParent;
            }
            //--TRIMMABLE-BOUNDARY-END(30066076084)
            
            //--TRIMMABLE-BOUNDARY-START(47245945268)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostAddOn.AddOnParent.set
            set LCFCP$IPostAddOn$AddOnParent(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591239604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddOnParent = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47245945268)
            
            //--TRIMMABLE-BOUNDARY-START(8590276907)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590276907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590276907)
            
            //--TRIMMABLE-BOUNDARY-START(8590276907)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(8590276907)
            
            static $h = 342315;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133144328491),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014786347,
        "f": 50364417
      },
      "n": "Type",
      "d": 342315,
      "h": 133144328491,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144328491),
//--TRIMMABLE-BOUNDARY-START(77309753643),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834917163,
        "f": 50364417
      },
      "n": "Link",
      "d": 342315,
      "h": 77309753643,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77309753643),
//--TRIMMABLE-BOUNDARY-START(85899688235),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424851755,
        "f": 50331649
      },
      "n": "ParentLink",
      "d": 342315,
      "h": 85899688235,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85899688235),
//--TRIMMABLE-BOUNDARY-START(21475178795),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244982571,
        "f": 50331649
      },
      "n": "CanAddOn",
      "d": 342315,
      "h": 21475178795,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475178795),
//--TRIMMABLE-BOUNDARY-START(17180211499),
    {
      "p": 16771508,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655047979,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669492011,
        "f": 83886081
      },
      "n": "AddOnParent",
      "d": 342315,
      "h": 17180211499,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180211499),
//--TRIMMABLE-BOUNDARY-START(12885244203),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065113387,
        "f": 50331649
      },
      "n": "AddOnActivityDescription",
      "d": 342315,
      "h": 12885244203,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885244203)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(120259426603),
    {
      "r": 262145,
      "n": "ShouldEditName",
      "d": 342315,
      "h": 120259426603,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120259426603),
//--TRIMMABLE-BOUNDARY-START(94489622827),
    {
      "r": 262145,
      "n": "RequiresName",
      "d": 342315,
      "h": 94489622827,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489622827),
//--TRIMMABLE-BOUNDARY-START(124554393899),
    {
      "r": 262145,
      "n": "ShouldEditSummary",
      "d": 342315,
      "h": 124554393899,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124554393899),
//--TRIMMABLE-BOUNDARY-START(98784590123),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 342315,
      "h": 98784590123,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98784590123),
//--TRIMMABLE-BOUNDARY-START(128849361195),
    {
      "r": 262145,
      "n": "ShouldEditTags",
      "d": 342315,
      "h": 128849361195,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128849361195),
//--TRIMMABLE-BOUNDARY-START(103079557419),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": 342315,
      "h": 103079557419,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103079557419),
//--TRIMMABLE-BOUNDARY-START(115964459307),
    {
      "r": 262145,
      "n": "ShouldEditIcon",
      "d": 342315,
      "h": 115964459307,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115964459307),
//--TRIMMABLE-BOUNDARY-START(90194655531),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 342315,
      "h": 90194655531,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90194655531),
//--TRIMMABLE-BOUNDARY-START(137439295787),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": 342315,
      "h": 137439295787,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137439295787),
//--TRIMMABLE-BOUNDARY-START(81604720939),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 342315,
      "h": 81604720939,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604720939)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590276907),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 342315,
      "h": 8590276907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590276907)
  ],
  "h": 342315
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostAddOn, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Common${separator}Models${separator}CommunityNotePostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(342315)
        
        

        //--TRIMMABLE-BOUNDARY-START(80171)
        $asm.$cls(`$fbjj.LCCCCS.ICommunityNotePostFeedRemoteService`, ($self) => class ICommunityNotePostFeedRemoteService
        {
            static $h = 80171;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 80171,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Commmet.Common.Services.ICommunityNotePostFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Commmet${separator}Common${separator}Services${separator}ICommunityNotePostFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(80171)
        
        

        //--TRIMMABLE-BOUNDARY-START(669995)
        $asm.$cls(`$fbjj.LCCNCS.ICommunityNoteRemoteService`, ($self) => class ICommunityNoteRemoteService
        {
            static $h = 669995;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295637291),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.Int32)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "CountNote",
      "o": "LCCNCS$ICommunityNoteRemoteService$CountNote",
      "d": 669995,
      "h": 4295637291,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295637291)
  ],
  "h": 669995,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.ICreateDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.IReadDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Common.Services.ICommunityNoteRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Common${separator}Services${separator}ICommunityNoteRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(669995)
        
        

        //--TRIMMABLE-BOUNDARY-START(145707)
        $asm.$cls(`$fbjj.LCCCCS.ICommunityNotePostFeedRemoteService_Mocking`, ($self) => class ICommunityNotePostFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295113003)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295113003);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295113003)
            
            //--TRIMMABLE-BOUNDARY-START(8590080299)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Note$Common$Models$CommunityNotePostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590080299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$fbjj.LCCNCM.CommunityNotePostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$fbjj.LCCNCM.CommunityNotePostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590080299)
            
            static $h = 145707;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295113003),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 145707,
      "h": 4295113003,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295113003)
  ],
  "h": 145707
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fbjj.LCCCCS.ICommunityNotePostFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Commmet.Common.Services.ICommunityNotePostFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Commmet${separator}Common${separator}Services${separator}ICommunityNotePostFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(145707)
        
        

        //--TRIMMABLE-BOUNDARY-START(735531)
        $asm.$cls(`$fbjj.LCCNCS.ICommunityNoteRemoteService_Mocking`, ($self) => class ICommunityNoteRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295702827)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295702827);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295702827)
            
            //--TRIMMABLE-BOUNDARY-START(8590670123)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<int>> */ LCCNCS$ICommunityNoteRemoteService$CountNote(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590670123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fbjj.LCCNCS.ICommunityNoteRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$$.S.Int32).$type;
                    $i1.MethodName = "CountNote";
                    return $i1;
                })();
                return this.InvokeAsync($.$fbjj.LCCNCS.ICommunityNoteRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.Int32), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590670123)
            
            //--TRIMMABLE-BOUNDARY-START(12885637419)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Note$Common$Models$CommunityNotePostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885637419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$fbjj.LCCNCM.CommunityNotePostModel).$type;
                    $i2.MethodName = "Create";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$fbjj.LCCNCM.CommunityNotePostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885637419)
            
            //--TRIMMABLE-BOUNDARY-START(21475572011)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Note$Common$Models$CommunityNotePostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475572011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$fbjj.LCCNCM.CommunityNotePostModel).$type;
                    $i3.MethodName = "ReadMany";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fbjj.LCCNCM.CommunityNotePostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475572011)
            
            //--TRIMMABLE-BOUNDARY-START(25770539307)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Note$Common$Models$CommunityNotePostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770539307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$fbjj.LCCNCM.CommunityNotePostModel).$type;
                    $i4.MethodName = "ReadSingle";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.WireTransportModel$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fbjj.LCCNCM.CommunityNotePostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770539307)
            
            //--TRIMMABLE-BOUNDARY-START(30065506603)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Note$Common$Models$CommunityNotePostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065506603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$fbjj.LCCNCM.CommunityNotePostModel).$type;
                    $i5.MethodName = "Update";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$fbjj.LCCNCM.CommunityNotePostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30065506603)
            
            //--TRIMMABLE-BOUNDARY-START(17180604715)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180604715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel).$type;
                    $i6.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i6.MethodName = "Delete";
                    return $i6;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$fbjj.LCCNCM.CommunityNotePostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180604715)
            
            static $h = 735531;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295702827),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 735531,
      "h": 4295702827,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295702827)
  ],
  "h": 735531
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fbjj.LCCNCS.ICommunityNoteRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.ICreateDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.IReadDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Common.Services.ICommunityNoteRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Common${separator}Services${separator}ICommunityNoteRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(735531)
        
        

        //--TRIMMABLE-BOUNDARY-START(473387)
        $asm.$cls(`$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptor`, ($self) => class CommunityNotePostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fbjj.LCCNCM.CommunityNotePostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295440683)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295440683);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptor.GenerateProperties($.$fbjj.LCCNCM.CommunityNotePostModel, this, factory);
                    }, $ofiXGb ??= {"r":65537,"n":"","d":473387,"h":0,"f":17825794}), 0, "CommunityNotePostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Note.Common\\Models_CommunityNotePostModel_LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModelTypeDescriptorBuilder.g.cs", "CommunityNotePostModelTypeDescriptor", 45);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295440683)
            
            //--TRIMMABLE-BOUNDARY-START(12885375275)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885375275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fbjj.LCCNCM.CommunityNotePostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$fbjj.LCCNCM.CommunityNotePostModel)).Type);
                        }, $jsYJXk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":473387,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fbjj.LCCNCM.CommunityNotePostModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Link";
                        $i3.DelaredOn = "LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$fbjj.LCCNCM.CommunityNotePostModel)).Link);
                        }, $tpHVkc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":473387,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ParentLink"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fbjj.LCCNCM.CommunityNotePostModel.$type, $.$discardRef(), "ParentLink", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ParentLink")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "ParentLink";
                        $i5.DelaredOn = "LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$fbjj.LCCNCM.CommunityNotePostModel)).ParentLink);
                        }, $GgWiXj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":473387,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CanAddOn"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fbjj.LCCNCM.CommunityNotePostModel.$type, $.$discardRef(), "CanAddOn", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CanAddOn")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "CanAddOn";
                        $i7.DelaredOn = "LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$fbjj.LCCNCM.CommunityNotePostModel)).CanAddOn);
                        }, $mpLlvg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":473387,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AddOnParent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fbjj.LCCNCM.CommunityNotePostModel.$type, $.$discardRef(), "AddOnParent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AddOnParent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostBaseModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "AddOnParent";
                        $i9.DelaredOn = "LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$LCOv.LCFCPM$1.PostBaseModel, ($.$cast(target, $.$fbjj.LCCNCM.CommunityNotePostModel)).AddOnParent);
                        }, $CVUprh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":473387,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.AddOnParent = value.AsReference($.$LCOv.LCFCPM$1.PostBaseModel);
                        }, $NFJweg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":473387,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AddOnActivityDescription"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fbjj.LCCNCM.CommunityNotePostModel.$type, $.$discardRef(), "AddOnActivityDescription", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AddOnActivityDescription")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "AddOnActivityDescription";
                        $i11.DelaredOn = "LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$fbjj.LCCNCM.CommunityNotePostModel)).AddOnActivityDescription);
                        }, $LlHvFb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":473387,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885375275)
            
            //--TRIMMABLE-BOUNDARY-START(17180342571)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180342571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _ParentLink = _target.ParentLink;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ParentLink"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ParentLink, ($v) => _ParentLink = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _CanAddOn = _target.CanAddOn;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CanAddOn"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _CanAddOn, ($v) => _CanAddOn = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _AddOnParent = _target.AddOnParent;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AddOnParent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostBaseModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _AddOnParent, ($v) => _AddOnParent = $v, $.$LCOv.LCFCPM$1.PostBaseModel)))
                    {
                        _target.AddOnParent = _AddOnParent;
                    }
                }
                {
                    /*var*/ let _AddOnActivityDescription = _target.AddOnActivityDescription;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AddOnActivityDescription"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _AddOnActivityDescription, ($v) => _AddOnActivityDescription = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180342571)
            
            //--TRIMMABLE-BOUNDARY-START(8590407979)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590407979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fbjj.LCCNCM.CommunityNotePostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fbjj.LCCNCM.CommunityNotePostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fbjj.LCCNCM.CommunityNotePostModel)))
                {
                    /*var*/ let result = $.$fbjj.LCCNCM.CommunityNotePostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fbjj.LCCNCM.CommunityNotePostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fbjj.LCCNCM.CommunityNotePostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fbjj.LCCNCM.CommunityNotePostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590407979)
            
            static $h = 473387;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fbjj.LCCNCM.CommunityNotePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885375275),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 473387,
      "h": 12885375275,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885375275),
//--TRIMMABLE-BOUNDARY-START(17180342571),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 342315,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 473387,
      "h": 17180342571,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180342571),
//--TRIMMABLE-BOUNDARY-START(8590407979),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 342315,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 473387,
      "h": 8590407979,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590407979)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295440683),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 473387,
      "h": 4295440683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295440683)
  ],
  "h": 473387
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fbjj.LCCNCM.CommunityNotePostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Note.Common.Models.CommunityNotePostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Note${separator}Common${separator}Models${separator}CommunityNotePostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(473387)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(14635)
