
//--TRIMMABLE-BOUNDARY-START(19384)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $jlvo, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $GYJg, $PZCj, $PIIp, $RoTr, $vOBI, $irDD) {
    "use strict";
    let _;
    let $tcHQAh;
    let $digHmj;
    let $SgVbwf;
    let $zJYOEf;
    let $TnbUFc;
    let $XqncIa;
    let $BQYkRh;
    let $dAZWeh;
    let $rVEVLh;
    let $XlTGij;
    let $KeDuFg;
    let $asxkrd;
    let $OCUEtg;
    let $KrrYkh;
    let $lFURuj;
    let $HdLCya;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Organization.Client.Blazor", 
    {
  "h": 19384,
  "f": "LivingThing.Core.Community.Organization.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Organization.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Organization.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(609208)
        $asm.$cls(`$Mstz.LCCOCS.Place`, ($self) => class Place extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(77310020536)
            /*string?*/ Icon = null;
            //--TRIMMABLE-BOUNDARY-END(77310020536)
            
            //--TRIMMABLE-BOUNDARY-START(133144595384)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(133144595384)
            
            //--TRIMMABLE-BOUNDARY-START(30065380280)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(30065380280)
            
            //--TRIMMABLE-BOUNDARY-START(81604987832)
            /*string?*/ Link = null;
            //--TRIMMABLE-BOUNDARY-END(81604987832)
            
            //--TRIMMABLE-BOUNDARY-START(85899955128)
            /*object?*/ LinkParameter = null;
            //--TRIMMABLE-BOUNDARY-END(85899955128)
            
            //--TRIMMABLE-BOUNDARY-START(25770412984)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770412984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770412984)
            
            //--TRIMMABLE-BOUNDARY-START(25770412984)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770412984)
            
            static $h = 609208;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310020536),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245249464,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079824312,
        "f": 83886081
      },
      "n": "Icon",
      "d": 609208,
      "h": 77310020536,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310020536),
//--TRIMMABLE-BOUNDARY-START(133144595384),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015053240,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849628088,
        "f": 83886081
      },
      "n": "Title",
      "d": 609208,
      "h": 133144595384,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144595384),
//--TRIMMABLE-BOUNDARY-START(30065380280),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655314872,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489889720,
        "f": 83886081
      },
      "n": "Description",
      "d": 609208,
      "h": 30065380280,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065380280),
//--TRIMMABLE-BOUNDARY-START(81604987832),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835184056,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669758904,
        "f": 83886081
      },
      "n": "Link",
      "d": 609208,
      "h": 81604987832,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604987832),
//--TRIMMABLE-BOUNDARY-START(85899955128),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425118648,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259693496,
        "f": 83886081
      },
      "n": "LinkParameter",
      "d": 609208,
      "h": 85899955128,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899955128)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770412984),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 609208,
      "h": 25770412984,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770412984)
  ],
  "h": 609208
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Client.Services.Place`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Client${separator}Services${separator}Place`; }
        });
        //--TRIMMABLE-BOUNDARY-END(609208)
        
        

        //--TRIMMABLE-BOUNDARY-START(215992)
        $asm.$cls(`$Mstz.LCCOC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295183288)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295183288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$Mstz.LCCOC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295183288)
            
            static $h = 215992;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295183288),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 215992,
      "h": 4295183288,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295183288)
  ],
  "h": 215992
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(215992)
        
        

        //--TRIMMABLE-BOUNDARY-START(543672)
        $asm.$cls(`$Mstz.LCCOCS.CommunityGroupOrganizationService`, ($self) => class CommunityGroupOrganizationService extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590478264)
            $ctor$1(/*CommunityGroupService*/ service)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590478264);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.GroupService = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590478264)
            
            //--TRIMMABLE-BOUNDARY-START(25770347448)
            /*CommunityGroupService*/ GroupService = null;
            //--TRIMMABLE-BOUNDARY-END(25770347448)
            
            //--TRIMMABLE-BOUNDARY-START(21475380152)
            /*IEnumerable<Place> */ GetPlaces(/*CommunityGroupOrganizationPostModel*/ group)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475380152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.ToArray($.$Mstz.LCCOCS.Place, $.$sl.SL.Enumerable.Where($.$Mstz.LCCOCS.Place, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Mstz.LCCOCS.Place), [(group.Settings?.YoutubeStream?.ChannelId ?? null) !== null ? (() =>
                {
                    //new $.$Mstz.LCCOCS.Place()
                    const $t1 = $.$Mstz.LCCOCS.Place;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Title = "Watch us Live";
                    $i1.Description = `Live Program`;
                    $i1.Icon = "mdi-youtube";
                    $i1.Link = "YoutubeLive";
                    $i1.LinkParameter = group;
                    return $i1;
                })() : null, (() =>
                {
                    //new $.$Mstz.LCCOCS.Place()
                    const $t2 = $.$Mstz.LCCOCS.Place;
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.Title = "Media";
                    $i2.Icon = "mdi-message-video";
                    $i2.Link = "Media";
                    $i2.LinkParameter = group;
                    return $i2;
                })(), (() =>
                {
                    //new $.$Mstz.LCCOCS.Place()
                    const $t3 = $.$Mstz.LCCOCS.Place;
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.Title = "Publications";
                    $i3.Icon = "mdi-newspaper";
                    $i3.Link = "Article";
                    $i3.LinkParameter = group;
                    return $i3;
                })(), (() =>
                {
                    //new $.$Mstz.LCCOCS.Place()
                    const $t4 = $.$Mstz.LCCOCS.Place;
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.Title = "Activities";
                    $i4.Icon = "mdi-timeline";
                    $i4.Link = "Activities";
                    $i4.LinkParameter = group;
                    return $i4;
                })(), (() =>
                {
                    //new $.$Mstz.LCCOCS.Place()
                    const $t5 = $.$Mstz.LCCOCS.Place;
                    const $i5 = new $t5();
                    $i5.$ctor$1();
                    $i5.Title = "Departments";
                    $i5.Icon = "mdi-source-branch";
                    $i5.Link = "Departments";
                    $i5.LinkParameter = group;
                    return $i5;
                })(), (() =>
                {
                    //new $.$Mstz.LCCOCS.Place()
                    const $t6 = $.$Mstz.LCCOCS.Place;
                    const $i6 = new $t6();
                    $i6.$ctor$1();
                    $i6.Title = "Members";
                    $i6.Icon = "mdi-account-multiple-outline";
                    $i6.Link = "Members";
                    $i6.LinkParameter = group;
                    return $i6;
                })(), (() =>
                {
                    //new $.$Mstz.LCCOCS.Place()
                    const $t7 = $.$Mstz.LCCOCS.Place;
                    const $i7 = new $t7();
                    $i7.$ctor$1();
                    $i7.Title = "Calendar";
                    $i7.Icon = "mdi-calendar";
                    $i7.Link = "Calendar";
                    $i7.LinkParameter = group;
                    return $i7;
                })(), (() =>
                {
                    //new $.$Mstz.LCCOCS.Place()
                    const $t8 = $.$Mstz.LCCOCS.Place;
                    const $i8 = new $t8();
                    $i8.$ctor$1();
                    $i8.Title = "Chat Us";
                    $i8.Description = `Come. Let's discuss...`;
                    $i8.Icon = "mdi-message";
                    $i8.Link = "Chat";
                    $i8.LinkParameter = group;
                    return $i8;
                })(), (group.Settings?.YoutubeStream?.ChannelId ?? null) !== null ? (() =>
                {
                    //new $.$Mstz.LCCOCS.Place()
                    const $t9 = $.$Mstz.LCCOCS.Place;
                    const $i9 = new $t9();
                    $i9.$ctor$1();
                    $i9.Title = "Youtube Streams";
                    $i9.Description = `Live Program`;
                    $i9.Icon = "mdi-youtube-tv";
                    $i9.Link = "YoutubeStreams";
                    $i9.LinkParameter = group;
                    return $i9;
                })() : null], [-1], null), new ($.$$.S.Func$$$($.$Mstz.LCCOCS.Place, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                {
                    return p !== null;
                }, $TnbUFc ??= {"r":262145,"p":[{"n":"p","p":609208}],"n":"","d":543672,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(21475380152)
            
            static $h = 543672;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770347448),
    {
      "p": 634270,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180412856,
        "f": 50331649
      },
      "n": "GroupService",
      "d": 543672,
      "h": 25770347448,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770347448)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475380152),
    {
      "r": $.$$.SCG.IEnumerable$$($.$Mstz.LCCOCS.Place).$h,
      "p": [
        {
          "n": "group",
          "p": 271185
        }
      ],
      "n": "GetPlaces",
      "d": 543672,
      "h": 21475380152,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475380152)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590478264),
    {
      "p": [
        {
          "n": "service",
          "p": 634270
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 543672,
      "h": 8590478264,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590478264)
  ],
  "h": 543672
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Client.Services.CommunityGroupOrganizationService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Client${separator}Services${separator}CommunityGroupOrganizationService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(543672)
        
        

        //--TRIMMABLE-BOUNDARY-START(84920)
        $asm.$cls(`$Mstz._LCCOCPH.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295052216)
            static /*void */ CreateCommunityAccountBanner_0(TAccount, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TAccount*/ __arg0)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295052216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountBanner$$(TAccount), seq);
                __builder.AddComponentParameter(__seq0, "ViewModel", $.$box(__arg0, TAccount));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295052216)
            
            static $h = 84920;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295052216),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TAccount) => TAccount.$h
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "CreateCommunityAccountBanner_0",
      "d": 84920,
      "h": 4295052216,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295052216)
  ],
  "h": 84920
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Organization.Client.Pages.HomePage.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Organization${separator}Client${separator}Pages${separator}HomePage${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(84920)
        
        

        //--TRIMMABLE-BOUNDARY-START(281528)
        $asm.$cls(`$Mstz.LCCOC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180150712)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Mstz.LCCOCP.HomePage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Mstz.LCCOCP.HomePage().$ctor$3();
                    }, $SgVbwf ??= {"r":2752627,"n":"","d":281528,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Mstz.LCCOCS$1.Synopsis.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Mstz.LCCOCS$1.Synopsis().$ctor$3();
                    }, $zJYOEf ??= {"r":2752627,"n":"","d":281528,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180150712)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295248824)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295248824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295248824)
            
            //--TRIMMABLE-BOUNDARY-START(4295248824)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295248824)
            
            static $h = 281528;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180150712),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885183416,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 281528,
      "h": 17180150712,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180150712)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295248824),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 281528,
      "h": 4295248824,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295248824)
  ],
  "h": 281528
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(281528)
        
        

        //--TRIMMABLE-BOUNDARY-START(412600)
        $asm.$cls(`$Mstz.LCCOC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590347192)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590347192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$Mstz.LCCOCS.CommunityGroupOrganizationService, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$Mstz.LCCOCS.CommunityGroupOrganizationApplicationHandler, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Mstz.LCCOCS.CommunityGroupOrganizationApplicationHandler, x);
                }, $tcHQAh ??= {"r":16815552,"p":[{"n":"x","p":327718}],"n":"","d":412600,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Mstz.LCCOCS.CommunityGroupOrganizationApplicationHandler, x);
                }, $digHmj ??= {"r":765342,"p":[{"n":"x","p":327718}],"n":"","d":412600,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590347192)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Mstz.LCCOC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295379896)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295379896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295379896)
            
            //--TRIMMABLE-BOUNDARY-START(4295379896)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295379896)
            
            static $h = 412600;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590347192),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 412600,
      "h": 8590347192,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590347192)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295379896),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 412600,
      "h": 4295379896,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295379896)
  ],
  "h": 412600
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(412600)
        
        

        //--TRIMMABLE-BOUNDARY-START(740280)
        $asm.$cls(`$Mstz.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295707576)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295707576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295707576)
            
            //--TRIMMABLE-BOUNDARY-START(4295707576)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295707576)
            
            static $h = 740280;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295707576),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 740280,
      "h": 4295707576,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295707576)
  ],
  "h": 740280
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(740280)
        
        

        //--TRIMMABLE-BOUNDARY-START(805816)
        $asm.$cls(`$Mstz.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295773112)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295773112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295773112)
            
            //--TRIMMABLE-BOUNDARY-START(4295773112)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295773112)
            
            static $h = 805816;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295773112),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 805816,
      "h": 4295773112,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295773112)
  ],
  "h": 805816,
  "a": [
    {
      "t": 740280,
      "c": 4295707576
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(805816)
        
        

        //--TRIMMABLE-BOUNDARY-START(150456)
        $asm.$cls(`$Mstz.LCCOC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590085048)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590085048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590085048)
            
            //--TRIMMABLE-BOUNDARY-START(4295117752)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295117752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295117752)
            
            //--TRIMMABLE-BOUNDARY-START(4295117752)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295117752)
            
            static $h = 150456;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590085048),
    {
      "r": 65537,
      "n": "Execute",
      "d": 150456,
      "h": 8590085048,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590085048)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295117752),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 150456,
      "h": 4295117752,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295117752)
  ],
  "h": 150456
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(150456)
        
        

        //--TRIMMABLE-BOUNDARY-START(347064)
        $asm.$cls(`$Mstz.LCCOCP.HomePage`, ($self) => class HomePage extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21475183544)
            /*CommunityGroupApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(21475183544)
            
            //--TRIMMABLE-BOUNDARY-START(81604725688)
            /*CommunityGroupOrganizationService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(81604725688)
            
            //--TRIMMABLE-BOUNDARY-START(68719823800)
            /*CommunityGroupOrganizationPostModel*/ Group = null;
            //--TRIMMABLE-BOUNDARY-END(68719823800)
            
            //--TRIMMABLE-BOUNDARY-START(77309758392)
            /*string */ get OptimizedComponentName()
            {
                return "homepage";
            }
            //--TRIMMABLE-BOUNDARY-END(77309758392)
            
            //--TRIMMABLE-BOUNDARY-START(111669496760)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669496760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Group":
                    this.Group = $.$cast(parameter.Value, $.$irDD.LCCOCM.CommunityGroupOrganizationPostModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(111669496760)
            
            //--TRIMMABLE-BOUNDARY-START(73014791096)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014791096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Application = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PIIp.LCCGCS.CommunityGroupApplication, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Mstz.LCCOCS.CommunityGroupOrganizationService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(73014791096)
            
            //--TRIMMABLE-BOUNDARY-START(25770150840)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770150840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 0);
                __builder.AddComponentParameter(1, "Name", "");
                __builder.AddComponentParameter(2, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, -2147483648/*int.MinValue*/), $.$$.S.Int32));
                __builder.AddComponentParameter(3, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/ | (((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? 4/*ApplicationPageAccessibility.Tab*/ : 0/*ApplicationPageAccessibility.None*/)), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                __builder.AddComponentParameter(4, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ | 16/*ApplicationPageFeatures.TopToolBarOverlay*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                __builder.AddComponentParameter(5, "ToolBarBackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                __builder.AddComponentParameter(6, "RemoveApplicationFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 128/*ApplicationFeatures.ToolBarBorder*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddComponentParameter(7, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)))().$ctor(this, ( (/*e*/ e) =>
                {
                    return $.$ahDc.LCCCSL.CommunityLayoutExtension.SetLayoutHeader($.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~(12/*CommunityLayoutFeatures.PadX*/ | 1/*CommunityLayoutFeatures.PadT*/), null, null, true), this.GetBanner());
                }), $BQYkRh ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object).$h}],"n":"","d":347064,"h":0,"f":17825794}));
                __builder.AddAttribute$3(8, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$4(9, this.Group.Title);
                    }, $dAZWeh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":347064,"h":0,"f":17825794});
                }), $rVEVLh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":347064,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$1(11, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-Organization"), false));
                    }, $XlTGij ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":347064,"h":0,"f":17825794});
                }), $KeDuFg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":347064,"h":0,"f":17825794}));
                __builder.AddAttribute$3(12, "ToolBarChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        /*var*/ let ownsAccount = this.Service.GroupService.CommunityService.IsOwnedByCurrentUser(this.Group);
                        if (ownsAccount)
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 13);
                            __builder2.AddComponentParameter(14, "PageLink", "Settings");
                            __builder2.AddComponentParameter(15, "link-class", "mdi mdi-cog");
                            __builder2.CloseComponent();
                        }
                    }, $asxkrd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":347064,"h":0,"f":17825794});
                }), $OCUEtg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":347064,"h":0,"f":17825794}));
                __builder.AddAttribute$3(16, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*__*/ __) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                    }, $KrrYkh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":347064,"h":0,"f":17825794});
                }), $lFURuj ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":347064,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(17, "\r\n\r\n}");
            }
            //--TRIMMABLE-BOUNDARY-END(25770150840)
            
            //--TRIMMABLE-BOUNDARY-START(64424856504)
            /*RenderFragment */ GetBanner()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424856504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    $.$Mstz._LCCOCPH.TypeInference.CreateCommunityAccountBanner_0($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel, __builder2, 18, 19, this.Group);
                }, $HdLCya ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":347064,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(64424856504)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180216248)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180216248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180216248)
            
            //--TRIMMABLE-BOUNDARY-START(17180216248)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17180216248)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475183544)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(21475183544)
                
                //--TRIMMABLE-BOUNDARY-START(81604725688)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(81604725688)
                
            }
            static $h = 347064;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475183544),
    {
      "p": 503198,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360085432,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194660280,
        "f": 83886081
      },
      "n": "Application",
      "d": 347064,
      "h": 21475183544,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475183544),
//--TRIMMABLE-BOUNDARY-START(81604725688),
    {
      "p": 543672,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129889208,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374529464,
        "f": 83886081
      },
      "n": "Service",
      "d": 347064,
      "h": 81604725688,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81604725688),
//--TRIMMABLE-BOUNDARY-START(68719823800),
    {
      "p": 271185,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950020024,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784594872,
        "f": 83886081
      },
      "n": "Group",
      "d": 347064,
      "h": 68719823800,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719823800),
//--TRIMMABLE-BOUNDARY-START(77309758392),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539954616,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 347064,
      "h": 77309758392,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77309758392)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111669496760),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 347064,
      "h": 111669496760,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669496760),
//--TRIMMABLE-BOUNDARY-START(73014791096),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 347064,
      "h": 73014791096,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73014791096),
//--TRIMMABLE-BOUNDARY-START(25770150840),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 347064,
      "h": 25770150840,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770150840),
//--TRIMMABLE-BOUNDARY-START(64424856504),
    {
      "r": 6881395,
      "n": "GetBanner",
      "d": 347064,
      "h": 64424856504,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64424856504)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180216248),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 347064,
      "h": 17180216248,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180216248)
  ],
  "h": 347064
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Client.Pages.HomePage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Client${separator}Pages${separator}HomePage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(347064)
        
        

        //--TRIMMABLE-BOUNDARY-START(674744)
        $asm.$cls(`$Mstz.LCCOCS$1.Synopsis`, ($self) => class Synopsis extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(94489955256)
            /*ICommunityNuggetProvider*/ NuggetProvider = null;
            //--TRIMMABLE-BOUNDARY-END(94489955256)
            
            //--TRIMMABLE-BOUNDARY-START(30065445816)
            /*ICommunityCalendarProvider*/ EventProvider = null;
            //--TRIMMABLE-BOUNDARY-END(30065445816)
            
            //--TRIMMABLE-BOUNDARY-START(103079889848)
            /*CommunityGroupOrganizationService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(103079889848)
            
            //--TRIMMABLE-BOUNDARY-START(85900020664)
            /*CommunityGroupOrganizationPostModel*/ Group = null;
            //--TRIMMABLE-BOUNDARY-END(85900020664)
            
            //--TRIMMABLE-BOUNDARY-START(141734595512)
            /*DataFilter */ get TodayNuggetFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Group.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741847/*PostFilterTypes.FeaturedInParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1286/*PostTypes.ArticleNugget*/, $.$LCOv.LCFCPM$1.PostTypes) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(141734595512)
            
            //--TRIMMABLE-BOUNDARY-START(98784922552)
            /*string */ get OptimizedComponentName()
            {
                return "synopsis";
            }
            //--TRIMMABLE-BOUNDARY-END(98784922552)
            
            //--TRIMMABLE-BOUNDARY-START(146029562808)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029562808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Group":
                    this.Group = $.$cast(parameter.Value, $.$irDD.LCCOCM.CommunityGroupOrganizationPostModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(146029562808)
            
            //--TRIMMABLE-BOUNDARY-START(90194987960)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194987960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.NuggetProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.ICommunityNuggetProvider, serviceProvider);
                this.EventProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.ICommunityCalendarProvider, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Mstz.LCCOCS.CommunityGroupOrganizationService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(90194987960)
            
            //--TRIMMABLE-BOUNDARY-START(25770478520)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770478520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pdx mgb-10");
                __builder.AddContent$1(2, this.NuggetProvider.LCCCS$ICommunityNuggetProvider$GetTodayNugget(this.TodayNuggetFilter));
                __builder.AddMarkupContent(3, "\r\n    ");
                __builder.AddContent$1(4, this.EventProvider.LCCCS$ICommunityCalendarProvider$GetUpcomingEvents(this.Group));
                __builder.AddMarkupContent(5, "\r\n    ");
                __builder.OpenElement(6, "ul");
                __builder.AddAttribute$5(7, "class", "reset grid colm-1 gap-05");
                let $en2 = $.$sl.SL.Enumerable.Take($.$Mstz.LCCOCS.Place, this.Service.GetPlaces(this.Group), 9).SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let place = $en2.SCG$IEnumerator$$$Current;
                    {
                        __builder.OpenElement(8, "li");
                        __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 9);
                        __builder.AddComponentParameter(10, "href", place.Link);
                        __builder.AddComponentParameter(11, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, place.LinkParameter));
                        __builder.AddComponentParameter(12, "Class", "mg-a d-block text-center");
                        __builder.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(14, "div");
                            __builder2.AddAttribute$5(15, "class", "stack corner-2 pdx-1 pdy mg-1 bg-card bd-primary shadow clickable flex");
                            __builder2.OpenElement(16, "i");
                            __builder2.AddAttribute$5(17, "class", $.$strNN($.$strNN($.$strNN("mgx-a" + " mdi") + " fsz-35") + " ") + $.$strNN((place.Icon)));
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(18, "\r\n                        ");
                            __builder2.OpenElement(19, "h4");
                            __builder2.AddAttribute$5(20, "class", "mgx-a text-center mgt-1 mgb-0 nowrap");
                            __builder2.AddContent$4(21, place.Title);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }), $XqncIa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":674744,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(25770478520)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21475511224)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475511224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475511224)
            
            //--TRIMMABLE-BOUNDARY-START(21475511224)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21475511224)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(94489955256)
                this.NuggetProvider = null;
                //--TRIMMABLE-BOUNDARY-END(94489955256)
                
                //--TRIMMABLE-BOUNDARY-START(30065445816)
                this.EventProvider = null;
                //--TRIMMABLE-BOUNDARY-END(30065445816)
                
                //--TRIMMABLE-BOUNDARY-START(103079889848)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(103079889848)
                
            }
            static $h = 674744;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94489955256),
    {
      "p": 18060736,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835249592,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849693624,
        "f": 83886081
      },
      "n": "NuggetProvider",
      "d": 674744,
      "h": 94489955256,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94489955256),
//--TRIMMABLE-BOUNDARY-START(30065445816),
    {
      "p": 17339840,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655380408,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669824440,
        "f": 83886081
      },
      "n": "EventProvider",
      "d": 674744,
      "h": 30065445816,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065445816),
//--TRIMMABLE-BOUNDARY-START(103079889848),
    {
      "p": 543672,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015118776,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439628216,
        "f": 83886081
      },
      "n": "Service",
      "d": 674744,
      "h": 103079889848,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103079889848),
//--TRIMMABLE-BOUNDARY-START(85900020664),
    {
      "p": 271185,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245315000,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259759032,
        "f": 83886081
      },
      "n": "Group",
      "d": 674744,
      "h": 85900020664,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900020664),
//--TRIMMABLE-BOUNDARY-START(141734595512),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605053368,
        "f": 50331650
      },
      "n": "TodayNuggetFilter",
      "d": 674744,
      "h": 141734595512,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(141734595512),
//--TRIMMABLE-BOUNDARY-START(98784922552),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425184184,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 674744,
      "h": 98784922552,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98784922552)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(146029562808),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 674744,
      "h": 146029562808,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029562808),
//--TRIMMABLE-BOUNDARY-START(90194987960),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 674744,
      "h": 90194987960,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90194987960),
//--TRIMMABLE-BOUNDARY-START(25770478520),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 674744,
      "h": 25770478520,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770478520)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475511224),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 674744,
      "h": 21475511224,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475511224)
  ],
  "h": 674744
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Client.Shared.Synopsis`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Client${separator}Shared${separator}Synopsis`; }
        });
        //--TRIMMABLE-BOUNDARY-END(674744)
        
        

        //--TRIMMABLE-BOUNDARY-START(478136)
        $asm.$cls(`$Mstz.LCCOCS.CommunityGroupOrganizationApplicationHandler`, ($self) => class CommunityGroupOrganizationApplicationHandler extends $.$PIIp.LCCGCS.CommunityGroupTypeHandlerBase$$$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel, $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates)
        {
            //--TRIMMABLE-BOUNDARY-START(163209235384)
            /*PostTypes */ get Type()
            {
                return 2306/*PostTypes.GroupOrganization*/;
            }
            //--TRIMMABLE-BOUNDARY-END(163209235384)
            
            //--TRIMMABLE-BOUNDARY-START(141734398904)
            /*IEnumerable<string> */ get Roles()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Minister", "GuestMinister"], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(141734398904)
            
            //--TRIMMABLE-BOUNDARY-START(150324333496)
            /*string */ get SubGroupTitle()
            {
                return "Department";
            }
            //--TRIMMABLE-BOUNDARY-END(150324333496)
            
            //--TRIMMABLE-BOUNDARY-START(128849497016)
            /*string */ get Id()
            {
                return "Organization";
            }
            //--TRIMMABLE-BOUNDARY-END(128849497016)
            
            //--TRIMMABLE-BOUNDARY-START(137439431608)
            /*string */ get PostsName()
            {
                return "Organizations";
            }
            //--TRIMMABLE-BOUNDARY-END(137439431608)
            
            //--TRIMMABLE-BOUNDARY-START(146029366200)
            /*IEnumerable<ICommunityApplicationServiceCategory>?*/ ServiceCategories = null;
            //--TRIMMABLE-BOUNDARY-END(146029366200)
            
            //--TRIMMABLE-BOUNDARY-START(158914268088)
            /*string? */ get Title()
            {
                return "Organization";
            }
            //--TRIMMABLE-BOUNDARY-END(158914268088)
            
            //--TRIMMABLE-BOUNDARY-START(124554529720)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account-group"/*MaterialDesignIconNames.AccountGroup*/);
            }
            //--TRIMMABLE-BOUNDARY-END(124554529720)
            
            //--TRIMMABLE-BOUNDARY-START(133144464312)
            /*string? */ get Name()
            {
                return "Chruch";
            }
            //--TRIMMABLE-BOUNDARY-END(133144464312)
            
            //--TRIMMABLE-BOUNDARY-START(154619300792)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#8E9633";
                    $i1.ForegroundColor = "#FFFFFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619300792)
            
            //--TRIMMABLE-BOUNDARY-START(12885380024)
            /*IEnumerable<PostTypes> */ get AccountsType()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostTypes), [2306/*PostTypes.GroupOrganization*/], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(12885380024)
            
            //--TRIMMABLE-BOUNDARY-START(111669627832)
            /*RenderFragment? */ GetAccountView(/*AccountBaseModel*/ account, /*string?*/ route)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669627832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$PIIp.LCCGCS$1.CommunityGroupApplicationView$$$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel, $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates), (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.set_Item("ViewModel", $.$LCOv.LCFCPM$1.PostFactory.EnsureIsCorrectType$1($.$LCOv.LCFCPM$1.AccountBaseModel, $.$irDD.LCCOCM.CommunityGroupOrganizationPostModel, account));
                    $i2.set_Item("Route", route);
                    return $i2;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(111669627832)
            
            //--TRIMMABLE-BOUNDARY-START(120259562424)
            /*RenderFragment? */ GetGroupSynopsis(/*AccountBaseModel*/ group)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259562424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$Mstz.LCCOCS$1.Synopsis, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t3 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.set_Item("Group", group);
                    return $i3;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(120259562424)
            
            //--TRIMMABLE-BOUNDARY-START(115964595128)
            /*RenderFragment? */ GetGroupPages(/*AccountBaseModel*/ group)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964595128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
                return $.$hDPm.LCFC.FragmentView.Join(null, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mac.MAC.RenderFragment), [ $.$hDPm.LCFC.FragmentView.From$1($.$Mstz.LCCOCP.HomePage, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.set_Item("Group", group);
                    return $i4;
                })(), null, null) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(115964595128)
            
            //--TRIMMABLE-BOUNDARY-START(8590412728)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590412728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590412728)
            
            //--TRIMMABLE-BOUNDARY-START(8590412728)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590412728)
            
            static $h = 478136;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PIIp.LCCGCS.CommunityGroupTypeHandlerBase$$$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel, $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(163209235384),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374660536,
        "f": 50364417
      },
      "n": "Type",
      "d": 478136,
      "h": 163209235384,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209235384),
//--TRIMMABLE-BOUNDARY-START(141734398904),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424987576,
        "f": 50364417
      },
      "n": "Roles",
      "d": 478136,
      "h": 141734398904,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734398904),
//--TRIMMABLE-BOUNDARY-START(150324333496),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604856760,
        "f": 50364417
      },
      "n": "SubGroupTitle",
      "d": 478136,
      "h": 150324333496,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324333496),
//--TRIMMABLE-BOUNDARY-START(128849497016),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655183800,
        "f": 50364417
      },
      "n": "Id",
      "d": 478136,
      "h": 128849497016,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128849497016),
//--TRIMMABLE-BOUNDARY-START(137439431608),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835052984,
        "f": 50364417
      },
      "n": "PostsName",
      "d": 478136,
      "h": 137439431608,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439431608),
//--TRIMMABLE-BOUNDARY-START(146029366200),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS.ICommunityApplicationServiceCategory).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014922168,
        "f": 50364417
      },
      "n": "ServiceCategories",
      "d": 478136,
      "h": 146029366200,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029366200),
//--TRIMMABLE-BOUNDARY-START(158914268088),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784725944,
        "f": 50364417
      },
      "n": "Title",
      "d": 478136,
      "h": 158914268088,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914268088),
//--TRIMMABLE-BOUNDARY-START(124554529720),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065249208,
        "f": 50364417
      },
      "n": "Icon",
      "d": 478136,
      "h": 124554529720,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(124554529720),
//--TRIMMABLE-BOUNDARY-START(133144464312),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245118392,
        "f": 50364417
      },
      "n": "Name",
      "d": 478136,
      "h": 133144464312,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144464312),
//--TRIMMABLE-BOUNDARY-START(154619300792),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194791352,
        "f": 50364417
      },
      "n": "Theme",
      "d": 478136,
      "h": 154619300792,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619300792),
//--TRIMMABLE-BOUNDARY-START(12885380024),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475314616,
        "f": 50364417
      },
      "n": "AccountsType",
      "d": 478136,
      "h": 12885380024,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885380024)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111669627832),
    {
      "r": 6881395,
      "p": [
        {
          "n": "account",
          "p": 6220212
        },
        {
          "n": "route",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetAccountView",
      "d": 478136,
      "h": 111669627832,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669627832),
//--TRIMMABLE-BOUNDARY-START(120259562424),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetGroupSynopsis",
      "d": 478136,
      "h": 120259562424,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120259562424),
//--TRIMMABLE-BOUNDARY-START(115964595128),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetGroupPages",
      "d": 478136,
      "h": 115964595128,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115964595128)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590412728),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 478136,
      "h": 8590412728,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590412728)
  ],
  "h": 478136
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler$$$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel, $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates), $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, $.$ydCm.LCCCS.ICommunityApplicationSubService, $.$yleQ.LCFCA.IApplicationSubService, $.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Client.Services.CommunityGroupOrganizationApplicationHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Client${separator}Services${separator}CommunityGroupOrganizationApplicationHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(478136)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Account.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Account.Client.Blazor", "NetJs.LivingThing.Core.Community.Group.Common", "NetJs.LivingThing.Core.Community.Group.Client.Blazor", "NetJs.LivingThing.Core.Community.Group.User.Common", "NetJs.LivingThing.Core.Community.Group.User.Client.Blazor", "NetJs.LivingThing.Core.Community.Organization.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(19384)
