
//--TRIMMABLE-BOUNDARY-START(9041)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm, $PZCj) {
    "use strict";
    let _;
    let $Unwnve;
    let $cXySii;
    let $vlJFmj;
    let $Izewkg;
    let $CMHwYa;
    let $HAkilf;
    let $VUndtb;
    let $ZdDkmb;
    let $RNsyhe;
    let $MtwuRk;
    let $myZLVa;
    let $GLTvOc;
    let $Bddgih;
    let $xjlQmd;
    let $wgiuDe;
    let $zdJtJi;
    let $nUnMug;
    let $vhUlgc;
    let $FnRbmc;
    let $OIENJi;
    let $FbFAdk;
    let $CuRfFi;
    let $GHnWpj;
    let $ALttza;
    let $reVFma;
    let $GlQrZe;
    let $HAatQa;
    let $smqSDi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Organization.Common", 
    {
  "h": 9041,
  "f": "LivingThing.Core.Community.Organization.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Organization.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Organization.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(861009)
        $asm.$cls(`$irDD.LCCOCM.CommunityGroupOrganizationServiceTierCustomAttributesProvider`, ($self) => class CommunityGroupOrganizationServiceTierCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295828305)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295828305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295828305)
            
            static $h = 861009;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295828305),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 861009,
      "h": 4295828305,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295828305)
  ],
  "h": 861009
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationServiceTierCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Models${separator}CommunityGroupOrganizationServiceTierCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(861009)
        
        

        //--TRIMMABLE-BOUNDARY-START(140113)
        $asm.$cls(`$irDD.LCCOC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295107409)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295107409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295107409)
            
            static $h = 140113;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295107409),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 140113,
      "h": 4295107409,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295107409)
  ],
  "h": 140113
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(140113)
        
        

        //--TRIMMABLE-BOUNDARY-START(1712977)
        $asm.$cls(`$irDD.LCCOCS$2.CommunityGroupOrganizationPostStatesCustomAttributesProvider`, ($self) => class CommunityGroupOrganizationPostStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296680273)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296680273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$2.CommunityGroupPostStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296680273)
            
            static $h = 1712977;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296680273),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1712977,
      "h": 4296680273,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296680273)
  ],
  "h": 1712977
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.States.CommunityGroupOrganizationPostStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}States${separator}CommunityGroupOrganizationPostStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1712977)
        
        

        //--TRIMMABLE-BOUNDARY-START(2171729)
        $asm.$cls(`$irDD.LCCOC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297139025)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297139025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$irDD.LCCOCM.CommunityGroupOrganizationPostModelTypeDescriptorBuilder.Register();
                $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModelTypeDescriptorBuilder.Register();
                $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettingsTypeDescriptorBuilder.Register();
                $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettingsTypeDescriptorBuilder.Register();
                $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStatesTypeDescriptorBuilder.Register();
                $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297139025)
            
            static $h = 2171729;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297139025),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2171729,
      "h": 4297139025,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297139025)
  ],
  "h": 2171729
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2171729)
        
        

        //--TRIMMABLE-BOUNDARY-START(1450833)
        $asm.$cls(`$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettingsCustomAttributesProvider`, ($self) => class CommunityGroupOrganizationServiceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296418129)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296418129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296418129)
            
            static $h = 1450833;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296418129),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1450833,
      "h": 4296418129,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296418129)
  ],
  "h": 1450833
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationServiceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Settings${separator}CommunityGroupOrganizationServiceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1450833)
        
        

        //--TRIMMABLE-BOUNDARY-START(1975121)
        $asm.$cls(`$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStatesCustomAttributesProvider`, ($self) => class CommunityOrganizationGroupServiceStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296942417)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296942417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296942417)
            
            static $h = 1975121;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296942417),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1975121,
      "h": 4296942417,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296942417)
  ],
  "h": 1975121
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.States.CommunityOrganizationGroupServiceStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}States${separator}CommunityOrganizationGroupServiceStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1975121)
        
        

        //--TRIMMABLE-BOUNDARY-START(1188689)
        $asm.$cls(`$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettingsCustomAttributesProvider`, ($self) => class CommunityGroupOrganizationPostSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296155985)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296155985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296155985)
            
            static $h = 1188689;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296155985),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1188689,
      "h": 4296155985,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296155985)
  ],
  "h": 1188689
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationPostSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Settings${separator}CommunityGroupOrganizationPostSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1188689)
        
        

        //--TRIMMABLE-BOUNDARY-START(1319761)
        $asm.$cls(`$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettingsTypeDescriptorBuilder`, ($self) => class CommunityGroupOrganizationPostSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591254353)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591254353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettingsTypeDescriptor()
                        const $t1 = $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationPostSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $RNsyhe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1319761,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591254353)
            
            //--TRIMMABLE-BOUNDARY-START(4296287057)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296287057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296287057)
            
            //--TRIMMABLE-BOUNDARY-START(4296287057)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296287057)
            
            static $h = 1319761;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591254353),
    {
      "r": 65537,
      "n": "Register",
      "d": 1319761,
      "h": 8591254353,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591254353)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296287057),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1319761,
      "h": 4296287057,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296287057)
  ],
  "h": 1319761
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationPostSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Settings${separator}CommunityGroupOrganizationPostSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1319761)
        
        

        //--TRIMMABLE-BOUNDARY-START(205649)
        $asm.$cls(`$irDD.LCCOC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295172945)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295172945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$irDD.LCCOCS.IComunityOrganizationRemoteService, $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking().$ctor$3(impl);
                }, $Unwnve ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":205649,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking().$ctor$3(impl);
                }, $cXySii ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":205649,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking().$ctor$3(impl);
                }, $vlJFmj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":205649,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking().$ctor$3(impl);
                }, $Izewkg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":205649,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking().$ctor$3(impl);
                }, $CMHwYa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":205649,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking().$ctor$3(impl);
                }, $HAkilf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":205649,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking().$ctor$3(impl);
                }, $VUndtb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":205649,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking().$ctor$3(impl);
                }, $ZdDkmb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":205649,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295172945)
            
            static $h = 205649;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295172945),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 205649,
      "h": 4295172945,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295172945)
  ],
  "h": 205649
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(205649)
        
        

        //--TRIMMABLE-BOUNDARY-START(1581905)
        $asm.$cls(`$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettingsTypeDescriptorBuilder`, ($self) => class CommunityGroupOrganizationServiceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591516497)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591516497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettingsTypeDescriptor()
                        const $t1 = $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationServiceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $myZLVa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1581905,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591516497)
            
            //--TRIMMABLE-BOUNDARY-START(4296549201)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296549201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296549201)
            
            //--TRIMMABLE-BOUNDARY-START(4296549201)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296549201)
            
            static $h = 1581905;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591516497),
    {
      "r": 65537,
      "n": "Register",
      "d": 1581905,
      "h": 8591516497,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591516497)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296549201),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1581905,
      "h": 4296549201,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296549201)
  ],
  "h": 1581905
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationServiceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Settings${separator}CommunityGroupOrganizationServiceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1581905)
        
        

        //--TRIMMABLE-BOUNDARY-START(336721)
        $asm.$cls(`$irDD.LCCOCM.CommunityGroupOrganizationPostModelCustomAttributesProvider`, ($self) => class CommunityGroupOrganizationPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295304017)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295304017)
            
            //--TRIMMABLE-BOUNDARY-START(8590271313)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590271313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$irDD.LCCOCM.CommunityGroupOrganizationPostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates).$type, $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates)), [(() =>
                        {
                            //new $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates)()
                            const $t3 = $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates);
                            const $i3 = new $t3();
                            $i3.$ctor$3();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates)), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i4 = new $t4();
                        $i4.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i4.set_Item("ServiceId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i4;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$irDD.LCCOCM.CommunityGroupOrganizationPostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $Bddgih ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":336721,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $xjlQmd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":336721,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$PZCj.LCCGCM.CommunityGroupBasePostModelCustomAttributesProvider$$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590271313)
            
            static $h = 336721;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590271313),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 336721,
      "h": 8590271313,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590271313)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295304017),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 336721,
      "h": 4295304017,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295304017)
  ],
  "h": 336721
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Models${separator}CommunityGroupOrganizationPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(336721)
        
        

        //--TRIMMABLE-BOUNDARY-START(74577)
        $asm.$cls(`$irDD.LCCOC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295041873)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295041873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$irDD.LCCOCM.CommunityGroupOrganizationPostModelCustomAttributesProvider, $.$irDD.LCCOCM.CommunityGroupOrganizationPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$irDD.LCCOCM.CommunityGroupOrganizationServiceModelCustomAttributesProvider, $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$irDD.LCCOCM.CommunityGroupOrganizationServiceTier.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$irDD.LCCOCM.CommunityGroupOrganizationServiceTierCustomAttributesProvider, $.$irDD.LCCOCM.CommunityGroupOrganizationServiceTierCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettingsCustomAttributesProvider, $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettingsCustomAttributesProvider, $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStatesCustomAttributesProvider, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStatesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStatesCustomAttributesProvider, $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295041873)
            
            static $h = 74577;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295041873),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 74577,
      "h": 4295041873,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295041873)
  ],
  "h": 74577
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(74577)
        
        

        //--TRIMMABLE-BOUNDARY-START(598865)
        $asm.$cls(`$irDD.LCCOCM.CommunityGroupOrganizationServiceModelCustomAttributesProvider`, ($self) => class CommunityGroupOrganizationServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295566161)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295566161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ServiceModelCustomAttributesProvider$$$$($.$irDD.LCCOCM.CommunityGroupOrganizationServiceTier, $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings, $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295566161)
            
            static $h = 598865;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295566161),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 598865,
      "h": 4295566161,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295566161)
  ],
  "h": 598865
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Models${separator}CommunityGroupOrganizationServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(598865)
        
        

        //--TRIMMABLE-BOUNDARY-START(467793)
        $asm.$cls(`$irDD.LCCOCM.CommunityGroupOrganizationPostModelTypeDescriptorBuilder`, ($self) => class CommunityGroupOrganizationPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590402385)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590402385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$irDD.LCCOCM.CommunityGroupOrganizationPostModelTypeDescriptor()
                        const $t1 = $.$irDD.LCCOCM.CommunityGroupOrganizationPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ALttza ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":467793,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590402385)
            
            //--TRIMMABLE-BOUNDARY-START(4295435089)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295435089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295435089)
            
            //--TRIMMABLE-BOUNDARY-START(4295435089)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295435089)
            
            static $h = 467793;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590402385),
    {
      "r": 65537,
      "n": "Register",
      "d": 467793,
      "h": 8590402385,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590402385)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295435089),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 467793,
      "h": 4295435089,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295435089)
  ],
  "h": 467793
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Models${separator}CommunityGroupOrganizationPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(467793)
        
        

        //--TRIMMABLE-BOUNDARY-START(729937)
        $asm.$cls(`$irDD.LCCOCM.CommunityGroupOrganizationServiceModelTypeDescriptorBuilder`, ($self) => class CommunityGroupOrganizationServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590664529)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590664529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModelTypeDescriptor()
                        const $t1 = $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $FnRbmc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":729937,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590664529)
            
            //--TRIMMABLE-BOUNDARY-START(4295697233)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295697233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295697233)
            
            //--TRIMMABLE-BOUNDARY-START(4295697233)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295697233)
            
            static $h = 729937;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590664529),
    {
      "r": 65537,
      "n": "Register",
      "d": 729937,
      "h": 8590664529,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590664529)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295697233),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 729937,
      "h": 4295697233,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295697233)
  ],
  "h": 729937
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Models${separator}CommunityGroupOrganizationServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(729937)
        
        

        //--TRIMMABLE-BOUNDARY-START(2106193)
        $asm.$cls(`$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStatesTypeDescriptorBuilder`, ($self) => class CommunityOrganizationGroupServiceStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592040785)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592040785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStatesTypeDescriptor()
                        const $t1 = $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Organization.Common.States.CommunityOrganizationGroupServiceStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $wgiuDe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2106193,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592040785)
            
            //--TRIMMABLE-BOUNDARY-START(4297073489)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297073489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297073489)
            
            //--TRIMMABLE-BOUNDARY-START(4297073489)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297073489)
            
            static $h = 2106193;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592040785),
    {
      "r": 65537,
      "n": "Register",
      "d": 2106193,
      "h": 8592040785,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592040785)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297073489),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2106193,
      "h": 4297073489,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297073489)
  ],
  "h": 2106193
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.States.CommunityOrganizationGroupServiceStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}States${separator}CommunityOrganizationGroupServiceStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2106193)
        
        

        //--TRIMMABLE-BOUNDARY-START(1844049)
        $asm.$cls(`$irDD.LCCOCS$2.CommunityGroupOrganizationPostStatesTypeDescriptorBuilder`, ($self) => class CommunityGroupOrganizationPostStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591778641)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591778641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStatesTypeDescriptor()
                        const $t1 = $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Organization.Common.States.CommunityGroupOrganizationPostStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $nUnMug ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1844049,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591778641)
            
            //--TRIMMABLE-BOUNDARY-START(4296811345)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296811345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296811345)
            
            //--TRIMMABLE-BOUNDARY-START(4296811345)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296811345)
            
            static $h = 1844049;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591778641),
    {
      "r": 65537,
      "n": "Register",
      "d": 1844049,
      "h": 8591778641,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591778641)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296811345),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1844049,
      "h": 4296811345,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296811345)
  ],
  "h": 1844049
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.States.CommunityGroupOrganizationPostStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}States${separator}CommunityGroupOrganizationPostStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1844049)
        
        

        //--TRIMMABLE-BOUNDARY-START(926545)
        $asm.$cls(`$irDD.LCCOC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590861137)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590861137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel, 2306/*PostTypes.GroupOrganization*/);
                $.$irDD.LCCOC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$irDD.LCCOC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$irDD.LCCOC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590861137)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$irDD.LCCOC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295893841)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295893841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295893841)
            
            //--TRIMMABLE-BOUNDARY-START(4295893841)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295893841)
            
            static $h = 926545;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590861137),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 926545,
      "h": 8590861137,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590861137)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295893841),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 926545,
      "h": 4295893841,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295893841)
  ],
  "h": 926545
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(926545)
        
        

        //--TRIMMABLE-BOUNDARY-START(795473)
        $asm.$str(`$irDD.LCCOCM.CommunityGroupOrganizationServiceTier`, ($self) => class CommunityGroupOrganizationServiceTier extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Trial = 0;
            static Standard = 1;
            static Gold = 2;
            static Platinum = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(795473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Trial": 0n,
                    "Standard": 1n,
                    "Gold": 2n,
                    "Platinum": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295762769)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295762769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295762769)
            
            //--TRIMMABLE-BOUNDARY-START(4295762769)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295762769)
            
            static $h = 795473;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475631953),
    {
      "t": 795473,
      "n": "Trial",
      "d": 795473,
      "h": 21475631953,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475631953),
//--TRIMMABLE-BOUNDARY-START(17180664657),
    {
      "t": 795473,
      "n": "Standard",
      "d": 795473,
      "h": 17180664657,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180664657),
//--TRIMMABLE-BOUNDARY-START(8590730065),
    {
      "t": 795473,
      "n": "Gold",
      "d": 795473,
      "h": 8590730065,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590730065),
//--TRIMMABLE-BOUNDARY-START(12885697361),
    {
      "t": 795473,
      "n": "Platinum",
      "d": 795473,
      "h": 12885697361,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885697361)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295762769),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 795473,
      "h": 4295762769,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295762769)
  ],
  "h": 795473
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationServiceTier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Models${separator}CommunityGroupOrganizationServiceTier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(795473)
        
        

        //--TRIMMABLE-BOUNDARY-START(1385297)
        $asm.$cls(`$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings`, ($self) => class CommunityGroupOrganizationServiceSettings extends $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296352593)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296352593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296352593)
            
            //--TRIMMABLE-BOUNDARY-START(4296352593)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296352593)
            
            static $h = 1385297;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296352593),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1385297,
      "h": 4296352593,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296352593)
  ],
  "h": 1385297
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationServiceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Settings${separator}CommunityGroupOrganizationServiceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1385297)
        
        

        //--TRIMMABLE-BOUNDARY-START(1647441)
        $asm.$cls(`$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates`, ($self) => class CommunityGroupOrganizationPostStates extends $.$PZCj.LCCGCS$2.CommunityGroupPostStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296614737)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296614737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296614737)
            
            //--TRIMMABLE-BOUNDARY-START(4296614737)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296614737)
            
            static $h = 1647441;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$2.CommunityGroupPostStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296614737),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1647441,
      "h": 4296614737,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296614737)
  ],
  "h": 1647441
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.States.CommunityGroupOrganizationPostStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}States${separator}CommunityGroupOrganizationPostStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1647441)
        
        

        //--TRIMMABLE-BOUNDARY-START(1909585)
        $asm.$cls(`$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates`, ($self) => class CommunityOrganizationGroupServiceStates extends $.$PZCj.LCCGCS$2.CommunityGroupServiceStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296876881)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296876881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296876881)
            
            //--TRIMMABLE-BOUNDARY-START(4296876881)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296876881)
            
            static $h = 1909585;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$2.CommunityGroupServiceStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296876881),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1909585,
      "h": 4296876881,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296876881)
  ],
  "h": 1909585
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.States.CommunityOrganizationGroupServiceStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}States${separator}CommunityOrganizationGroupServiceStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1909585)
        
        

        //--TRIMMABLE-BOUNDARY-START(1123153)
        $asm.$cls(`$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings`, ($self) => class CommunityGroupOrganizationPostSettings extends $.$PZCj.LCCGCS$1.CommunityGroupPostSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296090449)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296090449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296090449)
            
            //--TRIMMABLE-BOUNDARY-START(4296090449)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296090449)
            
            static $h = 1123153;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$1.CommunityGroupPostSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296090449),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1123153,
      "h": 4296090449,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296090449)
  ],
  "h": 1123153
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationPostSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Settings${separator}CommunityGroupOrganizationPostSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1123153)
        
        

        //--TRIMMABLE-BOUNDARY-START(1516369)
        $asm.$cls(`$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettingsTypeDescriptor`, ($self) => class CommunityGroupOrganizationServiceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296483665)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296483665);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettingsTypeDescriptor.GenerateProperties($.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings, this, factory);
                    }, $GLTvOc ??= {"r":65537,"n":"","d":1516369,"h":0,"f":17825794}), 0, "CommunityGroupOrganizationServiceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Organization.Common\\Settings_CommunityGroupOrganizationServiceSettings_LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationServiceSettingsTypeDescriptorBuilder.g.cs", "CommunityGroupOrganizationServiceSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296483665)
            
            //--TRIMMABLE-BOUNDARY-START(12886418257)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886418257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886418257)
            
            //--TRIMMABLE-BOUNDARY-START(17181385553)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationServiceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181385553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Settings.CommunityGroupServiceSettings?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181385553)
            
            //--TRIMMABLE-BOUNDARY-START(8591450961)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationServiceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591450961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings)))
                {
                    /*var*/ let result = $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591450961)
            
            static $h = 1516369;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886418257),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1516369,
      "h": 12886418257,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886418257),
//--TRIMMABLE-BOUNDARY-START(17181385553),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1385297,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1516369,
      "h": 17181385553,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181385553),
//--TRIMMABLE-BOUNDARY-START(8591450961),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1385297,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1516369,
      "h": 8591450961,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591450961)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296483665),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1516369,
      "h": 4296483665,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296483665)
  ],
  "h": 1516369
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationServiceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Settings${separator}CommunityGroupOrganizationServiceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1516369)
        
        

        //--TRIMMABLE-BOUNDARY-START(1254225)
        $asm.$cls(`$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettingsTypeDescriptor`, ($self) => class CommunityGroupOrganizationPostSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296221521)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296221521);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettingsTypeDescriptor.GenerateProperties($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, this, factory);
                    }, $MtwuRk ??= {"r":65537,"n":"","d":1254225,"h":0,"f":17825794}), 0, "CommunityGroupOrganizationPostSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Organization.Common\\Settings_CommunityGroupOrganizationPostSettings_LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationPostSettingsTypeDescriptorBuilder.g.cs", "CommunityGroupOrganizationPostSettingsTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296221521)
            
            //--TRIMMABLE-BOUNDARY-START(12886156113)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886156113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886156113)
            
            //--TRIMMABLE-BOUNDARY-START(17181123409)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationPostSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181123409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Settings.CommunityGroupPostSettings?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$1.CommunityGroupPostSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181123409)
            
            //--TRIMMABLE-BOUNDARY-START(8591188817)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationPostSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591188817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings)))
                {
                    /*var*/ let result = $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591188817)
            
            static $h = 1254225;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886156113),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1254225,
      "h": 12886156113,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886156113),
//--TRIMMABLE-BOUNDARY-START(17181123409),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1123153,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1254225,
      "h": 17181123409,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181123409),
//--TRIMMABLE-BOUNDARY-START(8591188817),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1123153,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1254225,
      "h": 8591188817,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591188817)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296221521),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1254225,
      "h": 4296221521,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296221521)
  ],
  "h": 1254225
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationPostSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Settings${separator}CommunityGroupOrganizationPostSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1254225)
        
        

        //--TRIMMABLE-BOUNDARY-START(2040657)
        $asm.$cls(`$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStatesTypeDescriptor`, ($self) => class CommunityOrganizationGroupServiceStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4297007953)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297007953);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStatesTypeDescriptor.GenerateProperties($.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates, this, factory);
                    }, $zdJtJi ??= {"r":65537,"n":"","d":2040657,"h":0,"f":17825794}), 0, "CommunityOrganizationGroupServiceStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Organization.Common\\States_CommunityOrganizationGroupServiceStates_LivingThing.Core.Community.Organization.Common.States.CommunityOrganizationGroupServiceStatesTypeDescriptorBuilder.g.cs", "CommunityOrganizationGroupServiceStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297007953)
            
            //--TRIMMABLE-BOUNDARY-START(12886942545)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886942545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886942545)
            
            //--TRIMMABLE-BOUNDARY-START(17181909841)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Organization.Common.States.CommunityOrganizationGroupServiceStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181909841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.States.CommunityGroupServiceStates?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181909841)
            
            //--TRIMMABLE-BOUNDARY-START(8591975249)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Organization.Common.States.CommunityOrganizationGroupServiceStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591975249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates)))
                {
                    /*var*/ let result = $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591975249)
            
            static $h = 2040657;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886942545),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2040657,
      "h": 12886942545,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886942545),
//--TRIMMABLE-BOUNDARY-START(17181909841),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1909585,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2040657,
      "h": 17181909841,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181909841),
//--TRIMMABLE-BOUNDARY-START(8591975249),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1909585,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2040657,
      "h": 8591975249,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591975249)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297007953),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2040657,
      "h": 4297007953,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297007953)
  ],
  "h": 2040657
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.States.CommunityOrganizationGroupServiceStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}States${separator}CommunityOrganizationGroupServiceStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2040657)
        
        

        //--TRIMMABLE-BOUNDARY-START(1778513)
        $asm.$cls(`$irDD.LCCOCS$2.CommunityGroupOrganizationPostStatesTypeDescriptor`, ($self) => class CommunityGroupOrganizationPostStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296745809)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296745809);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStatesTypeDescriptor.GenerateProperties($.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates, this, factory);
                    }, $vhUlgc ??= {"r":65537,"n":"","d":1778513,"h":0,"f":17825794}), 0, "CommunityGroupOrganizationPostStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Organization.Common\\States_CommunityGroupOrganizationPostStates_LivingThing.Core.Community.Organization.Common.States.CommunityGroupOrganizationPostStatesTypeDescriptorBuilder.g.cs", "CommunityGroupOrganizationPostStatesTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296745809)
            
            //--TRIMMABLE-BOUNDARY-START(12886680401)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886680401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886680401)
            
            //--TRIMMABLE-BOUNDARY-START(17181647697)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Organization.Common.States.CommunityGroupOrganizationPostStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181647697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.States.CommunityGroupPostStates?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$2.CommunityGroupPostStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181647697)
            
            //--TRIMMABLE-BOUNDARY-START(8591713105)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Organization.Common.States.CommunityGroupOrganizationPostStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591713105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates)))
                {
                    /*var*/ let result = $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591713105)
            
            static $h = 1778513;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886680401),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1778513,
      "h": 12886680401,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886680401),
//--TRIMMABLE-BOUNDARY-START(17181647697),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1647441,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1778513,
      "h": 17181647697,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181647697),
//--TRIMMABLE-BOUNDARY-START(8591713105),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1647441,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1778513,
      "h": 8591713105,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591713105)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296745809),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1778513,
      "h": 4296745809,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296745809)
  ],
  "h": 1778513
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.States.CommunityGroupOrganizationPostStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}States${separator}CommunityGroupOrganizationPostStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1778513)
        
        

        //--TRIMMABLE-BOUNDARY-START(271185)
        $asm.$cls(`$irDD.LCCOCM.CommunityGroupOrganizationPostModel`, ($self) => class CommunityGroupOrganizationPostModel extends $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates)
        {
            //--TRIMMABLE-BOUNDARY-START(38654976849)
            /*PostTypes */ get Type()
            {
                return 2306/*PostTypes.GroupOrganization*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38654976849)
            
            //--TRIMMABLE-BOUNDARY-START(25770074961)
            /*string? */ get ServiceId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885173073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "ServiceId", null);
            }
            /*string? */ set ServiceId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360009553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "ServiceId");
            }
            //--TRIMMABLE-BOUNDARY-END(25770074961)
            
            //--TRIMMABLE-BOUNDARY-START(4295238481)
            //default constructor overload
            $ctor$9()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295238481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295238481)
            
            //--TRIMMABLE-BOUNDARY-START(4295238481)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(4295238481)
            
            static $h = 271185;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38654976849),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475107665,
        "f": 50364417
      },
      "n": "Type",
      "d": 271185,
      "h": 38654976849,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38654976849),
//--TRIMMABLE-BOUNDARY-START(25770074961),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885173073,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360009553,
        "f": 83886081
      },
      "n": "ServiceId",
      "d": 271185,
      "h": 25770074961,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770074961)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295238481),
    {
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 271185,
      "h": 4295238481,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295238481)
  ],
  "h": 271185,
  "a": [
    {
      "t": $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates).$h,
      "c": Number(BigInt($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates).$h)|0x100000000n)
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostRatable, $.$YUlm.LCSCM.IShipmentAccount, $.$Iaui.LCFCM.IApplicationAccountModel, $.$LCOv.LCFCP.IPostNamedLocation, $.$PZCj.LCCGCM.ICommunityGroupModel, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostReactable, $.$LCOv.LCFCP.IPostSharable, $.$LCOv.LCFCP.IPostViewTrackable, $.$LCOv.LCFCP.IPostApplicationScope, $.$LCOv.LCFCP.IGroupAccountModel, $.$LCOv.LCFCP.IUserAccountModel, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Models${separator}CommunityGroupOrganizationPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(271185)
        
        

        //--TRIMMABLE-BOUNDARY-START(992081)
        $asm.$cls(`$irDD.LCCOCS.IComunityOrganizationRemoteService`, ($self) => class IComunityOrganizationRemoteService
        {
            static $h = 992081;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 992081,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.IReadDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Services.IComunityOrganizationRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Services${separator}IComunityOrganizationRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(992081)
        
        

        //--TRIMMABLE-BOUNDARY-START(1057617)
        $asm.$cls(`$irDD.LCCOCS.IComunityOrganizationRemoteService_Mocking`, ($self) => class IComunityOrganizationRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296024913)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296024913);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296024913)
            
            //--TRIMMABLE-BOUNDARY-START(8590992209)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Organization$Common$Models$CommunityGroupOrganizationPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590992209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590992209)
            
            //--TRIMMABLE-BOUNDARY-START(17180926801)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Organization$Common$Models$CommunityGroupOrganizationPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180926801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180926801)
            
            //--TRIMMABLE-BOUNDARY-START(21475894097)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Organization$Common$Models$CommunityGroupOrganizationPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475894097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475894097)
            
            //--TRIMMABLE-BOUNDARY-START(25770861393)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Organization$Common$Models$CommunityGroupOrganizationPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770861393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770861393)
            
            //--TRIMMABLE-BOUNDARY-START(12885959505)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885959505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885959505)
            
            static $h = 1057617;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296024913),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1057617,
      "h": 4296024913,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296024913)
  ],
  "h": 1057617
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$irDD.LCCOCS.IComunityOrganizationRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.IReadDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Services.IComunityOrganizationRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Services${separator}IComunityOrganizationRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1057617)
        
        

        //--TRIMMABLE-BOUNDARY-START(533329)
        $asm.$cls(`$irDD.LCCOCM.CommunityGroupOrganizationServiceModel`, ($self) => class CommunityGroupOrganizationServiceModel extends $.$Iaui.LCFCM.ServiceModel$$$$($.$irDD.LCCOCM.CommunityGroupOrganizationServiceTier, $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings, $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(30065304401)
            /*DataId*/ GroupAccountId;
            //--TRIMMABLE-BOUNDARY-END(30065304401)
            
            //--TRIMMABLE-BOUNDARY-START(34360271697)
            /*string? */ get ServiceLink()
            {
                return `/Organization/${$.$strNN(this.Name)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(34360271697)
            
            //--TRIMMABLE-BOUNDARY-START(8590467921)
            //default constructor overload
            $ctor$9()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590467921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590467921)
            
            //--TRIMMABLE-BOUNDARY-START(8590467921)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(8590467921)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30065304401)
                this.GroupAccountId = $.$default($.$fPer.LCFCD.DataId);
                //--TRIMMABLE-BOUNDARY-END(30065304401)
                
            }
            static $h = 533329;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ServiceModel$$$$($.$irDD.LCCOCM.CommunityGroupOrganizationServiceTier, $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings, $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065304401),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180402513,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950206289,
        "f": 83886081
      },
      "n": "GroupAccountId",
      "d": 533329,
      "h": 30065304401,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065304401),
//--TRIMMABLE-BOUNDARY-START(34360271697),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770337105,
        "f": 50364417
      },
      "n": "ServiceLink",
      "d": 533329,
      "h": 34360271697,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360271697)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590467921),
    {
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 533329,
      "h": 8590467921,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590467921)
  ],
  "h": 533329
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$irDD.LCCOCM.CommunityGroupOrganizationServiceTier), $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Models${separator}CommunityGroupOrganizationServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(533329)
        
        

        //--TRIMMABLE-BOUNDARY-START(402257)
        $asm.$cls(`$irDD.LCCOCM.CommunityGroupOrganizationPostModelTypeDescriptor`, ($self) => class CommunityGroupOrganizationPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295369553)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295369553);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$irDD.LCCOCM.CommunityGroupOrganizationPostModelTypeDescriptor.GenerateProperties($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel, this, factory);
                    }, $reVFma ??= {"r":65537,"n":"","d":402257,"h":0,"f":17825794}), 0, "CommunityGroupOrganizationPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Organization.Common\\Models_CommunityGroupOrganizationPostModel_LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModelTypeDescriptorBuilder.g.cs", "CommunityGroupOrganizationPostModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295369553)
            
            //--TRIMMABLE-BOUNDARY-START(12885304145)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885304145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$irDD.LCCOCM.CommunityGroupOrganizationPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$irDD.LCCOCM.CommunityGroupOrganizationPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$irDD.LCCOCM.CommunityGroupOrganizationPostModel)).Type);
                        }, $GlQrZe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":402257,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$irDD.LCCOCM.CommunityGroupOrganizationPostModel.$type, $.$discardRef(), "ServiceId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "ServiceId";
                        $i3.DelaredOn = "LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$irDD.LCCOCM.CommunityGroupOrganizationPostModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$irDD.LCCOCM.CommunityGroupOrganizationPostModel)).ServiceId);
                        }, $HAatQa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":402257,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$irDD.LCCOCM.CommunityGroupOrganizationPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ServiceId = value.AsReference($.$$.S.String);
                        }, $smqSDi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":402257,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885304145)
            
            //--TRIMMABLE-BOUNDARY-START(17180271441)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180271441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel<LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationPostSettings, LivingThing.Core.Community.Organization.Common.States.CommunityGroupOrganizationPostStates>?*/ let targetBase = _target;
                $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$irDD.LCCOCS$1.CommunityGroupOrganizationPostSettings, $.$irDD.LCCOCS$2.CommunityGroupOrganizationPostStates)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _ServiceId = _target.ServiceId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ServiceId, ($v) => _ServiceId = $v, $.$$.S.String)))
                    {
                        _target.ServiceId = _ServiceId;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180271441)
            
            //--TRIMMABLE-BOUNDARY-START(8590336849)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590336849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$irDD.LCCOCM.CommunityGroupOrganizationPostModel().$ctor$9();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$irDD.LCCOCM.CommunityGroupOrganizationPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCM.CommunityGroupOrganizationPostModel)))
                {
                    /*var*/ let result = $.$irDD.LCCOCM.CommunityGroupOrganizationPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCM.CommunityGroupOrganizationPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$irDD.LCCOCM.CommunityGroupOrganizationPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCM.CommunityGroupOrganizationPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590336849)
            
            static $h = 402257;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885304145),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 402257,
      "h": 12885304145,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885304145),
//--TRIMMABLE-BOUNDARY-START(17180271441),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 271185,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 402257,
      "h": 17180271441,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180271441),
//--TRIMMABLE-BOUNDARY-START(8590336849),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 271185,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 402257,
      "h": 8590336849,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590336849)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295369553),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 402257,
      "h": 4295369553,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295369553)
  ],
  "h": 402257
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$irDD.LCCOCM.CommunityGroupOrganizationPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Models${separator}CommunityGroupOrganizationPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(402257)
        
        

        //--TRIMMABLE-BOUNDARY-START(664401)
        $asm.$cls(`$irDD.LCCOCM.CommunityGroupOrganizationServiceModelTypeDescriptor`, ($self) => class CommunityGroupOrganizationServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295631697)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295631697);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModelTypeDescriptor.GenerateProperties($.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel, this, factory);
                    }, $OIENJi ??= {"r":65537,"n":"","d":664401,"h":0,"f":17825794}), 0, "CommunityGroupOrganizationServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Organization.Common\\Models_CommunityGroupOrganizationServiceModel_LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationServiceModelTypeDescriptorBuilder.g.cs", "CommunityGroupOrganizationServiceModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295631697)
            
            //--TRIMMABLE-BOUNDARY-START(12885566289)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885566289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("GroupAccountId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel.$type, $.$discardRef(), "GroupAccountId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("GroupAccountId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "GroupAccountId";
                        $i1.DelaredOn = "LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationServiceModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$irDD.LCCOCM.CommunityGroupOrganizationServiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel)).GroupAccountId);
                        }, $FbFAdk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":664401,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$irDD.LCCOCM.CommunityGroupOrganizationServiceModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.GroupAccountId = value.AsValue($.$fPer.LCFCD.DataId);
                        }, $CuRfFi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":664401,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceLink"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel.$type, $.$discardRef(), "ServiceLink", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceLink")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "ServiceLink";
                        $i3.DelaredOn = "LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationServiceModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$irDD.LCCOCM.CommunityGroupOrganizationServiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel)).ServiceLink);
                        }, $GHnWpj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":664401,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCM.ServiceModelTypeDescriptor$$$$($.$irDD.LCCOCM.CommunityGroupOrganizationServiceTier, $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings, $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885566289)
            
            //--TRIMMABLE-BOUNDARY-START(17180533585)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180533585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ServiceModel<LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationServiceTier, LivingThing.Core.Community.Organization.Common.Settings.CommunityGroupOrganizationServiceSettings, LivingThing.Core.Community.Organization.Common.States.CommunityOrganizationGroupServiceStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ServiceModelTypeDescriptor$$$$($.$irDD.LCCOCM.CommunityGroupOrganizationServiceTier, $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings, $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ServiceModel$$$$($.$irDD.LCCOCM.CommunityGroupOrganizationServiceTier, $.$irDD.LCCOCS$1.CommunityGroupOrganizationServiceSettings, $.$irDD.LCCOCS$2.CommunityOrganizationGroupServiceStates)));
                {
                    /*var*/ let _GroupAccountId = _target.GroupAccountId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("GroupAccountId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _GroupAccountId, ($v) => _GroupAccountId = $v, null, true)))
                    {
                        _target.GroupAccountId = $.$clone(_GroupAccountId);
                    }
                }
                {
                    /*var*/ let _ServiceLink = _target.ServiceLink;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceLink"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ServiceLink, ($v) => _ServiceLink = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180533585)
            
            //--TRIMMABLE-BOUNDARY-START(8590598993)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590598993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel().$ctor$9();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel)))
                {
                    /*var*/ let result = $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590598993)
            
            static $h = 664401;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885566289),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 664401,
      "h": 12885566289,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885566289),
//--TRIMMABLE-BOUNDARY-START(17180533585),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 533329,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 664401,
      "h": 17180533585,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180533585),
//--TRIMMABLE-BOUNDARY-START(8590598993),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 533329,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 664401,
      "h": 8590598993,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590598993)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295631697),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 664401,
      "h": 4295631697,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295631697)
  ],
  "h": 664401
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$irDD.LCCOCM.CommunityGroupOrganizationServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Organization.Common.Models.CommunityGroupOrganizationServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Organization${separator}Common${separator}Models${separator}CommunityGroupOrganizationServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(664401)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Group.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(9041)
