
//--TRIMMABLE-BOUNDARY-START(54941)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $lmlW) {
    "use strict";
    let _;
    let $lUXLpf;
    let $ZwCfrh;
    let $WsMbZe;
    let $QKDSie;
    let $RgLHKg;
    let $ZrwKZf;
    let $ZApkcf;
    let $YTTosb;
    let $TKmpUg;
    let $WZXamh;
    let $ozWvJf;
    let $bwducc;
    let $hHUAXb;
    let $lNvVue;
    let $tIpwOk;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Pay.Client.Blazor", 
    {
  "h": 54941,
  "f": "LivingThing.Core.Community.Pay.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Pay.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Pay.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(186013)
        $asm.$cls(`$izAa.LCCPC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295153309)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295153309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$izAa.LCCPC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295153309)
            
            static $h = 186013;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295153309),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 186013,
      "h": 4295153309,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295153309)
  ],
  "h": 186013
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(186013)
        
        

        //--TRIMMABLE-BOUNDARY-START(251549)
        $asm.$cls(`$izAa.LCCPC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180120733)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$izAa.LCCPCP.CommunityPayApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$izAa.LCCPCP.CommunityPayApp().$ctor$3();
                    }, $lUXLpf ??= {"r":2752627,"n":"","d":251549,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180120733)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295218845)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295218845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295218845)
            
            //--TRIMMABLE-BOUNDARY-START(4295218845)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295218845)
            
            static $h = 251549;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180120733),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885153437,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 251549,
      "h": 17180120733,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180120733)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295218845),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 251549,
      "h": 4295218845,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295218845)
  ],
  "h": 251549
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(251549)
        
        

        //--TRIMMABLE-BOUNDARY-START(382621)
        $asm.$cls(`$izAa.LCCPC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590317213)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590317213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$izAa.LCCPCS.CommunityPayService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$lmlW.LCCPCM.CommunityPayPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$izAa.LCCPCS.CommunityPayApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$izAa.LCCPCS.CommunityPayApplication, x);
                }, $ZwCfrh ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":382621,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$izAa.LCCPCS.CommunityPayApplication, x);
                }, $WsMbZe ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":382621,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$lmlW.LCCPCM.CommunityPayPostModel, services, null);
                $.$izAa.LCCPC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590317213)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$izAa.LCCPC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295349917)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295349917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295349917)
            
            //--TRIMMABLE-BOUNDARY-START(4295349917)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295349917)
            
            static $h = 382621;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590317213),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 382621,
      "h": 8590317213,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590317213)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295349917),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 382621,
      "h": 4295349917,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295349917)
  ],
  "h": 382621
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(382621)
        
        

        //--TRIMMABLE-BOUNDARY-START(644765)
        $asm.$cls(`$izAa.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295612061)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295612061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295612061)
            
            //--TRIMMABLE-BOUNDARY-START(4295612061)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295612061)
            
            static $h = 644765;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295612061),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 644765,
      "h": 4295612061,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295612061)
  ],
  "h": 644765,
  "a": [
    {
      "t": 579229,
      "c": 4295546525
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(644765)
        
        

        //--TRIMMABLE-BOUNDARY-START(579229)
        $asm.$cls(`$izAa.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295546525)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295546525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295546525)
            
            //--TRIMMABLE-BOUNDARY-START(4295546525)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295546525)
            
            static $h = 579229;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295546525),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 579229,
      "h": 4295546525,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295546525)
  ],
  "h": 579229
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(579229)
        
        

        //--TRIMMABLE-BOUNDARY-START(120477)
        $asm.$cls(`$izAa.LCCPC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590055069)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590055069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590055069)
            
            //--TRIMMABLE-BOUNDARY-START(4295087773)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295087773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295087773)
            
            //--TRIMMABLE-BOUNDARY-START(4295087773)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295087773)
            
            static $h = 120477;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590055069),
    {
      "r": 65537,
      "n": "Execute",
      "d": 120477,
      "h": 8590055069,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590055069)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295087773),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 120477,
      "h": 4295087773,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295087773)
  ],
  "h": 120477
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(120477)
        
        

        //--TRIMMABLE-BOUNDARY-START(317085)
        $asm.$cls(`$izAa.LCCPCP.CommunityPayApp`, ($self) => class CommunityPayApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(60129859229)
            /*CommunityPayService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(60129859229)
            
            //--TRIMMABLE-BOUNDARY-START(21475153565)
            /*CommunityPayApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(21475153565)
            
            //--TRIMMABLE-BOUNDARY-START(55834891933)
            /*IUIRenderingProvider*/ Rendering = null;
            //--TRIMMABLE-BOUNDARY-END(55834891933)
            
            //--TRIMMABLE-BOUNDARY-START(25770120861)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770120861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "InitialViewIndex", "0");
                __builder.AddComponentParameter(2, "Name", "Pay");
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(5, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 6);
                        __builder2.AddComponentParameter(7, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                        __builder2.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(9, wrap.View);
                        }), $QKDSie ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":317085,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $RgLHKg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":317085,"h":0,"f":17825794});
                }), $ZrwKZf ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":317085,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/*splash*/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 11);
                        __builder2.AddComponentParameter(12, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, splash.ViewModel));
                        __builder2.AddComponentParameter(13, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, splash.Message));
                        __builder2.CloseComponent();
                    }, $ZApkcf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":317085,"h":0,"f":17825794});
                }), $YTTosb ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":317085,"h":0,"f":17825794}));
                __builder.AddAttribute$3(14, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 15);
                    __builder2.AddComponentParameter(16, "Name", "");
                    __builder2.AddComponentParameter(17, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddAttribute$3(18, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(19, "Pay");
                        }, $TKmpUg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":317085,"h":0,"f":17825794});
                    }), $WZXamh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":317085,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(20, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(21, "<i class=\"mdi mdi-book\"></i>");
                        }, $ozWvJf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":317085,"h":0,"f":17825794});
                    }), $bwducc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":317085,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(22, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityApplicationUnderDevelopment, 23);
                            __builder3.AddComponentParameter(24, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCS.ICommunityClientApplication, this.Application));
                            __builder3.CloseComponent();
                        }, $hHUAXb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":317085,"h":0,"f":17825794});
                    }), $lNvVue ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":317085,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $tIpwOk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":317085,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25770120861)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180186269)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180186269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180186269)
            
            //--TRIMMABLE-BOUNDARY-START(17180186269)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17180186269)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60129859229)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(60129859229)
                
                //--TRIMMABLE-BOUNDARY-START(21475153565)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(21475153565)
                
                //--TRIMMABLE-BOUNDARY-START(55834891933)
                this.Rendering = null;
                //--TRIMMABLE-BOUNDARY-END(55834891933)
                
            }
            static $h = 317085;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129859229),
    {
      "p": 513693,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539924637,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899663005,
        "f": 83886081
      },
      "n": "Service",
      "d": 317085,
      "h": 60129859229,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60129859229),
//--TRIMMABLE-BOUNDARY-START(21475153565),
    {
      "p": 448157,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360055453,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719793821,
        "f": 83886081
      },
      "n": "Application",
      "d": 317085,
      "h": 21475153565,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475153565),
//--TRIMMABLE-BOUNDARY-START(55834891933),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949990045,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309728413,
        "f": 83886081
      },
      "n": "Rendering",
      "d": 317085,
      "h": 55834891933,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834891933)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770120861),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 317085,
      "h": 25770120861,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770120861)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180186269),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 317085,
      "h": 17180186269,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180186269)
  ],
  "h": 317085
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Client.Pages.CommunityPayApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Client${separator}Pages${separator}CommunityPayApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(317085)
        
        

        //--TRIMMABLE-BOUNDARY-START(448157)
        $asm.$cls(`$izAa.LCCPCS.CommunityPayApplication`, ($self) => class CommunityPayApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885350045)
            $ctor$5(/*CommunityPayService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885350045);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885350045)
            
            //--TRIMMABLE-BOUNDARY-START(137439401629)
            /*string */ get Name()
            {
                return "Pay";
            }
            //--TRIMMABLE-BOUNDARY-END(137439401629)
            
            //--TRIMMABLE-BOUNDARY-START(154619270813)
            /*string */ get Title()
            {
                return "Pay";
            }
            //--TRIMMABLE-BOUNDARY-END(154619270813)
            
            //--TRIMMABLE-BOUNDARY-START(21475284637)
            /*string */ get Description()
            {
                return "Pay for good and services using our payment mediattion service. Your money is released only when you are satisfied";
            }
            //--TRIMMABLE-BOUNDARY-END(21475284637)
            
            //--TRIMMABLE-BOUNDARY-START(133144434333)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-cash"/*MaterialDesignIconNames.Cash*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144434333)
            
            //--TRIMMABLE-BOUNDARY-START(150324303517)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2E969B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(150324303517)
            
            //--TRIMMABLE-BOUNDARY-START(30065219229)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065219229)
            
            //--TRIMMABLE-BOUNDARY-START(17180317341)
            /*Type? */ get ApplicationViewType()
            {
                return $.$izAa.LCCPCP.CommunityPayApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180317341)
            
            //--TRIMMABLE-BOUNDARY-START(128849467037)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849467037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$izAa.LCCPCP.CommunityPayApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849467037)
            
            //--TRIMMABLE-BOUNDARY-START(25770251933)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770251933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770251933)
            
            //--TRIMMABLE-BOUNDARY-START(141734368925)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734368925)
            
            //--TRIMMABLE-BOUNDARY-START(4295415453)
            /*CommunityPayService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295415453)
            
            //--TRIMMABLE-BOUNDARY-START(146029336221)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(146029336221)
            
            //--TRIMMABLE-BOUNDARY-START(158914238109)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(4608/*PostTypes.Pay*/, 4609/*PostTypes.PayEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(158914238109)
            
            static $h = 448157;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439401629),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604826781,
        "f": 50364417
      },
      "n": "Name",
      "d": 448157,
      "h": 137439401629,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439401629),
//--TRIMMABLE-BOUNDARY-START(154619270813),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964565149,
        "f": 50364417
      },
      "n": "Title",
      "d": 448157,
      "h": 154619270813,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619270813),
//--TRIMMABLE-BOUNDARY-START(21475284637),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835023005,
        "f": 50364417
      },
      "n": "Description",
      "d": 448157,
      "h": 21475284637,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475284637),
//--TRIMMABLE-BOUNDARY-START(133144434333),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014892189,
        "f": 50364417
      },
      "n": "Icon",
      "d": 448157,
      "h": 133144434333,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144434333),
//--TRIMMABLE-BOUNDARY-START(150324303517),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374630557,
        "f": 50364417
      },
      "n": "Theme",
      "d": 448157,
      "h": 150324303517,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324303517),
//--TRIMMABLE-BOUNDARY-START(30065219229),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424957597,
        "f": 50364417
      },
      "n": "Features",
      "d": 448157,
      "h": 30065219229,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065219229),
//--TRIMMABLE-BOUNDARY-START(17180317341),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245088413,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 448157,
      "h": 17180317341,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180317341),
//--TRIMMABLE-BOUNDARY-START(141734368925),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194761373,
        "f": 50364417
      },
      "n": "Order",
      "d": 448157,
      "h": 141734368925,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734368925),
//--TRIMMABLE-BOUNDARY-START(4295415453),
    {
      "p": 513693,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655153821,
        "f": 50331650
      },
      "n": "_Service",
      "d": 448157,
      "h": 4295415453,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295415453),
//--TRIMMABLE-BOUNDARY-START(146029336221),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784695965,
        "f": 50364417
      },
      "n": "Service",
      "d": 448157,
      "h": 146029336221,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029336221),
//--TRIMMABLE-BOUNDARY-START(158914238109),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554499741,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 448157,
      "h": 158914238109,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914238109)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849467037),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 448157,
      "h": 128849467037,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849467037),
//--TRIMMABLE-BOUNDARY-START(25770251933),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 448157,
      "h": 25770251933,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770251933)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885350045),
    {
      "p": [
        {
          "n": "service",
          "p": 513693
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 448157,
      "h": 12885350045,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885350045)
  ],
  "h": 448157
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Client.Services.CommunityPayApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Client${separator}Services${separator}CommunityPayApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(448157)
        
        

        //--TRIMMABLE-BOUNDARY-START(513693)
        $asm.$cls(`$izAa.LCCPCS.CommunityPayService`, ($self) => class CommunityPayService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$lmlW.LCCPCM.CommunityPayPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295480989)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295480989);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295480989)
            
            static $h = 513693;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$lmlW.LCCPCM.CommunityPayPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295480989),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 513693,
      "h": 4295480989,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295480989)
  ],
  "h": 513693
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$lmlW.LCCPCM.CommunityPayPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$lmlW.LCCPCM.CommunityPayPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Client.Services.CommunityPayService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Client${separator}Services${separator}CommunityPayService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(513693)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Pay.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(54941)
