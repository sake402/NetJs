
//--TRIMMABLE-BOUNDARY-START(44823)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $bfuWTb;
    let $baboHi;
    let $EGmULb;
    let $oQTlXd;
    let $SlSUgh;
    let $AElhzj;
    let $ohnnGg;
    let $oJGZhf;
    let $zvbGib;
    let $zpCPua;
    let $XncVTf;
    let $vFspUd;
    let $DBwipe;
    let $pTMORb;
    let $XxcGek;
    let $xLjSTa;
    let $TESMck;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Pay.Common", 
    {
  "h": 44823,
  "f": "LivingThing.Core.Community.Pay.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Pay.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Pay.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1290007)
        $asm.$cls(`$lmlW.LCCPCS$2.CommunityPayStatesCustomAttributesProvider`, ($self) => class CommunityPayStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296257303)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296257303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296257303)
            
            static $h = 1290007;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296257303),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1290007,
      "h": 4296257303,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296257303)
  ],
  "h": 1290007
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.States.CommunityPayStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}States${separator}CommunityPayStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1290007)
        
        

        //--TRIMMABLE-BOUNDARY-START(110359)
        $asm.$cls(`$lmlW.LCCPC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295077655)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295077655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$lmlW.LCCPCM.CommunityPayModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$lmlW.LCCPCM.CommunityPayModelCustomAttributesProvider, $.$lmlW.LCCPCM.CommunityPayModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$lmlW.LCCPCM.CommunityPayPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$lmlW.LCCPCM.CommunityPayPostModelCustomAttributesProvider, $.$lmlW.LCCPCM.CommunityPayPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$lmlW.LCCPCS$1.CommunityPaySettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$lmlW.LCCPCS$1.CommunityPaySettingsCustomAttributesProvider, $.$lmlW.LCCPCS$1.CommunityPaySettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$lmlW.LCCPCS$2.CommunityPayStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$lmlW.LCCPCS$2.CommunityPayStatesCustomAttributesProvider, $.$lmlW.LCCPCS$2.CommunityPayStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295077655)
            
            static $h = 110359;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295077655),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 110359,
      "h": 4295077655,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295077655)
  ],
  "h": 110359
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(110359)
        
        

        //--TRIMMABLE-BOUNDARY-START(569111)
        $asm.$cls(`$lmlW.LCCPCM.CommunityPayPostModelCustomAttributesProvider`, ($self) => class CommunityPayPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295536407)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295536407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295536407)
            
            static $h = 569111;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295536407),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 569111,
      "h": 4295536407,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295536407)
  ],
  "h": 569111
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Models${separator}CommunityPayPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(569111)
        
        

        //--TRIMMABLE-BOUNDARY-START(1027863)
        $asm.$cls(`$lmlW.LCCPCS$1.CommunityPaySettingsCustomAttributesProvider`, ($self) => class CommunityPaySettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295995159)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295995159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295995159)
            
            static $h = 1027863;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295995159),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1027863,
      "h": 4295995159,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295995159)
  ],
  "h": 1027863
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Settings.CommunityPaySettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Settings${separator}CommunityPaySettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1027863)
        
        

        //--TRIMMABLE-BOUNDARY-START(306967)
        $asm.$cls(`$lmlW.LCCPCM.CommunityPayModelCustomAttributesProvider`, ($self) => class CommunityPayModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295274263)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295274263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$lmlW.LCCPCS$1.CommunityPaySettings, $.$lmlW.LCCPCS$2.CommunityPayStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295274263)
            
            static $h = 306967;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295274263),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 306967,
      "h": 4295274263,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295274263)
  ],
  "h": 306967
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Models.CommunityPayModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Models${separator}CommunityPayModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(306967)
        
        

        //--TRIMMABLE-BOUNDARY-START(1158935)
        $asm.$cls(`$lmlW.LCCPCS$1.CommunityPaySettingsTypeDescriptorBuilder`, ($self) => class CommunityPaySettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591093527)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591093527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$lmlW.LCCPCS$1.CommunityPaySettingsTypeDescriptor()
                        const $t1 = $.$lmlW.LCCPCS$1.CommunityPaySettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Pay.Common.Settings.CommunityPaySettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $zvbGib ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1158935,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$lmlW.LCCPCS$1.CommunityPaySettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591093527)
            
            //--TRIMMABLE-BOUNDARY-START(4296126231)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296126231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296126231)
            
            //--TRIMMABLE-BOUNDARY-START(4296126231)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296126231)
            
            static $h = 1158935;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591093527),
    {
      "r": 65537,
      "n": "Register",
      "d": 1158935,
      "h": 8591093527,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591093527)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296126231),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1158935,
      "h": 4296126231,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296126231)
  ],
  "h": 1158935
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Settings.CommunityPaySettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Settings${separator}CommunityPaySettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1158935)
        
        

        //--TRIMMABLE-BOUNDARY-START(1486615)
        $asm.$cls(`$lmlW.LCCPC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296453911)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296453911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$lmlW.LCCPCM.CommunityPayModelTypeDescriptorBuilder.Register();
                $.$lmlW.LCCPCM.CommunityPayPostModelTypeDescriptorBuilder.Register();
                $.$lmlW.LCCPCS$1.CommunityPaySettingsTypeDescriptorBuilder.Register();
                $.$lmlW.LCCPCS$2.CommunityPayStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296453911)
            
            static $h = 1486615;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296453911),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1486615,
      "h": 4296453911,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296453911)
  ],
  "h": 1486615
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1486615)
        
        

        //--TRIMMABLE-BOUNDARY-START(438039)
        $asm.$cls(`$lmlW.LCCPCM.CommunityPayModelTypeDescriptorBuilder`, ($self) => class CommunityPayModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590372631)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590372631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$lmlW.LCCPCM.CommunityPayModelTypeDescriptor()
                        const $t1 = $.$lmlW.LCCPCM.CommunityPayModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Pay.Common.Models.CommunityPayModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XncVTf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":438039,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$lmlW.LCCPCM.CommunityPayModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590372631)
            
            //--TRIMMABLE-BOUNDARY-START(4295405335)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295405335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295405335)
            
            //--TRIMMABLE-BOUNDARY-START(4295405335)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295405335)
            
            static $h = 438039;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590372631),
    {
      "r": 65537,
      "n": "Register",
      "d": 438039,
      "h": 8590372631,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590372631)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295405335),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 438039,
      "h": 4295405335,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295405335)
  ],
  "h": 438039
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Models.CommunityPayModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Models${separator}CommunityPayModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(438039)
        
        

        //--TRIMMABLE-BOUNDARY-START(1421079)
        $asm.$cls(`$lmlW.LCCPCS$2.CommunityPayStatesTypeDescriptorBuilder`, ($self) => class CommunityPayStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591355671)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591355671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$lmlW.LCCPCS$2.CommunityPayStatesTypeDescriptor()
                        const $t1 = $.$lmlW.LCCPCS$2.CommunityPayStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Pay.Common.States.CommunityPayStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $DBwipe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1421079,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$lmlW.LCCPCS$2.CommunityPayStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591355671)
            
            //--TRIMMABLE-BOUNDARY-START(4296388375)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296388375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296388375)
            
            //--TRIMMABLE-BOUNDARY-START(4296388375)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296388375)
            
            static $h = 1421079;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591355671),
    {
      "r": 65537,
      "n": "Register",
      "d": 1421079,
      "h": 8591355671,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591355671)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296388375),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1421079,
      "h": 4296388375,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296388375)
  ],
  "h": 1421079
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.States.CommunityPayStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}States${separator}CommunityPayStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1421079)
        
        

        //--TRIMMABLE-BOUNDARY-START(700183)
        $asm.$cls(`$lmlW.LCCPCM.CommunityPayPostModelTypeDescriptorBuilder`, ($self) => class CommunityPayPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590634775)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590634775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$lmlW.LCCPCM.CommunityPayPostModelTypeDescriptor()
                        const $t1 = $.$lmlW.LCCPCM.CommunityPayPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XxcGek ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":700183,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$lmlW.LCCPCM.CommunityPayPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590634775)
            
            //--TRIMMABLE-BOUNDARY-START(4295667479)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295667479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295667479)
            
            //--TRIMMABLE-BOUNDARY-START(4295667479)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295667479)
            
            static $h = 700183;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590634775),
    {
      "r": 65537,
      "n": "Register",
      "d": 700183,
      "h": 8590634775,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590634775)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295667479),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 700183,
      "h": 4295667479,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295667479)
  ],
  "h": 700183
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Models${separator}CommunityPayPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(700183)
        
        

        //--TRIMMABLE-BOUNDARY-START(175895)
        $asm.$cls(`$lmlW.LCCPC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295143191)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295143191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$lmlW.LCCPCS.IComunityPayRemoteService, $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking().$ctor$3(impl);
                }, $bfuWTb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":175895,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking().$ctor$3(impl);
                }, $baboHi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":175895,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking().$ctor$3(impl);
                }, $EGmULb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":175895,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking().$ctor$3(impl);
                }, $oQTlXd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":175895,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking().$ctor$3(impl);
                }, $SlSUgh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":175895,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking().$ctor$3(impl);
                }, $AElhzj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":175895,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking().$ctor$3(impl);
                }, $ohnnGg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":175895,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$lmlW.LCCPCS.IComunityPayRemoteService_Mocking().$ctor$3(impl);
                }, $oJGZhf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":175895,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295143191)
            
            static $h = 175895;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295143191),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 175895,
      "h": 4295143191,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295143191)
  ],
  "h": 175895
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(175895)
        
        

        //--TRIMMABLE-BOUNDARY-START(765719)
        $asm.$cls(`$lmlW.LCCPC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590700311)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590700311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$lmlW.LCCPCM.CommunityPayPostModel, 4608/*PostTypes.Pay*/);
                $.$lmlW.LCCPC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$lmlW.LCCPC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$lmlW.LCCPC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590700311)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$lmlW.LCCPC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295733015)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295733015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295733015)
            
            //--TRIMMABLE-BOUNDARY-START(4295733015)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295733015)
            
            static $h = 765719;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590700311),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 765719,
      "h": 8590700311,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590700311)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295733015),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 765719,
      "h": 4295733015,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295733015)
  ],
  "h": 765719
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(765719)
        
        

        //--TRIMMABLE-BOUNDARY-START(1224471)
        $asm.$cls(`$lmlW.LCCPCS$2.CommunityPayStates`, ($self) => class CommunityPayStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296191767)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296191767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296191767)
            
            //--TRIMMABLE-BOUNDARY-START(4296191767)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296191767)
            
            static $h = 1224471;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296191767),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1224471,
      "h": 4296191767,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296191767)
  ],
  "h": 1224471
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.States.CommunityPayStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}States${separator}CommunityPayStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1224471)
        
        

        //--TRIMMABLE-BOUNDARY-START(962327)
        $asm.$cls(`$lmlW.LCCPCS$1.CommunityPaySettings`, ($self) => class CommunityPaySettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4295929623)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295929623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295929623)
            
            //--TRIMMABLE-BOUNDARY-START(4295929623)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295929623)
            
            static $h = 962327;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295929623),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 962327,
      "h": 4295929623,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295929623)
  ],
  "h": 962327
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Settings.CommunityPaySettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Settings${separator}CommunityPaySettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(962327)
        
        

        //--TRIMMABLE-BOUNDARY-START(1093399)
        $asm.$cls(`$lmlW.LCCPCS$1.CommunityPaySettingsTypeDescriptor`, ($self) => class CommunityPaySettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lmlW.LCCPCS$1.CommunityPaySettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296060695)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296060695);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$lmlW.LCCPCS$1.CommunityPaySettingsTypeDescriptor.GenerateProperties($.$lmlW.LCCPCS$1.CommunityPaySettings, this, factory);
                    }, $zpCPua ??= {"r":65537,"n":"","d":1093399,"h":0,"f":17825794}), 0, "CommunityPaySettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Pay.Common\\Settings_CommunityPaySettings_LivingThing.Core.Community.Pay.Common.Settings.CommunityPaySettingsTypeDescriptorBuilder.g.cs", "CommunityPaySettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296060695)
            
            //--TRIMMABLE-BOUNDARY-START(12885995287)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885995287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885995287)
            
            //--TRIMMABLE-BOUNDARY-START(17180962583)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Pay.Common.Settings.CommunityPaySettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180962583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180962583)
            
            //--TRIMMABLE-BOUNDARY-START(8591027991)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Pay.Common.Settings.CommunityPaySettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591027991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$lmlW.LCCPCS$1.CommunityPaySettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$lmlW.LCCPCS$1.CommunityPaySettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$lmlW.LCCPCS$1.CommunityPaySettings)))
                {
                    /*var*/ let result = $.$lmlW.LCCPCS$1.CommunityPaySettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$lmlW.LCCPCS$1.CommunityPaySettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$lmlW.LCCPCS$1.CommunityPaySettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$lmlW.LCCPCS$1.CommunityPaySettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591027991)
            
            static $h = 1093399;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lmlW.LCCPCS$1.CommunityPaySettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885995287),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1093399,
      "h": 12885995287,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885995287),
//--TRIMMABLE-BOUNDARY-START(17180962583),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 962327,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1093399,
      "h": 17180962583,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180962583),
//--TRIMMABLE-BOUNDARY-START(8591027991),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 962327,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1093399,
      "h": 8591027991,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591027991)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296060695),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1093399,
      "h": 4296060695,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296060695)
  ],
  "h": 1093399
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$lmlW.LCCPCS$1.CommunityPaySettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Settings.CommunityPaySettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Settings${separator}CommunityPaySettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1093399)
        
        

        //--TRIMMABLE-BOUNDARY-START(1355543)
        $asm.$cls(`$lmlW.LCCPCS$2.CommunityPayStatesTypeDescriptor`, ($self) => class CommunityPayStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lmlW.LCCPCS$2.CommunityPayStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296322839)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296322839);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$lmlW.LCCPCS$2.CommunityPayStatesTypeDescriptor.GenerateProperties($.$lmlW.LCCPCS$2.CommunityPayStates, this, factory);
                    }, $pTMORb ??= {"r":65537,"n":"","d":1355543,"h":0,"f":17825794}), 0, "CommunityPayStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Pay.Common\\States_CommunityPayStates_LivingThing.Core.Community.Pay.Common.States.CommunityPayStatesTypeDescriptorBuilder.g.cs", "CommunityPayStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296322839)
            
            //--TRIMMABLE-BOUNDARY-START(12886257431)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886257431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886257431)
            
            //--TRIMMABLE-BOUNDARY-START(17181224727)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Pay.Common.States.CommunityPayStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181224727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181224727)
            
            //--TRIMMABLE-BOUNDARY-START(8591290135)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Pay.Common.States.CommunityPayStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591290135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$lmlW.LCCPCS$2.CommunityPayStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$lmlW.LCCPCS$2.CommunityPayStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$lmlW.LCCPCS$2.CommunityPayStates)))
                {
                    /*var*/ let result = $.$lmlW.LCCPCS$2.CommunityPayStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$lmlW.LCCPCS$2.CommunityPayStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$lmlW.LCCPCS$2.CommunityPayStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$lmlW.LCCPCS$2.CommunityPayStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591290135)
            
            static $h = 1355543;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lmlW.LCCPCS$2.CommunityPayStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886257431),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1355543,
      "h": 12886257431,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886257431),
//--TRIMMABLE-BOUNDARY-START(17181224727),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1224471,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1355543,
      "h": 17181224727,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181224727),
//--TRIMMABLE-BOUNDARY-START(8591290135),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1224471,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1355543,
      "h": 8591290135,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591290135)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296322839),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1355543,
      "h": 4296322839,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296322839)
  ],
  "h": 1355543
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$lmlW.LCCPCS$2.CommunityPayStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.States.CommunityPayStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}States${separator}CommunityPayStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1355543)
        
        

        //--TRIMMABLE-BOUNDARY-START(503575)
        $asm.$cls(`$lmlW.LCCPCM.CommunityPayPostModel`, ($self) => class CommunityPayPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180372759)
            /*PostTypes */ get Type()
            {
                return 4608/*PostTypes.Pay*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180372759)
            
            //--TRIMMABLE-BOUNDARY-START(4295470871)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295470871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295470871)
            
            //--TRIMMABLE-BOUNDARY-START(4295470871)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295470871)
            
            static $h = 503575;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180372759),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885405463,
        "f": 50364417
      },
      "n": "Type",
      "d": 503575,
      "h": 17180372759,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180372759)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295470871),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 503575,
      "h": 4295470871,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295470871)
  ],
  "h": 503575
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Models${separator}CommunityPayPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(503575)
        
        

        //--TRIMMABLE-BOUNDARY-START(831255)
        $asm.$cls(`$lmlW.LCCPCS.IComunityPayRemoteService`, ($self) => class IComunityPayRemoteService
        {
            static $h = 831255;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 831255,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.IReadDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Services.IComunityPayRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Services${separator}IComunityPayRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(831255)
        
        

        //--TRIMMABLE-BOUNDARY-START(896791)
        $asm.$cls(`$lmlW.LCCPCS.IComunityPayRemoteService_Mocking`, ($self) => class IComunityPayRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295864087)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295864087);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295864087)
            
            //--TRIMMABLE-BOUNDARY-START(8590831383)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Pay$Common$Models$CommunityPayPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590831383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lmlW.LCCPCM.CommunityPayPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$lmlW.LCCPCM.CommunityPayPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590831383)
            
            //--TRIMMABLE-BOUNDARY-START(17180765975)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Pay$Common$Models$CommunityPayPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180765975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lmlW.LCCPCM.CommunityPayPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$lmlW.LCCPCM.CommunityPayPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180765975)
            
            //--TRIMMABLE-BOUNDARY-START(21475733271)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Pay$Common$Models$CommunityPayPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475733271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$lmlW.LCCPCM.CommunityPayPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$lmlW.LCCPCM.CommunityPayPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475733271)
            
            //--TRIMMABLE-BOUNDARY-START(25770700567)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Pay$Common$Models$CommunityPayPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770700567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$lmlW.LCCPCM.CommunityPayPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$lmlW.LCCPCM.CommunityPayPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770700567)
            
            //--TRIMMABLE-BOUNDARY-START(12885798679)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885798679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$lmlW.LCCPCM.CommunityPayPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885798679)
            
            static $h = 896791;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295864087),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 896791,
      "h": 4295864087,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295864087)
  ],
  "h": 896791
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$lmlW.LCCPCS.IComunityPayRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.IReadDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Services.IComunityPayRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Services${separator}IComunityPayRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(896791)
        
        

        //--TRIMMABLE-BOUNDARY-START(634647)
        $asm.$cls(`$lmlW.LCCPCM.CommunityPayPostModelTypeDescriptor`, ($self) => class CommunityPayPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lmlW.LCCPCM.CommunityPayPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295601943)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295601943);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$lmlW.LCCPCM.CommunityPayPostModelTypeDescriptor.GenerateProperties($.$lmlW.LCCPCM.CommunityPayPostModel, this, factory);
                    }, $xLjSTa ??= {"r":65537,"n":"","d":634647,"h":0,"f":17825794}), 0, "CommunityPayPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Pay.Common\\Models_CommunityPayPostModel_LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModelTypeDescriptorBuilder.g.cs", "CommunityPayPostModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295601943)
            
            //--TRIMMABLE-BOUNDARY-START(12885536535)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885536535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$lmlW.LCCPCM.CommunityPayPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$lmlW.LCCPCM.CommunityPayPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$lmlW.LCCPCM.CommunityPayPostModel)).Type);
                        }, $TESMck ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":634647,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885536535)
            
            //--TRIMMABLE-BOUNDARY-START(17180503831)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180503831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180503831)
            
            //--TRIMMABLE-BOUNDARY-START(8590569239)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590569239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$lmlW.LCCPCM.CommunityPayPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$lmlW.LCCPCM.CommunityPayPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$lmlW.LCCPCM.CommunityPayPostModel)))
                {
                    /*var*/ let result = $.$lmlW.LCCPCM.CommunityPayPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$lmlW.LCCPCM.CommunityPayPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$lmlW.LCCPCM.CommunityPayPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$lmlW.LCCPCM.CommunityPayPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590569239)
            
            static $h = 634647;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lmlW.LCCPCM.CommunityPayPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885536535),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 634647,
      "h": 12885536535,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885536535),
//--TRIMMABLE-BOUNDARY-START(17180503831),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 503575,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 634647,
      "h": 17180503831,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180503831),
//--TRIMMABLE-BOUNDARY-START(8590569239),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 503575,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 634647,
      "h": 8590569239,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590569239)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295601943),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 634647,
      "h": 4295601943,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295601943)
  ],
  "h": 634647
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$lmlW.LCCPCM.CommunityPayPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Models.CommunityPayPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Models${separator}CommunityPayPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(634647)
        
        

        //--TRIMMABLE-BOUNDARY-START(241431)
        $asm.$cls(`$lmlW.LCCPCM.CommunityPayModel`, ($self) => class CommunityPayModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$lmlW.LCCPCS$1.CommunityPaySettings, $.$lmlW.LCCPCS$2.CommunityPayStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295208727)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295208727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295208727)
            
            //--TRIMMABLE-BOUNDARY-START(4295208727)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295208727)
            
            static $h = 241431;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$lmlW.LCCPCS$1.CommunityPaySettings, $.$lmlW.LCCPCS$2.CommunityPayStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295208727),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 241431,
      "h": 4295208727,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295208727)
  ],
  "h": 241431
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Models.CommunityPayModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Models${separator}CommunityPayModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(241431)
        
        

        //--TRIMMABLE-BOUNDARY-START(372503)
        $asm.$cls(`$lmlW.LCCPCM.CommunityPayModelTypeDescriptor`, ($self) => class CommunityPayModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lmlW.LCCPCM.CommunityPayModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295339799)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295339799);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$lmlW.LCCPCM.CommunityPayModelTypeDescriptor.GenerateProperties($.$lmlW.LCCPCM.CommunityPayModel, this, factory);
                    }, $vFspUd ??= {"r":65537,"n":"","d":372503,"h":0,"f":17825794}), 0, "CommunityPayModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Pay.Common\\Models_CommunityPayModel_LivingThing.Core.Community.Pay.Common.Models.CommunityPayModelTypeDescriptorBuilder.g.cs", "CommunityPayModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295339799)
            
            //--TRIMMABLE-BOUNDARY-START(12885274391)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885274391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$lmlW.LCCPCS$1.CommunityPaySettings, $.$lmlW.LCCPCS$2.CommunityPayStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885274391)
            
            //--TRIMMABLE-BOUNDARY-START(17180241687)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Pay.Common.Models.CommunityPayModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180241687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Pay.Common.Settings.CommunityPaySettings, LivingThing.Core.Community.Pay.Common.States.CommunityPayStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$lmlW.LCCPCS$1.CommunityPaySettings, $.$lmlW.LCCPCS$2.CommunityPayStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$lmlW.LCCPCS$1.CommunityPaySettings, $.$lmlW.LCCPCS$2.CommunityPayStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180241687)
            
            //--TRIMMABLE-BOUNDARY-START(8590307095)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Pay.Common.Models.CommunityPayModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590307095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$lmlW.LCCPCM.CommunityPayModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$lmlW.LCCPCM.CommunityPayModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$lmlW.LCCPCM.CommunityPayModel)))
                {
                    /*var*/ let result = $.$lmlW.LCCPCM.CommunityPayModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$lmlW.LCCPCM.CommunityPayModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$lmlW.LCCPCM.CommunityPayModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$lmlW.LCCPCM.CommunityPayModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590307095)
            
            static $h = 372503;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$lmlW.LCCPCM.CommunityPayModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885274391),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 372503,
      "h": 12885274391,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885274391),
//--TRIMMABLE-BOUNDARY-START(17180241687),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 241431,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 372503,
      "h": 17180241687,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180241687),
//--TRIMMABLE-BOUNDARY-START(8590307095),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 241431,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 372503,
      "h": 8590307095,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590307095)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295339799),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 372503,
      "h": 4295339799,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295339799)
  ],
  "h": 372503
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$lmlW.LCCPCM.CommunityPayModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Pay.Common.Models.CommunityPayModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Pay${separator}Common${separator}Models${separator}CommunityPayModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(372503)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(44823)
