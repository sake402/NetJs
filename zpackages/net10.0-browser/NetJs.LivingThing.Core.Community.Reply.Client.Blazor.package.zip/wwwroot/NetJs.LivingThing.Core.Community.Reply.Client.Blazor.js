
//--TRIMMABLE-BOUNDARY-START(59967)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $FuXl) {
    "use strict";
    let _;
    let $ysqbae;
    let $lGEAjc;
    let $RMDmck;
    let $OSWmGe;
    let $PDErNf;
    let $KBsZZa;
    let $qVqywd;
    let $ajPijh;
    let $gBLoyk;
    let $HSSzSe;
    let $GzYAqc;
    let $jGaLfh;
    let $raNpbf;
    let $iXOFSd;
    let $NuNAbf;
    let $UIULbl;
    let $mIyIbk;
    let $mwBeFh;
    let $qWSlpj;
    let $kXIinf;
    let $kBLccb;
    let $EWKiod;
    let $hzrYwi;
    let $ljjzTc;
    let $HdHOxk;
    let $EkQedc;
    let $kYSWdj;
    let $lcDYbh;
    let $wPhVPc;
    let $PUpCcb;
    let $mpEmli;
    let $XUJIyf;
    let $kOFLWc;
    let $mfPKld;
    let $QxvUGb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Reply.Client.Blazor", 
    {
  "h": 59967,
  "f": "LivingThing.Core.Community.Reply.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Reply.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Reply.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(453183)
        $asm.$cls(`$aAgx.LCCRC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590387775)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590387775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$aAgx.LCCRCP.Home, "LivingThing.Core.Community.Reply.Client", "Pages\\Home", "Home", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Reply", "/Replys" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("Zoey", 1, "ReplyHome", "Replys", "mdi mdi-home"/*MaterialDesignIconNames.Home*/, 8659143824n | 524288n | 32768n | 65536n, null, null, null, null, null, null, null, null, null, null, null, null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590387775)
            
            //--TRIMMABLE-BOUNDARY-START(4295420479)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295420479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295420479)
            
            //--TRIMMABLE-BOUNDARY-START(4295420479)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295420479)
            
            static $h = 453183;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590387775),
    {
      "r": 65537,
      "n": "Build",
      "d": 453183,
      "h": 8590387775,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590387775)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295420479),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 453183,
      "h": 4295420479,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295420479)
  ],
  "h": 453183
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(453183)
        
        

        //--TRIMMABLE-BOUNDARY-START(322111)
        $asm.$cls(`$aAgx.LCCRC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295289407)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295289407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$aAgx.LCCRC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295289407)
            
            static $h = 322111;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295289407),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 322111,
      "h": 4295289407,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295289407)
  ],
  "h": 322111
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(322111)
        
        

        //--TRIMMABLE-BOUNDARY-START(125503)
        $asm.$cls(`$aAgx._LCCRCPH.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295092799)
            static /*void */ CreateCommunityAddOn_0(TAddOn, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TAddOn*/ __arg0)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295092799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCSA$2.CommunityAddOn$$(TAddOn), seq);
                __builder.AddComponentParameter(__seq0, "ViewModel", $.$box(__arg0, TAddOn));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295092799)
            
            static $h = 125503;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295092799),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TAddOn) => TAddOn.$h
        }
      ],
      "g": [
        "TAddOn"
      ],
      "n": "CreateCommunityAddOn_0",
      "d": 125503,
      "h": 4295092799,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295092799)
  ],
  "h": 125503
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Reply.Client.Pages.Home.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Pages${separator}Home${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(125503)
        
        

        //--TRIMMABLE-BOUNDARY-START(191039)
        $asm.$cls(`$aAgx._LCCRCSA.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295158335)
            static /*void */ CreateCommunityAddOn_0(TAddOn, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TAddOn*/ __arg0)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295158335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCSA$2.CommunityAddOn$$(TAddOn), seq);
                __builder.AddComponentParameter(__seq0, "ViewModel", $.$box(__arg0, TAddOn));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295158335)
            
            static $h = 191039;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295158335),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TAddOn) => TAddOn.$h
        }
      ],
      "g": [
        "TAddOn"
      ],
      "n": "CreateCommunityAddOn_0",
      "d": 191039,
      "h": 4295158335,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295158335)
  ],
  "h": 191039
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Reply.Client.Shared.AccountReplies.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Shared${separator}AccountReplies${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(191039)
        
        

        //--TRIMMABLE-BOUNDARY-START(387647)
        $asm.$cls(`$aAgx.LCCRC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180256831)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$aAgx.LCCRCP.Home.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$aAgx.LCCRCP.Home().$ctor$4();
                    }, $ysqbae ??= {"r":2752627,"n":"","d":387647,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$aAgx.LCCRCS$1.AccountReplies.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$aAgx.LCCRCS$1.AccountReplies().$ctor$5();
                    }, $lGEAjc ??= {"r":2752627,"n":"","d":387647,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180256831)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295354943)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295354943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295354943)
            
            //--TRIMMABLE-BOUNDARY-START(4295354943)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295354943)
            
            static $h = 387647;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180256831),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885289535,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 387647,
      "h": 17180256831,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180256831)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295354943),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 387647,
      "h": 4295354943,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295354943)
  ],
  "h": 387647
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(387647)
        
        

        //--TRIMMABLE-BOUNDARY-START(649791)
        $asm.$cls(`$aAgx.LCCRC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590584383)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590584383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$aAgx.LCCRC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$aAgx.LCCRCS.CommunityReplyService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$hDPm.LCFCI.ICommentProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityPostAddOnProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityReplyProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$aAgx.LCCRCS.CommunityReplyProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityReplyProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyProvider, x);
                }, $GzYAqc ??= {"r":18453952,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityPostAddOnProvider))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyProvider, x);
                }, $jGaLfh ??= {"r":18126272,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCI.ICommentProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyProvider, x);
                }, $raNpbf ??= {"r":63723178,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$FuXl.LCCRCM.CommunityReplyPostModel, services, null);
                $.$aAgx.LCCRC._Startup.AddGeneratedComponentOptimizers(services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityUserDashboardApplicationPage, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$aAgx.LCCRCS.CommunityReplyApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityUserDashboardApplicationPage))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyApplication, x);
                }, $iXOFSd ??= {"r":19371456,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyApplication, x);
                }, $NuNAbf ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyApplication, x);
                }, $UIULbl ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyApplication, x);
                }, $mIyIbk ??= {"r":$.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference).$h,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$LCOv.LCFCPS.IAccountTask, $.$aAgx.LCCRCT.Reply2Task, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$LCOv.LCFCPS.IAccountTask, $.$aAgx.LCCRCT.Reply10Task, services);
                $.$aAgx.LCCRC.NavigationMenuBuilder.Build();
            }
            //--TRIMMABLE-BOUNDARY-END(8590584383)
            
            //--TRIMMABLE-BOUNDARY-START(12885551679)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885551679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_CommunityReplyProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$aAgx.LCCRCS.CommunityReplyProvider().$ctor$1();
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$aAgx.LCCRCS.CommunityReplyProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$aAgx.LCCRC.ServiceRegistrar, Get_CommunityReplyProvider, $mwBeFh ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_CommunityReplyProvider","d":649791,"h":0,"f":16777250})));
                /*static object*/  function Get_ICommunityReplyProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyProvider, x);
                    }), $qWSlpj ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCS.ICommunityReplyProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$aAgx.LCCRC.ServiceRegistrar, Get_ICommunityReplyProvider, $kXIinf ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ICommunityReplyProvider","d":649791,"h":0,"f":16777250})));
                /*static object*/  function Get_ICommunityPostAddOnProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyProvider, x);
                    }), $kBLccb ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCS.ICommunityPostAddOnProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$aAgx.LCCRC.ServiceRegistrar, Get_ICommunityPostAddOnProvider, $EWKiod ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ICommunityPostAddOnProvider","d":649791,"h":0,"f":16777250})));
                /*static object*/  function Get_ICommentProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyProvider, x);
                    }), $hzrYwi ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$hDPm.LCFCI.ICommentProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$aAgx.LCCRC.ServiceRegistrar, Get_ICommentProvider, $ljjzTc ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ICommentProvider","d":649791,"h":0,"f":16777250})));
                /*static object*/  function Get_CommunityReplyApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$aAgx.LCCRCS.CommunityReplyApplication().$ctor$3(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$aAgx.LCCRCS.CommunityReplyService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyService, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$aAgx.LCCRCS.CommunityReplyApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$aAgx.LCCRC.ServiceRegistrar, Get_CommunityReplyApplication, $HdHOxk ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_CommunityReplyApplication","d":649791,"h":0,"f":16777250})));
                /*static object*/  function Get_ICommunityUserDashboardApplicationPage(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyApplication, x);
                    }), $EkQedc ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCS.ICommunityUserDashboardApplicationPage.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$aAgx.LCCRC.ServiceRegistrar, Get_ICommunityUserDashboardApplicationPage, $kYSWdj ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ICommunityUserDashboardApplicationPage","d":649791,"h":0,"f":16777250})));
                /*static object*/  function Get_IClientApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyApplication, x);
                    }), $lcDYbh ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$sZVd.LCFCA.IClientApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$aAgx.LCCRC.ServiceRegistrar, Get_IClientApplication, $wPhVPc ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IClientApplication","d":649791,"h":0,"f":16777250})));
                /*static object*/  function Get_ICommunityClientApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyApplication, x);
                    }), $PUpCcb ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCS.ICommunityClientApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$aAgx.LCCRC.ServiceRegistrar, Get_ICommunityClientApplication, $mpEmli ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ICommunityClientApplication","d":649791,"h":0,"f":16777250})));
                /*static object*/  function Get_ICommunityClientApplication_NoCategoryPostModel_CommunityReplyPostModel_CommunityReplyPostModel_ApplicationBaseUserPreference_(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aAgx.LCCRCS.CommunityReplyApplication, x);
                    }), $XUJIyf ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":649791,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference).$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$aAgx.LCCRC.ServiceRegistrar, Get_ICommunityClientApplication_NoCategoryPostModel_CommunityReplyPostModel_CommunityReplyPostModel_ApplicationBaseUserPreference_, $kOFLWc ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ICommunityClientApplication_NoCategoryPostModel_CommunityReplyPostModel_CommunityReplyPostModel_ApplicationBaseUserPreference_","d":649791,"h":0,"f":16777250})));
                /*static object*/  function Get_Reply2Task(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$aAgx.LCCRCT.Reply2Task().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$ahDc.LCCCS.CommunityRootService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.CommunityRootService, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$mac.MAC.NavigationManager, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$LCOv.LCFCPS.IAccountTask.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$aAgx.LCCRC.ServiceRegistrar, Get_Reply2Task, $mfPKld ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_Reply2Task","d":649791,"h":0,"f":16777250})));
                /*static object*/  function Get_Reply10Task(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$aAgx.LCCRCT.Reply10Task().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$ahDc.LCCCS.CommunityRootService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.CommunityRootService, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$mac.MAC.NavigationManager, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$LCOv.LCFCPS.IAccountTask.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$aAgx.LCCRC.ServiceRegistrar, Get_Reply10Task, $QxvUGb ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_Reply10Task","d":649791,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12885551679)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$aAgx.LCCRC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295617087)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295617087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295617087)
            
            //--TRIMMABLE-BOUNDARY-START(4295617087)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295617087)
            
            static $h = 649791;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590584383),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 649791,
      "h": 8590584383,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590584383),
//--TRIMMABLE-BOUNDARY-START(12885551679),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 649791,
      "h": 12885551679,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885551679)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295617087),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 649791,
      "h": 4295617087,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295617087)
  ],
  "h": 649791
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(649791)
        
        

        //--TRIMMABLE-BOUNDARY-START(1501759)
        $asm.$cls(`$aAgx.LCCRCT.Reply10Task`, ($self) => class Reply10Task extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296469055)
            /*NavigationManager*/ _navigationManager = null;
            //--TRIMMABLE-BOUNDARY-END(4296469055)
            
            //--TRIMMABLE-BOUNDARY-START(8591436351)
            /*CommunityRootService*/ _service = null;
            //--TRIMMABLE-BOUNDARY-END(8591436351)
            
            //--TRIMMABLE-BOUNDARY-START(12886403647)
            $ctor$1(/*CommunityRootService*/ service, /*NavigationManager*/ navigationManager)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886403647);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._service = service;
                    this._navigationManager = navigationManager;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886403647)
            
            //--TRIMMABLE-BOUNDARY-START(17181370943)
            /*string? */ get CompositeGroupName()
            {
                return "Daily Content Creation Plus";
            }
            //--TRIMMABLE-BOUNDARY-END(17181370943)
            
            //--TRIMMABLE-BOUNDARY-START(85900847679)
            /*int */ get Order()
            {
                return 2;
            }
            //--TRIMMABLE-BOUNDARY-END(85900847679)
            
            //--TRIMMABLE-BOUNDARY-START(98785749567)
            /*string? */ get Title()
            {
                return "Daily engage";
            }
            //--TRIMMABLE-BOUNDARY-END(98785749567)
            
            //--TRIMMABLE-BOUNDARY-START(81605880383)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-comment"/*MaterialDesignIconNames.Comment*/);
            }
            //--TRIMMABLE-BOUNDARY-END(81605880383)
            
            //--TRIMMABLE-BOUNDARY-START(21476338239)
            /*string? */ get Description()
            {
                return "Engage 10 posts by replying to them";
            }
            //--TRIMMABLE-BOUNDARY-END(21476338239)
            
            //--TRIMMABLE-BOUNDARY-START(90195814975)
            /*Money */ get Reward()
            {
                return new $.$fPer.LCFCDM.Money().$ctor$3(20 / 2, 1/*MoneyUnitTypes.Naira*/);
            }
            //--TRIMMABLE-BOUNDARY-END(90195814975)
            
            //--TRIMMABLE-BOUNDARY-START(94490782271)
            /*Task */ StartAsync(/*object*/ caller)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490782271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._service.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Toast("Engage with the community by replying to posts in the feed!", null);
                this._navigationManager.NavigateTo$1("", false, false);
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(94490782271)
            
            //--TRIMMABLE-BOUNDARY-START(77310913087)
            /*ValueTask<int> *//*async*/  GetCompletion(/*AccountBaseModel*/ account)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Int32), $.$$.S.Int32, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310913087);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this._service.Account.Identifier.HasValue)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, 0);
                    }
                    /*var*/ let today = $.$fPer.LCFCDC.DateTimeExtension.GetDate(2/*DateRange.Today*/, true, null);
                    /*var*/ let filter = new $.$fPer.LCFCD.DataFilter().$ctor$22(null, null, new $.$fPer.LCFCD.CompositeDataId().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this._service.Account.Identifier ], null, null)), null, 1, 0, today.Start, today.End, new $.$fPer.LCFCD.Sorting(), null).WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741826/*PostFilterTypes.Account*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostRequestProperties, 1196268653051967n | 4503599627370496n, 0);
                    /*var*/ let result = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$FuXl.LCCRCM.CommunityReplyPostModel, this._service.UnitOfWork.LCFCI$IClientUnitOfWork$Server, filter, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, ((result.TotalCount * 10) | 0));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77310913087)
            
            //--TRIMMABLE-BOUNDARY-START(25795422644)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Services.IAccountTask.CompositeGroupName.get
            get LCFCPS$IAccountTask$CompositeGroupName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8615553460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CompositeGroupName;
            }
            //--TRIMMABLE-BOUNDARY-END(25795422644)
            
            //--TRIMMABLE-BOUNDARY-START(42975291828)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Services.IAccountTask.Order.get
            get LCFCPS$IAccountTask$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64450128308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(42975291828)
            
            //--TRIMMABLE-BOUNDARY-START(51565226420)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Services.IAccountTask.Reward.get
            get LCFCPS$IAccountTask$Reward()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68745095604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reward;
            }
            //--TRIMMABLE-BOUNDARY-END(51565226420)
            
            //--TRIMMABLE-BOUNDARY-START(73040062900)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Services.IAccountTask.StartAsync(object)
            LCFCPS$IAccountTask$StartAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73040062900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(73040062900)
            
            //--TRIMMABLE-BOUNDARY-START(55860193716)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Services.IAccountTask.GetCompletion(LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel)
            LCFCPS$IAccountTask$GetCompletion()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55860193716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCompletion(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(55860193716)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 1501759;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181370943),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066272831,
        "f": 50331649
      },
      "n": "CompositeGroupName",
      "d": 1501759,
      "h": 17181370943,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181370943),
//--TRIMMABLE-BOUNDARY-START(85900847679),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836076607,
        "f": 50331649
      },
      "n": "Order",
      "d": 1501759,
      "h": 85900847679,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900847679),
//--TRIMMABLE-BOUNDARY-START(98785749567),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015945791,
        "f": 50331649
      },
      "n": "Title",
      "d": 1501759,
      "h": 98785749567,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785749567),
//--TRIMMABLE-BOUNDARY-START(81605880383),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246142015,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1501759,
      "h": 81605880383,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605880383),
//--TRIMMABLE-BOUNDARY-START(21476338239),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656207423,
        "f": 50331649
      },
      "n": "Description",
      "d": 1501759,
      "h": 21476338239,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476338239),
//--TRIMMABLE-BOUNDARY-START(90195814975),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426011199,
        "f": 50331649
      },
      "n": "Reward",
      "d": 1501759,
      "h": 90195814975,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195814975)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94490782271),
    {
      "r": 178454529,
      "p": [
        {
          "n": "caller",
          "p": 131073
        }
      ],
      "n": "StartAsync",
      "d": 1501759,
      "h": 94490782271,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490782271),
//--TRIMMABLE-BOUNDARY-START(77310913087),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "account",
          "p": 6220212
        }
      ],
      "n": "GetCompletion",
      "d": 1501759,
      "h": 77310913087,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(77310913087)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296469055),
    {
      "t": 4980851,
      "n": "_navigationManager",
      "d": 1501759,
      "h": 4296469055,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296469055),
//--TRIMMABLE-BOUNDARY-START(8591436351),
    {
      "t": 16487872,
      "n": "_service",
      "d": 1501759,
      "h": 8591436351,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591436351)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886403647),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        },
        {
          "n": "navigationManager",
          "p": 4980851
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1501759,
      "h": 12886403647,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886403647)
  ],
  "h": 1501759
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IAccountTask, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Tasks.Reply10Task`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Tasks${separator}Reply10Task`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1501759)
        
        

        //--TRIMMABLE-BOUNDARY-START(1567295)
        $asm.$cls(`$aAgx.LCCRCT.Reply2Task`, ($self) => class Reply2Task extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296534591)
            /*NavigationManager*/ _navigationManager = null;
            //--TRIMMABLE-BOUNDARY-END(4296534591)
            
            //--TRIMMABLE-BOUNDARY-START(8591501887)
            /*CommunityRootService*/ _service = null;
            //--TRIMMABLE-BOUNDARY-END(8591501887)
            
            //--TRIMMABLE-BOUNDARY-START(12886469183)
            $ctor$1(/*CommunityRootService*/ service, /*NavigationManager*/ navigationManager)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886469183);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._service = service;
                    this._navigationManager = navigationManager;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886469183)
            
            //--TRIMMABLE-BOUNDARY-START(17181436479)
            /*string? */ get CompositeGroupName()
            {
                return "Daily Content Creation";
            }
            //--TRIMMABLE-BOUNDARY-END(17181436479)
            
            //--TRIMMABLE-BOUNDARY-START(85900913215)
            /*int */ get Order()
            {
                return 3;
            }
            //--TRIMMABLE-BOUNDARY-END(85900913215)
            
            //--TRIMMABLE-BOUNDARY-START(98785815103)
            /*string? */ get Title()
            {
                return "Daily engage";
            }
            //--TRIMMABLE-BOUNDARY-END(98785815103)
            
            //--TRIMMABLE-BOUNDARY-START(81605945919)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-comment"/*MaterialDesignIconNames.Comment*/);
            }
            //--TRIMMABLE-BOUNDARY-END(81605945919)
            
            //--TRIMMABLE-BOUNDARY-START(21476403775)
            /*string? */ get Description()
            {
                return "Engage 2 posts by replying to them";
            }
            //--TRIMMABLE-BOUNDARY-END(21476403775)
            
            //--TRIMMABLE-BOUNDARY-START(90195880511)
            /*Money */ get Reward()
            {
                return new $.$fPer.LCFCDM.Money().$ctor$3(10 / 3, 1/*MoneyUnitTypes.Naira*/);
            }
            //--TRIMMABLE-BOUNDARY-END(90195880511)
            
            //--TRIMMABLE-BOUNDARY-START(94490847807)
            /*Task */ StartAsync(/*object*/ caller)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490847807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._service.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Toast("Engage with the community by replying to posts in the feed!", null);
                this._navigationManager.NavigateTo$1("", false, false);
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(94490847807)
            
            //--TRIMMABLE-BOUNDARY-START(77310978623)
            /*ValueTask<int> *//*async*/  GetCompletion(/*AccountBaseModel*/ account)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Int32), $.$$.S.Int32, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310978623);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this._service.Account.Identifier.HasValue)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, 0);
                    }
                    /*var*/ let today = $.$fPer.LCFCDC.DateTimeExtension.GetDate(2/*DateRange.Today*/, true, null);
                    /*var*/ let filter = new $.$fPer.LCFCD.DataFilter().$ctor$22(null, null, new $.$fPer.LCFCD.CompositeDataId().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this._service.Account.Identifier ], null, null)), null, 1, 0, today.Start, today.End, new $.$fPer.LCFCD.Sorting(), null).WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741826/*PostFilterTypes.Account*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostRequestProperties, 1196268653051967n | 4503599627370496n, 0);
                    /*var*/ let result = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$FuXl.LCCRCM.CommunityReplyPostModel, this._service.UnitOfWork.LCFCI$IClientUnitOfWork$Server, filter, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, ((result.TotalCount * 50) | 0));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77310978623)
            
            //--TRIMMABLE-BOUNDARY-START(25795422644)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Services.IAccountTask.CompositeGroupName.get
            get LCFCPS$IAccountTask$CompositeGroupName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8615553460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CompositeGroupName;
            }
            //--TRIMMABLE-BOUNDARY-END(25795422644)
            
            //--TRIMMABLE-BOUNDARY-START(42975291828)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Services.IAccountTask.Order.get
            get LCFCPS$IAccountTask$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64450128308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(42975291828)
            
            //--TRIMMABLE-BOUNDARY-START(51565226420)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Services.IAccountTask.Reward.get
            get LCFCPS$IAccountTask$Reward()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68745095604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reward;
            }
            //--TRIMMABLE-BOUNDARY-END(51565226420)
            
            //--TRIMMABLE-BOUNDARY-START(73040062900)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Services.IAccountTask.StartAsync(object)
            LCFCPS$IAccountTask$StartAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73040062900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(73040062900)
            
            //--TRIMMABLE-BOUNDARY-START(55860193716)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Services.IAccountTask.GetCompletion(LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel)
            LCFCPS$IAccountTask$GetCompletion()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55860193716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCompletion(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(55860193716)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 1567295;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181436479),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066338367,
        "f": 50331649
      },
      "n": "CompositeGroupName",
      "d": 1567295,
      "h": 17181436479,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181436479),
//--TRIMMABLE-BOUNDARY-START(85900913215),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836142143,
        "f": 50331649
      },
      "n": "Order",
      "d": 1567295,
      "h": 85900913215,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900913215),
//--TRIMMABLE-BOUNDARY-START(98785815103),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016011327,
        "f": 50331649
      },
      "n": "Title",
      "d": 1567295,
      "h": 98785815103,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785815103),
//--TRIMMABLE-BOUNDARY-START(81605945919),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246207551,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1567295,
      "h": 81605945919,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605945919),
//--TRIMMABLE-BOUNDARY-START(21476403775),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656272959,
        "f": 50331649
      },
      "n": "Description",
      "d": 1567295,
      "h": 21476403775,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476403775),
//--TRIMMABLE-BOUNDARY-START(90195880511),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426076735,
        "f": 50331649
      },
      "n": "Reward",
      "d": 1567295,
      "h": 90195880511,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195880511)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94490847807),
    {
      "r": 178454529,
      "p": [
        {
          "n": "caller",
          "p": 131073
        }
      ],
      "n": "StartAsync",
      "d": 1567295,
      "h": 94490847807,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490847807),
//--TRIMMABLE-BOUNDARY-START(77310978623),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "account",
          "p": 6220212
        }
      ],
      "n": "GetCompletion",
      "d": 1567295,
      "h": 77310978623,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(77310978623)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296534591),
    {
      "t": 4980851,
      "n": "_navigationManager",
      "d": 1567295,
      "h": 4296534591,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296534591),
//--TRIMMABLE-BOUNDARY-START(8591501887),
    {
      "t": 16487872,
      "n": "_service",
      "d": 1567295,
      "h": 8591501887,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591501887)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886469183),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        },
        {
          "n": "navigationManager",
          "p": 4980851
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1567295,
      "h": 12886469183,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886469183)
  ],
  "h": 1567295
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IAccountTask, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Tasks.Reply2Task`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Tasks${separator}Reply2Task`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1567295)
        
        

        //--TRIMMABLE-BOUNDARY-START(846399)
        $asm.$cls(`$aAgx.LCCRCS.CommunityReplyProvider`, ($self) => class CommunityReplyProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(73015290431)
            /*string */ get Name()
            {
                return "Reply";
            }
            //--TRIMMABLE-BOUNDARY-END(73015290431)
            
            //--TRIMMABLE-BOUNDARY-START(77310257727)
            /*string */ get Title()
            {
                return "Reply";
            }
            //--TRIMMABLE-BOUNDARY-END(77310257727)
            
            //--TRIMMABLE-BOUNDARY-START(17180715583)
            /*string */ get Description()
            {
                return "Make your opinion about this post";
            }
            //--TRIMMABLE-BOUNDARY-END(17180715583)
            
            //--TRIMMABLE-BOUNDARY-START(68720323135)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-comment-outline"/*MaterialDesignIconNames.CommentOutline*/);
            }
            //--TRIMMABLE-BOUNDARY-END(68720323135)
            
            //--TRIMMABLE-BOUNDARY-START(8590780991)
            /*bool */ CanAddOn(/*IPost*/ parent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590780991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$is(parent, $.$LCOv.LCFCP.IPostReplyable);
            }
            //--TRIMMABLE-BOUNDARY-END(8590780991)
            
            //--TRIMMABLE-BOUNDARY-START(12885748287)
            /*ValueTask */ Clicked(/*IPost*/ post)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885748287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12885748287)
            
            //--TRIMMABLE-BOUNDARY-START(55835421247)
            /*string? */ GetAddOnMetrics(/*IPost*/ post)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835421247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let comments = ($.$cast(post, $.$LCOv.LCFCPM$1.PostBaseModel)).CommentsCount;
                if ($.$$.S.Int32.op_GreaterThan(comments, 0))
                {
                    /*int?*/ let __ca1__;
                    return _ = ((__ca1__ = comments) !== null ? $.$fPer.LCFCS$6.NumberExtension.FormatScientific$1($.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(__ca1__), "0", false) : null);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(55835421247)
            
            //--TRIMMABLE-BOUNDARY-START(60130388543)
            /*RenderFragment? */ GetAddOnView(/*IPost*/ parent, /*RenderFragment?*/ bodyPreview, /*CommunityAddOnsFeatures*/ addOnFeatures)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130388543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let dm;
                if ($.$is(parent, $.$Iaui.LCFCM.DataModel, { set $v($v){ dm = $v; } }))
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                    {
                        builder.OpenComponent$1($.$ahDc.LCCCSA$2.CommunityAddOns$$($.$FuXl.LCCRCM.CommunityReplyPostModel), 1);
                        builder.AddAttribute$4(4, "Parent", dm);
                        builder.AddAttribute$4(7, "Features", $.$box(addOnFeatures, $.$ahDc.LCCCSA$2.CommunityAddOnsFeatures));
                        builder.AddAttribute$4(8, "AddOnProvider", this);
                        builder.AddAttribute$3(8, "InitialParentPreview", bodyPreview);
                        builder.CloseComponent();
                    }, $gBLoyk ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":846399,"h":0,"f":17825794});
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(60130388543)
            
            //--TRIMMABLE-BOUNDARY-START(64425355839)
            /*RenderFragment? */ GetComments(/*CommentConfiguration?*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425355839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((configuration?.Anonymous ?? null) === true)
                {
                    return null;
                }
                else 
                {
                    if ((configuration?.Target ?? null) !== null)
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                        {
                            builder.OpenComponent$1($.$ahDc.LCCCSA$2.CommunityAddOns$$($.$FuXl.LCCRCM.CommunityReplyPostModel), 1);
                            builder.AddAttribute$4(4, "Parent", configuration.Target);
                            builder.AddAttribute$4(7, "Features", $.$box(0/*CommunityAddOnsFeatures.Default*/ | (((configuration?.StickyEditor ?? null) ?? false) ? 4/*CommunityAddOnsFeatures.EditorSnapOverlayBottom*/ : 2/*CommunityAddOnsFeatures.EditorSnapLayoutBottom*/), $.$ahDc.LCCCSA$2.CommunityAddOnsFeatures));
                            builder.AddAttribute$4(8, "AddOnProvider", this);
                            builder.CloseComponent();
                        }, $HSSzSe ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":846399,"h":0,"f":17825794});
                    }
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425355839)
            
            //--TRIMMABLE-BOUNDARY-START(4313093568)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityPostAddOnProvider.CanAddOn(LivingThing.Core.Frameworks.Common.Posts.IPost)
            LCCCS$ICommunityPostAddOnProvider$CanAddOn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313093568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanAddOn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313093568)
            
            //--TRIMMABLE-BOUNDARY-START(8608060864)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityPostAddOnProvider.Clicked(LivingThing.Core.Frameworks.Common.Posts.IPost)
            LCCCS$ICommunityPostAddOnProvider$Clicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8608060864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clicked(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8608060864)
            
            //--TRIMMABLE-BOUNDARY-START(17197995456)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityPostAddOnProvider.GetAddOnView(LivingThing.Core.Frameworks.Common.Posts.IPost, Microsoft.AspNetCore.Components.RenderFragment?, LivingThing.Core.Community.Client.Shared.AddOns.CommunityAddOnsFeatures)
            LCCCS$ICommunityPostAddOnProvider$GetAddOnView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17197995456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAddOnView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17197995456)
            
            //--TRIMMABLE-BOUNDARY-START(12903028160)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityPostAddOnProvider.GetAddOnMetrics(LivingThing.Core.Frameworks.Common.Posts.IPost)
            LCCCS$ICommunityPostAddOnProvider$GetAddOnMetrics()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12903028160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAddOnMetrics(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12903028160)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(4358690474)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.ICommentProvider.GetComments(LivingThing.Core.Frameworks.Client.Interface.CommentConfiguration?)
            LCFCI$ICommentProvider$GetComments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358690474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetComments(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358690474)
            
            //--TRIMMABLE-BOUNDARY-START(4295813695)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295813695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295813695)
            
            //--TRIMMABLE-BOUNDARY-START(4295813695)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295813695)
            
            static $h = 846399;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015290431),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950519359,
        "f": 50331649
      },
      "n": "Name",
      "d": 846399,
      "h": 73015290431,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015290431),
//--TRIMMABLE-BOUNDARY-START(77310257727),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540453951,
        "f": 50331649
      },
      "n": "Title",
      "d": 846399,
      "h": 77310257727,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310257727),
//--TRIMMABLE-BOUNDARY-START(17180715583),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770650175,
        "f": 50331649
      },
      "n": "Description",
      "d": 846399,
      "h": 17180715583,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180715583),
//--TRIMMABLE-BOUNDARY-START(68720323135),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360584767,
        "f": 50331649
      },
      "n": "Icon",
      "d": 846399,
      "h": 68720323135,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720323135)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590780991),
    {
      "r": 262145,
      "p": [
        {
          "n": "parent",
          "p": 1173940
        }
      ],
      "n": "CanAddOn",
      "d": 846399,
      "h": 8590780991,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590780991),
//--TRIMMABLE-BOUNDARY-START(12885748287),
    {
      "r": 181338113,
      "p": [
        {
          "n": "post",
          "p": 1173940
        }
      ],
      "n": "Clicked",
      "d": 846399,
      "h": 12885748287,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885748287),
//--TRIMMABLE-BOUNDARY-START(55835421247),
    {
      "r": 1310721,
      "p": [
        {
          "n": "post",
          "p": 1173940
        }
      ],
      "n": "GetAddOnMetrics",
      "d": 846399,
      "h": 55835421247,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835421247),
//--TRIMMABLE-BOUNDARY-START(60130388543),
    {
      "r": 6881395,
      "p": [
        {
          "n": "parent",
          "p": 1173940
        },
        {
          "n": "bodyPreview",
          "p": 6881395
        },
        {
          "n": "addOnFeatures",
          "p": 22844864
        }
      ],
      "n": "GetAddOnView",
      "d": 846399,
      "h": 60130388543,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130388543),
//--TRIMMABLE-BOUNDARY-START(64425355839),
    {
      "r": 6881395,
      "p": [
        {
          "n": "configuration",
          "p": 62674602,
          "f": 65
        }
      ],
      "n": "GetComments",
      "d": 846399,
      "h": 64425355839,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425355839)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295813695),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 846399,
      "h": 4295813695,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295813695)
  ],
  "h": 846399
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityReplyProvider, $.$ahDc.LCCCS.ICommunityPostAddOnProvider, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$hDPm.LCFCI.ICommentProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Services.CommunityReplyProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Services${separator}CommunityReplyProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(846399)
        
        

        //--TRIMMABLE-BOUNDARY-START(1632831)
        $asm.$cls(`$aAgx.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296600127)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296600127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296600127)
            
            //--TRIMMABLE-BOUNDARY-START(4296600127)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296600127)
            
            static $h = 1632831;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296600127),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1632831,
      "h": 4296600127,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296600127)
  ],
  "h": 1632831
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1632831)
        
        

        //--TRIMMABLE-BOUNDARY-START(1698367)
        $asm.$cls(`$aAgx.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296665663)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296665663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296665663)
            
            //--TRIMMABLE-BOUNDARY-START(4296665663)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296665663)
            
            static $h = 1698367;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296665663),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1698367,
      "h": 4296665663,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296665663)
  ],
  "h": 1698367,
  "a": [
    {
      "t": 1632831,
      "c": 4296600127
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1698367)
        
        

        //--TRIMMABLE-BOUNDARY-START(518719)
        $asm.$cls(`$aAgx.LCCRCP.CommunityCommentApp`, ($self) => class CommunityCommentApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590453311)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590453311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590453311)
            
            //--TRIMMABLE-BOUNDARY-START(4295486015)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295486015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295486015)
            
            //--TRIMMABLE-BOUNDARY-START(4295486015)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295486015)
            
            static $h = 518719;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590453311),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 518719,
      "h": 8590453311,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590453311)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295486015),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 518719,
      "h": 4295486015,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295486015)
  ],
  "h": 518719
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Pages.CommunityCommentApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Pages${separator}CommunityCommentApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(518719)
        
        

        //--TRIMMABLE-BOUNDARY-START(1043007)
        $asm.$cls(`$aAgx.LCCRCS$1.AnonymousComment`, ($self) => class AnonymousComment extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590977599)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590977599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590977599)
            
            //--TRIMMABLE-BOUNDARY-START(4296010303)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296010303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296010303)
            
            //--TRIMMABLE-BOUNDARY-START(4296010303)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296010303)
            
            static $h = 1043007;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590977599),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1043007,
      "h": 8590977599,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590977599)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296010303),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1043007,
      "h": 4296010303,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296010303)
  ],
  "h": 1043007
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Shared.AnonymousComment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Shared${separator}AnonymousComment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1043007)
        
        

        //--TRIMMABLE-BOUNDARY-START(1174079)
        $asm.$cls(`$aAgx.LCCRCS$1.AnonymousCommentListing`, ($self) => class AnonymousCommentListing extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8591108671)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591108671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8591108671)
            
            //--TRIMMABLE-BOUNDARY-START(4296141375)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296141375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296141375)
            
            //--TRIMMABLE-BOUNDARY-START(4296141375)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296141375)
            
            static $h = 1174079;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591108671),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1174079,
      "h": 8591108671,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591108671)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296141375),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1174079,
      "h": 4296141375,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296141375)
  ],
  "h": 1174079
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Shared.AnonymousCommentListing`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Shared${separator}AnonymousCommentListing`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1174079)
        
        

        //--TRIMMABLE-BOUNDARY-START(1436223)
        $asm.$cls(`$aAgx.LCCRCS$1.CommunityComments`, ($self) => class CommunityComments extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8591370815)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591370815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8591370815)
            
            //--TRIMMABLE-BOUNDARY-START(4296403519)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296403519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296403519)
            
            //--TRIMMABLE-BOUNDARY-START(4296403519)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296403519)
            
            static $h = 1436223;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591370815),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1436223,
      "h": 8591370815,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591370815)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296403519),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1436223,
      "h": 4296403519,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296403519)
  ],
  "h": 1436223
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Shared.CommunityComments`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Shared${separator}CommunityComments`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1436223)
        
        

        //--TRIMMABLE-BOUNDARY-START(1239615)
        $asm.$cls(`$aAgx.LCCRCS$1.AnonymousCommentRoot`, ($self) => class AnonymousCommentRoot extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8591174207)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591174207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8591174207)
            
            //--TRIMMABLE-BOUNDARY-START(4296206911)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296206911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296206911)
            
            //--TRIMMABLE-BOUNDARY-START(4296206911)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296206911)
            
            static $h = 1239615;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591174207),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1239615,
      "h": 8591174207,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591174207)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296206911),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1239615,
      "h": 4296206911,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296206911)
  ],
  "h": 1239615
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Shared.AnonymousCommentRoot`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Shared${separator}AnonymousCommentRoot`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1239615)
        
        

        //--TRIMMABLE-BOUNDARY-START(1108543)
        $asm.$cls(`$aAgx.LCCRCS$1.AnonymousCommentEditor`, ($self) => class AnonymousCommentEditor extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8591043135)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591043135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8591043135)
            
            //--TRIMMABLE-BOUNDARY-START(4296075839)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296075839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296075839)
            
            //--TRIMMABLE-BOUNDARY-START(4296075839)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296075839)
            
            static $h = 1108543;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591043135),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1108543,
      "h": 8591043135,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591043135)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296075839),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1108543,
      "h": 4296075839,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296075839)
  ],
  "h": 1108543
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Shared.AnonymousCommentEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Shared${separator}AnonymousCommentEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1108543)
        
        

        //--TRIMMABLE-BOUNDARY-START(256575)
        $asm.$cls(`$aAgx.LCCRC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590191167)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590191167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590191167)
            
            //--TRIMMABLE-BOUNDARY-START(4295223871)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295223871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295223871)
            
            //--TRIMMABLE-BOUNDARY-START(4295223871)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295223871)
            
            static $h = 256575;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590191167),
    {
      "r": 65537,
      "n": "Execute",
      "d": 256575,
      "h": 8590191167,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590191167)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295223871),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 256575,
      "h": 4295223871,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295223871)
  ],
  "h": 256575
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(256575)
        
        

        //--TRIMMABLE-BOUNDARY-START(1305151)
        $asm.$cls(`$aAgx.LCCRCS$1.CommunityComment`, ($self) => class CommunityComment extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8591239743)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591239743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8591239743)
            
            //--TRIMMABLE-BOUNDARY-START(4296272447)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296272447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296272447)
            
            //--TRIMMABLE-BOUNDARY-START(4296272447)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296272447)
            
            static $h = 1305151;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591239743),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1305151,
      "h": 8591239743,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591239743)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296272447),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1305151,
      "h": 4296272447,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296272447)
  ],
  "h": 1305151
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Shared.CommunityComment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Shared${separator}CommunityComment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1305151)
        
        

        //--TRIMMABLE-BOUNDARY-START(1370687)
        $asm.$cls(`$aAgx.LCCRCS$1.CommunityCommentEditor`, ($self) => class CommunityCommentEditor extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8591305279)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591305279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8591305279)
            
            //--TRIMMABLE-BOUNDARY-START(4296337983)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296337983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296337983)
            
            //--TRIMMABLE-BOUNDARY-START(4296337983)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296337983)
            
            static $h = 1370687;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591305279),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1370687,
      "h": 8591305279,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591305279)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296337983),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1370687,
      "h": 4296337983,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296337983)
  ],
  "h": 1370687
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Shared.CommunityCommentEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Shared${separator}CommunityCommentEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1370687)
        
        

        //--TRIMMABLE-BOUNDARY-START(584255)
        $asm.$cls(`$aAgx.LCCRCP.Home`, ($self) => class Home extends $.$lJUR.LCFCS.ApplicationLayoutPage
        {
            //--TRIMMABLE-BOUNDARY-START(21475420735)
            /*string */ get OptimizedComponentName()
            {
                return "home applicationlayoutpage";
            }
            //--TRIMMABLE-BOUNDARY-END(21475420735)
            
            //--TRIMMABLE-BOUNDARY-START(8590518847)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590518847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCS$1.CommunityAppIntro, 0);
                __builder.AddComponentParameter(1, "Class", "pdx");
                __builder.AddComponentParameter(2, "Title", "Zoey");
                __builder.AddComponentParameter(3, "SubTitle", "Replys");
                __builder.CloseComponent();
                __builder.AddMarkupContent(4, "\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$FuXl.LCCRCM.CommunityReplyPostModel), 5);
                __builder.AddComponentParameter(6, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, !$.$$.S.String.IsNullOrEmpty(this.SearchKey) ? new $.$fPer.LCFCD.DataFilter().$ctor$19(this.SearchKey, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741853/*PostFilterTypes.Search*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)) : $.$fPer.LCFCD.DataFilter.Default));
                __builder.AddComponentParameter(7, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8192n | 32768n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(8, "SideBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/ & ~32/*SideBarFeatures.ContentScroll*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                __builder.AddComponentParameter(9, "Class", "pdb pdl");
                __builder.AddComponentParameter(10, "li-class", "pd bg-card corner mgt");
                __builder.AddAttribute$3(11, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$FuXl.LCCRCM.CommunityReplyPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$FuXl.LCCRCM.CommunityReplyPostModel))))().$ctor(this, ( (/*comment*/ comment) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        $.$aAgx._LCCRCPH.TypeInference.CreateCommunityAddOn_0($.$FuXl.LCCRCM.CommunityReplyPostModel, __builder2, 12, 13, comment.Data);
                    }, $RMDmck ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":584255,"h":0,"f":17825794});
                }), $OSWmGe ??= {"r":6881395,"p":[{"n":"comment","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$FuXl.LCCRCM.CommunityReplyPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$FuXl.LCCRCM.CommunityReplyPostModel)).$h}],"n":"","d":584255,"h":0,"f":17825794}));
                __builder.AddAttribute$3(14, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                }), $PDErNf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":584255,"h":0,"f":17825794}));
                __builder.SetKey((this.SearchKey ?? $.$cast(this, $.$$.S.Object)));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590518847)
            
            //--TRIMMABLE-BOUNDARY-START(4295551551)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295551551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295551551)
            
            //--TRIMMABLE-BOUNDARY-START(4295551551)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295551551)
            
            static $h = 584255;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationLayoutPage; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475420735),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180453439,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 584255,
      "h": 21475420735,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475420735)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590518847),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 584255,
      "h": 8590518847,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590518847)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295551551),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 584255,
      "h": 4295551551,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295551551)
  ],
  "h": 584255,
  "a": [
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "Zoey",
          "t": 1310721
        },
        {
          "v": 1,
          "t": 655361
        },
        {
          "v": "ReplyHome",
          "t": 1310721
        },
        {
          "v": "Replys",
          "t": 1310721
        },
        {
          "v": "mdi mdi-home",
          "t": 1310721
        },
        {
          "v": 8659766416,
          "t": 67786410
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 7640512,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Reply",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Replys",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$lJUR.LCFCS.IApplicationLayoutPage, $.$lJUR.LCFCS.IApplicationLayoutConfiguration, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Pages.Home`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Pages${separator}Home`; }
        });
        //--TRIMMABLE-BOUNDARY-END(584255)
        
        

        //--TRIMMABLE-BOUNDARY-START(780863)
        $asm.$cls(`$aAgx.LCCRCS.CommunityReplyPostFeedProvider`, ($self) => class CommunityReplyPostFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$FuXl.LCCRCM.CommunityReplyPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295748159)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295748159);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295748159)
            
            //--TRIMMABLE-BOUNDARY-START(8590715455)
            /*CommunityFeedModel */ ConvertFeed(/*CommunityReplyPostModel*/ post)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590715455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let feed = super.ConvertFeed(post);
                feed.ToolBarFeatures &= ~32/*CommunityToolBarFeatures.AddOn*/;
                return feed;
            }
            //--TRIMMABLE-BOUNDARY-END(8590715455)
            
            //--TRIMMABLE-BOUNDARY-START(12885682751)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityReplyPostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885682751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let targetTitle = model.MetadataParentTitle;
                /*var*/ let targetType = model.MetadataParentType;
                if (targetType !== null && targetTitle !== null)
                {
                    return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`commented on ${$.$strNN(targetType)} \"${$.$strNN(targetTitle)}\"`, false);
                }
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1("commented", false);
            }
            //--TRIMMABLE-BOUNDARY-END(12885682751)
            
            static $h = 780863;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$FuXl.LCCRCM.CommunityReplyPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590715455),
    {
      "r": 4822464,
      "p": [
        {
          "n": "post",
          "p": 620119
        }
      ],
      "n": "ConvertFeed",
      "d": 780863,
      "h": 8590715455,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590715455),
//--TRIMMABLE-BOUNDARY-START(12885682751),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 620119
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 780863,
      "h": 12885682751,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885682751)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295748159),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 780863,
      "h": 4295748159,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295748159)
  ],
  "h": 780863
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Services.CommunityReplyPostFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Services${separator}CommunityReplyPostFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(780863)
        
        

        //--TRIMMABLE-BOUNDARY-START(911935)
        $asm.$cls(`$aAgx.LCCRCS.CommunityReplyService`, ($self) => class CommunityReplyService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295879231)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295879231);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295879231)
            
            static $h = 911935;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295879231),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 911935,
      "h": 4295879231,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295879231)
  ],
  "h": 911935
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Services.CommunityReplyService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Services${separator}CommunityReplyService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(911935)
        
        

        //--TRIMMABLE-BOUNDARY-START(977471)
        $asm.$cls(`$aAgx.LCCRCS$1.AccountReplies`, ($self) => class AccountReplies extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$LCOv.LCFCPM$1.AccountModel)
        {
            //--TRIMMABLE-BOUNDARY-START(21475813951)
            /*string */ get OptimizedComponentName()
            {
                return "accountreplies";
            }
            //--TRIMMABLE-BOUNDARY-END(21475813951)
            
            //--TRIMMABLE-BOUNDARY-START(8590912063)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590912063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$FuXl.LCCRCM.CommunityReplyPostModel), 0);
                __builder.AddComponentParameter(1, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.ViewModel.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8192n | 32768n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(3, "SideBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/ & ~32/*SideBarFeatures.ContentScroll*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                __builder.AddComponentParameter(4, "li-class", "corner mgt");
                __builder.AddAttribute$3(5, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$FuXl.LCCRCM.CommunityReplyPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$FuXl.LCCRCM.CommunityReplyPostModel))))().$ctor(this, ( (/**/ comment) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        $.$aAgx._LCCRCSA.TypeInference.CreateCommunityAddOn_0($.$FuXl.LCCRCM.CommunityReplyPostModel, __builder2, 6, 7, comment.Data);
                    }, $KBsZZa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":977471,"h":0,"f":17825794});
                }), $qVqywd ??= {"r":6881395,"p":[{"n":"comment","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$FuXl.LCCRCM.CommunityReplyPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$FuXl.LCCRCM.CommunityReplyPostModel)).$h}],"n":"","d":977471,"h":0,"f":17825794}));
                __builder.AddAttribute$3(8, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 9);
                    __builder2.AddComponentParameter(10, "Message", "No comment yet");
                    __builder2.CloseComponent();
                }), $ajPijh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":977471,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590912063)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295944767)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295944767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295944767)
            
            //--TRIMMABLE-BOUNDARY-START(4295944767)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295944767)
            
            static $h = 977471;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$LCOv.LCFCPM$1.AccountModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475813951),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180846655,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 977471,
      "h": 21475813951,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475813951)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590912063),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 977471,
      "h": 8590912063,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590912063)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295944767),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 977471,
      "h": 4295944767,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295944767)
  ],
  "h": 977471
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Shared.AccountReplies`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Shared${separator}AccountReplies`; }
        });
        //--TRIMMABLE-BOUNDARY-END(977471)
        
        

        //--TRIMMABLE-BOUNDARY-START(715327)
        $asm.$cls(`$aAgx.LCCRCS.CommunityReplyApplication`, ($self) => class CommunityReplyApplication extends $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(12885617215)
            $ctor$3(/*CommunityReplyService*/ service)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885617215);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885617215)
            
            //--TRIMMABLE-BOUNDARY-START(137439668799)
            /*string */ get Name()
            {
                return "Reply";
            }
            //--TRIMMABLE-BOUNDARY-END(137439668799)
            
            //--TRIMMABLE-BOUNDARY-START(154619537983)
            /*string */ get Title()
            {
                return "Reply";
            }
            //--TRIMMABLE-BOUNDARY-END(154619537983)
            
            //--TRIMMABLE-BOUNDARY-START(21475551807)
            /*string */ get Description()
            {
                return "Reply";
            }
            //--TRIMMABLE-BOUNDARY-END(21475551807)
            
            //--TRIMMABLE-BOUNDARY-START(133144701503)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-comment"/*MaterialDesignIconNames.Comment*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144701503)
            
            //--TRIMMABLE-BOUNDARY-START(150324570687)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#1E568B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(150324570687)
            
            //--TRIMMABLE-BOUNDARY-START(30065486399)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065486399)
            
            //--TRIMMABLE-BOUNDARY-START(17180584511)
            /*Type? */ get ApplicationViewType()
            {
                return $.$aAgx.LCCRCP.Home.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180584511)
            
            //--TRIMMABLE-BOUNDARY-START(128849734207)
            /*RenderFragment? */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849734207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 1/*CommunityApplicationViewType.UserDashboard*/ && $.$is(account, $.$LCOv.LCFCPM$1.AccountModel))
                {
                    return $.$hDPm.LCFC.FragmentView.From$1($.$aAgx.LCCRCS$1.AccountReplies, (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.set_Item("ViewModel", $.$box(account, TAccount));
                        return $i2;
                    })(), null, null);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(128849734207)
            
            //--TRIMMABLE-BOUNDARY-START(25770519103)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770519103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770519103)
            
            //--TRIMMABLE-BOUNDARY-START(141734636095)
            /*int */ get Order()
            {
                return 1000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734636095)
            
            //--TRIMMABLE-BOUNDARY-START(4295682623)
            /*CommunityReplyService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295682623)
            
            //--TRIMMABLE-BOUNDARY-START(146029603391)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(146029603391)
            
            //--TRIMMABLE-BOUNDARY-START(158914505279)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(512/*PostTypes.Reply*/, 514/*PostTypes.ReplyEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(158914505279)
            
            static $h = 715327;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439668799),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605093951,
        "f": 50364417
      },
      "n": "Name",
      "d": 715327,
      "h": 137439668799,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439668799),
//--TRIMMABLE-BOUNDARY-START(154619537983),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964832319,
        "f": 50364417
      },
      "n": "Title",
      "d": 715327,
      "h": 154619537983,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619537983),
//--TRIMMABLE-BOUNDARY-START(21475551807),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835290175,
        "f": 50364417
      },
      "n": "Description",
      "d": 715327,
      "h": 21475551807,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475551807),
//--TRIMMABLE-BOUNDARY-START(133144701503),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015159359,
        "f": 50364417
      },
      "n": "Icon",
      "d": 715327,
      "h": 133144701503,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144701503),
//--TRIMMABLE-BOUNDARY-START(150324570687),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374897727,
        "f": 50364417
      },
      "n": "Theme",
      "d": 715327,
      "h": 150324570687,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324570687),
//--TRIMMABLE-BOUNDARY-START(30065486399),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425224767,
        "f": 50364417
      },
      "n": "Features",
      "d": 715327,
      "h": 30065486399,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065486399),
//--TRIMMABLE-BOUNDARY-START(17180584511),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245355583,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 715327,
      "h": 17180584511,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180584511),
//--TRIMMABLE-BOUNDARY-START(141734636095),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195028543,
        "f": 50364417
      },
      "n": "Order",
      "d": 715327,
      "h": 141734636095,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734636095),
//--TRIMMABLE-BOUNDARY-START(4295682623),
    {
      "p": 911935,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655420991,
        "f": 50331650
      },
      "n": "_Service",
      "d": 715327,
      "h": 4295682623,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295682623),
//--TRIMMABLE-BOUNDARY-START(146029603391),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784963135,
        "f": 50364417
      },
      "n": "Service",
      "d": 715327,
      "h": 146029603391,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029603391),
//--TRIMMABLE-BOUNDARY-START(158914505279),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554766911,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 715327,
      "h": 158914505279,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914505279)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849734207),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 715327,
      "h": 128849734207,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849734207),
//--TRIMMABLE-BOUNDARY-START(25770519103),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 715327,
      "h": 25770519103,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770519103)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885617215),
    {
      "p": [
        {
          "n": "service",
          "p": 911935
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 715327,
      "h": 12885617215,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885617215)
  ],
  "h": 715327
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$FuXl.LCCRCM.CommunityReplyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$sZVd.LCFCA.IClientApplication, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$ahDc.LCCCS.ICommunityUserDashboardApplicationPage, $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$LCOv.LCFCPM$1.AccountModel), $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Client.Services.CommunityReplyApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Client${separator}Services${separator}CommunityReplyApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(715327)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Reply.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(59967)
