
//--TRIMMABLE-BOUNDARY-START(30295)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $MJClpj;
    let $faIMrg;
    let $djtpba;
    let $GLUMOc;
    let $PXstzi;
    let $JUJxra;
    let $tRmZFj;
    let $WpFbrj;
    let $KLoVbf;
    let $tCByjg;
    let $lKiEqb;
    let $xDiFRc;
    let $pTAovg;
    let $SQnSzc;
    let $YxAKti;
    let $wUQhpj;
    let $tqJaYb;
    let $ztTgil;
    let $AyOHEc;
    let $BIWAKk;
    let $AUkDGi;
    let $tjEKJh;
    let $KeQzNi;
    let $hwpYHk;
    let $kQUWhj;
    let $oUAQSi;
    let $OJBBDf;
    let $uOAYDf;
    let $lICrDi;
    let $vYomCe;
    let $QZrbqc;
    let $ebtduc;
    let $CLVnPd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Reply.Common", 
    {
  "h": 30295,
  "f": "LivingThing.Core.Community.Reply.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Reply.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Reply.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1341015)
        $asm.$cls(`$FuXl.LCCRC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296308311)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296308311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptorBuilder.Register();
                $.$FuXl.LCCRCM.RatedCommunityReplyModelTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296308311)
            
            static $h = 1341015;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296308311),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1341015,
      "h": 4296308311,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296308311)
  ],
  "h": 1341015
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1341015)
        
        

        //--TRIMMABLE-BOUNDARY-START(947799)
        $asm.$cls(`$FuXl.LCCRCM.RatedCommunityReplyModelCustomAttributesProvider`, ($self) => class RatedCommunityReplyModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295915095)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295915095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$FuXl.LCCRCM.CommunityReplyPostModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295915095)
            
            static $h = 947799;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295915095),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 947799,
      "h": 4295915095,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295915095)
  ],
  "h": 947799
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.Models.RatedCommunityReplyModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}Models${separator}RatedCommunityReplyModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(947799)
        
        

        //--TRIMMABLE-BOUNDARY-START(357975)
        $asm.$cls(`$FuXl.LCCRC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295325271)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295325271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295325271)
            
            static $h = 357975;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295325271),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 357975,
      "h": 4295325271,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295325271)
  ],
  "h": 357975
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(357975)
        
        

        //--TRIMMABLE-BOUNDARY-START(292439)
        $asm.$cls(`$FuXl.LCCRC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295259735)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295259735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$FuXl.LCCRCM.CommentFlags.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$FuXl.LCCRCM.CommentFlagsCustomAttributesProvider, $.$FuXl.LCCRCM.CommentFlagsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$FuXl.LCCRCM.CommunityReplyPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelCustomAttributesProvider, $.$FuXl.LCCRCM.CommunityReplyPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$FuXl.LCCRCM.RatedCommunityReplyModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$FuXl.LCCRCM.RatedCommunityReplyModelCustomAttributesProvider, $.$FuXl.LCCRCM.RatedCommunityReplyModelCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295259735)
            
            static $h = 292439;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295259735),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 292439,
      "h": 4295259735,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295259735)
  ],
  "h": 292439
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(292439)
        
        

        //--TRIMMABLE-BOUNDARY-START(423511)
        $asm.$cls(`$FuXl.LCCRC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295390807)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295390807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$FuXl.LCCCCS.ICommunityReplyPostFeedRemoteService, $.$FuXl.LCCCCS.ICommunityReplyPostFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$FuXl.LCCCCS.ICommunityReplyPostFeedRemoteService_Mocking().$ctor$3(impl);
                }, $djtpba ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":423511,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$FuXl.LCCCCS.ICommunityReplyPostFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$FuXl.LCCCCS.ICommunityReplyPostFeedRemoteService_Mocking().$ctor$3(impl);
                }, $GLUMOc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":423511,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$FuXl.LCCRCS.ICommunityReplyRemoteService, $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking().$ctor$3(impl);
                }, $PXstzi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":423511,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking().$ctor$3(impl);
                }, $JUJxra ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":423511,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking().$ctor$3(impl);
                }, $tRmZFj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":423511,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking().$ctor$3(impl);
                }, $WpFbrj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":423511,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking().$ctor$3(impl);
                }, $KLoVbf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":423511,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking().$ctor$3(impl);
                }, $tCByjg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":423511,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking().$ctor$3(impl);
                }, $lKiEqb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":423511,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking().$ctor$3(impl);
                }, $xDiFRc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":423511,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295390807)
            
            static $h = 423511;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295390807),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 423511,
      "h": 4295390807,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295390807)
  ],
  "h": 423511
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(423511)
        
        

        //--TRIMMABLE-BOUNDARY-START(1078871)
        $asm.$cls(`$FuXl.LCCRCM.RatedCommunityReplyModelTypeDescriptorBuilder`, ($self) => class RatedCommunityReplyModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591013463)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591013463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$FuXl.LCCRCM.RatedCommunityReplyModelTypeDescriptor()
                        const $t1 = $.$FuXl.LCCRCM.RatedCommunityReplyModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Reply.Common.Models.RatedCommunityReplyModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $pTAovg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1078871,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$FuXl.LCCRCM.RatedCommunityReplyModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591013463)
            
            //--TRIMMABLE-BOUNDARY-START(4296046167)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296046167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296046167)
            
            //--TRIMMABLE-BOUNDARY-START(4296046167)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296046167)
            
            static $h = 1078871;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591013463),
    {
      "r": 65537,
      "n": "Register",
      "d": 1078871,
      "h": 8591013463,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591013463)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296046167),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1078871,
      "h": 4296046167,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296046167)
  ],
  "h": 1078871
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.Models.RatedCommunityReplyModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}Models${separator}RatedCommunityReplyModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1078871)
        
        

        //--TRIMMABLE-BOUNDARY-START(554583)
        $asm.$cls(`$FuXl.LCCRCM.CommentFlagsCustomAttributesProvider`, ($self) => class CommentFlagsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295521879)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295521879)
            
            //--TRIMMABLE-BOUNDARY-START(8590489175)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590489175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$FuXl.LCCRCM.CommentFlagsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$FuXl.LCCRCM.CommentFlagsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $MJClpj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":554583,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $faIMrg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":554583,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590489175)
            
            static $h = 554583;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590489175),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 554583,
      "h": 8590489175,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590489175)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295521879),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 554583,
      "h": 4295521879,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295521879)
  ],
  "h": 554583
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.Models.CommentFlagsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}Models${separator}CommentFlagsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(554583)
        
        

        //--TRIMMABLE-BOUNDARY-START(816727)
        $asm.$cls(`$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptorBuilder`, ($self) => class CommunityReplyPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590751319)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590751319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor()
                        const $t1 = $.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $tqJaYb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":816727,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$FuXl.LCCRCM.CommunityReplyPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590751319)
            
            //--TRIMMABLE-BOUNDARY-START(4295784023)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295784023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295784023)
            
            //--TRIMMABLE-BOUNDARY-START(4295784023)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295784023)
            
            static $h = 816727;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590751319),
    {
      "r": 65537,
      "n": "Register",
      "d": 816727,
      "h": 8590751319,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590751319)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295784023),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 816727,
      "h": 4295784023,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295784023)
  ],
  "h": 816727
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}Models${separator}CommunityReplyPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(816727)
        
        

        //--TRIMMABLE-BOUNDARY-START(685655)
        $asm.$cls(`$FuXl.LCCRCM.CommunityReplyPostModelCustomAttributesProvider`, ($self) => class CommunityReplyPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295652951)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295652951)
            
            //--TRIMMABLE-BOUNDARY-START(8590620247)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590620247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$FuXl.LCCRCM.CommunityReplyPostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(8, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("ParentLink", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Email", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (0);
                            $i4.ExcludeFilter = ($.$FuXl.LCCCM.NameEmailReplyExclude.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Tag", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CommentFlags", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("IsAnonymous", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CanAddOn", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("AddOnActivityDescription", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("AddOnParent", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$FuXl.LCCRCM.CommunityReplyPostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $YxAKti ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":685655,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $wUQhpj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":685655,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590620247)
            
            static $h = 685655;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590620247),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 685655,
      "h": 8590620247,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590620247)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295652951),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 685655,
      "h": 4295652951,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295652951)
  ],
  "h": 685655
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}Models${separator}CommunityReplyPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(685655)
        
        

        //--TRIMMABLE-BOUNDARY-START(1144407)
        $asm.$cls(`$FuXl.LCCRC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591078999)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591078999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$FuXl.LCCRC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$FuXl.LCCRCM.CommunityReplyPostModel, 512/*PostTypes.Reply*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$FuXl.LCCRCM.CommunityReplyPostModel, 513/*PostTypes.ReplyReply*/);
                $.$FuXl.LCCRC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$FuXl.LCCRC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$FuXl.LCCRC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591078999)
            
            //--TRIMMABLE-BOUNDARY-START(12886046295)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886046295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12886046295)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$FuXl.LCCRC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296111703)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296111703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296111703)
            
            //--TRIMMABLE-BOUNDARY-START(4296111703)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296111703)
            
            static $h = 1144407;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591078999),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1144407,
      "h": 8591078999,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591078999),
//--TRIMMABLE-BOUNDARY-START(12886046295),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 1144407,
      "h": 12886046295,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886046295)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296111703),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1144407,
      "h": 4296111703,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296111703)
  ],
  "h": 1144407
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1144407)
        
        

        //--TRIMMABLE-BOUNDARY-START(226903)
        $asm.$cls(`$FuXl.LCCCM.NameEmailReplyExclude`, ($self) => class NameEmailReplyExclude extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590161495)
            /*bool */ Filter(/*object?*/ target, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590161495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let model;
                if ($.$is(target, $.$FuXl.LCCRCM.CommunityReplyPostModel, { set $v($v){ model = $v; } }))
                {
                    return model.IsAnonymous;
                }
                return schema.AttributeFilter;
            }
            //--TRIMMABLE-BOUNDARY-END(8590161495)
            
            //--TRIMMABLE-BOUNDARY-START(4296968534)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaFilterProvider.Filter(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaFilterProvider$Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296968534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296968534)
            
            //--TRIMMABLE-BOUNDARY-START(4295194199)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295194199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295194199)
            
            //--TRIMMABLE-BOUNDARY-START(4295194199)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295194199)
            
            static $h = 226903;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590161495),
    {
      "r": 262145,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Filter",
      "d": 226903,
      "h": 8590161495,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590161495)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295194199),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 226903,
      "h": 4295194199,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295194199)
  ],
  "h": 226903
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaFilterProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.NameEmailReplyExclude`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}NameEmailReplyExclude`; }
        });
        //--TRIMMABLE-BOUNDARY-END(226903)
        
        

        //--TRIMMABLE-BOUNDARY-START(489047)
        $asm.$str(`$FuXl.LCCRCM.CommentFlags`, ($self) => class CommentFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Approved = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Approved": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295456343)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295456343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295456343)
            
            //--TRIMMABLE-BOUNDARY-START(4295456343)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295456343)
            
            static $h = 489047;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885390935),
    {
      "t": 489047,
      "n": "None",
      "d": 489047,
      "h": 12885390935,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885390935),
//--TRIMMABLE-BOUNDARY-START(8590423639),
    {
      "t": 489047,
      "n": "Approved",
      "d": 489047,
      "h": 8590423639,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590423639)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295456343),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 489047,
      "h": 4295456343,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295456343)
  ],
  "h": 489047,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.Models.CommentFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}Models${separator}CommentFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(489047)
        
        

        //--TRIMMABLE-BOUNDARY-START(620119)
        $asm.$cls(`$FuXl.LCCRCM.CommunityReplyPostModel`, ($self) => class CommunityReplyPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(25770423895)
            $ctor$6()
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770423895);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = "_";
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770423895)
            
            //--TRIMMABLE-BOUNDARY-START(236223821399)
            /*PostTypes */ get Type()
            {
                return this.SetType ?? 512/*PostTypes.Reply*/;
            }
            //--TRIMMABLE-BOUNDARY-END(236223821399)
            
            //--TRIMMABLE-BOUNDARY-START(219043952215)
            /*bool */ ShouldEditName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(219043952215);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219043952215)
            
            //--TRIMMABLE-BOUNDARY-START(158914410071)
            /*bool */ RequiresName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914410071);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914410071)
            
            //--TRIMMABLE-BOUNDARY-START(223338919511)
            /*bool */ ShouldEditSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(223338919511);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223338919511)
            
            //--TRIMMABLE-BOUNDARY-START(163209377367)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209377367);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209377367)
            
            //--TRIMMABLE-BOUNDARY-START(227633886807)
            /*bool */ ShouldEditTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227633886807);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227633886807)
            
            //--TRIMMABLE-BOUNDARY-START(167504344663)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504344663);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504344663)
            
            //--TRIMMABLE-BOUNDARY-START(214748984919)
            /*bool */ ShouldEditIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214748984919);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214748984919)
            
            //--TRIMMABLE-BOUNDARY-START(154619442775)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619442775);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619442775)
            
            //--TRIMMABLE-BOUNDARY-START(240518788695)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518788695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                descriptors = $.$LCOv.LCFCPM$1.PostBaseModel.Exclude(descriptors, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "Name", "Summary", "Email", "PostFlags" ], null, null));
                return super.UpdateDescriptors(descriptors, $.$clone(schema));
            }
            //--TRIMMABLE-BOUNDARY-END(240518788695)
            
            //--TRIMMABLE-BOUNDARY-START(146029508183)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029508183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.ModifyDescriptor(propertyBuilder);
                $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Post", "Enter Reply", "", null, 11n, 1000);
            }
            //--TRIMMABLE-BOUNDARY-END(146029508183)
            
            //--TRIMMABLE-BOUNDARY-START(141734540887)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$2(this, null, "Reply/Post", null, true);
            }
            //--TRIMMABLE-BOUNDARY-END(141734540887)
            
            //--TRIMMABLE-BOUNDARY-START(150324475479)
            /*string? */ get ParentLink()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964737111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let targetLink = this.MetadataParentLink;
                if (targetLink !== null)
                {
                    return `${$.$strNN(targetLink)}#${$.$strNN($.$dspc(this.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}`;
                }
                if (this.ParentId.HasValue)
                {
                    return `Post/${$.$strNN($.$dspc(this.ParentId.Id, $.$$.S.Object, ($t) => $t.ToString))}#${$.$strNN(this.Identifier.ToString())}`;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(150324475479)
            
            //--TRIMMABLE-BOUNDARY-START(47245260375)
            /*string*/ Email = null;
            //--TRIMMABLE-BOUNDARY-END(47245260375)
            
            //--TRIMMABLE-BOUNDARY-START(231928854103)
            /*string*/ Tag = null;
            //--TRIMMABLE-BOUNDARY-END(231928854103)
            
            //--TRIMMABLE-BOUNDARY-START(42950293079)
            /*CommentFlags*/ CommentFlags = 0;
            //--TRIMMABLE-BOUNDARY-END(42950293079)
            
            //--TRIMMABLE-BOUNDARY-START(137439573591)
            /*bool*/ IsAnonymous = false;
            //--TRIMMABLE-BOUNDARY-END(137439573591)
            
            //--TRIMMABLE-BOUNDARY-START(38655325783)
            /*bool */ get CanAddOn()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(38655325783)
            
            //--TRIMMABLE-BOUNDARY-START(30065391191)
            /*string */ get AddOnActivityDescription()
            {
                return "commented";
            }
            //--TRIMMABLE-BOUNDARY-END(30065391191)
            
            //--TRIMMABLE-BOUNDARY-START(34360358487)
            /*PostBaseModel*/ AddOnParent = null;
            //--TRIMMABLE-BOUNDARY-END(34360358487)
            
            //--TRIMMABLE-BOUNDARY-START(38656010676)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostAddOn.CanAddOn.get
            get LCFCP$IPostAddOn$CanAddOn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886206900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanAddOn;
            }
            //--TRIMMABLE-BOUNDARY-END(38656010676)
            
            //--TRIMMABLE-BOUNDARY-START(21476141492)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostAddOn.AddOnActivityDescription.get
            get LCFCP$IPostAddOn$AddOnActivityDescription()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296272308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddOnActivityDescription;
            }
            //--TRIMMABLE-BOUNDARY-END(21476141492)
            
            //--TRIMMABLE-BOUNDARY-START(30066076084)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostAddOn.AddOnParent.get
            get LCFCP$IPostAddOn$AddOnParent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591239604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddOnParent;
            }
            //--TRIMMABLE-BOUNDARY-END(30066076084)
            
            //--TRIMMABLE-BOUNDARY-START(47245945268)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostAddOn.AddOnParent.set
            set LCFCP$IPostAddOn$AddOnParent(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591239604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddOnParent = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47245945268)
            
            //--TRIMMABLE-BOUNDARY-START(8593271220)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesCount.get
            get LCFCP$IPostReplyable$RepliesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478173108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593271220)
            
            //--TRIMMABLE-BOUNDARY-START(17183205812)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesDepth.get
            get LCFCP$IPostReplyable$RepliesDepth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773140404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesDepth;
            }
            //--TRIMMABLE-BOUNDARY-END(17183205812)
            
            //--TRIMMABLE-BOUNDARY-START(8593009076)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReactable.Reactions.get
            get LCFCP$IPostReactable$Reactions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887976372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reactions;
            }
            //--TRIMMABLE-BOUNDARY-END(8593009076)
            
            //--TRIMMABLE-BOUNDARY-START(25770423895)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(25770423895)
            
            static $h = 620119;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(236223821399),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144606295,
        "f": 50364417
      },
      "n": "Type",
      "d": 620119,
      "h": 236223821399,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(236223821399),
//--TRIMMABLE-BOUNDARY-START(141734540887),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374802519,
        "f": 50364417
      },
      "n": "Link",
      "d": 620119,
      "h": 141734540887,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734540887),
//--TRIMMABLE-BOUNDARY-START(150324475479),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964737111,
        "f": 50331649
      },
      "n": "ParentLink",
      "d": 620119,
      "h": 150324475479,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324475479),
//--TRIMMABLE-BOUNDARY-START(47245260375),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194933335,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193274148439,
        "f": 83886081
      },
      "n": "Email",
      "d": 620119,
      "h": 47245260375,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 0,
              "t": 655361
            },
            {
              "n": "ExcludeFilter",
              "v": 226903,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245260375),
//--TRIMMABLE-BOUNDARY-START(231928854103),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554671703,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454017623,
        "f": 83886081
      },
      "n": "Tag",
      "d": 620119,
      "h": 231928854103,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231928854103),
//--TRIMMABLE-BOUNDARY-START(42950293079),
    {
      "p": 489047,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604998743,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184684213847,
        "f": 83886081
      },
      "n": "CommentFlags",
      "d": 620119,
      "h": 42950293079,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950293079),
//--TRIMMABLE-BOUNDARY-START(137439573591),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784867927,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201864083031,
        "f": 83886081
      },
      "n": "IsAnonymous",
      "d": 620119,
      "h": 137439573591,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439573591),
//--TRIMMABLE-BOUNDARY-START(38655325783),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015064151,
        "f": 50331649
      },
      "n": "CanAddOn",
      "d": 620119,
      "h": 38655325783,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655325783),
//--TRIMMABLE-BOUNDARY-START(30065391191),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835194967,
        "f": 50331649
      },
      "n": "AddOnActivityDescription",
      "d": 620119,
      "h": 30065391191,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065391191),
//--TRIMMABLE-BOUNDARY-START(34360358487),
    {
      "p": 16771508,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425129559,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094279255,
        "f": 83886081
      },
      "n": "AddOnParent",
      "d": 620119,
      "h": 34360358487,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360358487)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(219043952215),
    {
      "r": 262145,
      "n": "ShouldEditName",
      "d": 620119,
      "h": 219043952215,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(219043952215),
//--TRIMMABLE-BOUNDARY-START(158914410071),
    {
      "r": 262145,
      "n": "RequiresName",
      "d": 620119,
      "h": 158914410071,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158914410071),
//--TRIMMABLE-BOUNDARY-START(223338919511),
    {
      "r": 262145,
      "n": "ShouldEditSummary",
      "d": 620119,
      "h": 223338919511,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(223338919511),
//--TRIMMABLE-BOUNDARY-START(163209377367),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 620119,
      "h": 163209377367,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163209377367),
//--TRIMMABLE-BOUNDARY-START(227633886807),
    {
      "r": 262145,
      "n": "ShouldEditTags",
      "d": 620119,
      "h": 227633886807,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(227633886807),
//--TRIMMABLE-BOUNDARY-START(167504344663),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": 620119,
      "h": 167504344663,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167504344663),
//--TRIMMABLE-BOUNDARY-START(214748984919),
    {
      "r": 262145,
      "n": "ShouldEditIcon",
      "d": 620119,
      "h": 214748984919,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(214748984919),
//--TRIMMABLE-BOUNDARY-START(154619442775),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 620119,
      "h": 154619442775,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154619442775),
//--TRIMMABLE-BOUNDARY-START(240518788695),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": 620119,
      "h": 240518788695,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(240518788695),
//--TRIMMABLE-BOUNDARY-START(146029508183),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 620119,
      "h": 146029508183,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029508183)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770423895),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 620119,
      "h": 25770423895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770423895)
  ],
  "h": 620119
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostAddOn, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostReactable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}Models${separator}CommunityReplyPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(620119)
        
        

        //--TRIMMABLE-BOUNDARY-START(95831)
        $asm.$cls(`$FuXl.LCCCCS.ICommunityReplyPostFeedRemoteService`, ($self) => class ICommunityReplyPostFeedRemoteService
        {
            static $h = 95831;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 95831,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Commmet.Common.Services.ICommunityReplyPostFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Commmet${separator}Common${separator}Services${separator}ICommunityReplyPostFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(95831)
        
        

        //--TRIMMABLE-BOUNDARY-START(1209943)
        $asm.$cls(`$FuXl.LCCRCS.ICommunityReplyRemoteService`, ($self) => class ICommunityReplyRemoteService
        {
            static $h = 1209943;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591144535),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.Int32)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "CountReply",
      "o": "LCCRCS$ICommunityReplyRemoteService$CountReply",
      "d": 1209943,
      "h": 8591144535,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591144535),
//--TRIMMABLE-BOUNDARY-START(4296177239),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "commentId",
          "p": 1310721
        }
      ],
      "n": "ApproveReply",
      "o": "LCCRCS$ICommunityReplyRemoteService$ApproveReply",
      "d": 1209943,
      "h": 4296177239,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296177239)
  ],
  "h": 1209943,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.IReadDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.Services.ICommunityReplyRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}Services${separator}ICommunityReplyRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1209943)
        
        

        //--TRIMMABLE-BOUNDARY-START(882263)
        $asm.$cls(`$FuXl.LCCRCM.RatedCommunityReplyModel`, ($self) => class RatedCommunityReplyModel extends $.$FuXl.LCCRCM.CommunityReplyPostModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590816855)
            /*ValueTask<bool> */ Validate(/*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590816855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Rating <= 0)
                {
                    return $.$$.STT.ValueTask.FromException$1($.$$.S.Boolean, new $.$$.S.InvalidOperationException().$ctor$12("Rating required"));
                }
                return super.Validate($.$clone(schema));
            }
            //--TRIMMABLE-BOUNDARY-END(8590816855)
            
            //--TRIMMABLE-BOUNDARY-START(4295849559)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295849559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295849559)
            
            //--TRIMMABLE-BOUNDARY-START(4295849559)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295849559)
            
            static $h = 882263;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$FuXl.LCCRCM.CommunityReplyPostModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590816855),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Validate",
      "d": 882263,
      "h": 8590816855,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590816855)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295849559),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 882263,
      "h": 4295849559,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295849559)
  ],
  "h": 882263
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostAddOn, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostReactable, $.$fPer.LCFCD.IDataValidator ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.Models.RatedCommunityReplyModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}Models${separator}RatedCommunityReplyModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(882263)
        
        

        //--TRIMMABLE-BOUNDARY-START(161367)
        $asm.$cls(`$FuXl.LCCCCS.ICommunityReplyPostFeedRemoteService_Mocking`, ($self) => class ICommunityReplyPostFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295128663)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295128663);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295128663)
            
            //--TRIMMABLE-BOUNDARY-START(8590095959)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Reply$Common$Models$CommunityReplyPostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590095959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$FuXl.LCCRCM.CommunityReplyPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$FuXl.LCCRCM.CommunityReplyPostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590095959)
            
            static $h = 161367;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295128663),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 161367,
      "h": 4295128663,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295128663)
  ],
  "h": 161367
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$FuXl.LCCCCS.ICommunityReplyPostFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Commmet.Common.Services.ICommunityReplyPostFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Commmet${separator}Common${separator}Services${separator}ICommunityReplyPostFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(161367)
        
        

        //--TRIMMABLE-BOUNDARY-START(1275479)
        $asm.$cls(`$FuXl.LCCRCS.ICommunityReplyRemoteService_Mocking`, ($self) => class ICommunityReplyRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296242775)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296242775);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296242775)
            
            //--TRIMMABLE-BOUNDARY-START(12886177367)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<int>> */ LCCRCS$ICommunityReplyRemoteService$CountReply(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886177367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$FuXl.LCCRCS.ICommunityReplyRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$$.S.Int32).$type;
                    $i1.MethodName = "CountReply";
                    return $i1;
                })();
                return this.InvokeAsync($.$FuXl.LCCRCS.ICommunityReplyRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.Int32), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886177367)
            
            //--TRIMMABLE-BOUNDARY-START(8591210071)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel> */ LCCRCS$ICommunityReplyRemoteService$ApproveReply(/*string*/ commentId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591210071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$FuXl.LCCRCS.ICommunityReplyRemoteService.$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportModel.$type;
                    $i2.MethodName = "ApproveReply";
                    return $i2;
                })();
                return this.InvokeAsync($.$FuXl.LCCRCS.ICommunityReplyRemoteService, $.$fPer.LCFCD.WireTransportModel, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, commentId) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591210071)
            
            //--TRIMMABLE-BOUNDARY-START(17181144663)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Reply$Common$Models$CommunityReplyPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181144663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$FuXl.LCCRCM.CommunityReplyPostModel).$type;
                    $i3.MethodName = "Create";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$FuXl.LCCRCM.CommunityReplyPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181144663)
            
            //--TRIMMABLE-BOUNDARY-START(25771079255)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Reply$Common$Models$CommunityReplyPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771079255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$FuXl.LCCRCM.CommunityReplyPostModel).$type;
                    $i4.MethodName = "ReadMany";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$FuXl.LCCRCM.CommunityReplyPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771079255)
            
            //--TRIMMABLE-BOUNDARY-START(30066046551)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Reply$Common$Models$CommunityReplyPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066046551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$FuXl.LCCRCM.CommunityReplyPostModel).$type;
                    $i5.MethodName = "ReadSingle";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$FuXl.LCCRCM.CommunityReplyPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30066046551)
            
            //--TRIMMABLE-BOUNDARY-START(34361013847)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Reply$Common$Models$CommunityReplyPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361013847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel).$type;
                    $i6.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$FuXl.LCCRCM.CommunityReplyPostModel).$type;
                    $i6.MethodName = "Update";
                    return $i6;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$FuXl.LCCRCM.CommunityReplyPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(34361013847)
            
            //--TRIMMABLE-BOUNDARY-START(21476111959)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476111959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel).$type;
                    $i7.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i7.MethodName = "Delete";
                    return $i7;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$FuXl.LCCRCM.CommunityReplyPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476111959)
            
            static $h = 1275479;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296242775),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1275479,
      "h": 4296242775,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296242775)
  ],
  "h": 1275479
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$FuXl.LCCRCS.ICommunityReplyRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.IReadDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.Services.ICommunityReplyRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}Services${separator}ICommunityReplyRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1275479)
        
        

        //--TRIMMABLE-BOUNDARY-START(751191)
        $asm.$cls(`$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor`, ($self) => class CommunityReplyPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$FuXl.LCCRCM.CommunityReplyPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295718487)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295718487);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor.GenerateProperties($.$FuXl.LCCRCM.CommunityReplyPostModel, this, factory);
                    }, $ztTgil ??= {"r":65537,"n":"","d":751191,"h":0,"f":17825794}), 0, "CommunityReplyPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Reply.Common\\Models_CommunityReplyPostModel_LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModelTypeDescriptorBuilder.g.cs", "CommunityReplyPostModelTypeDescriptor", 46);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295718487)
            
            //--TRIMMABLE-BOUNDARY-START(12885653079)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885653079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Email"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$FuXl.LCCRCM.CommunityReplyPostModel.$type, $.$discardRef(), "Email", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Email")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Email";
                        $i1.DelaredOn = "LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$FuXl.LCCRCM.CommunityReplyPostModel)).Email);
                        }, $AyOHEc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":751191,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Email = value.AsReference($.$$.S.String);
                        }, $BIWAKk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":751191,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$FuXl.LCCRCM.CommunityReplyPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Type";
                        $i3.DelaredOn = "LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$FuXl.LCCRCM.CommunityReplyPostModel)).Type);
                        }, $AUkDGi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":751191,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$FuXl.LCCRCM.CommunityReplyPostModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Link";
                        $i5.DelaredOn = "LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$FuXl.LCCRCM.CommunityReplyPostModel)).Link);
                        }, $tjEKJh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":751191,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ParentLink"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$FuXl.LCCRCM.CommunityReplyPostModel.$type, $.$discardRef(), "ParentLink", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ParentLink")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "ParentLink";
                        $i7.DelaredOn = "LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$FuXl.LCCRCM.CommunityReplyPostModel)).ParentLink);
                        }, $KeQzNi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":751191,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Tag"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$FuXl.LCCRCM.CommunityReplyPostModel.$type, $.$discardRef(), "Tag", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Tag")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Tag";
                        $i9.DelaredOn = "LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$FuXl.LCCRCM.CommunityReplyPostModel)).Tag);
                        }, $hwpYHk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":751191,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Tag = value.AsReference($.$$.S.String);
                        }, $kQUWhj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":751191,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CommentFlags"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$FuXl.LCCRCM.CommunityReplyPostModel.$type, $.$discardRef(), "CommentFlags", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CommentFlags")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$FuXl.LCCRCM.CommentFlags, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "CommentFlags";
                        $i11.DelaredOn = "LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$FuXl.LCCRCM.CommentFlags, ($.$cast(target, $.$FuXl.LCCRCM.CommunityReplyPostModel)).CommentFlags);
                        }, $oUAQSi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":751191,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CommentFlags = value.AsEnumValue($.$FuXl.LCCRCM.CommentFlags);
                        }, $OJBBDf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":751191,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsAnonymous"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$FuXl.LCCRCM.CommunityReplyPostModel.$type, $.$discardRef(), "IsAnonymous", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsAnonymous")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "IsAnonymous";
                        $i13.DelaredOn = "LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$FuXl.LCCRCM.CommunityReplyPostModel)).IsAnonymous);
                        }, $uOAYDf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":751191,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.IsAnonymous = value.AsBool();
                        }, $lICrDi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":751191,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CanAddOn"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$FuXl.LCCRCM.CommunityReplyPostModel.$type, $.$discardRef(), "CanAddOn", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CanAddOn")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "CanAddOn";
                        $i15.DelaredOn = "LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$FuXl.LCCRCM.CommunityReplyPostModel)).CanAddOn);
                        }, $vYomCe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":751191,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AddOnActivityDescription"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$FuXl.LCCRCM.CommunityReplyPostModel.$type, $.$discardRef(), "AddOnActivityDescription", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AddOnActivityDescription")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "AddOnActivityDescription";
                        $i17.DelaredOn = "LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$FuXl.LCCRCM.CommunityReplyPostModel)).AddOnActivityDescription);
                        }, $QZrbqc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":751191,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AddOnParent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$FuXl.LCCRCM.CommunityReplyPostModel.$type, $.$discardRef(), "AddOnParent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AddOnParent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostBaseModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "AddOnParent";
                        $i19.DelaredOn = "LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$LCOv.LCFCPM$1.PostBaseModel, ($.$cast(target, $.$FuXl.LCCRCM.CommunityReplyPostModel)).AddOnParent);
                        }, $ebtduc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":751191,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.AddOnParent = value.AsReference($.$LCOv.LCFCPM$1.PostBaseModel);
                        }, $CLVnPd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":751191,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885653079)
            
            //--TRIMMABLE-BOUNDARY-START(17180620375)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180620375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Email = _target.Email;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Email"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Email, ($v) => _Email = $v, $.$$.S.String)))
                    {
                        _target.Email = _Email;
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _ParentLink = _target.ParentLink;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ParentLink"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ParentLink, ($v) => _ParentLink = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Tag = _target.Tag;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Tag"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Tag, ($v) => _Tag = $v, $.$$.S.String)))
                    {
                        _target.Tag = _Tag;
                    }
                }
                {
                    /*var*/ let _CommentFlags = _target.CommentFlags;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CommentFlags"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$FuXl.LCCRCM.CommentFlags));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$FuXl.LCCRCM.CommentFlags, () => _CommentFlags, ($v) => _CommentFlags = $v, null, true)))
                    {
                        _target.CommentFlags = _CommentFlags;
                    }
                }
                {
                    /*var*/ let _IsAnonymous = _target.IsAnonymous;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsAnonymous"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsAnonymous, ($v) => _IsAnonymous = $v, null, true)))
                    {
                        _target.IsAnonymous = _IsAnonymous;
                    }
                }
                {
                    /*var*/ let _CanAddOn = _target.CanAddOn;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CanAddOn"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _CanAddOn, ($v) => _CanAddOn = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _AddOnActivityDescription = _target.AddOnActivityDescription;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AddOnActivityDescription"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _AddOnActivityDescription, ($v) => _AddOnActivityDescription = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _AddOnParent = _target.AddOnParent;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AddOnParent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostBaseModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _AddOnParent, ($v) => _AddOnParent = $v, $.$LCOv.LCFCPM$1.PostBaseModel)))
                    {
                        _target.AddOnParent = _AddOnParent;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180620375)
            
            //--TRIMMABLE-BOUNDARY-START(8590685783)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590685783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$FuXl.LCCRCM.CommunityReplyPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$FuXl.LCCRCM.CommunityReplyPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$FuXl.LCCRCM.CommunityReplyPostModel)))
                {
                    /*var*/ let result = $.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$FuXl.LCCRCM.CommunityReplyPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$FuXl.LCCRCM.CommunityReplyPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$FuXl.LCCRCM.CommunityReplyPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590685783)
            
            static $h = 751191;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$FuXl.LCCRCM.CommunityReplyPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885653079),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 751191,
      "h": 12885653079,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885653079),
//--TRIMMABLE-BOUNDARY-START(17180620375),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 620119,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 751191,
      "h": 17180620375,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180620375),
//--TRIMMABLE-BOUNDARY-START(8590685783),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 620119,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 751191,
      "h": 8590685783,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590685783)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295718487),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 751191,
      "h": 4295718487,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295718487)
  ],
  "h": 751191
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$FuXl.LCCRCM.CommunityReplyPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}Models${separator}CommunityReplyPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(751191)
        
        

        //--TRIMMABLE-BOUNDARY-START(1013335)
        $asm.$cls(`$FuXl.LCCRCM.RatedCommunityReplyModelTypeDescriptor`, ($self) => class RatedCommunityReplyModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$FuXl.LCCRCM.RatedCommunityReplyModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295980631)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295980631);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$FuXl.LCCRCM.RatedCommunityReplyModelTypeDescriptor.GenerateProperties($.$FuXl.LCCRCM.RatedCommunityReplyModel, this, factory);
                    }, $SQnSzc ??= {"r":65537,"n":"","d":1013335,"h":0,"f":17825794}), 0, "RatedCommunityReplyModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Reply.Common\\Models_RatedCommunityReplyModel_LivingThing.Core.Community.Reply.Common.Models.RatedCommunityReplyModelTypeDescriptorBuilder.g.cs", "RatedCommunityReplyModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295980631)
            
            //--TRIMMABLE-BOUNDARY-START(12885915223)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885915223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885915223)
            
            //--TRIMMABLE-BOUNDARY-START(17180882519)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Reply.Common.Models.RatedCommunityReplyModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180882519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Reply.Common.Models.CommunityReplyPostModel?*/ let targetBase = _target;
                $.$FuXl.LCCRCM.CommunityReplyPostModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$FuXl.LCCRCM.CommunityReplyPostModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180882519)
            
            //--TRIMMABLE-BOUNDARY-START(8590947927)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Reply.Common.Models.RatedCommunityReplyModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590947927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$FuXl.LCCRCM.RatedCommunityReplyModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$FuXl.LCCRCM.RatedCommunityReplyModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$FuXl.LCCRCM.RatedCommunityReplyModel)))
                {
                    /*var*/ let result = $.$FuXl.LCCRCM.RatedCommunityReplyModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$FuXl.LCCRCM.RatedCommunityReplyModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$FuXl.LCCRCM.RatedCommunityReplyModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$FuXl.LCCRCM.RatedCommunityReplyModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590947927)
            
            static $h = 1013335;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$FuXl.LCCRCM.RatedCommunityReplyModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885915223),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1013335,
      "h": 12885915223,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885915223),
//--TRIMMABLE-BOUNDARY-START(17180882519),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 882263,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1013335,
      "h": 17180882519,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180882519),
//--TRIMMABLE-BOUNDARY-START(8590947927),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 882263,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1013335,
      "h": 8590947927,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590947927)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295980631),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1013335,
      "h": 4295980631,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295980631)
  ],
  "h": 1013335
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$FuXl.LCCRCM.RatedCommunityReplyModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Reply.Common.Models.RatedCommunityReplyModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Reply${separator}Common${separator}Models${separator}RatedCommunityReplyModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1013335)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(30295)
