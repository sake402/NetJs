
//--TRIMMABLE-BOUNDARY-START(55912)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $dXSd) {
    "use strict";
    let _;
    let $RFyzOe;
    let $cMROuf;
    let $gWUXme;
    let $VkIyfj;
    let $BAUclk;
    let $aGCMwc;
    let $QjjBch;
    let $ksVkke;
    let $hvHyij;
    let $adPRjg;
    let $UVJlDi;
    let $DzUPPj;
    let $evFxya;
    let $zJXook;
    let $eAIThe;
    let $fnduce;
    let $DPiELj;
    let $jXXQkc;
    let $LNtpLf;
    let $dcWIbi;
    let $JqgtPb;
    let $oYIGTi;
    let $iZMsZb;
    let $rdzNAd;
    let $AElQEh;
    let $fjXUJe;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Review.Client.Blazor", 
    {
  "h": 55912,
  "f": "LivingThing.Core.Community.Review.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Review.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Review.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(186984)
        $asm.$cls(`$dqzR.LCCRC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295154280)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295154280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$dqzR.LCCRC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295154280)
            
            static $h = 186984;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295154280),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 186984,
      "h": 4295154280,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295154280)
  ],
  "h": 186984
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(186984)
        
        

        //--TRIMMABLE-BOUNDARY-START(252520)
        $asm.$cls(`$dqzR.LCCRC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180121704)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$dqzR.LCCRCP.CommunityReviewApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$dqzR.LCCRCP.CommunityReviewApp().$ctor$6();
                    }, $RFyzOe ??= {"r":2752627,"n":"","d":252520,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$dqzR.LCCRCS$1.CommunityReview.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$dqzR.LCCRCS$1.CommunityReview().$ctor$5();
                    }, $cMROuf ??= {"r":2752627,"n":"","d":252520,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$dqzR.LCCRCS$1.CommunityReviewRatingSummary.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$dqzR.LCCRCS$1.CommunityReviewRatingSummary().$ctor$5();
                    }, $gWUXme ??= {"r":2752627,"n":"","d":252520,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180121704)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295219816)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295219816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295219816)
            
            //--TRIMMABLE-BOUNDARY-START(4295219816)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295219816)
            
            static $h = 252520;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180121704),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885154408,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 252520,
      "h": 17180121704,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180121704)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295219816),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 252520,
      "h": 4295219816,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295219816)
  ],
  "h": 252520
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(252520)
        
        

        //--TRIMMABLE-BOUNDARY-START(383592)
        $asm.$cls(`$dqzR.LCCRC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590318184)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590318184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$dqzR.LCCRC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$dqzR.LCCRCS.CommunityReviewService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$dXSd.LCCRCM.CommunityReviewPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel, $.$dXSd.LCCRCM.CommunityReviewPostModel, $.$dXSd.LCCRCM.CommunityReviewUserPreference), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$dqzR.LCCRCS.CommunityReviewApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$dqzR.LCCRCS.CommunityReviewApplication, x);
                }, $aGCMwc ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":383592,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel, $.$dXSd.LCCRCM.CommunityReviewPostModel, $.$dXSd.LCCRCM.CommunityReviewUserPreference)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$dqzR.LCCRCS.CommunityReviewApplication, x);
                }, $QjjBch ??= {"r":$.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel, $.$dXSd.LCCRCM.CommunityReviewPostModel, $.$dXSd.LCCRCM.CommunityReviewUserPreference).$h,"p":[{"n":"x","p":327718}],"n":"","d":383592,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$dqzR.LCCRCS.CommunityReviewApplication, x);
                }, $ksVkke ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":383592,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$dqzR.LCCRCS.CommunityReviewFeedProvider, services);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$dXSd.LCCRCM.CommunityReviewCategoryModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$dXSd.LCCRCM.CommunityReviewPostModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$dXSd.LCCRCM.CommunityReviewElementModel, services, null);
                $.$dqzR.LCCRC._Startup.AddGeneratedComponentOptimizers(services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$hDPm.LCFCI.IViewProvider$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$dqzR.LCCRCS.CommunityReviewViewProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCS.ICommunityPostAddOnProvider, $.$dqzR.LCCRCS.CommunityReviewAddOnProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590318184)
            
            //--TRIMMABLE-BOUNDARY-START(12885285480)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885285480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_CommunityReviewApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$dqzR.LCCRCS.CommunityReviewApplication().$ctor$3(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$dqzR.LCCRCS.CommunityReviewService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$dqzR.LCCRCS.CommunityReviewService, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$dqzR.LCCRCS.CommunityReviewApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$dqzR.LCCRC.ServiceRegistrar, Get_CommunityReviewApplication, $hvHyij ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_CommunityReviewApplication","d":383592,"h":0,"f":16777250})));
                /*static object*/  function Get_IClientApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$dqzR.LCCRCS.CommunityReviewApplication, x);
                    }), $adPRjg ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":383592,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$sZVd.LCFCA.IClientApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$dqzR.LCCRC.ServiceRegistrar, Get_IClientApplication, $UVJlDi ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IClientApplication","d":383592,"h":0,"f":16777250})));
                /*static object*/  function Get_ICommunityClientApplication_CommunityReviewCategoryModel_CommunityReviewElementModel_CommunityReviewPostModel_CommunityReviewUserPreference_(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$dqzR.LCCRCS.CommunityReviewApplication, x);
                    }), $DzUPPj ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":383592,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel, $.$dXSd.LCCRCM.CommunityReviewPostModel, $.$dXSd.LCCRCM.CommunityReviewUserPreference).$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$dqzR.LCCRC.ServiceRegistrar, Get_ICommunityClientApplication_CommunityReviewCategoryModel_CommunityReviewElementModel_CommunityReviewPostModel_CommunityReviewUserPreference_, $evFxya ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ICommunityClientApplication_CommunityReviewCategoryModel_CommunityReviewElementModel_CommunityReviewPostModel_CommunityReviewUserPreference_","d":383592,"h":0,"f":16777250})));
                /*static object*/  function Get_ICommunityClientApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$dqzR.LCCRCS.CommunityReviewApplication, x);
                    }), $zJXook ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":383592,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCS.ICommunityClientApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$dqzR.LCCRC.ServiceRegistrar, Get_ICommunityClientApplication, $eAIThe ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ICommunityClientApplication","d":383592,"h":0,"f":16777250})));
                /*static object*/  function Get_CommunityReviewFeedProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$dqzR.LCCRCS.CommunityReviewFeedProvider().$ctor$2(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$hDPm.LCFCI.IClientUnitOfWork, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientUnitOfWork, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCF.ICommunityMainFeedProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$dqzR.LCCRC.ServiceRegistrar, Get_CommunityReviewFeedProvider, $fnduce ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_CommunityReviewFeedProvider","d":383592,"h":0,"f":16777250})));
                /*static object*/  function Get_CommunityReviewViewProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$dqzR.LCCRCS.CommunityReviewViewProvider().$ctor$1();
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$hDPm.LCFCI.IViewProvider$$($.$dXSd.LCCRCM.CommunityReviewElementModel).$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$dqzR.LCCRC.ServiceRegistrar, Get_CommunityReviewViewProvider, $DPiELj ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_CommunityReviewViewProvider","d":383592,"h":0,"f":16777250})));
                /*static object*/  function Get_CommunityReviewAddOnProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$dqzR.LCCRCS.CommunityReviewAddOnProvider().$ctor$1();
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCS.ICommunityPostAddOnProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$dqzR.LCCRC.ServiceRegistrar, Get_CommunityReviewAddOnProvider, $jXXQkc ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_CommunityReviewAddOnProvider","d":383592,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12885285480)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$dqzR.LCCRC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295350888)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295350888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295350888)
            
            //--TRIMMABLE-BOUNDARY-START(4295350888)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295350888)
            
            static $h = 383592;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590318184),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 383592,
      "h": 8590318184,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590318184),
//--TRIMMABLE-BOUNDARY-START(12885285480),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 383592,
      "h": 12885285480,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885285480)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295350888),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 383592,
      "h": 4295350888,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295350888)
  ],
  "h": 383592
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(383592)
        
        

        //--TRIMMABLE-BOUNDARY-START(449128)
        $asm.$cls(`$dqzR.LCCRCS.CommunityReviewAddOnProvider`, ($self) => class CommunityReviewAddOnProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68719925864)
            /*string */ get Name()
            {
                return "Review";
            }
            //--TRIMMABLE-BOUNDARY-END(68719925864)
            
            //--TRIMMABLE-BOUNDARY-START(73014893160)
            /*string */ get Title()
            {
                return "Reviews";
            }
            //--TRIMMABLE-BOUNDARY-END(73014893160)
            
            //--TRIMMABLE-BOUNDARY-START(17180318312)
            /*string */ get Description()
            {
                return "Add a public review/star ratings to this";
            }
            //--TRIMMABLE-BOUNDARY-END(17180318312)
            
            //--TRIMMABLE-BOUNDARY-START(64424958568)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-star"/*MaterialDesignIconNames.Star*/);
            }
            //--TRIMMABLE-BOUNDARY-END(64424958568)
            
            //--TRIMMABLE-BOUNDARY-START(8590383720)
            /*bool */ CanAddOn(/*IPost*/ post)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590383720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return post.LCFCP$IPost$Identifier.HasValue && !(post !== null && ($.$is(post, $.$dXSd.LCCRCM.CommunityReviewPostModel))) && $.$is(post, $.$LCOv.LCFCP.IPostReviewable);
            }
            //--TRIMMABLE-BOUNDARY-END(8590383720)
            
            //--TRIMMABLE-BOUNDARY-START(12885351016)
            /*ValueTask */ Clicked(/*IPost*/ post)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885351016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12885351016)
            
            //--TRIMMABLE-BOUNDARY-START(60129991272)
            /*RenderFragment */ GetAddOnView(/*IPost*/ parent, /*RenderFragment?*/ bodyPreview, /*CommunityAddOnsFeatures*/ addOnFeatures)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129991272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenComponent$1($.$ahDc.LCCCSA$2.CommunityAddOns$$($.$dXSd.LCCRCM.CommunityReviewPostModel), 1);
                    builder.AddAttribute$5(2, "Title", "Reviews");
                    builder.AddAttribute$4(4, "Parent", $.$cast(parent, $.$LCOv.LCFCPM$1.PostBaseModel));
                    builder.AddAttribute$5(5, "Class", "pdx");
                    builder.AddAttribute$4(6, "Features", $.$box(addOnFeatures, $.$ahDc.LCCCSA$2.CommunityAddOnsFeatures));
                    builder.AddAttribute$3(7, "InitialParentPreview", bodyPreview);
                    builder.CloseComponent();
                }, $BAUclk ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":449128,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(60129991272)
            
            //--TRIMMABLE-BOUNDARY-START(55835023976)
            /*string? */ GetAddOnMetrics(/*IPost*/ post)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835023976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let comments = ($.$cast(post, $.$LCOv.LCFCPM$1.PostBaseModel)).ReviewsCount;
                if ($.$$.S.Int32.op_GreaterThan(comments, 0))
                {
                    /*int?*/ let __ca1__;
                    return _ = ((__ca1__ = comments) !== null ? $.$fPer.LCFCS$6.NumberExtension.FormatScientific$1($.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(__ca1__), "0", false) : null);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(55835023976)
            
            //--TRIMMABLE-BOUNDARY-START(4313093568)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityPostAddOnProvider.CanAddOn(LivingThing.Core.Frameworks.Common.Posts.IPost)
            LCCCS$ICommunityPostAddOnProvider$CanAddOn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313093568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanAddOn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313093568)
            
            //--TRIMMABLE-BOUNDARY-START(8608060864)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityPostAddOnProvider.Clicked(LivingThing.Core.Frameworks.Common.Posts.IPost)
            LCCCS$ICommunityPostAddOnProvider$Clicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8608060864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clicked(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8608060864)
            
            //--TRIMMABLE-BOUNDARY-START(17197995456)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityPostAddOnProvider.GetAddOnView(LivingThing.Core.Frameworks.Common.Posts.IPost, Microsoft.AspNetCore.Components.RenderFragment?, LivingThing.Core.Community.Client.Shared.AddOns.CommunityAddOnsFeatures)
            LCCCS$ICommunityPostAddOnProvider$GetAddOnView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17197995456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAddOnView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17197995456)
            
            //--TRIMMABLE-BOUNDARY-START(12903028160)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityPostAddOnProvider.GetAddOnMetrics(LivingThing.Core.Frameworks.Common.Posts.IPost)
            LCCCS$ICommunityPostAddOnProvider$GetAddOnMetrics()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12903028160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAddOnMetrics(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12903028160)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(4295416424)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295416424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295416424)
            
            //--TRIMMABLE-BOUNDARY-START(4295416424)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295416424)
            
            static $h = 449128;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719925864),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950122088,
        "f": 50331649
      },
      "n": "Name",
      "d": 449128,
      "h": 68719925864,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719925864),
//--TRIMMABLE-BOUNDARY-START(73014893160),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540056680,
        "f": 50331649
      },
      "n": "Title",
      "d": 449128,
      "h": 73014893160,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014893160),
//--TRIMMABLE-BOUNDARY-START(17180318312),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770252904,
        "f": 50331649
      },
      "n": "Description",
      "d": 449128,
      "h": 17180318312,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180318312),
//--TRIMMABLE-BOUNDARY-START(64424958568),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360187496,
        "f": 50331649
      },
      "n": "Icon",
      "d": 449128,
      "h": 64424958568,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424958568)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590383720),
    {
      "r": 262145,
      "p": [
        {
          "n": "post",
          "p": 1173940
        }
      ],
      "n": "CanAddOn",
      "d": 449128,
      "h": 8590383720,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590383720),
//--TRIMMABLE-BOUNDARY-START(12885351016),
    {
      "r": 181338113,
      "p": [
        {
          "n": "post",
          "p": 1173940
        }
      ],
      "n": "Clicked",
      "d": 449128,
      "h": 12885351016,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885351016),
//--TRIMMABLE-BOUNDARY-START(60129991272),
    {
      "r": 6881395,
      "p": [
        {
          "n": "parent",
          "p": 1173940
        },
        {
          "n": "bodyPreview",
          "p": 6881395
        },
        {
          "n": "addOnFeatures",
          "p": 22844864
        }
      ],
      "n": "GetAddOnView",
      "d": 449128,
      "h": 60129991272,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129991272),
//--TRIMMABLE-BOUNDARY-START(55835023976),
    {
      "r": 1310721,
      "p": [
        {
          "n": "post",
          "p": 1173940
        }
      ],
      "n": "GetAddOnMetrics",
      "d": 449128,
      "h": 55835023976,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835023976)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295416424),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 449128,
      "h": 4295416424,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295416424)
  ],
  "h": 449128
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityPostAddOnProvider, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Client.Services.CommunityReviewAddOnProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Client${separator}Services${separator}CommunityReviewAddOnProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(449128)
        
        

        //--TRIMMABLE-BOUNDARY-START(907880)
        $asm.$cls(`$dqzR.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295875176)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295875176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295875176)
            
            //--TRIMMABLE-BOUNDARY-START(4295875176)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295875176)
            
            static $h = 907880;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295875176),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 907880,
      "h": 4295875176,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295875176)
  ],
  "h": 907880
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(907880)
        
        

        //--TRIMMABLE-BOUNDARY-START(973416)
        $asm.$cls(`$dqzR.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295940712)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295940712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295940712)
            
            //--TRIMMABLE-BOUNDARY-START(4295940712)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295940712)
            
            static $h = 973416;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295940712),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 973416,
      "h": 4295940712,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295940712)
  ],
  "h": 973416,
  "a": [
    {
      "t": 907880,
      "c": 4295875176
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(973416)
        
        

        //--TRIMMABLE-BOUNDARY-START(121448)
        $asm.$cls(`$dqzR.LCCRC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590056040)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590056040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590056040)
            
            //--TRIMMABLE-BOUNDARY-START(4295088744)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295088744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295088744)
            
            //--TRIMMABLE-BOUNDARY-START(4295088744)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295088744)
            
            static $h = 121448;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590056040),
    {
      "r": 65537,
      "n": "Execute",
      "d": 121448,
      "h": 8590056040,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590056040)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295088744),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 121448,
      "h": 4295088744,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295088744)
  ],
  "h": 121448
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(121448)
        
        

        //--TRIMMABLE-BOUNDARY-START(711272)
        $asm.$cls(`$dqzR.LCCRCS.CommunityReviewViewProvider`, ($self) => class CommunityReviewViewProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590645864)
            /*RenderFragment? */ GetView(/*ContainerContext<CommunityReviewElementModel>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590645864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.HasAttribute($.$ahDc.LCCCSP.CommunityPostView, new ($.$$.S.Func$$$($.$ahDc.LCCCSP.CommunityPostView, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e === 8/*CommunityPostView.PostOpenedEpilogue*/;
                }, $VkIyfj ??= {"r":262145,"p":[{"n":"e","p":31299008}],"n":"","d":711272,"h":0,"f":17825794})))
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$dqzR.LCCRCS$1.CommunityReviewRatingSummary, $.$dXSd.LCCRCM.CommunityReviewElementModel, value.Data, false, null);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8590645864)
            
            //--TRIMMABLE-BOUNDARY-START(4360984234)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IViewProvider<LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel>.GetView(LivingThing.Core.Frameworks.Client.Interface.ContainerContext<LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel>)
            LCFCI$IViewProvider$LivingThing$Core$Community$Review$Common$Models$CommunityReviewElementModel$GetView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4360984234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4360984234)
            
            //--TRIMMABLE-BOUNDARY-START(4295678568)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295678568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295678568)
            
            //--TRIMMABLE-BOUNDARY-START(4295678568)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295678568)
            
            static $h = 711272;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590645864),
    {
      "r": 6881395,
      "p": [
        {
          "n": "value",
          "p": $.$hDPm.LCFCI.ContainerContext$$($.$dXSd.LCCRCM.CommunityReviewElementModel).$h
        }
      ],
      "n": "GetView",
      "d": 711272,
      "h": 8590645864,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590645864)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295678568),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 711272,
      "h": 4295678568,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295678568)
  ],
  "h": 711272
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCI.IViewProvider$$($.$dXSd.LCCRCM.CommunityReviewElementModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Client.Services.CommunityReviewViewProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Client${separator}Services${separator}CommunityReviewViewProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(711272)
        
        

        //--TRIMMABLE-BOUNDARY-START(842344)
        $asm.$cls(`$dqzR.LCCRCS$1.CommunityReviewRatingSummary`, ($self) => class CommunityReviewRatingSummary extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$dXSd.LCCRCM.CommunityReviewElementModel)
        {
            //--TRIMMABLE-BOUNDARY-START(133144828520)
            /*string[]*/ static ThemeColors = null;
            //--TRIMMABLE-BOUNDARY-END(133144828520)
            
            //--TRIMMABLE-BOUNDARY-START(103080057448)
            /*Dictionary<int, int>?*/ ratings = null;
            //--TRIMMABLE-BOUNDARY-END(103080057448)
            
            //--TRIMMABLE-BOUNDARY-START(77310253672)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(77310253672)
            
            //--TRIMMABLE-BOUNDARY-START(73015286376)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(73015286376)
            
            //--TRIMMABLE-BOUNDARY-START(98785090152)
            /*PropertyChangedEventHandler?*/ PropertyChanged$1 = null;
            //--TRIMMABLE-BOUNDARY-END(98785090152)
            
            //--TRIMMABLE-BOUNDARY-START(98785090152)
            //--TRIMMABLE-BOUNDARY-START(25770646120)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770646120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Combine$2(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(25770646120)
            
            //--TRIMMABLE-BOUNDARY-START(111669992040)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669992040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Remove(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(111669992040)
            
            //--TRIMMABLE-BOUNDARY-END(98785090152)
            
            //--TRIMMABLE-BOUNDARY-START(68720319080)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720319080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t1, $r1;
                        this.ratings = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$dXSd.LCCRCS.IComunityReviewRemoteService, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Int32), this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$dXSd.LCCRCS.IComunityReviewRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Int32))))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server.LCCRCS$IComunityReviewRemoteService$GetRatings(this.ViewModel.Identifier);
                        }, $LNtpLf ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Int32))).$h,"p":[{"n":"server","p":1260819}],"n":"","d":842344,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        this.ratings ??= new ($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$1();
                        for(/*int*/ let i = 0; i <= 5; i++)
                        {
                            if (!this.ratings.ContainsKey(i))
                            {
                                this.ratings.set_Item(i, 0);
                            }
                        }
                    });
                }, $dcWIbi ??= {"r":181338113,"n":"","d":842344,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                {
                    return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                }, $JqgtPb ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":842344,"h":0,"f":17825794}), null, false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(68720319080)
            
            //--TRIMMABLE-BOUNDARY-START(94490122856)
            /*int */ Percentage(/*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490122856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sum = $.$sl.SL.Enumerable.Sum$17($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32), this.ratings, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32), $.$$.S.Int32))().$ctor(this,  (/*r*/ r) =>
                {
                    return r.Value;
                }, $oYIGTi ??= {"r":655361,"p":[{"n":"r","p":$.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32).$h}],"n":"","d":842344,"h":0,"f":17825794}));
                if (sum === 0)
                {
                    return 0;
                }
                return $.trunc(((value * 100) | 0) / sum);
            }
            //--TRIMMABLE-BOUNDARY-END(94490122856)
            
            //--TRIMMABLE-BOUNDARY-START(90195155560)
            /*double */ get Overall()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425351784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sum = $.$sl.SL.Enumerable.Sum$17($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32), this.ratings, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32), $.$$.S.Int32))().$ctor(this,  (/*r*/ r) =>
                {
                    return ((5 * r.Value) | 0);
                }, $iZMsZb ??= {"r":655361,"p":[{"n":"r","p":$.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32).$h}],"n":"","d":842344,"h":0,"f":17825794}));
                if (sum === 0)
                {
                    return 2.5;
                }
                /*var*/ let w = $.$sl.SL.Enumerable.Sum$17($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32), this.ratings, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32), $.$$.S.Int32))().$ctor(this,  (/*r*/ r) =>
                {
                    return ((r.Key * r.Value) | 0);
                }, $rdzNAd ??= {"r":655361,"p":[{"n":"r","p":$.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32).$h}],"n":"","d":842344,"h":0,"f":17825794}));
                return 5 * $.$cast(w, $.$$.S.Double) / $.$cast(sum, $.$$.S.Double);
            }
            //--TRIMMABLE-BOUNDARY-END(90195155560)
            
            //--TRIMMABLE-BOUNDARY-START(81605220968)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605220968);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = this.Load(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(81605220968)
            
            //--TRIMMABLE-BOUNDARY-START(30065613416)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065613416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    if (this.ratings !== null)
                    {
                        __builder2.OpenElement(3, "div");
                        __builder2.AddAttribute$5(4, "class", "container mgt-10 ");
                        __builder2.OpenElement(5, "div");
                        __builder2.AddAttribute$5(6, "class", "bd corner pd bg-card row responsive");
                        __builder2.OpenElement(7, "div");
                        __builder2.AddAttribute$5(8, "class", "miwx-1 col-5");
                        let $en4 = $.$sl.SL.Enumerable.OrderByDescending$1($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32), $.$$.S.Int32, this.ratings, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32), $.$$.S.Int32))().$ctor(this,  (/*d*/ d) =>
                        {
                            return d.Key;
                        }, $AElQEh ??= {"r":655361,"p":[{"n":"d","p":$.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32).$h}],"n":"","d":842344,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                        while ($en4.SC$1$IEnumerator$MoveNext())
                        {
                            let rating = $en4.SCG$IEnumerator$$$Current;
                            {
                                __builder2.OpenElement(9, "div");
                                __builder2.AddAttribute$5(10, "class", "flex mgy-1");
                                __builder2.OpenElement(11, "span");
                                __builder2.AddContent$3(12, $.$box(rating.Key, $.$$.S.Int32));
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(13, "\r\n                            ");
                                __builder2.OpenElement(14, "i");
                                __builder2.AddAttribute$5(15, "class", $.$strNN($.$strNN($.$strNN("mdi" + " mdi-star") + " cl-") + $.$strNN(($.$$.System.Array.$ReadT1.call($.$dqzR.LCCRCS$1.CommunityReviewRatingSummary.ThemeColors, rating.Key)))) + " mgx-1");
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(16, "\r\n                            ");
                                __builder2.OpenElement(17, "div");
                                __builder2.AddAttribute$5(18, "class", "bd progressbar fill bg-gray hx-01 mgy-a corner-5 clip");
                                __builder2.OpenElement(19, "div");
                                __builder2.AddAttribute$5(20, "class", $.$strNN($.$strNN($.$strNN("progress" + " bg-") + $.$strNN(($.$$.System.Array.$ReadT1.call($.$dqzR.LCCRCS$1.CommunityReviewRatingSummary.ThemeColors, rating.Key)))) + " hf") + " ");
                                __builder2.AddAttribute$5(21, "style", $.$strNN("width:" + " " + ($.$box(this.Percentage(rating.Value), $.$$.S.Int32))) + "%;");
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(22, "\r\n                            ");
                                __builder2.OpenElement(23, "small");
                                __builder2.AddAttribute$5(24, "class", "mgl-2 fw-bold mgy-a");
                                __builder2.AddContent$3(25, $.$box(rating.Value, $.$$.S.Int32));
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                            }
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(26, "\r\n                ");
                        __builder2.OpenElement(27, "div");
                        __builder2.AddAttribute$5(28, "class", "col-5 miwx-1 stack");
                        __builder2.AddMarkupContent(29, "<h3 class=\"mg-0\">Overall Ratings</h3>\r\n                    ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCR.Ratings, 30);
                        __builder2.AddComponentParameter(31, "Class", "mgl-a fsz-20");
                        __builder2.AddComponentParameter(32, "Rating", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Double, this.Overall), $.$$.S.Double));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                }), $fjXUJe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":842344,"h":0,"f":17825794}));
                __builder.CloseComponent();
                if (this.ViewModel.ReviewByLocation)
                {
                    __builder.AddMarkupContent(33, "<h3 class=\"mgt-10 mgx\">Service Performance Map</h3>\r\n    ");
                    __builder.OpenElement(34, "div");
                    __builder.AddAttribute$5(35, "class", "hx-3");
                    __builder.OpenComponent$1($.$hDPm.LCFCCM.LeafletMap, 36);
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065613416)
            
            //--TRIMMABLE-BOUNDARY-START(85900188264)
            /*string */ get OptimizedComponentName()
            {
                return "communityreviewratingsummary";
            }
            //--TRIMMABLE-BOUNDARY-END(85900188264)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180711528)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180711528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180711528)
            
            //--TRIMMABLE-BOUNDARY-START(17180711528)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(17180711528)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77310253672)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(77310253672)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12885744232)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885744232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(133144828520)
                    this.ThemeColors = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["fatal", "error", "warning", "info", "primary", "success"], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(133144828520)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885744232)
            
            static $h = 842344;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$dXSd.LCCRCM.CommunityReviewElementModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310253672),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245482600,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849861224,
        "f": 83886081
      },
      "n": "Loading",
      "d": 842344,
      "h": 77310253672,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310253672),
//--TRIMMABLE-BOUNDARY-START(73015286376),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655548008,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259926632,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 842344,
      "h": 73015286376,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015286376),
//--TRIMMABLE-BOUNDARY-START(90195155560),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425351784,
        "f": 50331650
      },
      "n": "Overall",
      "d": 842344,
      "h": 90195155560,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(90195155560),
//--TRIMMABLE-BOUNDARY-START(85900188264),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835417192,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 842344,
      "h": 85900188264,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(85900188264)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720319080),
    {
      "r": 181338113,
      "n": "Load",
      "d": 842344,
      "h": 68720319080,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720319080),
//--TRIMMABLE-BOUNDARY-START(94490122856),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "Percentage",
      "d": 842344,
      "h": 94490122856,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94490122856),
//--TRIMMABLE-BOUNDARY-START(81605220968),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 842344,
      "h": 81605220968,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(81605220968),
//--TRIMMABLE-BOUNDARY-START(30065613416),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 842344,
      "h": 30065613416,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30065613416)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(133144828520),
    {
      "t": $.$typeArray($.$$.S.String).$h,
      "n": "ThemeColors",
      "d": 842344,
      "h": 133144828520,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(133144828520),
//--TRIMMABLE-BOUNDARY-START(103080057448),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Int32).$h,
      "n": "ratings",
      "d": 842344,
      "h": 103080057448,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(103080057448)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180711528),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 842344,
      "h": 17180711528,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180711528)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(98785090152),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 842344,
        "h": 25770646120,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 842344,
        "h": 111669992040,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "o": "@$1",
      "d": 842344,
      "h": 98785090152,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(98785090152)
  ],
  "h": 842344
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Client.Shared.CommunityReviewRatingSummary`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Client${separator}Shared${separator}CommunityReviewRatingSummary`; }
        });
        //--TRIMMABLE-BOUNDARY-END(842344)
        
        

        //--TRIMMABLE-BOUNDARY-START(580200)
        $asm.$cls(`$dqzR.LCCRCS.CommunityReviewFeedProvider`, ($self) => class CommunityReviewFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$dXSd.LCCRCM.CommunityReviewPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295547496)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295547496);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295547496)
            
            //--TRIMMABLE-BOUNDARY-START(8590514792)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityReviewPostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590514792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`created a review`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590514792)
            
            static $h = 580200;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$dXSd.LCCRCM.CommunityReviewPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590514792),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 736531
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 580200,
      "h": 8590514792,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590514792)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295547496),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 580200,
      "h": 4295547496,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295547496)
  ],
  "h": 580200
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Client.Services.CommunityReviewFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Client${separator}Services${separator}CommunityReviewFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(580200)
        
        

        //--TRIMMABLE-BOUNDARY-START(776808)
        $asm.$cls(`$dqzR.LCCRCS$1.CommunityReview`, ($self) => class CommunityReview extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$dXSd.LCCRCM.CommunityReviewPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(21475613288)
            /*string */ get OptimizedComponentName()
            {
                return "communityreview";
            }
            //--TRIMMABLE-BOUNDARY-END(21475613288)
            
            //--TRIMMABLE-BOUNDARY-START(8590711400)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590711400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "row pdx");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "col-a pdt-0 flex");
                __builder.OpenElement(4, "div");
                __builder.AddAttribute$5(5, "class", " hx-05 wx-05 mg-a round clip");
                __builder.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityUserAvatar, 6);
                __builder.AddComponentParameter(7, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IUserAccountModel, this.ViewModel.Account));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(8, "\r\n    ");
                __builder.OpenElement(9, "div");
                __builder.AddAttribute$5(10, "class", "col-10 mgl");
                __builder.OpenElement(11, "div");
                __builder.AddAttribute$5(12, "class", "row pdt-2");
                __builder.OpenElement(13, "div");
                __builder.AddAttribute$5(14, "class", "col-6 ");
                __builder.OpenElement(15, "h4");
                __builder.AddAttribute$5(16, "class", "mg-0");
                __builder.AddContent$4(17, (this.ViewModel.Account?.Title ?? null));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(18, "\r\n            ");
                __builder.AddMarkupContent(19, "<div class=\"col-a\"><div class=\"flex text-right\"></div></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(20, "\r\n        ");
                __builder.OpenElement(21, "p");
                __builder.AddAttribute$5(22, "class", "op-7 mgy-1 lh-1");
                __builder.AddContent$4(23, this.ViewModel.Summary ?? this.ViewModel.Post);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590711400)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295744104)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295744104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295744104)
            
            //--TRIMMABLE-BOUNDARY-START(4295744104)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295744104)
            
            static $h = 776808;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$dXSd.LCCRCM.CommunityReviewPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475613288),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180645992,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 776808,
      "h": 21475613288,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475613288)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590711400),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 776808,
      "h": 8590711400,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590711400)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295744104),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 776808,
      "h": 4295744104,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295744104)
  ],
  "h": 776808
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Client.Shared.CommunityReview`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Client${separator}Shared${separator}CommunityReview`; }
        });
        //--TRIMMABLE-BOUNDARY-END(776808)
        
        

        //--TRIMMABLE-BOUNDARY-START(645736)
        $asm.$cls(`$dqzR.LCCRCS.CommunityReviewService`, ($self) => class CommunityReviewService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$dXSd.LCCRCM.CommunityReviewPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295613032)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295613032);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295613032)
            
            static $h = 645736;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$dXSd.LCCRCM.CommunityReviewPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295613032),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 645736,
      "h": 4295613032,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295613032)
  ],
  "h": 645736
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$dXSd.LCCRCM.CommunityReviewPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$dXSd.LCCRCM.CommunityReviewPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Client.Services.CommunityReviewService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Client${separator}Services${separator}CommunityReviewService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(645736)
        
        

        //--TRIMMABLE-BOUNDARY-START(514664)
        $asm.$cls(`$dqzR.LCCRCS.CommunityReviewApplication`, ($self) => class CommunityReviewApplication extends $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel, $.$dXSd.LCCRCM.CommunityReviewPostModel, $.$dXSd.LCCRCM.CommunityReviewUserPreference, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(12885416552)
            $ctor$3(/*CommunityReviewService*/ service)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885416552);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885416552)
            
            //--TRIMMABLE-BOUNDARY-START(137439468136)
            /*string */ get Name()
            {
                return "Review";
            }
            //--TRIMMABLE-BOUNDARY-END(137439468136)
            
            //--TRIMMABLE-BOUNDARY-START(158914304616)
            /*string */ get Title()
            {
                return "Review";
            }
            //--TRIMMABLE-BOUNDARY-END(158914304616)
            
            //--TRIMMABLE-BOUNDARY-START(21475351144)
            /*string */ get Description()
            {
                return "Share your experiences to help others make better choices and encourage product/service providers to do better. In Review, an Element, as we call it is something that can be reviewed or fedback; a company, a product, a service, a website, an app and whatnots.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475351144)
            
            //--TRIMMABLE-BOUNDARY-START(133144500840)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-star"/*MaterialDesignIconNames.Star*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144500840)
            
            //--TRIMMABLE-BOUNDARY-START(154619337320)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#1EAEFE";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619337320)
            
            //--TRIMMABLE-BOUNDARY-START(30065285736)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/ | 4/*ApplicationServiceFeatures.Recommended*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065285736)
            
            //--TRIMMABLE-BOUNDARY-START(17180383848)
            /*Type? */ get ApplicationViewType()
            {
                return $.$dqzR.LCCRCP.CommunityReviewApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180383848)
            
            //--TRIMMABLE-BOUNDARY-START(128849533544)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849533544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$dqzR.LCCRCP.CommunityReviewApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849533544)
            
            //--TRIMMABLE-BOUNDARY-START(25770318440)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770318440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770318440)
            
            //--TRIMMABLE-BOUNDARY-START(146029402728)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029402728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029402728)
            
            //--TRIMMABLE-BOUNDARY-START(141734435432)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734435432)
            
            //--TRIMMABLE-BOUNDARY-START(4295481960)
            /*CommunityReviewService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295481960)
            
            //--TRIMMABLE-BOUNDARY-START(150324370024)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(150324370024)
            
            //--TRIMMABLE-BOUNDARY-START(163209271912)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(7424/*PostTypes.Review*/, 7428/*PostTypes.ReviewEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209271912)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 514664;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel, $.$dXSd.LCCRCM.CommunityReviewPostModel, $.$dXSd.LCCRCM.CommunityReviewUserPreference, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439468136),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604893288,
        "f": 50364417
      },
      "n": "Name",
      "d": 514664,
      "h": 137439468136,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439468136),
//--TRIMMABLE-BOUNDARY-START(158914304616),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964631656,
        "f": 50364417
      },
      "n": "Title",
      "d": 514664,
      "h": 158914304616,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914304616),
//--TRIMMABLE-BOUNDARY-START(21475351144),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835089512,
        "f": 50364417
      },
      "n": "Description",
      "d": 514664,
      "h": 21475351144,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475351144),
//--TRIMMABLE-BOUNDARY-START(133144500840),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014958696,
        "f": 50364417
      },
      "n": "Icon",
      "d": 514664,
      "h": 133144500840,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144500840),
//--TRIMMABLE-BOUNDARY-START(154619337320),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374697064,
        "f": 50364417
      },
      "n": "Theme",
      "d": 514664,
      "h": 154619337320,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619337320),
//--TRIMMABLE-BOUNDARY-START(30065285736),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425024104,
        "f": 50364417
      },
      "n": "Features",
      "d": 514664,
      "h": 30065285736,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065285736),
//--TRIMMABLE-BOUNDARY-START(17180383848),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245154920,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 514664,
      "h": 17180383848,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180383848),
//--TRIMMABLE-BOUNDARY-START(141734435432),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194827880,
        "f": 50364417
      },
      "n": "Order",
      "d": 514664,
      "h": 141734435432,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734435432),
//--TRIMMABLE-BOUNDARY-START(4295481960),
    {
      "p": 645736,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655220328,
        "f": 50331650
      },
      "n": "_Service",
      "d": 514664,
      "h": 4295481960,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295481960),
//--TRIMMABLE-BOUNDARY-START(150324370024),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784762472,
        "f": 50364417
      },
      "n": "Service",
      "d": 514664,
      "h": 150324370024,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324370024),
//--TRIMMABLE-BOUNDARY-START(163209271912),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554566248,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 514664,
      "h": 163209271912,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209271912)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849533544),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 514664,
      "h": 128849533544,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849533544),
//--TRIMMABLE-BOUNDARY-START(25770318440),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 514664,
      "h": 25770318440,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770318440),
//--TRIMMABLE-BOUNDARY-START(146029402728),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 514664,
      "h": 146029402728,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029402728)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885416552),
    {
      "p": [
        {
          "n": "service",
          "p": 645736
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 514664,
      "h": 12885416552,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885416552)
  ],
  "h": 514664
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel, $.$dXSd.LCCRCM.CommunityReviewPostModel, $.$dXSd.LCCRCM.CommunityReviewUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$dXSd.LCCRCM.CommunityReviewElementModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Client.Services.CommunityReviewApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Client${separator}Services${separator}CommunityReviewApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(514664)
        
        

        //--TRIMMABLE-BOUNDARY-START(318056)
        $asm.$cls(`$dqzR.LCCRCP.CommunityReviewApp`, ($self) => class CommunityReviewApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel, $.$dXSd.LCCRCM.CommunityReviewPostModel, $.$dXSd.LCCRCM.CommunityReviewUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(128849336936)
            /*string */ get OptimizedComponentName()
            {
                return "communityreviewapp communitydefaultpages";
            }
            //--TRIMMABLE-BOUNDARY-END(128849336936)
            
            //--TRIMMABLE-BOUNDARY-START(120259402344)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259402344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.CommunityReviewService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$dqzR.LCCRCS.CommunityReviewService, serviceProvider);
                this.CommunityReviewApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$dqzR.LCCRCS.CommunityReviewApplication, serviceProvider);
                this.Rendering$1 = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IUIRenderingProvider, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(120259402344)
            
            //--TRIMMABLE-BOUNDARY-START(47244958312)
            /*CommunityReviewService*/ CommunityReviewService = null;
            //--TRIMMABLE-BOUNDARY-END(47244958312)
            
            //--TRIMMABLE-BOUNDARY-START(42949991016)
            /*CommunityReviewApplication*/ CommunityReviewApplication = null;
            //--TRIMMABLE-BOUNDARY-END(42949991016)
            
            //--TRIMMABLE-BOUNDARY-START(133144304232)
            /*IUIRenderingProvider*/ Rendering$1 = null;
            //--TRIMMABLE-BOUNDARY-END(133144304232)
            
            //--TRIMMABLE-BOUNDARY-START(21475154536)
            /*ICommunityClientApplication */ get Application()
            {
                return this.CommunityReviewApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(21475154536)
            
            //--TRIMMABLE-BOUNDARY-START(34360056424)
            /*CommunityPostView */ get CardView()
            {
                return 3/*CommunityPostView.CardFeed*/;
            }
            //--TRIMMABLE-BOUNDARY-END(34360056424)
            
            //--TRIMMABLE-BOUNDARY-START(38655023720)
            /*int? */ get CardWidthHint()
            {
                return 250;
            }
            //--TRIMMABLE-BOUNDARY-END(38655023720)
            
            //--TRIMMABLE-BOUNDARY-START(30065089128)
            /*int? */ get CardSpaceHint()
            {
                return 20;
            }
            //--TRIMMABLE-BOUNDARY-END(30065089128)
            
            //--TRIMMABLE-BOUNDARY-START(124554369640)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554369640);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Service.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(124554369640)
            
            //--TRIMMABLE-BOUNDARY-START(25770121832)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770121832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
            }
            //--TRIMMABLE-BOUNDARY-END(25770121832)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180187240)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180187240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180187240)
            
            //--TRIMMABLE-BOUNDARY-START(17180187240)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(17180187240)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(47244958312)
                this.CommunityReviewService = null;
                //--TRIMMABLE-BOUNDARY-END(47244958312)
                
                //--TRIMMABLE-BOUNDARY-START(42949991016)
                this.CommunityReviewApplication = null;
                //--TRIMMABLE-BOUNDARY-END(42949991016)
                
                //--TRIMMABLE-BOUNDARY-START(133144304232)
                this.Rendering$1 = null;
                //--TRIMMABLE-BOUNDARY-END(133144304232)
                
            }
            static $h = 318056;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel, $.$dXSd.LCCRCM.CommunityReviewPostModel, $.$dXSd.LCCRCM.CommunityReviewUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(128849336936),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374500456,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 318056,
      "h": 128849336936,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128849336936),
//--TRIMMABLE-BOUNDARY-START(47244958312),
    {
      "p": 645736,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784565864,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324173416,
        "f": 83886081
      },
      "n": "CommunityReviewService",
      "d": 318056,
      "h": 47244958312,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47244958312),
//--TRIMMABLE-BOUNDARY-START(42949991016),
    {
      "p": 514664,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194631272,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734238824,
        "f": 83886081
      },
      "n": "CommunityReviewApplication",
      "d": 318056,
      "h": 42949991016,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42949991016),
//--TRIMMABLE-BOUNDARY-START(133144304232),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964435048,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914108008,
        "f": 83886081
      },
      "n": "Rendering",
      "o": "@$1",
      "d": 318056,
      "h": 133144304232,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133144304232),
//--TRIMMABLE-BOUNDARY-START(21475154536),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834892904,
        "f": 50364420
      },
      "n": "Application",
      "d": 318056,
      "h": 21475154536,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(21475154536),
//--TRIMMABLE-BOUNDARY-START(34360056424),
    {
      "p": 31299008,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014762088,
        "f": 50364420
      },
      "n": "CardView",
      "d": 318056,
      "h": 34360056424,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(34360056424),
//--TRIMMABLE-BOUNDARY-START(38655023720),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604696680,
        "f": 50364420
      },
      "n": "CardWidthHint",
      "d": 318056,
      "h": 38655023720,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(38655023720),
//--TRIMMABLE-BOUNDARY-START(30065089128),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424827496,
        "f": 50364420
      },
      "n": "CardSpaceHint",
      "d": 318056,
      "h": 30065089128,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(30065089128)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(120259402344),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 318056,
      "h": 120259402344,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120259402344),
//--TRIMMABLE-BOUNDARY-START(124554369640),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 318056,
      "h": 124554369640,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(124554369640),
//--TRIMMABLE-BOUNDARY-START(25770121832),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 318056,
      "h": 25770121832,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770121832)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180187240),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 318056,
      "h": 17180187240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180187240)
  ],
  "h": 318056
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Client.Pages.CommunityReviewApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Client${separator}Pages${separator}CommunityReviewApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(318056)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Review.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(55912)
