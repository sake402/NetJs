
//--TRIMMABLE-BOUNDARY-START(15635)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $BKdKkb;
    let $ucbtse;
    let $TypMUg;
    let $aNaJGa;
    let $rbHWac;
    let $JKkVPf;
    let $WIHBAj;
    let $eZkLng;
    let $HptCXd;
    let $lFiylc;
    let $MerrQg;
    let $Ihgvod;
    let $BtUEUd;
    let $qEVdtb;
    let $EsxKta;
    let $wjDfwb;
    let $zJcSKe;
    let $emsReh;
    let $HauJTb;
    let $pcshGb;
    let $EGFxuh;
    let $haQsgh;
    let $ARMaGc;
    let $kJQGYd;
    let $QWWDLk;
    let $qxFSef;
    let $hHcqld;
    let $uOhXfi;
    let $uVCAze;
    let $Twyaye;
    let $LHMHFb;
    let $FyNXTj;
    let $XcOARj;
    let $QDaJPj;
    let $xtqNEh;
    let $JghMKb;
    let $BdBNNa;
    let $PVCpdf;
    let $SeeBDe;
    let $eInxpf;
    let $mCZTTf;
    let $HyMvOa;
    let $PJwzDi;
    let $CAgRDc;
    let $AaUIxd;
    let $DhpEqi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Review.Common", 
    {
  "h": 15635,
  "f": "LivingThing.Core.Community.Review.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Review.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Review.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1260819)
        $asm.$cls(`$dXSd.LCCRCS.IComunityReviewRemoteService`, ($self) => class IComunityReviewRemoteService
        {
            static $h = 1260819;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296228115),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Int32))).$h,
      "p": [
        {
          "n": "targetId",
          "p": 10455382
        }
      ],
      "n": "GetRatings",
      "o": "LCCRCS$IComunityReviewRemoteService$GetRatings",
      "d": 1260819,
      "h": 4296228115,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296228115)
  ],
  "h": 1260819,
  "a": [
    {
      "t": 3537875,
      "c": 8593472467,
      "a": [
        {
          "v": [$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$h,$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$dXSd.LCCRCM.CommunityReviewElementModel).$h,$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$dXSd.LCCRCM.CommunityReviewPostModel).$h
          ],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Services.IComunityReviewRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Services${separator}IComunityReviewRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1260819)
        
        

        //--TRIMMABLE-BOUNDARY-START(81171)
        $asm.$cls(`$dXSd.LCCRC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295048467)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295048467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dXSd.LCCRCM.CommunityReviewCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dXSd.LCCRCM.CommunityReviewCategoryModelCustomAttributesProvider, $.$dXSd.LCCRCM.CommunityReviewCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dXSd.LCCRCM.CommunityReviewElementModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dXSd.LCCRCM.CommunityReviewElementModelCustomAttributesProvider, $.$dXSd.LCCRCM.CommunityReviewElementModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dXSd.LCCRCM.CommunityReviewPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dXSd.LCCRCM.CommunityReviewPostModelCustomAttributesProvider, $.$dXSd.LCCRCM.CommunityReviewPostModelCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295048467)
            
            static $h = 81171;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295048467),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 81171,
      "h": 4295048467,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295048467)
  ],
  "h": 81171
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(81171)
        
        

        //--TRIMMABLE-BOUNDARY-START(277779)
        $asm.$cls(`$dXSd.LCCRCM.CommunityReviewCategoryModelCustomAttributesProvider`, ($self) => class CommunityReviewCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295245075)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295245075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295245075)
            
            static $h = 277779;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295245075),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 277779,
      "h": 4295245075,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295245075)
  ],
  "h": 277779
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Models${separator}CommunityReviewCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(277779)
        
        

        //--TRIMMABLE-BOUNDARY-START(1391891)
        $asm.$cls(`$dXSd.LCCRC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296359187)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296359187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$dXSd.LCCRCM.CommunityReviewCategoryModelTypeDescriptorBuilder.Register();
                $.$dXSd.LCCRCM.CommunityReviewElementModelTypeDescriptorBuilder.Register();
                $.$dXSd.LCCRCM.CommunityReviewPostModelTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296359187)
            
            static $h = 1391891;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296359187),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1391891,
      "h": 4296359187,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296359187)
  ],
  "h": 1391891
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1391891)
        
        

        //--TRIMMABLE-BOUNDARY-START(802067)
        $asm.$cls(`$dXSd.LCCRCM.CommunityReviewPostModelCustomAttributesProvider`, ($self) => class CommunityReviewPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295769363)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295769363)
            
            //--TRIMMABLE-BOUNDARY-START(8590736659)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590736659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dXSd.LCCRCM.CommunityReviewPostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("ParentLink", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CanAddOn", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("AddOnParent", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("AddOnActivityDescription", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dXSd.LCCRCM.CommunityReviewPostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $ucbtse ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":802067,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $TypMUg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":802067,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590736659)
            
            static $h = 802067;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590736659),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 802067,
      "h": 8590736659,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590736659)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295769363),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 802067,
      "h": 4295769363,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295769363)
  ],
  "h": 802067
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Models${separator}CommunityReviewPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(802067)
        
        

        //--TRIMMABLE-BOUNDARY-START(539923)
        $asm.$cls(`$dXSd.LCCRCM.CommunityReviewElementModelCustomAttributesProvider`, ($self) => class CommunityReviewElementModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295507219)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295507219)
            
            //--TRIMMABLE-BOUNDARY-START(8590474515)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590474515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dXSd.LCCRCM.CommunityReviewElementModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("ReviewByLocation", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1024);
                            $i3.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i3.Description = "Enabling this means each user review is localized to their environment and they will be asked to choose the location of their experience";
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-map-marker"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dXSd.LCCRCM.CommunityReviewElementModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $aNaJGa ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":539923,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $rbHWac ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":539923,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590474515)
            
            static $h = 539923;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590474515),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 539923,
      "h": 8590474515,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590474515)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295507219),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 539923,
      "h": 4295507219,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295507219)
  ],
  "h": 539923
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Models${separator}CommunityReviewElementModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(539923)
        
        

        //--TRIMMABLE-BOUNDARY-START(146707)
        $asm.$cls(`$dXSd.LCCRC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295114003)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295114003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$dXSd.LCCRCS.ICommunityReviewFeedRemoteService, $.$dXSd.LCCRCS.ICommunityReviewFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCCRCS.ICommunityReviewFeedRemoteService_Mocking().$ctor$3(impl);
                }, $JKkVPf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$dXSd.LCCRCS.ICommunityReviewFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$dXSd.LCCRCS.ICommunityReviewFeedRemoteService_Mocking().$ctor$3(impl);
                }, $WIHBAj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$dXSd.LCCRCS.IComunityReviewRemoteService, $.$dXSd.LCCRCS.IComunityReviewRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCCRCS.IComunityReviewRemoteService_Mocking().$ctor$3(impl);
                }, $eZkLng ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking().$ctor$3(impl);
                }, $HptCXd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking().$ctor$3(impl);
                }, $lFiylc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking().$ctor$3(impl);
                }, $MerrQg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking().$ctor$3(impl);
                }, $Ihgvod ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking().$ctor$3(impl);
                }, $BtUEUd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking().$ctor$3(impl);
                }, $qEVdtb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking().$ctor$3(impl);
                }, $EsxKta ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking().$ctor$3(impl);
                }, $wjDfwb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking().$ctor$3(impl);
                }, $zJcSKe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking().$ctor$3(impl);
                }, $emsReh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking().$ctor$3(impl);
                }, $HauJTb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking().$ctor$3(impl);
                }, $pcshGb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking().$ctor$3(impl);
                }, $EGFxuh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking().$ctor$3(impl);
                }, $haQsgh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking().$ctor$3(impl);
                }, $ARMaGc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking().$ctor$3(impl);
                }, $kJQGYd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking().$ctor$3(impl);
                }, $QWWDLk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking().$ctor$3(impl);
                }, $qxFSef ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking().$ctor$3(impl);
                }, $hHcqld ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking().$ctor$3(impl);
                }, $uOhXfi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking().$ctor$3(impl);
                }, $uVCAze ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":146707,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295114003)
            
            static $h = 146707;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295114003),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 146707,
      "h": 4295114003,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295114003)
  ],
  "h": 146707
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(146707)
        
        

        //--TRIMMABLE-BOUNDARY-START(408851)
        $asm.$cls(`$dXSd.LCCRCM.CommunityReviewCategoryModelTypeDescriptorBuilder`, ($self) => class CommunityReviewCategoryModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590343443)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590343443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dXSd.LCCRCM.CommunityReviewCategoryModelTypeDescriptor()
                        const $t1 = $.$dXSd.LCCRCM.CommunityReviewCategoryModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Twyaye ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":408851,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dXSd.LCCRCM.CommunityReviewCategoryModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590343443)
            
            //--TRIMMABLE-BOUNDARY-START(4295376147)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295376147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295376147)
            
            //--TRIMMABLE-BOUNDARY-START(4295376147)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295376147)
            
            static $h = 408851;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590343443),
    {
      "r": 65537,
      "n": "Register",
      "d": 408851,
      "h": 8590343443,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590343443)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295376147),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 408851,
      "h": 4295376147,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295376147)
  ],
  "h": 408851
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Models${separator}CommunityReviewCategoryModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(408851)
        
        

        //--TRIMMABLE-BOUNDARY-START(670995)
        $asm.$cls(`$dXSd.LCCRCM.CommunityReviewElementModelTypeDescriptorBuilder`, ($self) => class CommunityReviewElementModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590605587)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590605587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dXSd.LCCRCM.CommunityReviewElementModelTypeDescriptor()
                        const $t1 = $.$dXSd.LCCRCM.CommunityReviewElementModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XcOARj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":670995,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dXSd.LCCRCM.CommunityReviewElementModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590605587)
            
            //--TRIMMABLE-BOUNDARY-START(4295638291)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295638291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295638291)
            
            //--TRIMMABLE-BOUNDARY-START(4295638291)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295638291)
            
            static $h = 670995;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590605587),
    {
      "r": 65537,
      "n": "Register",
      "d": 670995,
      "h": 8590605587,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590605587)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295638291),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 670995,
      "h": 4295638291,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295638291)
  ],
  "h": 670995
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Models${separator}CommunityReviewElementModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(670995)
        
        

        //--TRIMMABLE-BOUNDARY-START(933139)
        $asm.$cls(`$dXSd.LCCRCM.CommunityReviewPostModelTypeDescriptorBuilder`, ($self) => class CommunityReviewPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590867731)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590867731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dXSd.LCCRCM.CommunityReviewPostModelTypeDescriptor()
                        const $t1 = $.$dXSd.LCCRCM.CommunityReviewPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $SeeBDe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":933139,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dXSd.LCCRCM.CommunityReviewPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590867731)
            
            //--TRIMMABLE-BOUNDARY-START(4295900435)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295900435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295900435)
            
            //--TRIMMABLE-BOUNDARY-START(4295900435)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295900435)
            
            static $h = 933139;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590867731),
    {
      "r": 65537,
      "n": "Register",
      "d": 933139,
      "h": 8590867731,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590867731)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295900435),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 933139,
      "h": 4295900435,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295900435)
  ],
  "h": 933139
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Models${separator}CommunityReviewPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(933139)
        
        

        //--TRIMMABLE-BOUNDARY-START(1064211)
        $asm.$cls(`$dXSd.LCCRC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885966099)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885966099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_RemoteSchemaOptionReader_CommunityReviewCategoryModel_(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new ($.$uvJL.LCFCR.RemoteSchemaOptionReader$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel))().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$uvJL.LCFCR.IServerRemoteService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$fPer.LCFCS$5.IDataCacheStorageService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFCS$5.IDataCacheStorageService, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$meo.MEO.IOptions$$($.$uvJL.LCFCR.RemoteSchemaReaderOption$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel)), provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$meo.MEO.IOptions$$($.$uvJL.LCFCR.RemoteSchemaReaderOption$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel)), provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$fPer.LCFCA$1.ISchemaOptionReader$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$dXSd.LCCRC.ServiceRegistrar, Get_RemoteSchemaOptionReader_CommunityReviewCategoryModel_, $BKdKkb ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_RemoteSchemaOptionReader_CommunityReviewCategoryModel_","d":1064211,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12885966099)
            
            //--TRIMMABLE-BOUNDARY-START(8590998803)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590998803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$dXSd.LCCRC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$dXSd.LCCRCM.CommunityReviewPostModel, 7427/*PostTypes.ReviewPost*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$dXSd.LCCRCM.CommunityReviewElementModel, 7425/*PostTypes.ReviewElement*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$dXSd.LCCRCM.CommunityReviewCategoryModel, 7426/*PostTypes.ReviewCategory*/);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFCA$1.ISchemaOptionReader$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$uvJL.LCFCR.RemoteSchemaOptionReader$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), services);
                $.$dXSd.LCCRC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$dXSd.LCCRC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$dXSd.LCCRC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590998803)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$dXSd.LCCRC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296031507)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296031507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296031507)
            
            //--TRIMMABLE-BOUNDARY-START(4296031507)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296031507)
            
            static $h = 1064211;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885966099),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 1064211,
      "h": 12885966099,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885966099),
//--TRIMMABLE-BOUNDARY-START(8590998803),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1064211,
      "h": 8590998803,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590998803)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296031507),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1064211,
      "h": 4296031507,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296031507)
  ],
  "h": 1064211
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1064211)
        
        

        //--TRIMMABLE-BOUNDARY-START(1326355)
        $asm.$cls(`$dXSd.LCCRCS.IComunityReviewRemoteService_Mocking`, ($self) => class IComunityReviewRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296293651)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296293651);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296293651)
            
            //--TRIMMABLE-BOUNDARY-START(8591260947)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<System.Collections.Generic.Dictionary<int, int>>> */ LCCRCS$IComunityReviewRemoteService$GetRatings(/*LivingThing.Core.Frameworks.Common.Data.DataId*/ targetId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591260947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$dXSd.LCCRCS.IComunityReviewRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Int32)).$type;
                    $i1.MethodName = "GetRatings";
                    return $i1;
                })();
                return this.InvokeAsync($.$dXSd.LCCRCS.IComunityReviewRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Int32)), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(targetId)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591260947)
            
            static $h = 1326355;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296293651),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1326355,
      "h": 4296293651,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296293651)
  ],
  "h": 1326355
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$dXSd.LCCRCS.IComunityReviewRemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Services.IComunityReviewRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Services${separator}IComunityReviewRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1326355)
        
        

        //--TRIMMABLE-BOUNDARY-START(998675)
        $asm.$cls(`$dXSd.LCCRCM.CommunityReviewUserPreference`, ($self) => class CommunityReviewUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4295965971)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295965971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295965971)
            
            //--TRIMMABLE-BOUNDARY-START(4295965971)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295965971)
            
            static $h = 998675;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295965971),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 998675,
      "h": 4295965971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295965971)
  ],
  "h": 998675
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Models.CommunityReviewUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Models${separator}CommunityReviewUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(998675)
        
        

        $asm.$typeProxy("$dXSd.LCCRCM.CommunityReviewCategoryModel", "$dXSd.LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel");
        //--TRIMMABLE-BOUNDARY-START(474387)
        $asm.$cls(`$dXSd.LCCRCM.CommunityReviewElementModel`, ($self) => class CommunityReviewElementModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $self)
        {
            //--TRIMMABLE-BOUNDARY-START(98784722195)
            /*PostTypes */ get Type()
            {
                return this.SetType ?? 7425/*PostTypes.ReviewElement*/;
            }
            //--TRIMMABLE-BOUNDARY-END(98784722195)
            
            //--TRIMMABLE-BOUNDARY-START(85899820307)
            /*bool */ ShouldEditName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899820307);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899820307)
            
            //--TRIMMABLE-BOUNDARY-START(55835049235)
            /*bool */ RequiresName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835049235);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835049235)
            
            //--TRIMMABLE-BOUNDARY-START(94489754899)
            /*bool */ ShouldEditSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489754899);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489754899)
            
            //--TRIMMABLE-BOUNDARY-START(64424983827)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424983827);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424983827)
            
            //--TRIMMABLE-BOUNDARY-START(90194787603)
            /*bool */ ShouldEditPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194787603);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194787603)
            
            //--TRIMMABLE-BOUNDARY-START(60130016531)
            /*bool */ RequiresPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130016531);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130016531)
            
            //--TRIMMABLE-BOUNDARY-START(81604853011)
            /*bool */ ShouldEditIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604853011);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604853011)
            
            //--TRIMMABLE-BOUNDARY-START(51540081939)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540081939);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540081939)
            
            //--TRIMMABLE-BOUNDARY-START(34360212755)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$1(this, $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "Review", "Post" ], null, null), null, true, true);
            }
            //--TRIMMABLE-BOUNDARY-END(34360212755)
            
            //--TRIMMABLE-BOUNDARY-START(68719951123)
            /*bool */ get ReviewByLocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475310867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Boolean, false, "ReviewByLocation", null);
            }
            /*bool */ set ReviewByLocation(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309885715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Boolean, value, "ReviewByLocation");
            }
            //--TRIMMABLE-BOUNDARY-END(68719951123)
            
            //--TRIMMABLE-BOUNDARY-START(47245114643)
            /*bool */ get LCFCP$IPostLocationBasedReviewable$IsReviewLocationBased()
            {
                return this.ReviewByLocation;
            }
            //--TRIMMABLE-BOUNDARY-END(47245114643)
            
            //--TRIMMABLE-BOUNDARY-START(8592878004)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostRatable.Ratings.get
            get LCFCP$IPostRatable$Ratings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887845300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Ratings;
            }
            //--TRIMMABLE-BOUNDARY-END(8592878004)
            
            //--TRIMMABLE-BOUNDARY-START(21477779892)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostRatable.Ratings.set
            set LCFCP$IPostRatable$Ratings(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887845300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Ratings = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21477779892)
            
            //--TRIMMABLE-BOUNDARY-START(4295441683)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295441683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295441683)
            
            //--TRIMMABLE-BOUNDARY-START(4295441683)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295441683)
            
            static $h = 474387;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98784722195),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065245459,
        "f": 50364417
      },
      "n": "Type",
      "d": 474387,
      "h": 98784722195,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98784722195),
//--TRIMMABLE-BOUNDARY-START(34360212755),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885376275,
        "f": 50364417
      },
      "n": "Link",
      "d": 474387,
      "h": 34360212755,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360212755),
//--TRIMMABLE-BOUNDARY-START(68719951123),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475310867,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309885715,
        "f": 83886081
      },
      "n": "ReviewByLocation",
      "d": 474387,
      "h": 68719951123,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1024,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Description",
              "v": "Enabling this means each user review is localized to their environment and they will be asked to choose the location of their experience",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-map-marker"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719951123),
//--TRIMMABLE-BOUNDARY-START(47245114643),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950147347,
        "f": 50331650
      },
      "n": "{1960372}.IsReviewLocationBased",
      "o": "LCFCP$IPostLocationBasedReviewable$IsReviewLocationBased",
      "d": 474387,
      "h": 47245114643,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47245114643)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85899820307),
    {
      "r": 262145,
      "n": "ShouldEditName",
      "d": 474387,
      "h": 85899820307,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85899820307),
//--TRIMMABLE-BOUNDARY-START(55835049235),
    {
      "r": 262145,
      "n": "RequiresName",
      "d": 474387,
      "h": 55835049235,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835049235),
//--TRIMMABLE-BOUNDARY-START(94489754899),
    {
      "r": 262145,
      "n": "ShouldEditSummary",
      "d": 474387,
      "h": 94489754899,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489754899),
//--TRIMMABLE-BOUNDARY-START(64424983827),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 474387,
      "h": 64424983827,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64424983827),
//--TRIMMABLE-BOUNDARY-START(90194787603),
    {
      "r": 262145,
      "n": "ShouldEditPost",
      "d": 474387,
      "h": 90194787603,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90194787603),
//--TRIMMABLE-BOUNDARY-START(60130016531),
    {
      "r": 262145,
      "n": "RequiresPost",
      "d": 474387,
      "h": 60130016531,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130016531),
//--TRIMMABLE-BOUNDARY-START(81604853011),
    {
      "r": 262145,
      "n": "ShouldEditIcon",
      "d": 474387,
      "h": 81604853011,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604853011),
//--TRIMMABLE-BOUNDARY-START(51540081939),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 474387,
      "h": 51540081939,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540081939)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295441683),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 474387,
      "h": 4295441683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295441683)
  ],
  "h": 474387
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostLocationBasedReviewable, $.$LCOv.LCFCP.IPostReviewable, $.$LCOv.LCFCP.IPostRatable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Models${separator}CommunityReviewElementModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(474387)
        
        

        //--TRIMMABLE-BOUNDARY-START(212243)
        $asm.$cls(`$dXSd.LCCRCM.CommunityReviewCategoryModel`, ($self) => class CommunityReviewCategoryModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$dXSd.LCCRCM.CommunityReviewElementModel)
        {
            //--TRIMMABLE-BOUNDARY-START(47244852499)
            /*PostTypes */ get Type()
            {
                return this.SetType ?? 7426/*PostTypes.ReviewCategory*/;
            }
            //--TRIMMABLE-BOUNDARY-END(47244852499)
            
            //--TRIMMABLE-BOUNDARY-START(42949885203)
            /*bool */ ShouldEditSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949885203);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949885203)
            
            //--TRIMMABLE-BOUNDARY-START(25770016019)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770016019);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770016019)
            
            //--TRIMMABLE-BOUNDARY-START(34359950611)
            /*bool */ ShouldEditIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359950611);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359950611)
            
            //--TRIMMABLE-BOUNDARY-START(17180081427)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180081427);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180081427)
            
            //--TRIMMABLE-BOUNDARY-START(38654917907)
            /*bool */ ShouldEditPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654917907);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654917907)
            
            //--TRIMMABLE-BOUNDARY-START(21475048723)
            /*bool */ RequiresPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475048723);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475048723)
            
            //--TRIMMABLE-BOUNDARY-START(30064983315)
            /*bool */ ShouldEditFlags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064983315);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064983315)
            
            //--TRIMMABLE-BOUNDARY-START(4295179539)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295179539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295179539)
            
            //--TRIMMABLE-BOUNDARY-START(4295179539)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295179539)
            
            static $h = 212243;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47244852499),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885114131,
        "f": 50364417
      },
      "n": "Type",
      "d": 212243,
      "h": 47244852499,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47244852499)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42949885203),
    {
      "r": 262145,
      "n": "ShouldEditSummary",
      "d": 212243,
      "h": 42949885203,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42949885203),
//--TRIMMABLE-BOUNDARY-START(25770016019),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 212243,
      "h": 25770016019,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770016019),
//--TRIMMABLE-BOUNDARY-START(34359950611),
    {
      "r": 262145,
      "n": "ShouldEditIcon",
      "d": 212243,
      "h": 34359950611,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34359950611),
//--TRIMMABLE-BOUNDARY-START(17180081427),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 212243,
      "h": 17180081427,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180081427),
//--TRIMMABLE-BOUNDARY-START(38654917907),
    {
      "r": 262145,
      "n": "ShouldEditPost",
      "d": 212243,
      "h": 38654917907,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38654917907),
//--TRIMMABLE-BOUNDARY-START(21475048723),
    {
      "r": 262145,
      "n": "RequiresPost",
      "d": 212243,
      "h": 21475048723,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475048723),
//--TRIMMABLE-BOUNDARY-START(30064983315),
    {
      "r": 262145,
      "n": "ShouldEditFlags",
      "d": 212243,
      "h": 30064983315,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30064983315)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295179539),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 212243,
      "h": 4295179539,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295179539)
  ],
  "h": 212243
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostByAdminOnly ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Models${separator}CommunityReviewCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(212243)
        
        

        //--TRIMMABLE-BOUNDARY-START(736531)
        $asm.$cls(`$dXSd.LCCRCM.CommunityReviewPostModel`, ($self) => class CommunityReviewPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8590671123)
            $ctor$6()
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590671123);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590671123)
            
            //--TRIMMABLE-BOUNDARY-START(120259820819)
            /*PostTypes */ get Type()
            {
                return this.SetType ?? 7427/*PostTypes.ReviewPost*/;
            }
            //--TRIMMABLE-BOUNDARY-END(120259820819)
            
            //--TRIMMABLE-BOUNDARY-START(107374918931)
            /*bool */ ShouldEditName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374918931);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374918931)
            
            //--TRIMMABLE-BOUNDARY-START(81605115155)
            /*bool */ RequiresName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605115155);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605115155)
            
            //--TRIMMABLE-BOUNDARY-START(111669886227)
            /*bool */ ShouldEditSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111669886227);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669886227)
            
            //--TRIMMABLE-BOUNDARY-START(85900082451)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900082451);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900082451)
            
            //--TRIMMABLE-BOUNDARY-START(115964853523)
            /*bool */ ShouldEditTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964853523);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964853523)
            
            //--TRIMMABLE-BOUNDARY-START(90195049747)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195049747);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195049747)
            
            //--TRIMMABLE-BOUNDARY-START(103079951635)
            /*bool */ ShouldEditIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079951635);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079951635)
            
            //--TRIMMABLE-BOUNDARY-START(77310147859)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310147859);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310147859)
            
            //--TRIMMABLE-BOUNDARY-START(124554788115)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554788115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 1/*SchemaType.Form*/)
                {
                    descriptors = $.$LCOv.LCFCPM$1.PostBaseModel.Exclude(descriptors, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "Summary", "PostFlags" ], null, null));
                }
                return super.UpdateDescriptors(descriptors, $.$clone(schema));
            }
            //--TRIMMABLE-BOUNDARY-END(124554788115)
            
            //--TRIMMABLE-BOUNDARY-START(68720213267)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720213267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Schema === 1/*SchemaType.Form*/)
                {
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Name", "Review Title", null, null, null, null);
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Post", "Review", "Review Content", null, 11n, 1000);
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Location", "Experience Location", "Tell us where your experienced takes place", null, null, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720213267)
            
            //--TRIMMABLE-BOUNDARY-START(73015180563)
            /*string? */ get ParentLink()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835311379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let targetLink = this.MetadataParentLink;
                if (targetLink !== null)
                {
                    return `${$.$strNN(targetLink)}#${$.$strNN($.$dspc(this.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}`;
                }
                if (this.ParentId.HasValue)
                {
                    return `Community/Post/${$.$strNN($.$dspc(this.ParentId.Id, $.$$.S.Object, ($t) => $t.ToString))}#${$.$strNN(this.Identifier.ToString())}`;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(73015180563)
            
            //--TRIMMABLE-BOUNDARY-START(21475573011)
            /*bool */ get CanAddOn()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(21475573011)
            
            //--TRIMMABLE-BOUNDARY-START(17180605715)
            /*PostBaseModel?*/ AddOnParent = null;
            //--TRIMMABLE-BOUNDARY-END(17180605715)
            
            //--TRIMMABLE-BOUNDARY-START(12885638419)
            /*string */ get AddOnActivityDescription()
            {
                return "added a review";
            }
            //--TRIMMABLE-BOUNDARY-END(12885638419)
            
            //--TRIMMABLE-BOUNDARY-START(128849755411)
            /*ValueTask<bool> */ Validate(/*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849755411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (schema.Type === 1/*SchemaType.Form*/ && this.Rating <= 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Please choose a rating");
                }
                return super.Validate($.$clone(schema));
            }
            //--TRIMMABLE-BOUNDARY-END(128849755411)
            
            //--TRIMMABLE-BOUNDARY-START(38656010676)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostAddOn.CanAddOn.get
            get LCFCP$IPostAddOn$CanAddOn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886206900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanAddOn;
            }
            //--TRIMMABLE-BOUNDARY-END(38656010676)
            
            //--TRIMMABLE-BOUNDARY-START(21476141492)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostAddOn.AddOnActivityDescription.get
            get LCFCP$IPostAddOn$AddOnActivityDescription()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296272308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddOnActivityDescription;
            }
            //--TRIMMABLE-BOUNDARY-END(21476141492)
            
            //--TRIMMABLE-BOUNDARY-START(30066076084)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostAddOn.AddOnParent.get
            get LCFCP$IPostAddOn$AddOnParent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591239604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddOnParent;
            }
            //--TRIMMABLE-BOUNDARY-END(30066076084)
            
            //--TRIMMABLE-BOUNDARY-START(47245945268)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostAddOn.AddOnParent.set
            set LCFCP$IPostAddOn$AddOnParent(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591239604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddOnParent = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47245945268)
            
            //--TRIMMABLE-BOUNDARY-START(8592943540)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostRating.Rating.get
            get LCFCP$IPostRating$Rating()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477845428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Rating;
            }
            //--TRIMMABLE-BOUNDARY-END(8592943540)
            
            //--TRIMMABLE-BOUNDARY-START(34362747316)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostRating.Rating.set
            set LCFCP$IPostRating$Rating(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477845428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Rating = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34362747316)
            
            //--TRIMMABLE-BOUNDARY-START(17182878132)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostRating.RatingMessage.get
            get LCFCP$IPostRating$RatingMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772812724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RatingMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(17182878132)
            
            //--TRIMMABLE-BOUNDARY-START(42952681908)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostRating.RatingMessage.set
            set LCFCP$IPostRating$RatingMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772812724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.RatingMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42952681908)
            
            //--TRIMMABLE-BOUNDARY-START(8593271220)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesCount.get
            get LCFCP$IPostReplyable$RepliesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478173108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593271220)
            
            //--TRIMMABLE-BOUNDARY-START(17183205812)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesDepth.get
            get LCFCP$IPostReplyable$RepliesDepth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773140404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesDepth;
            }
            //--TRIMMABLE-BOUNDARY-END(17183205812)
            
            //--TRIMMABLE-BOUNDARY-START(8590671123)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(8590671123)
            
            static $h = 736531;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120259820819),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425245971,
        "f": 50364417
      },
      "n": "Type",
      "d": 736531,
      "h": 120259820819,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120259820819),
//--TRIMMABLE-BOUNDARY-START(73015180563),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835311379,
        "f": 50331649
      },
      "n": "ParentLink",
      "d": 736531,
      "h": 73015180563,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015180563),
//--TRIMMABLE-BOUNDARY-START(21475573011),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245376787,
        "f": 50331649
      },
      "n": "CanAddOn",
      "d": 736531,
      "h": 21475573011,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475573011),
//--TRIMMABLE-BOUNDARY-START(17180605715),
    {
      "p": 16771508,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655442195,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784984339,
        "f": 83886081
      },
      "n": "AddOnParent",
      "d": 736531,
      "h": 17180605715,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180605715),
//--TRIMMABLE-BOUNDARY-START(12885638419),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065507603,
        "f": 50331649
      },
      "n": "AddOnActivityDescription",
      "d": 736531,
      "h": 12885638419,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885638419)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107374918931),
    {
      "r": 262145,
      "n": "ShouldEditName",
      "d": 736531,
      "h": 107374918931,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107374918931),
//--TRIMMABLE-BOUNDARY-START(81605115155),
    {
      "r": 262145,
      "n": "RequiresName",
      "d": 736531,
      "h": 81605115155,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605115155),
//--TRIMMABLE-BOUNDARY-START(111669886227),
    {
      "r": 262145,
      "n": "ShouldEditSummary",
      "d": 736531,
      "h": 111669886227,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669886227),
//--TRIMMABLE-BOUNDARY-START(85900082451),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 736531,
      "h": 85900082451,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900082451),
//--TRIMMABLE-BOUNDARY-START(115964853523),
    {
      "r": 262145,
      "n": "ShouldEditTags",
      "d": 736531,
      "h": 115964853523,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115964853523),
//--TRIMMABLE-BOUNDARY-START(90195049747),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": 736531,
      "h": 90195049747,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195049747),
//--TRIMMABLE-BOUNDARY-START(103079951635),
    {
      "r": 262145,
      "n": "ShouldEditIcon",
      "d": 736531,
      "h": 103079951635,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103079951635),
//--TRIMMABLE-BOUNDARY-START(77310147859),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 736531,
      "h": 77310147859,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310147859),
//--TRIMMABLE-BOUNDARY-START(124554788115),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": 736531,
      "h": 124554788115,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124554788115),
//--TRIMMABLE-BOUNDARY-START(68720213267),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 736531,
      "h": 68720213267,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720213267),
//--TRIMMABLE-BOUNDARY-START(128849755411),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Validate",
      "d": 736531,
      "h": 128849755411,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128849755411)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590671123),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 736531,
      "h": 8590671123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590671123)
  ],
  "h": 736531
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostAddOn, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostRating, $.$LCOv.LCFCP.IPostReplyable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Models${separator}CommunityReviewPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(736531)
        
        

        //--TRIMMABLE-BOUNDARY-START(1129747)
        $asm.$cls(`$dXSd.LCCRCS.ICommunityReviewFeedRemoteService`, ($self) => class ICommunityReviewFeedRemoteService
        {
            static $h = 1129747;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1129747,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Services.ICommunityReviewFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Services${separator}ICommunityReviewFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1129747)
        
        

        //--TRIMMABLE-BOUNDARY-START(1457427)
        $asm.$cls(`$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296424723)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296424723);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296424723)
            
            //--TRIMMABLE-BOUNDARY-START(8591392019)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Review$Common$Models$CommunityReviewCategoryModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591392019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591392019)
            
            //--TRIMMABLE-BOUNDARY-START(17181326611)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Review$Common$Models$CommunityReviewCategoryModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181326611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$dXSd.LCCRCM.CommunityReviewCategoryModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181326611)
            
            //--TRIMMABLE-BOUNDARY-START(21476293907)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Review$Common$Models$CommunityReviewCategoryModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476293907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$fPer.LCFCD.WireTransportModel$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$dXSd.LCCRCM.CommunityReviewCategoryModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476293907)
            
            //--TRIMMABLE-BOUNDARY-START(25771261203)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Review$Common$Models$CommunityReviewCategoryModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771261203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771261203)
            
            //--TRIMMABLE-BOUNDARY-START(12886359315)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886359315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$dXSd.LCCRCM.CommunityReviewCategoryModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886359315)
            
            static $h = 1457427;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296424723),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1457427,
      "h": 4296424723,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296424723)
  ],
  "h": 1457427
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$fPer.LCFCD.ICreateDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$fPer.LCFCD.IReadDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$fPer.LCFCD.IReadManyDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$fPer.LCFCD.IUpdateDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$fPer.LCFCD.IDeleteDataService$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityReviewCategoryModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1457427)
        
        

        //--TRIMMABLE-BOUNDARY-START(1522963)
        $asm.$cls(`$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityReviewElementModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296490259)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296490259);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296490259)
            
            //--TRIMMABLE-BOUNDARY-START(8591457555)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Review$Common$Models$CommunityReviewElementModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591457555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewElementModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$dXSd.LCCRCM.CommunityReviewElementModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591457555)
            
            //--TRIMMABLE-BOUNDARY-START(17181392147)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Review$Common$Models$CommunityReviewElementModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181392147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewElementModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$dXSd.LCCRCM.CommunityReviewElementModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181392147)
            
            //--TRIMMABLE-BOUNDARY-START(21476359443)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Review$Common$Models$CommunityReviewElementModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476359443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$dXSd.LCCRCM.CommunityReviewElementModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$fPer.LCFCD.WireTransportModel$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$dXSd.LCCRCM.CommunityReviewElementModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476359443)
            
            //--TRIMMABLE-BOUNDARY-START(25771326739)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Review$Common$Models$CommunityReviewElementModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771326739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewElementModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$dXSd.LCCRCM.CommunityReviewElementModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771326739)
            
            //--TRIMMABLE-BOUNDARY-START(12886424851)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886424851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$dXSd.LCCRCM.CommunityReviewElementModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886424851)
            
            static $h = 1522963;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296490259),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1522963,
      "h": 4296490259,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296490259)
  ],
  "h": 1522963
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$fPer.LCFCD.ICreateDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$fPer.LCFCD.IReadDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$fPer.LCFCD.IReadManyDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$fPer.LCFCD.IUpdateDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$fPer.LCFCD.IDeleteDataService$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityReviewElementModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityReviewElementModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1522963)
        
        

        //--TRIMMABLE-BOUNDARY-START(605459)
        $asm.$cls(`$dXSd.LCCRCM.CommunityReviewElementModelTypeDescriptor`, ($self) => class CommunityReviewElementModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dXSd.LCCRCM.CommunityReviewElementModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295572755)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295572755);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dXSd.LCCRCM.CommunityReviewElementModelTypeDescriptor.GenerateProperties($.$dXSd.LCCRCM.CommunityReviewElementModel, this, factory);
                    }, $QDaJPj ??= {"r":65537,"n":"","d":605459,"h":0,"f":17825794}), 0, "CommunityReviewElementModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Review.Common\\Models_CommunityReviewElementModel_LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModelTypeDescriptorBuilder.g.cs", "CommunityReviewElementModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295572755)
            
            //--TRIMMABLE-BOUNDARY-START(12885507347)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885507347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ReviewByLocation"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dXSd.LCCRCM.CommunityReviewElementModel.$type, $.$discardRef(), "ReviewByLocation", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ReviewByLocation")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ReviewByLocation";
                        $i1.DelaredOn = "LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dXSd.LCCRCM.CommunityReviewElementModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$dXSd.LCCRCM.CommunityReviewElementModel)).ReviewByLocation);
                        }, $xtqNEh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":605459,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dXSd.LCCRCM.CommunityReviewElementModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ReviewByLocation = value.AsBool();
                        }, $JghMKb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":605459,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dXSd.LCCRCM.CommunityReviewElementModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Type";
                        $i3.DelaredOn = "LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dXSd.LCCRCM.CommunityReviewElementModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$dXSd.LCCRCM.CommunityReviewElementModel)).Type);
                        }, $BdBNNa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":605459,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dXSd.LCCRCM.CommunityReviewElementModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Link";
                        $i5.DelaredOn = "LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dXSd.LCCRCM.CommunityReviewElementModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$dXSd.LCCRCM.CommunityReviewElementModel)).Link);
                        }, $PVCpdf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":605459,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885507347)
            
            //--TRIMMABLE-BOUNDARY-START(17180474643)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180474643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel, LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel)));
                {
                    /*var*/ let _ReviewByLocation = _target.ReviewByLocation;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ReviewByLocation"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _ReviewByLocation, ($v) => _ReviewByLocation = $v, null, true)))
                    {
                        _target.ReviewByLocation = _ReviewByLocation;
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180474643)
            
            //--TRIMMABLE-BOUNDARY-START(8590540051)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590540051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dXSd.LCCRCM.CommunityReviewElementModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dXSd.LCCRCM.CommunityReviewElementModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dXSd.LCCRCM.CommunityReviewElementModel)))
                {
                    /*var*/ let result = $.$dXSd.LCCRCM.CommunityReviewElementModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dXSd.LCCRCM.CommunityReviewElementModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dXSd.LCCRCM.CommunityReviewElementModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dXSd.LCCRCM.CommunityReviewElementModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590540051)
            
            static $h = 605459;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dXSd.LCCRCM.CommunityReviewElementModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885507347),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 605459,
      "h": 12885507347,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885507347),
//--TRIMMABLE-BOUNDARY-START(17180474643),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 474387,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 605459,
      "h": 17180474643,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180474643),
//--TRIMMABLE-BOUNDARY-START(8590540051),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 474387,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 605459,
      "h": 8590540051,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590540051)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295572755),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 605459,
      "h": 4295572755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295572755)
  ],
  "h": 605459
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dXSd.LCCRCM.CommunityReviewElementModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Models${separator}CommunityReviewElementModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(605459)
        
        

        //--TRIMMABLE-BOUNDARY-START(343315)
        $asm.$cls(`$dXSd.LCCRCM.CommunityReviewCategoryModelTypeDescriptor`, ($self) => class CommunityReviewCategoryModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295310611)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295310611);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dXSd.LCCRCM.CommunityReviewCategoryModelTypeDescriptor.GenerateProperties($.$dXSd.LCCRCM.CommunityReviewCategoryModel, this, factory);
                    }, $LHMHFb ??= {"r":65537,"n":"","d":343315,"h":0,"f":17825794}), 0, "CommunityReviewCategoryModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Review.Common\\Models_CommunityReviewCategoryModel_LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModelTypeDescriptorBuilder.g.cs", "CommunityReviewCategoryModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295310611)
            
            //--TRIMMABLE-BOUNDARY-START(12885245203)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885245203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dXSd.LCCRCM.CommunityReviewCategoryModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dXSd.LCCRCM.CommunityReviewCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$dXSd.LCCRCM.CommunityReviewCategoryModel)).Type);
                        }, $FyNXTj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":343315,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885245203)
            
            //--TRIMMABLE-BOUNDARY-START(17180212499)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180212499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel, LivingThing.Core.Community.Review.Common.Models.CommunityReviewElementModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel, $.$dXSd.LCCRCM.CommunityReviewElementModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180212499)
            
            //--TRIMMABLE-BOUNDARY-START(8590277907)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590277907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dXSd.LCCRCM.CommunityReviewCategoryModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dXSd.LCCRCM.CommunityReviewCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dXSd.LCCRCM.CommunityReviewCategoryModel)))
                {
                    /*var*/ let result = $.$dXSd.LCCRCM.CommunityReviewCategoryModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dXSd.LCCRCM.CommunityReviewCategoryModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dXSd.LCCRCM.CommunityReviewCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dXSd.LCCRCM.CommunityReviewCategoryModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590277907)
            
            static $h = 343315;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885245203),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 343315,
      "h": 12885245203,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885245203),
//--TRIMMABLE-BOUNDARY-START(17180212499),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 212243,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 343315,
      "h": 17180212499,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180212499),
//--TRIMMABLE-BOUNDARY-START(8590277907),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 212243,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 343315,
      "h": 8590277907,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590277907)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295310611),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 343315,
      "h": 4295310611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295310611)
  ],
  "h": 343315
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dXSd.LCCRCM.CommunityReviewCategoryModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Models.CommunityReviewCategoryModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Models${separator}CommunityReviewCategoryModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(343315)
        
        

        //--TRIMMABLE-BOUNDARY-START(1195283)
        $asm.$cls(`$dXSd.LCCRCS.ICommunityReviewFeedRemoteService_Mocking`, ($self) => class ICommunityReviewFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296162579)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296162579);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296162579)
            
            //--TRIMMABLE-BOUNDARY-START(8591129875)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Review$Common$Models$CommunityReviewPostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591129875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$dXSd.LCCRCM.CommunityReviewPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewPostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591129875)
            
            static $h = 1195283;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296162579),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1195283,
      "h": 4296162579,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296162579)
  ],
  "h": 1195283
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$dXSd.LCCRCS.ICommunityReviewFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Services.ICommunityReviewFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Services${separator}ICommunityReviewFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1195283)
        
        

        //--TRIMMABLE-BOUNDARY-START(1588499)
        $asm.$cls(`$dXSd.LCFCR.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityReviewPostModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296555795)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296555795);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296555795)
            
            //--TRIMMABLE-BOUNDARY-START(8591523091)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Review$Common$Models$CommunityReviewPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591523091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$dXSd.LCCRCM.CommunityReviewPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591523091)
            
            //--TRIMMABLE-BOUNDARY-START(17181457683)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Review$Common$Models$CommunityReviewPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181457683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$dXSd.LCCRCM.CommunityReviewPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181457683)
            
            //--TRIMMABLE-BOUNDARY-START(21476424979)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Review$Common$Models$CommunityReviewPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476424979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$dXSd.LCCRCM.CommunityReviewPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$dXSd.LCCRCM.CommunityReviewPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476424979)
            
            //--TRIMMABLE-BOUNDARY-START(25771392275)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Review$Common$Models$CommunityReviewPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771392275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$dXSd.LCCRCM.CommunityReviewPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771392275)
            
            //--TRIMMABLE-BOUNDARY-START(12886490387)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886490387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$dXSd.LCCRCM.CommunityReviewPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886490387)
            
            static $h = 1588499;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296555795),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1588499,
      "h": 4296555795,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296555795)
  ],
  "h": 1588499
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFCD.IReadDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityReviewPostModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityReviewPostModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1588499)
        
        

        //--TRIMMABLE-BOUNDARY-START(867603)
        $asm.$cls(`$dXSd.LCCRCM.CommunityReviewPostModelTypeDescriptor`, ($self) => class CommunityReviewPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dXSd.LCCRCM.CommunityReviewPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295834899)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295834899);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dXSd.LCCRCM.CommunityReviewPostModelTypeDescriptor.GenerateProperties($.$dXSd.LCCRCM.CommunityReviewPostModel, this, factory);
                    }, $eInxpf ??= {"r":65537,"n":"","d":867603,"h":0,"f":17825794}), 0, "CommunityReviewPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Review.Common\\Models_CommunityReviewPostModel_LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModelTypeDescriptorBuilder.g.cs", "CommunityReviewPostModelTypeDescriptor", 43);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295834899)
            
            //--TRIMMABLE-BOUNDARY-START(12885769491)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885769491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dXSd.LCCRCM.CommunityReviewPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dXSd.LCCRCM.CommunityReviewPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$dXSd.LCCRCM.CommunityReviewPostModel)).Type);
                        }, $mCZTTf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":867603,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ParentLink"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dXSd.LCCRCM.CommunityReviewPostModel.$type, $.$discardRef(), "ParentLink", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ParentLink")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "ParentLink";
                        $i3.DelaredOn = "LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dXSd.LCCRCM.CommunityReviewPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$dXSd.LCCRCM.CommunityReviewPostModel)).ParentLink);
                        }, $HyMvOa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":867603,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CanAddOn"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dXSd.LCCRCM.CommunityReviewPostModel.$type, $.$discardRef(), "CanAddOn", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CanAddOn")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "CanAddOn";
                        $i5.DelaredOn = "LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dXSd.LCCRCM.CommunityReviewPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$dXSd.LCCRCM.CommunityReviewPostModel)).CanAddOn);
                        }, $PJwzDi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":867603,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AddOnParent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dXSd.LCCRCM.CommunityReviewPostModel.$type, $.$discardRef(), "AddOnParent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AddOnParent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostBaseModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "AddOnParent";
                        $i7.DelaredOn = "LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dXSd.LCCRCM.CommunityReviewPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$LCOv.LCFCPM$1.PostBaseModel, ($.$cast(target, $.$dXSd.LCCRCM.CommunityReviewPostModel)).AddOnParent);
                        }, $CAgRDc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":867603,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dXSd.LCCRCM.CommunityReviewPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.AddOnParent = value.AsReference($.$LCOv.LCFCPM$1.PostBaseModel);
                        }, $AaUIxd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":867603,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AddOnActivityDescription"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dXSd.LCCRCM.CommunityReviewPostModel.$type, $.$discardRef(), "AddOnActivityDescription", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AddOnActivityDescription")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "AddOnActivityDescription";
                        $i9.DelaredOn = "LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dXSd.LCCRCM.CommunityReviewPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$dXSd.LCCRCM.CommunityReviewPostModel)).AddOnActivityDescription);
                        }, $DhpEqi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":867603,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885769491)
            
            //--TRIMMABLE-BOUNDARY-START(17180736787)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180736787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _ParentLink = _target.ParentLink;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ParentLink"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ParentLink, ($v) => _ParentLink = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _CanAddOn = _target.CanAddOn;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CanAddOn"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _CanAddOn, ($v) => _CanAddOn = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _AddOnParent = _target.AddOnParent;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AddOnParent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostBaseModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _AddOnParent, ($v) => _AddOnParent = $v, $.$LCOv.LCFCPM$1.PostBaseModel)))
                    {
                        _target.AddOnParent = _AddOnParent;
                    }
                }
                {
                    /*var*/ let _AddOnActivityDescription = _target.AddOnActivityDescription;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AddOnActivityDescription"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _AddOnActivityDescription, ($v) => _AddOnActivityDescription = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180736787)
            
            //--TRIMMABLE-BOUNDARY-START(8590802195)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590802195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dXSd.LCCRCM.CommunityReviewPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dXSd.LCCRCM.CommunityReviewPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dXSd.LCCRCM.CommunityReviewPostModel)))
                {
                    /*var*/ let result = $.$dXSd.LCCRCM.CommunityReviewPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dXSd.LCCRCM.CommunityReviewPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dXSd.LCCRCM.CommunityReviewPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dXSd.LCCRCM.CommunityReviewPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590802195)
            
            static $h = 867603;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dXSd.LCCRCM.CommunityReviewPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885769491),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 867603,
      "h": 12885769491,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885769491),
//--TRIMMABLE-BOUNDARY-START(17180736787),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 736531,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 867603,
      "h": 17180736787,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180736787),
//--TRIMMABLE-BOUNDARY-START(8590802195),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 736531,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 867603,
      "h": 8590802195,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590802195)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295834899),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 867603,
      "h": 4295834899,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295834899)
  ],
  "h": 867603
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dXSd.LCCRCM.CommunityReviewPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Review.Common.Models.CommunityReviewPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Review${separator}Common${separator}Models${separator}CommunityReviewPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(867603)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(15635)
