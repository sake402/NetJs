
//--TRIMMABLE-BOUNDARY-START(25991)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $xrPB, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $OCet, $fycR, $awPs, $qgEF, $SAWq) {
    "use strict";
    let _;
    let $KpQhze;
    let $cpRyja;
    let $eYzaui;
    let $YsPokh;
    let $KKKcob;
    let $WRnZRk;
    let $EHSJVh;
    let $oFQPth;
    let $xnvtod;
    let $DVCWGh;
    let $AEsmFf;
    let $BYaNyb;
    let $MxYNfd;
    let $SIATak;
    let $eZUYKi;
    let $YuIqwd;
    let $LWHGNg;
    let $frMIOb;
    let $VtleUj;
    let $vVdrzb;
    let $hMcWEi;
    let $FiKWsj;
    let $SQEfih;
    let $bBYOCg;
    let $frpcrk;
    let $PfNguc;
    let $RInSqc;
    let $GCIbsh;
    let $zFWFSh;
    let $ftCrsc;
    let $KJOwac;
    let $nZaXwj;
    let $STErUi;
    let $lRnzki;
    let $BKlSlh;
    let $msTdZj;
    let $uFQEEa;
    let $vFSyik;
    let $ioMPtj;
    let $xuZnfa;
    let $NIsUCc;
    let $wMkHnk;
    let $fETpBi;
    let $eQAkDd;
    let $nFPGYc;
    let $LzMsOi;
    let $SBNBka;
    let $romaOb;
    let $GBbvqg;
    let $YsBdnf;
    let $KyLxUe;
    let $nvOnLi;
    let $XMNbGb;
    let $xiJupc;
    let $IhRsUi;
    let $YIEsph;
    let $kwAbAf;
    let $KuYVNg;
    let $BHDTTd;
    let $puWErj;
    let $bqghOd;
    let $Rwelhj;
    let $jXEjca;
    let $cmxize;
    let $CFGWQi;
    let $paTfNc;
    let $piAsZg;
    let $hMeaZb;
    let $ChCcZj;
    let $LbjMIb;
    let $kdrCZj;
    let $LYPvlj;
    let $MPhqgk;
    let $npNajj;
    let $iEWOie;
    let $GOALUd;
    let $njEyEd;
    let $XxZXgc;
    let $QTerSj;
    let $OGwvSe;
    let $bGFQDd;
    let $YSWKWj;
    let $FwmzOh;
    let $ahBFPc;
    let $jSZbjb;
    let $GZEQMc;
    let $IXNZBb;
    let $UKcVPh;
    let $eQnOil;
    let $BZNFMi;
    let $UAZpma;
    let $YaNPkf;
    let $cPqnFj;
    let $LPVxmd;
    let $lDKpPc;
    let $TGjJld;
    let $HRHltf;
    let $KRelGd;
    let $HExbnh;
    let $WXLhCh;
    let $aounGe;
    let $drFVlh;
    let $fgGgPf;
    let $XUOPLg;
    let $ukLJWc;
    let $CafVuj;
    let $PeKWle;
    let $MZTjrd;
    let $bSsVwk;
    let $XrTCMa;
    let $Kyxxic;
    let $IOIwCk;
    let $cZuYuc;
    let $PIcaKh;
    let $iceEbc;
    let $aUQrwb;
    let $CJQtHj;
    let $cLtlHh;
    let $mgzejb;
    let $lGGYBb;
    let $FbOhtk;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.School.Client.Admin.Blazor", 
    {
  "h": 25991,
  "f": "LivingThing.Core.Community.School.Client.Admin.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.School.Client.Admin.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.School.Client.Admin.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(222599)
        $asm.$cls(`$bfaB.LCCSCA._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295189895)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295189895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$bfaB.LCCSCA.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295189895)
            
            static $h = 222599;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295189895),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 222599,
      "h": 4295189895,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295189895)
  ],
  "h": 222599
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.School.Client.Admin._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}School${separator}Client${separator}Admin${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(222599)
        
        

        //--TRIMMABLE-BOUNDARY-START(353671)
        $asm.$cls(`$bfaB.LCCSCA.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590288263)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590288263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$bfaB.LCCSCAP.Admin, "LivingThing.Core.Community.School.Client.Admin", "Pages\\Admin", "Admin", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Admin/School", "/Admin/School/{*Page}" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$bfaB.LCCSCAP.CreateSkill, "LivingThing.Core.Community.School.Client.Admin", "Pages\\CreateSkill", "Create Skill", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Admin/School/CreateSkill" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$bfaB.LCCSCAP.SkillAssets, "LivingThing.Core.Community.School.Client.Admin", "Pages\\SkillAssets", "Skill Assets", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Admin/School/SkillAssets" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590288263)
            
            //--TRIMMABLE-BOUNDARY-START(4295320967)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295320967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295320967)
            
            //--TRIMMABLE-BOUNDARY-START(4295320967)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295320967)
            
            static $h = 353671;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590288263),
    {
      "r": 65537,
      "n": "Build",
      "d": 353671,
      "h": 8590288263,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590288263)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295320967),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 353671,
      "h": 4295320967,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295320967)
  ],
  "h": 353671
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.School.Client.Admin.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}School${separator}Client${separator}Admin${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(353671)
        
        

        //--TRIMMABLE-BOUNDARY-START(91527)
        $asm.$cls(`$bfaB._LCCSCAPA.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295058823)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295058823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "ChildContent", __arg1);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295058823)
            
            static $h = 91527;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295058823),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 91527,
      "h": 4295058823,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295058823)
  ],
  "h": 91527
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.School.Client.Admin.Pages.Admin.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}School${separator}Client${separator}Admin${separator}Pages${separator}Admin${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(91527)
        
        

        //--TRIMMABLE-BOUNDARY-START(615815)
        $asm.$cls(`$bfaB.LCCSCA.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590550407)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590550407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bfaB.LCCSCA.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$hDPm.LCFCI.AdministrativeComponentProviderExtension.AddAdminPage($.$bfaB.LCCSCAP.Admin, services, "School", "mdi mdi-school"/*MaterialDesignIconNames.School*/);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$hDPm.LCFCCD.IDashboardTableDataPropertyAddOnViewProvider$$($.$OCet.LCCSCM.CommunitySchoolSkillModel), $.$bfaB.LCCSCA.SkillPlayerProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590550407)
            
            //--TRIMMABLE-BOUNDARY-START(12885517703)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885517703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_SkillPlayerProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$bfaB.LCCSCA.SkillPlayerProvider().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$awPs.LCCSCS.CommunitySchoolService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$awPs.LCCSCS.CommunitySchoolService, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$hDPm.LCFCI.IClientUnitOfWork, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientUnitOfWork, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$hDPm.LCFCCD.IDashboardTableDataPropertyAddOnViewProvider$$($.$OCet.LCCSCM.CommunitySchoolSkillModel).$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$bfaB.LCCSCA.ServiceRegistrar, Get_SkillPlayerProvider, $YsPokh ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_SkillPlayerProvider","d":615815,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12885517703)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$bfaB.LCCSCA.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295583111)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295583111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295583111)
            
            //--TRIMMABLE-BOUNDARY-START(4295583111)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295583111)
            
            static $h = 615815;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590550407),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 615815,
      "h": 8590550407,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590550407),
//--TRIMMABLE-BOUNDARY-START(12885517703),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 615815,
      "h": 12885517703,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885517703)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295583111),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 615815,
      "h": 4295583111,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295583111)
  ],
  "h": 615815
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.School.Client.Admin.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}School${separator}Client${separator}Admin${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(615815)
        
        

        //--TRIMMABLE-BOUNDARY-START(288135)
        $asm.$cls(`$bfaB.LCCSCA.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180157319)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$bfaB.LCCSCAP.Admin.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$bfaB.LCCSCAP.Admin().$ctor$3();
                    }, $KpQhze ??= {"r":2752627,"n":"","d":288135,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$bfaB.LCCSCAP.CreateSkill.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$bfaB.LCCSCAP.CreateSkill().$ctor$3();
                    }, $cpRyja ??= {"r":2752627,"n":"","d":288135,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$bfaB.LCCSCAP.SkillAssets.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$bfaB.LCCSCAP.SkillAssets().$ctor$3();
                    }, $eYzaui ??= {"r":2752627,"n":"","d":288135,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180157319)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295255431)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295255431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295255431)
            
            //--TRIMMABLE-BOUNDARY-START(4295255431)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295255431)
            
            static $h = 288135;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180157319),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885190023,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 288135,
      "h": 17180157319,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180157319)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295255431),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 288135,
      "h": 4295255431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295255431)
  ],
  "h": 288135
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.School.Client.Admin.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}School${separator}Client${separator}Admin${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(288135)
        
        

        //--TRIMMABLE-BOUNDARY-START(812423)
        $asm.$cls(`$bfaB.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295779719)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295779719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295779719)
            
            //--TRIMMABLE-BOUNDARY-START(4295779719)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295779719)
            
            static $h = 812423;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295779719),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 812423,
      "h": 4295779719,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295779719)
  ],
  "h": 812423,
  "a": [
    {
      "t": 746887,
      "c": 4295714183
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(812423)
        
        

        //--TRIMMABLE-BOUNDARY-START(746887)
        $asm.$cls(`$bfaB.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295714183)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295714183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295714183)
            
            //--TRIMMABLE-BOUNDARY-START(4295714183)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295714183)
            
            static $h = 746887;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295714183),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 746887,
      "h": 4295714183,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295714183)
  ],
  "h": 746887
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(746887)
        
        

        //--TRIMMABLE-BOUNDARY-START(157063)
        $asm.$cls(`$bfaB.LCCSCA._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590091655)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590091655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590091655)
            
            //--TRIMMABLE-BOUNDARY-START(4295124359)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295124359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295124359)
            
            //--TRIMMABLE-BOUNDARY-START(4295124359)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295124359)
            
            static $h = 157063;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590091655),
    {
      "r": 65537,
      "n": "Execute",
      "d": 157063,
      "h": 8590091655,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590091655)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295124359),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 157063,
      "h": 4295124359,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295124359)
  ],
  "h": 157063
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.School.Client.Admin._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}School${separator}Client${separator}Admin${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(157063)
        
        

        //--TRIMMABLE-BOUNDARY-START(550279)
        $asm.$cls(`$bfaB.LCCSCAP.SkillAssets`, ($self) => class SkillAssets extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(42950223239)
            /*CommunitySchoolService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(42950223239)
            
            //--TRIMMABLE-BOUNDARY-START(38655255943)
            /*string */ get OptimizedComponentName()
            {
                return "skillassets";
            }
            //--TRIMMABLE-BOUNDARY-END(38655255943)
            
            //--TRIMMABLE-BOUNDARY-START(34360288647)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360288647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$awPs.LCCSCS.CommunitySchoolService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(34360288647)
            
            //--TRIMMABLE-BOUNDARY-START(12885452167)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885452167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hv-10 scroll");
                __builder.AddMarkupContent(2, "<div class=\"pd bdb bg-card\"><h2 class=\"mg-0\">Assets Editor</h2></div>\r\n    ");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "pd");
                __builder.OpenComponent$1($.$SAWq.LCGCS.GalleryBrowser, 5);
                __builder.AddComponentParameter(6, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$qgEF.LCGCM.GalleryDescriptor, (() =>
                {
                    //new $.$qgEF.LCGCM.GalleryDescriptor()
                    const $t1 = $.$qgEF.LCGCM.GalleryDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.RootFolder = "LivingThing.Core.Community.School.Server.Services.CommunitySchoolSkillAssetGalleryWebHostingProvider";
                    return $i1;
                })()));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12885452167)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590484871)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590484871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590484871)
            
            //--TRIMMABLE-BOUNDARY-START(8590484871)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590484871)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42950223239)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(42950223239)
                
            }
            static $h = 550279;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950223239),
    {
      "p": 2224851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065321351,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540157831,
        "f": 83886081
      },
      "n": "Service",
      "d": 550279,
      "h": 42950223239,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950223239),
//--TRIMMABLE-BOUNDARY-START(38655255943),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475386759,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 550279,
      "h": 38655255943,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655255943)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360288647),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 550279,
      "h": 34360288647,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360288647),
//--TRIMMABLE-BOUNDARY-START(12885452167),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 550279,
      "h": 12885452167,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885452167)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590484871),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 550279,
      "h": 8590484871,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590484871)
  ],
  "h": 550279,
  "a": [
    {
      "t": 917616,
      "c": 17180786800,
      "n": [
        {
          "n": "Roles",
          "v": "SuperAdmin,School.Admin,School.Editor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/School/SkillAssets",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.School.Client.Admin.Pages.SkillAssets`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}School${separator}Client${separator}Admin${separator}Pages${separator}SkillAssets`; }
        });
        //--TRIMMABLE-BOUNDARY-END(550279)
        
        

        //--TRIMMABLE-BOUNDARY-START(484743)
        $asm.$cls(`$bfaB.LCCSCAP.CreateSkill`, ($self) => class CreateSkill extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(167504209287)
            /*string */ get OptimizedComponentName()
            {
                return "createskill";
            }
            //--TRIMMABLE-BOUNDARY-END(167504209287)
            
            //--TRIMMABLE-BOUNDARY-START(128849503623)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849503623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$awPs.LCCSCS.CommunitySchoolService, serviceProvider);
                this.Assets$1 = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCH.IAssetsCollection, serviceProvider);
                this.TokenResolver = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(128849503623)
            
            //--TRIMMABLE-BOUNDARY-START(193274013063)
            /*CommunitySchoolService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(193274013063)
            
            //--TRIMMABLE-BOUNDARY-START(38655190407)
            /*IAssetsCollection*/ Assets$1 = null;
            //--TRIMMABLE-BOUNDARY-END(38655190407)
            
            //--TRIMMABLE-BOUNDARY-START(283468326279)
            /*MarkdownPlusTokenMethodResolverFactory*/ TokenResolver = null;
            //--TRIMMABLE-BOUNDARY-END(283468326279)
            
            //--TRIMMABLE-BOUNDARY-START(133144470919)
            /*bool*/ isSkillTemplate = false;
            //--TRIMMABLE-BOUNDARY-END(133144470919)
            
            //--TRIMMABLE-BOUNDARY-START(279173358983)
            /*void */ ToggleSkillType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173358983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.isSkillTemplate = !this.isSkillTemplate;
                this.skill = this.isSkillTemplate ? new $.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel().$ctor$9() : new $.$OCet.LCCSCM.CommunitySchoolSkillModel().$ctor$9();
                this.skillSet = null;
                this.subject = null;
                this.grade = null;
                this.skillContext = null;
            }
            //--TRIMMABLE-BOUNDARY-END(279173358983)
            
            //--TRIMMABLE-BOUNDARY-START(261993489799)
            /*IEnumerable<ISelectOption<IChildrenHierachy>>?*/ skillHierachy = null;
            //--TRIMMABLE-BOUNDARY-END(261993489799)
            
            //--TRIMMABLE-BOUNDARY-START(270583424391)
            /*IEnumerable<ISelectOption<IChildrenHierachy>>?*/ skillTemplateHierachy = null;
            //--TRIMMABLE-BOUNDARY-END(270583424391)
            
            //--TRIMMABLE-BOUNDARY-START(287763293575)
            /*IEnumerable<ISelectOption<IChildrenHierachy>>? */ get UseHierachy()
            {
                return this.isSkillTemplate ? this.skillTemplateHierachy : this.skillHierachy;
            }
            //--TRIMMABLE-BOUNDARY-END(287763293575)
            
            //--TRIMMABLE-BOUNDARY-START(249108587911)
            /*CommunitySchoolSkillBaseModel?*/ skill = null;
            //--TRIMMABLE-BOUNDARY-END(249108587911)
            
            //--TRIMMABLE-BOUNDARY-START(266288457095)
            /*CommunitySchoolSkillSetModel?*/ skillSet = null;
            //--TRIMMABLE-BOUNDARY-END(266288457095)
            
            //--TRIMMABLE-BOUNDARY-START(274878391687)
            /*CommunitySchoolSkillSubjectModel?*/ subject = null;
            //--TRIMMABLE-BOUNDARY-END(274878391687)
            
            //--TRIMMABLE-BOUNDARY-START(124554536327)
            /*CommunitySchoolGradeModel?*/ grade = null;
            //--TRIMMABLE-BOUNDARY-END(124554536327)
            
            //--TRIMMABLE-BOUNDARY-START(253403555207)
            /*CommunitySchoolSkillPlayerContext?*/ skillContext = null;
            //--TRIMMABLE-BOUNDARY-END(253403555207)
            
            //--TRIMMABLE-BOUNDARY-START(184684078471)
            /*IChildrenHierachy?*/ selectedHierachy = null;
            //--TRIMMABLE-BOUNDARY-END(184684078471)
            
            //--TRIMMABLE-BOUNDARY-START(188979045767)
            /*IChildrenHierachy? */ get SelectedHierachy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489765255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.selectedHierachy;
            }
            /*IChildrenHierachy? */ set SelectedHierachy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633751431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.selectedHierachy = value;
                /*var*/ let current = $.$cast(($.$cast(this.selectedHierachy, $.$fPer.LCFCD.IParentHierachy)), $.$fPer.LCFCD.IReadOnlyValueProvider);
                while(current !== null)
                {
                    let skill;
                    if ($.$is((current?.LCFCD$IReadOnlyValueProvider$Value ?? null), $.$OCet.LCCSCM.CommunitySchoolSkillBaseModel, { set $v($v){ skill = $v; } }))
                    {
                        this.skill = skill;
                    }
                    let skillSet;
                    if ($.$is((current?.LCFCD$IReadOnlyValueProvider$Value ?? null), $.$OCet.LCCSCM.CommunitySchoolSkillSetModel, { set $v($v){ skillSet = $v; } }))
                    {
                        this.skillSet = skillSet;
                    }
                    let subject;
                    if ($.$is((current?.LCFCD$IReadOnlyValueProvider$Value ?? null), $.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, { set $v($v){ subject = $v; } }))
                    {
                        this.subject = subject;
                    }
                    let grade;
                    if ($.$is((current?.LCFCD$IReadOnlyValueProvider$Value ?? null), $.$OCet.LCCSCM.CommunitySchoolGradeModel, { set $v($v){ grade = $v; } }))
                    {
                        this.grade = grade;
                    }
                    current = $.$cast(((($.$cast(current, $.$fPer.LCFCD.IParentHierachy))?.LCFCD$IParentHierachy$Parent ?? null)), $.$fPer.LCFCD.IReadOnlyValueProvider);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979045767)
            
            //--TRIMMABLE-BOUNDARY-START(146029372807)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(146029372807)
            
            //--TRIMMABLE-BOUNDARY-START(141734405511)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(141734405511)
            
            //--TRIMMABLE-BOUNDARY-START(257698522503)
            /*FormBuilder<CommunitySchoolSkillModel>?*/ skillForm = null;
            //--TRIMMABLE-BOUNDARY-END(257698522503)
            
            //--TRIMMABLE-BOUNDARY-START(171799176583)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(171799176583)
            
            //--TRIMMABLE-BOUNDARY-START(171799176583)
            //--TRIMMABLE-BOUNDARY-START(34360223111)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360223111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360223111)
            
            //--TRIMMABLE-BOUNDARY-START(180389111175)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389111175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(180389111175)
            
            //--TRIMMABLE-BOUNDARY-END(171799176583)
            
            //--TRIMMABLE-BOUNDARY-START(163209241991)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209241991);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    _ = this.Assets$1.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResourcePathResolver.LCFCC$IResourcePathResolver$Resolve("LivingThing.Core.Community.School.Client.Blazor", "LivingThing.Core.Community.School.Client.Blazor.css", false) ], null, null));
                    if (!this.UnitOfWork.LCFCI$IClientUnitOfWork$Rendering.LCFCC$IUIRenderingProvider$IsPreRendering)
                    {
                        let $t1, $r1;
                        let $t2, $r2;
                        let $t3, $r3;
                        ($t1 = $.$vWqU.LCFCC.LoadingExtension.EnsureLoaded(this.Service, true), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        /*var*/ let grades = ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$OCet.LCCSCM.CommunitySchoolGradeModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1196268653051967n | 4194304n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        /*var*/ let subject = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1196268653051967n | 4194304n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        this.skillHierachy = $.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.ToList($.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy), $.$sl.SL.Enumerable.Select$1($.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolGradeModel, $.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel), $.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy), $.$sl.SL.Enumerable.Select$1($.$OCet.LCCSCM.CommunitySchoolGradeModel, $.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolGradeModel, $.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel), $.$sl.SL.Enumerable.OrderBy$1($.$OCet.LCCSCM.CommunitySchoolGradeModel, $.$$.S.Int32, grades.Data, new ($.$$.S.Func$$$($.$OCet.LCCSCM.CommunitySchoolGradeModel, $.$$.S.Int32))().$ctor(this,  (/*o*/ o) =>
                        {
                            return o.Order;
                        }, $KKKcob ??= {"r":655361,"p":[{"n":"o","p":2905797}],"n":"","d":484743,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OCet.LCCSCM.CommunitySchoolGradeModel, $.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolGradeModel, $.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel)))().$ctor(this,  (/*grade*/ grade) =>
                        {
                            return new ($.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolGradeModel, $.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel))().$ctor$1(null, grade, grade.Title, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$6(grade.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741837/*PostFilterTypes.HasAssociation*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 4194304n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), new $.$uvJL.LCFCR.RemoteProxyExecutionContext().$ctor$1(), new ($.$$.S.Func$$$$($.$fPer.LCFCD.IParentHierachy, $.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, $.$fPer.LCFCD.IChildrenHierachy))().$ctor(this,  (/*parent*/ parent, /*subject*/ subject) =>
                            {
                                return new ($.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, $.$OCet.LCCSCM.CommunitySchoolSkillSetModel))().$ctor$1(parent, subject, subject.Title, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$2(new $.$fPer.LCFCD.CompositeDataId().$ctor$3(2/*CompositeDataIdRelationship.And*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ subject.Identifier, grade.Identifier ], null, null)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741837/*PostFilterTypes.HasAssociation*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 4194304n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), new $.$uvJL.LCFCR.RemoteProxyExecutionContext().$ctor$1(), new ($.$$.S.Func$$$$($.$fPer.LCFCD.IParentHierachy, $.$OCet.LCCSCM.CommunitySchoolSkillSetModel, $.$fPer.LCFCD.IChildrenHierachy))().$ctor(this,  (/*parent*/ parent, /*skillset*/ skillset) =>
                                {
                                    return new ($.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolSkillSetModel, $.$OCet.LCCSCM.CommunitySchoolSkillModel))().$ctor$1(parent, skillset, skillset.Title, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$6(skillset.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 4194304n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), new $.$uvJL.LCFCR.RemoteProxyExecutionContext().$ctor$1(), new ($.$$.S.Func$$$$($.$fPer.LCFCD.IParentHierachy, $.$OCet.LCCSCM.CommunitySchoolSkillModel, $.$fPer.LCFCD.IChildrenHierachy))().$ctor(this,  (/*parent*/ parent, /*skill*/ skill) =>
                                    {
                                        return new ($.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolSkillModel, $.$$.S.Object))().$ctor$1(parent, skill, skill.Title, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), new $.$uvJL.LCFCR.RemoteProxyExecutionContext().$ctor$1(), null);
                                    }, $WRnZRk ??= {"r":15960406,"p":[{"n":"parent","p":20875606},{"n":"skill","p":6969029}],"n":"","d":484743,"h":0,"f":17825794}));
                                }, $EHSJVh ??= {"r":15960406,"p":[{"n":"parent","p":20875606},{"n":"skillset","p":8804037}],"n":"","d":484743,"h":0,"f":17825794}));
                            }, $oFQPth ??= {"r":15960406,"p":[{"n":"parent","p":20875606},{"n":"subject","p":9393861}],"n":"","d":484743,"h":0,"f":17825794}));
                        }, $xnvtod ??= {"r":$.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolGradeModel, $.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel).$h,"p":[{"n":"grade","p":2905797}],"n":"","d":484743,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolGradeModel, $.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel), $.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy)))().$ctor(this,  (/*o*/ o) =>
                        {
                            return (() =>
                            {
                                //new $.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy)()
                                const $t4 = $.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy);
                                const $i4 = new $t4();
                                $i4.$ctor$3(o);
                                $i4.Title = (($.$cast(o.Value, $.$OCet.LCCSCM.CommunitySchoolGradeModel))?.Title ?? null);
                                return $i4;
                            })();
                        }, $DVCWGh ??= {"r":$.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy).$h,"p":[{"n":"o","p":$.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolGradeModel, $.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel).$h}],"n":"","d":484743,"h":0,"f":17825794}))), $.$$.SCG.IEnumerable$$($.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy)), $.$$.SCG.IEnumerable$$($.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCD.IChildrenHierachy)));
                        this.skillTemplateHierachy = $.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.ToList($.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy), $.$sl.SL.Enumerable.Select$1($.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, $.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel), $.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy), $.$sl.SL.Enumerable.Select$1($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, $.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, $.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel), $.$sl.SL.Enumerable.OrderBy$1($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, $.$$.S.Int32, subject.Data, new ($.$$.S.Func$$$($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, $.$$.S.Int32))().$ctor(this,  (/*o*/ o) =>
                        {
                            return o.Order;
                        }, $AEsmFf ??= {"r":655361,"p":[{"n":"o","p":9393861}],"n":"","d":484743,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, $.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, $.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel)))().$ctor(this,  (/*subject*/ subject) =>
                        {
                            return new ($.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, $.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel))().$ctor$1(null, subject, subject.Title, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$6(subject.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 4194304n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), new $.$uvJL.LCFCR.RemoteProxyExecutionContext().$ctor$1(), new ($.$$.S.Func$$$$($.$fPer.LCFCD.IParentHierachy, $.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel, $.$fPer.LCFCD.IChildrenHierachy))().$ctor(this,  (/*parent*/ parent, /*template*/ template) =>
                            {
                                return new ($.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel, $.$$.S.Object))().$ctor$1(parent, template, template.Title, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), new $.$uvJL.LCFCR.RemoteProxyExecutionContext().$ctor$1(), null);
                            }, $BYaNyb ??= {"r":15960406,"p":[{"n":"parent","p":20875606},{"n":"template","p":9656005}],"n":"","d":484743,"h":0,"f":17825794}));
                        }, $MxYNfd ??= {"r":$.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, $.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel).$h,"p":[{"n":"subject","p":9393861}],"n":"","d":484743,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, $.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel), $.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy)))().$ctor(this,  (/*o*/ o) =>
                        {
                            return (() =>
                            {
                                //new $.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy)()
                                const $t5 = $.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy);
                                const $i5 = new $t5();
                                $i5.$ctor$3(o);
                                $i5.Title = (($.$cast(o.Value, $.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel))?.Title ?? null);
                                return $i5;
                            })();
                        }, $SIATak ??= {"r":$.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy).$h,"p":[{"n":"o","p":$.$vWqU.LCFCCR.RemoteServerDataHierachy$$$($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, $.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel).$h}],"n":"","d":484743,"h":0,"f":17825794}))), $.$$.SCG.IEnumerable$$($.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.IChildrenHierachy)), $.$$.SCG.IEnumerable$$($.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCD.IChildrenHierachy)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(163209241991)
            
            //--TRIMMABLE-BOUNDARY-START(137439438215)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439438215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(137439438215)
            
            //--TRIMMABLE-BOUNDARY-START(150324340103)
            /*void */ NewSkill()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324340103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.skill = this.isSkillTemplate ? new $.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel().$ctor$9() : new $.$OCet.LCCSCM.CommunitySchoolSkillModel().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(150324340103)
            
            //--TRIMMABLE-BOUNDARY-START(154619307399)
            /*ValueTask *//*async*/  NewSkillSet()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619307399);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.grade !== null && this.subject !== null)
                    {
                        let $t6, $r6;
                        let $t7, $r7;
                        /*var*/ let skillSet = ($t6 = $.$hDPm.LCFCI.ViewPresenterExtensions.Form($.$hDPm.LCFCI.ViewConfiguration, $.$OCet.LCCSCM.CommunitySchoolSkillSetModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "New SkillSet", false), null, null, null, null, 0, 4131, new $.$fPer.LCFCD$1.PropertyDescriptorFilter().$ctor(this,  (/*e*/ e, /*i*/ i) =>
                        {
                            return i.LCFCD$1$IPropertyDescriptor$Name !== "Grades" && i.LCFCD$1$IPropertyDescriptor$Name !== "Subject";
                        }, $eZUYKi ??= {"r":262145,"p":[{"n":"e","p":2394454},{"n":"i","p":40733014}],"n":"","d":484743,"h":0,"f":17825794}), null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.School.Common.Models.CommunitySchoolGradeModel>?*/ let __ca1__;
                        if (!(((__ca1__ = skillSet.Grades) !== null ? $.$sl.SL.Enumerable.Any$1($.$OCet.LCCSCM.CommunitySchoolGradeModel, __ca1__) : false)))
                        {
                            skillSet.Grades = $.$$.SRC.RuntimeHelpers.CreateArray($.$OCet.LCCSCM.CommunitySchoolGradeModel.$type, [ this.grade ], null, null);
                        }
                        skillSet.Subject ??= this.subject;
                        ($t7 = $.$vWqU.LCFCC.LoadingExtension.Load$1($.$fPer.LCFCD.WireTransportManyModel$$($.$OCet.LCCSCM.CommunitySchoolSkillSetModel), this, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$($.$OCet.LCCSCM.CommunitySchoolSkillSetModel))))().$ctor(this,  () =>
                        {
                            return $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$OCet.LCCSCM.CommunitySchoolSkillSetModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$OCet.LCCSCM.CommunitySchoolSkillSetModel), [ skillSet ], null, null));
                        }, $YuIqwd ??= {"r":$.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$($.$OCet.LCCSCM.CommunitySchoolSkillSetModel)).$h,"n":"","d":484743,"h":0,"f":17825794}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                        {
                            return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                        }, $LWHGNg ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":484743,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(154619307399)
            
            //--TRIMMABLE-BOUNDARY-START(158914274695)
            /*ValueTask *//*async*/  NewSkillSets()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914274695);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.grade !== null && this.subject !== null)
                    {
                        let $t8, $r8;
                        let $t9, $r9;
                        /*var*/ let skillSet = ($t8 = $.$hDPm.LCFCI.ViewPresenterExtensions.Input($.$hDPm.LCFCI.ViewConfiguration, $.$$.S.String, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "New SkillSets", false), null, null, 16n, null, 0, 4, 4131, null, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        /*var*/ let sets = $.$$.S.String.Split$4.call(skillSet, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*\r*/ 13, /*\n*/ 10], null, null), 1/*StringSplitOptions.RemoveEmptyEntries*/);
                        ($t9 = $.$vWqU.LCFCC.LoadingExtension.Load$1($.$fPer.LCFCD.WireTransportManyModel$$($.$OCet.LCCSCM.CommunitySchoolSkillSetModel), this, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$($.$OCet.LCCSCM.CommunitySchoolSkillSetModel))))().$ctor(this,  () =>
                        {
                            return $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$OCet.LCCSCM.CommunitySchoolSkillSetModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$sl.SL.Enumerable.ToArray($.$OCet.LCCSCM.CommunitySchoolSkillSetModel, $.$sl.SL.Enumerable.Select($.$$.S.String, $.$OCet.LCCSCM.CommunitySchoolSkillSetModel, sets, new ($.$$.S.Func$$$$($.$$.S.String, $.$$.S.Int32, $.$OCet.LCCSCM.CommunitySchoolSkillSetModel))().$ctor(this,  (/*s*/ s, /*i*/ i) =>
                            {
                                return (() =>
                                {
                                    //new $.$OCet.LCCSCM.CommunitySchoolSkillSetModel()
                                    const $t10 = $.$OCet.LCCSCM.CommunitySchoolSkillSetModel;
                                    const $i10 = new $t10();
                                    $i10.$ctor$6();
                                    $i10.Name = s;
                                    $i10.Order = ((i + 1) | 0);
                                    $i10.Grades = $.$$.SRC.RuntimeHelpers.CreateArray($.$OCet.LCCSCM.CommunitySchoolGradeModel.$type, [ this.grade ], null, null);
                                    $i10.Subject = this.subject;
                                    return $i10;
                                })();
                            }, $frMIOb ??= {"r":8804037,"p":[{"n":"s","p":1310721},{"n":"i","p":655361}],"n":"","d":484743,"h":0,"f":17825794}))));
                        }, $VtleUj ??= {"r":$.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$($.$OCet.LCCSCM.CommunitySchoolSkillSetModel)).$h,"n":"","d":484743,"h":0,"f":17825794}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                        {
                            return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                        }, $vVdrzb ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":484743,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(158914274695)
            
            //--TRIMMABLE-BOUNDARY-START(47245124999)
            /*Task *//*async*/  ConverSkillToTemplate()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245124999);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.skill !== null && this.skill.Identifier.HasValue && this.subject !== null && !(this.skill !== null && ($.$is(this.skill, $.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel))))
                    {
                        let $t11, $r11;
                        ($t11 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                            {
                                let $t13, $r13;
                                let $t14, $r14;
                                /*var*/ let template = (() =>
                                {
                                    //new $.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel()
                                    const $t12 = $.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel;
                                    const $i12 = new $t12();
                                    $i12.$ctor$9();
                                    $i12.Name = this.skill.Name;
                                    $i12.Post = this.skill.Post;
                                    $i12.Properties = this.skill.Properties;
                                    $i12.Subject = this.subject;
                                    $i12.Repeat = $.$with(this.skill.Repeat, ($clone) =>
                                    {
                                        $clone.Value = 1;
                                    });
                                    return $i12;
                                })();
                                /*var*/ let temp = $.$sl.SL.Enumerable.First$1($.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel, (($t13 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel), [ template ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)))).Data);
                                this.skill.Post = temp.Import;
                                ($t14 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$OCet.LCCSCM.CommunitySchoolSkillBaseModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$OCet.LCCSCM.CommunitySchoolSkillBaseModel), [ this.skill ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                                this.skill = (() =>
                                {
                                    //new $.$OCet.LCCSCM.CommunitySchoolSkillModel()
                                    const $t15 = $.$OCet.LCCSCM.CommunitySchoolSkillModel;
                                    const $i15 = new $t15();
                                    $i15.$ctor$9();
                                    $i15.Identifier = this.skill.Identifier;
                                    $i15.Name = this.skill.Name;
                                    $i15.Post = this.skill.Post;
                                    $i15.Properties = this.skill.Properties;
                                    return $i15;
                                })();
                            });
                        }, $hMcWEi ??= {"r":181338113,"n":"","d":484743,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                        {
                            return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                        }, $FiKWsj ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":484743,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47245124999)
            
            //--TRIMMABLE-BOUNDARY-START(51540092295)
            /*void */ Field(/*IObservableDataDescriptor*/ field)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540092295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                field.LCFCR$IReactiveObservable$Subscribe(new ($.$$.S.Action$$$($.$fPer.LCFCR.IReactiveObservable, $.$fPer.LCFCR.IReactiveObservableChanges))().$ctor(this,  (/*f*/ f, /*c*/ c) =>
                {
                    this.skillContext = null;
                    _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.School.Client.Admin.Blazor\\CreateSkill.razor.cs", "Field", 283);
                }, $SQEfih ??= {"r":65537,"p":[{"n":"f","p":54167894},{"n":"c","p":54298966}],"n":"","d":484743,"h":0,"f":17825794}), null, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(51540092295)
            
            //--TRIMMABLE-BOUNDARY-START(42950157703)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950157703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.UseHierachy !== null)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                    __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                    __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                    __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(4, "div");
                        __builder2.AddAttribute$5(5, "class", "hv-10 stack");
                        __builder2.OpenComponent$1($.$macw.MACF.EditForm, 6);
                        __builder2.AddComponentParameter(7, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                        __builder2.AddComponentParameter(8, "class", "pd bg-card bdb flex");
                        __builder2.AddAttribute$3(9, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*__*/ __) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenElement(10, "h2");
                                __builder3.AddAttribute$5(11, "class", "mgy-a mgr");
                                __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 12, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToggleSkillType)));
                                __builder3.AddContent$4(13, "Skill ");
                                __builder3.AddContent$4(14, this.isSkillTemplate ? "Template" : "");
                                __builder3.AddContent$4(15, " Editor");
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(16, "\r\n                ");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$($.$fPer.LCFCD.IChildrenHierachy), 17);
                                __builder3.AddComponentParameter(18, "Options", ($.$fPer.LCFCD.Paging.GetPager($.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCD.IChildrenHierachy), this.UseHierachy, null)));
                                __builder3.AddComponentParameter(19, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.InputType, 22n), $.$fPer.LCFC.InputType));
                                __builder3.AddComponentParameter(20, "Class", "fill mgy-a");
                                __builder3.AddComponentParameter(21, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.IChildrenHierachy, this.SelectedHierachy));
                                __builder3.AddComponentParameter(22, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$fPer.LCFCD.IChildrenHierachy), $.$mac.MAC.EventCallback.Factory.Create$6($.$fPer.LCFCD.IChildrenHierachy, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$fPer.LCFCD.IChildrenHierachy, this, new ($.$$.S.Action$$($.$fPer.LCFCD.IChildrenHierachy))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.SelectedHierachy = __value;
                                }, $bBYOCg ??= {"r":65537,"p":[{"n":"__value","p":15960406}],"n":"","d":484743,"h":0,"f":17825794}), this.SelectedHierachy))));
                                __builder3.AddComponentParameter(23, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$fPer.LCFCD.IChildrenHierachy)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "SelectedHierachy"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $frpcrk ??= {"r":38797349,"n":"","d":484743,"h":0,"f":17825794})).Invoke())));
                                __builder3.SetKey(this.UseHierachy);
                                __builder3.CloseComponent();
                                if (!this.isSkillTemplate && this.grade !== null && this.subject !== null)
                                {
                                    __builder3.OpenElement(24, "popup");
                                    __builder3.AddAttribute$5(25, "class", "pos-rel");
                                    __builder3.AddMarkupContent(26, "<button class=\"mgl pd corner shadow bg-primary mgy-a\">New SkillSet</button>\r\n                        ");
                                    __builder3.OpenElement(27, "pop");
                                    __builder3.AddAttribute$5(28, "class", "at righttoright toptobottom bg-card");
                                    __builder3.OpenElement(29, "ul");
                                    __builder3.AddAttribute$5(30, "class", "reset menu vh");
                                    __builder3.OpenElement(31, "li");
                                    __builder3.AddAttribute$5(32, "class", "menuitem");
                                    __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 33, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.NewSkillSet)));
                                    __builder3.AddMarkupContent(34, "\r\n                                    Single SkillSet\r\n                                ");
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(35, "\r\n                                ");
                                    __builder3.OpenElement(36, "li");
                                    __builder3.AddAttribute$5(37, "class", "menuitem");
                                    __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 38, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.NewSkillSets)));
                                    __builder3.AddMarkupContent(39, "\r\n                                    Batch SkillSet\r\n                                ");
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }
                                if (!this.isSkillTemplate)
                                {
                                    __builder3.OpenElement(40, "button");
                                    __builder3.AddAttribute$5(41, "class", "corner mgl bg-transparent mgy-a mdi mdi-plus");
                                    __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 42, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.NewSkill)));
                                    __builder3.CloseElement();
                                }
                            }, $PfNguc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":484743,"h":0,"f":17825794});
                        }), $RInSqc ??= {"r":6881395,"p":[{"n":"__","p":131188}],"n":"","d":484743,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        if (this.skill !== null && (!this.isSkillTemplate || (this.isSkillTemplate && this.subject !== null)))
                        {
                            __builder2.OpenComponent$1($.$awPs.LCCSCS$1.SkillEditor, 43);
                            __builder2.AddComponentParameter(44, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OCet.LCCSCM.CommunitySchoolSkillBaseModel, this.skill));
                            __builder2.AddComponentParameter(45, "Grade", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OCet.LCCSCM.CommunitySchoolGradeModel, this.grade));
                            __builder2.AddComponentParameter(46, "Subject", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel, this.subject));
                            __builder2.AddComponentParameter(47, "SkillSet", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OCet.LCCSCM.CommunitySchoolSkillSetModel, this.skillSet));
                            __builder2.AddComponentParameter(48, "Scope", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OCet.LCCSCM.ICommunitySchoolScope, null));
                            __builder2.AddAttribute$3(49, "ToolBar", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenElement(50, "h3");
                                __builder3.AddAttribute$5(51, "class", "fill mgy-a nowrap");
                                if ((this.skill?.Identifier.HasValue ?? null) ?? false)
                                {
                                    __builder3.AddMarkupContent(52, "\r\n                                    Edit Skill\r\n");
                                    if (this.isSkillTemplate)
                                    {
                                        __builder3.AddContent$4(53, "Template");
                                    }
                                    __builder3.AddContent$4(54, "                                    (");
                                    __builder3.AddContent$4(55, this.skill.Title);
                                    __builder3.AddMarkupContent(56, ")\r\n                                ");
                                }
                                else 
                                {
                                    __builder3.AddMarkupContent(57, "\r\n                                    New Skill\r\n                                ");
                                }
                                __builder3.CloseElement();
                                if ((this.skill?.Identifier.HasValue ?? null) ?? false)
                                {
                                    if (!this.isSkillTemplate && this.skill.Post !== null && !$.$$.S.String.Contains$3.call(this.skill.Post, "{import("))
                                    {
                                        __builder3.OpenElement(58, "button");
                                        __builder3.AddAttribute$5(59, "class", "corner bg-transparent mgy-a mdi mdi-tag");
                                        __builder3.AddAttribute$5(60, "title", "Convert to Template");
                                        __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 61, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ConverSkillToTemplate)));
                                        __builder3.CloseElement();
                                    }
                                }
                            }), $GCIbsh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":484743,"h":0,"f":17825794}));
                            __builder2.SetKey(this.skill);
                            __builder2.CloseComponent();
                        }
                        __builder2.CloseElement();
                    }), $zFWFSh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":484743,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950157703)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(4318975658)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.FormBuilder.IFormFieldEditController.Field(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor)
            LCFCCF$2$IFormFieldEditController$Field()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4318975658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Field(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4318975658)
            
            //--TRIMMABLE-BOUNDARY-START(25770288519)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770288519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770288519)
            
            //--TRIMMABLE-BOUNDARY-START(25770288519)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25770288519)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(193274013063)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(193274013063)
                
                //--TRIMMABLE-BOUNDARY-START(38655190407)
                this.Assets$1 = null;
                //--TRIMMABLE-BOUNDARY-END(38655190407)
                
                //--TRIMMABLE-BOUNDARY-START(283468326279)
                this.TokenResolver = null;
                //--TRIMMABLE-BOUNDARY-END(283468326279)
                
                //--TRIMMABLE-BOUNDARY-START(249108587911)
                this.skill = new $.$OCet.LCCSCM.CommunitySchoolSkillModel().$ctor$9();
                //--TRIMMABLE-BOUNDARY-END(249108587911)
                
                //--TRIMMABLE-BOUNDARY-START(146029372807)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(146029372807)
                
            }
            static $h = 484743;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(167504209287),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899830663,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 484743,
      "h": 167504209287,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(167504209287),
//--TRIMMABLE-BOUNDARY-START(193274013063),
    {
      "p": 2224851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079699847,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236223686023,
        "f": 83886081
      },
      "n": "Service",
      "d": 484743,
      "h": 193274013063,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193274013063),
//--TRIMMABLE-BOUNDARY-START(38655190407),
    {
      "p": 61691562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130026887,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201863947655,
        "f": 83886081
      },
      "n": "Assets",
      "o": "@$1",
      "d": 484743,
      "h": 38655190407,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655190407),
//--TRIMMABLE-BOUNDARY-START(283468326279),
    {
      "p": 1476860,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669634439,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244813620615,
        "f": 83886081
      },
      "n": "TokenResolver",
      "d": 484743,
      "h": 283468326279,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(283468326279),
//--TRIMMABLE-BOUNDARY-START(287763293575),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCD.IChildrenHierachy)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259569031,
        "f": 50331650
      },
      "n": "UseHierachy",
      "d": 484743,
      "h": 287763293575,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(287763293575),
//--TRIMMABLE-BOUNDARY-START(188979045767),
    {
      "p": 15960406,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489765255,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227633751431,
        "f": 83886082
      },
      "n": "SelectedHierachy",
      "d": 484743,
      "h": 188979045767,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(188979045767),
//--TRIMMABLE-BOUNDARY-START(146029372807),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309896071,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219043816839,
        "f": 83886081
      },
      "n": "Loading",
      "d": 484743,
      "h": 146029372807,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146029372807),
//--TRIMMABLE-BOUNDARY-START(141734405511),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719961479,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210453882247,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 484743,
      "h": 141734405511,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734405511)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849503623),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 484743,
      "h": 128849503623,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128849503623),
//--TRIMMABLE-BOUNDARY-START(279173358983),
    {
      "r": 65537,
      "n": "ToggleSkillType",
      "d": 484743,
      "h": 279173358983,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(279173358983),
//--TRIMMABLE-BOUNDARY-START(163209241991),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 484743,
      "h": 163209241991,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(163209241991),
//--TRIMMABLE-BOUNDARY-START(137439438215),
    {
      "r": 181338113,
      "n": "Load",
      "d": 484743,
      "h": 137439438215,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439438215),
//--TRIMMABLE-BOUNDARY-START(150324340103),
    {
      "r": 65537,
      "n": "NewSkill",
      "d": 484743,
      "h": 150324340103,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(150324340103),
//--TRIMMABLE-BOUNDARY-START(154619307399),
    {
      "r": 181338113,
      "n": "NewSkillSet",
      "d": 484743,
      "h": 154619307399,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(154619307399),
//--TRIMMABLE-BOUNDARY-START(158914274695),
    {
      "r": 181338113,
      "n": "NewSkillSets",
      "d": 484743,
      "h": 158914274695,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(158914274695),
//--TRIMMABLE-BOUNDARY-START(47245124999),
    {
      "r": 178454529,
      "n": "ConverSkillToTemplate",
      "d": 484743,
      "h": 47245124999,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(47245124999),
//--TRIMMABLE-BOUNDARY-START(51540092295),
    {
      "r": 65537,
      "p": [
        {
          "n": "field",
          "p": 40536406
        }
      ],
      "n": "Field",
      "d": 484743,
      "h": 51540092295,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540092295),
//--TRIMMABLE-BOUNDARY-START(42950157703),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 484743,
      "h": 42950157703,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(42950157703)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(133144470919),
    {
      "t": 262145,
      "n": "isSkillTemplate",
      "d": 484743,
      "h": 133144470919,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(133144470919),
//--TRIMMABLE-BOUNDARY-START(261993489799),
    {
      "t": $.$$.SCG.IEnumerable$$($.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCD.IChildrenHierachy)).$h,
      "n": "skillHierachy",
      "d": 484743,
      "h": 261993489799,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(261993489799),
//--TRIMMABLE-BOUNDARY-START(270583424391),
    {
      "t": $.$$.SCG.IEnumerable$$($.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCD.IChildrenHierachy)).$h,
      "n": "skillTemplateHierachy",
      "d": 484743,
      "h": 270583424391,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(270583424391),
//--TRIMMABLE-BOUNDARY-START(249108587911),
    {
      "t": 6117061,
      "n": "skill",
      "d": 484743,
      "h": 249108587911,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(249108587911),
//--TRIMMABLE-BOUNDARY-START(266288457095),
    {
      "t": 8804037,
      "n": "skillSet",
      "d": 484743,
      "h": 266288457095,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(266288457095),
//--TRIMMABLE-BOUNDARY-START(274878391687),
    {
      "t": 9393861,
      "n": "subject",
      "d": 484743,
      "h": 274878391687,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(274878391687),
//--TRIMMABLE-BOUNDARY-START(124554536327),
    {
      "t": 2905797,
      "n": "grade",
      "d": 484743,
      "h": 124554536327,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124554536327),
//--TRIMMABLE-BOUNDARY-START(253403555207),
    {
      "t": 11032261,
      "n": "skillContext",
      "d": 484743,
      "h": 253403555207,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(253403555207),
//--TRIMMABLE-BOUNDARY-START(184684078471),
    {
      "t": 15960406,
      "n": "selectedHierachy",
      "d": 484743,
      "h": 184684078471,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(184684078471),
//--TRIMMABLE-BOUNDARY-START(257698522503),
    {
      "t": $.$hDPm.LCFCCF$2.FormBuilder$$($.$OCet.LCCSCM.CommunitySchoolSkillModel).$h,
      "n": "skillForm",
      "d": 484743,
      "h": 257698522503,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(257698522503)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770288519),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 484743,
      "h": 25770288519,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770288519)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(171799176583),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 484743,
        "h": 34360223111,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 484743,
        "h": 180389111175,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 484743,
      "h": 171799176583,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(171799176583)
  ],
  "h": 484743,
  "a": [
    {
      "t": 917616,
      "c": 17180786800,
      "n": [
        {
          "n": "Roles",
          "v": "SuperAdmin,School.Admin,School.Editor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/School/CreateSkill",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$hDPm.LCFCCF$2.IFormFieldEditController, $.$hDPm.LCFCCF$2.IFormController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.School.Client.Admin.Pages.CreateSkill`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}School${separator}Client${separator}Admin${separator}Pages${separator}CreateSkill`; }
        });
        //--TRIMMABLE-BOUNDARY-END(484743)
        
        

        //--TRIMMABLE-BOUNDARY-START(419207)
        $asm.$cls(`$bfaB.LCCSCAP.Admin`, ($self) => class Admin extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(231928653191)
            /*string */ get OptimizedComponentName()
            {
                return "admin";
            }
            //--TRIMMABLE-BOUNDARY-END(231928653191)
            
            //--TRIMMABLE-BOUNDARY-START(399432377735)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432377735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "BasePath":
                    this.BasePath = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(399432377735)
            
            //--TRIMMABLE-BOUNDARY-START(206158849415)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158849415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$awPs.LCCSCS.CommunitySchoolService, serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Rendering = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IUIRenderingProvider, serviceProvider);
                this.UI = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientService, serviceProvider);
                this.Assets$1 = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCH.IAssetsCollection, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
                this.Player = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFCS$3.IMediaPlayer, serviceProvider);
                this.TokenResolver = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(206158849415)
            
            //--TRIMMABLE-BOUNDARY-START(236223620487)
            /*string*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(236223620487)
            
            //--TRIMMABLE-BOUNDARY-START(73014863239)
            /*string?*/ BasePath = null;
            //--TRIMMABLE-BOUNDARY-END(73014863239)
            
            //--TRIMMABLE-BOUNDARY-START(270583358855)
            /*CommunitySchoolService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(270583358855)
            
            //--TRIMMABLE-BOUNDARY-START(266288391559)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(266288391559)
            
            //--TRIMMABLE-BOUNDARY-START(261993424263)
            /*IUIRenderingProvider*/ Rendering = null;
            //--TRIMMABLE-BOUNDARY-END(261993424263)
            
            //--TRIMMABLE-BOUNDARY-START(403727345031)
            /*IUIClientService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(403727345031)
            
            //--TRIMMABLE-BOUNDARY-START(68719895943)
            /*IAssetsCollection*/ Assets$1 = null;
            //--TRIMMABLE-BOUNDARY-END(68719895943)
            
            //--TRIMMABLE-BOUNDARY-START(223338718599)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(223338718599)
            
            //--TRIMMABLE-BOUNDARY-START(240518587783)
            /*IMediaPlayer*/ Player = null;
            //--TRIMMABLE-BOUNDARY-END(240518587783)
            
            //--TRIMMABLE-BOUNDARY-START(395137410439)
            /*MarkdownPlusTokenMethodResolverFactory*/ TokenResolver = null;
            //--TRIMMABLE-BOUNDARY-END(395137410439)
            
            //--TRIMMABLE-BOUNDARY-START(219043751303)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(219043751303)
            
            //--TRIMMABLE-BOUNDARY-START(214748784007)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214748784007)
            
            //--TRIMMABLE-BOUNDARY-START(249108522375)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(249108522375)
            
            //--TRIMMABLE-BOUNDARY-START(249108522375)
            //--TRIMMABLE-BOUNDARY-START(64424928647)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424928647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(64424928647)
            
            //--TRIMMABLE-BOUNDARY-START(257698456967)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698456967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(257698456967)
            
            //--TRIMMABLE-BOUNDARY-END(249108522375)
            
            //--TRIMMABLE-BOUNDARY-START(386547475847)
            /*DashboardTable<CommunitySchoolSkillModel>?*/ skillTable = null;
            //--TRIMMABLE-BOUNDARY-END(386547475847)
            
            //--TRIMMABLE-BOUNDARY-START(382252508551)
            /*CommunitySchoolSkillPlayerContext?*/ skillContext = null;
            //--TRIMMABLE-BOUNDARY-END(382252508551)
            
            //--TRIMMABLE-BOUNDARY-START(377957541255)
            /*bool*/ showSkillPreview = false;
            //--TRIMMABLE-BOUNDARY-END(377957541255)
            
            //--TRIMMABLE-BOUNDARY-START(390842443143)
            /*Task *//*async*/  ToggleSkillPreview()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(390842443143);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.showSkillPreview && (this.skillTable?.Current ?? null) !== null)
                    {
                        let $t2, $r2;
                        ($t2 = $.$vWqU.LCFCR.DataModelExtension.EnsureHasProperties($.$OCet.LCCSCM.CommunitySchoolSkillModel, this.skillTable.Current, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "*" ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    this.showSkillPreview = !this.showSkillPreview;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(390842443143)
            
            //--TRIMMABLE-BOUNDARY-START(197568914823)
            /*T? */ GetProperty(TTable, T, /*IObservableDataDescriptor*/ target, /*T?*/ prefered)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568914823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let ft;
                if ($.$is(prefered, $.$hDPm.LCFCCD$1.DataListFeatures, { set $v($v){ ft = $v; } }))
                {
                    return $.$cast($.$box((ft | 131072n | 34359738368n), $.$hDPm.LCFCCD$1.DataListFeatures), T);
                }
                return $.$LCOv.LCFCP.PostUtility.GetCommunityDashboardTableProperty(TTable, T, target, prefered, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server);
            }
            //--TRIMMABLE-BOUNDARY-END(197568914823)
            
            //--TRIMMABLE-BOUNDARY-START(201863882119)
            /*ValueTask<object> */ GetPropertyValue(/*IObservableDataDescriptor*/ target, /*IPropertyDescriptor*/ property)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863882119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(201863882119)
            
            //--TRIMMABLE-BOUNDARY-START(244813555079)
            /*ValueTask<T?> */ PrepareItemFor(T, /*T?*/ item, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813555079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let id;
                if (($.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 4096/*SchemaType.Details*/ || $.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 1/*SchemaType.Form*/) && $.$is(item, $.$fPer.LCFCD.IIded, { set $v($v){ id = $v; } }) && id.LCFCD$IIded$Identifier.HasValue)
                {
                    return $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle(T, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$6(id.LCFCD$IIded$Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1213860839096383n | 4194304n | 4503599627370496n | 16777216n | 17592186044416n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), null);
                }
                return $.$$.STT.ValueTask.FromResult(T, item);
            }
            //--TRIMMABLE-BOUNDARY-END(244813555079)
            
            //--TRIMMABLE-BOUNDARY-START(227633685895)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227633685895);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    _ = this.Assets$1.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResourcePathResolver.LCFCC$IResourcePathResolver$Resolve("LivingThing.Core.Community.School.Client.Blazor", "LivingThing.Core.Community.School.Client.Blazor.css", false) ], null, null));
                    if (!this.Rendering.LCFCC$IUIRenderingProvider$IsPreRendering)
                    {
                        let $t3, $r3;
                        ($t3 = $.$vWqU.LCFCC.LoadingExtension.EnsureLoaded(this.Service, true), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                    ($t4 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(227633685895)
            
            //--TRIMMABLE-BOUNDARY-START(81604797831)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604797831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.skillContext?.Dispose();
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(81604797831)
            
            //--TRIMMABLE-BOUNDARY-START(210453816711)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453816711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(210453816711)
            
            //--TRIMMABLE-BOUNDARY-START(77309830535)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309830535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    $.$bfaB._LCCSCAPA.TypeInference.CreateCascadingValue_0($.$bfaB.LCCSCAP.Admin, __builder2, 4, 5, this, 6, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.Application, 7);
                        __builder3.AddComponentParameter(8, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(this.BasePath ?? "Admin/School")));
                        __builder3.AddComponentParameter(9, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                        __builder3.AddComponentParameter(10, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, (1125027/*ApplicationFeatures.Default*/ & ~(this.UnitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$Runtime.Type === 6/*RuntimeType.DesktopApp*/ ? 2/*ApplicationFeatures.Authorization*/ : 0/*ApplicationFeatures.None*/)) | 128/*ApplicationFeatures.ToolBarBorder*/ | 2048/*ApplicationFeatures.LeftSideBarBorder*/), $.$lJUR.LCFCS.ApplicationFeatures));
                        __builder3.AddAttribute$3(11, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(12, "<i class=\"mdi mdi-package cl-error\"></i>");
                            }, $ftCrsc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                        }), $KJOwac ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                        {
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 14);
                            __builder4.AddComponentParameter(15, "Name", "");
                            __builder4.AddComponentParameter(16, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("**"/*RoutePath.ZeroOrMorePathSegment*/)));
                            __builder4.AddComponentParameter(17, "Class", "pd");
                            __builder4.AddAttribute$3(18, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(19, "Dashboard");
                                }, $nZaXwj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $STErUi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(20, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(21, "<i class=\"mdi mdi-package\"></i>");
                                }, $lRnzki ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $BKlSlh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(22, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder5) =>
                                {
                                }, $msTdZj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $uFQEEa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(23, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 24);
                            __builder4.AddComponentParameter(25, "Name", "Coaches");
                            __builder4.AddComponentParameter(26, "Class", "pd");
                            __builder4.AddAttribute$3(27, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(28, "Coaches");
                                }, $vFSyik ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $ioMPtj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(29, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(30, "<i class=\"mdi mdi-road-variant\"></i>");
                                }, $xuZnfa ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $NIsUCc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(31, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$OCet.LCCSCM.CommunitySchoolCoachingSchoolAccountModel), 32);
                                    __builder5.AddComponentParameter(33, "ItemName", "Coach");
                                    __builder5.AddComponentParameter(34, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder5.AddComponentParameter(35, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (27073296294678532n & ~4096n) | 140737488355328n | 64n | 32n | 128n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                    __builder5.AddComponentParameter(36, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, (7616/*DashboardTableFeatures.Default*/ | 8192/*DashboardTableFeatures.FillPage*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/) & ~128/*DashboardTableFeatures.DetailsToDrawer*/ & ~4096/*DashboardTableFeatures.TitleBar*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(37, "DataListFilterFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFilterFeatures, 0/*DataListFilterFeatures.Default*/ | 1/*DataListFilterFeatures.Query*/), $.$hDPm.LCFCCD$1.DataListFilterFeatures));
                                    __builder5.CloseComponent();
                                }, $wMkHnk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $fETpBi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(38, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 39);
                            __builder4.AddComponentParameter(40, "Name", "Courses");
                            __builder4.AddComponentParameter(41, "Class", "pd");
                            __builder4.AddAttribute$3(42, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(43, "Courses");
                                }, $eQAkDd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $nFPGYc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(44, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(45, "<i class=\"mdi mdi-road-variant\"></i>");
                                }, $LzMsOi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $SBNBka ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(46, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$OCet.LCCSCM.CommunitySchoolCoachingCourseModel), 47);
                                    __builder5.AddComponentParameter(48, "ItemName", "Course");
                                    __builder5.AddComponentParameter(49, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder5.AddComponentParameter(50, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (27073296294678532n & ~4096n) | 140737488355328n | 64n | 32n | 128n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                    __builder5.AddComponentParameter(51, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, (7616/*DashboardTableFeatures.Default*/ | 8192/*DashboardTableFeatures.FillPage*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/) & ~128/*DashboardTableFeatures.DetailsToDrawer*/ & ~4096/*DashboardTableFeatures.TitleBar*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(52, "DataListFilterFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFilterFeatures, 0/*DataListFilterFeatures.Default*/ | 1/*DataListFilterFeatures.Query*/), $.$hDPm.LCFCCD$1.DataListFilterFeatures));
                                    __builder5.CloseComponent();
                                }, $romaOb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $GBbvqg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(53, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 54);
                            __builder4.AddComponentParameter(55, "Name", "Grades");
                            __builder4.AddComponentParameter(56, "Class", "pd");
                            __builder4.AddAttribute$3(57, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(58, "Grades");
                                }, $YsBdnf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $KyLxUe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(59, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(60, "<i class=\"mdi mdi-road-variant\"></i>");
                                }, $nvOnLi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $XMNbGb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(61, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$OCet.LCCSCM.CommunitySchoolGradeModel), 62);
                                    __builder5.AddComponentParameter(63, "ItemName", "Grade");
                                    __builder5.AddComponentParameter(64, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder5.AddComponentParameter(65, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (27073296294678532n & ~4096n) | 140737488355328n | 64n | 32n | 128n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                    __builder5.AddComponentParameter(66, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, (7616/*DashboardTableFeatures.Default*/ | 8192/*DashboardTableFeatures.FillPage*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/) & ~128/*DashboardTableFeatures.DetailsToDrawer*/ & ~4096/*DashboardTableFeatures.TitleBar*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(67, "DataListFilterFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFilterFeatures, 0/*DataListFilterFeatures.Default*/ | 1/*DataListFilterFeatures.Query*/), $.$hDPm.LCFCCD$1.DataListFilterFeatures));
                                    __builder5.CloseComponent();
                                }, $xiJupc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $IhRsUi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(68, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 69);
                            __builder4.AddComponentParameter(70, "Name", "Subjects");
                            __builder4.AddComponentParameter(71, "Class", "pd");
                            __builder4.AddAttribute$3(72, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(73, "Subjects");
                                }, $YIEsph ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $kwAbAf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(74, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(75, "<i class=\"mdi mdi-store\"></i>");
                                }, $KuYVNg ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $BHDTTd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(76, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$OCet.LCCSCM.CommunitySchoolSkillSubjectModel), 77);
                                    __builder5.AddComponentParameter(78, "ItemName", "Subject");
                                    __builder5.AddComponentParameter(79, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder5.AddComponentParameter(80, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (27073296294678532n & ~4096n) | 140737488355328n | 64n | 32n | 128n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                    __builder5.AddComponentParameter(81, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, (7616/*DashboardTableFeatures.Default*/ | 8192/*DashboardTableFeatures.FillPage*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/) & ~128/*DashboardTableFeatures.DetailsToDrawer*/ & ~4096/*DashboardTableFeatures.TitleBar*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(82, "DataListFilterFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFilterFeatures, 0/*DataListFilterFeatures.Default*/ | 1/*DataListFilterFeatures.Query*/), $.$hDPm.LCFCCD$1.DataListFilterFeatures));
                                    __builder5.CloseComponent();
                                }, $puWErj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $bqghOd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(83, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 84);
                            __builder4.AddComponentParameter(85, "Name", "SkillSet");
                            __builder4.AddComponentParameter(86, "Class", "pd");
                            __builder4.AddAttribute$3(87, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(88, "Skill Sets");
                                }, $Rwelhj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $jXEjca ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(89, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(90, "<i class=\"mdi mdi-map-marker\"></i>");
                                }, $cmxize ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $CFGWQi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(91, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$OCet.LCCSCM.CommunitySchoolSkillSetModel), 92);
                                    __builder5.AddComponentParameter(93, "ItemName", "SkillSet");
                                    __builder5.AddComponentParameter(94, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder5.AddComponentParameter(95, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (27073296294678532n & ~4096n) | 140737488355328n | 64n | 32n | 128n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                    __builder5.AddComponentParameter(96, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, (7616/*DashboardTableFeatures.Default*/ | 8192/*DashboardTableFeatures.FillPage*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/) & ~128/*DashboardTableFeatures.DetailsToDrawer*/ & ~4096/*DashboardTableFeatures.TitleBar*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(97, "DataListFilterFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFilterFeatures, 0/*DataListFilterFeatures.Default*/ | 1/*DataListFilterFeatures.Query*/), $.$hDPm.LCFCCD$1.DataListFilterFeatures));
                                    __builder5.CloseComponent();
                                }, $paTfNc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $piAsZg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(98, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 99);
                            __builder4.AddComponentParameter(100, "Name", "SkillTemplate");
                            __builder4.AddComponentParameter(101, "Class", "pd");
                            __builder4.AddAttribute$3(102, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(103, "Skill Template");
                                }, $hMeaZb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $ChCcZj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(104, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(105, "<i class=\"mdi mdi-map-marker\"></i>");
                                }, $LbjMIb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $kdrCZj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(106, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$OCet.LCCSCM.CommunitySchoolSkillTemplateModel), 107);
                                    __builder5.AddComponentParameter(108, "ItemName", "SkillTemplate");
                                    __builder5.AddComponentParameter(109, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder5.AddComponentParameter(110, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (27073296294678532n & ~4096n) | 140737488355328n | 64n | 32n | 128n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                    __builder5.AddComponentParameter(111, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, (7616/*DashboardTableFeatures.Default*/ | 8192/*DashboardTableFeatures.FillPage*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/) & ~128/*DashboardTableFeatures.DetailsToDrawer*/ & ~4096/*DashboardTableFeatures.TitleBar*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(112, "DataListFilterFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFilterFeatures, 0/*DataListFilterFeatures.Default*/ | 1/*DataListFilterFeatures.Query*/), $.$hDPm.LCFCCD$1.DataListFilterFeatures));
                                    __builder5.CloseComponent();
                                }, $LYPvlj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $MPhqgk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(113, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 114);
                            __builder4.AddComponentParameter(115, "Name", "Skills");
                            __builder4.AddComponentParameter(116, "Class", "pd");
                            __builder4.AddAttribute$3(117, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(118, "Skills");
                                }, $npNajj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $iEWOie ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(119, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(120, "<i class=\"mdi mdi-map-marker\"></i>");
                                }, $GOALUd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $njEyEd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(121, "FloatingButtons", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 122);
                                    __builder5.AddComponentParameter(123, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 132178/*ButtonFeatures.FloatingButton*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder5.AddComponentParameter(124, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ToggleSkillPreview))));
                                    __builder5.AddComponentParameter(125, "Class", "mdi mdi-remote-desktop");
                                    __builder5.CloseComponent();
                                }, $XxZXgc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $QTerSj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(126, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$OCet.LCCSCM.CommunitySchoolSkillModel), 127);
                                    __builder5.AddComponentParameter(128, "ItemName", "Skill");
                                    __builder5.AddComponentParameter(129, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder5.AddComponentParameter(130, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (27073296294678532n & ~4096n) | 140737488355328n | 64n | 32n | 128n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                    __builder5.AddComponentParameter(131, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, (7616/*DashboardTableFeatures.Default*/ | 8192/*DashboardTableFeatures.FillPage*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/) & ~128/*DashboardTableFeatures.DetailsToDrawer*/ & ~4096/*DashboardTableFeatures.TitleBar*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(132, "DataListFilterFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFilterFeatures, 0/*DataListFilterFeatures.Default*/ | 1/*DataListFilterFeatures.Query*/), $.$hDPm.LCFCCD$1.DataListFilterFeatures));
                                    __builder5.AddComponentReferenceCapture(133, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                                    {
                                        this.skillTable = $.$cast(__value, $.$hDPm.LCFCCD.DashboardTable$$($.$OCet.LCCSCM.CommunitySchoolSkillModel));
                                    }, $OGwvSe ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":419207,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                }, $bGFQDd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $YSWKWj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(134, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 135);
                            __builder4.AddComponentParameter(136, "Name", "Questions");
                            __builder4.AddComponentParameter(137, "Class", "pd");
                            __builder4.AddAttribute$3(138, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(139, "Questions");
                                }, $FwmzOh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $ahBFPc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(140, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(141, "<i class=\"mdi mdi-map-marker\"></i>");
                                }, $jSZbjb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $GZEQMc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(142, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$OCet.LCCSCM.CommunitySchoolQuestionModel), 143);
                                    __builder5.AddComponentParameter(144, "ItemName", "Question");
                                    __builder5.AddComponentParameter(145, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder5.AddComponentParameter(146, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (27073296294678532n & ~4096n) | 140737488355328n | 64n | 32n | 128n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                    __builder5.AddComponentParameter(147, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, (7616/*DashboardTableFeatures.Default*/ | 8192/*DashboardTableFeatures.FillPage*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/) & ~128/*DashboardTableFeatures.DetailsToDrawer*/ & ~4096/*DashboardTableFeatures.TitleBar*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(148, "DataListFilterFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFilterFeatures, 0/*DataListFilterFeatures.Default*/ | 1/*DataListFilterFeatures.Query*/), $.$hDPm.LCFCCD$1.DataListFilterFeatures));
                                    __builder5.CloseComponent();
                                }, $IXNZBb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $UKcVPh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(149, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 150);
                            __builder4.AddComponentParameter(151, "Name", "Videos");
                            __builder4.AddComponentParameter(152, "Class", "pd");
                            __builder4.AddAttribute$3(153, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(154, "Videos");
                                }, $eQnOil ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $BZNFMi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(155, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(156, "<i class=\"mdi mdi-map-marker\"></i>");
                                }, $UAZpma ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $YaNPkf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(157, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$OCet.LCCSCM.CommunitySchoolLearningVideoModel), 158);
                                    __builder5.AddComponentParameter(159, "ItemName", "Video");
                                    __builder5.AddComponentParameter(160, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder5.AddComponentParameter(161, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (27073296294678532n & ~4096n) | 140737488355328n | 64n | 32n | 128n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                    __builder5.AddComponentParameter(162, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, (7616/*DashboardTableFeatures.Default*/ | 8192/*DashboardTableFeatures.FillPage*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/) & ~128/*DashboardTableFeatures.DetailsToDrawer*/ & ~4096/*DashboardTableFeatures.TitleBar*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(163, "DataListFilterFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFilterFeatures, 0/*DataListFilterFeatures.Default*/ | 1/*DataListFilterFeatures.Query*/), $.$hDPm.LCFCCD$1.DataListFilterFeatures));
                                    __builder5.CloseComponent();
                                }, $cPqnFj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $LPVxmd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(164, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 165);
                            __builder4.AddComponentParameter(166, "Name", "NoteCategories");
                            __builder4.AddComponentParameter(167, "Class", "pd");
                            __builder4.AddAttribute$3(168, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(169, "Note Categories");
                                }, $lDKpPc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $TGjJld ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(170, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(171, "<i class=\"mdi mdi-map-marker\"></i>");
                                }, $HRHltf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $KRelGd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(172, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), 173);
                                    __builder5.AddComponentParameter(174, "ItemName", "Note Category");
                                    __builder5.AddComponentParameter(175, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder5.AddComponentParameter(176, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1196268653051967n | 4503599627370496n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null))));
                                    __builder5.AddComponentParameter(177, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (27073296294678532n & ~4096n) | 140737488355328n | 64n | 32n | 128n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                    __builder5.AddComponentParameter(178, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, (7616/*DashboardTableFeatures.Default*/ | 8192/*DashboardTableFeatures.FillPage*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/) & ~128/*DashboardTableFeatures.DetailsToDrawer*/ & ~4096/*DashboardTableFeatures.TitleBar*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(179, "DataListFilterFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFilterFeatures, 0/*DataListFilterFeatures.Default*/ | 1/*DataListFilterFeatures.Query*/), $.$hDPm.LCFCCD$1.DataListFilterFeatures));
                                    __builder5.CloseComponent();
                                }, $HExbnh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $WXLhCh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(180, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 181);
                            __builder4.AddComponentParameter(182, "Name", "CreateSkill");
                            __builder4.AddAttribute$3(183, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(184, "Create Skill");
                                }, $aounGe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $drFVlh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(185, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(186, "<i class=\"mdi mdi-plus\"></i>");
                                }, $fgGgPf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $XUOPLg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(187, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$bfaB.LCCSCAP.CreateSkill, 188);
                                    __builder5.CloseComponent();
                                }, $ukLJWc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $CafVuj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(189, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 190);
                            __builder4.AddComponentParameter(191, "Name", "SkillAssets");
                            __builder4.AddAttribute$3(192, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(193, "Skill Assets");
                                }, $PeKWle ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $MZTjrd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(194, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(195, "<i class=\"mdi mdi-file\"></i>");
                                }, $bSsVwk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $XrTCMa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(196, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$bfaB.LCCSCAP.SkillAssets, 197);
                                    __builder5.CloseComponent();
                                }, $Kyxxic ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $IOIwCk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(198, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 199);
                            __builder4.AddComponentParameter(200, "Name", "SkillBotHelp");
                            __builder4.AddComponentParameter(201, "Class", "pd");
                            __builder4.AddAttribute$3(202, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(203, "Skill Bot Help");
                                }, $cZuYuc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $PIcaKh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(204, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(205, "<i class=\"mdi mdi-help\"></i>");
                                }, $iceEbc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $aUQrwb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(206, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenElement(207, "SkillBotHelps");
                                    __builder5.CloseElement();
                                }, $CJQtHj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":419207,"h":0,"f":17825794});
                            }), $cLtlHh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":419207,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                        }), $mgzejb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":419207,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                    }, $lGGYBb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":419207,"h":0,"f":17825794}));
                }), $FbOhtk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":419207,"h":0,"f":17825794}));
                __builder.CloseComponent();
                if (this.showSkillPreview && (this.skillTable?.Current ?? null) !== null)
                {
                    if (this.skillContext === null || this.skillContext.Skill !== this.skillTable.Current)
                    {
                        this.skillContext?.Dispose();
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.School.Common.Models.CommunitySchoolGradeModel>?*/ let __ca1__;
                        this.skillContext = (() =>
                        {
                            //new $.$OCet.LCCSCS.CommunitySchoolSkillPlayerContext()
                            const $t5 = $.$OCet.LCCSCS.CommunitySchoolSkillPlayerContext;
                            const $i5 = new $t5();
                            $i5.$ctor$4(this.UnitOfWork.LCFCI$IClientUnitOfWork$ServiceProvider, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, this.UnitOfWork.LCFCI$IClientUnitOfWork$Cache, this.skillTable.Current, this.TokenResolver);
                            $i5.IsEditor = true;
                            $i5.Grade = ((__ca1__ = this.skillTable.Current.Grades) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$OCet.LCCSCM.CommunitySchoolGradeModel, __ca1__) : null);
                            $i5.MediaPlayer = this.Player;
                            return $i5;
                        })();
                    }
                    __builder.OpenElement(208, "div");
                    __builder.AddAttribute$5(209, "class", "pos-abs b-0 r-0");
                    __builder.OpenComponent$1($.$awPs.LCCSCS$1.LiveQA, 210);
                    __builder.AddComponentParameter(211, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCO.OneOf$$$($.$OCet.LCCSCS.CommunitySchoolSkillPlayerContext, $.$OCet.LCCSCS.ICommunitySchoolQuestionAnswerStore), $.$fPer.LCFCO.OneOf$$$($.$OCet.LCCSCS.CommunitySchoolSkillPlayerContext, $.$OCet.LCCSCS.ICommunitySchoolQuestionAnswerStore).op_Implicit(this.skillContext)));
                    __builder.AddComponentParameter(212, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$awPs.LCCSCS$1.LiveQAFeatures, 1/*LiveQAFeatures.AutoStart*/), $.$awPs.LCCSCS$1.LiveQAFeatures));
                    __builder.SetKey(this.skillContext);
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309830535)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4308162218)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableProvider.GetProperty<TTable, TValue>(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor?, TValue?)
            LCFCCD$IDashboardTableProvider$GetProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4308162218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4308162218)
            
            //--TRIMMABLE-BOUNDARY-START(4313077418)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListPrepareItemController.PrepareItemFor<T>(T?, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCCD$1$IDataListPrepareItemController$PrepareItemFor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313077418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PrepareItemFor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313077418)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(55834994055)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834994055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55834994055)
            
            //--TRIMMABLE-BOUNDARY-START(55834994055)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(55834994055)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(270583358855)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(270583358855)
                
                //--TRIMMABLE-BOUNDARY-START(266288391559)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(266288391559)
                
                //--TRIMMABLE-BOUNDARY-START(261993424263)
                this.Rendering = null;
                //--TRIMMABLE-BOUNDARY-END(261993424263)
                
                //--TRIMMABLE-BOUNDARY-START(403727345031)
                this.UI = null;
                //--TRIMMABLE-BOUNDARY-END(403727345031)
                
                //--TRIMMABLE-BOUNDARY-START(68719895943)
                this.Assets$1 = null;
                //--TRIMMABLE-BOUNDARY-END(68719895943)
                
                //--TRIMMABLE-BOUNDARY-START(223338718599)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(223338718599)
                
                //--TRIMMABLE-BOUNDARY-START(240518587783)
                this.Player = null;
                //--TRIMMABLE-BOUNDARY-END(240518587783)
                
                //--TRIMMABLE-BOUNDARY-START(395137410439)
                this.TokenResolver = null;
                //--TRIMMABLE-BOUNDARY-END(395137410439)
                
                //--TRIMMABLE-BOUNDARY-START(219043751303)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(219043751303)
                
            }
            static $h = 419207;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(231928653191),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144405383,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 419207,
      "h": 231928653191,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(231928653191),
//--TRIMMABLE-BOUNDARY-START(236223620487),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734339975,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322122966407,
        "f": 83886081
      },
      "n": "Page",
      "d": 419207,
      "h": 236223620487,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236223620487),
//--TRIMMABLE-BOUNDARY-START(73014863239),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784667015,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763228039,
        "f": 83886081
      },
      "n": "BasePath",
      "d": 419207,
      "h": 73014863239,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73014863239),
//--TRIMMABLE-BOUNDARY-START(270583358855),
    {
      "p": 2224851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094078343,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356482704775,
        "f": 83886081
      },
      "n": "Service",
      "d": 419207,
      "h": 270583358855,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(270583358855),
//--TRIMMABLE-BOUNDARY-START(266288391559),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504143751,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347892770183,
        "f": 83886081
      },
      "n": "Server",
      "d": 419207,
      "h": 266288391559,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(266288391559),
//--TRIMMABLE-BOUNDARY-START(261993424263),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914209159,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339302835591,
        "f": 83886081
      },
      "n": "Rendering",
      "d": 419207,
      "h": 261993424263,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(261993424263),
//--TRIMMABLE-BOUNDARY-START(403727345031),
    {
      "p": 65492650,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193273947527,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 373662573959,
        "f": 83886081
      },
      "n": "UI",
      "d": 419207,
      "h": 403727345031,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(403727345031),
//--TRIMMABLE-BOUNDARY-START(68719895943),
    {
      "p": 61691562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194732423,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279173293447,
        "f": 83886081
      },
      "n": "Assets",
      "o": "@$1",
      "d": 419207,
      "h": 68719895943,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719895943),
//--TRIMMABLE-BOUNDARY-START(223338718599),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554470791,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313533031815,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 419207,
      "h": 223338718599,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223338718599),
//--TRIMMABLE-BOUNDARY-START(240518587783),
    {
      "p": 61704534,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324274567,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330712900999,
        "f": 83886081
      },
      "n": "Player",
      "d": 419207,
      "h": 240518587783,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(240518587783),
//--TRIMMABLE-BOUNDARY-START(395137410439),
    {
      "p": 1476860,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684012935,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 365072639367,
        "f": 83886081
      },
      "n": "TokenResolver",
      "d": 419207,
      "h": 395137410439,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(395137410439),
//--TRIMMABLE-BOUNDARY-START(219043751303),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964536199,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943097223,
        "f": 83886081
      },
      "n": "Loading",
      "d": 419207,
      "h": 219043751303,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219043751303),
//--TRIMMABLE-BOUNDARY-START(214748784007),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374601607,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353162631,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 419207,
      "h": 214748784007,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214748784007)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(399432377735),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 419207,
      "h": 399432377735,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(399432377735),
//--TRIMMABLE-BOUNDARY-START(206158849415),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 419207,
      "h": 206158849415,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(206158849415),
//--TRIMMABLE-BOUNDARY-START(390842443143),
    {
      "r": 178454529,
      "n": "ToggleSkillPreview",
      "d": 419207,
      "h": 390842443143,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(390842443143),
//--TRIMMABLE-BOUNDARY-START(197568914823),
    {
      "r": (TTable, T) => T.$h,
      "p": [
        {
          "n": "target",
          "p": 40536406
        },
        {
          "n": "prefered",
          "p": (TTable, T) => T.$h
        }
      ],
      "g": [
        "TTable",
        "T"
      ],
      "n": "GetProperty",
      "d": 419207,
      "h": 197568914823,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(197568914823),
//--TRIMMABLE-BOUNDARY-START(201863882119),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "target",
          "p": 40536406
        },
        {
          "n": "property",
          "p": 40733014
        }
      ],
      "n": "GetPropertyValue",
      "d": 419207,
      "h": 201863882119,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201863882119),
//--TRIMMABLE-BOUNDARY-START(244813555079),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "item",
          "p": (T) => T.$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "g": [
        "T"
      ],
      "n": "PrepareItemFor",
      "d": 419207,
      "h": 244813555079,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(244813555079),
//--TRIMMABLE-BOUNDARY-START(227633685895),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 419207,
      "h": 227633685895,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(227633685895),
//--TRIMMABLE-BOUNDARY-START(81604797831),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 419207,
      "h": 81604797831,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604797831),
//--TRIMMABLE-BOUNDARY-START(210453816711),
    {
      "r": 181338113,
      "n": "Load",
      "d": 419207,
      "h": 210453816711,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210453816711),
//--TRIMMABLE-BOUNDARY-START(77309830535),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 419207,
      "h": 77309830535,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(77309830535)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(386547475847),
    {
      "t": $.$hDPm.LCFCCD.DashboardTable$$($.$OCet.LCCSCM.CommunitySchoolSkillModel).$h,
      "n": "skillTable",
      "d": 419207,
      "h": 386547475847,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(386547475847),
//--TRIMMABLE-BOUNDARY-START(382252508551),
    {
      "t": 11032261,
      "n": "skillContext",
      "d": 419207,
      "h": 382252508551,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(382252508551),
//--TRIMMABLE-BOUNDARY-START(377957541255),
    {
      "t": 262145,
      "n": "showSkillPreview",
      "d": 419207,
      "h": 377957541255,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(377957541255)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55834994055),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 419207,
      "h": 55834994055,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834994055)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(249108522375),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 419207,
        "h": 64424928647,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 419207,
        "h": 257698456967,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 419207,
      "h": 249108522375,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(249108522375)
  ],
  "h": 419207,
  "a": [
    {
      "t": 917616,
      "c": 17180786800,
      "n": [
        {
          "n": "Roles",
          "v": "SuperAdmin,School.Admin,School.Editor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/School",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/School/{*Page}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCD.IDashboardTableProvider, $.$hDPm.LCFCCD$1.IDataListPrepareItemController, $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.School.Client.Admin.Pages.Admin`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}School${separator}Client${separator}Admin${separator}Pages${separator}Admin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(419207)
        
        

        //--TRIMMABLE-BOUNDARY-START(681351)
        $asm.$cls(`$bfaB.LCCSCA.SkillPlayerProvider`, ($self) => class SkillPlayerProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81605059975)
            /*int*/ Order = 0;
            //--TRIMMABLE-BOUNDARY-END(81605059975)
            
            //--TRIMMABLE-BOUNDARY-START(85900027271)
            /*string? */ get Title()
            {
                return "Player";
            }
            //--TRIMMABLE-BOUNDARY-END(85900027271)
            
            //--TRIMMABLE-BOUNDARY-START(34360419719)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(34360419719)
            
            //--TRIMMABLE-BOUNDARY-START(77310092679)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-view-array"/*MaterialDesignIconNames.ViewArray*/);
            }
            //--TRIMMABLE-BOUNDARY-END(77310092679)
            
            //--TRIMMABLE-BOUNDARY-START(4295648647)
            /*CommunitySchoolService*/ _service = null;
            //--TRIMMABLE-BOUNDARY-END(4295648647)
            
            //--TRIMMABLE-BOUNDARY-START(12885583239)
            /*IClientUnitOfWork*/ _unitOfWork = null;
            //--TRIMMABLE-BOUNDARY-END(12885583239)
            
            //--TRIMMABLE-BOUNDARY-START(8590615943)
            /*MarkdownPlusTokenMethodResolverFactory*/ _tokenResolver = null;
            //--TRIMMABLE-BOUNDARY-END(8590615943)
            
            //--TRIMMABLE-BOUNDARY-START(25770485127)
            $ctor$1(/*CommunitySchoolService*/ service, /*IClientUnitOfWork*/ unitOfWork, /*MarkdownPlusTokenMethodResolverFactory*/ tokenResolver)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770485127);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._service = service;
                    this._unitOfWork = unitOfWork;
                    this._tokenResolver = tokenResolver;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770485127)
            
            //--TRIMMABLE-BOUNDARY-START(30065452423)
            /*bool */ CanProvideView(/*IObservableDataDescriptor<CommunitySchoolSkillModel>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065452423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(30065452423)
            
            //--TRIMMABLE-BOUNDARY-START(73015125383)
            /*RenderFragment? */ GetView(/*ContainerContext<IObservableDataDescriptor<CommunitySchoolSkillModel>>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015125383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let player = new $.$OCet.LCCSCS.CommunitySchoolSkillPlayerContext().$ctor$4(this._unitOfWork.LCFCI$IClientUnitOfWork$ServiceProvider, this._unitOfWork.LCFCI$IClientUnitOfWork$Server, this._unitOfWork.LCFCI$IClientUnitOfWork$Cache, value.Data.LCFCR$IReactiveObservable$$$Value, this._tokenResolver);
                return $.$hDPm.LCFC.FragmentView.From$1($.$awPs.LCCSCS$1.LiveQA, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("ViewModel", $.$fPer.LCFCO.OneOf$$$($.$OCet.LCCSCS.CommunitySchoolSkillPlayerContext, $.$OCet.LCCSCS.ICommunitySchoolQuestionAnswerStore).FromT0(player));
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(73015125383)
            
            //--TRIMMABLE-BOUNDARY-START(12898031274)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataPropertyAddOnViewProvider<LivingThing.Core.Community.School.Common.Models.CommunitySchoolSkillModel>.Order.get
            get LCFCCD$IDashboardTableDataPropertyAddOnViewProvider$$$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17192998570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(12898031274)
            
            //--TRIMMABLE-BOUNDARY-START(4308096682)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataPropertyAddOnViewProvider<LivingThing.Core.Community.School.Common.Models.CommunitySchoolSkillModel>.CanProvideView(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.School.Common.Models.CommunitySchoolSkillModel>)
            LCFCCD$IDashboardTableDataPropertyAddOnViewProvider$$$CanProvideView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4308096682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanProvideView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4308096682)
            
            //--TRIMMABLE-BOUNDARY-START(4360984234)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IViewProvider<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.School.Common.Models.CommunitySchoolSkillModel>>.GetView(LivingThing.Core.Frameworks.Client.Interface.ContainerContext<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.School.Common.Models.CommunitySchoolSkillModel>>)
            [`LCFCI$IViewProvider$LivingThing$Core$Frameworks$Common$DataDescriptor$IObservableDataDescriptor$LivingThing$Core$Community$School$Common$Models$CommunitySchoolSkillModel$$GetView`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4360984234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4360984234)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 681351;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605059975),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130223495,
        "f": 50331649
      },
      "n": "Order",
      "d": 681351,
      "h": 81605059975,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605059975),
//--TRIMMABLE-BOUNDARY-START(85900027271),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720158087,
        "f": 50331649
      },
      "n": "Title",
      "d": 681351,
      "h": 85900027271,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900027271),
//--TRIMMABLE-BOUNDARY-START(34360419719),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950354311,
        "f": 50331649
      },
      "n": "Description",
      "d": 681351,
      "h": 34360419719,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360419719),
//--TRIMMABLE-BOUNDARY-START(77310092679),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540288903,
        "f": 50331649
      },
      "n": "Icon",
      "d": 681351,
      "h": 77310092679,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310092679)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065452423),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": $.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$OCet.LCCSCM.CommunitySchoolSkillModel).$h
        }
      ],
      "n": "CanProvideView",
      "d": 681351,
      "h": 30065452423,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065452423),
//--TRIMMABLE-BOUNDARY-START(73015125383),
    {
      "r": 6881395,
      "p": [
        {
          "n": "value",
          "p": $.$hDPm.LCFCI.ContainerContext$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$OCet.LCCSCM.CommunitySchoolSkillModel)).$h
        }
      ],
      "n": "GetView",
      "d": 681351,
      "h": 73015125383,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015125383)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295648647),
    {
      "t": 2224851,
      "n": "_service",
      "d": 681351,
      "h": 4295648647,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295648647),
//--TRIMMABLE-BOUNDARY-START(12885583239),
    {
      "t": 63657642,
      "n": "_unitOfWork",
      "d": 681351,
      "h": 12885583239,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885583239),
//--TRIMMABLE-BOUNDARY-START(8590615943),
    {
      "t": 1476860,
      "n": "_tokenResolver",
      "d": 681351,
      "h": 8590615943,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590615943)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770485127),
    {
      "p": [
        {
          "n": "service",
          "p": 2224851
        },
        {
          "n": "unitOfWork",
          "p": 63657642
        },
        {
          "n": "tokenResolver",
          "p": 1476860
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 681351,
      "h": 25770485127,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770485127)
  ],
  "h": 681351
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableDataPropertyAddOnViewProvider$$($.$OCet.LCCSCM.CommunitySchoolSkillModel), $.$hDPm.LCFCI.IViewProvider$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$OCet.LCCSCM.CommunitySchoolSkillModel)), $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.School.Client.Admin.SkillPlayerProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}School${separator}Client${separator}Admin${separator}SkillPlayerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(681351)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Article.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.School.Common", "NetJs.LivingThing.Core.Frameworks.Client.TelegramMiniApp.Blazor", "NetJs.LivingThing.Core.Community.School.Client.Blazor", "NetJs.LivingThing.Core.Gallery.Common", "NetJs.LivingThing.Core.Gallery.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(25991)
