
//--TRIMMABLE-BOUNDARY-START(19774)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $fJEF) {
    "use strict";
    let _;
    let $nCevtc;
    let $cIOLVh;
    let $tAHsal;
    let $UjdWPf;
    let $BbfhJk;
    let $zmhYjc;
    let $SpBBTa;
    let $JZTspe;
    let $SLtoMj;
    let $MlKxDf;
    let $hdxczf;
    let $xtiRHd;
    let $hCphtg;
    let $zGfccf;
    let $QXITed;
    let $hZarHb;
    let $xaFaWk;
    let $pTFsKd;
    let $cnHZfc;
    let $Sgsghl;
    let $MfAKOd;
    let $PzLjKg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Short.Client.Blazor", 
    {
  "h": 19774,
  "f": "LivingThing.Core.Community.Short.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Short.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Short.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(150846)
        $asm.$cls(`$oAeB.LCCSC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295118142)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295118142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$oAeB.LCCSC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295118142)
            
            static $h = 150846;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295118142),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 150846,
      "h": 4295118142,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295118142)
  ],
  "h": 150846
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(150846)
        
        

        //--TRIMMABLE-BOUNDARY-START(216382)
        $asm.$cls(`$oAeB.LCCSC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180085566)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$oAeB.LCCSCP.CommunityShortApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$oAeB.LCCSCP.CommunityShortApp().$ctor$6();
                    }, $nCevtc ??= {"r":2752627,"n":"","d":216382,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180085566)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295183678)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295183678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295183678)
            
            //--TRIMMABLE-BOUNDARY-START(4295183678)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295183678)
            
            static $h = 216382;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180085566),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885118270,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 216382,
      "h": 17180085566,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180085566)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295183678),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 216382,
      "h": 4295183678,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295183678)
  ],
  "h": 216382
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(216382)
        
        

        //--TRIMMABLE-BOUNDARY-START(347454)
        $asm.$cls(`$oAeB.LCCSC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590282046)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590282046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$oAeB.LCCSCS.CommunityShortService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$fJEF.LCCSCM.CommunityShortPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$oAeB.LCCSCS.CommunityShortApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$oAeB.LCCSCS.CommunityShortApplication, x);
                }, $cIOLVh ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":347454,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$oAeB.LCCSCS.CommunityShortApplication, x);
                }, $tAHsal ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":347454,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$fJEF.LCCSCM.CommunityShortPostModel, services, null);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$oAeB.LCCSCS.CommunityShortFeedProvider, services);
                $.$oAeB.LCCSC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590282046)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$oAeB.LCCSC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295314750)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295314750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295314750)
            
            //--TRIMMABLE-BOUNDARY-START(4295314750)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295314750)
            
            static $h = 347454;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590282046),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 347454,
      "h": 8590282046,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590282046)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295314750),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 347454,
      "h": 4295314750,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295314750)
  ],
  "h": 347454
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(347454)
        
        

        //--TRIMMABLE-BOUNDARY-START(675134)
        $asm.$cls(`$oAeB.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295642430)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295642430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295642430)
            
            //--TRIMMABLE-BOUNDARY-START(4295642430)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295642430)
            
            static $h = 675134;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295642430),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 675134,
      "h": 4295642430,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295642430)
  ],
  "h": 675134
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(675134)
        
        

        //--TRIMMABLE-BOUNDARY-START(740670)
        $asm.$cls(`$oAeB.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295707966)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295707966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295707966)
            
            //--TRIMMABLE-BOUNDARY-START(4295707966)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295707966)
            
            static $h = 740670;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295707966),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 740670,
      "h": 4295707966,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295707966)
  ],
  "h": 740670,
  "a": [
    {
      "t": 675134,
      "c": 4295642430
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(740670)
        
        

        //--TRIMMABLE-BOUNDARY-START(85310)
        $asm.$cls(`$oAeB.LCCSC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590019902)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590019902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590019902)
            
            //--TRIMMABLE-BOUNDARY-START(4295052606)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295052606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295052606)
            
            //--TRIMMABLE-BOUNDARY-START(4295052606)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295052606)
            
            static $h = 85310;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590019902),
    {
      "r": 65537,
      "n": "Execute",
      "d": 85310,
      "h": 8590019902,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590019902)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295052606),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 85310,
      "h": 4295052606,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295052606)
  ],
  "h": 85310
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(85310)
        
        

        //--TRIMMABLE-BOUNDARY-START(478526)
        $asm.$cls(`$oAeB.LCCSCS.CommunityShortFeedProvider`, ($self) => class CommunityShortFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$fJEF.LCCSCM.CommunityShortPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295445822)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295445822);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295445822)
            
            //--TRIMMABLE-BOUNDARY-START(8590413118)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityShortPostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590413118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`created a media`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590413118)
            
            static $h = 478526;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$fJEF.LCCSCM.CommunityShortPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590413118),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 497995
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 478526,
      "h": 8590413118,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590413118)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295445822),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 478526,
      "h": 4295445822,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295445822)
  ],
  "h": 478526
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Client.Services.CommunityShortFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Client${separator}Services${separator}CommunityShortFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(478526)
        
        

        //--TRIMMABLE-BOUNDARY-START(609598)
        $asm.$cls(`$oAeB.LCCSCS$1.CommunityShortPost`, ($self) => class CommunityShortPost extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$fJEF.LCCSCM.CommunityShortPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8590544190)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590544190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "mawx-5 mgx-a pos-rel bg-black hv-10 flex");
                __builder.AddMarkupContent(2, "<video src=\"video.mp4\" width=\"100%\"></video>\r\n        ");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "pos-abs r-0 b-0 pdx pdb-30 stack");
                __builder.OpenElement(5, "div");
                __builder.AddAttribute$5(6, "class", "stack text-center mgy");
                __builder.AddMarkupContent(7, "<button class=\"mdi mdi-thumb-up bd-0 fsz-40 bg-transparent\"></button>\r\n                ");
                __builder.OpenElement(8, "small");
                __builder.AddContent$3(9, $.$box(this.ViewModel.VotesCount, $.$$.S.Int32));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\r\n            ");
                __builder.AddMarkupContent(11, "<div class=\"stack text-center mgy\"><button class=\"mdi mdi-thumb-down bd-0 fsz-40 bg-transparent\"></button>\r\n                <small>Dislike</small></div>\r\n            ");
                __builder.OpenElement(12, "div");
                __builder.AddAttribute$5(13, "class", "stack text-center mgy");
                __builder.AddMarkupContent(14, "<button class=\"mdi mdi-comment bd-0 fsz-40 bg-transparent\"></button>\r\n                ");
                __builder.OpenElement(15, "small");
                __builder.AddContent$3(16, $.$box(this.ViewModel.CommentsCount, $.$$.S.Int32));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(17, "\r\n            ");
                __builder.AddMarkupContent(18, "<div class=\"stack text-center mgy\"><button class=\"mdi mdi-share bd-0 fsz-40 bg-transparent\"></button>\r\n                <small>Share</small></div>\r\n            ");
                __builder.AddMarkupContent(19, "<div class=\"stack text-center mgy\"><button class=\"mdi mdi-dots-horizontal bd-0 fsz-40 bg-transparent\"></button></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(20, "\r\n        ");
                __builder.OpenElement(21, "div");
                __builder.AddAttribute$5(22, "class", "pos-abs l-0 r-0 b-0 pd");
                __builder.OpenElement(23, "h4");
                __builder.AddContent$4(24, this.ViewModel.Title);
                __builder.CloseElement();
                __builder.AddMarkupContent(25, "\r\n            ");
                __builder.AddMarkupContent(26, "<div class=\"row\"><div class=\"col-a\"><img src=\"https://source.unsplash.com/user/c_v_r/100x100\" width=\"40\" class=\"round\"></div>\r\n                <div class=\"col-a mgy-a mgl\"><h3 class=\"mgy-0\">Author</h3></div>\r\n                <div class=\"col-10 text-right mgy-a mgl\"><button class=\"bg-primary bd-0 corner-5 pdx-4 pdy-1\">Follow</button></div></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(27, "\r\n        ");
                __builder.AddMarkupContent(28, "<div class=\"pos-abs l-0 b-0 r-0\"><div class=\"bg-white hx-005\" style=\"width:50%\"></div></div>");
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590544190)
            
            //--TRIMMABLE-BOUNDARY-START(4295576894)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295576894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295576894)
            
            //--TRIMMABLE-BOUNDARY-START(4295576894)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295576894)
            
            static $h = 609598;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$fJEF.LCCSCM.CommunityShortPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590544190),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 609598,
      "h": 8590544190,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590544190)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295576894),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 609598,
      "h": 4295576894,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295576894)
  ],
  "h": 609598
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Client.Shared.CommunityShortPost`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Client${separator}Shared${separator}CommunityShortPost`; }
        });
        //--TRIMMABLE-BOUNDARY-END(609598)
        
        

        //--TRIMMABLE-BOUNDARY-START(412990)
        $asm.$cls(`$oAeB.LCCSCS.CommunityShortApplication`, ($self) => class CommunityShortApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885314878)
            $ctor$5(/*CommunityShortService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885314878);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885314878)
            
            //--TRIMMABLE-BOUNDARY-START(137439366462)
            /*string */ get Name()
            {
                return "Short";
            }
            //--TRIMMABLE-BOUNDARY-END(137439366462)
            
            //--TRIMMABLE-BOUNDARY-START(158914202942)
            /*string */ get Title()
            {
                return "Short Videos";
            }
            //--TRIMMABLE-BOUNDARY-END(158914202942)
            
            //--TRIMMABLE-BOUNDARY-START(21475249470)
            /*string */ get Description()
            {
                return "Share and watch creativities in a 15s short video.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475249470)
            
            //--TRIMMABLE-BOUNDARY-START(133144399166)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-video-marker"/*MaterialDesignIconNames.VideoMarker*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144399166)
            
            //--TRIMMABLE-BOUNDARY-START(154619235646)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#9E262B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619235646)
            
            //--TRIMMABLE-BOUNDARY-START(30065184062)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065184062)
            
            //--TRIMMABLE-BOUNDARY-START(17180282174)
            /*Type? */ get ApplicationViewType()
            {
                return $.$oAeB.LCCSCP.CommunityShortApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180282174)
            
            //--TRIMMABLE-BOUNDARY-START(128849431870)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849431870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$oAeB.LCCSCP.CommunityShortApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849431870)
            
            //--TRIMMABLE-BOUNDARY-START(25770216766)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770216766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770216766)
            
            //--TRIMMABLE-BOUNDARY-START(146029301054)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029301054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029301054)
            
            //--TRIMMABLE-BOUNDARY-START(141734333758)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734333758)
            
            //--TRIMMABLE-BOUNDARY-START(4295380286)
            /*CommunityShortService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295380286)
            
            //--TRIMMABLE-BOUNDARY-START(150324268350)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(150324268350)
            
            //--TRIMMABLE-BOUNDARY-START(163209170238)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(5888/*PostTypes.Short*/, 5890/*PostTypes.ShortEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209170238)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 412990;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439366462),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604791614,
        "f": 50364417
      },
      "n": "Name",
      "d": 412990,
      "h": 137439366462,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439366462),
//--TRIMMABLE-BOUNDARY-START(158914202942),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964529982,
        "f": 50364417
      },
      "n": "Title",
      "d": 412990,
      "h": 158914202942,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914202942),
//--TRIMMABLE-BOUNDARY-START(21475249470),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834987838,
        "f": 50364417
      },
      "n": "Description",
      "d": 412990,
      "h": 21475249470,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475249470),
//--TRIMMABLE-BOUNDARY-START(133144399166),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014857022,
        "f": 50364417
      },
      "n": "Icon",
      "d": 412990,
      "h": 133144399166,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144399166),
//--TRIMMABLE-BOUNDARY-START(154619235646),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374595390,
        "f": 50364417
      },
      "n": "Theme",
      "d": 412990,
      "h": 154619235646,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619235646),
//--TRIMMABLE-BOUNDARY-START(30065184062),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424922430,
        "f": 50364417
      },
      "n": "Features",
      "d": 412990,
      "h": 30065184062,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065184062),
//--TRIMMABLE-BOUNDARY-START(17180282174),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245053246,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 412990,
      "h": 17180282174,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180282174),
//--TRIMMABLE-BOUNDARY-START(141734333758),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194726206,
        "f": 50364417
      },
      "n": "Order",
      "d": 412990,
      "h": 141734333758,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734333758),
//--TRIMMABLE-BOUNDARY-START(4295380286),
    {
      "p": 544062,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655118654,
        "f": 50331650
      },
      "n": "_Service",
      "d": 412990,
      "h": 4295380286,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295380286),
//--TRIMMABLE-BOUNDARY-START(150324268350),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784660798,
        "f": 50364417
      },
      "n": "Service",
      "d": 412990,
      "h": 150324268350,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324268350),
//--TRIMMABLE-BOUNDARY-START(163209170238),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554464574,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 412990,
      "h": 163209170238,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209170238)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849431870),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 412990,
      "h": 128849431870,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849431870),
//--TRIMMABLE-BOUNDARY-START(25770216766),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 412990,
      "h": 25770216766,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770216766),
//--TRIMMABLE-BOUNDARY-START(146029301054),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 412990,
      "h": 146029301054,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029301054)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885314878),
    {
      "p": [
        {
          "n": "service",
          "p": 544062
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 412990,
      "h": 12885314878,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885314878)
  ],
  "h": 412990
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$fJEF.LCCSCM.CommunityShortPostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Client.Services.CommunityShortApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Client${separator}Services${separator}CommunityShortApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(412990)
        
        

        //--TRIMMABLE-BOUNDARY-START(281918)
        $asm.$cls(`$oAeB.LCCSCP.CommunityShortApp`, ($self) => class CommunityShortApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$fJEF.LCCSCM.CommunityShortPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$fJEF.LCCSCM.CommunityShortUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(98784529726)
            /*CommunityShortService*/ ShortService = null;
            //--TRIMMABLE-BOUNDARY-END(98784529726)
            
            //--TRIMMABLE-BOUNDARY-START(94489562430)
            /*CommunityShortApplication*/ ShortApplication = null;
            //--TRIMMABLE-BOUNDARY-END(94489562430)
            
            //--TRIMMABLE-BOUNDARY-START(17180151102)
            /*ICommunityClientApplication */ get Application()
            {
                return this.ShortApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(17180151102)
            
            //--TRIMMABLE-BOUNDARY-START(103079497022)
            /*UseDefaultPage */ get UsePage()
            {
                return 65535/*UseDefaultPage.Default*/ & ~1/*UseDefaultPage.Home*/;
            }
            //--TRIMMABLE-BOUNDARY-END(103079497022)
            
            //--TRIMMABLE-BOUNDARY-START(68719758654)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719758654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(68719758654)
            
            //--TRIMMABLE-BOUNDARY-START(21475118398)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475118398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "Name", "Short");
                __builder.AddComponentParameter(2, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.ShortService));
                __builder.AddComponentParameter(3, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(4, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 5);
                        __builder2.AddComponentParameter(6, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                        __builder2.AddAttribute$3(7, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(8, wrap.View);
                        }), $UjdWPf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":281918,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $BbfhJk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":281918,"h":0,"f":17825794});
                }), $zmhYjc ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":281918,"h":0,"f":17825794}));
                __builder.AddAttribute$3(9, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/*splash*/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 10);
                        __builder2.AddComponentParameter(11, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, splash.ViewModel));
                        __builder2.AddComponentParameter(12, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, splash.Message));
                        __builder2.CloseComponent();
                    }, $SpBBTa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":281918,"h":0,"f":17825794});
                }), $JZTspe ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":281918,"h":0,"f":17825794}));
                __builder.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$1(14, this.GetPages());
                }), $SLtoMj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":281918,"h":0,"f":17825794}));
                __builder.AddComponentReferenceCapture(15, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.App = $.$cast(__value, $.$lJUR.LCFCS.Application);
                }, $MlKxDf ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":281918,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21475118398)
            
            //--TRIMMABLE-BOUNDARY-START(73014725950)
            /*RenderFragment */ get PrependPages()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(16, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 17);
                    __builder2.AddComponentParameter(18, "Name", "Home");
                    __builder2.AddComponentParameter(19, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("**"/*RoutePath.ZeroOrMorePathSegment*/)));
                    __builder2.AddComponentParameter(20, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(21, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, (8707/*ApplicationPageFeatures.Default*/ & ~2/*ApplicationPageFeatures.BottomTab*/) | 16/*ApplicationPageFeatures.TopToolBarOverlay*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddComponentParameter(22, "ToolBarBackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.OfBlack(0.5)));
                    __builder2.AddComponentParameter(23, "ToolBarTextColorTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.White));
                    __builder2.AddComponentParameter(24, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~15/*CommunityLayoutFeatures.Pad*/, null, null, true);
                    }), $hdxczf ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object).$h}],"n":"","d":281918,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(25, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(26, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, new $.$fPer.LCFC.IconDescriptor(), false));
                        }, $xtiRHd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":281918,"h":0,"f":17825794});
                    }), $hCphtg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":281918,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(27, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(28, "Short");
                        }, $zGfccf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":281918,"h":0,"f":17825794});
                    }), $QXITed ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":281918,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(29, "ToolBarControls", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 30);
                            __builder3.AddComponentParameter(31, "PageLink", "EditPost");
                            __builder3.AddComponentParameter(32, "link-class", "mdi mdi-plus");
                            __builder3.CloseComponent();
                        }, $hZarHb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":281918,"h":0,"f":17825794});
                    }), $xaFaWk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":281918,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(33, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*_*/ _0) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$fJEF.LCCSCM.CommunityShortPostModel), 34);
                            __builder3.AddComponentParameter(35, "Class", "hf");
                            __builder3.AddComponentParameter(36, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddAttribute$3(37, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fJEF.LCCSCM.CommunityShortPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fJEF.LCCSCM.CommunityShortPostModel))))().$ctor(this, ( (/*sshort*/ sshort) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$oAeB.LCCSCS$1.CommunityShortPost, 38);
                                    __builder4.AddComponentParameter(39, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fJEF.LCCSCM.CommunityShortPostModel, sshort.Data));
                                    __builder4.CloseComponent();
                                }, $pTFsKd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":281918,"h":0,"f":17825794});
                            }), $cnHZfc ??= {"r":6881395,"p":[{"n":"sshort","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fJEF.LCCSCM.CommunityShortPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fJEF.LCCSCM.CommunityShortPostModel)).$h}],"n":"","d":281918,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $Sgsghl ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":281918,"h":0,"f":17825794});
                    }), $MfAKOd ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":281918,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(40, "\r\n    ");
                }, $PzLjKg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":281918,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(73014725950)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885183806)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885183806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885183806)
            
            //--TRIMMABLE-BOUNDARY-START(12885183806)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12885183806)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(98784529726)
                this.ShortService = null;
                //--TRIMMABLE-BOUNDARY-END(98784529726)
                
                //--TRIMMABLE-BOUNDARY-START(94489562430)
                this.ShortApplication = null;
                //--TRIMMABLE-BOUNDARY-END(94489562430)
                
            }
            static $h = 281918;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$fJEF.LCCSCM.CommunityShortPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$fJEF.LCCSCM.CommunityShortUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98784529726),
    {
      "p": 544062,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834856766,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194595134,
        "f": 83886081
      },
      "n": "ShortService",
      "d": 281918,
      "h": 98784529726,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98784529726),
//--TRIMMABLE-BOUNDARY-START(94489562430),
    {
      "p": 412990,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244922174,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604660542,
        "f": 83886081
      },
      "n": "ShortApplication",
      "d": 281918,
      "h": 94489562430,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94489562430),
//--TRIMMABLE-BOUNDARY-START(17180151102),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065052990,
        "f": 50364420
      },
      "n": "Application",
      "d": 281918,
      "h": 17180151102,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(17180151102),
//--TRIMMABLE-BOUNDARY-START(103079497022),
    {
      "p": 34379200,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424791358,
        "f": 50364420
      },
      "n": "UsePage",
      "d": 281918,
      "h": 103079497022,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(103079497022),
//--TRIMMABLE-BOUNDARY-START(73014725950),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654987582,
        "f": 50364420
      },
      "n": "PrependPages",
      "d": 281918,
      "h": 73014725950,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(73014725950)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68719758654),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 281918,
      "h": 68719758654,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(68719758654),
//--TRIMMABLE-BOUNDARY-START(21475118398),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 281918,
      "h": 21475118398,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475118398)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885183806),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 281918,
      "h": 12885183806,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885183806)
  ],
  "h": 281918
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Client.Pages.CommunityShortApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Client${separator}Pages${separator}CommunityShortApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(281918)
        
        

        //--TRIMMABLE-BOUNDARY-START(544062)
        $asm.$cls(`$oAeB.LCCSCS.CommunityShortService`, ($self) => class CommunityShortService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$fJEF.LCCSCM.CommunityShortPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295511358)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295511358);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295511358)
            
            static $h = 544062;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$fJEF.LCCSCM.CommunityShortPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295511358),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 544062,
      "h": 4295511358,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295511358)
  ],
  "h": 544062
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$fJEF.LCCSCM.CommunityShortPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$fJEF.LCCSCM.CommunityShortPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Client.Services.CommunityShortService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Client${separator}Services${separator}CommunityShortService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(544062)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Short.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(19774)
