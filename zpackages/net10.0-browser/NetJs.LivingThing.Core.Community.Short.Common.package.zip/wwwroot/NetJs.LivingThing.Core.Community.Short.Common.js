
//--TRIMMABLE-BOUNDARY-START(39243)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $SaeGlf;
    let $bcdhvj;
    let $nLDMVe;
    let $zDyFzi;
    let $iUyFif;
    let $FbTWJd;
    let $ofeani;
    let $uIwdia;
    let $QTlLWh;
    let $TCOmub;
    let $MRbPpa;
    let $GteVPa;
    let $VkZsSb;
    let $ZJLbZb;
    let $kZbQBi;
    let $VMlouk;
    let $RgKUxc;
    let $YVuSCj;
    let $ALajre;
    let $sLlXNa;
    let $YzFUbd;
    let $WepIJf;
    let $CrgqNk;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Short.Common", 
    {
  "h": 39243,
  "f": "LivingThing.Core.Community.Short.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Short.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Short.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1546571)
        $asm.$cls(`$fJEF.LCCSCS$2.CommunityShortStatesCustomAttributesProvider`, ($self) => class CommunityShortStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296513867)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296513867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296513867)
            
            static $h = 1546571;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296513867),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1546571,
      "h": 4296513867,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296513867)
  ],
  "h": 1546571
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.States.CommunityShortStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}States${separator}CommunityShortStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1546571)
        
        

        //--TRIMMABLE-BOUNDARY-START(1284427)
        $asm.$cls(`$fJEF.LCCSCS$1.CommunityShortSettingsCustomAttributesProvider`, ($self) => class CommunityShortSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296251723)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296251723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296251723)
            
            static $h = 1284427;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296251723),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1284427,
      "h": 4296251723,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296251723)
  ],
  "h": 1284427
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Settings.CommunityShortSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Settings${separator}CommunityShortSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1284427)
        
        

        //--TRIMMABLE-BOUNDARY-START(301387)
        $asm.$cls(`$fJEF.LCCSCM.CommunityShortModelCustomAttributesProvider`, ($self) => class CommunityShortModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295268683)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295268683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$fJEF.LCCSCS$1.CommunityShortSettings, $.$fJEF.LCCSCS$2.CommunityShortStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295268683)
            
            static $h = 301387;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295268683),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 301387,
      "h": 4295268683,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295268683)
  ],
  "h": 301387
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Models.CommunityShortModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Models${separator}CommunityShortModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(301387)
        
        

        //--TRIMMABLE-BOUNDARY-START(104779)
        $asm.$cls(`$fJEF.LCCSC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295072075)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295072075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fJEF.LCCSCM.CommunityShortModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fJEF.LCCSCM.CommunityShortModelCustomAttributesProvider, $.$fJEF.LCCSCM.CommunityShortModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fJEF.LCCSCM.CommunityShortPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fJEF.LCCSCM.CommunityShortPostModelCustomAttributesProvider, $.$fJEF.LCCSCM.CommunityShortPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fJEF.LCCSCS$1.CommunityShortSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fJEF.LCCSCS$1.CommunityShortSettingsCustomAttributesProvider, $.$fJEF.LCCSCS$1.CommunityShortSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fJEF.LCCSCS$2.CommunityShortStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fJEF.LCCSCS$2.CommunityShortStatesCustomAttributesProvider, $.$fJEF.LCCSCS$2.CommunityShortStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295072075)
            
            static $h = 104779;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295072075),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 104779,
      "h": 4295072075,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295072075)
  ],
  "h": 104779
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(104779)
        
        

        //--TRIMMABLE-BOUNDARY-START(1743179)
        $asm.$cls(`$fJEF.LCCSC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296710475)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296710475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fJEF.LCCSCM.CommunityShortModelTypeDescriptorBuilder.Register();
                $.$fJEF.LCCSCM.CommunityShortPostModelTypeDescriptorBuilder.Register();
                $.$fJEF.LCCSCS$1.CommunityShortSettingsTypeDescriptorBuilder.Register();
                $.$fJEF.LCCSCS$2.CommunityShortStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296710475)
            
            static $h = 1743179;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296710475),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1743179,
      "h": 4296710475,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296710475)
  ],
  "h": 1743179
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1743179)
        
        

        //--TRIMMABLE-BOUNDARY-START(1415499)
        $asm.$cls(`$fJEF.LCCSCS$1.CommunityShortSettingsTypeDescriptorBuilder`, ($self) => class CommunityShortSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591350091)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591350091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fJEF.LCCSCS$1.CommunityShortSettingsTypeDescriptor()
                        const $t1 = $.$fJEF.LCCSCS$1.CommunityShortSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Short.Common.Settings.CommunityShortSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $kZbQBi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1415499,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fJEF.LCCSCS$1.CommunityShortSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591350091)
            
            //--TRIMMABLE-BOUNDARY-START(4296382795)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296382795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296382795)
            
            //--TRIMMABLE-BOUNDARY-START(4296382795)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296382795)
            
            static $h = 1415499;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591350091),
    {
      "r": 65537,
      "n": "Register",
      "d": 1415499,
      "h": 8591350091,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591350091)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296382795),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1415499,
      "h": 4296382795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296382795)
  ],
  "h": 1415499
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Settings.CommunityShortSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Settings${separator}CommunityShortSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1415499)
        
        

        //--TRIMMABLE-BOUNDARY-START(170315)
        $asm.$cls(`$fJEF.LCCSC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295137611)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295137611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$fJEF.LCCSCS.ICommunityShortFeedRemoteService, $.$fJEF.LCCSCS.ICommunityShortFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fJEF.LCCSCS.ICommunityShortFeedRemoteService_Mocking().$ctor$3(impl);
                }, $iUyFif ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":170315,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fJEF.LCCSCS.ICommunityShortFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fJEF.LCCSCS.ICommunityShortFeedRemoteService_Mocking().$ctor$3(impl);
                }, $FbTWJd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":170315,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fJEF.LCCSCS.IComunityShortRemoteService, $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking().$ctor$3(impl);
                }, $ofeani ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":170315,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking().$ctor$3(impl);
                }, $uIwdia ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":170315,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking().$ctor$3(impl);
                }, $QTlLWh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":170315,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking().$ctor$3(impl);
                }, $TCOmub ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":170315,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking().$ctor$3(impl);
                }, $MRbPpa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":170315,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking().$ctor$3(impl);
                }, $GteVPa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":170315,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking().$ctor$3(impl);
                }, $VkZsSb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":170315,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fJEF.LCCSCS.IComunityShortRemoteService_Mocking().$ctor$3(impl);
                }, $ZJLbZb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":170315,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295137611)
            
            static $h = 170315;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295137611),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 170315,
      "h": 4295137611,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295137611)
  ],
  "h": 170315
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(170315)
        
        

        //--TRIMMABLE-BOUNDARY-START(1677643)
        $asm.$cls(`$fJEF.LCCSCS$2.CommunityShortStatesTypeDescriptorBuilder`, ($self) => class CommunityShortStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591612235)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591612235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fJEF.LCCSCS$2.CommunityShortStatesTypeDescriptor()
                        const $t1 = $.$fJEF.LCCSCS$2.CommunityShortStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Short.Common.States.CommunityShortStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $SaeGlf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1677643,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fJEF.LCCSCS$2.CommunityShortStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591612235)
            
            //--TRIMMABLE-BOUNDARY-START(4296644939)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296644939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296644939)
            
            //--TRIMMABLE-BOUNDARY-START(4296644939)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296644939)
            
            static $h = 1677643;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591612235),
    {
      "r": 65537,
      "n": "Register",
      "d": 1677643,
      "h": 8591612235,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591612235)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296644939),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1677643,
      "h": 4296644939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296644939)
  ],
  "h": 1677643
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.States.CommunityShortStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}States${separator}CommunityShortStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1677643)
        
        

        //--TRIMMABLE-BOUNDARY-START(432459)
        $asm.$cls(`$fJEF.LCCSCM.CommunityShortModelTypeDescriptorBuilder`, ($self) => class CommunityShortModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590367051)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590367051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fJEF.LCCSCM.CommunityShortModelTypeDescriptor()
                        const $t1 = $.$fJEF.LCCSCM.CommunityShortModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Short.Common.Models.CommunityShortModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $RgKUxc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":432459,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fJEF.LCCSCM.CommunityShortModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590367051)
            
            //--TRIMMABLE-BOUNDARY-START(4295399755)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295399755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295399755)
            
            //--TRIMMABLE-BOUNDARY-START(4295399755)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295399755)
            
            static $h = 432459;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590367051),
    {
      "r": 65537,
      "n": "Register",
      "d": 432459,
      "h": 8590367051,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590367051)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295399755),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 432459,
      "h": 4295399755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295399755)
  ],
  "h": 432459
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Models.CommunityShortModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Models${separator}CommunityShortModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(432459)
        
        

        //--TRIMMABLE-BOUNDARY-START(563531)
        $asm.$cls(`$fJEF.LCCSCM.CommunityShortPostModelCustomAttributesProvider`, ($self) => class CommunityShortPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295530827)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295530827)
            
            //--TRIMMABLE-BOUNDARY-START(8590498123)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590498123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$fJEF.LCCSCM.CommunityShortPostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("VideoSource", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (-2147483648);
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-video"], [-1], null);
                            $i3.Description = "Video Source";
                            $i3.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$fJEF.LCCSCM.CommunityShortPostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $nLDMVe ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":563531,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $zDyFzi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":563531,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590498123)
            
            static $h = 563531;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590498123),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 563531,
      "h": 8590498123,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590498123)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295530827),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 563531,
      "h": 4295530827,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295530827)
  ],
  "h": 563531
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Models${separator}CommunityShortPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(563531)
        
        

        //--TRIMMABLE-BOUNDARY-START(694603)
        $asm.$cls(`$fJEF.LCCSCM.CommunityShortPostModelTypeDescriptorBuilder`, ($self) => class CommunityShortPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590629195)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590629195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fJEF.LCCSCM.CommunityShortPostModelTypeDescriptor()
                        const $t1 = $.$fJEF.LCCSCM.CommunityShortPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ALajre ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":694603,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fJEF.LCCSCM.CommunityShortPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590629195)
            
            //--TRIMMABLE-BOUNDARY-START(4295661899)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295661899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295661899)
            
            //--TRIMMABLE-BOUNDARY-START(4295661899)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295661899)
            
            static $h = 694603;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590629195),
    {
      "r": 65537,
      "n": "Register",
      "d": 694603,
      "h": 8590629195,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590629195)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295661899),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 694603,
      "h": 4295661899,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295661899)
  ],
  "h": 694603
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Models${separator}CommunityShortPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(694603)
        
        

        //--TRIMMABLE-BOUNDARY-START(891211)
        $asm.$cls(`$fJEF.LCCSC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590825803)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590825803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$fJEF.LCCSCM.CommunityShortPostModel, 5888/*PostTypes.Short*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$fJEF.LCCSCM.CommunityShortPostModel, 5889/*PostTypes.ShortPost*/);
                $.$fJEF.LCCSC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$fJEF.LCCSC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$fJEF.LCCSC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590825803)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fJEF.LCCSC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295858507)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295858507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295858507)
            
            //--TRIMMABLE-BOUNDARY-START(4295858507)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295858507)
            
            static $h = 891211;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590825803),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 891211,
      "h": 8590825803,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590825803)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295858507),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 891211,
      "h": 4295858507,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295858507)
  ],
  "h": 891211
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(891211)
        
        

        //--TRIMMABLE-BOUNDARY-START(825675)
        $asm.$str(`$fJEF.LCCSCM.CommunityShortVideoSource`, ($self) => class CommunityShortVideoSource extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(30065596747)
            /*string*/ Url = null;
            //--TRIMMABLE-BOUNDARY-END(30065596747)
            
            //--TRIMMABLE-BOUNDARY-START(8590760267)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590760267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590760267)
            
            //--TRIMMABLE-BOUNDARY-START(8590760267)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590760267)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Url = this.Url;
                return copy;
            }
            static $h = 825675;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065596747),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180694859,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25770629451,
        "f": 83886081
      },
      "n": "Url",
      "d": 825675,
      "h": 30065596747,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065596747)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590760267),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 825675,
      "h": 8590760267,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590760267)
  ],
  "h": 825675
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IJsonSerializableDataConvert ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Models.CommunityShortVideoSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Models${separator}CommunityShortVideoSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(825675)
        
        

        //--TRIMMABLE-BOUNDARY-START(760139)
        $asm.$cls(`$fJEF.LCCSCM.CommunityShortUserPreference`, ($self) => class CommunityShortUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4295727435)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295727435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295727435)
            
            //--TRIMMABLE-BOUNDARY-START(4295727435)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295727435)
            
            static $h = 760139;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295727435),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 760139,
      "h": 4295727435,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295727435)
  ],
  "h": 760139
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Models.CommunityShortUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Models${separator}CommunityShortUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(760139)
        
        

        //--TRIMMABLE-BOUNDARY-START(1481035)
        $asm.$cls(`$fJEF.LCCSCS$2.CommunityShortStates`, ($self) => class CommunityShortStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296448331)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296448331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296448331)
            
            //--TRIMMABLE-BOUNDARY-START(4296448331)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296448331)
            
            static $h = 1481035;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296448331),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1481035,
      "h": 4296448331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296448331)
  ],
  "h": 1481035
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.States.CommunityShortStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}States${separator}CommunityShortStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1481035)
        
        

        //--TRIMMABLE-BOUNDARY-START(1218891)
        $asm.$cls(`$fJEF.LCCSCS$1.CommunityShortSettings`, ($self) => class CommunityShortSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296186187)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296186187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296186187)
            
            //--TRIMMABLE-BOUNDARY-START(4296186187)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296186187)
            
            static $h = 1218891;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296186187),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1218891,
      "h": 4296186187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296186187)
  ],
  "h": 1218891
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Settings.CommunityShortSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Settings${separator}CommunityShortSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1218891)
        
        

        //--TRIMMABLE-BOUNDARY-START(1612107)
        $asm.$cls(`$fJEF.LCCSCS$2.CommunityShortStatesTypeDescriptor`, ($self) => class CommunityShortStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fJEF.LCCSCS$2.CommunityShortStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296579403)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296579403);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fJEF.LCCSCS$2.CommunityShortStatesTypeDescriptor.GenerateProperties($.$fJEF.LCCSCS$2.CommunityShortStates, this, factory);
                    }, $bcdhvj ??= {"r":65537,"n":"","d":1612107,"h":0,"f":17825794}), 0, "CommunityShortStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Short.Common\\States_CommunityShortStates_LivingThing.Core.Community.Short.Common.States.CommunityShortStatesTypeDescriptorBuilder.g.cs", "CommunityShortStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296579403)
            
            //--TRIMMABLE-BOUNDARY-START(12886513995)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886513995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886513995)
            
            //--TRIMMABLE-BOUNDARY-START(17181481291)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Short.Common.States.CommunityShortStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181481291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181481291)
            
            //--TRIMMABLE-BOUNDARY-START(8591546699)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Short.Common.States.CommunityShortStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591546699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fJEF.LCCSCS$2.CommunityShortStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fJEF.LCCSCS$2.CommunityShortStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$fJEF.LCCSCS$2.CommunityShortStates)))
                {
                    /*var*/ let result = $.$fJEF.LCCSCS$2.CommunityShortStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fJEF.LCCSCS$2.CommunityShortStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fJEF.LCCSCS$2.CommunityShortStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$fJEF.LCCSCS$2.CommunityShortStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591546699)
            
            static $h = 1612107;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fJEF.LCCSCS$2.CommunityShortStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886513995),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1612107,
      "h": 12886513995,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886513995),
//--TRIMMABLE-BOUNDARY-START(17181481291),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1481035,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1612107,
      "h": 17181481291,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181481291),
//--TRIMMABLE-BOUNDARY-START(8591546699),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1481035,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1612107,
      "h": 8591546699,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591546699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296579403),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1612107,
      "h": 4296579403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296579403)
  ],
  "h": 1612107
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fJEF.LCCSCS$2.CommunityShortStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.States.CommunityShortStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}States${separator}CommunityShortStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1612107)
        
        

        //--TRIMMABLE-BOUNDARY-START(1349963)
        $asm.$cls(`$fJEF.LCCSCS$1.CommunityShortSettingsTypeDescriptor`, ($self) => class CommunityShortSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fJEF.LCCSCS$1.CommunityShortSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296317259)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296317259);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fJEF.LCCSCS$1.CommunityShortSettingsTypeDescriptor.GenerateProperties($.$fJEF.LCCSCS$1.CommunityShortSettings, this, factory);
                    }, $VMlouk ??= {"r":65537,"n":"","d":1349963,"h":0,"f":17825794}), 0, "CommunityShortSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Short.Common\\Settings_CommunityShortSettings_LivingThing.Core.Community.Short.Common.Settings.CommunityShortSettingsTypeDescriptorBuilder.g.cs", "CommunityShortSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296317259)
            
            //--TRIMMABLE-BOUNDARY-START(12886251851)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886251851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886251851)
            
            //--TRIMMABLE-BOUNDARY-START(17181219147)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Short.Common.Settings.CommunityShortSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181219147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181219147)
            
            //--TRIMMABLE-BOUNDARY-START(8591284555)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Short.Common.Settings.CommunityShortSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591284555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fJEF.LCCSCS$1.CommunityShortSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fJEF.LCCSCS$1.CommunityShortSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$fJEF.LCCSCS$1.CommunityShortSettings)))
                {
                    /*var*/ let result = $.$fJEF.LCCSCS$1.CommunityShortSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fJEF.LCCSCS$1.CommunityShortSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fJEF.LCCSCS$1.CommunityShortSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$fJEF.LCCSCS$1.CommunityShortSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591284555)
            
            static $h = 1349963;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fJEF.LCCSCS$1.CommunityShortSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886251851),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1349963,
      "h": 12886251851,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886251851),
//--TRIMMABLE-BOUNDARY-START(17181219147),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1218891,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1349963,
      "h": 17181219147,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181219147),
//--TRIMMABLE-BOUNDARY-START(8591284555),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1218891,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1349963,
      "h": 8591284555,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591284555)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296317259),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1349963,
      "h": 4296317259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296317259)
  ],
  "h": 1349963
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fJEF.LCCSCS$1.CommunityShortSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Settings.CommunityShortSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Settings${separator}CommunityShortSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1349963)
        
        

        //--TRIMMABLE-BOUNDARY-START(497995)
        $asm.$cls(`$fJEF.LCCSCM.CommunityShortPostModel`, ($self) => class CommunityShortPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(34360236363)
            /*PostTypes */ get Type()
            {
                return 5889/*PostTypes.ShortPost*/;
            }
            //--TRIMMABLE-BOUNDARY-END(34360236363)
            
            //--TRIMMABLE-BOUNDARY-START(38655203659)
            /*CommunityShortVideoSource */ get VideoSource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475334475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fJEF.LCCSCM.CommunityShortVideoSource, new $.$fJEF.LCCSCM.CommunityShortVideoSource(), "VideoSource", null);
            }
            /*CommunityShortVideoSource */ set VideoSource(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065269067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fJEF.LCCSCM.CommunityShortVideoSource, $.$clone(value), "VideoSource");
            }
            //--TRIMMABLE-BOUNDARY-END(38655203659)
            
            //--TRIMMABLE-BOUNDARY-START(8593271220)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesCount.get
            get LCFCP$IPostReplyable$RepliesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478173108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593271220)
            
            //--TRIMMABLE-BOUNDARY-START(17183205812)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesDepth.get
            get LCFCP$IPostReplyable$RepliesDepth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773140404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesDepth;
            }
            //--TRIMMABLE-BOUNDARY-END(17183205812)
            
            //--TRIMMABLE-BOUNDARY-START(8594385332)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostVotable.VotesCount.get
            get LCFCP$IPostVotable$VotesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479287220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.VotesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8594385332)
            
            //--TRIMMABLE-BOUNDARY-START(17184319924)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostVotable.VotesCount.set
            set LCFCP$IPostVotable$VotesCount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479287220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.VotesCount = value;
            }
            //--TRIMMABLE-BOUNDARY-END(17184319924)
            
            //--TRIMMABLE-BOUNDARY-START(4295465291)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295465291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295465291)
            
            //--TRIMMABLE-BOUNDARY-START(4295465291)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295465291)
            
            static $h = 497995;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360236363),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885399883,
        "f": 50364417
      },
      "n": "Type",
      "d": 497995,
      "h": 34360236363,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360236363),
//--TRIMMABLE-BOUNDARY-START(38655203659),
    {
      "p": 825675,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475334475,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065269067,
        "f": 83886081
      },
      "n": "VideoSource",
      "d": 497995,
      "h": 38655203659,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": -2147483648,
              "t": 655361
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-video"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            },
            {
              "n": "Description",
              "v": "Video Source",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655203659)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295465291),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 497995,
      "h": 4295465291,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295465291)
  ],
  "h": 497995
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostVotable, $.$LCOv.LCFCP.IPostSharable, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Models${separator}CommunityShortPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(497995)
        
        

        //--TRIMMABLE-BOUNDARY-START(956747)
        $asm.$cls(`$fJEF.LCCSCS.ICommunityShortFeedRemoteService`, ($self) => class ICommunityShortFeedRemoteService
        {
            static $h = 956747;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 956747,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Services.ICommunityShortFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Services${separator}ICommunityShortFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(956747)
        
        

        //--TRIMMABLE-BOUNDARY-START(1087819)
        $asm.$cls(`$fJEF.LCCSCS.IComunityShortRemoteService`, ($self) => class IComunityShortRemoteService
        {
            static $h = 1087819;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1087819,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.IReadDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Services.IComunityShortRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Services${separator}IComunityShortRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1087819)
        
        

        //--TRIMMABLE-BOUNDARY-START(1022283)
        $asm.$cls(`$fJEF.LCCSCS.ICommunityShortFeedRemoteService_Mocking`, ($self) => class ICommunityShortFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295989579)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295989579);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295989579)
            
            //--TRIMMABLE-BOUNDARY-START(8590956875)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Short$Common$Models$CommunityShortPostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590956875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$fJEF.LCCSCM.CommunityShortPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$fJEF.LCCSCM.CommunityShortPostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590956875)
            
            static $h = 1022283;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295989579),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1022283,
      "h": 4295989579,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295989579)
  ],
  "h": 1022283
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fJEF.LCCSCS.ICommunityShortFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Services.ICommunityShortFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Services${separator}ICommunityShortFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1022283)
        
        

        //--TRIMMABLE-BOUNDARY-START(1153355)
        $asm.$cls(`$fJEF.LCCSCS.IComunityShortRemoteService_Mocking`, ($self) => class IComunityShortRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296120651)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296120651);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296120651)
            
            //--TRIMMABLE-BOUNDARY-START(8591087947)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Short$Common$Models$CommunityShortPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591087947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$fJEF.LCCSCM.CommunityShortPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$fJEF.LCCSCM.CommunityShortPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591087947)
            
            //--TRIMMABLE-BOUNDARY-START(17181022539)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Short$Common$Models$CommunityShortPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181022539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$fJEF.LCCSCM.CommunityShortPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fJEF.LCCSCM.CommunityShortPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181022539)
            
            //--TRIMMABLE-BOUNDARY-START(21475989835)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Short$Common$Models$CommunityShortPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475989835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$fJEF.LCCSCM.CommunityShortPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fJEF.LCCSCM.CommunityShortPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475989835)
            
            //--TRIMMABLE-BOUNDARY-START(25770957131)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Short$Common$Models$CommunityShortPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770957131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$fJEF.LCCSCM.CommunityShortPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$fJEF.LCCSCM.CommunityShortPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770957131)
            
            //--TRIMMABLE-BOUNDARY-START(12886055243)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886055243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$fJEF.LCCSCM.CommunityShortPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886055243)
            
            static $h = 1153355;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296120651),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1153355,
      "h": 4296120651,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296120651)
  ],
  "h": 1153355
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fJEF.LCCSCS.IComunityShortRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.IReadDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Services.IComunityShortRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Services${separator}IComunityShortRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1153355)
        
        

        //--TRIMMABLE-BOUNDARY-START(629067)
        $asm.$cls(`$fJEF.LCCSCM.CommunityShortPostModelTypeDescriptor`, ($self) => class CommunityShortPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fJEF.LCCSCM.CommunityShortPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295596363)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295596363);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fJEF.LCCSCM.CommunityShortPostModelTypeDescriptor.GenerateProperties($.$fJEF.LCCSCM.CommunityShortPostModel, this, factory);
                    }, $sLlXNa ??= {"r":65537,"n":"","d":629067,"h":0,"f":17825794}), 0, "CommunityShortPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Short.Common\\Models_CommunityShortPostModel_LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModelTypeDescriptorBuilder.g.cs", "CommunityShortPostModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295596363)
            
            //--TRIMMABLE-BOUNDARY-START(12885530955)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885530955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("VideoSource"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fJEF.LCCSCM.CommunityShortPostModel.$type, $.$discardRef(), "VideoSource", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("VideoSource")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fJEF.LCCSCM.CommunityShortVideoSource, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "VideoSource";
                        $i1.DelaredOn = "LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fJEF.LCCSCM.CommunityShortPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fJEF.LCCSCM.CommunityShortVideoSource, ($.$cast(target, $.$fJEF.LCCSCM.CommunityShortPostModel)).VideoSource);
                        }, $YzFUbd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":629067,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fJEF.LCCSCM.CommunityShortPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.VideoSource = value.AsValue($.$fJEF.LCCSCM.CommunityShortVideoSource);
                        }, $WepIJf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":629067,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fJEF.LCCSCM.CommunityShortPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Type";
                        $i3.DelaredOn = "LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fJEF.LCCSCM.CommunityShortPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$fJEF.LCCSCM.CommunityShortPostModel)).Type);
                        }, $CrgqNk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":629067,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885530955)
            
            //--TRIMMABLE-BOUNDARY-START(17180498251)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180498251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _VideoSource = _target.VideoSource;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("VideoSource"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fJEF.LCCSCM.CommunityShortVideoSource));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fJEF.LCCSCM.CommunityShortVideoSource, () => _VideoSource, ($v) => _VideoSource = $v, null, true)))
                    {
                        _target.VideoSource = $.$clone(_VideoSource);
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180498251)
            
            //--TRIMMABLE-BOUNDARY-START(8590563659)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590563659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fJEF.LCCSCM.CommunityShortPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fJEF.LCCSCM.CommunityShortPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fJEF.LCCSCM.CommunityShortPostModel)))
                {
                    /*var*/ let result = $.$fJEF.LCCSCM.CommunityShortPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fJEF.LCCSCM.CommunityShortPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fJEF.LCCSCM.CommunityShortPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fJEF.LCCSCM.CommunityShortPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590563659)
            
            static $h = 629067;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fJEF.LCCSCM.CommunityShortPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885530955),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 629067,
      "h": 12885530955,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885530955),
//--TRIMMABLE-BOUNDARY-START(17180498251),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 497995,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 629067,
      "h": 17180498251,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180498251),
//--TRIMMABLE-BOUNDARY-START(8590563659),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 497995,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 629067,
      "h": 8590563659,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590563659)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295596363),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 629067,
      "h": 4295596363,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295596363)
  ],
  "h": 629067
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fJEF.LCCSCM.CommunityShortPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Models.CommunityShortPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Models${separator}CommunityShortPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(629067)
        
        

        //--TRIMMABLE-BOUNDARY-START(235851)
        $asm.$cls(`$fJEF.LCCSCM.CommunityShortModel`, ($self) => class CommunityShortModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$fJEF.LCCSCS$1.CommunityShortSettings, $.$fJEF.LCCSCS$2.CommunityShortStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295203147)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295203147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295203147)
            
            //--TRIMMABLE-BOUNDARY-START(4295203147)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295203147)
            
            static $h = 235851;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$fJEF.LCCSCS$1.CommunityShortSettings, $.$fJEF.LCCSCS$2.CommunityShortStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295203147),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 235851,
      "h": 4295203147,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295203147)
  ],
  "h": 235851
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Models.CommunityShortModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Models${separator}CommunityShortModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(235851)
        
        

        //--TRIMMABLE-BOUNDARY-START(366923)
        $asm.$cls(`$fJEF.LCCSCM.CommunityShortModelTypeDescriptor`, ($self) => class CommunityShortModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fJEF.LCCSCM.CommunityShortModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295334219)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295334219);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fJEF.LCCSCM.CommunityShortModelTypeDescriptor.GenerateProperties($.$fJEF.LCCSCM.CommunityShortModel, this, factory);
                    }, $YVuSCj ??= {"r":65537,"n":"","d":366923,"h":0,"f":17825794}), 0, "CommunityShortModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Short.Common\\Models_CommunityShortModel_LivingThing.Core.Community.Short.Common.Models.CommunityShortModelTypeDescriptorBuilder.g.cs", "CommunityShortModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295334219)
            
            //--TRIMMABLE-BOUNDARY-START(12885268811)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885268811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$fJEF.LCCSCS$1.CommunityShortSettings, $.$fJEF.LCCSCS$2.CommunityShortStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885268811)
            
            //--TRIMMABLE-BOUNDARY-START(17180236107)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Short.Common.Models.CommunityShortModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180236107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Short.Common.Settings.CommunityShortSettings, LivingThing.Core.Community.Short.Common.States.CommunityShortStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$fJEF.LCCSCS$1.CommunityShortSettings, $.$fJEF.LCCSCS$2.CommunityShortStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$fJEF.LCCSCS$1.CommunityShortSettings, $.$fJEF.LCCSCS$2.CommunityShortStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180236107)
            
            //--TRIMMABLE-BOUNDARY-START(8590301515)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Short.Common.Models.CommunityShortModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590301515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fJEF.LCCSCM.CommunityShortModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fJEF.LCCSCM.CommunityShortModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fJEF.LCCSCM.CommunityShortModel)))
                {
                    /*var*/ let result = $.$fJEF.LCCSCM.CommunityShortModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fJEF.LCCSCM.CommunityShortModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fJEF.LCCSCM.CommunityShortModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fJEF.LCCSCM.CommunityShortModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590301515)
            
            static $h = 366923;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fJEF.LCCSCM.CommunityShortModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885268811),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 366923,
      "h": 12885268811,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885268811),
//--TRIMMABLE-BOUNDARY-START(17180236107),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 235851,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 366923,
      "h": 17180236107,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180236107),
//--TRIMMABLE-BOUNDARY-START(8590301515),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 235851,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 366923,
      "h": 8590301515,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590301515)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295334219),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 366923,
      "h": 4295334219,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295334219)
  ],
  "h": 366923
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fJEF.LCCSCM.CommunityShortModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Short.Common.Models.CommunityShortModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Short${separator}Common${separator}Models${separator}CommunityShortModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(366923)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(39243)
