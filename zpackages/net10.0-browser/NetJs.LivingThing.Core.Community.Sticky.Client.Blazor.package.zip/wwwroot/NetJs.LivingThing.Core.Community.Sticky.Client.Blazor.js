
//--TRIMMABLE-BOUNDARY-START(37915)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $MXzz) {
    "use strict";
    let _;
    let $ssJHHa;
    let $azKWMh;
    let $LLHVWd;
    let $Fmolyg;
    let $fsKVDd;
    let $OfluBa;
    let $uvIwvd;
    let $ARlnHh;
    let $Frqmqi;
    let $KLSFNc;
    let $FDHzmc;
    let $eccxoc;
    let $YBGvzf;
    let $AvPqdh;
    let $FtmZOf;
    let $rBpbLf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Sticky.Client.Blazor", 
    {
  "h": 37915,
  "f": "LivingThing.Core.Community.Sticky.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Sticky.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Sticky.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(168987)
        $asm.$cls(`$BHhH.LCCSC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295136283)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295136283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$BHhH.LCCSC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295136283)
            
            static $h = 168987;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295136283),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 168987,
      "h": 4295136283,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295136283)
  ],
  "h": 168987
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(168987)
        
        

        //--TRIMMABLE-BOUNDARY-START(627739)
        $asm.$cls(`$BHhH.LCCSCS.StickyFeedProvider`, ($self) => class StickyFeedProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590562331)
            /*RenderFragment? */ GetStickies(/*PostBaseModel?*/ parent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590562331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$BHhH.LCCSCS$1.StickyFeed, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590562331)
            
            //--TRIMMABLE-BOUNDARY-START(4314076608)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityStickyFeedProvider.GetStickies(LivingThing.Core.Frameworks.Common.Posts.Models.PostBaseModel?)
            LCCCS$ICommunityStickyFeedProvider$GetStickies()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4314076608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStickies(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4314076608)
            
            //--TRIMMABLE-BOUNDARY-START(4295595035)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295595035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295595035)
            
            //--TRIMMABLE-BOUNDARY-START(4295595035)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295595035)
            
            static $h = 627739;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590562331),
    {
      "r": 6881395,
      "p": [
        {
          "n": "parent",
          "p": 16771508
        }
      ],
      "n": "GetStickies",
      "d": 627739,
      "h": 8590562331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590562331)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295595035),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 627739,
      "h": 4295595035,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295595035)
  ],
  "h": 627739
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityStickyFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Client.Services.StickyFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Client${separator}Services${separator}StickyFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(627739)
        
        

        //--TRIMMABLE-BOUNDARY-START(234523)
        $asm.$cls(`$BHhH.LCCSC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180103707)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$BHhH.LCCSCP.CommunityStickyApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$BHhH.LCCSCP.CommunityStickyApp().$ctor$6();
                    }, $ssJHHa ??= {"r":2752627,"n":"","d":234523,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$BHhH.LCCSCS$1.StickyFeed.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$BHhH.LCCSCS$1.StickyFeed().$ctor$3();
                    }, $azKWMh ??= {"r":2752627,"n":"","d":234523,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180103707)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295201819)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295201819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295201819)
            
            //--TRIMMABLE-BOUNDARY-START(4295201819)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295201819)
            
            static $h = 234523;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180103707),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885136411,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 234523,
      "h": 17180103707,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180103707)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295201819),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 234523,
      "h": 4295201819,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295201819)
  ],
  "h": 234523
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(234523)
        
        

        //--TRIMMABLE-BOUNDARY-START(431131)
        $asm.$cls(`$BHhH.LCCSC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590365723)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590365723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$BHhH.LCCSCS.CommunityStickyService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$BHhH.LCCSCS.CommunityStickyApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BHhH.LCCSCS.CommunityStickyApplication, x);
                }, $LLHVWd ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":431131,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BHhH.LCCSCS.CommunityStickyApplication, x);
                }, $Fmolyg ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":431131,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BHhH.LCCSCS.CommunityStickyApplication, x);
                }, $fsKVDd ??= {"r":$.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference).$h,"p":[{"n":"x","p":327718}],"n":"","d":431131,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$MXzz.LCCSCM.CommunityStickyPostModel, services, null);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCS.ICommunityStickyFeedProvider, $.$BHhH.LCCSCS.StickyFeedProvider, services);
                $.$BHhH.LCCSC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590365723)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$BHhH.LCCSC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295398427)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295398427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295398427)
            
            //--TRIMMABLE-BOUNDARY-START(4295398427)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295398427)
            
            static $h = 431131;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590365723),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 431131,
      "h": 8590365723,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590365723)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295398427),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 431131,
      "h": 4295398427,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295398427)
  ],
  "h": 431131
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(431131)
        
        

        //--TRIMMABLE-BOUNDARY-START(758811)
        $asm.$cls(`$BHhH.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295726107)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295726107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295726107)
            
            //--TRIMMABLE-BOUNDARY-START(4295726107)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295726107)
            
            static $h = 758811;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295726107),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 758811,
      "h": 4295726107,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295726107)
  ],
  "h": 758811
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(758811)
        
        

        //--TRIMMABLE-BOUNDARY-START(824347)
        $asm.$cls(`$BHhH.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295791643)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295791643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295791643)
            
            //--TRIMMABLE-BOUNDARY-START(4295791643)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295791643)
            
            static $h = 824347;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295791643),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 824347,
      "h": 4295791643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295791643)
  ],
  "h": 824347,
  "a": [
    {
      "t": 758811,
      "c": 4295726107
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(824347)
        
        

        //--TRIMMABLE-BOUNDARY-START(365595)
        $asm.$cls(`$BHhH.LCCSCP.CommunityStickyList`, ($self) => class CommunityStickyList extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590300187)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590300187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590300187)
            
            //--TRIMMABLE-BOUNDARY-START(4295332891)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295332891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295332891)
            
            //--TRIMMABLE-BOUNDARY-START(4295332891)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295332891)
            
            static $h = 365595;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590300187),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 365595,
      "h": 8590300187,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590300187)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295332891),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 365595,
      "h": 4295332891,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295332891)
  ],
  "h": 365595
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Client.Pages.CommunityStickyList`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Client${separator}Pages${separator}CommunityStickyList`; }
        });
        //--TRIMMABLE-BOUNDARY-END(365595)
        
        

        //--TRIMMABLE-BOUNDARY-START(103451)
        $asm.$cls(`$BHhH.LCCSC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590038043)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590038043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590038043)
            
            //--TRIMMABLE-BOUNDARY-START(4295070747)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295070747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295070747)
            
            //--TRIMMABLE-BOUNDARY-START(4295070747)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295070747)
            
            static $h = 103451;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590038043),
    {
      "r": 65537,
      "n": "Execute",
      "d": 103451,
      "h": 8590038043,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590038043)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295070747),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 103451,
      "h": 4295070747,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295070747)
  ],
  "h": 103451
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(103451)
        
        

        //--TRIMMABLE-BOUNDARY-START(693275)
        $asm.$cls(`$BHhH.LCCSCS$1.StickyFeed`, ($self) => class StickyFeed extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21475529755)
            /*string */ get OptimizedComponentName()
            {
                return "stickyfeed";
            }
            //--TRIMMABLE-BOUNDARY-END(21475529755)
            
            //--TRIMMABLE-BOUNDARY-START(8590627867)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590627867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$MXzz.LCCSCM.CommunityStickyPostModel), 0);
                __builder.AddComponentParameter(1, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741841/*PostFilterTypes.Featured*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                __builder.AddComponentParameter(2, "RemoteFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCR$1.RemoteFeatures, 34/*RemoteFeatures.Default*/ | 8/*RemoteFeatures.ResultCaching*/), $.$hDPm.LCFCCR$1.RemoteFeatures));
                __builder.AddComponentParameter(3, "Class", "mgt");
                __builder.AddComponentParameter(4, "li-class", "mgt");
                __builder.AddAttribute$3(5, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$MXzz.LCCSCM.CommunityStickyPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$MXzz.LCCSCM.CommunityStickyPostModel))))().$ctor(this, ( (/*item*/ item) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        /*var*/ let icon = $.$fPer.LCFCT.EnumExtensions.GetIcon($.$box(item.Data.Type, $.$LCOv.LCFCPM$1.PostTypes));
                        __builder2.OpenElement(6, "a");
                        __builder2.AddAttribute$5(7, "href", item.Data.Link);
                        __builder2.AddMultipleAttributes(8, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass(icon.Theme.WithForeground(null).WithOpacity(0.1).ToHtmlAttributes("bg-"), "pd bd bg-error-01 flex cl-text"))));
                        __builder2.OpenElement(9, "i");
                        __builder2.AddMultipleAttributes(10, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass(icon.Theme.ToHtmlAttributes("bg-"), `${$.$strNN(icon.Icon)} mgy-a fsz-20 miwx-04 mawx-04 mihx-04 mahx-04 bd round flex mgc-a`))));
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(11, "\r\n            ");
                        __builder2.OpenElement(12, "div");
                        __builder2.AddAttribute$5(13, "class", "fill stack mgx-2");
                        __builder2.OpenElement(14, "b");
                        __builder2.AddContent$4(15, item.Data.Title);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(16, "\r\n                ");
                        __builder2.OpenElement(17, "small");
                        __builder2.AddAttribute$5(18, "class", "mgt-1 d-block");
                        __builder2.AddContent$4(19, $.$fPer.LCFCS$6.StringExtension.LimitLength(item.Data.Summary, 50, true));
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(20, "\r\n            <i class=\"mdi mdi-chevron-right mgy-a\"></i>");
                        __builder2.CloseElement();
                    }, $OfluBa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":693275,"h":0,"f":17825794});
                }), $uvIwvd ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$MXzz.LCCSCM.CommunityStickyPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$MXzz.LCCSCM.CommunityStickyPostModel)).$h}],"n":"","d":693275,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590627867)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295660571)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295660571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295660571)
            
            //--TRIMMABLE-BOUNDARY-START(4295660571)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295660571)
            
            static $h = 693275;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475529755),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180562459,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 693275,
      "h": 21475529755,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475529755)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590627867),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 693275,
      "h": 8590627867,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590627867)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295660571),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 693275,
      "h": 4295660571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295660571)
  ],
  "h": 693275
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Client.Shared.StickyFeed`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Client${separator}Shared${separator}StickyFeed`; }
        });
        //--TRIMMABLE-BOUNDARY-END(693275)
        
        

        //--TRIMMABLE-BOUNDARY-START(496667)
        $asm.$cls(`$BHhH.LCCSCS.CommunityStickyApplication`, ($self) => class CommunityStickyApplication extends $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(17180365851)
            $ctor$3(/*CommunityStickyService*/ service)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180365851);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180365851)
            
            //--TRIMMABLE-BOUNDARY-START(150324352027)
            /*string */ get Name()
            {
                return "Sticky";
            }
            //--TRIMMABLE-BOUNDARY-END(150324352027)
            
            //--TRIMMABLE-BOUNDARY-START(171799188507)
            /*string */ get Title()
            {
                return "Sticky";
            }
            //--TRIMMABLE-BOUNDARY-END(171799188507)
            
            //--TRIMMABLE-BOUNDARY-START(25770300443)
            /*string */ get Description()
            {
                return "Zoey's own self management and reporting application";
            }
            //--TRIMMABLE-BOUNDARY-END(25770300443)
            
            //--TRIMMABLE-BOUNDARY-START(146029384731)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-pin"/*MaterialDesignIconNames.Pin*/);
            }
            //--TRIMMABLE-BOUNDARY-END(146029384731)
            
            //--TRIMMABLE-BOUNDARY-START(167504221211)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#0C3B76";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(167504221211)
            
            //--TRIMMABLE-BOUNDARY-START(34360235035)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(34360235035)
            
            //--TRIMMABLE-BOUNDARY-START(21475333147)
            /*Type? */ get ApplicationViewType()
            {
                return $.$BHhH.LCCSCP.CommunityStickyApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(21475333147)
            
            //--TRIMMABLE-BOUNDARY-START(141734417435)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734417435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$BHhH.LCCSCP.CommunityStickyApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(141734417435)
            
            //--TRIMMABLE-BOUNDARY-START(30065267739)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065267739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(30065267739)
            
            //--TRIMMABLE-BOUNDARY-START(154619319323)
            /*int */ get Order()
            {
                return 6000;
            }
            //--TRIMMABLE-BOUNDARY-END(154619319323)
            
            //--TRIMMABLE-BOUNDARY-START(158914286619)
            /*IEnumerable<IClientApplicationPage>?*/ Pages$1 = null;
            //--TRIMMABLE-BOUNDARY-END(158914286619)
            
            //--TRIMMABLE-BOUNDARY-START(4295463963)
            /*CommunityStickyService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295463963)
            
            //--TRIMMABLE-BOUNDARY-START(163209253915)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(163209253915)
            
            //--TRIMMABLE-BOUNDARY-START(176094155803)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(256/*PostTypes.Sticky*/, 262/*PostTypes.StickyEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(176094155803)
            
            static $h = 496667;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(150324352027),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899842587,
        "f": 50364417
      },
      "n": "Name",
      "d": 496667,
      "h": 150324352027,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324352027),
//--TRIMMABLE-BOUNDARY-START(171799188507),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849515547,
        "f": 50364417
      },
      "n": "Title",
      "d": 496667,
      "h": 171799188507,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(171799188507),
//--TRIMMABLE-BOUNDARY-START(25770300443),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130038811,
        "f": 50364417
      },
      "n": "Description",
      "d": 496667,
      "h": 25770300443,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770300443),
//--TRIMMABLE-BOUNDARY-START(146029384731),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309907995,
        "f": 50364417
      },
      "n": "Icon",
      "d": 496667,
      "h": 146029384731,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029384731),
//--TRIMMABLE-BOUNDARY-START(167504221211),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259580955,
        "f": 50364417
      },
      "n": "Theme",
      "d": 496667,
      "h": 167504221211,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(167504221211),
//--TRIMMABLE-BOUNDARY-START(34360235035),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719973403,
        "f": 50364417
      },
      "n": "Features",
      "d": 496667,
      "h": 34360235035,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360235035),
//--TRIMMABLE-BOUNDARY-START(21475333147),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540104219,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 496667,
      "h": 21475333147,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475333147),
//--TRIMMABLE-BOUNDARY-START(154619319323),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489777179,
        "f": 50364417
      },
      "n": "Order",
      "d": 496667,
      "h": 154619319323,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619319323),
//--TRIMMABLE-BOUNDARY-START(158914286619),
    {
      "p": $.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplicationPage).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079711771,
        "f": 50331649
      },
      "n": "Pages",
      "o": "@$1",
      "d": 496667,
      "h": 158914286619,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914286619),
//--TRIMMABLE-BOUNDARY-START(4295463963),
    {
      "p": 562203,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950169627,
        "f": 50331650
      },
      "n": "_Service",
      "d": 496667,
      "h": 4295463963,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295463963),
//--TRIMMABLE-BOUNDARY-START(163209253915),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669646363,
        "f": 50364417
      },
      "n": "Service",
      "d": 496667,
      "h": 163209253915,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209253915),
//--TRIMMABLE-BOUNDARY-START(176094155803),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439450139,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 496667,
      "h": 176094155803,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176094155803)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(141734417435),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 496667,
      "h": 141734417435,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(141734417435),
//--TRIMMABLE-BOUNDARY-START(30065267739),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 496667,
      "h": 30065267739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065267739)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180365851),
    {
      "p": [
        {
          "n": "service",
          "p": 562203
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 496667,
      "h": 17180365851,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180365851)
  ],
  "h": 496667
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Client.Services.CommunityStickyApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Client${separator}Services${separator}CommunityStickyApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(496667)
        
        

        //--TRIMMABLE-BOUNDARY-START(300059)
        $asm.$cls(`$BHhH.LCCSCP.CommunityStickyApp`, ($self) => class CommunityStickyApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(90194613275)
            /*CommunityStickyService*/ StickyService = null;
            //--TRIMMABLE-BOUNDARY-END(90194613275)
            
            //--TRIMMABLE-BOUNDARY-START(85899645979)
            /*CommunityStickyApplication*/ StickyApplication = null;
            //--TRIMMABLE-BOUNDARY-END(85899645979)
            
            //--TRIMMABLE-BOUNDARY-START(17180169243)
            /*ICommunityClientApplication */ get Application()
            {
                return this.StickyApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(17180169243)
            
            //--TRIMMABLE-BOUNDARY-START(64424809499)
            /*string */ get OptimizedComponentName()
            {
                return "communitystickyapp communitydefaultpages";
            }
            //--TRIMMABLE-BOUNDARY-END(64424809499)
            
            //--TRIMMABLE-BOUNDARY-START(60129842203)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129842203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.StickyService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BHhH.LCCSCS.CommunityStickyService, serviceProvider);
                this.StickyApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BHhH.LCCSCS.CommunityStickyApplication, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(60129842203)
            
            //--TRIMMABLE-BOUNDARY-START(21475136539)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475136539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "Name", "Sticky");
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.StickyService));
                __builder.AddAttribute$3(4, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/*splash*/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 5);
                        __builder2.AddComponentParameter(6, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, splash.ViewModel));
                        __builder2.AddComponentParameter(7, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, splash.Message));
                        __builder2.CloseComponent();
                    }, $ARlnHh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":300059,"h":0,"f":17825794});
                }), $Frqmqi ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":300059,"h":0,"f":17825794}));
                __builder.AddAttribute$3(8, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent)))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(9, "<i class=\"mdi mdi-pin\"></i>");
                    }, $KLSFNc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":300059,"h":0,"f":17825794});
                }), $FDHzmc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent).$h}],"n":"","d":300059,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 11);
                        __builder2.AddComponentParameter(12, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                        __builder2.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(14, wrap.View);
                        }), $eccxoc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":300059,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $YBGvzf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":300059,"h":0,"f":17825794});
                }), $AvPqdh ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":300059,"h":0,"f":17825794}));
                __builder.AddAttribute$3(15, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$1(16, this.GetPages());
                }), $FtmZOf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":300059,"h":0,"f":17825794}));
                __builder.AddComponentReferenceCapture(17, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.App = $.$cast(__value, $.$lJUR.LCFCS.Application);
                }, $rBpbLf ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":300059,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21475136539)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885201947)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885201947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885201947)
            
            //--TRIMMABLE-BOUNDARY-START(12885201947)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12885201947)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(90194613275)
                this.StickyService = null;
                //--TRIMMABLE-BOUNDARY-END(90194613275)
                
                //--TRIMMABLE-BOUNDARY-START(85899645979)
                this.StickyApplication = null;
                //--TRIMMABLE-BOUNDARY-END(85899645979)
                
            }
            static $h = 300059;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90194613275),
    {
      "p": 562203,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834874907,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604678683,
        "f": 83886081
      },
      "n": "StickyService",
      "d": 300059,
      "h": 90194613275,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194613275),
//--TRIMMABLE-BOUNDARY-START(85899645979),
    {
      "p": 496667,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244940315,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014744091,
        "f": 83886081
      },
      "n": "StickyApplication",
      "d": 300059,
      "h": 85899645979,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85899645979),
//--TRIMMABLE-BOUNDARY-START(17180169243),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065071131,
        "f": 50364420
      },
      "n": "Application",
      "d": 300059,
      "h": 17180169243,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(17180169243),
//--TRIMMABLE-BOUNDARY-START(64424809499),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655005723,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 300059,
      "h": 64424809499,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64424809499)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60129842203),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 300059,
      "h": 60129842203,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60129842203),
//--TRIMMABLE-BOUNDARY-START(21475136539),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 300059,
      "h": 21475136539,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475136539)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885201947),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 300059,
      "h": 12885201947,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885201947)
  ],
  "h": 300059
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Client.Pages.CommunityStickyApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Client${separator}Pages${separator}CommunityStickyApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(300059)
        
        

        //--TRIMMABLE-BOUNDARY-START(562203)
        $asm.$cls(`$BHhH.LCCSCS.CommunityStickyService`, ($self) => class CommunityStickyService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295529499)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295529499);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295529499)
            
            static $h = 562203;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295529499),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 562203,
      "h": 4295529499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295529499)
  ],
  "h": 562203
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$MXzz.LCCSCM.CommunityStickyPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Client.Services.CommunityStickyService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Client${separator}Services${separator}CommunityStickyService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(562203)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Sticky.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(37915)
