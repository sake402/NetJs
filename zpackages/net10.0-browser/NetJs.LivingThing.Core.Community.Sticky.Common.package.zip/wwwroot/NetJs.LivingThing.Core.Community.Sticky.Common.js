
//--TRIMMABLE-BOUNDARY-START(27255)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $hmnbeg;
    let $XKpqzi;
    let $WwZAsa;
    let $KmZEjh;
    let $PYpBKa;
    let $otrmsk;
    let $srzyyk;
    let $rZlVWc;
    let $CYfAra;
    let $jgtfea;
    let $ryqRck;
    let $NCnQbg;
    let $EZCbli;
    let $nZOwEg;
    let $Zvocrg;
    let $hjGxjl;
    let $neKkyk;
    let $muJSqi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Sticky.Common", 
    {
  "h": 27255,
  "f": "LivingThing.Core.Community.Sticky.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Sticky.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Sticky.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(617079)
        $asm.$cls(`$MXzz.LCCSCS.IStickyRemoteService`, ($self) => class IStickyRemoteService
        {
            static $h = 617079;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 617079,
  "a": [
    {
      "t": 3537875,
      "c": 8593472467,
      "a": [
        {
          "v": [$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$MXzz.LCCSCM.CommunityStickyPostModel).$h
          ],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Common.Services.IStickyRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Common${separator}Services${separator}IStickyRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(617079)
        
        

        //--TRIMMABLE-BOUNDARY-START(92791)
        $asm.$cls(`$MXzz.LCCSC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295060087)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295060087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MXzz.LCCSCM.CommunityStickyPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MXzz.LCCSCM.CommunityStickyPostModelCustomAttributesProvider, $.$MXzz.LCCSCM.CommunityStickyPostModelCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295060087)
            
            static $h = 92791;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295060087),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 92791,
      "h": 4295060087,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295060087)
  ],
  "h": 92791
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(92791)
        
        

        //--TRIMMABLE-BOUNDARY-START(748151)
        $asm.$cls(`$MXzz.LCCSC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295715447)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295715447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MXzz.LCCSCM.CommunityStickyPostModelTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4295715447)
            
            static $h = 748151;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295715447),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 748151,
      "h": 4295715447,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295715447)
  ],
  "h": 748151
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(748151)
        
        

        //--TRIMMABLE-BOUNDARY-START(289399)
        $asm.$cls(`$MXzz.LCCSCM.CommunityStickyPostModelCustomAttributesProvider`, ($self) => class CommunityStickyPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295256695)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295256695)
            
            //--TRIMMABLE-BOUNDARY-START(8590223991)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590223991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$MXzz.LCCSCM.CommunityStickyPostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("SetType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.Title = "Type";
                            $i3.Description = "Select the type of sticky you are creating";
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-source-branch"], [-1], null);
                            $i3.OptionsReader = ($.$MXzz.LCCSCM.CommunityStickyTypeReader.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("IsThread", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$MXzz.LCCSCM.CommunityStickyPostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $XKpqzi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":289399,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $WwZAsa ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":289399,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$($.$MXzz.LCCSCM.CommunityStickyPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590223991)
            
            static $h = 289399;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590223991),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 289399,
      "h": 8590223991,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590223991)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295256695),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 289399,
      "h": 4295256695,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295256695)
  ],
  "h": 289399
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Common${separator}Models${separator}CommunityStickyPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(289399)
        
        

        //--TRIMMABLE-BOUNDARY-START(158327)
        $asm.$cls(`$MXzz.LCCSC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295125623)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295125623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$MXzz.LCCSCS.IStickyRemoteService, $.$MXzz.LCCSCS.IStickyRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$MXzz.LCCSCS.IStickyRemoteService_Mocking().$ctor$3(impl);
                }, $KmZEjh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":158327,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking().$ctor$3(impl);
                }, $PYpBKa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":158327,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking().$ctor$3(impl);
                }, $otrmsk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":158327,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking().$ctor$3(impl);
                }, $srzyyk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":158327,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking().$ctor$3(impl);
                }, $rZlVWc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":158327,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking().$ctor$3(impl);
                }, $CYfAra ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":158327,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking().$ctor$3(impl);
                }, $jgtfea ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":158327,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking().$ctor$3(impl);
                }, $ryqRck ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":158327,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295125623)
            
            static $h = 158327;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295125623),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 158327,
      "h": 4295125623,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295125623)
  ],
  "h": 158327
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(158327)
        
        

        //--TRIMMABLE-BOUNDARY-START(420471)
        $asm.$cls(`$MXzz.LCCSCM.CommunityStickyPostModelTypeDescriptorBuilder`, ($self) => class CommunityStickyPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590355063)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590355063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MXzz.LCCSCM.CommunityStickyPostModelTypeDescriptor()
                        const $t1 = $.$MXzz.LCCSCM.CommunityStickyPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $NCnQbg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":420471,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MXzz.LCCSCM.CommunityStickyPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590355063)
            
            //--TRIMMABLE-BOUNDARY-START(4295387767)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295387767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295387767)
            
            //--TRIMMABLE-BOUNDARY-START(4295387767)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295387767)
            
            static $h = 420471;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590355063),
    {
      "r": 65537,
      "n": "Register",
      "d": 420471,
      "h": 8590355063,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590355063)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295387767),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 420471,
      "h": 4295387767,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295387767)
  ],
  "h": 420471
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Common${separator}Models${separator}CommunityStickyPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(420471)
        
        

        //--TRIMMABLE-BOUNDARY-START(551543)
        $asm.$cls(`$MXzz.LCCSC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590486135)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590486135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$MXzz.LCCSCM.CommunityStickyPostModel, 256/*PostTypes.Sticky*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$MXzz.LCCSCM.CommunityStickyPostModel, 257/*PostTypes.StickyAnnouncement*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$MXzz.LCCSCM.CommunityStickyPostModel, 261/*PostTypes.StickyBugReport*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$MXzz.LCCSCM.CommunityStickyPostModel, 260/*PostTypes.StickyFeatureRequest*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$MXzz.LCCSCM.CommunityStickyPostModel, 259/*PostTypes.StickyNews*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$MXzz.LCCSCM.CommunityStickyPostModel, 258/*PostTypes.StickyRules*/);
                $.$MXzz.LCCSC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$MXzz.LCCSC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$MXzz.LCCSC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590486135)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$MXzz.LCCSC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295518839)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295518839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295518839)
            
            //--TRIMMABLE-BOUNDARY-START(4295518839)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295518839)
            
            static $h = 551543;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590486135),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 551543,
      "h": 8590486135,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590486135)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295518839),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 551543,
      "h": 4295518839,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295518839)
  ],
  "h": 551543
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(551543)
        
        

        //--TRIMMABLE-BOUNDARY-START(682615)
        $asm.$cls(`$MXzz.LCCSCS.IStickyRemoteService_Mocking`, ($self) => class IStickyRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295649911)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295649911);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295649911)
            
            static $h = 682615;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295649911),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 682615,
      "h": 4295649911,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295649911)
  ],
  "h": 682615
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$MXzz.LCCSCS.IStickyRemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Common.Services.IStickyRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Common${separator}Services${separator}IStickyRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(682615)
        
        

        //--TRIMMABLE-BOUNDARY-START(486007)
        $asm.$cls(`$MXzz.LCCSCM.CommunityStickyTypeReader`, ($self) => class CommunityStickyTypeReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590420599)
            /*Pager<ISelectOption<PostTypes?>> */ GetOptions(/*object*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590420599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let isAdmin = false;
                return $.$LCOv.LCFCP.PostUtility.GetPostTypeOptions(this, "Sticky", new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.PostTypes, $.$$.S.Boolean))().$ctor(this,  (/*type*/ type) =>
                {
                    if (!isAdmin)
                    {
                        return type === 261/*PostTypes.StickyBugReport*/ || type === 260/*PostTypes.StickyFeatureRequest*/;
                    }
                    return true;
                }, $hmnbeg ??= {"r":262145,"p":[{"n":"type","p":21096884}],"n":"","d":486007,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590420599)
            
            //--TRIMMABLE-BOUNDARY-START(4297034070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaOptionReader<LivingThing.Core.Frameworks.Common.Posts.Models.PostTypes?>.GetOptions(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            [`LCFCA$1$ISchemaOptionReader$LivingThing$Core$Frameworks$Common$Posts$Models$PostTypes$LivingThing$Core$Frameworks$Common$Posts$Models$PostTypes$$GetOptions`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297034070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOptions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297034070)
            
            //--TRIMMABLE-BOUNDARY-START(4295453303)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295453303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295453303)
            
            //--TRIMMABLE-BOUNDARY-START(4295453303)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295453303)
            
            static $h = 486007;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590420599),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes))).$h,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "GetOptions",
      "d": 486007,
      "h": 8590420599,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590420599)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295453303),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 486007,
      "h": 4295453303,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295453303)
  ],
  "h": 486007
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyTypeReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Common${separator}Models${separator}CommunityStickyTypeReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(486007)
        
        

        //--TRIMMABLE-BOUNDARY-START(223863)
        $asm.$cls(`$MXzz.LCCSCM.CommunityStickyPostModel`, ($self) => class CommunityStickyPostModel extends $.$LCOv.LCFCPM$1.PostModel$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(94489504375)
            /*PostTypes */ get Type()
            {
                return this.SetType ?? 256/*PostTypes.Sticky*/;
            }
            //--TRIMMABLE-BOUNDARY-END(94489504375)
            
            //--TRIMMABLE-BOUNDARY-START(90194537079)
            /*PostTypes? */ get SetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064994935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.SetType;
            }
            /*PostTypes? */ set SetType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899569783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.SetType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(90194537079)
            
            //--TRIMMABLE-BOUNDARY-START(60129766007)
            /*IPost? */ get LCFCP$IPostThread$LastPost()
            {
                return this.LastPost;
            }
            //--TRIMMABLE-BOUNDARY-END(60129766007)
            
            //--TRIMMABLE-BOUNDARY-START(47244864119)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$2(this, null, "Sticky/Post", null, true);
            }
            //--TRIMMABLE-BOUNDARY-END(47244864119)
            
            //--TRIMMABLE-BOUNDARY-START(42949896823)
            /*bool */ get IsThread()
            {
                return this.Type === 260/*PostTypes.StickyFeatureRequest*/ || this.Type === 261/*PostTypes.StickyBugReport*/;
            }
            //--TRIMMABLE-BOUNDARY-END(42949896823)
            
            //--TRIMMABLE-BOUNDARY-START(64424733303)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424733303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Name", "Title", null, null, null, null);
                super.ModifyDescriptor(propertyBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(64424733303)
            
            //--TRIMMABLE-BOUNDARY-START(77309635191)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309635191);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309635191)
            
            //--TRIMMABLE-BOUNDARY-START(68719700599)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719700599);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719700599)
            
            //--TRIMMABLE-BOUNDARY-START(73014667895)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014667895);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014667895)
            
            //--TRIMMABLE-BOUNDARY-START(8594123188)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThread.IsThread.get
            get LCFCP$IPostThread$IsThread()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479025076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsThread;
            }
            //--TRIMMABLE-BOUNDARY-END(8594123188)
            
            //--TRIMMABLE-BOUNDARY-START(8594254260)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThreadPost.ParentId.get
            get LCFCP$IPostThreadPost$ParentId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889221556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParentId;
            }
            //--TRIMMABLE-BOUNDARY-END(8594254260)
            
            //--TRIMMABLE-BOUNDARY-START(21479156148)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostThreadPost.ParentId.set
            set LCFCP$IPostThreadPost$ParentId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889221556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ParentId = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21479156148)
            
            //--TRIMMABLE-BOUNDARY-START(8594385332)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostVotable.VotesCount.get
            get LCFCP$IPostVotable$VotesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479287220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.VotesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8594385332)
            
            //--TRIMMABLE-BOUNDARY-START(17184319924)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostVotable.VotesCount.set
            set LCFCP$IPostVotable$VotesCount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479287220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.VotesCount = value;
            }
            //--TRIMMABLE-BOUNDARY-END(17184319924)
            
            //--TRIMMABLE-BOUNDARY-START(8593271220)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesCount.get
            get LCFCP$IPostReplyable$RepliesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478173108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593271220)
            
            //--TRIMMABLE-BOUNDARY-START(17183205812)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesDepth.get
            get LCFCP$IPostReplyable$RepliesDepth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773140404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesDepth;
            }
            //--TRIMMABLE-BOUNDARY-END(17183205812)
            
            //--TRIMMABLE-BOUNDARY-START(8593992116)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSubscribable.SubscribersCount.get
            get LCFCP$IPostSubscribable$SubscribersCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888959412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SubscribersCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593992116)
            
            //--TRIMMABLE-BOUNDARY-START(8594319796)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostViewTrackable.ViewsCount.get
            get LCFCP$IPostViewTrackable$ViewsCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889287092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ViewsCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8594319796)
            
            //--TRIMMABLE-BOUNDARY-START(4295191159)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295191159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295191159)
            
            //--TRIMMABLE-BOUNDARY-START(4295191159)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295191159)
            
            static $h = 223863;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$($.$MXzz.LCCSCM.CommunityStickyPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94489504375),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654929527,
        "f": 50364417
      },
      "n": "Type",
      "d": 223863,
      "h": 94489504375,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(94489504375),
//--TRIMMABLE-BOUNDARY-START(90194537079),
    {
      "p": $.$typeNullable($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064994935,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899569783,
        "f": 83918849
      },
      "n": "SetType",
      "d": 223863,
      "h": 90194537079,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Title",
              "v": "Type",
              "t": 1310721
            },
            {
              "n": "Description",
              "v": "Select the type of sticky you are creating",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-source-branch"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            },
            {
              "n": "OptionsReader",
              "v": 486007,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194537079),
//--TRIMMABLE-BOUNDARY-START(60129766007),
    {
      "p": 1173940,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834798711,
        "f": 50331650
      },
      "n": "{4188596}.LastPost",
      "o": "LCFCP$IPostThread$LastPost",
      "d": 223863,
      "h": 60129766007,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60129766007),
//--TRIMMABLE-BOUNDARY-START(47244864119),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475060343,
        "f": 50364417
      },
      "n": "Link",
      "d": 223863,
      "h": 47244864119,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47244864119),
//--TRIMMABLE-BOUNDARY-START(42949896823),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885125751,
        "f": 50331649
      },
      "n": "IsThread",
      "d": 223863,
      "h": 42949896823,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42949896823)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64424733303),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 223863,
      "h": 64424733303,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64424733303),
//--TRIMMABLE-BOUNDARY-START(77309635191),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": 223863,
      "h": 77309635191,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77309635191),
//--TRIMMABLE-BOUNDARY-START(68719700599),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 223863,
      "h": 68719700599,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68719700599),
//--TRIMMABLE-BOUNDARY-START(73014667895),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 223863,
      "h": 73014667895,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73014667895)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295191159),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 223863,
      "h": 4295191159,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295191159)
  ],
  "h": 223863
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostThread, $.$LCOv.LCFCP.IPostThreadPost, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostVotable, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostPollable, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostSignable, $.$LCOv.LCFCP.IPostViewTrackable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Common${separator}Models${separator}CommunityStickyPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(223863)
        
        

        //--TRIMMABLE-BOUNDARY-START(813687)
        $asm.$cls(`$MXzz.LCFCR.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityStickyPostModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295780983)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295780983);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295780983)
            
            //--TRIMMABLE-BOUNDARY-START(8590748279)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Sticky$Common$Models$CommunityStickyPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590748279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$MXzz.LCCSCM.CommunityStickyPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$MXzz.LCCSCM.CommunityStickyPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590748279)
            
            //--TRIMMABLE-BOUNDARY-START(17180682871)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Sticky$Common$Models$CommunityStickyPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180682871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$MXzz.LCCSCM.CommunityStickyPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$MXzz.LCCSCM.CommunityStickyPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180682871)
            
            //--TRIMMABLE-BOUNDARY-START(21475650167)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Sticky$Common$Models$CommunityStickyPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475650167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$MXzz.LCCSCM.CommunityStickyPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$MXzz.LCCSCM.CommunityStickyPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475650167)
            
            //--TRIMMABLE-BOUNDARY-START(25770617463)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Sticky$Common$Models$CommunityStickyPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770617463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$MXzz.LCCSCM.CommunityStickyPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$MXzz.LCCSCM.CommunityStickyPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770617463)
            
            //--TRIMMABLE-BOUNDARY-START(12885715575)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885715575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$MXzz.LCCSCM.CommunityStickyPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885715575)
            
            static $h = 813687;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295780983),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 813687,
      "h": 4295780983,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295780983)
  ],
  "h": 813687
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$fPer.LCFCD.IReadDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityStickyPostModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityStickyPostModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(813687)
        
        

        //--TRIMMABLE-BOUNDARY-START(354935)
        $asm.$cls(`$MXzz.LCCSCM.CommunityStickyPostModelTypeDescriptor`, ($self) => class CommunityStickyPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MXzz.LCCSCM.CommunityStickyPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295322231)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295322231);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MXzz.LCCSCM.CommunityStickyPostModelTypeDescriptor.GenerateProperties($.$MXzz.LCCSCM.CommunityStickyPostModel, this, factory);
                    }, $EZCbli ??= {"r":65537,"n":"","d":354935,"h":0,"f":17825794}), 0, "CommunityStickyPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Sticky.Common\\Models_CommunityStickyPostModel_LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModelTypeDescriptorBuilder.g.cs", "CommunityStickyPostModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295322231)
            
            //--TRIMMABLE-BOUNDARY-START(12885256823)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885256823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SetType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MXzz.LCCSCM.CommunityStickyPostModel.$type, $.$discardRef(), "SetType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SetType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$LCOv.LCFCPM$1.PostTypes), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "SetType";
                        $i1.DelaredOn = "LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MXzz.LCCSCM.CommunityStickyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$MXzz.LCCSCM.CommunityStickyPostModel)).SetType);
                        }, $nZOwEg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":354935,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MXzz.LCCSCM.CommunityStickyPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SetType = value.AsNullableValue($.$LCOv.LCFCPM$1.PostTypes);
                        }, $Zvocrg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":354935,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MXzz.LCCSCM.CommunityStickyPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Type";
                        $i3.DelaredOn = "LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MXzz.LCCSCM.CommunityStickyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$MXzz.LCCSCM.CommunityStickyPostModel)).Type);
                        }, $hjGxjl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":354935,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MXzz.LCCSCM.CommunityStickyPostModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Link";
                        $i5.DelaredOn = "LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MXzz.LCCSCM.CommunityStickyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$MXzz.LCCSCM.CommunityStickyPostModel)).Link);
                        }, $neKkyk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":354935,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsThread"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MXzz.LCCSCM.CommunityStickyPostModel.$type, $.$discardRef(), "IsThread", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsThread")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "IsThread";
                        $i7.DelaredOn = "LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MXzz.LCCSCM.CommunityStickyPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$MXzz.LCCSCM.CommunityStickyPostModel)).IsThread);
                        }, $muJSqi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":354935,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$($.$MXzz.LCCSCM.CommunityStickyPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885256823)
            
            //--TRIMMABLE-BOUNDARY-START(17180224119)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180224119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$($.$MXzz.LCCSCM.CommunityStickyPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$($.$MXzz.LCCSCM.CommunityStickyPostModel)));
                {
                    /*var*/ let _SetType = _target.SetType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SetType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$LCOv.LCFCPM$1.PostTypes), () => _SetType, ($v) => _SetType = $v, null, true)))
                    {
                        _target.SetType = _SetType;
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _IsThread = _target.IsThread;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsThread"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsThread, ($v) => _IsThread = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180224119)
            
            //--TRIMMABLE-BOUNDARY-START(8590289527)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590289527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MXzz.LCCSCM.CommunityStickyPostModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MXzz.LCCSCM.CommunityStickyPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MXzz.LCCSCM.CommunityStickyPostModel)))
                {
                    /*var*/ let result = $.$MXzz.LCCSCM.CommunityStickyPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MXzz.LCCSCM.CommunityStickyPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MXzz.LCCSCM.CommunityStickyPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MXzz.LCCSCM.CommunityStickyPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590289527)
            
            static $h = 354935;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MXzz.LCCSCM.CommunityStickyPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885256823),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 354935,
      "h": 12885256823,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885256823),
//--TRIMMABLE-BOUNDARY-START(17180224119),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 223863,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 354935,
      "h": 17180224119,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180224119),
//--TRIMMABLE-BOUNDARY-START(8590289527),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 223863,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 354935,
      "h": 8590289527,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590289527)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295322231),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 354935,
      "h": 4295322231,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295322231)
  ],
  "h": 354935
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MXzz.LCCSCM.CommunityStickyPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Sticky.Common.Models.CommunityStickyPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Sticky${separator}Common${separator}Models${separator}CommunityStickyPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(354935)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(27255)
