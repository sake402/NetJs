﻿function beginStream(id, url, fullScreen) {
    window.clapprs = window.clapprs || {};
    var player = new Clappr.Player({
        source: url,
        parentId: "#" + id,
        autoPlay: true,
        mimeType: "video/mp4",
        width: '100%',
        height: '100%',
        disableErrorScreen: true, // Disable the internal error screen plugin
        //plugins: [ClapprPip.PipButton, ClapprPip.PipPlugin],
        events: {
            onError: function (e) {
                setTimeout(function () { player.configure(player.options); }, 500);
            }
        }
    });
    window.clapprs[id] = player;
    setTimeout(function () {
        player.play();
        if (fullScreen) {
            player.core.mediaControl.toggleFullscreen();
        }
    }, 500);
}
function pipStream(id) {
    var pip = window.pip;
    if (pip) {
        pip.destroy();
    }
    var player = window.clapprs[id];
    player.enterPictureInPicture();
    window.pip = player;
}
function destroyStream(id) {
    var player = window.clapprs[id];
    //if (player.isPlaying()) {
    //    pipStream(id);
    //} else {
    if (player == window.pip) {
        delete window.pip;
    }
    player.destroy();
    delete window.clapprs[id];
    //}
}

function playPause(id) {
    var player = window.clapprs[id];
    if (player.isPlaying()) {
        player.pause();
    } else {
        player.play();
    }
}

function streamFullScreen(id, go) {
    var player = window.clapprs[id];
    player.core.mediaControl.toggleFullscreen();
}

var handler;
//var backHandler;
//var noMoreBack = false;
function handleButtons(component) {
    if (handler) {
        document.removeEventListener("keydown", handler);
        //document.removeEventListener("backbutton", backHandler);
    }
    handler = function (key) {
        //console.log(event);
        var keys = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Enter", "Back"];
        if (keys.includes(key.key)) {
            if (key.key != "Enter") {
                key.preventDefault();
            }
            component.invokeMethodAsync("ButtonPressed", key.key);
            buttonTick();
        }
    };
    //backHandler = function (ev) {
    //    if (!noMoreBack) {
    //        ev.preventDefault();
    //        result = component.invokeMethodAsync("ButtonPressed", "Back");
    //        result.then(function (backed) {
    //            noMoreBack = !backed;
    //        });
    //    }
    //};
    document.addEventListener("keydown", handler);
    //document.addEventListener('backbutton', backHandler);
}

var player;
function buttonTick() {
    if (!player) {
        player = new Audio();
    }
    player.src = "_content/LivingThing.Core.Community.TV.App.Blazor/tone.wav";
    player.play();
}