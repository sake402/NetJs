
//--TRIMMABLE-BOUNDARY-START(19265)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mbc, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $mia, $mil, $mexl, $mit, $mij, $sih, $wZnq, $fnTP, $hqRR, $sitj, $Xjnw, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $uvJL, $DZqk, $kVHt, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $uVBI, $yleQ, $nYKj, $AvdQ, $xPgy, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $Bnua, $IHYd, $ZaYa, $OUNt, $aImc, $rAPp) {
    "use strict";
    let _;
    let $zEwvhk;
    let $aiKVjj;
    let $Rrtapb;
    let $yDCOVa;
    let $FBBsKe;
    let $LyJLEf;
    let $dEUKLg;
    let $QgUeVe;
    let $QmGwrg;
    let $XSPgMb;
    let $YhJGsf;
    let $XwluLg;
    let $obkWig;
    let $xzmQjf;
    let $ocaTMg;
    let $jjUAQe;
    let $HhHqke;
    let $psOaEh;
    let $sEyZJf;
    let $nqXdTh;
    let $LJOwcb;
    let $aQwWCa;
    let $acRtgh;
    let $WHwqpk;
    let $RwFHca;
    let $uZPPEc;
    let $tMXieb;
    let $clnKhh;
    let $oxxlcd;
    let $pSNUFf;
    let $hZBbjf;
    let $znnZKb;
    let $vahaWd;
    let $UqqsCk;
    let $hcBKnd;
    let $CfEBZd;
    let $nsDHqa;
    let $cIUVZi;
    let $qlGIDj;
    let $Kinfqi;
    let $UlTDNc;
    let $mZuCFc;
    let $Fbkmfl;
    let $fVIBVa;
    let $OdPLSe;
    let $EFFmvg;
    let $LMmFue;
    let $tloLBa;
    let $TgiPXk;
    let $ClhpEg;
    let $SYkMmj;
    let $aZlksd;
    let $SICyKb;
    let $vwltqc;
    let $PEfuxf;
    let $oWPqrf;
    let $ajwuBk;
    let $AqlOrk;
    let $WZjwWf;
    let $neFnWa;
    let $qLThRd;
    let $DFuTHg;
    let $srCQde;
    let $GBtUwf;
    let $JAfmUd;
    let $MhkqRb;
    let $veuNZd;
    let $rkvEtk;
    let $oMADvh;
    let $UaSIuj;
    let $HCBfzh;
    let $ntRBHk;
    let $CjuOll;
    let $ZZGIYk;
    let $WIIdDf;
    let $vIJbhd;
    let $KXgVHa;
    let $TJprCb;
    let $ynFtCd;
    let $hnaxph;
    let $sNXbTc;
    let $eJsLuk;
    let $KgOloj;
    let $yZHSzh;
    let $EInGUj;
    let $trSaja;
    let $pMykwf;
    let $YXdcZc;
    let $BIMEbj;
    let $rTzHXg;
    let $qVXAkd;
    let $Jznyik;
    let $cJdpbi;
    let $wyzBae;
    let $Fvfdzk;
    let $ncFVsf;
    let $QntyIf;
    let $bvnnzf;
    let $vKrWyc;
    let $mCbKKc;
    let $tcSPGg;
    let $YWQndh;
    let $gIbtEe;
    let $JRdGsi;
    let $SJBwub;
    let $jYSupe;
    let $BmVixi;
    let $AShgJd;
    let $vMQHNj;
    let $lURLLa;
    let $tfxgMf;
    let $XrZkak;
    let $VKtIZj;
    let $CRDxVg;
    let $yxEEuk;
    let $DIhbPi;
    let $qloWOe;
    let $EFJDfk;
    let $wNXtIg;
    let $GoFtsk;
    let $eqGape;
    let $nCUgMg;
    let $xDkXxk;
    let $HyDBfl;
    let $VhbLcd;
    let $eeygal;
    let $NBGkrf;
    let $dweISd;
    let $hsdKNk;
    let $YURLPb;
    let $TgmNNa;
    let $LtzsRb;
    let $ChKGDk;
    let $qlqWSe;
    let $XDwUSb;
    let $APVSIh;
    let $lzsKui;
    let $gHbYKi;
    let $VzReuk;
    let $fhCvKg;
    let $AXfBvd;
    let $wTSxpe;
    let $kSMbVj;
    let $QkKFbf;
    let $hKRCme;
    let $VNbbXe;
    let $VFsxtc;
    let $WccTJa;
    let $zjyLdl;
    let $ryDlJe;
    let $RQcPhc;
    let $SbDArh;
    let $iehvzi;
    let $PXgbRk;
    let $wkEccf;
    let $LGBidk;
    let $dlpLda;
    let $VtlHxd;
    let $fhDBIi;
    let $lCjsxh;
    let $xYdNvh;
    let $jYavSk;
    let $wHNBgb;
    let $UdpOJi;
    let $uHHbVc;
    let $daIifd;
    let $uhpsAj;
    let $ZRJbfe;
    let $mlNIUc;
    let $hgxwbh;
    let $DNqACd;
    let $LbVoQi;
    let $UCdiCk;
    let $DCubGc;
    let $NurlIh;
    let $HLwVRe;
    let $ZVooid;
    let $wVOREb;
    let $resTqf;
    let $XsncEg;
    let $agMUoj;
    let $ZGzNVa;
    let $pknLXi;
    let $XACURi;
    let $HHBPgj;
    let $ABEKff;
    let $BqMhbe;
    let $hCSoKb;
    let $zacZpk;
    let $bKMiTi;
    let $jpUTKd;
    let $nbCPqg;
    let $vTMGbi;
    let $Qfjcgj;
    let $YhdUrg;
    let $CnYsoe;
    let $fAonDc;
    let $sQeuvb;
    let $PXSGVb;
    let $yQMBQb;
    let $qfpZff;
    let $yxRtHa;
    let $xWRtLc;
    let $Qlbkbi;
    let $gVInVb;
    let $XBQdWk;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.TV.Client.Admin.Blazor", 
    {
  "h": 19265,
  "f": "LivingThing.Core.Community.TV.Client.Admin.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.TV.Client.Admin.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.TV.Client.Admin.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(281409)
        $asm.$cls(`$Cdtc.LCCTCA._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295248705)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295248705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$Cdtc.LCCTCA.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295248705)
            
            static $h = 281409;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295248705),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 281409,
      "h": 4295248705,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295248705)
  ],
  "h": 281409
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Admin._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Admin${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(281409)
        
        

        //--TRIMMABLE-BOUNDARY-START(412481)
        $asm.$cls(`$Cdtc.LCCTCA.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590347073)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590347073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$Cdtc.LCCTCAP.Admin, "LivingThing.Core.Community.TV.Client.Admin", "Pages\\Admin", "Admin", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Admin/TV", "/Admin/TV/{*Page}" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590347073)
            
            //--TRIMMABLE-BOUNDARY-START(4295379777)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295379777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295379777)
            
            //--TRIMMABLE-BOUNDARY-START(4295379777)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295379777)
            
            static $h = 412481;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590347073),
    {
      "r": 65537,
      "n": "Build",
      "d": 412481,
      "h": 8590347073,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590347073)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295379777),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 412481,
      "h": 4295379777,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295379777)
  ],
  "h": 412481
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Admin.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Admin${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(412481)
        
        

        //--TRIMMABLE-BOUNDARY-START(84801)
        $asm.$cls(`$Cdtc._LCCTCAPA.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295052097)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295052097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "ChildContent", __arg1);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295052097)
            
            //--TRIMMABLE-BOUNDARY-START(8590019393)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590019393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Theme", $.$clone(__arg0));
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590019393)
            
            //--TRIMMABLE-BOUNDARY-START(12884986689)
            static /*void */ CreateInputEditor_2(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884986689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Theme", $.$clone(__arg0));
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12884986689)
            
            //--TRIMMABLE-BOUNDARY-START(17179953985)
            static /*void */ CreateInputEditor_3(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179953985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Theme", $.$clone(__arg0));
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17179953985)
            
            static $h = 84801;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295052097),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 84801,
      "h": 4295052097,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295052097),
//--TRIMMABLE-BOUNDARY-START(8590019393),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 65309014
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 84801,
      "h": 8590019393,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590019393),
//--TRIMMABLE-BOUNDARY-START(12884986689),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 65309014
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_2",
      "d": 84801,
      "h": 12884986689,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12884986689),
//--TRIMMABLE-BOUNDARY-START(17179953985),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 65309014
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_3",
      "d": 84801,
      "h": 17179953985,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17179953985)
  ],
  "h": 84801
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.TV.Client.Admin.Pages.Admin.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Admin${separator}Pages${separator}Admin${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(84801)
        
        

        //--TRIMMABLE-BOUNDARY-START(346945)
        $asm.$cls(`$Cdtc.LCCTCA.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180216129)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Cdtc.LCCTCAP.Admin.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Cdtc.LCCTCAP.Admin().$ctor$3();
                    }, $zEwvhk ??= {"r":2752627,"n":"","d":346945,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180216129)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295314241)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295314241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295314241)
            
            //--TRIMMABLE-BOUNDARY-START(4295314241)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295314241)
            
            static $h = 346945;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180216129),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885248833,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 346945,
      "h": 17180216129,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180216129)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295314241),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 346945,
      "h": 4295314241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295314241)
  ],
  "h": 346945
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Admin.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Admin${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(346945)
        
        

        //--TRIMMABLE-BOUNDARY-START(150337)
        $asm.$cls(`$Cdtc.LCCTA.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590084929)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590084929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590084929)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Cdtc.LCCTA.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295117633)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295117633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295117633)
            
            //--TRIMMABLE-BOUNDARY-START(4295117633)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295117633)
            
            static $h = 150337;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590084929),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 150337,
      "h": 8590084929,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590084929)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295117633),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 150337,
      "h": 4295117633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295117633)
  ],
  "h": 150337
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Admin.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Admin${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(150337)
        
        

        //--TRIMMABLE-BOUNDARY-START(543553)
        $asm.$cls(`$Cdtc.LCCTCAS.M3UTVEditorProvider<>`, (T) => $asm.$gt(`$Cdtc.LCCTCAS.M3UTVEditorProvider<>`, [T], ($self) => class M3UTVEditorProvider$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(85899889473)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(85899889473)
            
            //--TRIMMABLE-BOUNDARY-START(68720020289)
            /*string?*/ m3u = null;
            //--TRIMMABLE-BOUNDARY-END(68720020289)
            
            //--TRIMMABLE-BOUNDARY-START(55835118401)
            /*bool */ get IsLiveTV()
            {
                return T.$type === $.$rAPp.LCCTFL.FreeLiveTVStream.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(55835118401)
            
            //--TRIMMABLE-BOUNDARY-START(60130085697)
            /*bool */ get IsMovie()
            {
                return T.$type === $.$rAPp.LCCTFM.FreeMovieStream.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(60130085697)
            
            //--TRIMMABLE-BOUNDARY-START(73014987585)
            /*void */ ParseM3U()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014987585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.m3u !== null)
                {
                    this.streams = $.$fPer.LCFCS$3.M3UPlaylistProvider.Parse(T, this.m3u, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014987585)
            
            //--TRIMMABLE-BOUNDARY-START(98784791361)
            /*IEnumerable<T>?*/ streams = null;
            //--TRIMMABLE-BOUNDARY-END(98784791361)
            
            //--TRIMMABLE-BOUNDARY-START(4295510849)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295510849);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295510849)
            
            //--TRIMMABLE-BOUNDARY-START(103079758657)
            /*IEnumerable<T>? */ get Streams()
            {
                return this.streams;
            }
            //--TRIMMABLE-BOUNDARY-END(103079758657)
            
            //--TRIMMABLE-BOUNDARY-START(77309954881)
            /*string? */ get Raw()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950216513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.m3u;
            }
            /*string? */ set Raw(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489824065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.m3u = value;
                this.ParseM3U();
            }
            //--TRIMMABLE-BOUNDARY-END(77309954881)
            
            //--TRIMMABLE-BOUNDARY-START(8590478145)
            /*IEnumerable<IStreamCategory>? */ get Categories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180412737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<T>?*/ let __ca1__;
                /*System.Collections.Generic.IEnumerable<string?>*/ let __ca2__;
                return $.$$.N.InterfaceVarianceStubHandler.Create(_ = ((__ca1__ = this.streams) !== null ? ((__ca2__ = $.$sl.SL.Enumerable.Select$1(T, $.$$.S.String, __ca1__, new ($.$$.S.Func$$$(T, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.CategoryId;
                }, $aiKVjj ??= {"r":1310721,"p":[{"n":"s","p":T?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}))) !== null ? $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$ZaYa.LCCTCS.StreamCategory, $.$sl.SL.Enumerable.Where($.$$.S.String, __ca2__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c !== null;
                }, $Rrtapb ??= {"r":262145,"p":[{"n":"c","p":1310721}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.String, $.$ZaYa.LCCTCS.StreamCategory))().$ctor(this,  (/*s*/ s) =>
                {
                    return (() =>
                    {
                        //new $.$ZaYa.LCCTCS.StreamCategory()
                        const $t1 = $.$ZaYa.LCCTCS.StreamCategory;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.CategoryName = s;
                        return $i1;
                    })();
                }, $yDCOVa ??= {"r":5280517,"p":[{"n":"s","p":1310721}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})) : null) : null), $.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS.StreamCategory), $.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS.IStreamCategory));
            }
            //--TRIMMABLE-BOUNDARY-END(8590478145)
            
            //--TRIMMABLE-BOUNDARY-START(107374725953)
            /*ValueTask */ Update(/*T*/ stream, /*int?*/ tmdbId, /*string?*/ genre, /*string?*/ plot, /*string?*/ posterUrl, /*string?*/ backdropUrl, /*string?*/ youtubeTrailer, /*DateTime?*/ releaseDate, /*TimeSpan?*/ duration, /*double?*/ votes, /*bool?*/ free, /*string?*/ categoryId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374725953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                stream.StreamId = tmdbId ?? stream.StreamId;
                stream.Description = plot ?? stream.Description;
                stream.PosterPhoto = posterUrl ?? stream.PosterPhoto;
                stream.BannerUrl = backdropUrl ?? stream.BannerUrl;
                stream.YoutubeTrailer = youtubeTrailer ?? stream.YoutubeTrailer;
                stream.Freemium = free ?? stream.Freemium;
                stream.Group = categoryId ?? stream.Group;
                this.m3u = $.$$.S.String.Join$5("\r\n\r\n", $.$sl.SL.Enumerable.Select$1(T, $.$$.S.String, this.streams, new ($.$$.S.Func$$$(T, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                {
                    return $.$dsp(s, T, ($t) => $t.GenerateM3U);
                }, $FBBsKe ??= {"r":1310721,"p":[{"n":"s","p":T?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(107374725953)
            
            //--TRIMMABLE-BOUNDARY-START(64425052993)
            /*Task<IEnumerable<T>> *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$(T)), $.$$.SCG.IEnumerable$$(T), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425052993);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.IsLiveTV)
                    {
                        let $t2, $r2;
                        this.m3u = ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$$.S.String, this.server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server.LCCTCS$ICommunityTVRemoteService$GetFreeLiveTVsM3U();
                        }, $LyJLEf ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)).$h,"p":[{"n":"server","p":3248901}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    else 
                    {
                        let $t3, $r3;
                        this.m3u = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$$.S.String, this.server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)))().$ctor(this,  (/**/ server) =>
                        {
                            return server.LCCTCS$ICommunityTVRemoteService$GetFreeMoviesM3U();
                        }, $dEUKLg ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)).$h,"p":[{"n":"server","p":3248901}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                    this.streams = $.$fPer.LCFCS$3.M3UPlaylistProvider.Parse(T, this.m3u, null);
                    return $.$$.N.AsyncResolver.Result($asnycContext, this.streams);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64425052993)
            
            //--TRIMMABLE-BOUNDARY-START(81604922177)
            /*ValueTask *//*async*/  Save()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604922177);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.IsLiveTV)
                    {
                        let $t4, $r4;
                        ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$ZaYa.LCCTCS.ICommunityTVRemoteService, this.server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server.LCCTCS$ICommunityTVRemoteService$SetFreeLiveTVsM3U(this.m3u);
                        }, $QgUeVe ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"server","p":3248901}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                    else 
                    {
                        let $t5, $r5;
                        ($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$ZaYa.LCCTCS.ICommunityTVRemoteService, this.server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server.LCCTCS$ICommunityTVRemoteService$SetFreeMoviesM3U(this.m3u);
                        }, $QmGwrg ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"server","p":3248901}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(81604922177)
            
            //--TRIMMABLE-BOUNDARY-START(12889723653)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.ITVEditorProvider<T>.Categories.get
            get LCCTCS$ITVEditorProvider$$$Categories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299789061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Categories;
            }
            //--TRIMMABLE-BOUNDARY-END(12889723653)
            
            //--TRIMMABLE-BOUNDARY-START(21479658245)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.ITVEditorProvider<T>.Streams.get
            get LCCTCS$ITVEditorProvider$$$Streams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34364560133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Streams;
            }
            //--TRIMMABLE-BOUNDARY-END(21479658245)
            
            //--TRIMMABLE-BOUNDARY-START(25774625541)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.ITVEditorProvider<T>.Load()
            LCCTCS$ITVEditorProvider$$$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25774625541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25774625541)
            
            //--TRIMMABLE-BOUNDARY-START(30069592837)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.ITVEditorProvider<T>.Save()
            LCCTCS$ITVEditorProvider$$$Save()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30069592837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Save(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30069592837)
            
            //--TRIMMABLE-BOUNDARY-START(38659527429)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.ITVEditorProvider<T>.Update(T, int?, string?, string?, string?, string?, string?, System.DateTime?, System.TimeSpan?, double?, bool?, string?)
            LCCTCS$ITVEditorProvider$$$Update()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38659527429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Update(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38659527429)
            
            //--TRIMMABLE-BOUNDARY-START(8594821893)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.ITVRawEditorProvider.Raw.get
            get LCCTCS$ITVRawEditorProvider$Raw()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889789189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Raw;
            }
            //--TRIMMABLE-BOUNDARY-END(8594821893)
            
            //--TRIMMABLE-BOUNDARY-START(21479723781)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.ITVRawEditorProvider.Raw.set
            set LCCTCS$ITVRawEditorProvider$Raw(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889789189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Raw = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21479723781)
            
            static $H = 543553;
            static $h = 543553;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835118401),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770347329,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331650
      },
      "n": "IsLiveTV",
      "d": this.$h,
      "H": 55835118401,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55835118401),
//--TRIMMABLE-BOUNDARY-START(60130085697),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360281921,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331650
      },
      "n": "IsMovie",
      "d": this.$h,
      "H": 60130085697,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60130085697),
//--TRIMMABLE-BOUNDARY-START(103079758657),
    {
      "p": $.$$.SCG.IEnumerable$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51540151105,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Streams",
      "d": this.$h,
      "H": 103079758657,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079758657),
//--TRIMMABLE-BOUNDARY-START(77309954881),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950216513,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 94489824065,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 83886081
      },
      "n": "Raw",
      "d": this.$h,
      "H": 77309954881,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309954881),
//--TRIMMABLE-BOUNDARY-START(8590478145),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS.IStreamCategory).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17180412737,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "Categories",
      "d": this.$h,
      "H": 8590478145,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590478145)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73014987585),
    {
      "r": 65537,
      "n": "ParseM3U",
      "d": this.$h,
      "H": 73014987585,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73014987585),
//--TRIMMABLE-BOUNDARY-START(107374725953),
    {
      "r": 181338113,
      "p": [
        {
          "n": "stream",
          "p": T?.$h??1572864
        },
        {
          "n": "tmdbId",
          "p": $.$typeNullable($.$$.S.Int32).$h,
          "f": 65
        },
        {
          "n": "genre",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "plot",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "posterUrl",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "backdropUrl",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "youtubeTrailer",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "releaseDate",
          "p": $.$typeNullable($.$$.S.DateTime).$h,
          "f": 65
        },
        {
          "n": "duration",
          "p": $.$typeNullable($.$$.S.TimeSpan).$h,
          "f": 65
        },
        {
          "n": "votes",
          "p": $.$typeNullable($.$$.S.Double).$h,
          "f": 65
        },
        {
          "n": "free",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65
        },
        {
          "n": "categoryId",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "Update",
      "d": this.$h,
      "H": 107374725953,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374725953),
//--TRIMMABLE-BOUNDARY-START(64425052993),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$(T)).$h,
      "n": "Load",
      "d": this.$h,
      "H": 64425052993,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(64425052993),
//--TRIMMABLE-BOUNDARY-START(81604922177),
    {
      "r": 181338113,
      "n": "Save",
      "d": this.$h,
      "H": 81604922177,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(81604922177)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(85899889473),
    {
      "t": 1309651,
      "n": "server",
      "d": this.$h,
      "H": 85899889473,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85899889473),
//--TRIMMABLE-BOUNDARY-START(68720020289),
    {
      "t": 1310721,
      "n": "m3u",
      "d": this.$h,
      "H": 68720020289,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68720020289),
//--TRIMMABLE-BOUNDARY-START(98784791361),
    {
      "t": $.$$.SCG.IEnumerable$$(T).$h,
      "n": "streams",
      "d": this.$h,
      "H": 98784791361,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98784791361)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295510849),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295510849,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295510849)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "f": 4,
      "c": [109424
      ]
    }
  ],
  "r": 1,
  "H": 543553,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ZaYa.LCCTCS.ITVEditorProvider$$(T), $.$ZaYa.LCCTCS.ITVRawEditorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Admin.Shared.M3UTVEditorProvider<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Admin${separator}Shared${separator}M3UTVEditorProvider$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(543553)
        
        

        //--TRIMMABLE-BOUNDARY-START(609089)
        $asm.$cls(`$Cdtc.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295576385)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295576385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295576385)
            
            //--TRIMMABLE-BOUNDARY-START(4295576385)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295576385)
            
            static $h = 609089;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295576385),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 609089,
      "h": 4295576385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295576385)
  ],
  "h": 609089
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(609089)
        
        

        //--TRIMMABLE-BOUNDARY-START(674625)
        $asm.$cls(`$Cdtc.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295641921)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295641921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295641921)
            
            //--TRIMMABLE-BOUNDARY-START(4295641921)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295641921)
            
            static $h = 674625;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295641921),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 674625,
      "h": 4295641921,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295641921)
  ],
  "h": 674625,
  "a": [
    {
      "t": 609089,
      "c": 4295576385
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(674625)
        
        

        //--TRIMMABLE-BOUNDARY-START(215873)
        $asm.$cls(`$Cdtc.LCCTCA._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590150465)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590150465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590150465)
            
            //--TRIMMABLE-BOUNDARY-START(4295183169)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295183169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295183169)
            
            //--TRIMMABLE-BOUNDARY-START(4295183169)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295183169)
            
            static $h = 215873;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590150465),
    {
      "r": 65537,
      "n": "Execute",
      "d": 215873,
      "h": 8590150465,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590150465)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295183169),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 215873,
      "h": 4295183169,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295183169)
  ],
  "h": 215873
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Admin._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Admin${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(215873)
        
        

        //--TRIMMABLE-BOUNDARY-START(478017)
        $asm.$cls(`$Cdtc.LCCTCAP.Admin`, ($self) => class Admin extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(137439431489)
            /*string */ get OptimizedComponentName()
            {
                return "admin";
            }
            //--TRIMMABLE-BOUNDARY-END(137439431489)
            
            //--TRIMMABLE-BOUNDARY-START(223338777409)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338777409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(223338777409)
            
            //--TRIMMABLE-BOUNDARY-START(120259562305)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259562305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Rendering = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IUIRenderingProvider, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aImc.LCCTCS.CommunityTVService, serviceProvider);
                this.UI = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientService, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(120259562305)
            
            //--TRIMMABLE-BOUNDARY-START(141734398785)
            /*string*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(141734398785)
            
            //--TRIMMABLE-BOUNDARY-START(154619300673)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(154619300673)
            
            //--TRIMMABLE-BOUNDARY-START(146029366081)
            /*IUIRenderingProvider*/ Rendering = null;
            //--TRIMMABLE-BOUNDARY-END(146029366081)
            
            //--TRIMMABLE-BOUNDARY-START(158914267969)
            /*CommunityTVService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(158914267969)
            
            //--TRIMMABLE-BOUNDARY-START(227633744705)
            /*IUIClientService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(227633744705)
            
            //--TRIMMABLE-BOUNDARY-START(124554529601)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(124554529601)
            
            //--TRIMMABLE-BOUNDARY-START(47245118273)
            /*M3UTVEditorProvider<FreeLiveTVStream>*/ freeLiveTVProvider = null;
            //--TRIMMABLE-BOUNDARY-END(47245118273)
            
            //--TRIMMABLE-BOUNDARY-START(51540085569)
            /*M3UTVEditorProvider<FreeMovieStream>*/ freeMoviesProvider = null;
            //--TRIMMABLE-BOUNDARY-END(51540085569)
            
            //--TRIMMABLE-BOUNDARY-START(128849496897)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849496897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.freeLiveTVProvider = new ($.$Cdtc.LCCTCAS.M3UTVEditorProvider$$($.$rAPp.LCCTFL.FreeLiveTVStream))().$ctor$1(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server);
                this.freeMoviesProvider = new ($.$Cdtc.LCCTCAS.M3UTVEditorProvider$$($.$rAPp.LCCTFM.FreeMovieStream))().$ctor$1(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server);
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(128849496897)
            
            //--TRIMMABLE-BOUNDARY-START(133144464193)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144464193);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.Rendering.LCFCC$IUIRenderingProvider$IsPreRendering)
                    {
                        let $t2, $r2;
                        this.Service.IsAdmin = true;
                        ($t2 = this.Service.Load(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(133144464193)
            
            //--TRIMMABLE-BOUNDARY-START(34360216385)
            /*Dictionary<CommunityTVServiceTierModel, RemoteDataTable<CommunityTVActiveCodeModel>>*/ activeCodeLists = null;
            //--TRIMMABLE-BOUNDARY-END(34360216385)
            
            //--TRIMMABLE-BOUNDARY-START(38655183681)
            /*Task *//*async*/  AddActiveCode(/*CommunityTVServiceTierModel*/ tier)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t5, $r5;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655183681);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let codes = ($t4 = this.UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Prompt($.$$.S.String, "Active codes", "Paste active codes here", "OK", "Cancel", null, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    /*var*/ let splited = $.$$.S.String.Split$4.call($.$$.S.String.Trim.call(codes), $.$$.S.String.ToCharArray.call(",\r\n "), 1/*StringSplitOptions.RemoveEmptyEntries*/);
                    /*var*/ let _codes = (($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$sl.SL.Enumerable.ToArray($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$sl.SL.Enumerable.Where($.$$.S.String, splited, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return !$.$$.S.String.IsNullOrEmpty(c) && !$.$$.S.String.IsNullOrWhiteSpace(c);
                    }, $XSPgMb ??= {"r":262145,"p":[{"n":"c","p":1310721}],"n":"","d":478017,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.String, $.$ZaYa.LCCTCM.CommunityTVActiveCodeModel))().$ctor(this,  (/*code*/ code) =>
                    {
                        return (() =>
                        {
                            //new $.$ZaYa.LCCTCM.CommunityTVActiveCodeModel()
                            const $t6 = $.$ZaYa.LCCTCM.CommunityTVActiveCodeModel;
                            const $i6 = new $t6();
                            $i6.$ctor$6();
                            $i6.Name = code;
                            $i6.Validity = tier.Months;
                            return $i6;
                        })();
                    }, $YhJGsf ??= {"r":627461,"p":[{"n":"code","p":1310721}],"n":"","d":478017,"h":0,"f":17825794})))), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)))).AsEnumerable();
                    ($t7 = this.activeCodeLists.get_Item(tier).Add$1($.$sl.SL.Enumerable.ToArray($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, _codes)), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38655183681)
            
            //--TRIMMABLE-BOUNDARY-START(150324333377)
            /*ValueTask *//*async*/  SaveGlobalSettings(/*CommunityTVGlobalSettings*/ settings)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324333377);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t8 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$ZaYa.LCCTCS.ICommunityTVRemoteService, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LCCTCS$ICommunityTVRemoteService$SaveGlobalSettings(settings);
                    }, $XwluLg ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"server","p":3248901}],"n":"","d":478017,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(150324333377)
            
            //--TRIMMABLE-BOUNDARY-START(42950150977)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950150977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Cdtc._LCCTCAPA.TypeInference.CreateCascadingValue_0($.$Cdtc.LCCTCAP.Admin, __builder, 0, 1, this, 2, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.Application, 3);
                    __builder2.AddComponentParameter(4, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Admin/TV")));
                    __builder2.AddComponentParameter(5, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                    __builder2.AddComponentParameter(6, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ | 128/*ApplicationFeatures.ToolBarBorder*/ | 2048/*ApplicationFeatures.LeftSideBarBorder*/), $.$lJUR.LCFCS.ApplicationFeatures));
                    __builder2.AddAttribute$3(7, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(8, "<i class=\"mdi mdi-youtube-tv cl-error\"></i>");
                        }, $obkWig ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                    }), $xzmQjf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(9, "ToolBars", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                        }, $ocaTMg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                    }), $jjUAQe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(10, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 11);
                        __builder3.AddComponentParameter(12, "Name", "");
                        __builder3.AddComponentParameter(13, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("**"/*RoutePath.ZeroOrMorePathSegment*/)));
                        __builder3.AddComponentParameter(14, "Class", "pd");
                        __builder3.AddAttribute$3(15, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(16, "Dashboard");
                            }, $HhHqke ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $psOaEh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(17, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(18, "<i class=\"mdi mdi-monitor\"></i>");
                            }, $sEyZJf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $nqXdTh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(19, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenElement(20, "div");
                                __builder4.AddAttribute$5(21, "class", "pd bg-error-02 bdl bd-error bdw-2");
                                if ($.$$.S.String.IsNullOrEmpty(this.Service.TVPlayerService.AdminSettings.AdminActiveCode))
                                {
                                    __builder4.AddMarkupContent(22, "<b>Hi there, No Admin Active Code is provided.</b>");
                                }
                                else 
                                {
                                    let $en9 = this.Service.TVPlayerService.StreamProviders.GetEnumerator();
                                    while ($en9.MoveNext())
                                    {
                                        let provider = $en9.Current;
                                        {
                                            let lprovider;
                                            if ($.$is(provider, $.$ZaYa.LCCTCS.ILoginStreamProvider, { set $v($v){ lprovider = $v; } }))
                                            {
                                                __builder4.OpenComponent$1($.$hDPm.LCFCCT$3.TaskView$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)), 23);
                                                __builder4.AddComponentParameter(24, "Task", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)), $.$$.S.Func$$($.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))), $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))), $.$fPer.LCFCR.ReactiveObservable$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))), $.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)), $.$$.S.Func$$($.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))), $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))), $.$fPer.LCFCR.ReactiveObservable$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))).op_Implicit$2(new ($.$$.S.Func$$($.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))))().$ctor(this, ( () =>
                                                {
                                                    return lprovider.LCCTCS$ILoginStreamProvider$Authenticate((() =>
                                                    {
                                                        //new $.$ZaYa.LCCTCS.TVLogin()
                                                        const $t10 = $.$ZaYa.LCCTCS.TVLogin;
                                                        const $i10 = new $t10();
                                                        $i10.$ctor$1();
                                                        $i10.ActiveCode = this.Service.TVPlayerService.AdminSettings.AdminActiveCode;
                                                        return $i10;
                                                    })());
                                                }), $LJOwcb ??= {"r":$.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)).$h,"n":"","d":478017,"h":0,"f":17825794}))));
                                                __builder4.AddAttribute$3(25, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))))().$ctor(this, ( (/*user*/ user) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                    {
                                                        __builder5.OpenElement(26, "b");
                                                        __builder5.AddContent$4(27, "Hi there, Admin Active Code expired ");
                                                        __builder5.AddContent$3(28, (user.Data.Item1?.LCCTCS$ILoginAuthenticationResult$ExpiryDate ?? null));
                                                        __builder5.CloseElement();
                                                    }, $aQwWCa ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                                }), $acRtgh ??= {"r":6881395,"p":[{"n":"user","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                                __builder4.CloseComponent();
                                            }
                                        }
                                    }
                                }
                                __builder4.CloseElement();
                            }, $WHwqpk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $RwFHca ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(29, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 30);
                        __builder3.AddComponentParameter(31, "Name", "Devices");
                        __builder3.AddComponentParameter(32, "Class", "pd-10");
                        __builder3.AddAttribute$3(33, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(34, "Devices");
                            }, $uZPPEc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $tMXieb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(35, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(36, "<i class=\"mdi mdi-devices\"></i>");
                            }, $clnKhh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $oxxlcd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(37, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(38, "<h2 class=\"mgt-0\">Devices</h2>\r\n                    ");
                                __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.RemoteDataTable$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel), 39);
                                __builder4.AddComponentParameter(40, "Class", "bg-card-07 bdt bdb fill");
                                __builder4.AddComponentParameter(41, "paginator-class", "fill");
                                __builder4.AddComponentParameter(42, "paginator-menu-class", "pd bg-card");
                                __builder4.AddComponentParameter(43, "PaginatorButtonFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                __builder4.AddComponentParameter(44, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder4.AddComponentParameter(45, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8n | 65536n | 2097152n | 8388608n | 4n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                __builder4.AddComponentParameter(46, "th-class", "nowrap fw-bold bg-primary-01 sd-1 bdb");
                                __builder4.AddAttribute$3(47, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel))))().$ctor(this, ( (/*order*/ order) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel), 48);
                                        __builder5.AddAttribute$3(49, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel)))().$ctor(this, ( (/*_*/ _0) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                __builder6.AddContent$4(50, "Account");
                                            }, $pSNUFf ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                        }), $hZBbjf ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                        __builder5.AddAttribute$3(51, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel))))().$ctor(this, ( (/*item*/ item) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                __builder6.AddContent$4(52, item.Data.Account.Name);
                                            }, $znnZKb ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                        }), $vahaWd ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                        __builder5.CloseComponent();
                                        __builder5.AddMarkupContent(53, "\r\n                            ");
                                        __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumnsFromSchema$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel), 54);
                                        __builder5.AddComponentParameter(55, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures, 0/*DataTableColumnsFromSchemaFeatures.Default*/ | 1/*DataTableColumnsFromSchemaFeatures.Editable*/ | 2/*DataTableColumnsFromSchemaFeatures.ServerUpdate*/), $.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures));
                                        __builder5.AddComponentParameter(56, "cell-class", "nowrap");
                                        __builder5.CloseComponent();
                                    }, $UqqsCk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                }), $hcBKnd ??= {"r":6881395,"p":[{"n":"order","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                            }, $CfEBZd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $nsDHqa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(57, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 58);
                        __builder3.AddComponentParameter(59, "Name", "Groups");
                        __builder3.AddComponentParameter(60, "Class", "pd-10");
                        __builder3.AddAttribute$3(61, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(62, "Groups");
                            }, $cIUVZi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $qlGIDj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(63, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(64, "<i class=\"mdi mdi-group\"></i>");
                            }, $Kinfqi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $UlTDNc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(65, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(66, "<h2 class=\"mgt-0\">Groups</h2>\r\n                    ");
                                __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.RemoteDataTable$$($.$ZaYa.LCCTCM.CommunityTVGroupModel), 67);
                                __builder4.AddComponentParameter(68, "Class", "bg-card-07 bdt bdb fill");
                                __builder4.AddComponentParameter(69, "paginator-class", "fill");
                                __builder4.AddComponentParameter(70, "paginator-menu-class", "pd bg-card");
                                __builder4.AddComponentParameter(71, "PaginatorButtonFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                __builder4.AddComponentParameter(72, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder4.AddComponentParameter(73, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8n | 65536n | 2097152n | 8388608n | 4n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                __builder4.AddComponentParameter(74, "th-class", "nowrap fw-bold bg-primary-01 sd-1 bdb");
                                __builder4.AddAttribute$3(75, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVGroupModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVGroupModel))))().$ctor(this, ( (/*order*/ order) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumnsFromSchema$$($.$ZaYa.LCCTCM.CommunityTVGroupModel), 76);
                                        __builder5.AddComponentParameter(77, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures, 0/*DataTableColumnsFromSchemaFeatures.Default*/ | 1/*DataTableColumnsFromSchemaFeatures.Editable*/ | 2/*DataTableColumnsFromSchemaFeatures.ServerUpdate*/), $.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures));
                                        __builder5.AddComponentParameter(78, "cell-class", "nowrap");
                                        __builder5.CloseComponent();
                                    }, $mZuCFc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                }), $Fbkmfl ??= {"r":6881395,"p":[{"n":"order","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVGroupModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVGroupModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                            }, $fVIBVa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $OdPLSe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(79, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 80);
                        __builder3.AddComponentParameter(81, "Name", "Accounts");
                        __builder3.AddComponentParameter(82, "Class", "pd-10");
                        __builder3.AddAttribute$3(83, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(84, "Accounts");
                            }, $EFFmvg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $LMmFue ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(85, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(86, "<i class=\"mdi mdi-account\"></i>");
                            }, $tloLBa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $TgiPXk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(87, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(88, "<h2 class=\"mgt-0\">Accounts</h2>\r\n                    ");
                                __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.RemoteDataTable$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), 89);
                                __builder4.AddComponentParameter(90, "Class", "bg-card-07 bdt bdb fill");
                                __builder4.AddComponentParameter(91, "paginator-class", "fill");
                                __builder4.AddComponentParameter(92, "paginator-menu-class", "pd bg-card");
                                __builder4.AddComponentParameter(93, "PaginatorButtonFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                __builder4.AddComponentParameter(94, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder4.AddComponentParameter(95, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8n | 65536n | 2097152n | 8388608n | 4n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                __builder4.AddComponentParameter(96, "th-class", "nowrap fw-bold bg-primary-01 sd-1 bdb");
                                __builder4.AddAttribute$3(97, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVAccountModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVAccountModel))))().$ctor(this, ( (/*order*/ order) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), 98);
                                        __builder5.AddAttribute$3(99, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)))().$ctor(this, ( (/*_*/ _0) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                __builder6.AddContent$4(100, "Account");
                                            }, $ClhpEg ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                        }), $SYkMmj ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCM.CommunityTVAccountModel).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                        __builder5.AddAttribute$3(101, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVAccountModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVAccountModel))))().$ctor(this, ( (/*item*/ item) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                __builder6.AddContent$4(102, item.Data.Account.Name);
                                            }, $aZlksd ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                        }), $SICyKb ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVAccountModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                        __builder5.CloseComponent();
                                        __builder5.AddMarkupContent(103, "\r\n                            ");
                                        __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumnsFromSchema$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), 104);
                                        __builder5.AddComponentParameter(105, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures, 0/*DataTableColumnsFromSchemaFeatures.Default*/ | 1/*DataTableColumnsFromSchemaFeatures.Editable*/ | 2/*DataTableColumnsFromSchemaFeatures.ServerUpdate*/), $.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures));
                                        __builder5.AddComponentParameter(106, "cell-class", "nowrap");
                                        __builder5.CloseComponent();
                                        __builder5.AddMarkupContent(107, "\r\n                            ");
                                        __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), 108);
                                        __builder5.AddComponentParameter(109, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 2147483647/*int.MaxValue*/), $.$$.S.Int32));
                                        __builder5.AddAttribute$3(110, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)))().$ctor(this, ( (/*_*/ _0) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                __builder6.AddContent$4(111, "User Name / Password");
                                            }, $vwltqc ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                        }), $PEfuxf ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCM.CommunityTVAccountModel).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                        __builder5.AddAttribute$3(112, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVAccountModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVAccountModel))))().$ctor(this, ( (/*item*/ item) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                                                if ((__ca1__ = item.Data.ActiveCodes) !== null ? $.$sl.SL.Enumerable.Any($.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                                                {
                                                    return !$.$$.S.String.IsNullOrEmpty(e);
                                                }, $oWPqrf ??= {"r":262145,"p":[{"n":"e","p":1310721}],"n":"","d":478017,"h":0,"f":17825794})) : false)
                                                {
                                                }
                                            }, $ajwuBk ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                        }), $AqlOrk ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVAccountModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                        __builder5.CloseComponent();
                                    }, $WZjwWf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                }), $neFnWa ??= {"r":6881395,"p":[{"n":"order","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVAccountModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                            }, $qLThRd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $DFuTHg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(113, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 114);
                        __builder3.AddComponentParameter(115, "Name", "ActiveCodes");
                        __builder3.AddComponentParameter(116, "Class", "pd-10");
                        __builder3.AddAttribute$3(117, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(118, "Active Codes");
                            }, $srCQde ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $GBtUwf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(119, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(120, "<i class=\"mdi mdi mdi-counter\"></i>");
                            }, $JAfmUd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $MhkqRb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(121, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(122, "<h2 class=\"mgt-0\">Active Codes</h2>\r\n                    ");
                                __builder4.OpenElement(123, "div");
                                __builder4.AddAttribute$5(124, "class", "grid colm-3 gap-2");
                                let $en11 = this.Service.Payment.ServiceTiers.Invoke(new $.$fPer.LCFCD.DataFilter().$ctor$1()).AsTask().GetAwaiter$1().GetResult().Data.SCG$IEnumerable$$$GetEnumerator();
                                while ($en11.SC$1$IEnumerator$MoveNext())
                                {
                                    let _grid = $en11.SCG$IEnumerator$$$Current;
                                    {
                                        /*var*/ let grid = $.$cast(_grid, $.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel);
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.RemoteDataTable$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel), 125);
                                        __builder4.AddComponentParameter(126, "ItemName", "Active Codes");
                                        __builder4.AddComponentParameter(127, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 34359738368n | 8n | 65536n | 256n | 8796093022208n | 8388608n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                        __builder4.AddComponentParameter(128, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741853/*PostFilterTypes.Search*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                                        {
                                            //new $.$LCOv.LCFCPM$1.PostSearchModel()
                                            const $t12 = $.$LCOv.LCFCPM$1.PostSearchModel;
                                            const $i12 = new $t12();
                                            $i12.$ctor$1();
                                            $i12.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                                            {
                                                //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                                                const $t13 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                                                const $i13 = new $t13();
                                                $i13.$ctor$3();
                                                $i13.FilterType = 65536/*PostPropertyQueryFilterType.PropertyValueMatch*/;
                                                $i13.Type = "Validity";
                                                $i13.NValue = grid.Months;
                                                return $i13;
                                            })()], [-1], null);
                                            return $i12;
                                        })(), 0)));
                                        __builder4.AddAttribute$3(129, "CustomToolBar", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel))))().$ctor(this, ( (/*toolbar*/ toolbar) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                            {
                                                __builder5.OpenElement(130, "h3");
                                                __builder5.AddAttribute$5(131, "class", "mg");
                                                if (grid.Months < 0)
                                                {
                                                    __builder5.AddContent$4(132, "Test");
                                                }
                                                else 
                                                {
                                                    __builder5.AddContent$3(133, $.$box(grid.Months, $.$$.S.Int32));
                                                    __builder5.AddContent$4(134, " months");
                                                }
                                                __builder5.CloseElement();
                                            }, $veuNZd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                        }), $rkvEtk ??= {"r":6881395,"p":[{"n":"toolbar","p":$.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                        __builder4.AddAttribute$3(135, "Wrapper", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel))))().$ctor(this, ( (/*wrap*/ wrap) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                            {
                                                __builder5.OpenElement(136, "div");
                                                __builder5.AddAttribute$5(137, "class", "bg-card bd stack");
                                                __builder5.AddContent$1(138, wrap.View);
                                                __builder5.AddMarkupContent(139, "\r\n                                        ");
                                                __builder5.OpenElement(140, "div");
                                                __builder5.AddAttribute$5(141, "class", "bg-tertiary pd text-right mgt");
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel), 142);
                                                __builder5.AddComponentParameter(143, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel, grid));
                                                __builder5.AddComponentParameter(144, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 256/*ButtonFeatures.Small*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                                __builder5.AddComponentParameter(145, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel, this, new ($.$$.S.Func$$$($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel, $.$$.STT.Task))().$ctor(this, this.AddActiveCode))));
                                                __builder5.AddComponentParameter(146, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                __builder5.AddAttribute$3(147, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddMarkupContent(148, "\r\n                                                Add Code\r\n                                            ");
                                                }), $oMADvh ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":478017,"h":0,"f":17825794}));
                                                __builder5.CloseComponent();
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                            }, $UaSIuj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                        }), $HCBfzh ??= {"r":6881395,"p":[{"n":"wrap","p":$.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                        __builder4.AddAttribute$3(149, "CustomRenderer", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListRenderContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel))))().$ctor(this, ( (/*render*/ render) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                            {
                                                if (render.Data !== null)
                                                {
                                                    __builder5.OpenElement(150, "div");
                                                    __builder5.AddAttribute$5(151, "class", "bg-primary pd");
                                                    __builder5.OpenElement(152, "div");
                                                    __builder5.AddAttribute$5(153, "class", "row fw-bold");
                                                    __builder5.OpenElement(154, "div");
                                                    __builder5.AddAttribute$5(155, "class", "col-5");
                                                    __builder5.AddMarkupContent(156, "\r\n                                                    Total: ");
                                                    __builder5.AddContent$3(157, $.$box(render.DataList.TotalItems, $.$$.S.Int32));
                                                    __builder5.CloseElement();
                                                    __builder5.AddMarkupContent(158, "\r\n                                                ");
                                                    __builder5.OpenElement(159, "div");
                                                    __builder5.AddAttribute$5(160, "class", "col-5");
                                                    __builder5.AddMarkupContent(161, "\r\n                                                    Used: ");
                                                    __builder5.AddContent$3(162, $.$box($.$sl.SL.Enumerable.Count($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)), render.Data, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)), $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                                                    {
                                                        return a.Model.Status !== 0/*CommunityTVActiveCodeStatus.Unassigned*/;
                                                    }, $ntRBHk ??= {"r":262145,"p":[{"n":"a","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)).$h}],"n":"","d":478017,"h":0,"f":17825794})), $.$$.S.Int32));
                                                    __builder5.CloseElement();
                                                    __builder5.AddMarkupContent(163, "\r\n                                                ");
                                                    __builder5.OpenElement(164, "div");
                                                    __builder5.AddAttribute$5(165, "class", "col-5");
                                                    __builder5.AddMarkupContent(166, "\r\n                                                    Unused: ");
                                                    __builder5.AddContent$3(167, $.$box($.$sl.SL.Enumerable.Count($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)), render.Data, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)), $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                                                    {
                                                        return a.Model.Status === 0/*CommunityTVActiveCodeStatus.Unassigned*/;
                                                    }, $CjuOll ??= {"r":262145,"p":[{"n":"a","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)).$h}],"n":"","d":478017,"h":0,"f":17825794})), $.$$.S.Int32));
                                                    __builder5.CloseElement();
                                                    __builder5.CloseElement();
                                                    __builder5.CloseElement();
                                                    __builder5.AddMarkupContent(168, "\r\n                                        ");
                                                    __builder5.OpenElement(169, "div");
                                                    __builder5.AddAttribute$5(170, "class", "hx-3 scroll");
                                                    __builder5.AddContent$1(171, render.DefaultRenderer.Invoke(render.DataList, render.Data, null));
                                                    __builder5.CloseElement();
                                                }
                                            }, $ZZGIYk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                        }), $WIIdDf ??= {"r":6881395,"p":[{"n":"render","p":$.$hDPm.LCFCCD$1.DataListRenderContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                        __builder4.AddAttribute$3(172, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 173);
                                            __builder5.AddComponentParameter(174, "Class", "mg");
                                            __builder5.AddComponentParameter(175, "Message", "No active code here");
                                            __builder5.CloseComponent();
                                        }), $vIJbhd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794}));
                                        __builder4.AddAttribute$3(176, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel))))().$ctor(this, ( (/*_dat*/ _dat) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                            {
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel), 177);
                                                __builder5.AddAttribute$3(178, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel))))().$ctor(this, ( (/*data*/ data) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                    {
                                                        __builder6.AddContent$3(179, $.$box(((data.Index + 1) | 0), $.$$.S.Int32));
                                                    }, $KXgVHa ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                                }), $TJprCb ??= {"r":6881395,"p":[{"n":"data","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                                __builder5.CloseComponent();
                                                __builder5.AddMarkupContent(180, "\r\n                                    ");
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel), 181);
                                                __builder5.AddAttribute$3(182, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel))))().$ctor(this, ( (/*data*/ data) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                    {
                                                        __builder6.AddContent$4(183, data.Data.Title);
                                                    }, $ynFtCd ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                                }), $hnaxph ??= {"r":6881395,"p":[{"n":"data","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                                __builder5.CloseComponent();
                                                __builder5.AddMarkupContent(184, "\r\n                                    ");
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel), 185);
                                                __builder5.AddAttribute$3(186, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel))))().$ctor(this, ( (/*data*/ data) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                    {
                                                        __builder6.OpenElement(187, "small");
                                                        __builder6.AddAttribute$5(188, "class", $.$strNN($.$strNN($.$strNN("corner-5" + " pdx-2") + " pdy-1") + " bg-") + $.$strNN((data.Data.Status === 0/*CommunityTVActiveCodeStatus.Unassigned*/ ? "success" : data.Data.Status === 1/*CommunityTVActiveCodeStatus.Assigned*/ ? "primary" : data.Data.Status === 2/*CommunityTVActiveCodeStatus.Using*/ ? "warning" : "error")));
                                                        __builder6.AddContent$4(189, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$ZaYa.LCCTCM.CommunityTVActiveCodeStatus, $.$$.S.UInt32, data.Data.Status)));
                                                        __builder6.CloseElement();
                                                    }, $sNXbTc ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                                }), $eJsLuk ??= {"r":6881395,"p":[{"n":"data","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                                __builder5.CloseComponent();
                                                __builder5.AddMarkupContent(190, "\r\n                                    ");
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel), 191);
                                                __builder5.AddAttribute$3(192, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel))))().$ctor(this, ( (/*data*/ data) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                    {
                                                        if (data.Data.Status >= 2/*CommunityTVActiveCodeStatus.Using*/)
                                                        {
                                                        }
                                                    }, $KgOloj ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                                }), $yZHSzh ??= {"r":6881395,"p":[{"n":"data","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                                __builder5.CloseComponent();
                                            }, $EInGUj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                        }), $trSaja ??= {"r":6881395,"p":[{"n":"_dat","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                        __builder4.SetKey(grid);
                                        __builder4.AddComponentReferenceCapture(193, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                                        {
                                            this.activeCodeLists.set_Item(grid, $.$cast(__value, $.$hDPm.LCFCCD$2.RemoteDataTable$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)));
                                        }, $pMykwf ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":478017,"h":0,"f":17825794}));
                                        __builder4.CloseComponent();
                                    }
                                }
                                __builder4.CloseElement();
                            }, $YXdcZc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $BIMEbj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(194, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 195);
                        __builder3.AddComponentParameter(196, "Name", "Categories");
                        __builder3.AddComponentParameter(197, "Class", "pd-10");
                        __builder3.AddAttribute$3(198, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(199, "Categories");
                            }, $rTzHXg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $qVXAkd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(200, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(201, "<i class=\"mdi mdi mdi-group\"></i>");
                            }, $Jznyik ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $cJdpbi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(202, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                            }, $wyzBae ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $Fvfdzk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(203, "ChildPages", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                        {
                            let $en14 = this.Service.TVPlayerService.StreamProviders.GetEnumerator();
                            while ($en14.MoveNext())
                            {
                                let provider = $en14.Current;
                                {
                                    __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 204);
                                    __builder4.AddComponentParameter(205, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN(provider.LCFC$INamed$Name)}Categories`));
                                    __builder4.AddComponentParameter(206, "Class", "pd-10");
                                    __builder4.AddAttribute$3(207, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(208, provider.LCFC$IDisplayable$Title);
                                        }, $ncFVsf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $QntyIf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(209, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.OpenElement(210, "i");
                                            __builder5.AddAttribute$4(211, "class", provider.LCFC$IDisplayable$Icon);
                                            __builder5.CloseElement();
                                        }, $bvnnzf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $vKrWyc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(212, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.OpenElement(213, "h2");
                                            __builder5.AddAttribute$5(214, "class", "mgt-0");
                                            __builder5.AddContent$4(215, provider.LCFC$IDisplayable$Title);
                                            __builder5.CloseElement();
                                            __builder5.AddMarkupContent(216, "\r\n                                    ");
                                            __builder5.AddContent$1(217, this.StreamCategoryList(provider.LCCTCS$IStreamProvider$GetCategories(this.Service.TVPlayerService)));
                                        }, $mCbKKc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $tcSPGg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }
                            }
                        }), $YWQndh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(218, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 219);
                        __builder3.AddComponentParameter(220, "Name", "Streams");
                        __builder3.AddComponentParameter(221, "Class", "pd-10");
                        __builder3.AddAttribute$3(222, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(223, "Streams");
                            }, $gIbtEe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $JRdGsi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(224, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(225, "<i class=\"mdi mdi mdi mdi-youtube-tv\"></i>");
                            }, $SJBwub ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $jYSupe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(226, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                            }, $BmVixi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $AShgJd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(227, "ChildPages", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                        {
                            let $en15 = this.Service.TVPlayerService.StreamProviders.GetEnumerator();
                            while ($en15.MoveNext())
                            {
                                let provider = $en15.Current;
                                {
                                    __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 228);
                                    __builder4.AddComponentParameter(229, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, provider.LCFC$INamed$Name));
                                    __builder4.AddComponentParameter(230, "Class", "pd-10");
                                    __builder4.AddAttribute$3(231, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(232, provider.LCFC$IDisplayable$Title);
                                        }, $vMQHNj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $lURLLa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(233, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.OpenElement(234, "i");
                                            __builder5.AddAttribute$4(235, "class", provider.LCFC$IDisplayable$Icon);
                                            __builder5.CloseElement();
                                        }, $tfxgMf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $XrZkak ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(236, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.OpenElement(237, "h2");
                                            __builder5.AddAttribute$5(238, "class", "mgt-0");
                                            __builder5.AddContent$4(239, provider.LCFC$IDisplayable$Title);
                                            __builder5.CloseElement();
                                            __builder5.AddMarkupContent(240, "\r\n                                ");
                                            __builder5.AddContent(241, this.StreamList(TStream, provider));
                                        }, $VKtIZj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $CRDxVg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }
                            }
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 242);
                            __builder4.AddComponentParameter(243, "Name", "FreeTVs");
                            __builder4.AddComponentParameter(244, "Class", "pd stack");
                            __builder4.AddAttribute$3(245, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(246, "Free TVs");
                                }, $yxEEuk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                            }), $DIhbPi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(247, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenElement(248, "i");
                                    __builder5.AddAttribute$5(249, "class", "mdi mdi-youtube-tv"/*TVPlayerServices.FreeLiveTVsIcon*/);
                                    __builder5.CloseElement();
                                }, $qloWOe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                            }), $EFJDfk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(250, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$OUNt.LCCTAS$1.TVEditor$$($.$rAPp.LCCTFL.FreeLiveTVStream), 251);
                                    __builder5.AddComponentParameter(252, "Provider", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ZaYa.LCCTCS.ITVEditorProvider$$($.$rAPp.LCCTFL.FreeLiveTVStream), this.freeLiveTVProvider));
                                    __builder5.CloseComponent();
                                }, $wNXtIg ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                            }), $GoFtsk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(253, "\r\n                    ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 254);
                            __builder4.AddComponentParameter(255, "Name", "FreeMovies");
                            __builder4.AddComponentParameter(256, "Class", "pd stack");
                            __builder4.AddAttribute$3(257, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(258, "Free Movies");
                                }, $eqGape ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                            }), $nCUgMg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(259, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenElement(260, "i");
                                    __builder5.AddAttribute$5(261, "class", "mdi mdi-video-box"/*TVPlayerServices.FreeMoviesIcon*/);
                                    __builder5.CloseElement();
                                }, $xDkXxk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                            }), $HyDBfl ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(262, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$OUNt.LCCTAS$1.TVEditor$$($.$rAPp.LCCTFM.FreeMovieStream), 263);
                                    __builder5.AddComponentParameter(264, "Provider", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ZaYa.LCCTCS.ITVEditorProvider$$($.$rAPp.LCCTFM.FreeMovieStream), this.freeMoviesProvider));
                                    __builder5.CloseComponent();
                                }, $VhbLcd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                            }), $eeygal ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                        }), $NBGkrf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(265, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 266);
                        __builder3.AddComponentParameter(267, "Name", "Banners");
                        __builder3.AddComponentParameter(268, "Class", "pd");
                        __builder3.AddAttribute$3(269, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(270, "App Banners");
                            }, $dweISd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $hsdKNk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(271, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(272, "<i class=\"mdi mdi-account-details\"></i>");
                            }, $YURLPb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $TgmNNa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(273, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$Bnua.LCCCAS.CommunityAdminBanners, 274);
                                __builder4.AddComponentParameter(275, "Tag", "TV");
                                __builder4.CloseComponent();
                            }, $LtzsRb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $ChKGDk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(276, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 277);
                        __builder3.AddComponentParameter(278, "Name", "Subscribers");
                        __builder3.AddComponentParameter(279, "Class", "pd");
                        __builder3.AddAttribute$3(280, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(281, "Subscribers");
                            }, $qlqWSe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $XDwUSb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(282, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(283, "<i class=\"mdi mdi-message\"></i>");
                            }, $APVSIh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $lzsKui ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(284, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(285, "<h2 class=\"mgt-0\">Subscriptions</h2>\r\n                    ");
                                __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.RemoteDataTable$$($.$Iaui.LCFCM.EmailSubscriptionModel), 286);
                                __builder4.AddComponentParameter(287, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$22("TV", null, new $.$fPer.LCFCD.CompositeDataId(), null, null, null, null, null, new $.$fPer.LCFCD.Sorting(), null)));
                                __builder4.AddComponentParameter(288, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8n | 65536n | 8n | 8388608n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                __builder4.AddAttribute$3(289, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.EmailSubscriptionModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$Iaui.LCFCM.EmailSubscriptionModel))))().$ctor(this, ( (/*_*/ _0) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumnsFromSchema$$($.$Iaui.LCFCM.EmailSubscriptionModel), 290);
                                        __builder5.AddComponentParameter(291, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures, 0/*DataTableColumnsFromSchemaFeatures.Default*/ | 1/*DataTableColumnsFromSchemaFeatures.Editable*/ | 2/*DataTableColumnsFromSchemaFeatures.ServerUpdate*/), $.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures));
                                        __builder5.CloseComponent();
                                    }, $gHbYKi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                }), $VzReuk ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.EmailSubscriptionModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$Iaui.LCFCM.EmailSubscriptionModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                            }, $fhCvKg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $AXfBvd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(292, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 293);
                        __builder3.AddComponentParameter(294, "Name", "Settings");
                        __builder3.AddComponentParameter(295, "Class", "pd");
                        __builder3.AddAttribute$3(296, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(297, "Settings");
                            }, $wTSxpe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $kSMbVj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(298, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(299, "<i class=\"mdi mdi-cogs\"></i>");
                            }, $QkKFbf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $hKRCme ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(300, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(301, "<h2 class=\"mgt-0\">Settings</h2>\r\n                    ");
                                __builder4.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 302);
                                __builder4.AddComponentParameter(303, "Class", "mawx-5 mgx-a");
                                __builder4.AddAttribute$3(304, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$ZaYa.LCCTCS$1.CommunityTVGlobalSettings), 305);
                                    __builder5.AddComponentParameter(306, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ZaYa.LCCTCS$1.CommunityTVGlobalSettings, this.Service.TVPlayerService.AdminSettings));
                                    __builder5.AddComponentParameter(307, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$ZaYa.LCCTCS$1.CommunityTVGlobalSettings), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$ZaYa.LCCTCS$1.CommunityTVGlobalSettings, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$ZaYa.LCCTCS$1.CommunityTVGlobalSettings, $.$$.STT.ValueTask))().$ctor(this, this.SaveGlobalSettings))));
                                    __builder5.AddAttribute$3(308, "Submit", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                    {
                                        __builder6.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 309);
                                        __builder6.AddComponentParameter(310, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                        __builder6.AddComponentParameter(311, "Class", "mgt");
                                        __builder6.AddComponentParameter(312, "type", "submit");
                                        __builder6.AddAttribute$3(313, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder7*/ __builder7) =>
                                        {
                                            __builder7.AddContent$4(314, "SAVE");
                                        }), $VNbbXe ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":478017,"h":0,"f":17825794}));
                                        __builder6.CloseComponent();
                                    }), $VFsxtc ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                }), $WccTJa ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                            }, $zjyLdl ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                        }), $ryDlJe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                    }), $RQcPhc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":478017,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $SbDArh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":478017,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(42950150977)
            
            //--TRIMMABLE-BOUNDARY-START(115964595009)
            /*RenderFragment */ GetView(/*ContainerContext<IEnumerable<ResourceModel>>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964595009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(315, "div");
                    __builder2.AddAttribute$5(316, "class", "wx-3");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$Iaui.LCFCM.ResourceModel), 317);
                    __builder2.AddComponentParameter(318, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), value.Data));
                    __builder2.AddComponentParameter(319, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 33554432n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddComponentParameter(320, "li-class", "hx-1 wx-2 mg-1 shadow bg-card corner");
                    __builder2.AddAttribute$3(321, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.ResourceModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.ResourceModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 322);
                            __builder3.AddComponentParameter(323, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 3/*MediaFeatures.Responsive*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                            __builder3.AddComponentParameter(324, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, context.Data));
                            __builder3.AddComponentParameter(325, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                            __builder3.CloseComponent();
                        }, $iehvzi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                    }), $PXgbRk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.ResourceModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.ResourceModel)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                }, $wkEccf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(115964595009)
            
            //--TRIMMABLE-BOUNDARY-START(219043810113)
            /*RenderFragment */ StreamList(TStream, /*IStreamProvider<TStream>*/ pager)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043810113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$macw.MACF.EditForm, 326);
                    __builder2.AddComponentParameter(327, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                    __builder2.AddComponentParameter(328, "class", "bg-card");
                    __builder2.AddAttribute$3(329, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*___*/ ___) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTable$$(TStream), 330);
                            __builder3.AddComponentParameter(331, "Pager", (pager.LCCTCS$IStreamProvider$$$GetStreams(this.Service.TVPlayerService, null)));
                            __builder3.AddComponentParameter(332, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n | 8n | 8388608n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddAttribute$3(333, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(TStream, $.$hDPm.LCFCCD$2.DataTableColumn$$(TStream))))().$ctor(this, ( (/*_*/ _0) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$(TStream), 334);
                                    __builder4.AddAttribute$3(335, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$(TStream)))().$ctor(this, ( (/*__*/ __) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                        }, $LGBidk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $dlpLda ??= {"r":6881395,"p":[{"n":"__","p":(TStream) => $.$$.SCG.IEnumerable$$(TStream).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(336, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(TStream, $.$hDPm.LCFCCD$2.DataTableColumn$$(TStream))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.OpenElement(337, "div");
                                            __builder5.AddAttribute$5(338, "class", "hx-1");
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 339);
                                            __builder5.AddComponentParameter(340, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ & ~3/*MediaFeatures.Responsive*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                            __builder5.AddComponentParameter(341, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Service.TVPlayerService.MapUrl(item.Data.LCCTCS$IStream$PosterPhoto, this.Navigation.Uri)));
                                            __builder5.CloseComponent();
                                            __builder5.CloseElement();
                                        }, $VtlHxd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $fhDBIi ??= {"r":6881395,"p":[{"n":"item","p":(TStream) => $.$hDPm.LCFCCD$1.DataListItemContext$$$(TStream, $.$hDPm.LCFCCD$2.DataTableColumn$$(TStream)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(342, "\r\n            ");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$(TStream), 343);
                                    __builder4.AddAttribute$3(344, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$(TStream)))().$ctor(this, ( (/*__*/ __) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(345, "Stream Id");
                                        }, $lCjsxh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $xYdNvh ??= {"r":6881395,"p":[{"n":"__","p":(TStream) => $.$$.SCG.IEnumerable$$(TStream).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(346, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(TStream, $.$hDPm.LCFCCD$2.DataTableColumn$$(TStream))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$3(347, $.$box(item.Data.LCCTCS$IStream$StreamId, $.$$.S.Int64));
                                        }, $jYavSk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $wHNBgb ??= {"r":6881395,"p":[{"n":"item","p":(TStream) => $.$hDPm.LCFCCD$1.DataListItemContext$$$(TStream, $.$hDPm.LCFCCD$2.DataTableColumn$$(TStream)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(348, "\r\n            ");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$(TStream), 349);
                                    __builder4.AddAttribute$3(350, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$(TStream)))().$ctor(this, ( (/*__*/ __) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(351, "Title");
                                        }, $UdpOJi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $uHHbVc ??= {"r":6881395,"p":[{"n":"__","p":(TStream) => $.$$.SCG.IEnumerable$$(TStream).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(352, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(TStream, $.$hDPm.LCFCCD$2.DataTableColumn$$(TStream))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(353, item.Data.LCFC$IDisplayable$Title);
                                        }, $daIifd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $uhpsAj ??= {"r":6881395,"p":[{"n":"item","p":(TStream) => $.$hDPm.LCFCCD$1.DataListItemContext$$$(TStream, $.$hDPm.LCFCCD$2.DataTableColumn$$(TStream)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(354, "\r\n            ");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$(TStream), 355);
                                    __builder4.AddAttribute$3(356, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$(TStream)))().$ctor(this, ( (/*__*/ __) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(357, "Recommended");
                                        }, $ZRJbfe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $mlNIUc ??= {"r":6881395,"p":[{"n":"__","p":(TStream) => $.$$.SCG.IEnumerable$$(TStream).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(358, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(TStream, $.$hDPm.LCFCCD$2.DataTableColumn$$(TStream))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            /*var*/ let binder = new ($.$hDPm.LCFCU.DelegateValueBinder$$($.$$.S.Boolean))().$ctor$8(this.Service.TVPlayerService.IsRecommended($.$box(item.Data, TStream)), new ($.$$.S.Func$$$($.$$.S.Boolean, $.$$.STT.Task))().$ctor(this,  (/*v*/ v) =>
                                            {
                                                return this.Service.TVPlayerService.SetRecommended($.$box(item.Data, TStream), v);
                                            }, $hgxwbh ??= {"r":178454529,"p":[{"n":"v","p":262145}],"n":"","d":478017,"h":0,"f":17825794}));
                                            $.$Cdtc._LCCTCAPA.TypeInference.CreateInputEditor_1($.$$.S.Boolean, __builder5, 359, 360, binder.Value ? $.$fPer.LCFC.Theme.Primary : $.$fPer.LCFC.Theme.Secondary, 361, binder.Value, 362, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Boolean, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Boolean, this, new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this,  (/*__value*/ __value) =>
                                            {
                                                return binder.Value = __value;
                                            }, $DNqACd ??= {"r":65537,"p":[{"n":"__value","p":262145}],"n":"","d":478017,"h":0,"f":17825794}), binder.Value)), 363, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                            {
                                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(binder), "Value"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                            }, $LbVoQi ??= {"r":38797349,"n":"","d":478017,"h":0,"f":17825794})).Invoke()));
                                        }, $UCdiCk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $DCubGc ??= {"r":6881395,"p":[{"n":"item","p":(TStream) => $.$hDPm.LCFCCD$1.DataListItemContext$$$(TStream, $.$hDPm.LCFCCD$2.DataTableColumn$$(TStream)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(364, "\r\n            ");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$(TStream), 365);
                                    __builder4.AddAttribute$3(366, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$(TStream)))().$ctor(this, ( (/*__*/ __) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(367, "Exclusion");
                                        }, $NurlIh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $HLwVRe ??= {"r":6881395,"p":[{"n":"__","p":(TStream) => $.$$.SCG.IEnumerable$$(TStream).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(368, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(TStream, $.$hDPm.LCFCCD$2.DataTableColumn$$(TStream))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            /*var*/ let binder = new ($.$hDPm.LCFCU.DelegateValueBinder$$($.$$.S.Boolean))().$ctor$8(this.Service.TVPlayerService.IsStreamExcluded(TStream, item.Data), new ($.$$.S.Func$$$($.$$.S.Boolean, $.$$.STT.Task))().$ctor(this,  (/*v*/ v) =>
                                            {
                                                return this.Service.TVPlayerService.SetStreamExcluded($.$box(item.Data, TStream), v);
                                            }, $ZVooid ??= {"r":178454529,"p":[{"n":"v","p":262145}],"n":"","d":478017,"h":0,"f":17825794}));
                                            $.$Cdtc._LCCTCAPA.TypeInference.CreateInputEditor_2($.$$.S.Boolean, __builder5, 369, 370, $.$fPer.LCFC.Theme.Error, 371, binder.Value, 372, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Boolean, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Boolean, this, new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this,  (/*__value*/ __value) =>
                                            {
                                                return binder.Value = __value;
                                            }, $wVOREb ??= {"r":65537,"p":[{"n":"__value","p":262145}],"n":"","d":478017,"h":0,"f":17825794}), binder.Value)), 373, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                            {
                                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(binder), "Value"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                            }, $resTqf ??= {"r":38797349,"n":"","d":478017,"h":0,"f":17825794})).Invoke()));
                                        }, $XsncEg ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $agMUoj ??= {"r":6881395,"p":[{"n":"item","p":(TStream) => $.$hDPm.LCFCCD$1.DataListItemContext$$$(TStream, $.$hDPm.LCFCCD$2.DataTableColumn$$(TStream)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $ZGzNVa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                            }), $pknLXi ??= {"r":6881395,"p":[{"n":"_","p":(TStream) => $.$hDPm.LCFCCD$1.DataListItemContext$$$(TStream, $.$hDPm.LCFCCD$2.DataTableColumn$$(TStream)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $XACURi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                    }), $HHBPgj ??= {"r":6881395,"p":[{"n":"___","p":131188}],"n":"","d":478017,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $ABEKff ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(219043810113)
            
            //--TRIMMABLE-BOUNDARY-START(214748842817)
            /*RenderFragment */ StreamCategoryList(/*Pager<IStreamCategory>*/ pager)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748842817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$macw.MACF.EditForm, 374);
                    __builder2.AddComponentParameter(375, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                    __builder2.AddComponentParameter(376, "class", "bg-card");
                    __builder2.AddAttribute$3(377, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*___*/ ___) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTable$$($.$ZaYa.LCCTCS.IStreamCategory), 378);
                            __builder3.AddComponentParameter(379, "Pager", (pager));
                            __builder3.AddComponentParameter(380, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n | 8n | 8388608n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddAttribute$3(381, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCS.IStreamCategory, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCS.IStreamCategory))))().$ctor(this, ( (/*_*/ _0) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCS.StreamCategory), 382);
                                    __builder4.AddAttribute$3(383, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS.StreamCategory)))().$ctor(this, ( (/*__*/ __) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(384, "Stream Id");
                                        }, $BqMhbe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $hCSoKb ??= {"r":6881395,"p":[{"n":"__","p":$.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS.StreamCategory).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(385, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCS.StreamCategory, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCS.StreamCategory))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(386, item.Data.CategoryId);
                                        }, $zacZpk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $bKMiTi ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCS.StreamCategory, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCS.StreamCategory)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(387, "\r\n            ");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCS.StreamCategory), 388);
                                    __builder4.AddAttribute$3(389, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS.StreamCategory)))().$ctor(this, ( (/*__*/ __) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(390, "Title");
                                        }, $jpUTKd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $nbCPqg ??= {"r":6881395,"p":[{"n":"__","p":$.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS.StreamCategory).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(391, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCS.StreamCategory, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCS.StreamCategory))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(392, item.Data.Title);
                                        }, $vTMGbi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $Qfjcgj ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCS.StreamCategory, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCS.StreamCategory)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(393, "\r\n            ");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCS.StreamCategory), 394);
                                    __builder4.AddAttribute$3(395, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS.StreamCategory)))().$ctor(this, ( (/*__*/ __) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(396, "Exclusion");
                                        }, $YhdUrg ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $CnYsoe ??= {"r":6881395,"p":[{"n":"__","p":$.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS.StreamCategory).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(397, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCS.StreamCategory, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCS.StreamCategory))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            /*var*/ let binder = new ($.$hDPm.LCFCU.DelegateValueBinder$$($.$$.S.Boolean))().$ctor$8(this.Service.TVPlayerService.IsCategoryExcluded(item.Data), new ($.$$.S.Func$$$($.$$.S.Boolean, $.$$.STT.Task))().$ctor(this,  (/*v*/ v) =>
                                            {
                                                return this.Service.TVPlayerService.SetCategoryExcluded(item.Data, v);
                                            }, $fAonDc ??= {"r":178454529,"p":[{"n":"v","p":262145}],"n":"","d":478017,"h":0,"f":17825794}));
                                            $.$Cdtc._LCCTCAPA.TypeInference.CreateInputEditor_3($.$$.S.Boolean, __builder5, 398, 399, binder.Value ? $.$fPer.LCFC.Theme.Error : $.$fPer.LCFC.Theme.Primary, 400, binder.Value, 401, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Boolean, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Boolean, this, new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this,  (/*__value*/ __value) =>
                                            {
                                                return binder.Value = __value;
                                            }, $sQeuvb ??= {"r":65537,"p":[{"n":"__value","p":262145}],"n":"","d":478017,"h":0,"f":17825794}), binder.Value)), 402, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                            {
                                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(binder), "Value"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                            }, $PXSGVb ??= {"r":38797349,"n":"","d":478017,"h":0,"f":17825794})).Invoke()));
                                        }, $yQMBQb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                                    }), $qfpZff ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCS.StreamCategory, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCS.StreamCategory)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $yxRtHa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                            }), $xWRtLc ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCS.IStreamCategory, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$ZaYa.LCCTCS.IStreamCategory)).$h}],"n":"","d":478017,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $Qlbkbi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
                    }), $gVInVb ??= {"r":6881395,"p":[{"n":"___","p":131188}],"n":"","d":478017,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $XBQdWk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":478017,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(214748842817)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4360984234)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IViewProvider<System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>>.GetView(LivingThing.Core.Frameworks.Client.Interface.ContainerContext<System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>>)
            [`LCFCI$IViewProvider$System$Collections$Generic$IEnumerable$LivingThing$Core$Frameworks$Common$Models$ResourceModel$$GetView`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4360984234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4360984234)
            
            //--TRIMMABLE-BOUNDARY-START(30065249089)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065249089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065249089)
            
            //--TRIMMABLE-BOUNDARY-START(30065249089)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(30065249089)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(154619300673)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(154619300673)
                
                //--TRIMMABLE-BOUNDARY-START(146029366081)
                this.Rendering = null;
                //--TRIMMABLE-BOUNDARY-END(146029366081)
                
                //--TRIMMABLE-BOUNDARY-START(158914267969)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(158914267969)
                
                //--TRIMMABLE-BOUNDARY-START(227633744705)
                this.UI = null;
                //--TRIMMABLE-BOUNDARY-END(227633744705)
                
                //--TRIMMABLE-BOUNDARY-START(124554529601)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(124554529601)
                
                //--TRIMMABLE-BOUNDARY-START(47245118273)
                this.freeLiveTVProvider = null;
                //--TRIMMABLE-BOUNDARY-END(47245118273)
                
                //--TRIMMABLE-BOUNDARY-START(51540085569)
                this.freeMoviesProvider = null;
                //--TRIMMABLE-BOUNDARY-END(51540085569)
                
                //--TRIMMABLE-BOUNDARY-START(34360216385)
                this.activeCodeLists = new ($.$$.SCG.Dictionary$$$($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel, $.$hDPm.LCFCCD$2.RemoteDataTable$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(34360216385)
                
            }
            static $h = 478017;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439431489),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719954753,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 478017,
      "h": 137439431489,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439431489),
//--TRIMMABLE-BOUNDARY-START(141734398785),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309889345,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094137153,
        "f": 83886081
      },
      "n": "Page",
      "d": 478017,
      "h": 141734398785,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141734398785),
//--TRIMMABLE-BOUNDARY-START(154619300673),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489758529,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193274006337,
        "f": 83886081
      },
      "n": "Server",
      "d": 478017,
      "h": 154619300673,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619300673),
//--TRIMMABLE-BOUNDARY-START(146029366081),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899823937,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184684071745,
        "f": 83886081
      },
      "n": "Rendering",
      "d": 478017,
      "h": 146029366081,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029366081),
//--TRIMMABLE-BOUNDARY-START(158914267969),
    {
      "p": 691684,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079693121,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201863940929,
        "f": 83886081
      },
      "n": "Service",
      "d": 478017,
      "h": 158914267969,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914267969),
//--TRIMMABLE-BOUNDARY-START(227633744705),
    {
      "p": 65492650,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669627713,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210453875521,
        "f": 83886081
      },
      "n": "UI",
      "d": 478017,
      "h": 227633744705,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(227633744705),
//--TRIMMABLE-BOUNDARY-START(124554529601),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130020161,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504202561,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 478017,
      "h": 124554529601,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124554529601)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(223338777409),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 478017,
      "h": 223338777409,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(223338777409),
//--TRIMMABLE-BOUNDARY-START(120259562305),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 478017,
      "h": 120259562305,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120259562305),
//--TRIMMABLE-BOUNDARY-START(128849496897),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 478017,
      "h": 128849496897,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(128849496897),
//--TRIMMABLE-BOUNDARY-START(133144464193),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 478017,
      "h": 133144464193,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(133144464193),
//--TRIMMABLE-BOUNDARY-START(38655183681),
    {
      "r": 178454529,
      "p": [
        {
          "n": "tier",
          "p": 6591237
        }
      ],
      "n": "AddActiveCode",
      "d": 478017,
      "h": 38655183681,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(38655183681),
//--TRIMMABLE-BOUNDARY-START(150324333377),
    {
      "r": 181338113,
      "p": [
        {
          "n": "settings",
          "p": 6329093
        }
      ],
      "n": "SaveGlobalSettings",
      "d": 478017,
      "h": 150324333377,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(150324333377),
//--TRIMMABLE-BOUNDARY-START(42950150977),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 478017,
      "h": 42950150977,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(42950150977),
//--TRIMMABLE-BOUNDARY-START(115964595009),
    {
      "r": 6881395,
      "p": [
        {
          "n": "value",
          "p": $.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel)).$h
        }
      ],
      "n": "GetView",
      "d": 478017,
      "h": 115964595009,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964595009),
//--TRIMMABLE-BOUNDARY-START(219043810113),
    {
      "r": 6881395,
      "p": [
        {
          "n": "pager",
          "p": (TStream) => $.$ZaYa.LCCTCS.IStreamProvider$$(TStream).$h
        }
      ],
      "g": [
        "TStream"
      ],
      "n": "StreamList",
      "d": 478017,
      "h": 219043810113,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(219043810113),
//--TRIMMABLE-BOUNDARY-START(214748842817),
    {
      "r": 6881395,
      "p": [
        {
          "n": "pager",
          "p": $.$fPer.LCFCD.Pager$$($.$ZaYa.LCCTCS.IStreamCategory).$h
        }
      ],
      "n": "StreamCategoryList",
      "d": 478017,
      "h": 214748842817,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(214748842817)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245118273),
    {
      "t": $.$Cdtc.LCCTCAS.M3UTVEditorProvider$$($.$rAPp.LCCTFL.FreeLiveTVStream).$h,
      "n": "freeLiveTVProvider",
      "d": 478017,
      "h": 47245118273,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245118273),
//--TRIMMABLE-BOUNDARY-START(51540085569),
    {
      "t": $.$Cdtc.LCCTCAS.M3UTVEditorProvider$$($.$rAPp.LCCTFM.FreeMovieStream).$h,
      "n": "freeMoviesProvider",
      "d": 478017,
      "h": 51540085569,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540085569),
//--TRIMMABLE-BOUNDARY-START(34360216385),
    {
      "t": $.$$.SCG.Dictionary$$$($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel, $.$hDPm.LCFCCD$2.RemoteDataTable$$($.$ZaYa.LCCTCM.CommunityTVActiveCodeModel)).$h,
      "n": "activeCodeLists",
      "d": 478017,
      "h": 34360216385,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360216385)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065249089),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 478017,
      "h": 30065249089,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065249089)
  ],
  "h": 478017,
  "a": [
    {
      "t": 917616,
      "c": 17180786800,
      "n": [
        {
          "n": "Roles",
          "v": "SuperAdmin,TV.Admin",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/TV",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/TV/{*Page}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCI.IViewProvider$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel)) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Admin.Pages.Admin`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Admin${separator}Pages${separator}Admin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(478017)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Bcl.Cryptography", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.Microsoft.IdentityModel.Logging", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.IdentityModel.Tokens", "NetJs.Microsoft.IdentityModel.JsonWebTokens", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.Newtonsoft.Json", "NetJs.ReverseMarkdown", "NetJs.System.IdentityModel.Tokens.Jwt", "NetJs.TMDbLib", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Authentication.Common", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Authentication.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Admin.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Local", "NetJs.LivingThing.Core.Community.TV.Common", "NetJs.LivingThing.Core.Community.TV.App.Blazor", "NetJs.LivingThing.Core.Community.TV.Client.Blazor", "NetJs.LivingThing.Core.Community.TV.Free"));
})();
//--TRIMMABLE-BOUNDARY-END(19265)
