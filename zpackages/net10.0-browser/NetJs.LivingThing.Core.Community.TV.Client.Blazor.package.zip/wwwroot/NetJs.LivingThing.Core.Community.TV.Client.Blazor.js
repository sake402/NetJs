
//--TRIMMABLE-BOUNDARY-START(36324)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mbc, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $mia, $mil, $mexl, $mit, $mij, $sih, $wZnq, $fnTP, $hqRR, $sitj, $Xjnw, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $uvJL, $DZqk, $kVHt, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $uVBI, $yleQ, $nYKj, $AvdQ, $xPgy, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $IHYd, $ZaYa, $OUNt) {
    "use strict";
    let _;
    let $StInCh;
    let $kkKGLh;
    let $xQxtzg;
    let $TVdLJb;
    let $wfgIkg;
    let $lBQSSc;
    let $dSYabg;
    let $mdUESf;
    let $NuIcfc;
    let $zDXoNe;
    let $BLgtmj;
    let $umngXi;
    let $qGfeQe;
    let $rLEGvg;
    let $QCTjvc;
    let $TzJICb;
    let $CwTJde;
    let $ojkiYe;
    let $BIUYRd;
    let $YiESSi;
    let $JjfDak;
    let $homacb;
    let $XPfxMj;
    let $KygQca;
    let $FwJUSg;
    let $NzoxXj;
    let $oQBKOi;
    let $DfzvJj;
    let $MBWSNf;
    let $ROORml;
    let $Zclphf;
    let $DfDvSf;
    let $HrNDzh;
    let $FMfIgc;
    let $ErvEmd;
    let $SpAVza;
    let $avQBHg;
    let $AUYoQh;
    let $nBqWwd;
    let $ZAAoDk;
    let $nQscPa;
    let $qmTxef;
    let $nhfWwd;
    let $kmNIoi;
    let $OXyHqh;
    let $DlWbVi;
    let $UMDmWa;
    let $GDXhYk;
    let $WHPJLh;
    let $zSYVAe;
    let $RGHILc;
    let $kMWeZe;
    let $MzqXDh;
    let $pGLGdg;
    let $VHyzne;
    let $HrnSdi;
    let $FsVPsf;
    let $MQIZXf;
    let $WZcBSk;
    let $hybKBd;
    let $BXyzEf;
    let $oRsjta;
    let $lKJiBe;
    let $ywnMll;
    let $BniPMe;
    let $WdqHSa;
    let $BMQbdl;
    let $wOzANb;
    let $NZbGqa;
    let $gqxkCh;
    let $GlmXkj;
    let $sjMXPc;
    let $yGTfBe;
    let $jyZrWh;
    let $MLWRXe;
    let $uawJud;
    let $vCwzAe;
    let $QYsvSb;
    let $yUcHrd;
    let $MzFaGj;
    let $FXGYhj;
    let $KZYmzd;
    let $WsgIQg;
    let $PTWJej;
    let $XSKohd;
    let $jMooOb;
    let $sCtLbh;
    let $xGSRBf;
    let $bCQfdi;
    let $QgvUfk;
    let $AlEtea;
    let $epgGZj;
    let $XwsGEf;
    let $zyVSaf;
    let $LyYTDd;
    let $WGQLZk;
    let $GTodpe;
    let $Yimfbh;
    let $vMQirj;
    let $GhqALk;
    let $vMyvZe;
    let $bRNisg;
    let $aJGwgg;
    let $Hkbugl;
    let $RvgGvf;
    let $coPTbg;
    let $caNvke;
    let $YXeeoh;
    let $XHMxHe;
    let $YvmUwg;
    let $PVoobe;
    let $yhJzwb;
    let $zrapNd;
    let $BKsgKa;
    let $yEUakh;
    let $ZIDDQe;
    let $jHGuEj;
    let $aZyGBf;
    let $GWExrb;
    let $DBulvh;
    let $HZesUj;
    let $ugKDic;
    let $aHmhyc;
    let $HhDGYf;
    let $iNJIgh;
    let $hxfjfe;
    let $cojJHb;
    let $JmzYmg;
    let $YJoVvi;
    let $TjvLxb;
    let $CiLbEb;
    let $RhGJxk;
    let $AggLsc;
    let $svxKFd;
    let $CagiXf;
    let $jvYKfb;
    let $AHtonf;
    let $YiLgVd;
    let $YpIMWk;
    let $KwXDif;
    let $OSjtDd;
    let $khSsKa;
    let $RuMvRg;
    let $yGDPKd;
    let $Kvgpwe;
    let $KikDUj;
    let $rwRZyk;
    let $hxUPid;
    let $Xjenwb;
    let $bFVgKh;
    let $uLMKFf;
    let $vxTyee;
    let $ozHEwj;
    let $wNnARc;
    let $hpMDMg;
    let $wZNzAb;
    let $qzFXWg;
    let $TvawMc;
    let $iYMOxe;
    let $CeLEqi;
    let $LKpQek;
    let $jaGOIc;
    let $ZqWnnl;
    let $szVeQc;
    let $UtcOYb;
    let $dsixjg;
    let $UtqxZc;
    let $hrknhf;
    let $sDGQAd;
    let $GTCFea;
    let $QRyhXb;
    let $AyUaug;
    let $jnlZsh;
    let $MGeNQd;
    let $RxNRBk;
    let $KZFrJd;
    let $lwNjhl;
    let $EgpwLe;
    let $keGxog;
    let $XQBjDc;
    let $IKmqFd;
    let $FZotPe;
    let $GwOfca;
    let $yCCELd;
    let $Odseti;
    let $qRsjVf;
    let $LxraBc;
    let $fxxEmg;
    let $TIZTpc;
    let $MakJkj;
    let $lpZzkf;
    let $URauvc;
    let $fRLFjl;
    let $oskdib;
    let $iwQjOi;
    let $obsKpd;
    let $TdYyCf;
    let $caaqhl;
    let $PhfYdj;
    let $nCyEeg;
    let $qbtvZk;
    let $TYJeSk;
    let $cQlwvb;
    let $oSFiWj;
    let $EUADvh;
    let $JVozdj;
    let $daAjIa;
    let $nqkiYf;
    let $Xpjvml;
    let $cmAoog;
    let $dZQxxd;
    let $rRbnTi;
    let $NpLfdb;
    let $iRiTob;
    let $VkTTYk;
    let $eiWVzj;
    let $YPgXCd;
    let $omYUxg;
    let $fsfUKh;
    let $jVwimh;
    let $NcHNja;
    let $BCtRsd;
    let $NHzota;
    let $oELlTd;
    let $OzRTJh;
    let $CGrqvj;
    let $LRWXqg;
    let $fiywCf;
    let $IcRaLe;
    let $EJvvdd;
    let $VVZEsh;
    let $MNqJcj;
    let $Kdvnyj;
    let $LCVqwh;
    let $GXnEkd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.TV.Client.Blazor", 
    {
  "h": 36324,
  "f": "LivingThing.Core.Community.TV.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.TV.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.TV.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(298468)
        $asm.$cls(`$aImc.LCCTC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295265764)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295265764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$aImc.LCCTC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295265764)
            
            static $h = 298468;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295265764),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 298468,
      "h": 4295265764,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295265764)
  ],
  "h": 298468
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(298468)
        
        

        //--TRIMMABLE-BOUNDARY-START(1084900)
        $asm.$cls(`$aImc.LCCTCS$1.TVQueryComand`, ($self) => class TVQueryComand extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475921380)
            /*string*/ Intent = null;
            //--TRIMMABLE-BOUNDARY-END(21475921380)
            
            //--TRIMMABLE-BOUNDARY-START(8591019492)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591019492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591019492)
            
            //--TRIMMABLE-BOUNDARY-START(8591019492)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591019492)
            
            static $h = 1084900;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475921380),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180954084,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065855972,
        "f": 83886081
      },
      "n": "Intent",
      "d": 1084900,
      "h": 21475921380,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475921380)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591019492),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1084900,
      "h": 8591019492,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591019492)
  ],
  "h": 1084900
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Shared.TVQueryComand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Shared${separator}TVQueryComand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1084900)
        
        

        //--TRIMMABLE-BOUNDARY-START(101860)
        $asm.$cls(`$aImc._LCCTCPC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295069156)
            static /*void */ CreateDataList_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg0, /*int*/ __seq1, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<global::System.Collections.Generic.IEnumerable<T>>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<global::System.Collections.Generic.IEnumerable<T>>>*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295069156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Features", $.$box(__arg0, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq1, "Data", __arg1);
                __builder.AddComponentParameter(__seq2, "DataChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "DataExpression", __arg3);
                __builder.AddComponentParameter(__seq4, "ChildContent", __arg4);
                __builder.AddComponentParameter(__seq5, "Empty", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295069156)
            
            //--TRIMMABLE-BOUNDARY-START(8590036452)
            static /*void */ CreateDataList_1(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg2, /*int*/ __seq3, /*global::System.Object*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590036452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "Data", __arg1);
                __builder.AddComponentParameter(__seq2, "Features", $.$box(__arg2, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq3, "li-class", __arg3);
                __builder.AddComponentParameter(__seq4, "ChildContent", __arg4);
                __builder.AddComponentParameter(__seq5, "Empty", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590036452)
            
            static $h = 101860;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295069156),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 14505642
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (T) => $.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$(T)).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (T) => $.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.SCG.IEnumerable$$(T))).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": 6881395
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_0",
      "d": 101860,
      "h": 4295069156,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295069156),
//--TRIMMABLE-BOUNDARY-START(8590036452),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 14505642
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 131073
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": 6881395
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_1",
      "d": 101860,
      "h": 8590036452,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590036452)
  ],
  "h": 101860
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.TV.Client.Pages.CommunityTVApp.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Pages${separator}CommunityTVApp${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(101860)
        
        

        //--TRIMMABLE-BOUNDARY-START(167396)
        $asm.$cls(`$aImc._LCCTCSC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295134692)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Client.Components.Input.InputEditorFeatures*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295134692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Theme", $.$clone(__arg0));
                __builder.AddComponentParameter(__seq1, "Features", $.$box(__arg1, $.$hDPm.LCFCCI$1.InputEditorFeatures));
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295134692)
            
            static $h = 167396;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295134692),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 65309014
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 27612842
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 167396,
      "h": 4295134692,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295134692)
  ],
  "h": 167396
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.TV.Client.Shared.CommunityTVDevicePairingAuthenticationInput.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Shared${separator}CommunityTVDevicePairingAuthenticationInput${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(167396)
        
        

        //--TRIMMABLE-BOUNDARY-START(364004)
        $asm.$cls(`$aImc.LCCTC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180233188)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$aImc.LCCTCP.CommunityTVApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$aImc.LCCTCP.CommunityTVApp().$ctor$3();
                    }, $kkKGLh ??= {"r":2752627,"n":"","d":364004,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$aImc.LCCTCS$1.CommunityTVAppInMobile.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$aImc.LCCTCS$1.CommunityTVAppInMobile().$ctor$3();
                    }, $xQxtzg ??= {"r":2752627,"n":"","d":364004,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$aImc.LCCTCS$1.CommunityTVAuthentication.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$aImc.LCCTCS$1.CommunityTVAuthentication().$ctor$3();
                    }, $TVdLJb ??= {"r":2752627,"n":"","d":364004,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$aImc.LCCTCS$1.CommunityTVBackground.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$aImc.LCCTCS$1.CommunityTVBackground().$ctor$3();
                    }, $wfgIkg ??= {"r":2752627,"n":"","d":364004,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$aImc.LCCTCS$1.CommunityTVDevicePairingAuthenticationInput.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$aImc.LCCTCS$1.CommunityTVDevicePairingAuthenticationInput().$ctor$5();
                    }, $lBQSSc ??= {"r":2752627,"n":"","d":364004,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$aImc.LCCTCS$1.CommunityTVSplashScreen.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$aImc.LCCTCS$1.CommunityTVSplashScreen().$ctor$3();
                    }, $dSYabg ??= {"r":2752627,"n":"","d":364004,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180233188)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295331300)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295331300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295331300)
            
            //--TRIMMABLE-BOUNDARY-START(4295331300)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295331300)
            
            static $h = 364004;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180233188),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885265892,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 364004,
      "h": 17180233188,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180233188)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295331300),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 364004,
      "h": 4295331300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295331300)
  ],
  "h": 364004
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(364004)
        
        

        //--TRIMMABLE-BOUNDARY-START(495076)
        $asm.$cls(`$aImc.LCCTC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590429668)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590429668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$aImc.LCCTCS.CommunityTVService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$ZaYa.LCCTCM.CommunityTVPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$aImc.LCCTCS.CommunityTVApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aImc.LCCTCS.CommunityTVApplication, x);
                }, $XPfxMj ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":495076,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aImc.LCCTCS.CommunityTVApplication, x);
                }, $KygQca ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":495076,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$ZaYa.LCCTCM.CommunityTVPostModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$ZaYa.LCCTCM.CommunityTVAccountModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$ZaYa.LCCTCM.CommunityTVDeviceModel, services, null);
                $.$hDPm.LCFCI.InputEditorProviderExtension.AddInputEditor$1($.$ZaYa.LCCTCM.CommunityTVDevicePairingAuthenticationCode, $.$aImc.LCCTCS$1.CommunityTVDevicePairingAuthenticationInput, services);
                $.$aImc.LCCTC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590429668)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$aImc.LCCTC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295462372)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295462372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295462372)
            
            //--TRIMMABLE-BOUNDARY-START(4295462372)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295462372)
            
            static $h = 495076;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590429668),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 495076,
      "h": 8590429668,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590429668)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295462372),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 495076,
      "h": 4295462372,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295462372)
  ],
  "h": 495076
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(495076)
        
        

        //--TRIMMABLE-BOUNDARY-START(1215972)
        $asm.$cls(`$aImc.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296183268)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296183268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296183268)
            
            //--TRIMMABLE-BOUNDARY-START(4296183268)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296183268)
            
            static $h = 1215972;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296183268),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1215972,
      "h": 4296183268,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296183268)
  ],
  "h": 1215972,
  "a": [
    {
      "t": 1150436,
      "c": 4296117732
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1215972)
        
        

        //--TRIMMABLE-BOUNDARY-START(1150436)
        $asm.$cls(`$aImc.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296117732)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296117732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296117732)
            
            //--TRIMMABLE-BOUNDARY-START(4296117732)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296117732)
            
            static $h = 1150436;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296117732),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1150436,
      "h": 4296117732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296117732)
  ],
  "h": 1150436
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1150436)
        
        

        //--TRIMMABLE-BOUNDARY-START(232932)
        $asm.$cls(`$aImc.LCCTC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590167524)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590167524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590167524)
            
            //--TRIMMABLE-BOUNDARY-START(4295200228)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295200228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295200228)
            
            //--TRIMMABLE-BOUNDARY-START(4295200228)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295200228)
            
            static $h = 232932;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590167524),
    {
      "r": 65537,
      "n": "Execute",
      "d": 232932,
      "h": 8590167524,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590167524)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295200228),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 232932,
      "h": 4295200228,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295200228)
  ],
  "h": 232932
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(232932)
        
        

        //--TRIMMABLE-BOUNDARY-START(1019364)
        $asm.$cls(`$aImc.LCCTCS$1.CommunityTVSplashScreen`, ($self) => class CommunityTVSplashScreen extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21475855844)
            /*string */ get OptimizedComponentName()
            {
                return "communitytvsplashscreen";
            }
            //--TRIMMABLE-BOUNDARY-END(21475855844)
            
            //--TRIMMABLE-BOUNDARY-START(8590953956)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590953956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pos-rel hv-10 wv-10");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "pos-abs t-0 r-0 b-0 l-0 z--1");
                __builder.OpenComponent$1($.$aImc.LCCTCS$1.CommunityTVBackground, 4);
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(5, "\r\n    ");
                __builder.AddMarkupContent(6, "<div class=\"stack z-10 hf\"><div class=\"mg-a stack\"><img src=\"_content/LivingThing.Core.Community.TV.Client.Blazor/img/logo.jpeg\" class=\"mgx-a wx-1 hx-1\">\r\n            <span class=\"mgt bg-white pdx pdy-2 corner-3 text-center\">Companion</span></div></div>");
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590953956)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295986660)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295986660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295986660)
            
            //--TRIMMABLE-BOUNDARY-START(4295986660)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295986660)
            
            static $h = 1019364;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475855844),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180888548,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1019364,
      "h": 21475855844,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475855844)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590953956),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1019364,
      "h": 8590953956,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590953956)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295986660),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1019364,
      "h": 4295986660,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295986660)
  ],
  "h": 1019364
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Shared.CommunityTVSplashScreen`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Shared${separator}CommunityTVSplashScreen`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1019364)
        
        

        //--TRIMMABLE-BOUNDARY-START(888292)
        $asm.$cls(`$aImc.LCCTCS$1.CommunityTVBackground`, ($self) => class CommunityTVBackground extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(25770692068)
            /*string */ get OptimizedComponentName()
            {
                return "communitytvbackground";
            }
            //--TRIMMABLE-BOUNDARY-END(25770692068)
            
            //--TRIMMABLE-BOUNDARY-START(8590822884)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590822884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "svg");
                __builder.AddAttribute$5(1, "xmlns", "http://www.w3.org/2000/svg");
                __builder.AddAttribute$5(2, "xmlns:xlink", "http://www.w3.org/1999/xlink");
                __builder.AddAttribute$5(3, "width", "100%");
                __builder.AddAttribute$5(4, "height", "100%");
                __builder.AddAttribute$5(5, "viewBox", "0 0 375 812");
                __builder.OpenElement(6, "defs");
                __builder.OpenElement(7, "linearGradient");
                __builder.AddAttribute$5(8, "id", $.$strNN((this.id)) + "-linear-gradient");
                __builder.AddAttribute$5(9, "x1", "0.5");
                __builder.AddAttribute$5(10, "x2", "0.069");
                __builder.AddAttribute$5(11, "y2", "0.99");
                __builder.AddAttribute$5(12, "gradientUnits", "objectBoundingBox");
                __builder.AddMarkupContent(13, "<stop offset=\"0\" stop-color=\"#cab900\"></stop>\r\n            <stop offset=\"0\" stop-color=\"#c9b800\"></stop>\r\n            <stop offset=\"0.027\" stop-color=\"#d2c000\"></stop>\r\n            <stop offset=\"0.34\" stop-color=\"#84826f\"></stop>\r\n            <stop offset=\"0.692\" stop-color=\"#807e6e\"></stop>\r\n            <stop offset=\"0.763\" stop-color=\"#c3bd76\"></stop>\r\n            <stop offset=\"0.9\" stop-color=\"#f0de05\"></stop>\r\n            <stop offset=\"1\" stop-color=\"#beb231\"></stop>");
                __builder.CloseElement();
                __builder.AddMarkupContent(14, "\r\n        ");
                __builder.OpenElement(15, "radialGradient");
                __builder.AddAttribute$5(16, "id", $.$strNN((this.id)) + "-radial-gradient");
                __builder.AddAttribute$5(17, "cx", "0.203");
                __builder.AddAttribute$5(18, "cy", "0.086");
                __builder.AddAttribute$5(19, "r", "2.188");
                __builder.AddAttribute$5(20, "gradientTransform", "matrix(0.997, 0.077, -0.037, 0.479, 0.004, 0.029)");
                __builder.AddAttribute$5(21, "gradientUnits", "objectBoundingBox");
                __builder.AddMarkupContent(22, "<stop offset=\"0\" stop-color=\"#0a386a\"></stop>\r\n            <stop offset=\"0.066\" stop-color=\"#134c8a\"></stop>\r\n            <stop offset=\"0.109\" stop-color=\"#124a87\"></stop>\r\n            <stop offset=\"0.198\" stop-color=\"#134d8c\"></stop>\r\n            <stop offset=\"0.279\" stop-color=\"#165497\"></stop>\r\n            <stop offset=\"0.384\" stop-color=\"#2778d1\"></stop>\r\n            <stop offset=\"0.384\" stop-color=\"#8cb2db\"></stop>\r\n            <stop offset=\"0.389\" stop-color=\"#3e85d3\"></stop>\r\n            <stop offset=\"0.389\" stop-color=\"#7da4ce\"></stop>\r\n            <stop offset=\"0.399\" stop-color=\"#3476be\"></stop>\r\n            <stop offset=\"0.833\" stop-color=\"#347fd2\"></stop>\r\n            <stop offset=\"0.842\" stop-color=\"#2675cc\"></stop>\r\n            <stop offset=\"0.847\" stop-color=\"#2269b8\"></stop>\r\n            <stop offset=\"1\" stop-color=\"#051c35\"></stop>");
                __builder.CloseElement();
                __builder.AddMarkupContent(23, "\r\n        ");
                __builder.OpenElement(24, "linearGradient");
                __builder.AddAttribute$5(25, "id", $.$strNN((this.id)) + "-linear-gradient-2");
                __builder.AddAttribute$5(26, "x1", "1.036");
                __builder.AddAttribute$5(27, "y1", "0.013");
                __builder.AddAttribute$5(28, "x2", "0.036");
                __builder.AddAttribute$5(29, "y2", "1.009");
                __builder.AddAttribute$5(30, "gradientUnits", "objectBoundingBox");
                __builder.AddMarkupContent(31, "<stop offset=\"0\" stop-color=\"#2daebd\"></stop>\r\n            <stop offset=\"0.645\" stop-color=\"#65aeb7\"></stop>\r\n            <stop offset=\"1\" stop-color=\"#74c1cb\"></stop>");
                __builder.CloseElement();
                __builder.AddMarkupContent(32, "\r\n        ");
                __builder.OpenElement(33, "clipPath");
                __builder.AddAttribute$5(34, "id", $.$strNN((this.id)) + "-clip-iPhone_X_XS_11_Pro_12");
                __builder.AddMarkupContent(35, "<rect width=\"375\" height=\"812\"></rect>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(36, "\r\n    ");
                __builder.OpenElement(37, "g");
                __builder.AddAttribute$5(38, "data-name", "iPhone X, XS, 11 Pro \u2013 12");
                __builder.AddAttribute$5(39, "clip-path", $.$strNN("url(#" + $.$strNN((this.id))) + "-clip-iPhone_X_XS_11_Pro_12)");
                __builder.AddMarkupContent(40, "<rect width=\"375\" height=\"812\" fill=\"#fff\"></rect>\r\n        ");
                __builder.OpenElement(41, "g");
                __builder.AddAttribute$5(42, "data-name", "Rectangle 3");
                __builder.AddAttribute$5(43, "stroke", "#707070");
                __builder.AddAttribute$5(44, "stroke-width", "1");
                __builder.AddAttribute$5(45, "fill", $.$strNN("url(#" + $.$strNN((this.id))) + "-linear-gradient)");
                __builder.AddMarkupContent(46, "<rect width=\"375\" height=\"812\" stroke=\"none\"></rect>\r\n            <rect x=\"0.5\" y=\"0.5\" width=\"374\" height=\"811\" fill=\"none\"></rect>");
                __builder.CloseElement();
                __builder.AddMarkupContent(47, "\r\n        ");
                __builder.OpenElement(48, "rect");
                __builder.AddAttribute$5(49, "data-name", "Rectangle 1");
                __builder.AddAttribute$5(50, "width", "294");
                __builder.AddAttribute$5(51, "height", "759");
                __builder.AddAttribute$5(52, "transform", "translate(-30 -30)");
                __builder.AddAttribute$5(53, "fill", $.$strNN("url(#" + $.$strNN((this.id))) + "-radial-gradient)");
                __builder.CloseElement();
                __builder.AddMarkupContent(54, "\r\n        ");
                __builder.OpenElement(55, "rect");
                __builder.AddAttribute$5(56, "data-name", "Rectangle 2");
                __builder.AddAttribute$5(57, "width", "244");
                __builder.AddAttribute$5(58, "height", "748");
                __builder.AddAttribute$5(59, "transform", "translate(131 64)");
                __builder.AddAttribute$5(60, "fill", $.$strNN("url(#" + $.$strNN((this.id))) + "-linear-gradient-2)");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590822884)
            
            //--TRIMMABLE-BOUNDARY-START(21475724772)
            /*string*/ id = null;
            //--TRIMMABLE-BOUNDARY-END(21475724772)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295855588)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295855588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295855588)
            
            //--TRIMMABLE-BOUNDARY-START(4295855588)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295855588)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475724772)
                this.id = $.$fPer.LCFCS$6.StringExtension.GetRandomString(8, true, true, false);
                //--TRIMMABLE-BOUNDARY-END(21475724772)
                
            }
            static $h = 888292;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770692068),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180757476,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 888292,
      "h": 25770692068,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770692068)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590822884),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 888292,
      "h": 8590822884,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590822884)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475724772),
    {
      "t": 1310721,
      "n": "id",
      "d": 888292,
      "h": 21475724772,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475724772)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295855588),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 888292,
      "h": 4295855588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295855588)
  ],
  "h": 888292
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Shared.CommunityTVBackground`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Shared${separator}CommunityTVBackground`; }
        });
        //--TRIMMABLE-BOUNDARY-END(888292)
        
        

        //--TRIMMABLE-BOUNDARY-START(757220)
        $asm.$cls(`$aImc.LCCTCS$1.CommunityTVAppInMobile`, ($self) => class CommunityTVAppInMobile extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21475593700)
            /*string */ get OptimizedComponentName()
            {
                return "communitytvappinmobile";
            }
            //--TRIMMABLE-BOUNDARY-END(21475593700)
            
            //--TRIMMABLE-BOUNDARY-START(8590691812)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590691812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "LivingThing.Core.Community.TV.App.Pages.LiveTV");
                __builder.AddAttribute$5(1, "Features", "TVFeatures.Default&~TVFeatures.ToolBar&~TVFeatures.SideBar");
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590691812)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295724516)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295724516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295724516)
            
            //--TRIMMABLE-BOUNDARY-START(4295724516)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295724516)
            
            static $h = 757220;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475593700),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180626404,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 757220,
      "h": 21475593700,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475593700)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590691812),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 757220,
      "h": 8590691812,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590691812)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295724516),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 757220,
      "h": 4295724516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295724516)
  ],
  "h": 757220
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Shared.CommunityTVAppInMobile`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Shared${separator}CommunityTVAppInMobile`; }
        });
        //--TRIMMABLE-BOUNDARY-END(757220)
        
        

        //--TRIMMABLE-BOUNDARY-START(822756)
        $asm.$cls(`$aImc.LCCTCS$1.CommunityTVAuthentication`, ($self) => class CommunityTVAuthentication extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(12885724644)
            /*IClientAuthenticationService*/ AuthenticationService = null;
            //--TRIMMABLE-BOUNDARY-END(12885724644)
            
            //--TRIMMABLE-BOUNDARY-START(51540430308)
            /*bool*/ rememberMe = false;
            //--TRIMMABLE-BOUNDARY-END(51540430308)
            
            //--TRIMMABLE-BOUNDARY-START(38655528420)
            /*bool*/ havRead = false;
            //--TRIMMABLE-BOUNDARY-END(38655528420)
            
            //--TRIMMABLE-BOUNDARY-START(77310234084)
            /*void */ ToggleRememberMe()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310234084);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.rememberMe = !this.rememberMe;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310234084)
            
            //--TRIMMABLE-BOUNDARY-START(73015266788)
            /*void */ ToggleHaveRead()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015266788);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.havRead = !this.havRead;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015266788)
            
            //--TRIMMABLE-BOUNDARY-START(85900168676)
            /*string*/ view = null;
            //--TRIMMABLE-BOUNDARY-END(85900168676)
            
            //--TRIMMABLE-BOUNDARY-START(64425332196)
            /*void */ SetLogin()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425332196);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.view = "Login";
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425332196)
            
            //--TRIMMABLE-BOUNDARY-START(68720299492)
            /*void */ SetRegister()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720299492);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.view = "SignUp";
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720299492)
            
            //--TRIMMABLE-BOUNDARY-START(81605201380)
            /*Task */ ValidateSignUp()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605201380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.havRead)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Must agree to terms and conditions");
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(81605201380)
            
            //--TRIMMABLE-BOUNDARY-START(47245463012)
            /*string */ get OptimizedComponentName()
            {
                return "communitytvauthentication";
            }
            //--TRIMMABLE-BOUNDARY-END(47245463012)
            
            //--TRIMMABLE-BOUNDARY-START(42950495716)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950495716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.AuthenticationService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientAuthenticationService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(42950495716)
            
            //--TRIMMABLE-BOUNDARY-START(17180691940)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180691940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pos-rel hf wf");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "pos-abs t-0 r-0 b-0 l-0 z--1");
                __builder.OpenComponent$1($.$aImc.LCCTCS$1.CommunityTVBackground, 4);
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(5, "\r\n    ");
                __builder.OpenElement(6, "div");
                __builder.AddAttribute$5(7, "class", "stack z-10 hf");
                __builder.OpenElement(8, "div");
                __builder.AddAttribute$5(9, "class", "bg-card pd mgy-a mgx corner-3");
                __builder.AddMarkupContent(10, "<div class=\"stack\"><img src=\"_content/LivingThing.Core.Community.TV.Client.Blazor/img/logo.jpeg\" class=\"mgx-a wx-1 hx-1\">\r\n                <span class=\"mgt bg-white pdx pdy-2 corner-3 text-center mgx-a\">Companion</span></div>\r\n            ");
                __builder.OpenComponent$1($.$hDPm.LCFCCM$6.MultiView, 11);
                __builder.AddComponentParameter(12, "CurrentViewName", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.view));
                __builder.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCM$6.View, 14);
                    __builder2.AddComponentParameter(15, "Name", "Login");
                    __builder2.AddComponentParameter(16, "TransitionIn", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 32/*DisplayMode.FadeIn*/), $.$hDPm.LCFCI.DisplayMode));
                    __builder2.AddComponentParameter(17, "TransitionOut", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 41/*DisplayMode.FadeOut*/), $.$hDPm.LCFCI.DisplayMode));
                    __builder2.AddAttribute$3(18, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(19, "<h3 class=\"text-center\">Please Login</h3>\r\n                    ");
                            __builder3.AddContent$1(20, this.AuthenticationService.LCFCI$IClientAuthenticationService$Authenticate((() =>
                            {
                                //new $.$hDPm.LCFCI.AuthenticationParameter()
                                const $t1 = $.$hDPm.LCFCI.AuthenticationParameter;
                                const $i1 = new $t1();
                                $i1.$ctor$1();
                                $i1.Flags = 1/*LoginActionFlags.Login*/;
                                $i1.LoginFormSuffix = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(21, "\r\n                        ");
                                }, $mdUESf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":822756,"h":0,"f":17825794});
                                return $i1;
                            })()));
                            __builder3.AddMarkupContent(22, "\r\n                    ");
                            __builder3.OpenElement(23, "div");
                            __builder3.AddAttribute$5(24, "class", "mgt-10 row");
                            __builder3.AddMarkupContent(25, "<b>I dont have an account?</b>\r\n                        ");
                            __builder3.OpenElement(26, "div");
                            __builder3.AddAttribute$5(27, "class", "col-a");
                            __builder3.OpenElement(28, "button");
                            __builder3.AddAttribute$5(29, "class", "bg-primary bd-0 corner-3 pdx-2 pdy-1 nowrap");
                            __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 30, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.SetRegister)));
                            __builder3.AddContent$4(31, "Sign Up");
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                        }, $NuIcfc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":822756,"h":0,"f":17825794});
                    }), $zDXoNe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":822756,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(32, "\r\n                ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCM$6.View, 33);
                    __builder2.AddComponentParameter(34, "Name", "SignUp");
                    __builder2.AddComponentParameter(35, "TransitionIn", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 32/*DisplayMode.FadeIn*/), $.$hDPm.LCFCI.DisplayMode));
                    __builder2.AddComponentParameter(36, "TransitionOut", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 41/*DisplayMode.FadeOut*/), $.$hDPm.LCFCI.DisplayMode));
                    __builder2.AddAttribute$3(37, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(38, "<h3 class=\"text-center\">Signup</h3>\r\n                    ");
                            __builder3.AddContent$1(39, this.AuthenticationService.LCFCI$IClientAuthenticationService$Authenticate((() =>
                            {
                                //new $.$hDPm.LCFCI.AuthenticationParameter()
                                const $t2 = $.$hDPm.LCFCI.AuthenticationParameter;
                                const $i2 = new $t2();
                                $i2.$ctor$1();
                                $i2.Flags = 2/*LoginActionFlags.Register*/;
                                return $i2;
                            })()));
                            __builder3.AddMarkupContent(40, "\r\n                    ");
                            __builder3.OpenElement(41, "div");
                            __builder3.AddAttribute$5(42, "class", "mgt-10 row");
                            __builder3.AddMarkupContent(43, "<b>I already have an account?</b>\r\n                        ");
                            __builder3.OpenElement(44, "div");
                            __builder3.AddAttribute$5(45, "class", "col-a");
                            __builder3.OpenElement(46, "button");
                            __builder3.AddAttribute$5(47, "class", "bg-primary bd-0 corner-3 pdx-2 pdy-1 nowrap");
                            __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 48, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.SetLogin)));
                            __builder3.AddContent$4(49, "Sign In");
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                        }, $BLgtmj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":822756,"h":0,"f":17825794});
                    }), $umngXi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":822756,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $qGfeQe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":822756,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17180691940)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590757348)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590757348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590757348)
            
            //--TRIMMABLE-BOUNDARY-START(8590757348)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590757348)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885724644)
                this.AuthenticationService = null;
                //--TRIMMABLE-BOUNDARY-END(12885724644)
                
                //--TRIMMABLE-BOUNDARY-START(85900168676)
                this.view = "Login";
                //--TRIMMABLE-BOUNDARY-END(85900168676)
                
            }
            static $h = 822756;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885724644),
    {
      "p": 63592106,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770626532,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130364900,
        "f": 83886081
      },
      "n": "AuthenticationService",
      "d": 822756,
      "h": 12885724644,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885724644),
//--TRIMMABLE-BOUNDARY-START(47245463012),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360561124,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 822756,
      "h": 47245463012,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245463012)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77310234084),
    {
      "r": 65537,
      "n": "ToggleRememberMe",
      "d": 822756,
      "h": 77310234084,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77310234084),
//--TRIMMABLE-BOUNDARY-START(73015266788),
    {
      "r": 65537,
      "n": "ToggleHaveRead",
      "d": 822756,
      "h": 73015266788,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015266788),
//--TRIMMABLE-BOUNDARY-START(64425332196),
    {
      "r": 65537,
      "n": "SetLogin",
      "d": 822756,
      "h": 64425332196,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425332196),
//--TRIMMABLE-BOUNDARY-START(68720299492),
    {
      "r": 65537,
      "n": "SetRegister",
      "d": 822756,
      "h": 68720299492,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720299492),
//--TRIMMABLE-BOUNDARY-START(81605201380),
    {
      "r": 178454529,
      "n": "ValidateSignUp",
      "d": 822756,
      "h": 81605201380,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81605201380),
//--TRIMMABLE-BOUNDARY-START(42950495716),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 822756,
      "h": 42950495716,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950495716),
//--TRIMMABLE-BOUNDARY-START(17180691940),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 822756,
      "h": 17180691940,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180691940)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540430308),
    {
      "t": 262145,
      "n": "rememberMe",
      "d": 822756,
      "h": 51540430308,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540430308),
//--TRIMMABLE-BOUNDARY-START(38655528420),
    {
      "t": 262145,
      "n": "havRead",
      "d": 822756,
      "h": 38655528420,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655528420),
//--TRIMMABLE-BOUNDARY-START(85900168676),
    {
      "t": 1310721,
      "n": "view",
      "d": 822756,
      "h": 85900168676,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85900168676)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590757348),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 822756,
      "h": 8590757348,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590757348)
  ],
  "h": 822756
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Shared.CommunityTVAuthentication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Shared${separator}CommunityTVAuthentication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(822756)
        
        

        //--TRIMMABLE-BOUNDARY-START(429540)
        $asm.$cls(`$aImc.LCCTCP.CommunityTVApp`, ($self) => class CommunityTVApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(163209186788)
            /*string */ get OptimizedComponentName()
            {
                return "communitytvapp";
            }
            //--TRIMMABLE-BOUNDARY-END(163209186788)
            
            //--TRIMMABLE-BOUNDARY-START(137439383012)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439383012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aImc.LCCTCS.CommunityTVService, serviceProvider);
                this.Application = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$aImc.LCCTCS.CommunityTVApplication, serviceProvider);
                this.Rendering = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IUIRenderingProvider, serviceProvider);
                this.UI = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientService, serviceProvider);
                this.AuthenticationService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GfYa.LCFCA.IAuthenticationService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(137439383012)
            
            //--TRIMMABLE-BOUNDARY-START(154619252196)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(154619252196)
            
            //--TRIMMABLE-BOUNDARY-START(180389055972)
            /*CommunityTVService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(180389055972)
            
            //--TRIMMABLE-BOUNDARY-START(47245069796)
            /*CommunityTVApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(47245069796)
            
            //--TRIMMABLE-BOUNDARY-START(176094088676)
            /*IUIRenderingProvider*/ Rendering = null;
            //--TRIMMABLE-BOUNDARY-END(176094088676)
            
            //--TRIMMABLE-BOUNDARY-START(236223630820)
            /*IUIClientService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(236223630820)
            
            //--TRIMMABLE-BOUNDARY-START(51540037092)
            /*IAuthenticationService*/ AuthenticationService = null;
            //--TRIMMABLE-BOUNDARY-END(51540037092)
            
            //--TRIMMABLE-BOUNDARY-START(42950102500)
            /*Application?*/ application = null;
            //--TRIMMABLE-BOUNDARY-END(42950102500)
            
            //--TRIMMABLE-BOUNDARY-START(38655135204)
            /*CommunityPosts<CommunityTVAccountModel>?*/ accounts = null;
            //--TRIMMABLE-BOUNDARY-END(38655135204)
            
            //--TRIMMABLE-BOUNDARY-START(133144415716)
            /*CommunityPosts<CommunityTVGroupModel>?*/ groups = null;
            //--TRIMMABLE-BOUNDARY-END(133144415716)
            
            //--TRIMMABLE-BOUNDARY-START(64424938980)
            /*CommunityPosts<CommunityTVDeviceModel>?*/ devices = null;
            //--TRIMMABLE-BOUNDARY-END(64424938980)
            
            //--TRIMMABLE-BOUNDARY-START(34360167908)
            /*Task *//*async*/  AccountCreated(/*CommunityTVAccountModel*/ account)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360167908);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.accounts !== null)
                    {
                        let $t1, $r1;
                        ($t1 = this.accounts.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$ZaYa.LCCTCM.CommunityTVAccountModel), [ account ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                    ($t2 = this.UI.LCFCI$IUIClientService$ClientPage.LCFCC$IUIPageService$NavigateBack(null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360167908)
            
            //--TRIMMABLE-BOUNDARY-START(128849448420)
            /*Task *//*async*/  GroupCreated(/*CommunityTVGroupModel*/ group)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128849448420);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = this.groups.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$ZaYa.LCCTCM.CommunityTVGroupModel), [ group ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    ($t4 = this.UI.LCFCI$IUIClientService$ClientPage.LCFCC$IUIPageService$NavigateBack(null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(128849448420)
            
            //--TRIMMABLE-BOUNDARY-START(60129971684)
            /*Task *//*async*/  DeviceCreated(/*CommunityTVDeviceModel*/ device)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129971684);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t5 = this.devices.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$ZaYa.LCCTCM.CommunityTVDeviceModel), [ device ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    ($t6 = this.UI.LCFCI$IUIClientService$ClientPage.LCFCC$IUIPageService$NavigateBack(null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60129971684)
            
            //--TRIMMABLE-BOUNDARY-START(141734350308)
            /*Task *//*async*/  LaunchTV(/*CommunityTVAccountModel*/ usingAccount)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t7, $r7;
                    let $t8, $r8;
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141734350308);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t7 = this.Service.TVPlayerService.Login(usingAccount, false, true), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    ($t8 = this.Service.TVPlayerService.EnsureLoaded(false), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    ($t9 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.TV.Client.Blazor\\CommunityTVApp.razor.cs", "LaunchTV", 72), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    this.Navigation.NavigateTo$1($.$fPer.LCFC.Stringy.op_Implicit$1($.$hDPm.LCFC.UtilityExtensions.GetAppLink$1("IPTV", this.application.NavigationPathSegment)), false, false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(141734350308)
            
            //--TRIMMABLE-BOUNDARY-START(167504154084)
            /*Task<IEnumerable<string>> *//*async*/  Pay(/*IPaymentTier*/ tier, /*CommunityTVAccountModel*/ account)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$$.S.String)), $.$$.SCG.IEnumerable$$($.$$.S.String), async ($asnycContext) => 
                {
                    let $t11, $r11;
                    let $t13, $r13;
                    let $t14, $r14;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504154084);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*ServiceTierModel*/ let _tier = $.$cast(tier, $.$AvdQ.LCFCP.ServiceTierModel);
                    /*string*/ let paymentReference;
                    if (tier.LCFCP$IPaymentTier$Cost.Value > 0)
                    {
                        let $t10, $r10;
                        paymentReference = (($t10 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Payment.LCFCI$IUIPaymentProcessorProvider$ProcessPayment(tier.LCFCP$IPaymentTier$Cost, $.$strNN(tier.LCFC$INamed$Name) + ": TV Subscription", $.$strNN($.$strNN($.$strNN($.$strNN($.$dspc(this.Service.CommunityService.Account.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString)) + "/") + $.$strNN(tier.LCFC$INamed$Name)) + "/") + $.$strNN($.$$.S.DateTime.UtcNow.ToString()), tier.LCFC$IDescribable$Description, null, "TV", null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)))).Reference;
                    }
                    else 
                    {
                        paymentReference = $.$strNN($.$strNN($.$strNN($.$strNN($.$dspc(this.Service.CommunityService.Account.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString)) + "/") + $.$strNN(tier.LCFC$INamed$Name)) + "/") + $.$strNN($.$$.S.DateTime.UtcNow.ToString());
                    }
                    /*var*/ let codes = ($t11 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$$.SCG.Dictionary$$$($.$$.S.Guid, $.$$.SCG.IEnumerable$$($.$$.S.String)), this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.Guid, $.$$.SCG.IEnumerable$$($.$$.S.String)))))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LCCTCS$ICommunityTVRemoteService$PurchaseActiveCode(account.Identifier, ($.$cast(_tier, $.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel)).Months, ($.$cast(_tier, $.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel)).Connections, paymentReference);
                    }, $FwJUSg ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.Guid, $.$$.SCG.IEnumerable$$($.$$.S.String)))).$h,"p":[{"n":"server","p":3248901}],"n":"","d":429540,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                    if (tier.LCFCP$IPaymentTier$Cost.Value === 0)
                    {
                        let $t12, $r12;
                        ($t12 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$vWqU.LCFCCR.ICoreRemoteService, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$vWqU.LCFCCR.ICoreRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server.LCFCCR$ICoreRemoteService$SetVariable(this.Service.CommunityService.Account.Identifier, "CommunityUserAccountModelVariables.HasUsedTrial"/*CommunityUserAccountModelVariables.HasUsedTrial*/, "1");
                        }, $NzoxXj ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"server","p":7429544}],"n":"","d":429540,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                    }
                    account.ActiveCodes = $.$sl.SL.Enumerable.Single$1($.$$.SCG.KeyValuePair$$$($.$$.S.Guid, $.$$.SCG.IEnumerable$$($.$$.S.String)), codes).Value;
                    ($t13 = this.UI.LCFCI$IUIClientService$ClientPage.LCFCC$IUIPageService$NavigateBack(null), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                    ($t14 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.TV.Client.Blazor\\CommunityTVApp.razor.cs", "Pay", 103), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Single$1($.$$.SCG.KeyValuePair$$$($.$$.S.Guid, $.$$.SCG.IEnumerable$$($.$$.S.String)), codes).Value);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167504154084)
            
            //--TRIMMABLE-BOUNDARY-START(171799121380)
            /*Task *//*async*/  PayGroup(/*IPaymentTier*/ tier, /*CommunityTVGroupModel*/ group)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t16, $r16;
                    let $t18, $r18;
                    let $t19, $r19;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171799121380);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*ServiceTierModel*/ let _tier = $.$cast(tier, $.$AvdQ.LCFCP.ServiceTierModel);
                    /*string*/ let paymentReference;
                    if (tier.LCFCP$IPaymentTier$Cost.Value > 0)
                    {
                        let $t15, $r15;
                        /*var*/ let exchangeRate = this.Service.TVPlayerService.AdminSettings.GetMultiplierRate(2/*MoneyUnitTypes.Dollar*/, 1/*MoneyUnitTypes.Naira*/);
                        /*Money*/ let naira = new $.$fPer.LCFCDM.Money().$ctor$3($.$fPer.LCFCDM.Money.op_Implicit($.$fPer.LCFCDM.Money.op_Multiply(tier.LCFCP$IPaymentTier$Cost, exchangeRate)), 1/*MoneyUnitTypes.Naira*/);
                        paymentReference = (($t15 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Payment.LCFCI$IUIPaymentProcessorProvider$ProcessPayment($.$clone(naira), $.$strNN(tier.LCFC$INamed$Name) + ": TV Subscription", $.$strNN($.$strNN($.$strNN($.$strNN($.$dspc(this.Service.CommunityService.Account.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString)) + "/") + $.$strNN(tier.LCFC$INamed$Name)) + "/") + $.$strNN($.$$.S.DateTime.UtcNow.ToString()), tier.LCFC$IDescribable$Description, null, "TV", null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)))).Reference;
                    }
                    else 
                    {
                        paymentReference = $.$strNN($.$strNN($.$strNN($.$strNN($.$dspc(this.Service.CommunityService.Account.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString)) + "/") + $.$strNN(tier.LCFC$INamed$Name)) + "/") + $.$strNN($.$$.S.DateTime.UtcNow.ToString());
                    }
                    /*var*/ let codes = ($t16 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$$.SCG.Dictionary$$$($.$$.S.Guid, $.$$.SCG.IEnumerable$$($.$$.S.String)), this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.Guid, $.$$.SCG.IEnumerable$$($.$$.S.String)))))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LCCTCS$ICommunityTVRemoteService$PurchaseActiveCode(group.Identifier, ($.$cast(_tier, $.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel)).Months, ($.$cast(_tier, $.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel)).Connections, paymentReference);
                    }, $oQBKOi ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.Guid, $.$$.SCG.IEnumerable$$($.$$.S.String)))).$h,"p":[{"n":"server","p":3248901}],"n":"","d":429540,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                    if (tier.LCFCP$IPaymentTier$Cost.Value === 0)
                    {
                        let $t17, $r17;
                        ($t17 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$vWqU.LCFCCR.ICoreRemoteService, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$vWqU.LCFCCR.ICoreRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server.LCFCCR$ICoreRemoteService$SetVariable(this.Service.CommunityService.Account.Identifier, "CommunityUserAccountModelVariables.HasUsedTrial"/*CommunityUserAccountModelVariables.HasUsedTrial*/, "1");
                        }, $DfzvJj ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"server","p":7429544}],"n":"","d":429540,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t17, { set $v($v) { $r17 = $v; } }) ? $r17 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t17)));
                    }
                    if (codes.ContainsKey($.$$.S.Guid.Empty))
                    {
                        group.SavedActiveCodes = $.$sl.SL.Enumerable.Concat($.$$.S.String, (group.SavedActiveCodes ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [0], null)), codes.get_Item($.$$.S.Guid.Empty));
                    }
                    ($t18 = this.UI.LCFCI$IUIClientService$ClientPage.LCFCC$IUIPageService$NavigateBack(null), ($.$$.N.AsyncResolver.IsCompleted($t18, { set $v($v) { $r18 = $v; } }) ? $r18 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t18)));
                    ($t19 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.TV.Client.Blazor\\CommunityTVApp.razor.cs", "PayGroup", 131), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(171799121380)
            
            //--TRIMMABLE-BOUNDARY-START(146029317604)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029317604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$SetOptions(new ($.$$.S.Func$$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$fPer.LCFCA$1.SchemaType, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p, /*s*/ s) =>
                {
                    return p.LCFCD$1$IPropertyDescriptor$Name === "ChannelCategories" || p.LCFCD$1$IPropertyDescriptor$Name === "ChannelCategories" || p.LCFCD$1$IPropertyDescriptor$Name === "MovieCategories" || p.LCFCD$1$IPropertyDescriptor$Name === "SeriesCategories";
                }, $MBWSNf ??= {"r":262145,"p":[{"n":"p","p":40733014},{"n":"s","p":2722134}],"n":"","d":429540,"h":0,"f":17825794}), new ($.$$.S.Action$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$fPer.LCFCA$1.SchemaType))().$ctor(this,  (/*p*/ p, /*s*/ s) =>
                {
                    p.LCFCD$1$IPropertyDescriptor$SetOption($.$hDPm.LCFCCD$1.DataListFeatures, null, 35184381210624n | 8n);
                }, $ROORml ??= {"r":65537,"p":[{"n":"p","p":40733014},{"n":"s","p":2722134}],"n":"","d":429540,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(146029317604)
            
            //--TRIMMABLE-BOUNDARY-START(158914219492)
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t20, $r20;
                    let $t31, $r31;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914219492);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (firstRender && !this.Rendering.LCFCC$IUIRenderingProvider$IsPreRendering && ($t20 = this.AuthenticationService.LCFCA$IReadOnlyAuthenticationService$GetIsLoggedIn(), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20))))
                    {
                        let $t21, $r21;
                        let $t22, $r22;
                        /*var*/ let queryParameter = $.$fPer.LCFCS$6.StringExtension.QueryStringAs($.$aImc.LCCTCS$1.TVQueryComand, new $.$spu.S.Uri().$ctor$5(this.Navigation.Uri).Query);
                        /*LivingThing.Core.Community.TV.Client.Shared.TVQueryComand?*/ let __ca1__;
                        /*string*/ let __ca2__;
                        /*var*/ let intent = ((__ca1__ = queryParameter) !== null ? ((__ca2__ = __ca1__.Intent) !== null ? $.$$.S.String.ToLower.call(__ca2__) : null) : null);
                        ($t21 = $.$vWqU.LCFCC.LoadingExtension.EnsureLoaded(this.Service, true), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21)));
                        /*var*/ let tiers = (($t22 = this.Service.Payment.ServiceTiers.Invoke(new $.$fPer.LCFCD.DataFilter().$ctor$1()), ($.$$.N.AsyncResolver.IsCompleted($t22, { set $v($v) { $r22 = $v; } }) ? $r22 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t22)))).Data;
                        /*var*/ let tier = $.$sl.SL.Enumerable.SingleOrDefault$1($.$nYKj.LCFCP.IPaymentTier$$($.$nYKj.LCFCP.PaymentCategoryType), tiers, new ($.$$.S.Func$$$($.$nYKj.LCFCP.IPaymentTier$$($.$nYKj.LCFCP.PaymentCategoryType), $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                        {
                            return ($.$cast(t, $.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel)).Slug === intent;
                        }, $Zclphf ??= {"r":262145,"p":[{"n":"t","p":$.$nYKj.LCFCP.IPaymentTier$$($.$nYKj.LCFCP.PaymentCategoryType).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                        /*var*/ let month = (($.$cast(tier, $.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel))?.Months ?? null) ?? 0;
                        if (month !== 0)
                        {
                            let $t23, $r23;
                            /*var*/ let accounts = ($t23 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$ZaYa.LCCTCM.CommunityTVAccountModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)), null), ($.$$.N.AsyncResolver.IsCompleted($t23, { set $v($v) { $r23 = $v; } }) ? $r23 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t23)));
                            /*CommunityTVAccountModel?*/ let account = null;
                            if (accounts.Data === null || !$.$sl.SL.Enumerable.Any$1($.$ZaYa.LCCTCM.CommunityTVAccountModel, accounts.Data))
                            {
                                let $t24, $r24;
                                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.TV.Common.Models.CommunityTVAccountModel>?*/ let __ca3__;
                                account = ((__ca3__ = (($t24 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$ZaYa.LCCTCM.CommunityTVAccountModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$ZaYa.LCCTCM.CommunityTVAccountModel), [ (() =>
                                {
                                    //new $.$ZaYa.LCCTCM.CommunityTVAccountModel()
                                    const $t25 = $.$ZaYa.LCCTCM.CommunityTVAccountModel;
                                    const $i25 = new $t25();
                                    $i25.$ctor$6();
                                    $i25.Name = "My TV Account";
                                    return $i25;
                                })() ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t24, { set $v($v) { $r24 = $v; } }) ? $r24 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t24)))).AsEnumerable()) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$ZaYa.LCCTCM.CommunityTVAccountModel, __ca3__) : null);
                            }
                            else 
                            {
                                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.TV.Common.Models.CommunityTVAccountModel>*/ let __ca4__;
                                account = ((__ca4__ = accounts.Data) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$ZaYa.LCCTCM.CommunityTVAccountModel, __ca4__) : null);
                            }
                            if (account !== null)
                            {
                                if (tier !== null)
                                {
                                    let $t26, $r26;
                                    let $t27, $r27;
                                    /*var*/ let codes = ($t26 = this.Pay(tier, account), ($.$$.N.AsyncResolver.IsCompleted($t26, { set $v($v) { $r26 = $v; } }) ? $r26 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t26)));
                                    ($t27 = $.$hDPm.LCFCI.ViewPresenterExtensions.MessageBox($.$hDPm.LCFCI.ViewConfiguration, this.UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Subscription Successful", false), $.$hDPm.LCFC.FragmentView.Add$1($.$$.S.Object, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Your TV Active Code is `, false), $.$hDPm.LCFC.FragmentView.Bold$3($.$$.S.Object, `${$.$strNN($.$sl.SL.Enumerable.First$1($.$$.S.String, codes))}`, (() =>
                                    {
                                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                                        const $t28 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                                        const $i28 = new $t28();
                                        $i28.$ctor$1();
                                        $i28.set_Item("class", "cl-primary fsz-30");
                                        return $i28;
                                    })())), null, null), ($.$$.N.AsyncResolver.IsCompleted($t27, { set $v($v) { $r27 = $v; } }) ? $r27 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t27)));
                                    this.Navigation.NavigateTo$2(`http://TVplayer.zoey.africa?activeCode=${$.$strNN($.$sl.SL.Enumerable.First$1($.$$.S.String, codes))}`, true);
                                }
                                else 
                                {
                                    let $t29, $r29;
                                    ($t29 = $.$hDPm.LCFCI.ViewPresenterExtensions.MessageBox($.$hDPm.LCFCI.ViewConfiguration, this.UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Error", false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Subscription not available. Perhaps you have subscribed for trial before.", false), null, null), ($.$$.N.AsyncResolver.IsCompleted($t29, { set $v($v) { $r29 = $v; } }) ? $r29 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t29)));
                                }
                            }
                            else 
                            {
                                let $t30, $r30;
                                ($t30 = $.$hDPm.LCFCI.ViewPresenterExtensions.MessageBox($.$hDPm.LCFCI.ViewConfiguration, this.UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Error", false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "No valid account available for subscription", false), null, null), ($.$$.N.AsyncResolver.IsCompleted($t30, { set $v($v) { $r30 = $v; } }) ? $r30 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t30)));
                            }
                        }
                    }
                    ($t31 = super.OnAfterRenderAsync(firstRender), ($.$$.N.AsyncResolver.IsCompleted($t31, { set $v($v) { $r31 = $v; } }) ? $r31 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t31)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(158914219492)
            
            //--TRIMMABLE-BOUNDARY-START(55835004388)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835004388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "Name", "TV");
                __builder.AddComponentParameter(2, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$ahDc.LCCCS.ApplicationExtension.GetBasePath(this.Application, this.Navigation)));
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~128/*ApplicationFeatures.ToolBarBorder*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddComponentParameter(5, "ToolBarBackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                __builder.AddComponentParameter(6, "ToolBarTextColorTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.White));
                __builder.AddComponentParameter(7, "_Class", "mawx-5 mgx-a");
                __builder.AddAttribute$3(8, "NotAuthorizedView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.IApplicationPageComponent))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$aImc.LCCTCS$1.CommunityTVAuthentication, 9);
                        __builder2.CloseComponent();
                    }, $DfDvSf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                }), $HrNDzh ??= {"r":6881395,"p":[{"n":"context","p":4599881}],"n":"","d":429540,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        if ($.$$.S.MemoryExtensions.Contains$2($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Live", "VOD", "Series", "Watch", "Favorites"], null, null)), wrap.Context.LCFCS$IApplicationPageContext$Page.LCFC$INamed$Name))
                        {
                            __builder2.AddContent$1(11, wrap.View);
                        }
                        else 
                        {
                            __builder2.OpenElement(12, "div");
                            __builder2.AddAttribute$5(13, "class", "pos-rel hv-10 wf mawx-5 mgx-a");
                            __builder2.OpenElement(14, "div");
                            __builder2.AddAttribute$5(15, "class", "pos-abs t-0 r-0 b-0 l-0 z--1");
                            __builder2.OpenComponent$1($.$aImc.LCCTCS$1.CommunityTVBackground, 16);
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(17, "\r\n                ");
                            __builder2.OpenElement(18, "div");
                            __builder2.AddAttribute$5(19, "class", "stack z-10 hf");
                            __builder2.OpenElement(20, "div");
                            __builder2.AddAttribute$5(21, "class", "bg-card hv-9 pd mgt-15 mgx corner-3 stack");
                            __builder2.AddAttribute$5(22, "style", "-backdrop-filter:blur(15px) ;");
                            __builder2.AddMarkupContent(23, "<div class=\"row mgt \"><div class=\"stack col-a\"><img src=\"_content/LivingThing.Core.Community.TV.Client.Blazor/img/logo.jpeg\" class=\"mgx-a wx-05 hx-05\">\r\n                                <span class=\"mgt\">Companion</span></div>\r\n                            <div class=\"col-10\"></div></div>\r\n                        ");
                            __builder2.OpenElement(24, "div");
                            __builder2.AddAttribute$5(25, "class", "fill scroll");
                            __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 26);
                            __builder2.AddComponentParameter(27, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                            __builder2.AddComponentParameter(28, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSL.CommunityLayoutFeatures, 31/*CommunityLayoutFeatures.Default*/ & ~12/*CommunityLayoutFeatures.PadX*/), $.$ahDc.LCCCSL.CommunityLayoutFeatures));
                            __builder2.AddAttribute$3(29, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$1(30, wrap.View);
                            }), $FMfIgc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                    }, $ErvEmd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                }), $SpAVza ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":429540,"h":0,"f":17825794}));
                __builder.AddAttribute$3(31, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/*splash*/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$aImc.LCCTCS$1.CommunityTVSplashScreen, 32);
                        __builder2.CloseComponent();
                    }, $avQBHg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                }), $AUYoQh ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":429540,"h":0,"f":17825794}));
                __builder.AddAttribute$3(33, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 34);
                    __builder2.AddComponentParameter(35, "Name", "");
                    __builder2.AddComponentParameter(36, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, (((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? 4/*ApplicationPageAccessibility.Tab*/ : 0/*ApplicationPageAccessibility.None*/) | 2/*ApplicationPageAccessibility.Sidebar*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(37, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ | 16/*ApplicationPageFeatures.TopToolBarOverlay*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(38, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(39, "Home");
                        }, $nBqWwd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $ZAAoDk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(40, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(41, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-home"/*MaterialDesignIconNames.Home*/), false));
                        }, $nQscPa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $qmTxef ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(42, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$OUNt.LCCTAS$1.HomeListing, 43);
                            __builder3.CloseComponent();
                        }, $nhfWwd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $kmNIoi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(44, "\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 45);
                    __builder2.AddComponentParameter(46, "Name", "Devices");
                    __builder2.AddComponentParameter(47, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, (((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? 4/*ApplicationPageAccessibility.Tab*/ : 0/*ApplicationPageAccessibility.None*/) | 2/*ApplicationPageAccessibility.Sidebar*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(48, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(49, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(50, "Devices");
                        }, $OXyHqh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $DlWbVi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(51, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(52, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-devices"/*MaterialDesignIconNames.Devices*/), false));
                        }, $UMDmWa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $GDXhYk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(53, "FloatingButtons", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 54);
                            __builder3.AddComponentParameter(55, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                            __builder3.AddComponentParameter(56, "Class", "mdi mdi-plus");
                            __builder3.AddComponentParameter(57, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 132178/*ButtonFeatures.FloatingButton*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder3.AddComponentParameter(58, "PageLink", "NewDevice");
                            __builder3.CloseComponent();
                        }, $WHPJLh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $zSYVAe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(59, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(60, "<h1>My Devices</h1>\r\n                    ");
                            __builder3.OpenComponent$1($.$ahDc.LCCCSP.CommunityPosts$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel), 61);
                            __builder3.AddComponentParameter(62, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                            __builder3.AddComponentParameter(63, "DataListFeatures", "DataListFeatures.Default | DataListFeatures.InfinityScroll | DataListFeatures.Delete | DataListFeatures.ServerDelete");
                            __builder3.AddComponentParameter(64, "Filter", new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)));
                            __builder3.AddAttribute$3(65, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 66);
                                __builder4.AddComponentParameter(67, "Message", "No device. Add one now");
                                __builder4.AddComponentParameter(68, "ButtonText", "New Device");
                                __builder4.AddComponentParameter(69, "ButtonLink", "NewDevice");
                                __builder4.CloseComponent();
                            }), $RGHILc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.AddComponentReferenceCapture(70, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                this.devices = $.$cast(__value, $.$ahDc.LCCCSP.CommunityPosts$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel));
                            }, $kMWeZe ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $MzqXDh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $pGLGdg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(71, "\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel), 72);
                    __builder2.AddComponentParameter(73, "Name", "NewDevice");
                    __builder2.AddComponentParameter(74, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(75, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/ & ~256/*ApplicationPageFeatures.ParameterRequired*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(76, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(77, "New Device");
                        }, $VHyzne ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $HrnSdi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(78, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(79, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-devices"/*MaterialDesignIconNames.Devices*/), false));
                        }, $FsVPsf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $MQIZXf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(80, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(81, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$ZaYa.LCCTCM.CommunityTVDeviceModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$ahDc.LCCCS$1.CommunityCreate$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$ZaYa.LCCTCM.CommunityTVDeviceModel), 82);
                                    __builder4.AddComponentParameter(83, "Target", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ZaYa.LCCTCM.CommunityTVDeviceModel, e));
                                    __builder4.AddComponentParameter(84, "OnCreated", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$ZaYa.LCCTCM.CommunityTVDeviceModel, this, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel, $.$$.STT.Task))().$ctor(this, this.DeviceCreated))));
                                    __builder4.CloseComponent();
                                }, $WZcBSk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }, $hybKBd ??= {"r":6881395,"p":[{"n":"e","p":1151749}],"n":"","d":429540,"h":0,"f":17825794}), null, true));
                        }, $BXyzEf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $oRsjta ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(85, "\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel), 86);
                    __builder2.AddComponentParameter(87, "Name", "Device");
                    __builder2.AddComponentParameter(88, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Device/${$.$strNN("***"/*RoutePath.OneOrMorePathSegment*/)}`)));
                    __builder2.AddComponentParameter(89, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(90, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(91, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(92, "@context.Data.RouteParameter.ToViewAsync(e=>e.Title)");
                        }, $lKJiBe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $ywnMll ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(93, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(94, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-devices"/*MaterialDesignIconNames.Devices*/), false));
                        }, $BniPMe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $WdqHSa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(95, "FloatingButtons", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(96, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$ZaYa.LCCTCM.CommunityTVDeviceModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 97);
                                    __builder4.AddComponentParameter(98, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                    __builder4.AddComponentParameter(99, "Class", "mdi mdi-pencil");
                                    __builder4.AddComponentParameter(100, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 132178/*ButtonFeatures.FloatingButton*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder4.AddComponentParameter(101, "PageLink", "NewDevice");
                                    __builder4.AddComponentParameter(102, "PageParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, e));
                                    __builder4.CloseComponent();
                                }, $BMQbdl ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }, $wOzANb ??= {"r":6881395,"p":[{"n":"e","p":1151749}],"n":"","d":429540,"h":0,"f":17825794}), null, true));
                        }, $NZbGqa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $gqxkCh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(103, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(104, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$ZaYa.LCCTCM.CommunityTVDeviceModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(105, "\r\n                            ");
                                    __builder4.OpenElement(106, "h1");
                                    __builder4.AddContent$4(107, "Device: ");
                                    __builder4.AddContent$4(108, e.Title);
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(109, "\r\n                            ");
                                    __builder4.AddMarkupContent(110, "<h3 class=\"mgt-0 pos-abs\">Used by</h3>\r\n                            ");
                                    __builder4.OpenComponent$1($.$mac.MAC.CascadingValue$$($.$hDPm.LCFCI.IDataFilterContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)), 111);
                                    __builder4.AddComponentParameter(112, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.IDataFilterContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), (() =>
                                    {
                                        //new $.$hDPm.LCFCI.DataFilterContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)()
                                        const $t32 = $.$hDPm.LCFCI.DataFilterContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel);
                                        const $i32 = new $t32();
                                        $i32.$ctor$2();
                                        $i32.CreateFilter = new $.$fPer.LCFCD.DataFilter().$ctor$6(e.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741837/*PostFilterTypes.HasAssociation*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null));
                                        return $i32;
                                    })()));
                                    __builder4.AddAttribute$3(113, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenComponent$1($.$ahDc.LCCCSP.CommunityPosts$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), 114);
                                        __builder5.AddComponentParameter(115, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                        __builder5.AddComponentParameter(116, "ItemName", "Account");
                                        __builder5.AddComponentParameter(117, "DataListFeatures", "DataListFeatures.Default | DataListFeatures.InfinityScroll | DataListFeatures.Delete | DataListFeatures.ServerDelete | DataListFeatures.Add | DataListFeatures.ServerAdd");
                                        __builder5.AddComponentParameter(118, "Filter", new $.$fPer.LCFCD.DataFilter().$ctor$6(e.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741837/*PostFilterTypes.HasAssociation*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)));
                                        __builder5.CloseComponent();
                                    }), $GlmXkj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(119, "\r\n                        ");
                                }, $sjMXPc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }, $yGTfBe ??= {"r":6881395,"p":[{"n":"e","p":1151749}],"n":"","d":429540,"h":0,"f":17825794}), null, true));
                        }, $jyZrWh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $MLWRXe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(120, "\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 121);
                    __builder2.AddComponentParameter(122, "Name", "Accounts");
                    __builder2.AddComponentParameter(123, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, (((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? 4/*ApplicationPageAccessibility.Tab*/ : 0/*ApplicationPageAccessibility.None*/) | 2/*ApplicationPageAccessibility.Sidebar*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(124, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(125, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(126, "Accounts");
                        }, $uawJud ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $vCwzAe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(127, "FloatingButtons", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 128);
                            __builder3.AddComponentParameter(129, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                            __builder3.AddComponentParameter(130, "Class", "mdi mdi-plus");
                            __builder3.AddComponentParameter(131, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 132178/*ButtonFeatures.FloatingButton*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder3.AddComponentParameter(132, "PageLink", "NewAccount");
                            __builder3.CloseComponent();
                        }, $QYsvSb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $yUcHrd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(133, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(134, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account-multiple"/*MaterialDesignIconNames.AccountMultiple*/), false));
                        }, $MzFaGj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $FXGYhj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(135, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(136, "<h1>My Accounts</h1>\r\n                    ");
                            __builder3.OpenComponent$1($.$ahDc.LCCCSP.CommunityPosts$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), 137);
                            __builder3.AddComponentParameter(138, "DataListFeatures", "DataListFeatures.Default | DataListFeatures.InfinityScroll | DataListFeatures.Delete | DataListFeatures.ServerDelete");
                            __builder3.AddComponentParameter(139, "Filter", new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)));
                            __builder3.AddAttribute$3(140, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 141);
                                __builder4.AddComponentParameter(142, "Message", "No viewing account. Add one now");
                                __builder4.AddComponentParameter(143, "ButtonText", "New Account");
                                __builder4.AddComponentParameter(144, "ButtonLink", "NewAccount");
                                __builder4.CloseComponent();
                            }), $KZYmzd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.AddComponentReferenceCapture(145, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                this.accounts = $.$cast(__value, $.$ahDc.LCCCSP.CommunityPosts$$($.$ZaYa.LCCTCM.CommunityTVAccountModel));
                            }, $WsgIQg ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $PTWJej ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $XSKohd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(146, "\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactory, 147);
                    __builder2.AddComponentParameter(148, "Name", "NewAccount");
                    __builder2.AddComponentParameter(149, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(150, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(151, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(152, "New Account");
                        }, $jMooOb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $sCtLbh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(153, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(154, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account"/*MaterialDesignIconNames.Account*/), false));
                        }, $xGSRBf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $bCQfdi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(155, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityCreate$$$($.$ZaYa.LCCTCM.CommunityTVGroupModel, $.$ZaYa.LCCTCM.CommunityTVAccountModel), 156);
                            __builder3.AddComponentParameter(157, "OnCreated", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$ZaYa.LCCTCM.CommunityTVAccountModel, this, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVAccountModel, $.$$.STT.Task))().$ctor(this, this.AccountCreated))));
                            __builder3.CloseComponent();
                        }, $QgvUfk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $AlEtea ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(158, "\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), 159);
                    __builder2.AddComponentParameter(160, "Name", "Account");
                    __builder2.AddComponentParameter(161, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Account/${$.$strNN("***"/*RoutePath.OneOrMorePathSegment*/)}`)));
                    __builder2.AddComponentParameter(162, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(163, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(164, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(165, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$ZaYa.LCCTCM.CommunityTVAccountModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVAccountModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e.Title;
                            }, $epgGZj ??= {"r":131073,"p":[{"n":"e","p":365317}],"n":"","d":429540,"h":0,"f":17825794}), true));
                        }, $XwsGEf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $zyVSaf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(166, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(167, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-devices"/*MaterialDesignIconNames.Devices*/), false));
                        }, $LyYTDd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $WGQLZk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(168, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(169, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$ZaYa.LCCTCM.CommunityTVAccountModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVAccountModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(170, "\r\n                            ");
                                    __builder4.OpenElement(171, "div");
                                    __builder4.AddAttribute$5(172, "class", "row");
                                    __builder4.OpenElement(173, "div");
                                    __builder4.AddAttribute$5(174, "class", "col-10");
                                    __builder4.OpenElement(175, "h1");
                                    __builder4.AddContent$4(176, "Account: ");
                                    __builder4.AddContent$4(177, e.Title);
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                    /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                                    if ((__ca1__ = e.ActiveCodes) !== null ? $.$sl.SL.Enumerable.Any$1($.$$.S.String, __ca1__) : false)
                                    {
                                        __builder4.OpenElement(178, "div");
                                        __builder4.AddAttribute$5(179, "class", "col-a stack");
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), 180);
                                        __builder4.AddComponentParameter(181, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ZaYa.LCCTCM.CommunityTVAccountModel, e));
                                        __builder4.AddComponentParameter(182, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                        __builder4.AddComponentParameter(183, "Class", "nowrap mgy-a");
                                        __builder4.AddComponentParameter(184, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 256/*ButtonFeatures.Small*/ | 4096/*ButtonFeatures.SwallowClickException*/ | 8192/*ButtonFeatures.LoadingOnClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                        __builder4.AddComponentParameter(185, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$ZaYa.LCCTCM.CommunityTVAccountModel, this, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVAccountModel, $.$$.STT.Task))().$ctor(this, this.LaunchTV))));
                                        __builder4.AddAttribute$3(186, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(187, "Launch TV");
                                        }), $GTodpe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                                        __builder4.CloseComponent();
                                        __builder4.CloseElement();
                                    }
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(188, "\r\n                            ");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCA.Accordion, 189);
                                    __builder4.AddComponentParameter(190, "Exclusive", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                                    __builder4.AddAttribute$3(191, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 192);
                                        __builder5.AddComponentParameter(193, "Class", "mgb");
                                        __builder5.AddAttribute$3(194, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                __builder6.AddMarkupContent(195, "<div class=\"row d bg-primary-01 clickable\"><div class=\"col-a bg-primary pd mgr\"><i class=\"mdi mdi-cash \"></i></div>\r\n                                            <div class=\"col-10 stack\"><h3 class=\"mgy-a\">Subscription</h3></div></div>");
                                            }, $Yimfbh ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                        }), $vMQirj ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                                        __builder5.AddAttribute$3(196, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                $.$aImc._LCCTCPC.TypeInference.CreateDataList_0($.$$.S.String, __builder6, 197, 198, 35184372092928n | 256n | 4398046511104n, 199, e.ActiveCodes, 200, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.SCG.IEnumerable$$($.$$.S.String), this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.SCG.IEnumerable$$($.$$.S.String), this, new ($.$$.S.Action$$($.$$.SCG.IEnumerable$$($.$$.S.String)))().$ctor(this,  (/*__value*/ __value) =>
                                                {
                                                    return e.ActiveCodes = __value;
                                                }, $GhqALk ??= {"r":65537,"p":[{"n":"__value","p":$.$$.SCG.IEnumerable$$($.$$.S.String).$h}],"n":"","d":429540,"h":0,"f":17825794}), e.ActiveCodes)), 201, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                {
                                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(e), "ActiveCodes"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                }, $vMyvZe ??= {"r":38797349,"n":"","d":429540,"h":0,"f":17825794})).Invoke()), 202, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.String, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.String))))().$ctor(this,  (/*_code*/ _code) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder7*/ __builder7) =>
                                                    {
                                                        __builder7.OpenElement(203, "div");
                                                        __builder7.AddAttribute$5(204, "class", "row");
                                                        __builder7.OpenElement(205, "div");
                                                        __builder7.AddAttribute$5(206, "class", "col-10");
                                                        __builder7.OpenElement(207, "h2");
                                                        __builder7.AddContent$4(208, _code.Model);
                                                        __builder7.CloseElement();
                                                        __builder7.CloseElement();
                                                        __builder7.CloseElement();
                                                        let $en33 = this.Service.TVPlayerService.StreamProviders.GetEnumerator();
                                                        while ($en33.MoveNext())
                                                        {
                                                            let provider = $en33.Current;
                                                            {
                                                                let lprovider;
                                                                if ($.$is(provider, $.$ZaYa.LCCTCS.ILoginStreamProvider, { set $v($v){ lprovider = $v; } }))
                                                                {
                                                                    __builder7.OpenComponent$1($.$hDPm.LCFCCT$3.TaskView$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)), 209);
                                                                    __builder7.AddComponentParameter(210, "Task", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)), $.$$.S.Func$$($.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))), $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))), $.$fPer.LCFCR.ReactiveObservable$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))), $.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)), $.$$.S.Func$$($.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))), $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))), $.$fPer.LCFCR.ReactiveObservable$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))).op_Implicit$2(new ($.$$.S.Func$$($.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))))().$ctor(this, ( () =>
                                                                    {
                                                                        return lprovider.LCCTCS$ILoginStreamProvider$Authenticate((() =>
                                                                        {
                                                                            //new $.$ZaYa.LCCTCS.TVLogin()
                                                                            const $t34 = $.$ZaYa.LCCTCS.TVLogin;
                                                                            const $i34 = new $t34();
                                                                            $i34.$ctor$1();
                                                                            $i34.ActiveCode = $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.String, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.String)).op_Implicit$1(_code);
                                                                            return $i34;
                                                                        })());
                                                                    }), $bRNisg ??= {"r":$.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)).$h,"n":"","d":429540,"h":0,"f":17825794}))));
                                                                    __builder7.AddAttribute$3(211, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory))))().$ctor(this, ( (/*user*/ user) =>
                                                                    {
                                                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder8*/ __builder8) =>
                                                                        {
                                                                            if ((user.Data.Item1?.LCCTCS$ILoginAuthenticationResult$StartDate ?? null) !== null)
                                                                            {
                                                                                __builder8.OpenElement(212, "div");
                                                                                __builder8.AddAttribute$5(213, "class", "row");
                                                                                __builder8.OpenElement(214, "div");
                                                                                __builder8.AddAttribute$5(215, "class", "col-a");
                                                                                __builder8.OpenElement(216, "small");
                                                                                __builder8.AddAttribute$5(217, "class", "nowrap cl-primary");
                                                                                __builder8.AddMarkupContent(218, "<i class=\"mdi mdi-calendar-start\"></i>\r\n                                                                ");
                                                                                __builder8.AddContent$3(219, user.Data.Item1.LCCTCS$ILoginAuthenticationResult$StartDate);
                                                                                __builder8.CloseElement();
                                                                                __builder8.CloseElement();
                                                                                __builder8.AddMarkupContent(220, "\r\n                                                        <div class=\"col-10\"></div>\r\n                                                        ");
                                                                                __builder8.OpenElement(221, "div");
                                                                                __builder8.AddAttribute$5(222, "class", "col-a");
                                                                                __builder8.OpenElement(223, "small");
                                                                                __builder8.AddAttribute$5(224, "class", "nowrap cl-error");
                                                                                __builder8.AddContent$3(225, (user.Data.Item1?.LCCTCS$ILoginAuthenticationResult$ExpiryDate ?? null));
                                                                                __builder8.AddMarkupContent(226, "\r\n                                                                <i class=\"mdi mdi-calendar-end\"></i>");
                                                                                __builder8.CloseElement();
                                                                                __builder8.CloseElement();
                                                                                __builder8.CloseElement();
                                                                                __builder8.AddMarkupContent(227, "\r\n                                                    ");
                                                                                __builder8.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 228);
                                                                                __builder8.AddComponentParameter(229, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, (user.Data.Item1?.LCCTCS$ILoginAuthenticationResult$Usage ?? null) ?? 0), $.$$.S.Int32));
                                                                                __builder8.AddComponentParameter(230, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Gray));
                                                                                __builder8.AddComponentParameter(231, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                                                __builder8.CloseComponent();
                                                                            }
                                                                        }, $aJGwgg ??= {"r":65537,"p":[{"n":"__builder8","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                                                    }), $Hkbugl ??= {"r":6881395,"p":[{"n":"user","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.ValueTuple$$$($.$ZaYa.LCCTCS.ILoginAuthenticationResult, $.$ZaYa.LCCTCS.IStreamProviderFactory)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                                                                    __builder7.CloseComponent();
                                                                }
                                                            }
                                                        }
                                                    }, $RvgGvf ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                                }, $coPTbg ??= {"r":6881395,"p":[{"n":"_code","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.String, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.String)).$h}],"n":"","d":429540,"h":0,"f":17825794}), 232, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder7*/ __builder7) =>
                                                {
                                                    __builder7.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 233);
                                                    __builder7.AddComponentParameter(234, "Message", "No TV subscription in this account");
                                                    __builder7.AddComponentParameter(235, "Class", "mgx mgt");
                                                    __builder7.AddComponentParameter(236, "ButtonText", "Subscribe");
                                                    __builder7.AddComponentParameter(237, "ButtonLink", "Pay");
                                                    __builder7.AddComponentParameter(238, "ButtonLinkParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, e));
                                                    __builder7.CloseComponent();
                                                }, $caNvke ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                                            }, $YXeeoh ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                        }), $XHMxHe ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                                        __builder5.CloseComponent();
                                        __builder5.AddMarkupContent(239, "\r\n                                ");
                                        __builder5.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 240);
                                        __builder5.AddComponentParameter(241, "Class", "mgb");
                                        __builder5.AddAttribute$3(242, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                __builder6.OpenElement(243, "div");
                                                __builder6.AddAttribute$5(244, "class", "row d bg-error-01 clickable");
                                                __builder6.AddMarkupContent(245, "<div class=\"col-a bg-error pd mgr\"><i class=\"mdi mdi-history \"></i></div>\r\n                                            ");
                                                __builder6.OpenElement(246, "div");
                                                __builder6.AddAttribute$5(247, "class", "col-10 stack pdr");
                                                __builder6.OpenElement(248, "h3");
                                                __builder6.AddAttribute$5(249, "class", "mgy-a");
                                                __builder6.AddContent$4(250, "View History");
                                                __builder6.OpenElement(251, "small");
                                                __builder6.AddAttribute$5(252, "class", "f-right");
                                                __builder6.AddContent$4(253, "(last ");
                                                __builder6.AddContent$3(254, $.$box(50/*CommunityTVAccountModel.OpenedStreamsCount*/, $.$$.S.Int32));
                                                __builder6.AddContent$4(255, ")");
                                                __builder6.CloseElement();
                                                __builder6.CloseElement();
                                                __builder6.CloseElement();
                                                __builder6.CloseElement();
                                            }, $YvmUwg ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                        }), $PVoobe ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                                        __builder5.AddAttribute$3(256, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                $.$aImc._LCCTCPC.TypeInference.CreateDataList_1($.$ZaYa.LCCTCS.OpenedStream, __builder6, 257, 258, "mgt wf", 259, e.OpenedStreams ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$ZaYa.LCCTCS.OpenedStream), null, [0], null), 260, 35184372092928n | 65536n | 33554432n, 261, "mgr", 262, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCS.OpenedStream, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$ZaYa.LCCTCS.OpenedStream))))().$ctor(this,  (/*opened*/ opened) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder7*/ __builder7) =>
                                                    {
                                                        __builder7.AddContent$1(263, $.$OUNt.LCCTAS$1.StreamCard.View(opened.Data.Stream, this.Service.TVPlayerService, this.Navigation, "wx-15", false, this.More($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCS.OpenedStream, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$ZaYa.LCCTCS.OpenedStream)).op_Implicit$1(opened))));
                                                    }, $yhJzwb ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                                }, $zrapNd ??= {"r":6881395,"p":[{"n":"opened","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ZaYa.LCCTCS.OpenedStream, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$ZaYa.LCCTCS.OpenedStream)).$h}],"n":"","d":429540,"h":0,"f":17825794}), 264, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder7*/ __builder7) =>
                                                {
                                                    __builder7.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 265);
                                                    __builder7.AddComponentParameter(266, "Class", "mgx-a mgy");
                                                    __builder7.AddComponentParameter(267, "Message", "No viewing history");
                                                    __builder7.CloseComponent();
                                                }, $BKsgKa ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                                            }, $yEUakh ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                        }), $ZIDDQe ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                                        __builder5.CloseComponent();
                                        __builder5.AddMarkupContent(268, "\r\n                                ");
                                        __builder5.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 269);
                                        __builder5.AddAttribute$3(270, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                __builder6.AddMarkupContent(271, "<div class=\"row d bg-secondary-01 clickable\"><div class=\"col-a bg-secondary pd mgr\"><i class=\"mdi mdi-pencil\"></i></div>\r\n                                            <div class=\"col-10 stack\"><h3 class=\"mgy-a\">Customize</h3></div></div>");
                                            }, $jHGuEj ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                        }), $aZyGBf ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                                        __builder5.AddAttribute$3(272, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                __builder6.OpenElement(273, "div");
                                                __builder6.AddAttribute$5(274, "class", "pdy");
                                                __builder6.OpenComponent$1($.$ahDc.LCCCS$1.CommunityCreate$$$($.$ZaYa.LCCTCM.CommunityTVGroupModel, $.$ZaYa.LCCTCM.CommunityTVAccountModel), 275);
                                                __builder6.AddComponentParameter(276, "Target", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ZaYa.LCCTCM.CommunityTVAccountModel, e));
                                                __builder6.AddComponentParameter(277, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                __builder6.AddComponentParameter(278, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCF$2.IFormController, this));
                                                __builder6.AddComponentParameter(279, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCS$1.CommunityCreateFeatures, 3/*CommunityCreateFeatures.Default*/ & ~1/*CommunityCreateFeatures.Wizard*/), $.$ahDc.LCCCS$1.CommunityCreateFeatures));
                                                __builder6.CloseComponent();
                                                __builder6.CloseElement();
                                            }, $GWExrb ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                        }), $DBulvh ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                                        __builder5.CloseComponent();
                                    }), $HZesUj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(280, "\r\n                        ");
                                }, $ugKDic ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }, $aHmhyc ??= {"r":6881395,"p":[{"n":"e","p":365317}],"n":"","d":429540,"h":0,"f":17825794}), null, true));
                        }, $HhDGYf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $iNJIgh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(281, "\r\n\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 282);
                    __builder2.AddComponentParameter(283, "Name", "Groups");
                    __builder2.AddComponentParameter(284, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, (((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? 4/*ApplicationPageAccessibility.Tab*/ : 0/*ApplicationPageAccessibility.None*/) | 2/*ApplicationPageAccessibility.Sidebar*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(285, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(286, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(287, "Groups");
                        }, $hxfjfe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $cojJHb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(288, "FloatingButtons", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 289);
                            __builder3.AddComponentParameter(290, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                            __builder3.AddComponentParameter(291, "Class", "mdi mdi-plus");
                            __builder3.AddComponentParameter(292, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 132178/*ButtonFeatures.FloatingButton*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder3.AddComponentParameter(293, "PageLink", "NewGroup");
                            __builder3.CloseComponent();
                        }, $JmzYmg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $YJoVvi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(294, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(295, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-group"/*MaterialDesignIconNames.Group*/), false));
                        }, $TjvLxb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $CiLbEb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(296, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(297, "<h3>My Groups</h3>\r\n                    ");
                            __builder3.OpenComponent$1($.$ahDc.LCCCSP.CommunityPosts$$($.$ZaYa.LCCTCM.CommunityTVGroupModel), 298);
                            __builder3.AddComponentParameter(299, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                            __builder3.AddComponentParameter(300, "DataListFeatures", "DataListFeatures.Default | DataListFeatures.InfinityScroll | DataListFeatures.Delete");
                            __builder3.AddComponentParameter(301, "Filter", new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)));
                            __builder3.AddAttribute$3(302, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 303);
                                __builder4.AddComponentParameter(304, "Message", "No group. Add one now");
                                __builder4.AddComponentParameter(305, "ButtonText", "New Group");
                                __builder4.AddComponentParameter(306, "ButtonLink", "NewGroup");
                                __builder4.CloseComponent();
                            }), $RhGJxk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.AddComponentReferenceCapture(307, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                this.groups = $.$cast(__value, $.$ahDc.LCCCSP.CommunityPosts$$($.$ZaYa.LCCTCM.CommunityTVGroupModel));
                            }, $AggLsc ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $svxKFd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $CagiXf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(308, "\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$ZaYa.LCCTCM.CommunityTVGroupModel), 309);
                    __builder2.AddComponentParameter(310, "Name", "NewGroup");
                    __builder2.AddComponentParameter(311, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(312, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/ & ~256/*ApplicationPageFeatures.ParameterRequired*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(313, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(314, "New Group");
                        }, $jvYKfb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $AHtonf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(315, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(316, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-home-group-plus"/*MaterialDesignIconNames.HomeGroupPlus*/), false));
                        }, $YiLgVd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $YpIMWk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(317, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(318, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$ZaYa.LCCTCM.CommunityTVGroupModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVGroupModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$ahDc.LCCCS$1.CommunityCreate$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$ZaYa.LCCTCM.CommunityTVGroupModel), 319);
                                    __builder4.AddComponentParameter(320, "Target", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ZaYa.LCCTCM.CommunityTVGroupModel, e));
                                    __builder4.AddComponentParameter(321, "OnCreated", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$ZaYa.LCCTCM.CommunityTVGroupModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$ZaYa.LCCTCM.CommunityTVGroupModel, this, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVGroupModel, $.$$.STT.Task))().$ctor(this, this.GroupCreated))));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(322, "\r\n");
                                }, $KwXDif ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }, $OSjtDd ??= {"r":6881395,"p":[{"n":"e","p":1544965}],"n":"","d":429540,"h":0,"f":17825794}), null, true));
                        }, $khSsKa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $RuMvRg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(323, "\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$ZaYa.LCCTCM.CommunityTVGroupModel), 324);
                    __builder2.AddComponentParameter(325, "Name", "Group");
                    __builder2.AddComponentParameter(326, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Group/${$.$strNN("***"/*RoutePath.OneOrMorePathSegment*/)}`)));
                    __builder2.AddComponentParameter(327, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(328, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(329, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(330, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$ZaYa.LCCTCM.CommunityTVGroupModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVGroupModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e.Title;
                            }, $yGDPKd ??= {"r":131073,"p":[{"n":"e","p":1544965}],"n":"","d":429540,"h":0,"f":17825794}), true));
                        }, $Kvgpwe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $KikDUj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(331, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(332, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-group"/*MaterialDesignIconNames.Group*/), false));
                        }, $rwRZyk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $hxUPid ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(333, "FloatingButtons", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(334, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$ZaYa.LCCTCM.CommunityTVGroupModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVGroupModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 335);
                                    __builder4.AddComponentParameter(336, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                    __builder4.AddComponentParameter(337, "Class", "mdi mdi-pencil");
                                    __builder4.AddComponentParameter(338, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 132178/*ButtonFeatures.FloatingButton*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder4.AddComponentParameter(339, "PageLink", "NewGroup");
                                    __builder4.AddComponentParameter(340, "PageParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, e));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(341, "\r\n");
                                }, $Xjenwb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }, $bFVgKh ??= {"r":6881395,"p":[{"n":"e","p":1544965}],"n":"","d":429540,"h":0,"f":17825794}), null, true));
                        }, $uLMKFf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $vxTyee ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(342, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(343, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$ZaYa.LCCTCM.CommunityTVGroupModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVGroupModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(344, "\r\n                            ");
                                    __builder4.OpenElement(345, "div");
                                    __builder4.AddAttribute$5(346, "class", "row");
                                    __builder4.OpenElement(347, "div");
                                    __builder4.AddAttribute$5(348, "class", "col-10");
                                    __builder4.OpenElement(349, "h1");
                                    __builder4.AddContent$4(350, "Group: ");
                                    __builder4.AddContent$4(351, e.Title);
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(352, "\r\n                                ");
                                    __builder4.OpenElement(353, "div");
                                    __builder4.AddAttribute$5(354, "class", "col-a stack");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 355);
                                    __builder4.AddComponentParameter(356, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                    __builder4.AddComponentParameter(357, "Class", "mgy-a");
                                    __builder4.AddComponentParameter(358, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 256/*ButtonFeatures.Small*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder4.AddComponentParameter(359, "PageLink", "PayGroup");
                                    __builder4.AddComponentParameter(360, "PageParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, e));
                                    __builder4.AddAttribute$3(361, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.AddMarkupContent(362, "\r\n                                        Subscribe\r\n                                    ");
                                    }), $ozHEwj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(363, "\r\n                            ");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCA.Accordion, 364);
                                    __builder4.AddComponentParameter(365, "Exclusive", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                                    __builder4.AddAttribute$3(366, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 367);
                                        __builder5.AddAttribute$3(368, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                __builder6.AddMarkupContent(369, "<div class=\"row d bg-primary-01 clickable\"><div class=\"col-a bg-primary pd mgr\"><i class=\"mdi mdi-account-multiple\"></i></div>\r\n                                            <div class=\"col-10 stack\"><h3 class=\"mgy-a\">Accounts</h3></div></div>");
                                            }, $wNnARc ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                        }), $hpMDMg ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                                        __builder5.AddAttribute$3(370, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                __builder6.OpenComponent$1($.$mac.MAC.CascadingValue$$($.$hDPm.LCFCI.IDataFilterContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)), 371);
                                                __builder6.AddComponentParameter(372, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.IDataFilterContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), (() =>
                                                {
                                                    //new $.$hDPm.LCFCI.DataFilterContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)()
                                                    const $t35 = $.$hDPm.LCFCI.DataFilterContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel);
                                                    const $i35 = new $t35();
                                                    $i35.$ctor$2();
                                                    $i35.DeleteFilter = new $.$fPer.LCFCD.DataFilter().$ctor$12(e.Identifier);
                                                    return $i35;
                                                })()));
                                                __builder6.AddAttribute$3(373, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder7*/ __builder7) =>
                                                {
                                                    __builder7.OpenComponent$1($.$ahDc.LCCCSP.CommunityPosts$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), 374);
                                                    __builder7.AddComponentParameter(375, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                    __builder7.AddComponentParameter(376, "Class", "mgy");
                                                    __builder7.AddComponentParameter(377, "Filter", new $.$fPer.LCFCD.DataFilter().$ctor$6(e.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)));
                                                    __builder7.AddComponentParameter(378, "DataListFeatures", "DataListFeatures.Default|DataListFeatures.Add|DataListFeatures.ServerAdd|DataListFeatures.Delete|DataListFeatures.ServerDelete");
                                                    __builder7.CloseComponent();
                                                }), $wZNzAb ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                                                __builder6.CloseComponent();
                                            }, $qzFXWg ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                        }), $TvawMc ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                                        __builder5.CloseComponent();
                                        /*System.Collections.Generic.IEnumerable<string>?*/ let __ca2__;
                                        if ((__ca2__ = e.SavedActiveCodes) !== null ? $.$sl.SL.Enumerable.Any$1($.$$.S.String, __ca2__) : false)
                                        {
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 379);
                                            __builder5.AddAttribute$3(380, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddMarkupContent(381, "<div class=\"row d bg-error-01 clickable\"><div class=\"col-a bg-error pd mgr\"><i class=\"mdi mdi-account \"></i></div>\r\n                                            <div class=\"col-10 stack\"><h3 class=\"mgy-a\">Saved Codes</h3></div></div>");
                                                }, $iYMOxe ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                            }), $CeLEqi ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                                            __builder5.AddAttribute$3(382, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    let $en36 = e.SavedActiveCodes.SCG$IEnumerable$$$GetEnumerator();
                                                    while ($en36.SC$1$IEnumerator$MoveNext())
                                                    {
                                                        let _code = $en36.SCG$IEnumerator$$$Current;
                                                        {
                                                            __builder6.OpenElement(383, "h2");
                                                            __builder6.AddContent$4(384, _code);
                                                            __builder6.CloseElement();
                                                        }
                                                    }
                                                }, $LKpQek ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                            }), $jaGOIc ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                        }
                                    }), $ZqWnnl ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(385, "\r\n                        ");
                                }, $szVeQc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }, $UtcOYb ??= {"r":6881395,"p":[{"n":"e","p":1544965}],"n":"","d":429540,"h":0,"f":17825794}), null, true));
                        }, $dsixjg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $UtqxZc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(386, "\r\n\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), 387);
                    __builder2.AddComponentParameter(388, "Name", "Pay");
                    __builder2.AddComponentParameter(389, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(390, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(391, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(392, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$ZaYa.LCCTCM.CommunityTVAccountModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVAccountModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e.Title;
                            }, $hrknhf ??= {"r":131073,"p":[{"n":"e","p":365317}],"n":"","d":429540,"h":0,"f":17825794}), true));
                        }, $sDGQAd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $GTCFea ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(393, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(394, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-devices"/*MaterialDesignIconNames.Devices*/), false));
                        }, $QRyhXb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $AyUaug ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(395, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel))))().$ctor(this, ( (/*payAccount*/ payAccount) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(396, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$ZaYa.LCCTCM.CommunityTVAccountModel, payAccount.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVAccountModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(397, "\r\n                            ");
                                    __builder4.OpenElement(398, "h1");
                                    __builder4.AddContent$4(399, "Renew Account: ");
                                    __builder4.AddContent$4(400, e.Title);
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(401, "\r\n                            ");
                                    __builder4.OpenComponent$1($.$dgLE.LCPCS$1.ChooseServiceTier, 402);
                                    __builder4.AddComponentParameter(403, "ServiceTierProvider", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$nYKj.LCFCP.IPaymentTierProvider, this.Service.Payment));
                                    __builder4.AddAttribute$3(404, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$nYKj.LCFCP.IPaymentTier)))().$ctor(this, ( (/*tier*/ tier) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            if (tier.Model !== null)
                                            {
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$nYKj.LCFCP.IPaymentTier), 405);
                                                __builder5.AddComponentParameter(406, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$nYKj.LCFCP.IPaymentTier, tier.Model));
                                                __builder5.AddComponentParameter(407, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$nYKj.LCFCP.IPaymentTier), $.$mac.MAC.EventCallback.Factory.Create$10($.$nYKj.LCFCP.IPaymentTier, this, new ($.$$.S.Func$$$($.$nYKj.LCFCP.IPaymentTier, $.$$.STT.Task))().$ctor(this,  (/*v*/ v) =>
                                                {
                                                    return this.Pay(v, e);
                                                }, $jnlZsh ??= {"r":178454529,"p":[{"n":"v","p":739096}],"n":"","d":429540,"h":0,"f":17825794}))));
                                                __builder5.AddComponentParameter(408, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 4096/*ButtonFeatures.SwallowClickException*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                                __builder5.AddComponentParameter(409, "Class", "d-block mgb-a fw-bold");
                                                __builder5.AddComponentParameter(410, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                __builder5.AddAttribute$3(411, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddMarkupContent(412, "\r\n                                        Pay ");
                                                    __builder6.AddContent$3(413, tier.Model.LCFCP$IPaymentTier$Cost);
                                                }), $MGeNQd ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                                                __builder5.CloseComponent();
                                            }
                                        }, $RxNRBk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                    }), $KZFrJd ??= {"r":6881395,"p":[{"n":"tier","p":$.$hDPm.LCFCI.ContainerContext$$($.$nYKj.LCFCP.IPaymentTier).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(414, "\r\n                        ");
                                }, $lwNjhl ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }, $EgpwLe ??= {"r":6881395,"p":[{"n":"e","p":365317}],"n":"","d":429540,"h":0,"f":17825794}), null, true));
                        }, $keGxog ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $XQBjDc ??= {"r":6881395,"p":[{"n":"payAccount","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVAccountModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(415, "\r\n\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$ZaYa.LCCTCM.CommunityTVGroupModel), 416);
                    __builder2.AddComponentParameter(417, "Name", "PayGroup");
                    __builder2.AddComponentParameter(418, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(419, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(420, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(421, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$ZaYa.LCCTCM.CommunityTVGroupModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVGroupModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e.Title;
                            }, $IKmqFd ??= {"r":131073,"p":[{"n":"e","p":1544965}],"n":"","d":429540,"h":0,"f":17825794}), true));
                        }, $FZotPe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $GwOfca ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(422, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(423, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-devices"/*MaterialDesignIconNames.Devices*/), false));
                        }, $yCCELd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $Odseti ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(424, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel))))().$ctor(this, ( (/*payGroup*/ payGroup) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(425, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$ZaYa.LCCTCM.CommunityTVGroupModel, payGroup.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$ZaYa.LCCTCM.CommunityTVGroupModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(426, "\r\n                            ");
                                    __builder4.OpenElement(427, "h1");
                                    __builder4.AddContent$4(428, "Subscribe Group: ");
                                    __builder4.AddContent$4(429, e.Title);
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(430, "\r\n                            ");
                                    __builder4.OpenComponent$1($.$dgLE.LCPCS$1.ChooseServiceTier, 431);
                                    __builder4.AddComponentParameter(432, "ServiceTierProvider", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$nYKj.LCFCP.IPaymentTierProvider, this.Service.Payment));
                                    __builder4.AddComponentParameter(433, "DataTag", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, e));
                                    __builder4.AddAttribute$3(434, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$nYKj.LCFCP.IPaymentTier)))().$ctor(this, ( (/*tier*/ tier) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            if (tier.Model !== null)
                                            {
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$nYKj.LCFCP.IPaymentTier), 435);
                                                __builder5.AddComponentParameter(436, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$nYKj.LCFCP.IPaymentTier, tier.Model));
                                                __builder5.AddComponentParameter(437, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$nYKj.LCFCP.IPaymentTier), $.$mac.MAC.EventCallback.Factory.Create$10($.$nYKj.LCFCP.IPaymentTier, this, new ($.$$.S.Func$$$($.$nYKj.LCFCP.IPaymentTier, $.$$.STT.Task))().$ctor(this,  (/*v*/ v) =>
                                                {
                                                    return this.PayGroup(v, e);
                                                }, $qRsjVf ??= {"r":178454529,"p":[{"n":"v","p":739096}],"n":"","d":429540,"h":0,"f":17825794}))));
                                                __builder5.AddComponentParameter(438, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 4096/*ButtonFeatures.SwallowClickException*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                                __builder5.AddComponentParameter(439, "Class", "d-block mgb-a fw-bold");
                                                __builder5.AddComponentParameter(440, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                __builder5.AddAttribute$3(441, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddMarkupContent(442, "\r\n                                        Pay ");
                                                    __builder6.AddContent$3(443, tier.Model.LCFCP$IPaymentTier$Cost);
                                                }), $LxraBc ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                                                __builder5.CloseComponent();
                                            }
                                        }, $fxxEmg ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                                    }), $TIZTpc ??= {"r":6881395,"p":[{"n":"tier","p":$.$hDPm.LCFCI.ContainerContext$$($.$nYKj.LCFCP.IPaymentTier).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(444, "\r\n                        ");
                                }, $MakJkj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }, $lpZzkf ??= {"r":6881395,"p":[{"n":"e","p":1544965}],"n":"","d":429540,"h":0,"f":17825794}), null, true));
                        }, $URauvc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $fRLFjl ??= {"r":6881395,"p":[{"n":"payGroup","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$ZaYa.LCCTCM.CommunityTVGroupModel)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    /*LivingThing.Core.Community.TV.Common.Models.CommunityTVAccountModel?*/ let __ca3__;
                    /*System.Collections.Generic.IEnumerable<string>?*/ let __ca4__;
                    if ((__ca3__ = this.Service.TVPlayerService.Account) !== null ? ((__ca4__ = __ca3__.ActiveCodes) !== null ? $.$sl.SL.Enumerable.Any$1($.$$.S.String, __ca4__) : false) : false)
                    {
                        __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 445);
                        __builder2.AddComponentParameter(446, "Name", "Watch");
                        __builder2.AddComponentParameter(447, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("IPTV")));
                        __builder2.AddComponentParameter(448, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/ | (((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? 4/*ApplicationPageAccessibility.Tab*/ : 0/*ApplicationPageAccessibility.None*/)), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                        __builder2.AddComponentParameter(449, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                        __builder2.AddAttribute$3(450, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$4(451, "Watch");
                            }, $oskdib ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                        }), $iwQjOi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(452, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$1(453, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-youtube"/*TVPlayerServices.LiveTVIcon*/), false));
                            }, $obsKpd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                        }), $TdYyCf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(454, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$OUNt.LCCTAP.Index, 455);
                                __builder3.AddComponentParameter(456, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$OUNt.LCCTAS$1.TVFeatures, 3/*TVFeatures.Default*/ & ~1/*TVFeatures.ToolBar*/), $.$OUNt.LCCTAS$1.TVFeatures));
                                __builder3.CloseComponent();
                            }, $caaqhl ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                        }), $PhfYdj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(457, "ChildPages", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactory, 458);
                            __builder3.AddComponentParameter(459, "Name", "Live");
                            __builder3.AddComponentParameter(460, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("IPTV/Live")));
                            __builder3.AddComponentParameter(461, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                            __builder3.AddAttribute$3(462, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$4(463, "LiveTV");
                                }, $nCyEeg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }), $qbtvZk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(464, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$1(465, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-youtube"/*TVPlayerServices.LiveTVIcon*/), false));
                                }, $TYJeSk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }), $cQlwvb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(466, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(467, "LivingThing.Core.Community.TV.App.Pages.XtreamLiveTV");
                                    __builder4.AddAttribute$5(468, "Features", "TVFeatures.Default & ~TVFeatures.ToolBar");
                                    __builder4.CloseElement();
                                }, $oSFiWj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }), $EUADvh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(469, "\r\n                        ");
                            __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactory, 470);
                            __builder3.AddComponentParameter(471, "Name", "VOD");
                            __builder3.AddComponentParameter(472, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("IPTV/VOD")));
                            __builder3.AddComponentParameter(473, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                            __builder3.AddAttribute$3(474, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$4(475, "VOD");
                                }, $JVozdj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }), $daAjIa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(476, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$1(477, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-video"/*TVPlayerServices.VODIcon*/), false));
                                }, $nqkiYf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }), $Xpjvml ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(478, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(479, "LivingThing.Core.Community.TV.App.Pages.XtreamVOD");
                                    __builder4.AddAttribute$5(480, "Features", "TVFeatures.Default & ~TVFeatures.ToolBar");
                                    __builder4.CloseElement();
                                }, $cmAoog ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }), $dZQxxd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(481, "\r\n                        ");
                            __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactory, 482);
                            __builder3.AddComponentParameter(483, "Name", "Series");
                            __builder3.AddComponentParameter(484, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("IPTV/Series")));
                            __builder3.AddComponentParameter(485, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                            __builder3.AddAttribute$3(486, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$4(487, "Series");
                                }, $rRbnTi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }), $NpLfdb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(488, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$1(489, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-movie-roll"/*TVPlayerServices.SeriesIcon*/), false));
                                }, $iRiTob ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }), $VkTTYk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(490, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(491, "LivingThing.Core.Community.TV.App.Pages.XtreamSeries");
                                    __builder4.AddAttribute$5(492, "Features", "TVFeatures.Default & ~TVFeatures.ToolBar");
                                    __builder4.CloseElement();
                                }, $eiWVzj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }), $YPgXCd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(493, "\r\n                        ");
                            __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactory, 494);
                            __builder3.AddComponentParameter(495, "Name", "Favorites");
                            __builder3.AddComponentParameter(496, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("IPTV/Favorites")));
                            __builder3.AddComponentParameter(497, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                            __builder3.AddAttribute$3(498, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$4(499, "Series");
                                }, $omYUxg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }), $fsfUKh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(500, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$1(501, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-heart"/*MaterialDesignIconNames.Heart*/), false));
                                }, $jVwimh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }), $NcHNja ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(502, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$OUNt.LCCTAP.Favorites, 503);
                                    __builder4.AddComponentParameter(504, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$OUNt.LCCTAS$1.TVFeatures, 3/*TVFeatures.Default*/ & ~1/*TVFeatures.ToolBar*/), $.$OUNt.LCCTAS$1.TVFeatures));
                                    __builder4.CloseComponent();
                                }, $BCtRsd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                            }), $NHzota ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }), $oELlTd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 505);
                    __builder2.AddComponentParameter(506, "Name", "Help");
                    __builder2.AddComponentParameter(507, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~15/*CommunityLayoutFeatures.Pad*/, null, null, true);
                    }), $OzRTJh ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(508, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(509, "Help");
                        }, $CGrqvj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $LRWXqg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(510, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(511, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-help"/*MaterialDesignIconNames.Help*/), false));
                        }, $fiywCf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $IcRaLe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(512, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityAppIntro, 513);
                            __builder3.AddComponentParameter(514, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN((/*true ?*/ "mgx--5"/* : ""*/))} bdt`));
                            __builder3.AddAttribute$3(515, "SiteMap", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(516, "\r\n                            TV Help\r\n                        ");
                            }), $EJvvdd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(517, "\r\n                    ");
                            __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityApplicationHelp, 518);
                            __builder3.AddComponentParameter(519, "Application", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCS.ICommunityClientApplication, this.Application));
                            __builder3.CloseComponent();
                        }, $VVZEsh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
                    }), $MNqJcj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":429540,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $Kdvnyj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":429540,"h":0,"f":17825794}));
                __builder.AddComponentReferenceCapture(520, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.application = $.$cast(__value, $.$lJUR.LCFCS.Application);
                }, $LCVqwh ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":429540,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(55835004388)
            
            //--TRIMMABLE-BOUNDARY-START(150324284900)
            /*RenderFragment */ More(/*OpenedStream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324284900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(521, "div");
                    __builder2.AddAttribute$5(522, "class", "text-center fsz-small");
                    __builder2.AddContent$3(523, stream.Date);
                    __builder2.CloseElement();
                }, $GXnEkd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":429540,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(150324284900)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4335831382)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptorModifier.ModifyDescriptor(LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptorModifierBuilder)
            LCFCD$1$IPropertyDescriptorModifier$ModifyDescriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4335831382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ModifyDescriptor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4335831382)
            
            //--TRIMMABLE-BOUNDARY-START(30065200612)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065200612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065200612)
            
            //--TRIMMABLE-BOUNDARY-START(30065200612)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(30065200612)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(154619252196)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(154619252196)
                
                //--TRIMMABLE-BOUNDARY-START(180389055972)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(180389055972)
                
                //--TRIMMABLE-BOUNDARY-START(47245069796)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(47245069796)
                
                //--TRIMMABLE-BOUNDARY-START(176094088676)
                this.Rendering = null;
                //--TRIMMABLE-BOUNDARY-END(176094088676)
                
                //--TRIMMABLE-BOUNDARY-START(236223630820)
                this.UI = null;
                //--TRIMMABLE-BOUNDARY-END(236223630820)
                
                //--TRIMMABLE-BOUNDARY-START(51540037092)
                this.AuthenticationService = null;
                //--TRIMMABLE-BOUNDARY-END(51540037092)
                
            }
            static $h = 429540;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(163209186788),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784677348,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 429540,
      "h": 163209186788,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209186788),
//--TRIMMABLE-BOUNDARY-START(154619252196),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194742756,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206158859748,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 429540,
      "h": 154619252196,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619252196),
//--TRIMMABLE-BOUNDARY-START(180389055972),
    {
      "p": 691684,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964546532,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338728932,
        "f": 83886081
      },
      "n": "Service",
      "d": 429540,
      "h": 180389055972,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180389055972),
//--TRIMMABLE-BOUNDARY-START(47245069796),
    {
      "p": 560612,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014873572,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188978990564,
        "f": 83886081
      },
      "n": "Application",
      "d": 429540,
      "h": 47245069796,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245069796),
//--TRIMMABLE-BOUNDARY-START(176094088676),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374611940,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214748794340,
        "f": 83886081
      },
      "n": "Rendering",
      "d": 429540,
      "h": 176094088676,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176094088676),
//--TRIMMABLE-BOUNDARY-START(236223630820),
    {
      "p": 65492650,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554481124,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928663524,
        "f": 83886081
      },
      "n": "UI",
      "d": 429540,
      "h": 236223630820,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236223630820),
//--TRIMMABLE-BOUNDARY-START(51540037092),
    {
      "p": 1655170,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604808164,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197568925156,
        "f": 83886081
      },
      "n": "AuthenticationService",
      "d": 429540,
      "h": 51540037092,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540037092)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137439383012),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 429540,
      "h": 137439383012,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137439383012),
//--TRIMMABLE-BOUNDARY-START(34360167908),
    {
      "r": 178454529,
      "p": [
        {
          "n": "account",
          "p": 365317
        }
      ],
      "n": "AccountCreated",
      "d": 429540,
      "h": 34360167908,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(34360167908),
//--TRIMMABLE-BOUNDARY-START(128849448420),
    {
      "r": 178454529,
      "p": [
        {
          "n": "group",
          "p": 1544965
        }
      ],
      "n": "GroupCreated",
      "d": 429540,
      "h": 128849448420,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(128849448420),
//--TRIMMABLE-BOUNDARY-START(60129971684),
    {
      "r": 178454529,
      "p": [
        {
          "n": "device",
          "p": 1151749
        }
      ],
      "n": "DeviceCreated",
      "d": 429540,
      "h": 60129971684,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(60129971684),
//--TRIMMABLE-BOUNDARY-START(141734350308),
    {
      "r": 178454529,
      "p": [
        {
          "n": "usingAccount",
          "p": 365317
        }
      ],
      "n": "LaunchTV",
      "d": 429540,
      "h": 141734350308,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(141734350308),
//--TRIMMABLE-BOUNDARY-START(167504154084),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$$.S.String)).$h,
      "p": [
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "account",
          "p": 365317
        }
      ],
      "n": "Pay",
      "d": 429540,
      "h": 167504154084,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(167504154084),
//--TRIMMABLE-BOUNDARY-START(171799121380),
    {
      "r": 178454529,
      "p": [
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "group",
          "p": 1544965
        }
      ],
      "n": "PayGroup",
      "d": 429540,
      "h": 171799121380,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(171799121380),
//--TRIMMABLE-BOUNDARY-START(146029317604),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 429540,
      "h": 146029317604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029317604),
//--TRIMMABLE-BOUNDARY-START(158914219492),
    {
      "r": 178454529,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": 429540,
      "h": 158914219492,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(158914219492),
//--TRIMMABLE-BOUNDARY-START(55835004388),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 429540,
      "h": 55835004388,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55835004388),
//--TRIMMABLE-BOUNDARY-START(150324284900),
    {
      "r": 6881395,
      "p": [
        {
          "n": "stream",
          "p": 5149445
        }
      ],
      "n": "More",
      "d": 429540,
      "h": 150324284900,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(150324284900)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950102500),
    {
      "t": 733257,
      "n": "application",
      "d": 429540,
      "h": 42950102500,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950102500),
//--TRIMMABLE-BOUNDARY-START(38655135204),
    {
      "t": $.$ahDc.LCCCSP.CommunityPosts$$($.$ZaYa.LCCTCM.CommunityTVAccountModel).$h,
      "n": "accounts",
      "d": 429540,
      "h": 38655135204,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655135204),
//--TRIMMABLE-BOUNDARY-START(133144415716),
    {
      "t": $.$ahDc.LCCCSP.CommunityPosts$$($.$ZaYa.LCCTCM.CommunityTVGroupModel).$h,
      "n": "groups",
      "d": 429540,
      "h": 133144415716,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(133144415716),
//--TRIMMABLE-BOUNDARY-START(64424938980),
    {
      "t": $.$ahDc.LCCCSP.CommunityPosts$$($.$ZaYa.LCCTCM.CommunityTVDeviceModel).$h,
      "n": "devices",
      "d": 429540,
      "h": 64424938980,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64424938980)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065200612),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 429540,
      "h": 30065200612,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065200612)
  ],
  "h": 429540
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCF$2.IFormFieldEditPropertyController, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$hDPm.LCFCCF$2.IFormController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Pages.CommunityTVApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Pages${separator}CommunityTVApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(429540)
        
        

        //--TRIMMABLE-BOUNDARY-START(626148)
        $asm.$cls(`$aImc.LCCTCS.CommunityTVPaymentServiceProvider`, ($self) => class CommunityTVPaymentServiceProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(94489906660)
            /*TVPlayerServices*/ TVService = null;
            //--TRIMMABLE-BOUNDARY-END(94489906660)
            
            //--TRIMMABLE-BOUNDARY-START(8590560740)
            /*CommunityTVService*/ AppService = null;
            //--TRIMMABLE-BOUNDARY-END(8590560740)
            
            //--TRIMMABLE-BOUNDARY-START(77310037476)
            /*bool*/ isAdmin = false;
            //--TRIMMABLE-BOUNDARY-END(77310037476)
            
            //--TRIMMABLE-BOUNDARY-START(4295593444)
            $ctor$1(/*TVPlayerServices*/ tvservice, /*CommunityTVService*/ appService, /*bool*/ admin)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295593444);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.TVService = tvservice;
                    this.AppService = appService;
                    this.isAdmin = admin;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295593444)
            
            //--TRIMMABLE-BOUNDARY-START(12885528036)
            /*PaymentCategoryType */ get Category()
            {
                return 2/*PaymentCategoryType.Entertainment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(12885528036)
            
            //--TRIMMABLE-BOUNDARY-START(85899972068)
            /*Pager<IPaymentTier<PaymentCategoryType>> */ get ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130168292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.Cast$1($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel, $.$nYKj.LCFCP.IPaymentTier$$($.$nYKj.LCFCP.PaymentCategoryType), $.$fPer.LCFCD.Paging.GetPager($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel, this.TVService.AdminSettings.PremiumServiceTiers, new ($.$$.S.Func$$$$($.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel), $.$fPer.LCFCD.DataFilter, $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel))))().$ctor(this, /*async*/  (/*tiers*/ tiers, /*filter*/ filter) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel)), $.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel), async ($asnycContext) => 
                    {
                        if (!this.isAdmin)
                        {
                            let $t1, $r1;
                            /*var*/ let usedTrial = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$vWqU.LCFCCR.ICoreRemoteService, $.$$.S.String, this.TVService.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$vWqU.LCFCCR.ICoreRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)))().$ctor(this,  (/*server*/ server) =>
                            {
                                return server.LCFCCR$ICoreRemoteService$GetVariable(this.AppService.CommunityService.Account.Identifier, "CommunityUserAccountModelVariables.HasUsedTrial"/*CommunityUserAccountModelVariables.HasUsedTrial*/);
                            }, $rLEGvg ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)).$h,"p":[{"n":"server","p":7429544}],"n":"","d":626148,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                            /*bool*/ let hasUsedTrial = !$.$$.S.String.IsNullOrEmpty(usedTrial);
                            if (hasUsedTrial)
                            {
                                tiers = $.$sl.SL.Enumerable.Skip($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel, tiers, 1);
                            }
                        }
                        let group;
                        if ($.$is(filter.Tag, $.$ZaYa.LCCTCM.CommunityTVGroupModel, { set $v($v){ group = $v; } }))
                        {
                            let $t2, $r2;
                            /*var*/ let counts = ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$LCOv.LCFCP.IPostRemoteService, $.$$.S.Int32, this.TVService.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$LCOv.LCFCP.IPostRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.Int32)))().$ctor(this,  (/*server*/ server) =>
                            {
                                return server.LCFCP$IPostRemoteService$CountChildren(new $.$fPer.LCFCD.DataFilter().$ctor$12(group.Identifier).WithAttribute$2($.$LCOv.LCFCPM$1.PostTypes, 5377/*PostTypes.TVAccount*/, 0));
                            }, $QCTjvc ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.Int32)).$h,"p":[{"n":"server","p":3205556}],"n":"","d":626148,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Where($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel, tiers, new ($.$$.S.Func$$$($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel, $.$$.S.Boolean))().$ctor(this,  (/**/ t) =>
                            {
                                return t.Connections >= counts;
                            }, $TzJICb ??= {"r":262145,"p":[{"n":"t","p":6591237}],"n":"","d":626148,"h":0,"f":17825794})));
                        }
                        else 
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Where($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel, tiers, new ($.$$.S.Func$$$($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.Connections === 1;
                            }, $CwTJde ??= {"r":262145,"p":[{"n":"t","p":6591237}],"n":"","d":626148,"h":0,"f":17825794})));
                        }
                    });
                }, $ojkiYe ??= {"r":$.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel)).$h,"p":[{"n":"tiers","p":$.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS$1.CommunityTVServiceTierModel).$h},{"n":"filter","p":9734486}],"n":"","d":626148,"h":0,"f":17829890})));
            }
            //--TRIMMABLE-BOUNDARY-END(85899972068)
            
            //--TRIMMABLE-BOUNDARY-START(81605004772)
            /*string */ get Name()
            {
                return "TV";
            }
            //--TRIMMABLE-BOUNDARY-END(81605004772)
            
            //--TRIMMABLE-BOUNDARY-START(90194939364)
            /*string */ get Title()
            {
                return "TV";
            }
            //--TRIMMABLE-BOUNDARY-END(90194939364)
            
            //--TRIMMABLE-BOUNDARY-START(17180495332)
            /*string */ get Description()
            {
                return "Watch live TVs, movies and series";
            }
            //--TRIMMABLE-BOUNDARY-END(17180495332)
            
            //--TRIMMABLE-BOUNDARY-START(73015070180)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-youtube-tv"/*MaterialDesignIconNames.YoutubeTv*/);
            }
            //--TRIMMABLE-BOUNDARY-END(73015070180)
            
            //--TRIMMABLE-BOUNDARY-START(12885968664)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider<LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType>.Category.get
            get LCFCP$IPaymentTierProvider$$$Category()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296034072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Category;
            }
            //--TRIMMABLE-BOUNDARY-END(12885968664)
            
            //--TRIMMABLE-BOUNDARY-START(21475903256)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider<LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType>.ServiceTiers.get
            get LCFCP$IPaymentTierProvider$$$ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540674328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceTiers;
            }
            //--TRIMMABLE-BOUNDARY-END(21475903256)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            static $h = 626148;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885528036),
    {
      "p": 1328920,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770429924,
        "f": 50331649
      },
      "n": "Category",
      "d": 626148,
      "h": 12885528036,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885528036),
//--TRIMMABLE-BOUNDARY-START(85899972068),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier$$($.$nYKj.LCFCP.PaymentCategoryType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130168292,
        "f": 50331649
      },
      "n": "ServiceTiers",
      "d": 626148,
      "h": 85899972068,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899972068),
//--TRIMMABLE-BOUNDARY-START(81605004772),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540233700,
        "f": 50331649
      },
      "n": "Name",
      "d": 626148,
      "h": 81605004772,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605004772),
//--TRIMMABLE-BOUNDARY-START(90194939364),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720102884,
        "f": 50331649
      },
      "n": "Title",
      "d": 626148,
      "h": 90194939364,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194939364),
//--TRIMMABLE-BOUNDARY-START(17180495332),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360364516,
        "f": 50331649
      },
      "n": "Description",
      "d": 626148,
      "h": 17180495332,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180495332),
//--TRIMMABLE-BOUNDARY-START(73015070180),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950299108,
        "f": 50331649
      },
      "n": "Icon",
      "d": 626148,
      "h": 73015070180,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015070180)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(94489906660),
    {
      "t": 5739269,
      "n": "TVService",
      "d": 626148,
      "h": 94489906660,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(94489906660),
//--TRIMMABLE-BOUNDARY-START(8590560740),
    {
      "t": 691684,
      "n": "AppService",
      "d": 626148,
      "h": 8590560740,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590560740),
//--TRIMMABLE-BOUNDARY-START(77310037476),
    {
      "t": 262145,
      "n": "isAdmin",
      "d": 626148,
      "h": 77310037476,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77310037476)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295593444),
    {
      "p": [
        {
          "n": "tvservice",
          "p": 5739269
        },
        {
          "n": "appService",
          "p": 691684
        },
        {
          "n": "admin",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 626148,
      "h": 4295593444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295593444)
  ],
  "h": 626148
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType), $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Services.CommunityTVPaymentServiceProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Services${separator}CommunityTVPaymentServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(626148)
        
        

        //--TRIMMABLE-BOUNDARY-START(953828)
        $asm.$cls(`$aImc.LCCTCS$1.CommunityTVDevicePairingAuthenticationInput`, ($self) => class CommunityTVDevicePairingAuthenticationInput extends $.$hDPm.LCFCI.BaseInputEditor$$($.$ZaYa.LCCTCM.CommunityTVDevicePairingAuthenticationCode)
        {
            //--TRIMMABLE-BOUNDARY-START(47245594084)
            /*string */ get OptimizedComponentName()
            {
                return "communitytvdevicepairingauthenticationinput";
            }
            //--TRIMMABLE-BOUNDARY-END(47245594084)
            
            //--TRIMMABLE-BOUNDARY-START(42950626788)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950626788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(42950626788)
            
            //--TRIMMABLE-BOUNDARY-START(51540561380)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(51540561380)
            
            //--TRIMMABLE-BOUNDARY-START(17180823012)
            /*string?*/ code = null;
            //--TRIMMABLE-BOUNDARY-END(17180823012)
            
            //--TRIMMABLE-BOUNDARY-START(73015397860)
            /*bool*/ verifying = false;
            //--TRIMMABLE-BOUNDARY-END(73015397860)
            
            //--TRIMMABLE-BOUNDARY-START(64425463268)
            /*bool*/ verified = false;
            //--TRIMMABLE-BOUNDARY-END(64425463268)
            
            //--TRIMMABLE-BOUNDARY-START(21475790308)
            /*string?*/ error = null;
            //--TRIMMABLE-BOUNDARY-END(21475790308)
            
            //--TRIMMABLE-BOUNDARY-START(68720430564)
            /*Task *//*async*/  Verify()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720430564);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.verifying = true;
                    try
                    {
                        let $t1, $r1;
                        let $t2, $r2;
                        if ($.$$.S.String.IsNullOrEmpty(this.code))
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("Enter pairing code");
                        }
                        /*var*/ let result = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$$.S.String, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)))().$ctor(this,  (/**/ service) =>
                        {
                            return service.LCCTCS$ICommunityTVRemoteService$VerifyDevicePairingCode(this.code);
                        }, $BIUYRd ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)).$h,"p":[{"n":"service","p":3248901}],"n":"","d":953828,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        ($t2 = this.ValueChanged.InvokeAsync$1((() =>
                        {
                            //new $.$ZaYa.LCCTCM.CommunityTVDevicePairingAuthenticationCode()
                            const $t3 = $.$ZaYa.LCCTCM.CommunityTVDevicePairingAuthenticationCode;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            $i3.Code = this.code;
                            $i3.DeviceId = result;
                            return $i3;
                        })()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        this.verified = true;
                    }
                    catch(e)
                    {
                        this.code = null;
                        this.error = e.Message;
                    }
                    this.verifying = false;
                    ($t4 = this.StateChanged(false, false, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.TV.Client.Blazor\\CommunityTVDevicePairingAuthenticationInput.razor.cs", "Verify", 46), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68720430564)
            
            //--TRIMMABLE-BOUNDARY-START(12885855716)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885855716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "row");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "col-10");
                $.$aImc._LCCTCSC.TypeInference.CreateInputEditor_0($.$$.S.String, __builder, 4, 5, $.$fPer.LCFC.Theme.OfPrimary(0.1), 6, (4131/*InputEditorFeatures.Default*/ & ~2/*InputEditorFeatures.BorderBottom*/) | 8/*InputEditorFeatures.Highlight*/, 7, this.code, 8, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.code = __value;
                }, $YiESSi ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":953828,"h":0,"f":17825794}), this.code)), 9, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                {
                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "code"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                }, $JjfDak ??= {"r":38797349,"n":"","d":953828,"h":0,"f":17825794})).Invoke()));
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\r\n    ");
                __builder.OpenElement(11, "div");
                __builder.AddAttribute$5(12, "class", "col-a flex");
                if (this.verifying)
                {
                    __builder.AddMarkupContent(13, "<i class=\"mdi mdi-loading mdi-spin fsz-30 mg-a\"></i>");
                }
                else if (this.verified)
                {
                    __builder.AddMarkupContent(14, "<i class=\"mdi mdi-check-circle fsz-30 cl-primary mg-a\"></i>");
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 15);
                    __builder.AddComponentParameter(16, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder.AddComponentParameter(17, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 256/*ButtonFeatures.Small*/ | 4096/*ButtonFeatures.SwallowClickException*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder.AddComponentParameter(18, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Verify))));
                    __builder.AddAttribute$3(19, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$4(20, "Pair");
                    }), $homacb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":953828,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(21, "\r\n");
                __builder.OpenElement(22, "small");
                __builder.AddAttribute$5(23, "class", "cl-error");
                __builder.AddContent$4(24, this.error);
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12885855716)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590888420)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590888420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590888420)
            
            //--TRIMMABLE-BOUNDARY-START(8590888420)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590888420)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51540561380)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(51540561380)
                
            }
            static $h = 953828;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCI.BaseInputEditor$$($.$ZaYa.LCCTCM.CommunityTVDevicePairingAuthenticationCode); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245594084),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065724900,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 953828,
      "h": 47245594084,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245594084),
//--TRIMMABLE-BOUNDARY-START(51540561380),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655659492,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130495972,
        "f": 83886081
      },
      "n": "Server",
      "d": 953828,
      "h": 51540561380,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540561380)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950626788),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 953828,
      "h": 42950626788,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950626788),
//--TRIMMABLE-BOUNDARY-START(68720430564),
    {
      "r": 178454529,
      "n": "Verify",
      "d": 953828,
      "h": 68720430564,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(68720430564),
//--TRIMMABLE-BOUNDARY-START(12885855716),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 953828,
      "h": 12885855716,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885855716)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180823012),
    {
      "t": 1310721,
      "n": "code",
      "d": 953828,
      "h": 17180823012,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180823012),
//--TRIMMABLE-BOUNDARY-START(73015397860),
    {
      "t": 262145,
      "n": "verifying",
      "d": 953828,
      "h": 73015397860,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015397860),
//--TRIMMABLE-BOUNDARY-START(64425463268),
    {
      "t": 262145,
      "n": "verified",
      "d": 953828,
      "h": 64425463268,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425463268),
//--TRIMMABLE-BOUNDARY-START(21475790308),
    {
      "t": 1310721,
      "n": "error",
      "d": 953828,
      "h": 21475790308,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475790308)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590888420),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 953828,
      "h": 8590888420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590888420)
  ],
  "h": 953828
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$$.S.IDisposable, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$fPer.LCFC.ISelectOption$$($.$ZaYa.LCCTCM.CommunityTVDevicePairingAuthenticationCode)), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$ZaYa.LCCTCM.CommunityTVDevicePairingAuthenticationCode), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$fPer.LCFC.ISelectOption$$($.$ZaYa.LCCTCM.CommunityTVDevicePairingAuthenticationCode)), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$fPer.LCFC.ISelectOption$$($.$ZaYa.LCCTCM.CommunityTVDevicePairingAuthenticationCode)), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$ZaYa.LCCTCM.CommunityTVDevicePairingAuthenticationCode), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$ZaYa.LCCTCM.CommunityTVDevicePairingAuthenticationCode), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Shared.CommunityTVDevicePairingAuthenticationInput`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Shared${separator}CommunityTVDevicePairingAuthenticationInput`; }
        });
        //--TRIMMABLE-BOUNDARY-END(953828)
        
        

        //--TRIMMABLE-BOUNDARY-START(560612)
        $asm.$cls(`$aImc.LCCTCS.CommunityTVApplication`, ($self) => class CommunityTVApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885462500)
            $ctor$5(/*CommunityTVService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885462500);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885462500)
            
            //--TRIMMABLE-BOUNDARY-START(146029448676)
            /*string */ get Name()
            {
                return "TVManager";
            }
            //--TRIMMABLE-BOUNDARY-END(146029448676)
            
            //--TRIMMABLE-BOUNDARY-START(167504285156)
            /*string */ get Title()
            {
                return "TV Manager";
            }
            //--TRIMMABLE-BOUNDARY-END(167504285156)
            
            //--TRIMMABLE-BOUNDARY-START(21475397092)
            /*string */ get Description()
            {
                return "Pay less and Watch more live TVs, Movies and Series.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475397092)
            
            //--TRIMMABLE-BOUNDARY-START(141734481380)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-youtube-tv"/*MaterialDesignIconNames.YoutubeTv*/);
            }
            //--TRIMMABLE-BOUNDARY-END(141734481380)
            
            //--TRIMMABLE-BOUNDARY-START(163209317860)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#1884E0";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(163209317860)
            
            //--TRIMMABLE-BOUNDARY-START(30065331684)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 97/*ApplicationServiceFeatures.DefaultInDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065331684)
            
            //--TRIMMABLE-BOUNDARY-START(158914350564)
            /*IEnumerable<ApplicationServiceDescriptor>? */ get ServiceModules()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$yleQ.LCFCA.ApplicationServiceDescriptor), [(() =>
                {
                    //new $.$yleQ.LCFCA.ApplicationServiceDescriptor()
                    const $t2 = $.$yleQ.LCFCA.ApplicationServiceDescriptor;
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.Name = "TVAdmin";
                    $i2.Title = "TVAdmin";
                    $i2.MainAssemblies = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA.ApplicationAssembly), [$.$fPer.LCFCA.ApplicationAssembly.op_Implicit$1("LivingThing.Core.Community.TV.Client.Admin.Blazor")], [-1], null);
                    $i2.UIEntryType = "LivingThing.Core.Community.TV.Client.Admin.Pages.Admin";
                    $i2.Icon = $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-youtube-studio"/*MaterialDesignIconNames.YoutubeStudio*/);
                    $i2.Description = "Administrative app for TV";
                    $i2.Paths = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["TV/Admin"], null, null);
                    $i2.Theme = this.Theme;
                    return $i2;
                })()], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(158914350564)
            
            //--TRIMMABLE-BOUNDARY-START(17180429796)
            /*Type? */ get ApplicationViewType()
            {
                return $.$aImc.LCCTCP.CommunityTVApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180429796)
            
            //--TRIMMABLE-BOUNDARY-START(137439514084)
            /*RenderFragment? */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439514084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$aImc.LCCTCP.CommunityTVApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(137439514084)
            
            //--TRIMMABLE-BOUNDARY-START(25770364388)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770364388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770364388)
            
            //--TRIMMABLE-BOUNDARY-START(150324415972)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(150324415972)
            
            //--TRIMMABLE-BOUNDARY-START(4295527908)
            /*CommunityTVService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295527908)
            
            //--TRIMMABLE-BOUNDARY-START(154619383268)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(154619383268)
            
            //--TRIMMABLE-BOUNDARY-START(171799252452)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(5376/*PostTypes.TV*/, 5382/*PostTypes.TVEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(171799252452)
            
            //--TRIMMABLE-BOUNDARY-START(8592072160)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceModuleProvider.ServiceModules.get
            get LCFCA$IApplicationServiceModuleProvider$ServiceModules()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887039456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceModules;
            }
            //--TRIMMABLE-BOUNDARY-END(8592072160)
            
            static $h = 560612;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(146029448676),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604939236,
        "f": 50364417
      },
      "n": "Name",
      "d": 560612,
      "h": 146029448676,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029448676),
//--TRIMMABLE-BOUNDARY-START(167504285156),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554612196,
        "f": 50364417
      },
      "n": "Title",
      "d": 560612,
      "h": 167504285156,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(167504285156),
//--TRIMMABLE-BOUNDARY-START(21475397092),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835135460,
        "f": 50364417
      },
      "n": "Description",
      "d": 560612,
      "h": 21475397092,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475397092),
//--TRIMMABLE-BOUNDARY-START(141734481380),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015004644,
        "f": 50364417
      },
      "n": "Icon",
      "d": 560612,
      "h": 141734481380,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734481380),
//--TRIMMABLE-BOUNDARY-START(163209317860),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964677604,
        "f": 50364417
      },
      "n": "Theme",
      "d": 560612,
      "h": 163209317860,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209317860),
//--TRIMMABLE-BOUNDARY-START(30065331684),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425070052,
        "f": 50364417
      },
      "n": "Features",
      "d": 560612,
      "h": 30065331684,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065331684),
//--TRIMMABLE-BOUNDARY-START(158914350564),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374743012,
        "f": 50331649
      },
      "n": "ServiceModules",
      "d": 560612,
      "h": 158914350564,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914350564),
//--TRIMMABLE-BOUNDARY-START(17180429796),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245200868,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 560612,
      "h": 17180429796,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180429796),
//--TRIMMABLE-BOUNDARY-START(150324415972),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194873828,
        "f": 50364417
      },
      "n": "Order",
      "d": 560612,
      "h": 150324415972,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324415972),
//--TRIMMABLE-BOUNDARY-START(4295527908),
    {
      "p": 691684,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655266276,
        "f": 50331650
      },
      "n": "_Service",
      "d": 560612,
      "h": 4295527908,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295527908),
//--TRIMMABLE-BOUNDARY-START(154619383268),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784808420,
        "f": 50364417
      },
      "n": "Service",
      "d": 560612,
      "h": 154619383268,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619383268),
//--TRIMMABLE-BOUNDARY-START(171799252452),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144546788,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 560612,
      "h": 171799252452,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(171799252452)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137439514084),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 560612,
      "h": 137439514084,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(137439514084),
//--TRIMMABLE-BOUNDARY-START(25770364388),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 560612,
      "h": 25770364388,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770364388)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885462500),
    {
      "p": [
        {
          "n": "service",
          "p": 691684
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 560612,
      "h": 12885462500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885462500)
  ],
  "h": 560612
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$yleQ.LCFCA.IApplicationServiceModuleProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Services.CommunityTVApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Services${separator}CommunityTVApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(560612)
        
        

        //--TRIMMABLE-BOUNDARY-START(691684)
        $asm.$cls(`$aImc.LCCTCS.CommunityTVService`, ($self) => class CommunityTVService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$ZaYa.LCCTCM.CommunityTVPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180560868)
            $ctor$6(/*CommunityRootService*/ service, /*TVPlayerServices*/ tVServices)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180560868);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.TVPlayerService = tVServices;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180560868)
            
            //--TRIMMABLE-BOUNDARY-START(85900037604)
            /*TVPlayerServices*/ TVPlayerService = null;
            //--TRIMMABLE-BOUNDARY-END(85900037604)
            
            //--TRIMMABLE-BOUNDARY-START(64425201124)
            /*CommunityTVPaymentServiceProvider?*/ Payment = null;
            //--TRIMMABLE-BOUNDARY-END(64425201124)
            
            //--TRIMMABLE-BOUNDARY-START(90195004900)
            /*YoutubeStreamSettings? */ get YoutubeSettings()
            {
                return (this.TVPlayerService.AdminSettings?.YoutubeSettings ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(90195004900)
            
            //--TRIMMABLE-BOUNDARY-START(55835266532)
            /*bool*/ IsAdmin = false;
            //--TRIMMABLE-BOUNDARY-END(55835266532)
            
            //--TRIMMABLE-BOUNDARY-START(60130233828)
            /*ValueTask *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130233828);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t2, $r2;
                            let $t3, $r3;
                            ($t2 = super.Load(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            ($t3 = this.TVPlayerService.EnsureLoaded(this.IsAdmin), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                            this.Payment = new $.$aImc.LCCTCS.CommunityTVPaymentServiceProvider().$ctor$1(this.TVPlayerService, this, this.CommunityService.UserAuthenticationTicket.HasRoles("SuperAdmin,Admin," + $.$strNN("TV.Admin"/*CommunityTVAccountModel.AdminRole*/)));
                        });
                    }, $StInCh ??= {"r":181338113,"n":"","d":691684,"h":0,"f":17829890}), false, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60130233828)
            
            //--TRIMMABLE-BOUNDARY-START(8592006624)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceHasYoutubeHelps.YoutubeSettings.get
            get LCFCA$IApplicationServiceHasYoutubeHelps$YoutubeSettings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886973920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.YoutubeSettings;
            }
            //--TRIMMABLE-BOUNDARY-END(8592006624)
            
            static $h = 691684;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$ZaYa.LCCTCM.CommunityTVPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85900037604),
    {
      "p": 5739269,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950364644,
        "f": 50331649
      },
      "n": "TVPlayerService",
      "d": 691684,
      "h": 85900037604,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900037604),
//--TRIMMABLE-BOUNDARY-START(64425201124),
    {
      "p": 626148,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360430052,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605070308,
        "f": 83886082
      },
      "n": "Payment",
      "d": 691684,
      "h": 64425201124,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425201124),
//--TRIMMABLE-BOUNDARY-START(90195004900),
    {
      "p": 20981078,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540299236,
        "f": 50331649
      },
      "n": "YoutubeSettings",
      "d": 691684,
      "h": 90195004900,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195004900),
//--TRIMMABLE-BOUNDARY-START(55835266532),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770495460,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015135716,
        "f": 83886081
      },
      "n": "IsAdmin",
      "d": 691684,
      "h": 55835266532,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835266532)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130233828),
    {
      "r": 181338113,
      "n": "Load",
      "d": 691684,
      "h": 60130233828,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(60130233828)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180560868),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        },
        {
          "n": "tVServices",
          "p": 5739269
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 691684,
      "h": 17180560868,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180560868)
  ],
  "h": 691684
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$ZaYa.LCCTCM.CommunityTVPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$ZaYa.LCCTCM.CommunityTVPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$yleQ.LCFCA.IApplicationServiceHasYoutubeHelps, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Client.Services.CommunityTVService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Client${separator}Services${separator}CommunityTVService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(691684)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Bcl.Cryptography", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.Microsoft.IdentityModel.Logging", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.IdentityModel.Tokens", "NetJs.Microsoft.IdentityModel.JsonWebTokens", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.Newtonsoft.Json", "NetJs.ReverseMarkdown", "NetJs.System.IdentityModel.Tokens.Jwt", "NetJs.TMDbLib", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Authentication.Common", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Authentication.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Local", "NetJs.LivingThing.Core.Community.TV.Common", "NetJs.LivingThing.Core.Community.TV.App.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(36324)
