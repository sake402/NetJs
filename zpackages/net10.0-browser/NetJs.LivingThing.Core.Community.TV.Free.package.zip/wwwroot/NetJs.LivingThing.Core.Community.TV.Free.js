
//--TRIMMABLE-BOUNDARY-START(43888)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $fnTP, $Xjnw, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm, $IHYd, $ZaYa) {
    "use strict";
    let _;
    let $lhEhYi;
    let $IYOKWk;
    let $VmhgQi;
    let $uMdXRd;
    let $MAoIJe;
    let $CZkUoi;
    let $YOJMmh;
    let $bNvTHc;
    let $jlqaCk;
    let $ZYwQld;
    let $DovqEb;
    let $QCLwpc;
    let $uRPMEe;
    let $NBKWph;
    let $gxspPi;
    let $bcqiLh;
    let $tnYOMh;
    let $QPPiTa;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.TV.Free", 
    {
  "h": 43888,
  "f": "LivingThing.Core.Community.TV.Free",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.TV.Free",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.TV.Free",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(437104)
        $asm.$cls(`$rAPp.LCCTF.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590371696)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590371696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ZaYa.LCCTCS.StreamConverter.Register($.$rAPp.LCCTFL.FreeLiveTVStream);
                $.$ZaYa.LCCTCS.StreamConverter.Register($.$rAPp.LCCTFM.FreeMovieStream);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ZaYa.LCCTCS.IStreamProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$rAPp.LCCTFL.FreeLiveTVStreamProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ZaYa.LCCTCS.IStreamProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$rAPp.LCCTFL.FreeLiveTVStreamProvider, x);
                }, $lhEhYi ??= {"r":4494085,"p":[{"n":"x","p":327718}],"n":"","d":437104,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ZaYa.LCCTCS.IStreamProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$rAPp.LCCTFM.FreeMovieStreamProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ZaYa.LCCTCS.IStreamProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$rAPp.LCCTFM.FreeMovieStreamProvider, x);
                }, $IYOKWk ??= {"r":4494085,"p":[{"n":"x","p":327718}],"n":"","d":437104,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590371696)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$rAPp.LCCTF.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295404400)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295404400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295404400)
            
            //--TRIMMABLE-BOUNDARY-START(4295404400)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295404400)
            
            static $h = 437104;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590371696),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 437104,
      "h": 8590371696,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590371696)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295404400),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 437104,
      "h": 4295404400,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295404400)
  ],
  "h": 437104
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Free.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Free${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(437104)
        
        

        //--TRIMMABLE-BOUNDARY-START(109424)
        $asm.$cls(`$rAPp.LCCTF.FreeStream`, ($self) => class FreeStream extends $.$fPer.LCFCD.MediaModel
        {
            //--TRIMMABLE-BOUNDARY-START(34359847792)
            /*string? */ get CategoryId()
            {
                return !$.$$.S.String.IsNullOrEmpty(this.Group) ? this.Group : null;
            }
            //--TRIMMABLE-BOUNDARY-END(34359847792)
            
            //--TRIMMABLE-BOUNDARY-START(304942787440)
            /*long */ get StreamId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093768560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int64, "StreamId");
            }
            /*long */ set StreamId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292057885552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Int64, value, "StreamId");
            }
            //--TRIMMABLE-BOUNDARY-END(304942787440)
            
            //--TRIMMABLE-BOUNDARY-START(210453506928)
            /*string?*/ PosterPhoto = null;
            //--TRIMMABLE-BOUNDARY-END(210453506928)
            
            //--TRIMMABLE-BOUNDARY-START(214748474224)
            /*TVPreview */ get Preview()
            {
                return this.YoutubeTrailer !== null ? 0/*TVPreview.Iframe*/ : this.BannerUrl !== null ? 1/*TVPreview.Image*/ : 2/*TVPreview.Video*/;
            }
            //--TRIMMABLE-BOUNDARY-END(214748474224)
            
            //--TRIMMABLE-BOUNDARY-START(219043441520)
            /*string? */ get PreviewUri()
            {
                return this.YoutubeTrailer ?? this.BannerUrl;
            }
            //--TRIMMABLE-BOUNDARY-END(219043441520)
            
            //--TRIMMABLE-BOUNDARY-START(231928343408)
            /*DateTime?*/ ReleaseDate = null;
            //--TRIMMABLE-BOUNDARY-END(231928343408)
            
            //--TRIMMABLE-BOUNDARY-START(38654815088)
            /*DateTime?*/ Dated = null;
            //--TRIMMABLE-BOUNDARY-END(38654815088)
            
            //--TRIMMABLE-BOUNDARY-START(309237754736)
            /*long? */ get TmdbId()
            {
                return this.StreamId;
            }
            //--TRIMMABLE-BOUNDARY-END(309237754736)
            
            //--TRIMMABLE-BOUNDARY-START(51539716976)
            /*bool */ get Freemium()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374291824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Boolean, "Freemium");
            }
            /*bool */ set Freemium(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698147184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Boolean, value, "Freemium");
            }
            //--TRIMMABLE-BOUNDARY-END(51539716976)
            
            //--TRIMMABLE-BOUNDARY-START(42949782384)
            /*string? */ get Director()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784357232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "Director");
            }
            /*string? */ set Director(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108212592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "Director");
            }
            //--TRIMMABLE-BOUNDARY-END(42949782384)
            
            //--TRIMMABLE-BOUNDARY-START(206158539632)
            /*string? */ get Plot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964226416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "Plot");
            }
            /*string? */ set Plot(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288081776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "Plot");
            }
            //--TRIMMABLE-BOUNDARY-END(206158539632)
            
            //--TRIMMABLE-BOUNDARY-START(30064880496)
            /*string? */ get Cast()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014553456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "Cast");
            }
            /*string? */ set Cast(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518278000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "Cast");
            }
            //--TRIMMABLE-BOUNDARY-END(30064880496)
            
            //--TRIMMABLE-BOUNDARY-START(227633376112)
            /*float? */ get Rating()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913899376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$typeNullable($.$$.S.Single), "Rating");
            }
            /*float? */ set Rating(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283467950960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$typeNullable($.$$.S.Single), value, "Rating");
            }
            //--TRIMMABLE-BOUNDARY-END(227633376112)
            
            //--TRIMMABLE-BOUNDARY-START(25769913200)
            /*string[]? */ get BackdropPhoto()
            {
                return this.BannerUrl !== null ? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [this.BannerUrl], null, null) : null;
            }
            //--TRIMMABLE-BOUNDARY-END(25769913200)
            
            //--TRIMMABLE-BOUNDARY-START(317827689328)
            /*string? */ get YoutubeTrailer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863572336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "YoutubeTrailer");
            }
            /*string? */ set YoutubeTrailer(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300647820144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "YoutubeTrailer");
            }
            //--TRIMMABLE-BOUNDARY-END(317827689328)
            
            //--TRIMMABLE-BOUNDARY-START(223338408816)
            /*Dictionary<string, object?>*/ Properties = null;
            //--TRIMMABLE-BOUNDARY-END(223338408816)
            
            //--TRIMMABLE-BOUNDARY-START(47244749680)
            /*bool */ Equals$2(/*IStream?*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244749680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.GetType.call(other) === $.$$.S.Object.GetType.call(this) && other.LCCTCS$IStream$StreamId === this.StreamId)
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(47244749680)
            
            //--TRIMMABLE-BOUNDARY-START(55834684272)
            /*string */ GenerateM3U()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834684272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                return `#EXTINF:-1${$.$strNN((this.Id !== null ? ` tvg-id=\"${$.$strNN(this.Id)}\"` : ""))} tvg-logo=\"${$.$strNN(this.PosterPhoto)}\" group-title=\"${$.$strNN(this.CategoryId)}\"${$.$strNN((this.Freemium ? " freemium=\"true\"" : ""))}${$.$strNN((this.TmdbId !== 0 ? ` tmdbid=\"${$.$strNN(this.TmdbId)}\"` : ""))}${$.$strNN((this.YoutubeTrailer !== null ? ` youtubetrailer=\"${$.$strNN(this.YoutubeTrailer)}\"` : ""))},${$.$strNN(this.Title)}\r\n${$.$strNN(((__ca1__ = this.MediaUrls) !== null ? $.$sl.SL.Enumerable.First$1($.$$.S.String, __ca1__) : null))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(55834684272)
            
            //--TRIMMABLE-BOUNDARY-START(107378348805)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStream.Type.get
            get LCCTCS$IStream$Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141738087173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Type;
            }
            //--TRIMMABLE-BOUNDARY-END(107378348805)
            
            //--TRIMMABLE-BOUNDARY-START(21479002885)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStream.CategoryId.get
            get LCCTCS$IStream$CategoryId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299133701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CategoryId;
            }
            //--TRIMMABLE-BOUNDARY-END(21479002885)
            
            //--TRIMMABLE-BOUNDARY-START(90198479621)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStream.StreamId.get
            get LCCTCS$IStream$StreamId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133148152581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StreamId;
            }
            //--TRIMMABLE-BOUNDARY-END(90198479621)
            
            //--TRIMMABLE-BOUNDARY-START(98788414213)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStream.TmdbId.get
            get LCCTCS$IStream$TmdbId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137443119877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TmdbId;
            }
            //--TRIMMABLE-BOUNDARY-END(98788414213)
            
            //--TRIMMABLE-BOUNDARY-START(47248806661)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStream.PosterPhoto.get
            get LCCTCS$IStream$PosterPhoto()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111673316101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PosterPhoto;
            }
            //--TRIMMABLE-BOUNDARY-END(47248806661)
            
            //--TRIMMABLE-BOUNDARY-START(55838741253)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStream.Preview.get
            get LCCTCS$IStream$Preview()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115968283397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Preview;
            }
            //--TRIMMABLE-BOUNDARY-END(55838741253)
            
            //--TRIMMABLE-BOUNDARY-START(64428675845)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStream.PreviewUri.get
            get LCCTCS$IStream$PreviewUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120263250693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PreviewUri;
            }
            //--TRIMMABLE-BOUNDARY-END(64428675845)
            
            //--TRIMMABLE-BOUNDARY-START(38658872069)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStream.Genre.get
            get LCCTCS$IStream$Genre()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889068293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Genre;
            }
            //--TRIMMABLE-BOUNDARY-END(38658872069)
            
            //--TRIMMABLE-BOUNDARY-START(81608545029)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStream.ReleaseDate.get
            get LCCTCS$IStream$ReleaseDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128853185285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReleaseDate;
            }
            //--TRIMMABLE-BOUNDARY-END(81608545029)
            
            //--TRIMMABLE-BOUNDARY-START(30068937477)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStream.Duration.get
            get LCCTCS$IStream$Duration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594100997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Duration;
            }
            //--TRIMMABLE-BOUNDARY-END(30068937477)
            
            //--TRIMMABLE-BOUNDARY-START(73018610437)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStream.Rating.get
            get LCCTCS$IStream$Rating()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124558217989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Rating;
            }
            //--TRIMMABLE-BOUNDARY-END(73018610437)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(12931664214)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDated.Dated.get
            get LCFC$IDated$Dated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341729622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dated;
            }
            //--TRIMMABLE-BOUNDARY-END(12931664214)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Community.TV.Common.Services.IStream>.Equals(LivingThing.Core.Community.TV.Common.Services.IStream?)
            S$IEquatable$LivingThing$Core$Community$TV$Common$Services$IStream$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(107378545413)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamInfo.TmdbId.get
            get LCCTCS$IStreamInfo$TmdbId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137443316485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TmdbId;
            }
            //--TRIMMABLE-BOUNDARY-END(107378545413)
            
            //--TRIMMABLE-BOUNDARY-START(47249003269)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamInfo.Director.get
            get LCCTCS$IStreamInfo$Director()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889264901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Director;
            }
            //--TRIMMABLE-BOUNDARY-END(47249003269)
            
            //--TRIMMABLE-BOUNDARY-START(98788610821)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamInfo.ReleaseDate.get
            get LCCTCS$IStreamInfo$ReleaseDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133148349189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReleaseDate;
            }
            //--TRIMMABLE-BOUNDARY-END(98788610821)
            
            //--TRIMMABLE-BOUNDARY-START(55838937861)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamInfo.Duration.get
            get LCCTCS$IStreamInfo$Duration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184232197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Duration;
            }
            //--TRIMMABLE-BOUNDARY-END(55838937861)
            
            //--TRIMMABLE-BOUNDARY-START(64428872453)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamInfo.Genre.get
            get LCCTCS$IStreamInfo$Genre()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479199493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Genre;
            }
            //--TRIMMABLE-BOUNDARY-END(64428872453)
            
            //--TRIMMABLE-BOUNDARY-START(73018807045)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamInfo.Plot.get
            get LCCTCS$IStreamInfo$Plot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120263447301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Plot;
            }
            //--TRIMMABLE-BOUNDARY-END(73018807045)
            
            //--TRIMMABLE-BOUNDARY-START(38659068677)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamInfo.Cast.get
            get LCCTCS$IStreamInfo$Cast()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594297605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Cast;
            }
            //--TRIMMABLE-BOUNDARY-END(38659068677)
            
            //--TRIMMABLE-BOUNDARY-START(90198676229)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamInfo.Rating.get
            get LCCTCS$IStreamInfo$Rating()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128853381893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Rating;
            }
            //--TRIMMABLE-BOUNDARY-END(90198676229)
            
            //--TRIMMABLE-BOUNDARY-START(30069134085)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamInfo.BackdropPhoto.get
            get LCCTCS$IStreamInfo$BackdropPhoto()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299330309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BackdropPhoto;
            }
            //--TRIMMABLE-BOUNDARY-END(30069134085)
            
            //--TRIMMABLE-BOUNDARY-START(115968480005)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamInfo.YoutubeTrailer.get
            get LCCTCS$IStreamInfo$YoutubeTrailer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141738283781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.YoutubeTrailer;
            }
            //--TRIMMABLE-BOUNDARY-END(115968480005)
            
            //--TRIMMABLE-BOUNDARY-START(81608741637)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamInfo.Properties.get
            get LCCTCS$IStreamInfo$Properties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124558414597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Properties;
            }
            //--TRIMMABLE-BOUNDARY-END(81608741637)
            
            //--TRIMMABLE-BOUNDARY-START(21474945904)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474945904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21474945904)
            
            //--TRIMMABLE-BOUNDARY-START(21474945904)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21474945904)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(231928343408)
                this.ReleaseDate = null;
                //--TRIMMABLE-BOUNDARY-END(231928343408)
                
                //--TRIMMABLE-BOUNDARY-START(38654815088)
                this.Dated = null;
                //--TRIMMABLE-BOUNDARY-END(38654815088)
                
            }
            static $h = 109424;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD.MediaModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359847792),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604488048,
        "f": 50331649
      },
      "n": "CategoryId",
      "d": 109424,
      "h": 34359847792,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359847792),
//--TRIMMABLE-BOUNDARY-START(304942787440),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176093768560,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292057885552,
        "f": 83886081
      },
      "n": "StreamId",
      "d": 109424,
      "h": 304942787440,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(304942787440),
//--TRIMMABLE-BOUNDARY-START(210453506928),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554161008,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274878016368,
        "f": 83886081
      },
      "n": "PosterPhoto",
      "d": 109424,
      "h": 210453506928,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210453506928),
//--TRIMMABLE-BOUNDARY-START(214748474224),
    {
      "p": 5804805,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144095600,
        "f": 50331649
      },
      "n": "Preview",
      "d": 109424,
      "h": 214748474224,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214748474224),
//--TRIMMABLE-BOUNDARY-START(219043441520),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734030192,
        "f": 50331649
      },
      "n": "PreviewUri",
      "d": 109424,
      "h": 219043441520,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219043441520),
//--TRIMMABLE-BOUNDARY-START(231928343408),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167503833968,
        "f": 50331649
      },
      "n": "ReleaseDate",
      "d": 109424,
      "h": 231928343408,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(231928343408),
//--TRIMMABLE-BOUNDARY-START(38654815088),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194422640,
        "f": 50331649
      },
      "n": "Dated",
      "d": 109424,
      "h": 38654815088,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654815088),
//--TRIMMABLE-BOUNDARY-START(309237754736),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184683703152,
        "f": 50331649
      },
      "n": "TmdbId",
      "d": 109424,
      "h": 309237754736,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309237754736),
//--TRIMMABLE-BOUNDARY-START(51539716976),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374291824,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698147184,
        "f": 83886081
      },
      "n": "Freemium",
      "d": 109424,
      "h": 51539716976,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539716976),
//--TRIMMABLE-BOUNDARY-START(313532722032),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193273637744,
        "f": 50331905
      },
      "n": "Type",
      "d": 109424,
      "h": 313532722032,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(313532722032),
//--TRIMMABLE-BOUNDARY-START(42949782384),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784357232,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108212592,
        "f": 83886081
      },
      "n": "Director",
      "d": 109424,
      "h": 42949782384,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949782384),
//--TRIMMABLE-BOUNDARY-START(206158539632),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964226416,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288081776,
        "f": 83886081
      },
      "n": "Plot",
      "d": 109424,
      "h": 206158539632,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206158539632),
//--TRIMMABLE-BOUNDARY-START(30064880496),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014553456,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518278000,
        "f": 83886081
      },
      "n": "Cast",
      "d": 109424,
      "h": 30064880496,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064880496),
//--TRIMMABLE-BOUNDARY-START(227633376112),
    {
      "p": $.$typeNullable($.$$.S.Single).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158913899376,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283467950960,
        "f": 83886081
      },
      "n": "Rating",
      "d": 109424,
      "h": 227633376112,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227633376112),
//--TRIMMABLE-BOUNDARY-START(25769913200),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424618864,
        "f": 50331649
      },
      "n": "BackdropPhoto",
      "d": 109424,
      "h": 25769913200,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25769913200),
//--TRIMMABLE-BOUNDARY-START(317827689328),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201863572336,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300647820144,
        "f": 83886081
      },
      "n": "YoutubeTrailer",
      "d": 109424,
      "h": 317827689328,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(317827689328),
//--TRIMMABLE-BOUNDARY-START(223338408816),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150323964784,
        "f": 50331649
      },
      "n": "Properties",
      "d": 109424,
      "h": 223338408816,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223338408816)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47244749680),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 4166405
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 109424,
      "h": 47244749680,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244749680),
//--TRIMMABLE-BOUNDARY-START(55834684272),
    {
      "r": 1310721,
      "n": "GenerateM3U",
      "d": 109424,
      "h": 55834684272,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834684272)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21474945904),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 109424,
      "h": 21474945904,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(21474945904)
  ],
  "h": 109424
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IMediaModel, $.$ZaYa.LCCTCS.IPlayableStream, $.$ZaYa.LCCTCS.IStream, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDated, $.$$.S.IEquatable$$($.$ZaYa.LCCTCS.IStream), $.$ZaYa.LCCTCS.IStreamInfo ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Free.FreeStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Free${separator}FreeStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(109424)
        
        

        //--TRIMMABLE-BOUNDARY-START(306032)
        $asm.$cls(`$rAPp.LCCTFM.FreeMovieStream`, ($self) => class FreeMovieStream extends $.$rAPp.LCCTF.FreeStream
        {
            //--TRIMMABLE-BOUNDARY-START(34360044400)
            /*string */ get Type()
            {
                return "FreeMovieStream";
            }
            //--TRIMMABLE-BOUNDARY-END(34360044400)
            
            //--TRIMMABLE-BOUNDARY-START(25770109808)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770109808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast(this.StreamId, $.$$.S.Int32);
            }
            //--TRIMMABLE-BOUNDARY-END(25770109808)
            
            //--TRIMMABLE-BOUNDARY-START(8590240624)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590240624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let v;
                if ($.$is(obj, $.$rAPp.LCCTFM.FreeMovieStream, { set $v($v){ v = $v; } }))
                {
                    return v.Title === this.Title;
                }
                return $.$$.S.Object.Equals$1.call(this, obj);
            }
            //--TRIMMABLE-BOUNDARY-END(8590240624)
            
            //--TRIMMABLE-BOUNDARY-START(12885207920)
            /*bool */ Equals$3(/*FreeMovieStream?*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885207920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title === (other?.Title ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(12885207920)
            
            //--TRIMMABLE-BOUNDARY-START(30065077104)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065077104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN(this.Title)} (${$.$strNN(this.Group)})`;
            }
            //--TRIMMABLE-BOUNDARY-END(30065077104)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Community.TV.Free.Movies.FreeMovieStream>.Equals(LivingThing.Core.Community.TV.Free.Movies.FreeMovieStream?)
            S$IEquatable$LivingThing$Core$Community$TV$Free$Movies$FreeMovieStream$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$3(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(4295273328)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295273328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295273328)
            
            //--TRIMMABLE-BOUNDARY-START(4295273328)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295273328)
            
            static $h = 306032;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rAPp.LCCTF.FreeStream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360044400),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475142512,
        "f": 50364417
      },
      "n": "Type",
      "d": 306032,
      "h": 34360044400,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360044400)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770109808),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 306032,
      "h": 25770109808,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770109808),
//--TRIMMABLE-BOUNDARY-START(8590240624),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 306032,
      "h": 8590240624,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590240624),
//--TRIMMABLE-BOUNDARY-START(12885207920),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 306032
        }
      ],
      "n": "Equals",
      "o": "@$3",
      "d": 306032,
      "h": 12885207920,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885207920),
//--TRIMMABLE-BOUNDARY-START(30065077104),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 306032,
      "h": 30065077104,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065077104)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295273328),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 306032,
      "h": 4295273328,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295273328)
  ],
  "h": 306032
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IMediaModel, $.$ZaYa.LCCTCS.IStreamInfo, $.$$.S.IEquatable$$($.$rAPp.LCCTFM.FreeMovieStream), $.$ZaYa.LCCTCS.IVODStream, $.$ZaYa.LCCTCS.IRecordedStream, $.$ZaYa.LCCTCS.IPlayableStream, $.$ZaYa.LCCTCS.IStream, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDated, $.$$.S.IEquatable$$($.$ZaYa.LCCTCS.IStream) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Free.Movies.FreeMovieStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Free${separator}Movies${separator}FreeMovieStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(306032)
        
        

        //--TRIMMABLE-BOUNDARY-START(174960)
        $asm.$cls(`$rAPp.LCCTFL.FreeLiveTVStream`, ($self) => class FreeLiveTVStream extends $.$rAPp.LCCTF.FreeStream
        {
            //--TRIMMABLE-BOUNDARY-START(51539782512)
            /*string */ get Type()
            {
                return "FreeLiveTVStream";
            }
            //--TRIMMABLE-BOUNDARY-END(51539782512)
            
            //--TRIMMABLE-BOUNDARY-START(12885076848)
            /*IEnumerable<IStreamEPG>?*/ EPGs = null;
            //--TRIMMABLE-BOUNDARY-END(12885076848)
            
            //--TRIMMABLE-BOUNDARY-START(42949847920)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949847920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast(this.StreamId, $.$$.S.Int32);
            }
            //--TRIMMABLE-BOUNDARY-END(42949847920)
            
            //--TRIMMABLE-BOUNDARY-START(17180044144)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180044144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let v;
                if ($.$is(obj, $.$rAPp.LCCTFL.FreeLiveTVStream, { set $v($v){ v = $v; } }))
                {
                    return v.Title === this.Title;
                }
                return $.$$.S.Object.Equals$1.call(this, obj);
            }
            //--TRIMMABLE-BOUNDARY-END(17180044144)
            
            //--TRIMMABLE-BOUNDARY-START(21475011440)
            /*bool */ Equals$3(/*FreeLiveTVStream?*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475011440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title === (other?.Title ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(21475011440)
            
            //--TRIMMABLE-BOUNDARY-START(47244815216)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244815216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN(this.Title)} (${$.$strNN(this.Group)})`;
            }
            //--TRIMMABLE-BOUNDARY-END(47244815216)
            
            //--TRIMMABLE-BOUNDARY-START(12888347397)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.ILiveStream.EPGs.get
            get LCCTCS$ILiveStream$EPGs()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298412805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EPGs;
            }
            //--TRIMMABLE-BOUNDARY-END(12888347397)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Community.TV.Free.LiveTVs.FreeLiveTVStream>.Equals(LivingThing.Core.Community.TV.Free.LiveTVs.FreeLiveTVStream?)
            S$IEquatable$LivingThing$Core$Community$TV$Free$LiveTVs$FreeLiveTVStream$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$3(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(8590109552)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590109552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590109552)
            
            //--TRIMMABLE-BOUNDARY-START(8590109552)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590109552)
            
            static $h = 174960;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rAPp.LCCTF.FreeStream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51539782512),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654880624,
        "f": 50364417
      },
      "n": "Type",
      "d": 174960,
      "h": 51539782512,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51539782512),
//--TRIMMABLE-BOUNDARY-START(12885076848),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS.IStreamEPG).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064946032,
        "f": 50331649
      },
      "n": "EPGs",
      "d": 174960,
      "h": 12885076848,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885076848)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42949847920),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 174960,
      "h": 42949847920,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42949847920),
//--TRIMMABLE-BOUNDARY-START(17180044144),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 174960,
      "h": 17180044144,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180044144),
//--TRIMMABLE-BOUNDARY-START(21475011440),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 174960
        }
      ],
      "n": "Equals",
      "o": "@$3",
      "d": 174960,
      "h": 21475011440,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475011440),
//--TRIMMABLE-BOUNDARY-START(47244815216),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 174960,
      "h": 47244815216,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47244815216)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590109552),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 174960,
      "h": 8590109552,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590109552)
  ],
  "h": 174960
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IMediaModel, $.$ZaYa.LCCTCS.IStreamInfo, $.$ZaYa.LCCTCS.ILiveStream, $.$ZaYa.LCCTCS.IAutoPlayStream, $.$ZaYa.LCCTCS.IPlayableStream, $.$ZaYa.LCCTCS.IStream, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDated, $.$$.S.IEquatable$$($.$ZaYa.LCCTCS.IStream), $.$$.S.IEquatable$$($.$rAPp.LCCTFL.FreeLiveTVStream) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Free.LiveTVs.FreeLiveTVStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Free${separator}LiveTVs${separator}FreeLiveTVStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(174960)
        
        

        //--TRIMMABLE-BOUNDARY-START(371568)
        $asm.$cls(`$rAPp.LCCTFM.FreeMovieStreamProvider`, ($self) => class FreeMovieStreamProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(107374553968)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(107374553968)
            
            //--TRIMMABLE-BOUNDARY-START(17180240752)
            /*IEnumerable<FreeMovieStream>?*/ freeMovieStreams = null;
            //--TRIMMABLE-BOUNDARY-END(17180240752)
            
            //--TRIMMABLE-BOUNDARY-START(8590306160)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590306160);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590306160)
            
            //--TRIMMABLE-BOUNDARY-START(103079586672)
            /*string */ get Name()
            {
                return "FreeMovies";
            }
            //--TRIMMABLE-BOUNDARY-END(103079586672)
            
            //--TRIMMABLE-BOUNDARY-START(111669521264)
            /*string? */ get Title()
            {
                return "Free Movies";
            }
            //--TRIMMABLE-BOUNDARY-END(111669521264)
            
            //--TRIMMABLE-BOUNDARY-START(12885273456)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(12885273456)
            
            //--TRIMMABLE-BOUNDARY-START(77309782896)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-youtube-tv"/*TVPlayerServices.FreeLiveTVsIcon*/);
            }
            //--TRIMMABLE-BOUNDARY-END(77309782896)
            
            //--TRIMMABLE-BOUNDARY-START(98784619376)
            /*Type */ get LCCTCS$IStreamProvider$StreamType()
            {
                return $.$rAPp.LCCTFM.FreeMovieStream.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(98784619376)
            
            //--TRIMMABLE-BOUNDARY-START(68719848304)
            /*Pager<FreeMovieStream> */ GetStreams(/*TVPlayerServices*/ tvplayer, /*IStreamCategory?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719848304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ZaYa.LCCTCS.TVPlayerServices.GetPager($.$rAPp.LCCTFM.FreeMovieStream, new ($.$$.S.Func$$$($.$fPer.LCFCD.DataFilter, $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$rAPp.LCCTFM.FreeMovieStream))))().$ctor(this, /*async*/  (/*filter*/ filter) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$rAPp.LCCTFM.FreeMovieStream)), $.$$.SCG.IEnumerable$$($.$rAPp.LCCTFM.FreeMovieStream), async ($asnycContext) => 
                    {
                        let $t1, $r1;
                        if (this.freeMovieStreams !== null)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, this.freeMovieStreams);
                        }
                        /*var*/ let m3u = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$$.S.String, this.server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server.LCCTCS$ICommunityTVRemoteService$GetFreeMoviesM3U();
                        }, $VmhgQi ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)).$h,"p":[{"n":"server","p":3248901}],"n":"","d":371568,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, this.freeMovieStreams = $.$fPer.LCFCS$3.M3UPlaylistProvider.Parse($.$rAPp.LCCTFM.FreeMovieStream, m3u, null));
                    });
                }, $uMdXRd ??= {"r":$.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$rAPp.LCCTFM.FreeMovieStream)).$h,"p":[{"n":"filter","p":9734486}],"n":"","d":371568,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$rAPp.LCCTFM.FreeMovieStream, $.$$.S.Boolean))().$ctor(this,  (/*tv*/ tv) =>
                {
                    if (category !== null)
                    {
                        if (category.LCCTCS$IStreamCategory$CategoryName === "_Uncategorized" && $.$$.S.String.IsNullOrEmpty(tv.CategoryId))
                        {
                            return true;
                        }
                        /*string?*/ let __ca1__;
                        return ((__ca1__ = tv.CategoryId) !== null ? $.$$.S.String.Equals$2.call(__ca1__, category.LCCTCS$IStreamCategory$CategoryName, 3/*StringComparison.InvariantCultureIgnoreCase*/) : false);
                    }
                    return true;
                }, $MAoIJe ??= {"r":262145,"p":[{"n":"tv","p":306032}],"n":"","d":371568,"h":0,"f":17825794}), new ($.$$.S.Action$$($.$$.SCG.IEnumerable$$($.$rAPp.LCCTFM.FreeMovieStream)))().$ctor(this,  (/*tvs*/ tvs) =>
                {
                    if (tvs !== null && category !== null)
                    {
                        ($.$cast(category, $.$ZaYa.LCCTCS.StreamCategory)).StreamsCount = $.$sl.SL.Enumerable.Count($.$rAPp.LCCTFM.FreeMovieStream, tvs, new ($.$$.S.Func$$$($.$rAPp.LCCTFM.FreeMovieStream, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                        {
                            /*string?*/ let __ca2__;
                            return ($.$$.S.String.IsNullOrEmpty(t.CategoryId) && category.LCCTCS$IStreamCategory$CategoryName === "_Uncategorized") || (((__ca2__ = t.CategoryId) !== null ? $.$$.S.String.Equals$2.call(__ca2__, category.LCCTCS$IStreamCategory$CategoryName, 3/*StringComparison.InvariantCultureIgnoreCase*/) : false));
                        }, $CZkUoi ??= {"r":262145,"p":[{"n":"t","p":306032}],"n":"","d":371568,"h":0,"f":17825794}));
                    }
                }, $YOJMmh ??= {"r":65537,"p":[{"n":"tvs","p":$.$$.SCG.IEnumerable$$($.$rAPp.LCCTFM.FreeMovieStream).$h}],"n":"","d":371568,"h":0,"f":17825794}), null);
            }
            //--TRIMMABLE-BOUNDARY-END(68719848304)
            
            //--TRIMMABLE-BOUNDARY-START(55834946416)
            /*Pager<IStreamCategory>? */ GetCategories(/*TVPlayerServices*/ tvplayer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834946416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.Select($.$$.S.String, $.$ZaYa.LCCTCS.IStreamCategory, $.$fPer.LCFCD.Paging.OrderBy($.$$.S.String, $.$$.S.String, $.$fPer.LCFCD.Paging.Distinct($.$$.S.String, $.$fPer.LCFCD.Paging.Select($.$rAPp.LCCTFM.FreeMovieStream, $.$$.S.String, this.GetStreams(tvplayer, null), new ($.$$.S.Func$$$($.$rAPp.LCCTFM.FreeMovieStream, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                {
                    /*string?*/ let __ca3__;
                    return ((__ca3__ = s.CategoryId) !== null ? ($.$$.S.String.ToUpper.call(__ca3__) ?? "_Uncategorized") : "_Uncategorized");
                }, $bNvTHc ??= {"r":1310721,"p":[{"n":"s","p":306032}],"n":"","d":371568,"h":0,"f":17825794}))), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                {
                    return c;
                }, $jlqaCk ??= {"r":1310721,"p":[{"n":"c","p":1310721}],"n":"","d":371568,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.String, $.$ZaYa.LCCTCS.IStreamCategory))().$ctor(this,  (/*c*/ c) =>
                {
                    return (() =>
                    {
                        //new $.$ZaYa.LCCTCS.StreamCategory()
                        const $t2 = $.$ZaYa.LCCTCS.StreamCategory;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.CategoryName = c;
                        return $i2;
                    })();
                }, $ZYwQld ??= {"r":4231941,"p":[{"n":"c","p":1310721}],"n":"","d":371568,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(55834946416)
            
            //--TRIMMABLE-BOUNDARY-START(60129913712)
            /*ValueTask<IStreamInfo?> */ GetInfo(/*TVPlayerServices*/ tvplayer, /*IStream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129913712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$ZaYa.LCCTCS.IStreamInfo, $.$cast(stream, $.$rAPp.LCCTFM.FreeMovieStream));
            }
            //--TRIMMABLE-BOUNDARY-END(60129913712)
            
            //--TRIMMABLE-BOUNDARY-START(81604750192)
            /*Pager<IVODStream> */ LCCTCS$IStreamProvider$$$GetStreams(/*TVPlayerServices*/ tvplayer, /*IStreamCategory?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604750192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.Cast$1($.$rAPp.LCCTFM.FreeMovieStream, $.$ZaYa.LCCTCS.IVODStream, this.GetStreams(tvplayer, category));
            }
            //--TRIMMABLE-BOUNDARY-END(81604750192)
            
            //--TRIMMABLE-BOUNDARY-START(94489652080)
            /*Pager<IStream>? */ LCCTCS$IStreamProvider$GetStreams(/*TVPlayerServices*/ tvplayer, /*IStreamCategory?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489652080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.Cast$1($.$rAPp.LCCTFM.FreeMovieStream, $.$ZaYa.LCCTCS.IStream, this.GetStreams(tvplayer, category));
            }
            //--TRIMMABLE-BOUNDARY-END(94489652080)
            
            //--TRIMMABLE-BOUNDARY-START(64424881008)
            /*StreamPermission */ GetPermission(/*TVPlayerServices*/ tvplayer, /*IStream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424881008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 3/*StreamPermission.All*/;
            }
            //--TRIMMABLE-BOUNDARY-END(64424881008)
            
            //--TRIMMABLE-BOUNDARY-START(73014815600)
            /*ValueTask<Uri?> *//*async*/  GetStreamUri(/*TVPlayerServices*/ tvplayer, /*IStream*/ stream)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$spu.S.Uri), $.$spu.S.Uri, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014815600);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!tvplayer.ValidateMemberShip("Cub Membership"/*TVPlayerServices.CubClubMembershipName*/))
                    {
                        throw new $.$ZaYa.LCCTCS.MembershipAccessException().$ctor$5("Access denied");
                    }
                    /*var*/ let fstream = $.$cast(stream, $.$rAPp.LCCTFM.FreeMovieStream);
                    /*System.Collections.Generic.IEnumerable<string>?*/ let __ca4__;
                    if ((__ca4__ = fstream.MediaUrls) !== null ? $.$sl.SL.Enumerable.Any$1($.$$.S.String, __ca4__) : false)
                    {
                        /*var*/ let _uri;
                        /*var*/ let uri = $.$sl.SL.Enumerable.First$1($.$$.S.String, fstream.MediaUrls);
                        if ($.$spu.S.Uri.TryCreate(uri, $.$ref(() => (() =>
                        {
                            //new $.$spu.S.UriCreationOptions()
                            const $t3 = $.$spu.S.UriCreationOptions;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })(), ), $.$ref(() => _uri, ($v) => _uri = $v, $.$spu.S.Uri)))
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, _uri);
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73014815600)
            
            //--TRIMMABLE-BOUNDARY-START(4299526917)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamProvider<LivingThing.Core.Community.TV.Free.Movies.FreeMovieStream>.GetStreams(LivingThing.Core.Community.TV.Common.Services.TVPlayerServices, LivingThing.Core.Community.TV.Common.Services.IStreamCategory?)
            LCCTCS$IStreamProvider$$$GetStreams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299526917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStreams(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4299526917)
            
            //--TRIMMABLE-BOUNDARY-START(12889395973)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamProvider.GetCategories(LivingThing.Core.Community.TV.Common.Services.TVPlayerServices)
            LCCTCS$IStreamProvider$GetCategories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889395973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCategories(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12889395973)
            
            //--TRIMMABLE-BOUNDARY-START(17184363269)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamProvider.GetInfo(LivingThing.Core.Community.TV.Common.Services.TVPlayerServices, LivingThing.Core.Community.TV.Common.Services.IStream)
            LCCTCS$IStreamProvider$GetInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184363269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17184363269)
            
            //--TRIMMABLE-BOUNDARY-START(21479330565)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamProvider.GetPermission(LivingThing.Core.Community.TV.Common.Services.TVPlayerServices, LivingThing.Core.Community.TV.Common.Services.IStream)
            LCCTCS$IStreamProvider$GetPermission()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479330565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPermission(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21479330565)
            
            //--TRIMMABLE-BOUNDARY-START(30069265157)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamProvider.GetStreamUri(LivingThing.Core.Community.TV.Common.Services.TVPlayerServices, LivingThing.Core.Community.TV.Common.Services.IStream)
            LCCTCS$IStreamProvider$GetStreamUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30069265157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStreamUri(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30069265157)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180240752)
                this.freeMovieStreams = null;
                //--TRIMMABLE-BOUNDARY-END(17180240752)
                
            }
            static $h = 371568;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103079586672),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950044528,
        "f": 50331649
      },
      "n": "Name",
      "d": 371568,
      "h": 103079586672,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079586672),
//--TRIMMABLE-BOUNDARY-START(111669521264),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539979120,
        "f": 50331649
      },
      "n": "Title",
      "d": 371568,
      "h": 111669521264,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669521264),
//--TRIMMABLE-BOUNDARY-START(12885273456),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770175344,
        "f": 50331649
      },
      "n": "Description",
      "d": 371568,
      "h": 12885273456,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885273456),
//--TRIMMABLE-BOUNDARY-START(77309782896),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360109936,
        "f": 50331649
      },
      "n": "Icon",
      "d": 371568,
      "h": 77309782896,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309782896),
//--TRIMMABLE-BOUNDARY-START(98784619376),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194684784,
        "f": 50331650
      },
      "n": "{4494085}.StreamType",
      "o": "LCCTCS$IStreamProvider$StreamType",
      "d": 371568,
      "h": 98784619376,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98784619376)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68719848304),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$rAPp.LCCTFM.FreeMovieStream).$h,
      "p": [
        {
          "n": "tvplayer",
          "p": 5739269
        },
        {
          "n": "category",
          "p": 4231941
        }
      ],
      "n": "GetStreams",
      "d": 371568,
      "h": 68719848304,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719848304),
//--TRIMMABLE-BOUNDARY-START(55834946416),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$ZaYa.LCCTCS.IStreamCategory).$h,
      "p": [
        {
          "n": "tvplayer",
          "p": 5739269
        }
      ],
      "n": "GetCategories",
      "d": 371568,
      "h": 55834946416,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834946416),
//--TRIMMABLE-BOUNDARY-START(60129913712),
    {
      "r": $.$$.STT.ValueTask$$($.$ZaYa.LCCTCS.IStreamInfo).$h,
      "p": [
        {
          "n": "tvplayer",
          "p": 5739269
        },
        {
          "n": "stream",
          "p": 4166405
        }
      ],
      "n": "GetInfo",
      "d": 371568,
      "h": 60129913712,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129913712),
//--TRIMMABLE-BOUNDARY-START(64424881008),
    {
      "r": 5477125,
      "p": [
        {
          "n": "tvplayer",
          "p": 5739269
        },
        {
          "n": "stream",
          "p": 4166405
        }
      ],
      "n": "GetPermission",
      "d": 371568,
      "h": 64424881008,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424881008),
//--TRIMMABLE-BOUNDARY-START(73014815600),
    {
      "r": $.$$.STT.ValueTask$$($.$spu.S.Uri).$h,
      "p": [
        {
          "n": "tvplayer",
          "p": 5739269
        },
        {
          "n": "stream",
          "p": 4166405
        }
      ],
      "n": "GetStreamUri",
      "d": 371568,
      "h": 73014815600,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(73014815600)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(107374553968),
    {
      "t": 1309651,
      "n": "server",
      "d": 371568,
      "h": 107374553968,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(107374553968),
//--TRIMMABLE-BOUNDARY-START(17180240752),
    {
      "t": $.$$.SCG.IEnumerable$$($.$rAPp.LCCTFM.FreeMovieStream).$h,
      "n": "freeMovieStreams",
      "d": 371568,
      "h": 17180240752,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180240752)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590306160),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 371568,
      "h": 8590306160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590306160)
  ],
  "h": 371568
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ZaYa.LCCTCS.IStreamProvider$$($.$rAPp.LCCTFM.FreeMovieStream), $.$ZaYa.LCCTCS.IVODStreamProvider, $.$ZaYa.LCCTCS.IStreamProvider$$($.$ZaYa.LCCTCS.IVODStream), $.$ZaYa.LCCTCS.IStreamProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Free.Movies.FreeMovieStreamProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Free${separator}Movies${separator}FreeMovieStreamProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(371568)
        
        

        //--TRIMMABLE-BOUNDARY-START(240496)
        $asm.$cls(`$rAPp.LCCTFL.FreeLiveTVStreamProvider`, ($self) => class FreeLiveTVStreamProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(111669390192)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(111669390192)
            
            //--TRIMMABLE-BOUNDARY-START(17180109680)
            /*IEnumerable<FreeLiveTVStream>?*/ freeLiveTVStreams = null;
            //--TRIMMABLE-BOUNDARY-END(17180109680)
            
            //--TRIMMABLE-BOUNDARY-START(8590175088)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590175088);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590175088)
            
            //--TRIMMABLE-BOUNDARY-START(107374422896)
            /*string */ get Name()
            {
                return "FreeLiveTVs";
            }
            //--TRIMMABLE-BOUNDARY-END(107374422896)
            
            //--TRIMMABLE-BOUNDARY-START(115964357488)
            /*string? */ get Title()
            {
                return "Free Live TV";
            }
            //--TRIMMABLE-BOUNDARY-END(115964357488)
            
            //--TRIMMABLE-BOUNDARY-START(12885142384)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(12885142384)
            
            //--TRIMMABLE-BOUNDARY-START(77309651824)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-youtube-tv"/*TVPlayerServices.FreeLiveTVsIcon*/);
            }
            //--TRIMMABLE-BOUNDARY-END(77309651824)
            
            //--TRIMMABLE-BOUNDARY-START(103079455600)
            /*Type */ get LCCTCS$IStreamProvider$StreamType()
            {
                return $.$rAPp.LCCTFL.FreeLiveTVStream.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(103079455600)
            
            //--TRIMMABLE-BOUNDARY-START(68719717232)
            /*Pager<FreeLiveTVStream> */ GetStreams(/*TVPlayerServices*/ tvplayer, /*IStreamCategory?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719717232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ZaYa.LCCTCS.TVPlayerServices.GetPager($.$rAPp.LCCTFL.FreeLiveTVStream, new ($.$$.S.Func$$$($.$fPer.LCFCD.DataFilter, $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$rAPp.LCCTFL.FreeLiveTVStream))))().$ctor(this, /*async*/  (/*filter*/ filter) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$rAPp.LCCTFL.FreeLiveTVStream)), $.$$.SCG.IEnumerable$$($.$rAPp.LCCTFL.FreeLiveTVStream), async ($asnycContext) => 
                    {
                        let $t1, $r1;
                        if (this.freeLiveTVStreams !== null)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, this.freeLiveTVStreams);
                        }
                        /*var*/ let m3u = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$$.S.String, this.server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ZaYa.LCCTCS.ICommunityTVRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server.LCCTCS$ICommunityTVRemoteService$GetFreeLiveTVsM3U();
                        }, $DovqEb ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)).$h,"p":[{"n":"server","p":3248901}],"n":"","d":240496,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, this.freeLiveTVStreams = $.$fPer.LCFCS$3.M3UPlaylistProvider.Parse($.$rAPp.LCCTFL.FreeLiveTVStream, m3u, null));
                    });
                }, $QCLwpc ??= {"r":$.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$rAPp.LCCTFL.FreeLiveTVStream)).$h,"p":[{"n":"filter","p":9734486}],"n":"","d":240496,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$rAPp.LCCTFL.FreeLiveTVStream, $.$$.S.Boolean))().$ctor(this,  (/*tv*/ tv) =>
                {
                    if (category !== null)
                    {
                        if (category.LCCTCS$IStreamCategory$CategoryName === "_Uncategorized" && $.$$.S.String.IsNullOrEmpty(tv.CategoryId))
                        {
                            return true;
                        }
                        /*string?*/ let __ca1__;
                        return ((__ca1__ = tv.CategoryId) !== null ? $.$$.S.String.Equals$2.call(__ca1__, category.LCCTCS$IStreamCategory$CategoryName, 3/*StringComparison.InvariantCultureIgnoreCase*/) : false);
                    }
                    return true;
                }, $uRPMEe ??= {"r":262145,"p":[{"n":"tv","p":174960}],"n":"","d":240496,"h":0,"f":17825794}), new ($.$$.S.Action$$($.$$.SCG.IEnumerable$$($.$rAPp.LCCTFL.FreeLiveTVStream)))().$ctor(this,  (/*tvs*/ tvs) =>
                {
                    if (tvs !== null && category !== null)
                    {
                        ($.$cast(category, $.$ZaYa.LCCTCS.StreamCategory)).StreamsCount = $.$sl.SL.Enumerable.Count($.$rAPp.LCCTFL.FreeLiveTVStream, tvs, new ($.$$.S.Func$$$($.$rAPp.LCCTFL.FreeLiveTVStream, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                        {
                            /*string?*/ let __ca2__;
                            return ($.$$.S.String.IsNullOrEmpty(t.CategoryId) && category.LCCTCS$IStreamCategory$CategoryName === "_Uncategorized") || (((__ca2__ = t.CategoryId) !== null ? $.$$.S.String.Equals$2.call(__ca2__, category.LCCTCS$IStreamCategory$CategoryName, 3/*StringComparison.InvariantCultureIgnoreCase*/) : false));
                        }, $NBKWph ??= {"r":262145,"p":[{"n":"t","p":174960}],"n":"","d":240496,"h":0,"f":17825794}));
                    }
                }, $gxspPi ??= {"r":65537,"p":[{"n":"tvs","p":$.$$.SCG.IEnumerable$$($.$rAPp.LCCTFL.FreeLiveTVStream).$h}],"n":"","d":240496,"h":0,"f":17825794}), null);
            }
            //--TRIMMABLE-BOUNDARY-END(68719717232)
            
            //--TRIMMABLE-BOUNDARY-START(55834815344)
            /*Pager<IStreamCategory>? */ GetCategories(/*TVPlayerServices*/ tvplayer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834815344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.Select($.$$.S.String, $.$ZaYa.LCCTCS.IStreamCategory, $.$fPer.LCFCD.Paging.OrderBy($.$$.S.String, $.$$.S.String, $.$fPer.LCFCD.Paging.Distinct($.$$.S.String, $.$fPer.LCFCD.Paging.Select($.$rAPp.LCCTFL.FreeLiveTVStream, $.$$.S.String, this.GetStreams(tvplayer, null), new ($.$$.S.Func$$$($.$rAPp.LCCTFL.FreeLiveTVStream, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                {
                    /*string?*/ let __ca3__;
                    return ((__ca3__ = s.CategoryId) !== null ? ($.$$.S.String.ToUpper.call(__ca3__) ?? "_Uncategorized") : "_Uncategorized");
                }, $bcqiLh ??= {"r":1310721,"p":[{"n":"s","p":174960}],"n":"","d":240496,"h":0,"f":17825794}))), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                {
                    return c;
                }, $tnYOMh ??= {"r":1310721,"p":[{"n":"c","p":1310721}],"n":"","d":240496,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.String, $.$ZaYa.LCCTCS.IStreamCategory))().$ctor(this,  (/*c*/ c) =>
                {
                    return (() =>
                    {
                        //new $.$ZaYa.LCCTCS.StreamCategory()
                        const $t2 = $.$ZaYa.LCCTCS.StreamCategory;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.CategoryName = c;
                        return $i2;
                    })();
                }, $QPPiTa ??= {"r":4231941,"p":[{"n":"c","p":1310721}],"n":"","d":240496,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(55834815344)
            
            //--TRIMMABLE-BOUNDARY-START(60129782640)
            /*ValueTask<IStreamInfo?> */ GetInfo(/*TVPlayerServices*/ tvplayer, /*IStream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129782640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$ZaYa.LCCTCS.IStreamInfo, $.$cast(stream, $.$rAPp.LCCTFL.FreeLiveTVStream));
            }
            //--TRIMMABLE-BOUNDARY-END(60129782640)
            
            //--TRIMMABLE-BOUNDARY-START(81604619120)
            /*ValueTask<IEnumerable<IStreamEPG>?> */ LCCTCS$ILiveStreamProvider$GetEPG(/*ILiveStream*/ stream, /*int?*/ limit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604619120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.SCG.IEnumerable$$($.$ZaYa.LCCTCS.IStreamEPG), null);
            }
            //--TRIMMABLE-BOUNDARY-END(81604619120)
            
            //--TRIMMABLE-BOUNDARY-START(85899586416)
            /*Pager<ILiveStream> */ LCCTCS$IStreamProvider$$$GetStreams(/*TVPlayerServices*/ tvplayer, /*IStreamCategory?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899586416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.Cast$1($.$rAPp.LCCTFL.FreeLiveTVStream, $.$ZaYa.LCCTCS.ILiveStream, this.GetStreams(tvplayer, category));
            }
            //--TRIMMABLE-BOUNDARY-END(85899586416)
            
            //--TRIMMABLE-BOUNDARY-START(98784488304)
            /*Pager<IStream>? */ LCCTCS$IStreamProvider$GetStreams(/*TVPlayerServices*/ tvplayer, /*IStreamCategory?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784488304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.Cast$1($.$rAPp.LCCTFL.FreeLiveTVStream, $.$ZaYa.LCCTCS.IStream, this.GetStreams(tvplayer, category));
            }
            //--TRIMMABLE-BOUNDARY-END(98784488304)
            
            //--TRIMMABLE-BOUNDARY-START(73014684528)
            /*ValueTask<Uri?> *//*async*/  GetStreamUri(/*TVPlayerServices*/ tvplayer, /*IStream*/ stream)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$spu.S.Uri), $.$spu.S.Uri, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014684528);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!tvplayer.ValidateMemberShip("Cub Membership"/*TVPlayerServices.CubClubMembershipName*/))
                    {
                        throw new $.$ZaYa.LCCTCS.MembershipAccessException().$ctor$5("Access denied");
                    }
                    /*var*/ let fstream = $.$cast(stream, $.$rAPp.LCCTFL.FreeLiveTVStream);
                    /*System.Collections.Generic.IEnumerable<string>?*/ let __ca4__;
                    if ((__ca4__ = fstream.MediaUrls) !== null ? $.$sl.SL.Enumerable.Any$1($.$$.S.String, __ca4__) : false)
                    {
                        /*var*/ let _uri;
                        /*var*/ let uri = $.$sl.SL.Enumerable.First$1($.$$.S.String, fstream.MediaUrls);
                        if ($.$spu.S.Uri.TryCreate(uri, $.$ref(() => (() =>
                        {
                            //new $.$spu.S.UriCreationOptions()
                            const $t3 = $.$spu.S.UriCreationOptions;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })(), ), $.$ref(() => _uri, ($v) => _uri = $v, $.$spu.S.Uri)))
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, _uri);
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73014684528)
            
            //--TRIMMABLE-BOUNDARY-START(64424749936)
            /*StreamPermission */ GetPermission(/*TVPlayerServices*/ tvplayer, /*IStream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424749936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 1/*StreamPermission.Play*/;
            }
            //--TRIMMABLE-BOUNDARY-END(64424749936)
            
            //--TRIMMABLE-BOUNDARY-START(4299526917)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamProvider<LivingThing.Core.Community.TV.Free.LiveTVs.FreeLiveTVStream>.GetStreams(LivingThing.Core.Community.TV.Common.Services.TVPlayerServices, LivingThing.Core.Community.TV.Common.Services.IStreamCategory?)
            LCCTCS$IStreamProvider$$$GetStreams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299526917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStreams(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4299526917)
            
            //--TRIMMABLE-BOUNDARY-START(12889395973)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamProvider.GetCategories(LivingThing.Core.Community.TV.Common.Services.TVPlayerServices)
            LCCTCS$IStreamProvider$GetCategories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889395973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCategories(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12889395973)
            
            //--TRIMMABLE-BOUNDARY-START(17184363269)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamProvider.GetInfo(LivingThing.Core.Community.TV.Common.Services.TVPlayerServices, LivingThing.Core.Community.TV.Common.Services.IStream)
            LCCTCS$IStreamProvider$GetInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184363269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17184363269)
            
            //--TRIMMABLE-BOUNDARY-START(21479330565)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamProvider.GetPermission(LivingThing.Core.Community.TV.Common.Services.TVPlayerServices, LivingThing.Core.Community.TV.Common.Services.IStream)
            LCCTCS$IStreamProvider$GetPermission()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479330565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPermission(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21479330565)
            
            //--TRIMMABLE-BOUNDARY-START(30069265157)
            //Generated interface implemetation for LivingThing.Core.Community.TV.Common.Services.IStreamProvider.GetStreamUri(LivingThing.Core.Community.TV.Common.Services.TVPlayerServices, LivingThing.Core.Community.TV.Common.Services.IStream)
            LCCTCS$IStreamProvider$GetStreamUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30069265157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStreamUri(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30069265157)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180109680)
                this.freeLiveTVStreams = null;
                //--TRIMMABLE-BOUNDARY-END(17180109680)
                
            }
            static $h = 240496;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107374422896),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949913456,
        "f": 50331649
      },
      "n": "Name",
      "d": 240496,
      "h": 107374422896,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374422896),
//--TRIMMABLE-BOUNDARY-START(115964357488),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539848048,
        "f": 50331649
      },
      "n": "Title",
      "d": 240496,
      "h": 115964357488,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964357488),
//--TRIMMABLE-BOUNDARY-START(12885142384),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770044272,
        "f": 50331649
      },
      "n": "Description",
      "d": 240496,
      "h": 12885142384,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885142384),
//--TRIMMABLE-BOUNDARY-START(77309651824),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359978864,
        "f": 50331649
      },
      "n": "Icon",
      "d": 240496,
      "h": 77309651824,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309651824),
//--TRIMMABLE-BOUNDARY-START(103079455600),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489521008,
        "f": 50331650
      },
      "n": "{4494085}.StreamType",
      "o": "LCCTCS$IStreamProvider$StreamType",
      "d": 240496,
      "h": 103079455600,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(103079455600)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68719717232),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$rAPp.LCCTFL.FreeLiveTVStream).$h,
      "p": [
        {
          "n": "tvplayer",
          "p": 5739269
        },
        {
          "n": "category",
          "p": 4231941
        }
      ],
      "n": "GetStreams",
      "d": 240496,
      "h": 68719717232,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719717232),
//--TRIMMABLE-BOUNDARY-START(55834815344),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$ZaYa.LCCTCS.IStreamCategory).$h,
      "p": [
        {
          "n": "tvplayer",
          "p": 5739269
        }
      ],
      "n": "GetCategories",
      "d": 240496,
      "h": 55834815344,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834815344),
//--TRIMMABLE-BOUNDARY-START(60129782640),
    {
      "r": $.$$.STT.ValueTask$$($.$ZaYa.LCCTCS.IStreamInfo).$h,
      "p": [
        {
          "n": "tvplayer",
          "p": 5739269
        },
        {
          "n": "stream",
          "p": 4166405
        }
      ],
      "n": "GetInfo",
      "d": 240496,
      "h": 60129782640,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129782640),
//--TRIMMABLE-BOUNDARY-START(73014684528),
    {
      "r": $.$$.STT.ValueTask$$($.$spu.S.Uri).$h,
      "p": [
        {
          "n": "tvplayer",
          "p": 5739269
        },
        {
          "n": "stream",
          "p": 4166405
        }
      ],
      "n": "GetStreamUri",
      "d": 240496,
      "h": 73014684528,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(73014684528),
//--TRIMMABLE-BOUNDARY-START(64424749936),
    {
      "r": 5477125,
      "p": [
        {
          "n": "tvplayer",
          "p": 5739269
        },
        {
          "n": "stream",
          "p": 4166405
        }
      ],
      "n": "GetPermission",
      "d": 240496,
      "h": 64424749936,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424749936)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(111669390192),
    {
      "t": 1309651,
      "n": "server",
      "d": 240496,
      "h": 111669390192,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(111669390192),
//--TRIMMABLE-BOUNDARY-START(17180109680),
    {
      "t": $.$$.SCG.IEnumerable$$($.$rAPp.LCCTFL.FreeLiveTVStream).$h,
      "n": "freeLiveTVStreams",
      "d": 240496,
      "h": 17180109680,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180109680)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590175088),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 240496,
      "h": 8590175088,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590175088)
  ],
  "h": 240496
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ZaYa.LCCTCS.IStreamProvider$$($.$rAPp.LCCTFL.FreeLiveTVStream), $.$ZaYa.LCCTCS.ILiveStreamProvider, $.$ZaYa.LCCTCS.IStreamProvider$$($.$ZaYa.LCCTCS.ILiveStream), $.$ZaYa.LCCTCS.IStreamProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.TV.Free.LiveTVs.FreeLiveTVStreamProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}TV${separator}Free${separator}LiveTVs${separator}FreeLiveTVStreamProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(240496)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.Newtonsoft.Json", "NetJs.TMDbLib", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Local", "NetJs.LivingThing.Core.Community.TV.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(43888)
