
//--TRIMMABLE-BOUNDARY-START(12058)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $jlvo, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $GYJg, $PZCj, $PIIp, $dRBU) {
    "use strict";
    let _;
    let $HIGwtc;
    let $FYTndl;
    let $bJVUte;
    let $qHSftg;
    let $uoLSkc;
    let $oofAFc;
    let $JOLKzf;
    let $qlhkJd;
    let $yydeBk;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Thrift.Client.Blazor", 
    {
  "h": 12058,
  "f": "LivingThing.Core.Community.Thrift.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Thrift.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Thrift.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(143130)
        $asm.$cls(`$uXRA.LCCTC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295110426)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295110426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$uXRA.LCCTC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295110426)
            
            static $h = 143130;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295110426),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 143130,
      "h": 4295110426,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295110426)
  ],
  "h": 143130
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(143130)
        
        

        //--TRIMMABLE-BOUNDARY-START(339738)
        $asm.$cls(`$uXRA.LCCTC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590274330)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590274330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$uXRA.LCCTCS.CommunityThriftService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$uXRA.LCCTCS.CommunityThriftApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uXRA.LCCTCS.CommunityThriftApplication, x);
                }, $FYTndl ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":339738,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uXRA.LCCTCS.CommunityThriftApplication, x);
                }, $bJVUte ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":339738,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$LCOv.LCFCPM.IAccountMembershipIntegrationBase, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCSM.ICommunityMembershipProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCSM.ICommunityMembershipFeatureProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCSM.ICommunityMembershipAccountProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$uXRA.LCCTCS.CommunityGroupThriftApplicationProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uXRA.LCCTCS.CommunityGroupThriftApplicationProvider, x);
                }, $qHSftg ??= {"r":16815552,"p":[{"n":"x","p":327718}],"n":"","d":339738,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uXRA.LCCTCS.CommunityGroupThriftApplicationProvider, x);
                }, $uoLSkc ??= {"r":765342,"p":[{"n":"x","p":327718}],"n":"","d":339738,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCSM.ICommunityMembershipAccountProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uXRA.LCCTCS.CommunityGroupThriftApplicationProvider, x);
                }, $oofAFc ??= {"r":$.$ahDc.LCCCSM.ICommunityMembershipAccountProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":339738,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCSM.ICommunityMembershipFeatureProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uXRA.LCCTCS.CommunityGroupThriftApplicationProvider, x);
                }, $JOLKzf ??= {"r":$.$ahDc.LCCCSM.ICommunityMembershipFeatureProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":339738,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCSM.ICommunityMembershipProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uXRA.LCCTCS.CommunityGroupThriftApplicationProvider, x);
                }, $qlhkJd ??= {"r":29267392,"p":[{"n":"x","p":327718}],"n":"","d":339738,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$LCOv.LCFCPM.IAccountMembershipIntegrationBase))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uXRA.LCCTCS.CommunityGroupThriftApplicationProvider, x);
                }, $yydeBk ??= {"r":6089140,"p":[{"n":"x","p":327718}],"n":"","d":339738,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$uXRA.LCCTCS.CommunityThriftFeedProvider, services);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel, services, null);
                $.$uXRA.LCCTC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590274330)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$uXRA.LCCTC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295307034)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295307034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295307034)
            
            //--TRIMMABLE-BOUNDARY-START(4295307034)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295307034)
            
            static $h = 339738;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590274330),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 339738,
      "h": 8590274330,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590274330)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295307034),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 339738,
      "h": 4295307034,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295307034)
  ],
  "h": 339738
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(339738)
        
        

        //--TRIMMABLE-BOUNDARY-START(208666)
        $asm.$cls(`$uXRA.LCCTC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180077850)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$uXRA.LCCTCP.CommunityThriftApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$uXRA.LCCTCP.CommunityThriftApp().$ctor$6();
                    }, $HIGwtc ??= {"r":2752627,"n":"","d":208666,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180077850)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295175962)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295175962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295175962)
            
            //--TRIMMABLE-BOUNDARY-START(4295175962)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295175962)
            
            static $h = 208666;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180077850),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885110554,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 208666,
      "h": 17180077850,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180077850)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295175962),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 208666,
      "h": 4295175962,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295175962)
  ],
  "h": 208666
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(208666)
        
        

        //--TRIMMABLE-BOUNDARY-START(667418)
        $asm.$cls(`$uXRA.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295634714)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295634714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295634714)
            
            //--TRIMMABLE-BOUNDARY-START(4295634714)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295634714)
            
            static $h = 667418;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295634714),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 667418,
      "h": 4295634714,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295634714)
  ],
  "h": 667418
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(667418)
        
        

        //--TRIMMABLE-BOUNDARY-START(732954)
        $asm.$cls(`$uXRA.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295700250)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295700250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295700250)
            
            //--TRIMMABLE-BOUNDARY-START(4295700250)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295700250)
            
            static $h = 732954;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295700250),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 732954,
      "h": 4295700250,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295700250)
  ],
  "h": 732954,
  "a": [
    {
      "t": 667418,
      "c": 4295634714
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(732954)
        
        

        //--TRIMMABLE-BOUNDARY-START(77594)
        $asm.$cls(`$uXRA.LCCTC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590012186)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590012186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590012186)
            
            //--TRIMMABLE-BOUNDARY-START(4295044890)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295044890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295044890)
            
            //--TRIMMABLE-BOUNDARY-START(4295044890)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295044890)
            
            static $h = 77594;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590012186),
    {
      "r": 65537,
      "n": "Execute",
      "d": 77594,
      "h": 8590012186,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590012186)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295044890),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 77594,
      "h": 4295044890,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295044890)
  ],
  "h": 77594
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(77594)
        
        

        //--TRIMMABLE-BOUNDARY-START(536346)
        $asm.$cls(`$uXRA.LCCTCS.CommunityThriftFeedProvider`, ($self) => class CommunityThriftFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295503642)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295503642);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295503642)
            
            //--TRIMMABLE-BOUNDARY-START(8590470938)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityThriftContributionGroupModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590470938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`created an Thrift`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590470938)
            
            static $h = 536346;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590470938),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 561741
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 536346,
      "h": 8590470938,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590470938)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295503642),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 536346,
      "h": 4295503642,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295503642)
  ],
  "h": 536346
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Client.Services.CommunityThriftFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Client${separator}Services${separator}CommunityThriftFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(536346)
        
        

        //--TRIMMABLE-BOUNDARY-START(470810)
        $asm.$cls(`$uXRA.LCCTCS.CommunityThriftApplication`, ($self) => class CommunityThriftApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885372698)
            $ctor$5(/*CommunityThriftService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885372698);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885372698)
            
            //--TRIMMABLE-BOUNDARY-START(137439424282)
            /*string */ get Name()
            {
                return "Thrift";
            }
            //--TRIMMABLE-BOUNDARY-END(137439424282)
            
            //--TRIMMABLE-BOUNDARY-START(158914260762)
            /*string */ get Title()
            {
                return "Package Thrift";
            }
            //--TRIMMABLE-BOUNDARY-END(158914260762)
            
            //--TRIMMABLE-BOUNDARY-START(21475307290)
            /*string */ get Description()
            {
                return "Post a Thrift agent, send, track and receive a package from the comfort of your phone.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475307290)
            
            //--TRIMMABLE-BOUNDARY-START(133144456986)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-package"/*MaterialDesignIconNames.Package*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144456986)
            
            //--TRIMMABLE-BOUNDARY-START(154619293466)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2E669B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619293466)
            
            //--TRIMMABLE-BOUNDARY-START(30065241882)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065241882)
            
            //--TRIMMABLE-BOUNDARY-START(17180339994)
            /*Type? */ get ApplicationViewType()
            {
                return $.$uXRA.LCCTCP.CommunityThriftApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180339994)
            
            //--TRIMMABLE-BOUNDARY-START(128849489690)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849489690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$uXRA.LCCTCP.CommunityThriftApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849489690)
            
            //--TRIMMABLE-BOUNDARY-START(25770274586)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770274586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770274586)
            
            //--TRIMMABLE-BOUNDARY-START(146029358874)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029358874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029358874)
            
            //--TRIMMABLE-BOUNDARY-START(141734391578)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734391578)
            
            //--TRIMMABLE-BOUNDARY-START(4295438106)
            /*CommunityThriftService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295438106)
            
            //--TRIMMABLE-BOUNDARY-START(150324326170)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(150324326170)
            
            //--TRIMMABLE-BOUNDARY-START(163209228058)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(10240/*PostTypes.GroupThrift*/, 10243/*PostTypes.GroupThriftEnd*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209228058)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 470810;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439424282),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604849434,
        "f": 50364417
      },
      "n": "Name",
      "d": 470810,
      "h": 137439424282,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439424282),
//--TRIMMABLE-BOUNDARY-START(158914260762),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964587802,
        "f": 50364417
      },
      "n": "Title",
      "d": 470810,
      "h": 158914260762,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914260762),
//--TRIMMABLE-BOUNDARY-START(21475307290),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835045658,
        "f": 50364417
      },
      "n": "Description",
      "d": 470810,
      "h": 21475307290,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475307290),
//--TRIMMABLE-BOUNDARY-START(133144456986),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014914842,
        "f": 50364417
      },
      "n": "Icon",
      "d": 470810,
      "h": 133144456986,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144456986),
//--TRIMMABLE-BOUNDARY-START(154619293466),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374653210,
        "f": 50364417
      },
      "n": "Theme",
      "d": 470810,
      "h": 154619293466,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619293466),
//--TRIMMABLE-BOUNDARY-START(30065241882),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424980250,
        "f": 50364417
      },
      "n": "Features",
      "d": 470810,
      "h": 30065241882,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065241882),
//--TRIMMABLE-BOUNDARY-START(17180339994),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245111066,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 470810,
      "h": 17180339994,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180339994),
//--TRIMMABLE-BOUNDARY-START(141734391578),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194784026,
        "f": 50364417
      },
      "n": "Order",
      "d": 470810,
      "h": 141734391578,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734391578),
//--TRIMMABLE-BOUNDARY-START(4295438106),
    {
      "p": 601882,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655176474,
        "f": 50331650
      },
      "n": "_Service",
      "d": 470810,
      "h": 4295438106,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295438106),
//--TRIMMABLE-BOUNDARY-START(150324326170),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784718618,
        "f": 50364417
      },
      "n": "Service",
      "d": 470810,
      "h": 150324326170,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324326170),
//--TRIMMABLE-BOUNDARY-START(163209228058),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554522394,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 470810,
      "h": 163209228058,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209228058)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849489690),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 470810,
      "h": 128849489690,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849489690),
//--TRIMMABLE-BOUNDARY-START(25770274586),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 470810,
      "h": 25770274586,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770274586),
//--TRIMMABLE-BOUNDARY-START(146029358874),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 470810,
      "h": 146029358874,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029358874)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885372698),
    {
      "p": [
        {
          "n": "service",
          "p": 601882
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 470810,
      "h": 12885372698,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885372698)
  ],
  "h": 470810
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Client.Services.CommunityThriftApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Client${separator}Services${separator}CommunityThriftApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(470810)
        
        

        //--TRIMMABLE-BOUNDARY-START(405274)
        $asm.$cls(`$uXRA.LCCTCS.CommunityGroupThriftApplicationProvider`, ($self) => class CommunityGroupThriftApplicationProvider extends $.$PIIp.LCCGCS.CommunityGroupTypeHandlerBase$$$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel, $.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates)
        {
            //--TRIMMABLE-BOUNDARY-START(133144391450)
            /*PostTypes */ get Type()
            {
                return 10242/*PostTypes.GroupThriftContribution*/;
            }
            //--TRIMMABLE-BOUNDARY-END(133144391450)
            
            //--TRIMMABLE-BOUNDARY-START(12885307162)
            /*IEnumerable<PostTypes> */ get AccountsType()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostTypes), [10242/*PostTypes.GroupThriftContribution*/], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(12885307162)
            
            //--TRIMMABLE-BOUNDARY-START(107374587674)
            /*string */ get Id()
            {
                return "Thrift";
            }
            //--TRIMMABLE-BOUNDARY-END(107374587674)
            
            //--TRIMMABLE-BOUNDARY-START(115964522266)
            /*string */ get PostsName()
            {
                return "Contrbutions";
            }
            //--TRIMMABLE-BOUNDARY-END(115964522266)
            
            //--TRIMMABLE-BOUNDARY-START(120259489562)
            /*IEnumerable<ICommunityApplicationServiceCategory>?*/ ServiceCategories = null;
            //--TRIMMABLE-BOUNDARY-END(120259489562)
            
            //--TRIMMABLE-BOUNDARY-START(128849424154)
            /*string? */ get Title()
            {
                return "Thrift";
            }
            //--TRIMMABLE-BOUNDARY-END(128849424154)
            
            //--TRIMMABLE-BOUNDARY-START(103079620378)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-cash"/*MaterialDesignIconNames.Cash*/);
            }
            //--TRIMMABLE-BOUNDARY-END(103079620378)
            
            //--TRIMMABLE-BOUNDARY-START(111669554970)
            /*string? */ get Name()
            {
                return "Thrift";
            }
            //--TRIMMABLE-BOUNDARY-END(111669554970)
            
            //--TRIMMABLE-BOUNDARY-START(124554456858)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#8E9633";
                    $i1.ForegroundColor = "#FFFFFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(124554456858)
            
            //--TRIMMABLE-BOUNDARY-START(98784653082)
            /*RenderFragment? */ GetGroupSynopsis(/*AccountBaseModel*/ group)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784653082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(98784653082)
            
            //--TRIMMABLE-BOUNDARY-START(94489685786)
            /*RenderFragment? */ GetGroupPages(/*AccountBaseModel*/ group)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489685786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(94489685786)
            
            //--TRIMMABLE-BOUNDARY-START(8590339866)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590339866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590339866)
            
            //--TRIMMABLE-BOUNDARY-START(8590339866)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590339866)
            
            static $h = 405274;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PIIp.LCCGCS.CommunityGroupTypeHandlerBase$$$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel, $.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133144391450),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194718490,
        "f": 50364417
      },
      "n": "Type",
      "d": 405274,
      "h": 133144391450,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144391450),
//--TRIMMABLE-BOUNDARY-START(12885307162),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475241754,
        "f": 50364417
      },
      "n": "AccountsType",
      "d": 405274,
      "h": 12885307162,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885307162),
//--TRIMMABLE-BOUNDARY-START(107374587674),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655110938,
        "f": 50364417
      },
      "n": "Id",
      "d": 405274,
      "h": 107374587674,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107374587674),
//--TRIMMABLE-BOUNDARY-START(115964522266),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834980122,
        "f": 50364417
      },
      "n": "PostsName",
      "d": 405274,
      "h": 115964522266,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115964522266),
//--TRIMMABLE-BOUNDARY-START(120259489562),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS.ICommunityApplicationServiceCategory).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424914714,
        "f": 50364417
      },
      "n": "ServiceCategories",
      "d": 405274,
      "h": 120259489562,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120259489562),
//--TRIMMABLE-BOUNDARY-START(128849424154),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604783898,
        "f": 50364417
      },
      "n": "Title",
      "d": 405274,
      "h": 128849424154,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128849424154),
//--TRIMMABLE-BOUNDARY-START(103079620378),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065176346,
        "f": 50364417
      },
      "n": "Icon",
      "d": 405274,
      "h": 103079620378,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(103079620378),
//--TRIMMABLE-BOUNDARY-START(111669554970),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245045530,
        "f": 50364417
      },
      "n": "Name",
      "d": 405274,
      "h": 111669554970,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(111669554970),
//--TRIMMABLE-BOUNDARY-START(124554456858),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014849306,
        "f": 50364417
      },
      "n": "Theme",
      "d": 405274,
      "h": 124554456858,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(124554456858)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98784653082),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetGroupSynopsis",
      "d": 405274,
      "h": 98784653082,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98784653082),
//--TRIMMABLE-BOUNDARY-START(94489685786),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetGroupPages",
      "d": 405274,
      "h": 94489685786,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489685786)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590339866),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 405274,
      "h": 8590339866,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590339866)
  ],
  "h": 405274
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler$$$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel, $.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates), $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, $.$ydCm.LCCCS.ICommunityApplicationSubService, $.$yleQ.LCFCA.IApplicationSubService, $.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider, $.$ahDc.LCCCSM.ICommunityMembershipAccountProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$ahDc.LCCCSM.ICommunityMembershipFeatureProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel), $.$ahDc.LCCCSM.ICommunityMembershipProvider, $.$LCOv.LCFCPM.IAccountMembershipIntegrationBase, $.$LCOv.LCFCPS.IPostFeatureProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel), $.$LCOv.LCFCPS.IPostFeatureProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Client.Services.CommunityGroupThriftApplicationProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Client${separator}Services${separator}CommunityGroupThriftApplicationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(405274)
        
        

        //--TRIMMABLE-BOUNDARY-START(274202)
        $asm.$cls(`$uXRA.LCCTCP.CommunityThriftApp`, ($self) => class CommunityThriftApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$dRBU.LCCTCM.CommunityThriftUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(90194587418)
            /*CommunityThriftService*/ ThriftService = null;
            //--TRIMMABLE-BOUNDARY-END(90194587418)
            
            //--TRIMMABLE-BOUNDARY-START(85899620122)
            /*CommunityThriftApplication*/ ThriftApplication = null;
            //--TRIMMABLE-BOUNDARY-END(85899620122)
            
            //--TRIMMABLE-BOUNDARY-START(17180143386)
            /*ICommunityClientApplication */ get Application()
            {
                return this.ThriftApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(17180143386)
            
            //--TRIMMABLE-BOUNDARY-START(64424783642)
            /*string */ get OptimizedComponentName()
            {
                return "communitythriftapp communitydefaultpages";
            }
            //--TRIMMABLE-BOUNDARY-END(64424783642)
            
            //--TRIMMABLE-BOUNDARY-START(60129816346)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129816346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ThriftService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uXRA.LCCTCS.CommunityThriftService, serviceProvider);
                this.ThriftApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uXRA.LCCTCS.CommunityThriftApplication, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(60129816346)
            
            //--TRIMMABLE-BOUNDARY-START(21475110682)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475110682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
            }
            //--TRIMMABLE-BOUNDARY-END(21475110682)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885176090)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885176090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885176090)
            
            //--TRIMMABLE-BOUNDARY-START(12885176090)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12885176090)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(90194587418)
                this.ThriftService = null;
                //--TRIMMABLE-BOUNDARY-END(90194587418)
                
                //--TRIMMABLE-BOUNDARY-START(85899620122)
                this.ThriftApplication = null;
                //--TRIMMABLE-BOUNDARY-END(85899620122)
                
            }
            static $h = 274202;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$dRBU.LCCTCM.CommunityThriftUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90194587418),
    {
      "p": 601882,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834849050,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604652826,
        "f": 83886081
      },
      "n": "ThriftService",
      "d": 274202,
      "h": 90194587418,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194587418),
//--TRIMMABLE-BOUNDARY-START(85899620122),
    {
      "p": 470810,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244914458,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014718234,
        "f": 83886081
      },
      "n": "ThriftApplication",
      "d": 274202,
      "h": 85899620122,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85899620122),
//--TRIMMABLE-BOUNDARY-START(17180143386),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065045274,
        "f": 50364420
      },
      "n": "Application",
      "d": 274202,
      "h": 17180143386,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(17180143386),
//--TRIMMABLE-BOUNDARY-START(64424783642),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654979866,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 274202,
      "h": 64424783642,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64424783642)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60129816346),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 274202,
      "h": 60129816346,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60129816346),
//--TRIMMABLE-BOUNDARY-START(21475110682),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 274202,
      "h": 21475110682,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475110682)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885176090),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 274202,
      "h": 12885176090,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885176090)
  ],
  "h": 274202
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Client.Pages.CommunityThriftApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Client${separator}Pages${separator}CommunityThriftApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(274202)
        
        

        //--TRIMMABLE-BOUNDARY-START(601882)
        $asm.$cls(`$uXRA.LCCTCS.CommunityThriftService`, ($self) => class CommunityThriftService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295569178)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295569178);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295569178)
            
            static $h = 601882;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295569178),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 601882,
      "h": 4295569178,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295569178)
  ],
  "h": 601882
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Client.Services.CommunityThriftService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Client${separator}Services${separator}CommunityThriftService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(601882)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Account.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Account.Client.Blazor", "NetJs.LivingThing.Core.Community.Group.Common", "NetJs.LivingThing.Core.Community.Group.Client.Blazor", "NetJs.LivingThing.Core.Community.Thrift.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(12058)
