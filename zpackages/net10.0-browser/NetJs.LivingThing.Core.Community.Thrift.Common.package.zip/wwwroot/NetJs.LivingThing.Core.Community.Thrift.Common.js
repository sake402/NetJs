
//--TRIMMABLE-BOUNDARY-START(37453)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm, $PZCj) {
    "use strict";
    let _;
    let $NeSsqi;
    let $nTeOGf;
    let $gTzBBf;
    let $ZcFJQb;
    let $CFcjff;
    let $rNKBrj;
    let $QisSQf;
    let $OEqegf;
    let $FphaEj;
    let $lmDtWk;
    let $cYUKTd;
    let $LxdEsa;
    let $OMFiBf;
    let $Jdlvrj;
    let $pGuumi;
    let $IxeWJc;
    let $wIJzRg;
    let $zmlywk;
    let $VoRcKc;
    let $sinJBg;
    let $sYCTnh;
    let $iFtJMj;
    let $appQtf;
    let $AhTqxf;
    let $rfdOLc;
    let $CeFYLi;
    let $dfCcYi;
    let $qBRqtj;
    let $lDvJOj;
    let $YzyiMc;
    let $kmRTTg;
    let $TVpPie;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Thrift.Common", 
    {
  "h": 37453,
  "f": "LivingThing.Core.Community.Thrift.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Thrift.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Thrift.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(889421)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftContrubutionPurposeCustomAttributesProvider`, ($self) => class CommunityThriftContrubutionPurposeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295856717)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295856717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295856717)
            
            static $h = 889421;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295856717),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 889421,
      "h": 4295856717,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295856717)
  ],
  "h": 889421
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContrubutionPurposeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftContrubutionPurposeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(889421)
        
        

        //--TRIMMABLE-BOUNDARY-START(168525)
        $asm.$cls(`$dRBU.LCCTC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295135821)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295135821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295135821)
            
            static $h = 168525;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295135821),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 168525,
      "h": 4295135821,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295135821)
  ],
  "h": 168525
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(168525)
        
        

        //--TRIMMABLE-BOUNDARY-START(2396749)
        $asm.$cls(`$dRBU.LCCTC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297364045)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297364045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModelTypeDescriptorBuilder.Register();
                $.$dRBU.LCCTCM.CommunityThriftContributionGroupModelTypeDescriptorBuilder.Register();
                $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModelTypeDescriptorBuilder.Register();
                $.$dRBU.LCCTCM.CommunityThriftModelTypeDescriptorBuilder.Register();
                $.$dRBU.LCCTCS$1.CommunityThriftContributionSettingsTypeDescriptorBuilder.Register();
                $.$dRBU.LCCTCS$2.CommunityThriftContributionStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297364045)
            
            static $h = 2396749;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297364045),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2396749,
      "h": 4297364045,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297364045)
  ],
  "h": 2396749
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2396749)
        
        

        //--TRIMMABLE-BOUNDARY-START(1020493)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftGroupCategoryModelCustomAttributesProvider`, ($self) => class CommunityThriftGroupCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295987789)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295987789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295987789)
            
            static $h = 1020493;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295987789),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1020493,
      "h": 4295987789,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295987789)
  ],
  "h": 1020493
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftGroupCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftGroupCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1020493)
        
        

        //--TRIMMABLE-BOUNDARY-START(1282637)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftModelCustomAttributesProvider`, ($self) => class CommunityThriftModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296249933)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296249933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296249933)
            
            static $h = 1282637;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296249933),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1282637,
      "h": 4296249933,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296249933)
  ],
  "h": 1282637
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1282637)
        
        

        //--TRIMMABLE-BOUNDARY-START(102989)
        $asm.$cls(`$dRBU.LCCTC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295070285)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295070285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModelCustomAttributesProvider, $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRBU.LCCTCM.CommunityThriftContributionGroupModelCustomAttributesProvider, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRBU.LCCTCM.CommunityThriftContrubutionPurpose.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRBU.LCCTCM.CommunityThriftContrubutionPurposeCustomAttributesProvider, $.$dRBU.LCCTCM.CommunityThriftContrubutionPurposeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModelCustomAttributesProvider, $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRBU.LCCTCM.CommunityThriftModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRBU.LCCTCM.CommunityThriftModelCustomAttributesProvider, $.$dRBU.LCCTCM.CommunityThriftModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRBU.LCCTCS$1.CommunityThriftContributionSettingsCustomAttributesProvider, $.$dRBU.LCCTCS$1.CommunityThriftContributionSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRBU.LCCTCS$2.CommunityThriftContributionStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRBU.LCCTCS$2.CommunityThriftContributionStatesCustomAttributesProvider, $.$dRBU.LCCTCS$2.CommunityThriftContributionStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295070285)
            
            static $h = 102989;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295070285),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 102989,
      "h": 4295070285,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295070285)
  ],
  "h": 102989
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(102989)
        
        

        //--TRIMMABLE-BOUNDARY-START(2200141)
        $asm.$cls(`$dRBU.LCCTCS$2.CommunityThriftContributionStatesCustomAttributesProvider`, ($self) => class CommunityThriftContributionStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297167437)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297167437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$2.CommunityGroupPostStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297167437)
            
            static $h = 2200141;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297167437),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2200141,
      "h": 4297167437,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297167437)
  ],
  "h": 2200141
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.States.CommunityThriftContributionStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}States${separator}CommunityThriftContributionStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2200141)
        
        

        //--TRIMMABLE-BOUNDARY-START(365133)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModelCustomAttributesProvider`, ($self) => class CommunityThriftContributionGroupMemberFeatureModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295332429)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295332429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM.AccountMembershipFeatureModelCustomAttributesProvider$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295332429)
            
            static $h = 365133;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295332429),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 365133,
      "h": 4295332429,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295332429)
  ],
  "h": 365133
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftContributionGroupMemberFeatureModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(365133)
        
        

        //--TRIMMABLE-BOUNDARY-START(234061)
        $asm.$cls(`$dRBU.LCCTC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295201357)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295201357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$dRBU.LCCTCS.ICommunityThriftFeedRemoteService, $.$dRBU.LCCTCS.ICommunityThriftFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dRBU.LCCTCS.ICommunityThriftFeedRemoteService_Mocking().$ctor$3(impl);
                }, $gTzBBf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":234061,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$dRBU.LCCTCS.ICommunityThriftFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dRBU.LCCTCS.ICommunityThriftFeedRemoteService_Mocking().$ctor$3(impl);
                }, $ZcFJQb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":234061,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$dRBU.LCCTCS.IComunityThriftRemoteService, $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking().$ctor$3(impl);
                }, $CFcjff ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":234061,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking().$ctor$3(impl);
                }, $rNKBrj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":234061,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking().$ctor$3(impl);
                }, $QisSQf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":234061,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking().$ctor$3(impl);
                }, $OEqegf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":234061,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking().$ctor$3(impl);
                }, $FphaEj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":234061,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking().$ctor$3(impl);
                }, $lmDtWk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":234061,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking().$ctor$3(impl);
                }, $cYUKTd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":234061,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking().$ctor$3(impl);
                }, $LxdEsa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":234061,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295201357)
            
            static $h = 234061;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295201357),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 234061,
      "h": 4295201357,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295201357)
  ],
  "h": 234061
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(234061)
        
        

        //--TRIMMABLE-BOUNDARY-START(1937997)
        $asm.$cls(`$dRBU.LCCTCS$1.CommunityThriftContributionSettingsCustomAttributesProvider`, ($self) => class CommunityThriftContributionSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296905293)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296905293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296905293)
            
            static $h = 1937997;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296905293),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1937997,
      "h": 4296905293,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296905293)
  ],
  "h": 1937997
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Settings.CommunityThriftContributionSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Settings${separator}CommunityThriftContributionSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1937997)
        
        

        //--TRIMMABLE-BOUNDARY-START(1413709)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftModelTypeDescriptorBuilder`, ($self) => class CommunityThriftModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591348301)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591348301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRBU.LCCTCM.CommunityThriftModelTypeDescriptor()
                        const $t1 = $.$dRBU.LCCTCM.CommunityThriftModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $NeSsqi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1413709,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRBU.LCCTCM.CommunityThriftModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591348301)
            
            //--TRIMMABLE-BOUNDARY-START(4296381005)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296381005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296381005)
            
            //--TRIMMABLE-BOUNDARY-START(4296381005)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296381005)
            
            static $h = 1413709;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591348301),
    {
      "r": 65537,
      "n": "Register",
      "d": 1413709,
      "h": 8591348301,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591348301)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296381005),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1413709,
      "h": 4296381005,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296381005)
  ],
  "h": 1413709
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1413709)
        
        

        //--TRIMMABLE-BOUNDARY-START(1151565)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftGroupCategoryModelTypeDescriptorBuilder`, ($self) => class CommunityThriftGroupCategoryModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591086157)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591086157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModelTypeDescriptor()
                        const $t1 = $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftGroupCategoryModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $sYCTnh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1151565,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591086157)
            
            //--TRIMMABLE-BOUNDARY-START(4296118861)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296118861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296118861)
            
            //--TRIMMABLE-BOUNDARY-START(4296118861)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296118861)
            
            static $h = 1151565;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591086157),
    {
      "r": 65537,
      "n": "Register",
      "d": 1151565,
      "h": 8591086157,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591086157)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296118861),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1151565,
      "h": 4296118861,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296118861)
  ],
  "h": 1151565
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftGroupCategoryModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftGroupCategoryModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1151565)
        
        

        //--TRIMMABLE-BOUNDARY-START(2331213)
        $asm.$cls(`$dRBU.LCCTCS$2.CommunityThriftContributionStatesTypeDescriptorBuilder`, ($self) => class CommunityThriftContributionStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592265805)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592265805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRBU.LCCTCS$2.CommunityThriftContributionStatesTypeDescriptor()
                        const $t1 = $.$dRBU.LCCTCS$2.CommunityThriftContributionStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Thrift.Common.States.CommunityThriftContributionStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $OMFiBf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2331213,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRBU.LCCTCS$2.CommunityThriftContributionStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592265805)
            
            //--TRIMMABLE-BOUNDARY-START(4297298509)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297298509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297298509)
            
            //--TRIMMABLE-BOUNDARY-START(4297298509)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297298509)
            
            static $h = 2331213;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592265805),
    {
      "r": 65537,
      "n": "Register",
      "d": 2331213,
      "h": 8592265805,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592265805)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297298509),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2331213,
      "h": 4297298509,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297298509)
  ],
  "h": 2331213
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.States.CommunityThriftContributionStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}States${separator}CommunityThriftContributionStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2331213)
        
        

        //--TRIMMABLE-BOUNDARY-START(2069069)
        $asm.$cls(`$dRBU.LCCTCS$1.CommunityThriftContributionSettingsTypeDescriptorBuilder`, ($self) => class CommunityThriftContributionSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592003661)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592003661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRBU.LCCTCS$1.CommunityThriftContributionSettingsTypeDescriptor()
                        const $t1 = $.$dRBU.LCCTCS$1.CommunityThriftContributionSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Thrift.Common.Settings.CommunityThriftContributionSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $wIJzRg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2069069,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592003661)
            
            //--TRIMMABLE-BOUNDARY-START(4297036365)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297036365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297036365)
            
            //--TRIMMABLE-BOUNDARY-START(4297036365)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297036365)
            
            static $h = 2069069;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592003661),
    {
      "r": 65537,
      "n": "Register",
      "d": 2069069,
      "h": 8592003661,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592003661)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297036365),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2069069,
      "h": 4297036365,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297036365)
  ],
  "h": 2069069
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Settings.CommunityThriftContributionSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Settings${separator}CommunityThriftContributionSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2069069)
        
        

        //--TRIMMABLE-BOUNDARY-START(627277)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftContributionGroupModelCustomAttributesProvider`, ($self) => class CommunityThriftContributionGroupModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295594573)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295594573)
            
            //--TRIMMABLE-BOUNDARY-START(8590561869)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590561869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dRBU.LCCTCM.CommunityThriftContributionGroupModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute), [(() =>
                        {
                            //new $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute()
                            const $t3 = $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            $i3.SettingsType = ($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings.$type);
                            $i3.StateType = ($.$dRBU.LCCTCS$2.CommunityThriftContributionStates.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i4 = new $t4();
                        $i4.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i4.set_Item("Memberships", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (1024);
                            $i5.Description = "Create membership categories that allows you to further control how each member of a thrift are handled independently";
                            $i5.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=AccountMultiple"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("Roles", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("ServiceTiers", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i4;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dRBU.LCCTCM.CommunityThriftContributionGroupModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $VoRcKc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":627277,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $sinJBg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":627277,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$PZCj.LCCGCM.CommunityGroupBasePostModelCustomAttributesProvider$$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590561869)
            
            static $h = 627277;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590561869),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 627277,
      "h": 8590561869,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590561869)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295594573),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 627277,
      "h": 4295594573,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295594573)
  ],
  "h": 627277
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftContributionGroupModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(627277)
        
        

        //--TRIMMABLE-BOUNDARY-START(496205)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModelTypeDescriptorBuilder`, ($self) => class CommunityThriftContributionGroupMemberFeatureModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590430797)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590430797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModelTypeDescriptor()
                        const $t1 = $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $pGuumi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":496205,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590430797)
            
            //--TRIMMABLE-BOUNDARY-START(4295463501)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295463501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295463501)
            
            //--TRIMMABLE-BOUNDARY-START(4295463501)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295463501)
            
            static $h = 496205;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590430797),
    {
      "r": 65537,
      "n": "Register",
      "d": 496205,
      "h": 8590430797,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590430797)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295463501),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 496205,
      "h": 4295463501,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295463501)
  ],
  "h": 496205
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftContributionGroupMemberFeatureModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(496205)
        
        

        //--TRIMMABLE-BOUNDARY-START(758349)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftContributionGroupModelTypeDescriptorBuilder`, ($self) => class CommunityThriftContributionGroupModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590692941)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590692941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRBU.LCCTCM.CommunityThriftContributionGroupModelTypeDescriptor()
                        const $t1 = $.$dRBU.LCCTCM.CommunityThriftContributionGroupModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $rfdOLc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":758349,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590692941)
            
            //--TRIMMABLE-BOUNDARY-START(4295725645)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295725645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295725645)
            
            //--TRIMMABLE-BOUNDARY-START(4295725645)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295725645)
            
            static $h = 758349;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590692941),
    {
      "r": 65537,
      "n": "Register",
      "d": 758349,
      "h": 8590692941,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590692941)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295725645),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 758349,
      "h": 4295725645,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295725645)
  ],
  "h": 758349
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftContributionGroupModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(758349)
        
        

        //--TRIMMABLE-BOUNDARY-START(1544781)
        $asm.$cls(`$dRBU.LCCTC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591479373)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591479373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel, 10241/*PostTypes.GroupThriftCategory*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel, 10242/*PostTypes.GroupThriftContribution*/);
                $.$dRBU.LCCTC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$dRBU.LCCTC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$dRBU.LCCTC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591479373)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$dRBU.LCCTC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296512077)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296512077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296512077)
            
            //--TRIMMABLE-BOUNDARY-START(4296512077)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296512077)
            
            static $h = 1544781;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591479373),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1544781,
      "h": 8591479373,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591479373)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296512077),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1544781,
      "h": 4296512077,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296512077)
  ],
  "h": 1544781
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1544781)
        
        

        //--TRIMMABLE-BOUNDARY-START(823885)
        $asm.$str(`$dRBU.LCCTCM.CommunityThriftContrubutionPurpose`, ($self) => class CommunityThriftContrubutionPurpose extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Cash = 0;
            static Purchase = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(823885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Cash": 0n,
                    "Purchase": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295791181)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295791181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295791181)
            
            //--TRIMMABLE-BOUNDARY-START(4295791181)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295791181)
            
            static $h = 823885;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590758477),
    {
      "t": 823885,
      "n": "Cash",
      "d": 823885,
      "h": 8590758477,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590758477),
//--TRIMMABLE-BOUNDARY-START(12885725773),
    {
      "t": 823885,
      "n": "Purchase",
      "d": 823885,
      "h": 12885725773,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885725773)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295791181),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 823885,
      "h": 4295791181,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295791181)
  ],
  "h": 823885
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContrubutionPurpose`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftContrubutionPurpose`; }
        });
        //--TRIMMABLE-BOUNDARY-END(823885)
        
        

        //--TRIMMABLE-BOUNDARY-START(299597)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel`, ($self) => class CommunityThriftContributionGroupMemberFeatureModel extends $.$LCOv.LCFCPM.AccountMembershipFeatureModel$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(8590234189)
            static /*CommunityThriftContributionGroupMemberFeatureModel? */ From(/*IDataModel*/ account, /*IDataModel?*/ context, /*bool?*/ createIfNotExist)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590234189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.DataPropertiesExtensions.GetFeatures($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel, ($.$cast(account, $.$Iaui.LCFCM.DataModel)), $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel.GetFeatureKey(context), createIfNotExist);
            }
            //--TRIMMABLE-BOUNDARY-END(8590234189)
            
            //--TRIMMABLE-BOUNDARY-START(12885201485)
            static /*string */ GetFeatureKey(/*IDataModel?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885201485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((context?.LCFCD$IIded$Identifier.Id ?? null) === null)
                {
                    throw new $.$$.S.NullReferenceException().$ctor$12("context required");
                }
                return $.$strNN("$"/*DataFeatureModel.PrefixIdentifier*/) + "Thrift/" + $.$strNN($.$dspc(context.LCFCD$IIded$Identifier.Id, $.$$.S.Object, ($t) => $t.ToString));
            }
            //--TRIMMABLE-BOUNDARY-END(12885201485)
            
            //--TRIMMABLE-BOUNDARY-START(17180168781)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180168781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 1/*SchemaType.Form*/)
                {
                    return $.$Iaui.LCFCM.DataFeatureModel.Exclude(descriptors, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "MembershipTier", "Id", "NINPhoto", "Verified", "NamedLocation", "Roles" ], null, null));
                }
                return super.UpdateDescriptors(descriptors, $.$clone(schema));
            }
            //--TRIMMABLE-BOUNDARY-END(17180168781)
            
            //--TRIMMABLE-BOUNDARY-START(21480729012)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Membership.IAccountMembershipFeatureModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModel>.MembershipTier.get
            get LCFCPM$IAccountMembershipFeatureModel$$$MembershipTier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51545500084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MembershipTier;
            }
            //--TRIMMABLE-BOUNDARY-END(21480729012)
            
            //--TRIMMABLE-BOUNDARY-START(12890794420)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Membership.IAccountMembershipFeatureModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModel>.FullName.get
            get LCFCPM$IAccountMembershipFeatureModel$$$FullName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300859828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FullName;
            }
            //--TRIMMABLE-BOUNDARY-END(12890794420)
            
            //--TRIMMABLE-BOUNDARY-START(38660598196)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Membership.IAccountMembershipFeatureModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModel>.ProfilePicture.get
            get LCFCPM$IAccountMembershipFeatureModel$$$ProfilePicture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60135434676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ProfilePicture;
            }
            //--TRIMMABLE-BOUNDARY-END(38660598196)
            
            //--TRIMMABLE-BOUNDARY-START(30070663604)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Membership.IAccountMembershipFeatureModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModel>.NamedLocation.get
            get LCFCPM$IAccountMembershipFeatureModel$$$NamedLocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55840467380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NamedLocation;
            }
            //--TRIMMABLE-BOUNDARY-END(30070663604)
            
            //--TRIMMABLE-BOUNDARY-START(47250532788)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Membership.IAccountMembershipFeatureModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModel>.Verified.get
            get LCFCPM$IAccountMembershipFeatureModel$$$Verified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64430401972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Verified;
            }
            //--TRIMMABLE-BOUNDARY-END(47250532788)
            
            //--TRIMMABLE-BOUNDARY-START(8607009110)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModel>.GetFeatureKey(LivingThing.Core.Frameworks.Common.Data.IDataModel?)
            static LCFCD$IDataFeatureModel$$$GetFeatureKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8607009110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel.GetFeatureKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8607009110)
            
            //--TRIMMABLE-BOUNDARY-START(4312041814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModel>.From(LivingThing.Core.Frameworks.Common.Data.IDataModel, LivingThing.Core.Frameworks.Common.Data.IDataModel?, bool?)
            static LCFCD$IDataFeatureModel$$$From()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312041814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel.From(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312041814)
            
            //--TRIMMABLE-BOUNDARY-START(4295266893)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295266893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295266893)
            
            //--TRIMMABLE-BOUNDARY-START(4295266893)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295266893)
            
            static $h = 299597;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM.AccountMembershipFeatureModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590234189),
    {
      "r": 299597,
      "p": [
        {
          "n": "account",
          "p": 17533270
        },
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        },
        {
          "n": "createIfNotExist",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65
        }
      ],
      "n": "From",
      "d": 299597,
      "h": 8590234189,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590234189),
//--TRIMMABLE-BOUNDARY-START(12885201485),
    {
      "r": 1310721,
      "p": [
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        }
      ],
      "n": "GetFeatureKey",
      "d": 299597,
      "h": 12885201485,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885201485),
//--TRIMMABLE-BOUNDARY-START(17180168781),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": 299597,
      "h": 17180168781,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180168781)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295266893),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 299597,
      "h": 4295266893,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295266893)
  ],
  "h": 299597
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$LCOv.LCFCPM.IAccountMembershipFeatureModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel), $.$fPer.LCFCD.IDataFeatureModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftContributionGroupMemberFeatureModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(299597)
        
        

        //--TRIMMABLE-BOUNDARY-START(1479245)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftUserPreference`, ($self) => class CommunityThriftUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4296446541)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296446541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296446541)
            
            //--TRIMMABLE-BOUNDARY-START(4296446541)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296446541)
            
            static $h = 1479245;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296446541),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1479245,
      "h": 4296446541,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296446541)
  ],
  "h": 1479245
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1479245)
        
        

        //--TRIMMABLE-BOUNDARY-START(430669)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModelTypeDescriptor`, ($self) => class CommunityThriftContributionGroupMemberFeatureModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295397965)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295397965);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModelTypeDescriptor.GenerateProperties($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel, this, factory);
                    }, $IxeWJc ??= {"r":65537,"n":"","d":430669,"h":0,"f":17825794}), 0, "CommunityThriftContributionGroupMemberFeatureModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Thrift.Common\\Models_CommunityThriftContributionGroupMemberFeatureModel_LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModelTypeDescriptorBuilder.g.cs", "CommunityThriftContributionGroupMemberFeatureModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295397965)
            
            //--TRIMMABLE-BOUNDARY-START(12885332557)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885332557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM.AccountMembershipFeatureModelTypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885332557)
            
            //--TRIMMABLE-BOUNDARY-START(17180299853)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180299853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Membership.AccountMembershipFeatureModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM.AccountMembershipFeatureModelTypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM.AccountMembershipFeatureModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180299853)
            
            //--TRIMMABLE-BOUNDARY-START(8590365261)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590365261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel)))
                {
                    /*var*/ let result = $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590365261)
            
            static $h = 430669;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885332557),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 430669,
      "h": 12885332557,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885332557),
//--TRIMMABLE-BOUNDARY-START(17180299853),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 299597,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 430669,
      "h": 17180299853,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180299853),
//--TRIMMABLE-BOUNDARY-START(8590365261),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 299597,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 430669,
      "h": 8590365261,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590365261)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295397965),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 430669,
      "h": 4295397965,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295397965)
  ],
  "h": 430669
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupMemberFeatureModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupMemberFeatureModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftContributionGroupMemberFeatureModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(430669)
        
        

        //--TRIMMABLE-BOUNDARY-START(2134605)
        $asm.$cls(`$dRBU.LCCTCS$2.CommunityThriftContributionStates`, ($self) => class CommunityThriftContributionStates extends $.$PZCj.LCCGCS$2.CommunityGroupPostStates
        {
            //--TRIMMABLE-BOUNDARY-START(4297101901)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297101901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297101901)
            
            //--TRIMMABLE-BOUNDARY-START(4297101901)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4297101901)
            
            static $h = 2134605;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$2.CommunityGroupPostStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297101901),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2134605,
      "h": 4297101901,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297101901)
  ],
  "h": 2134605
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.States.CommunityThriftContributionStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}States${separator}CommunityThriftContributionStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2134605)
        
        

        //--TRIMMABLE-BOUNDARY-START(1872461)
        $asm.$cls(`$dRBU.LCCTCS$1.CommunityThriftContributionSettings`, ($self) => class CommunityThriftContributionSettings extends $.$PZCj.LCCGCS$1.CommunityGroupPostSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296839757)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296839757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296839757)
            
            //--TRIMMABLE-BOUNDARY-START(4296839757)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296839757)
            
            static $h = 1872461;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$1.CommunityGroupPostSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296839757),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1872461,
      "h": 4296839757,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296839757)
  ],
  "h": 1872461
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Settings.CommunityThriftContributionSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Settings${separator}CommunityThriftContributionSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1872461)
        
        

        //--TRIMMABLE-BOUNDARY-START(2265677)
        $asm.$cls(`$dRBU.LCCTCS$2.CommunityThriftContributionStatesTypeDescriptor`, ($self) => class CommunityThriftContributionStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRBU.LCCTCS$2.CommunityThriftContributionStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4297232973)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297232973);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRBU.LCCTCS$2.CommunityThriftContributionStatesTypeDescriptor.GenerateProperties($.$dRBU.LCCTCS$2.CommunityThriftContributionStates, this, factory);
                    }, $Jdlvrj ??= {"r":65537,"n":"","d":2265677,"h":0,"f":17825794}), 0, "CommunityThriftContributionStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Thrift.Common\\States_CommunityThriftContributionStates_LivingThing.Core.Community.Thrift.Common.States.CommunityThriftContributionStatesTypeDescriptorBuilder.g.cs", "CommunityThriftContributionStatesTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297232973)
            
            //--TRIMMABLE-BOUNDARY-START(12887167565)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887167565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887167565)
            
            //--TRIMMABLE-BOUNDARY-START(17182134861)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Thrift.Common.States.CommunityThriftContributionStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182134861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.States.CommunityGroupPostStates?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$2.CommunityGroupPostStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182134861)
            
            //--TRIMMABLE-BOUNDARY-START(8592200269)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Thrift.Common.States.CommunityThriftContributionStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592200269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRBU.LCCTCS$2.CommunityThriftContributionStates().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates)))
                {
                    /*var*/ let result = $.$dRBU.LCCTCS$2.CommunityThriftContributionStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592200269)
            
            static $h = 2265677;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRBU.LCCTCS$2.CommunityThriftContributionStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887167565),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2265677,
      "h": 12887167565,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887167565),
//--TRIMMABLE-BOUNDARY-START(17182134861),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2134605,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2265677,
      "h": 17182134861,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182134861),
//--TRIMMABLE-BOUNDARY-START(8592200269),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2134605,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2265677,
      "h": 8592200269,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592200269)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297232973),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2265677,
      "h": 4297232973,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297232973)
  ],
  "h": 2265677
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRBU.LCCTCS$2.CommunityThriftContributionStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.States.CommunityThriftContributionStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}States${separator}CommunityThriftContributionStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2265677)
        
        

        //--TRIMMABLE-BOUNDARY-START(2003533)
        $asm.$cls(`$dRBU.LCCTCS$1.CommunityThriftContributionSettingsTypeDescriptor`, ($self) => class CommunityThriftContributionSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296970829)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296970829);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRBU.LCCTCS$1.CommunityThriftContributionSettingsTypeDescriptor.GenerateProperties($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, this, factory);
                    }, $zmlywk ??= {"r":65537,"n":"","d":2003533,"h":0,"f":17825794}), 0, "CommunityThriftContributionSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Thrift.Common\\Settings_CommunityThriftContributionSettings_LivingThing.Core.Community.Thrift.Common.Settings.CommunityThriftContributionSettingsTypeDescriptorBuilder.g.cs", "CommunityThriftContributionSettingsTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296970829)
            
            //--TRIMMABLE-BOUNDARY-START(12886905421)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886905421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886905421)
            
            //--TRIMMABLE-BOUNDARY-START(17181872717)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Thrift.Common.Settings.CommunityThriftContributionSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181872717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Settings.CommunityGroupPostSettings?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$1.CommunityGroupPostSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181872717)
            
            //--TRIMMABLE-BOUNDARY-START(8591938125)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Thrift.Common.Settings.CommunityThriftContributionSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591938125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRBU.LCCTCS$1.CommunityThriftContributionSettings().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCS$1.CommunityThriftContributionSettings)))
                {
                    /*var*/ let result = $.$dRBU.LCCTCS$1.CommunityThriftContributionSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCS$1.CommunityThriftContributionSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCS$1.CommunityThriftContributionSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591938125)
            
            static $h = 2003533;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886905421),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2003533,
      "h": 12886905421,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886905421),
//--TRIMMABLE-BOUNDARY-START(17181872717),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1872461,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2003533,
      "h": 17181872717,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181872717),
//--TRIMMABLE-BOUNDARY-START(8591938125),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1872461,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2003533,
      "h": 8591938125,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591938125)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296970829),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2003533,
      "h": 4296970829,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296970829)
  ],
  "h": 2003533
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Settings.CommunityThriftContributionSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Settings${separator}CommunityThriftContributionSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2003533)
        
        

        //--TRIMMABLE-BOUNDARY-START(1217101)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftModel`, ($self) => class CommunityThriftModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296184397)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296184397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296184397)
            
            //--TRIMMABLE-BOUNDARY-START(4296184397)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4296184397)
            
            static $h = 1217101;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296184397),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1217101,
      "h": 4296184397,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296184397)
  ],
  "h": 1217101
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1217101)
        
        

        //--TRIMMABLE-BOUNDARY-START(1348173)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftModelTypeDescriptor`, ($self) => class CommunityThriftModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296315469)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296315469);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRBU.LCCTCM.CommunityThriftModelTypeDescriptor.GenerateProperties($.$dRBU.LCCTCM.CommunityThriftModel, this, factory);
                    }, $nTeOGf ??= {"r":65537,"n":"","d":1348173,"h":0,"f":17825794}), 0, "CommunityThriftModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Thrift.Common\\Models_CommunityThriftModel_LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftModelTypeDescriptorBuilder.g.cs", "CommunityThriftModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296315469)
            
            //--TRIMMABLE-BOUNDARY-START(12886250061)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886250061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886250061)
            
            //--TRIMMABLE-BOUNDARY-START(17181217357)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181217357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Thrift.Common.Settings.CommunityThriftContributionSettings, LivingThing.Core.Community.Thrift.Common.States.CommunityThriftContributionStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181217357)
            
            //--TRIMMABLE-BOUNDARY-START(8591282765)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591282765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRBU.LCCTCM.CommunityThriftModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRBU.LCCTCM.CommunityThriftModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCM.CommunityThriftModel)))
                {
                    /*var*/ let result = $.$dRBU.LCCTCM.CommunityThriftModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCM.CommunityThriftModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRBU.LCCTCM.CommunityThriftModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCM.CommunityThriftModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591282765)
            
            static $h = 1348173;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886250061),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1348173,
      "h": 12886250061,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886250061),
//--TRIMMABLE-BOUNDARY-START(17181217357),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1217101,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1348173,
      "h": 17181217357,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181217357),
//--TRIMMABLE-BOUNDARY-START(8591282765),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1217101,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1348173,
      "h": 8591282765,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591282765)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296315469),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1348173,
      "h": 4296315469,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296315469)
  ],
  "h": 1348173
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1348173)
        
        

        //--TRIMMABLE-BOUNDARY-START(561741)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftContributionGroupModel`, ($self) => class CommunityThriftContributionGroupModel extends $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates)
        {
            //--TRIMMABLE-BOUNDARY-START(73015005773)
            /*PostTypes */ get Type()
            {
                return 10242/*PostTypes.GroupThriftContribution*/;
            }
            //--TRIMMABLE-BOUNDARY-END(73015005773)
            
            //--TRIMMABLE-BOUNDARY-START(42950234701)
            /*IEnumerable<AccountMembership>? */ get Memberships()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885463629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperties($.$LCOv.LCFCPM.AccountMembership, "Memberships");
            }
            /*IEnumerable<AccountMembership>? */ set Memberships(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130103885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperties($.$LCOv.LCFCPM.AccountMembership, value, "Memberships");
            }
            //--TRIMMABLE-BOUNDARY-END(42950234701)
            
            //--TRIMMABLE-BOUNDARY-START(47245201997)
            /*IEnumerable<string>? */ get Roles()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475398221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperties($.$$.S.String, "Roles");
            }
            /*IEnumerable<string>? */ set Roles(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720038477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperties($.$$.S.String, value, "Roles");
            }
            //--TRIMMABLE-BOUNDARY-END(47245201997)
            
            //--TRIMMABLE-BOUNDARY-START(51540169293)
            /*Pager<ServiceTierModel<DynamicServiceTierType, DynamicServiceFeatureType>> */ get ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065332813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Membership.AccountMembership>?*/ let __ca1__;
                return $.$fPer.LCFCD.Paging.GetPager($.$AvdQ.LCFCP.ServiceTierModel$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType), (((__ca1__ = this.Memberships) !== null ? ($.$sl.SL.Enumerable.Select$1($.$LCOv.LCFCPM.AccountMembership, $.$AvdQ.LCFCP.ServiceTierModel$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType), __ca1__, new ($.$$.S.Func$$$($.$LCOv.LCFCPM.AccountMembership, $.$AvdQ.LCFCP.ServiceTierModel$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType)))().$ctor(this,  (/*m*/ m) =>
                {
                    return (() =>
                    {
                        //new $.$AvdQ.LCFCP.ServiceTierModel$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType)()
                        const $t1 = $.$AvdQ.LCFCP.ServiceTierModel$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType);
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = m.Title;
                        $i1.Cost = (m.Fee?.RecurringAmount ?? null) ?? new $.$fPer.LCFCDM.Money();
                        return $i1;
                    })();
                }, $AhTqxf ??= {"r":$.$AvdQ.LCFCP.ServiceTierModel$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType).$h,"p":[{"n":"m","p":4778420}],"n":"","d":561741,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$AvdQ.LCFCP.ServiceTierModel$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType))) : $.$sl.SL.Enumerable.Empty($.$AvdQ.LCFCP.ServiceTierModel$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType)))), null);
            }
            //--TRIMMABLE-BOUNDARY-END(51540169293)
            
            //--TRIMMABLE-BOUNDARY-START(8595696052)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Membership.IAccountMembershipBaseModel.Memberships.get
            get LCFCPM$IAccountMembershipBaseModel$Memberships()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21480597940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Memberships;
            }
            //--TRIMMABLE-BOUNDARY-END(8595696052)
            
            //--TRIMMABLE-BOUNDARY-START(17185630644)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Membership.IAccountMembershipBaseModel.Roles.get
            get LCFCPM$IAccountMembershipBaseModel$Roles()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25775565236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Roles;
            }
            //--TRIMMABLE-BOUNDARY-END(17185630644)
            
            //--TRIMMABLE-BOUNDARY-START(8592405440)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider<LivingThing.Core.Frameworks.Common.Product.DynamicServiceTierType, LivingThing.Core.Frameworks.Common.Product.DynamicServiceFeatureType>.ServiceTiers.get
            get LCFCP$ICatalogueProvider$$$$ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196784064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceTiers;
            }
            //--TRIMMABLE-BOUNDARY-END(8592405440)
            
            //--TRIMMABLE-BOUNDARY-START(4295529037)
            //default constructor overload
            $ctor$9()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295529037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295529037)
            
            //--TRIMMABLE-BOUNDARY-START(4295529037)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(4295529037)
            
            static $h = 561741;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015005773),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655267405,
        "f": 50364417
      },
      "n": "Type",
      "d": 561741,
      "h": 73015005773,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73015005773),
//--TRIMMABLE-BOUNDARY-START(42950234701),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM.AccountMembership).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885463629,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130103885,
        "f": 83886081
      },
      "n": "Memberships",
      "d": 561741,
      "h": 42950234701,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1024,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Create membership categories that allows you to further control how each member of a thrift are handled independently",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Options",
              "v": [
                "//Icon=AccountMultiple"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950234701),
//--TRIMMABLE-BOUNDARY-START(47245201997),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475398221,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720038477,
        "f": 83886081
      },
      "n": "Roles",
      "d": 561741,
      "h": 47245201997,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245201997),
//--TRIMMABLE-BOUNDARY-START(51540169293),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065332813,
        "f": 50331649
      },
      "n": "ServiceTiers",
      "d": 561741,
      "h": 51540169293,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540169293)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295529037),
    {
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 561741,
      "h": 4295529037,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295529037)
  ],
  "h": 561741,
  "a": [
    {
      "t": 4859222,
      "c": 12889761110,
      "n": [
        {
          "n": "SettingsType",
          "v": 1872461,
          "t": 188547073
        },
        {
          "n": "StateType",
          "v": 2134605,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostRatable, $.$YUlm.LCSCM.IShipmentAccount, $.$Iaui.LCFCM.IApplicationAccountModel, $.$LCOv.LCFCP.IPostNamedLocation, $.$PZCj.LCCGCM.ICommunityGroupModel, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostReactable, $.$LCOv.LCFCP.IPostSharable, $.$LCOv.LCFCP.IPostViewTrackable, $.$LCOv.LCFCP.IPostApplicationScope, $.$LCOv.LCFCP.IGroupAccountModel, $.$LCOv.LCFCP.IUserAccountModel, $.$fPer.LCFCC$2.IContact, $.$LCOv.LCFCPM.IAccountMembershipBaseModel, $.$LCOv.LCFCP.IPost, $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftContributionGroupModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(561741)
        
        

        //--TRIMMABLE-BOUNDARY-START(1610317)
        $asm.$cls(`$dRBU.LCCTCS.ICommunityThriftFeedRemoteService`, ($self) => class ICommunityThriftFeedRemoteService
        {
            static $h = 1610317;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1610317,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Services.ICommunityThriftFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Services${separator}ICommunityThriftFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1610317)
        
        

        //--TRIMMABLE-BOUNDARY-START(1741389)
        $asm.$cls(`$dRBU.LCCTCS.IComunityThriftRemoteService`, ($self) => class IComunityThriftRemoteService
        {
            static $h = 1741389;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1741389,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.ICreateDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.IReadDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.IReadManyDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.IUpdateDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.IDeleteDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Services.IComunityThriftRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Services${separator}IComunityThriftRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1741389)
        
        

        //--TRIMMABLE-BOUNDARY-START(1675853)
        $asm.$cls(`$dRBU.LCCTCS.ICommunityThriftFeedRemoteService_Mocking`, ($self) => class ICommunityThriftFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296643149)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296643149);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296643149)
            
            //--TRIMMABLE-BOUNDARY-START(8591610445)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Thrift$Common$Models$CommunityThriftContributionGroupModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591610445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591610445)
            
            static $h = 1675853;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296643149),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1675853,
      "h": 4296643149,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296643149)
  ],
  "h": 1675853
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$dRBU.LCCTCS.ICommunityThriftFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Services.ICommunityThriftFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Services${separator}ICommunityThriftFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1675853)
        
        

        //--TRIMMABLE-BOUNDARY-START(1806925)
        $asm.$cls(`$dRBU.LCCTCS.IComunityThriftRemoteService_Mocking`, ($self) => class IComunityThriftRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296774221)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296774221);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296774221)
            
            //--TRIMMABLE-BOUNDARY-START(8591741517)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Thrift$Common$Models$CommunityThriftContributionGroupModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591741517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591741517)
            
            //--TRIMMABLE-BOUNDARY-START(17181676109)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Thrift$Common$Models$CommunityThriftContributionGroupModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181676109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181676109)
            
            //--TRIMMABLE-BOUNDARY-START(21476643405)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Thrift$Common$Models$CommunityThriftContributionGroupModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476643405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.WireTransportModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476643405)
            
            //--TRIMMABLE-BOUNDARY-START(25771610701)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Thrift$Common$Models$CommunityThriftContributionGroupModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771610701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771610701)
            
            //--TRIMMABLE-BOUNDARY-START(12886708813)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886708813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886708813)
            
            static $h = 1806925;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296774221),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1806925,
      "h": 4296774221,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296774221)
  ],
  "h": 1806925
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$dRBU.LCCTCS.IComunityThriftRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.ICreateDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.IReadDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.IReadManyDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.IUpdateDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD.IDeleteDataService$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Services.IComunityThriftRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Services${separator}IComunityThriftRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1806925)
        
        

        //--TRIMMABLE-BOUNDARY-START(954957)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftGroupCategoryModel`, ($self) => class CommunityThriftGroupCategoryModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180824141)
            /*PostTypes */ get Type()
            {
                return 10241/*PostTypes.GroupThriftCategory*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180824141)
            
            //--TRIMMABLE-BOUNDARY-START(4295922253)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295922253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295922253)
            
            //--TRIMMABLE-BOUNDARY-START(4295922253)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295922253)
            
            static $h = 954957;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180824141),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885856845,
        "f": 50364417
      },
      "n": "Type",
      "d": 954957,
      "h": 17180824141,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180824141)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295922253),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 954957,
      "h": 4295922253,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295922253)
  ],
  "h": 954957
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftGroupCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftGroupCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(954957)
        
        

        //--TRIMMABLE-BOUNDARY-START(692813)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftContributionGroupModelTypeDescriptor`, ($self) => class CommunityThriftContributionGroupModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295660109)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295660109);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRBU.LCCTCM.CommunityThriftContributionGroupModelTypeDescriptor.GenerateProperties($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel, this, factory);
                    }, $CeFYLi ??= {"r":65537,"n":"","d":692813,"h":0,"f":17825794}), 0, "CommunityThriftContributionGroupModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Thrift.Common\\Models_CommunityThriftContributionGroupModel_LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModelTypeDescriptorBuilder.g.cs", "CommunityThriftContributionGroupModelTypeDescriptor", 43);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295660109)
            
            //--TRIMMABLE-BOUNDARY-START(12885594701)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885594701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Memberships"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel.$type, $.$discardRef(), "Memberships", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Memberships")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM.AccountMembership), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Memberships";
                        $i1.DelaredOn = "LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRBU.LCCTCM.CommunityThriftContributionGroupModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM.AccountMembership), ($.$cast(target, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel)).Memberships);
                        }, $dfCcYi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":692813,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRBU.LCCTCM.CommunityThriftContributionGroupModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Memberships = value.AsReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM.AccountMembership));
                        }, $qBRqtj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":692813,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Type";
                        $i3.DelaredOn = "LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRBU.LCCTCM.CommunityThriftContributionGroupModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel)).Type);
                        }, $lDvJOj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":692813,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Roles"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel.$type, $.$discardRef(), "Roles", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Roles")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Roles";
                        $i5.DelaredOn = "LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRBU.LCCTCM.CommunityThriftContributionGroupModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel)).Roles);
                        }, $YzyiMc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":692813,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRBU.LCCTCM.CommunityThriftContributionGroupModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Roles = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $kmRTTg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":692813,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceTiers"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel.$type, $.$discardRef(), "ServiceTiers", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceTiers")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType)), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "ServiceTiers";
                        $i7.DelaredOn = "LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRBU.LCCTCM.CommunityThriftContributionGroupModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType)), ($.$cast(target, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel)).ServiceTiers);
                        }, $TVpPie ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":692813,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885594701)
            
            //--TRIMMABLE-BOUNDARY-START(17180561997)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180561997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel<LivingThing.Core.Community.Thrift.Common.Settings.CommunityThriftContributionSettings, LivingThing.Core.Community.Thrift.Common.States.CommunityThriftContributionStates>?*/ let targetBase = _target;
                $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$dRBU.LCCTCS$1.CommunityThriftContributionSettings, $.$dRBU.LCCTCS$2.CommunityThriftContributionStates)));
                {
                    /*var*/ let _Memberships = _target.Memberships;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Memberships"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM.AccountMembership)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM.AccountMembership), $.$LCOv.LCFCPM.AccountMembership));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM.AccountMembership), $.$LCOv.LCFCPM.AccountMembership, property, $.$ref(() => _Memberships, ($v) => _Memberships = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM.AccountMembership))))
                    {
                        _target.Memberships = _Memberships;
                        if (_Memberships !== null)
                        {
                            let $en12 = _Memberships.SCG$IEnumerable$$$GetEnumerator();
                            while ($en12.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en12.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = $.$clone(item);
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM.AccountMembership, () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM.AccountMembership), $.$LCOv.LCFCPM.AccountMembership, property, $.$ref(() => _Memberships, ($v) => _Memberships = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM.AccountMembership)));
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Roles = _target.Roles;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Roles"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Roles, ($v) => _Roles = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.Roles = _Roles;
                        if (_Roles !== null)
                        {
                            let $en19 = _Roles.SCG$IEnumerable$$$GetEnumerator();
                            while ($en19.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en19.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Roles, ($v) => _Roles = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _ServiceTiers = _target.ServiceTiers;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceTiers"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType))));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ServiceTiers, ($v) => _ServiceTiers = $v, $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel$$$($.$AvdQ.LCFCP.DynamicServiceTierType, $.$AvdQ.LCFCP.DynamicServiceFeatureType)))))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180561997)
            
            //--TRIMMABLE-BOUNDARY-START(8590627405)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590627405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel().$ctor$9();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel)))
                {
                    /*var*/ let result = $.$dRBU.LCCTCM.CommunityThriftContributionGroupModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590627405)
            
            static $h = 692813;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885594701),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 692813,
      "h": 12885594701,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885594701),
//--TRIMMABLE-BOUNDARY-START(17180561997),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 561741,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 692813,
      "h": 17180561997,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180561997),
//--TRIMMABLE-BOUNDARY-START(8590627405),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 561741,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 692813,
      "h": 8590627405,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590627405)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295660109),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 692813,
      "h": 4295660109,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295660109)
  ],
  "h": 692813
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftContributionGroupModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftContributionGroupModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(692813)
        
        

        //--TRIMMABLE-BOUNDARY-START(1086029)
        $asm.$cls(`$dRBU.LCCTCM.CommunityThriftGroupCategoryModelTypeDescriptor`, ($self) => class CommunityThriftGroupCategoryModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296053325)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296053325);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModelTypeDescriptor.GenerateProperties($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel, this, factory);
                    }, $iFtJMj ??= {"r":65537,"n":"","d":1086029,"h":0,"f":17825794}), 0, "CommunityThriftGroupCategoryModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Thrift.Common\\Models_CommunityThriftGroupCategoryModel_LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftGroupCategoryModelTypeDescriptorBuilder.g.cs", "CommunityThriftGroupCategoryModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296053325)
            
            //--TRIMMABLE-BOUNDARY-START(12885987917)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885987917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftGroupCategoryModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel)).Type);
                        }, $appQtf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1086029,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885987917)
            
            //--TRIMMABLE-BOUNDARY-START(17180955213)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftGroupCategoryModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180955213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftGroupCategoryModel, LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftContributionGroupModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel, $.$dRBU.LCCTCM.CommunityThriftContributionGroupModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180955213)
            
            //--TRIMMABLE-BOUNDARY-START(8591020621)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftGroupCategoryModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591020621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel)))
                {
                    /*var*/ let result = $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591020621)
            
            static $h = 1086029;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885987917),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1086029,
      "h": 12885987917,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885987917),
//--TRIMMABLE-BOUNDARY-START(17180955213),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 954957,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1086029,
      "h": 17180955213,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180955213),
//--TRIMMABLE-BOUNDARY-START(8591020621),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 954957,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1086029,
      "h": 8591020621,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591020621)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296053325),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1086029,
      "h": 4296053325,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296053325)
  ],
  "h": 1086029
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRBU.LCCTCM.CommunityThriftGroupCategoryModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Thrift.Common.Models.CommunityThriftGroupCategoryModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Thrift${separator}Common${separator}Models${separator}CommunityThriftGroupCategoryModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1086029)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Group.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(37453)
