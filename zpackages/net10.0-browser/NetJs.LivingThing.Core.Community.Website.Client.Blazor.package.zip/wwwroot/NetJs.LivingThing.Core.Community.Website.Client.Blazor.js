
//--TRIMMABLE-BOUNDARY-START(38085)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $AEuu) {
    "use strict";
    let _;
    let $LvMJhf;
    let $DYSDCe;
    let $oHSlQe;
    let $vBLjzk;
    let $UkQpsg;
    let $fimyIa;
    let $OqjMTe;
    let $tEAPUd;
    let $oGZstd;
    let $pVpDEh;
    let $YjQBHh;
    let $PXbtXj;
    let $SGehAa;
    let $vxTFGe;
    let $MJSCZe;
    let $uTMSCj;
    let $IcfzQe;
    let $vTOrBh;
    let $LmKkxi;
    let $AWzmBj;
    let $vmymTc;
    let $lclgGb;
    let $JXAADd;
    let $dxTTVc;
    let $mdhdQh;
    let $hWKYgj;
    let $nnDMhe;
    let $vsjwhk;
    let $qpUkHe;
    let $fNvDsf;
    let $Qauvcc;
    let $icZOuh;
    let $QqPQZb;
    let $BqhbXf;
    let $oSRdYh;
    let $hNOWUb;
    let $lAwSFj;
    let $CtXKje;
    let $SgoFjf;
    let $BUhPvi;
    let $hVJMDc;
    let $eSAgOh;
    let $HAhnRb;
    let $TLBNjh;
    let $dbxOWj;
    let $jhFRTj;
    let $hEPRdf;
    let $zrHPNa;
    let $SbKMuc;
    let $lJdyii;
    let $xKpxuj;
    let $VwoSub;
    let $RtYrma;
    let $rGuSzd;
    let $UWANOc;
    let $weuaQi;
    let $VOZTyi;
    let $LCXADj;
    let $zOhTAf;
    let $zgGgIc;
    let $XXGcni;
    let $hGUKag;
    let $GVLIxc;
    let $jOjMKe;
    let $vZyGbf;
    let $dxUUMi;
    let $bUOoqk;
    let $QzAaJf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Website.Client.Blazor", 
    {
  "h": 38085,
  "f": "LivingThing.Core.Community.Website.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Website.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Website.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(365765)
        $asm.$cls(`$MDmQ.LCCWCE.IWebsiteEditable`, ($self) => class IWebsiteEditable
        {
            static $h = 365765;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295333061),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885267653,
        "f": 50331905
      },
      "n": "CId",
      "o": "LCCWCE$IWebsiteEditable$CId",
      "d": 365765,
      "h": 4295333061,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295333061)
  ],
  "h": 365765
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Editables.IWebsiteEditable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Editables${separator}IWebsiteEditable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(365765)
        
        

        //--TRIMMABLE-BOUNDARY-START(300229)
        $asm.$cls(`$MDmQ.LCCWCE.IWebsiteCommonEditable`, ($self) => class IWebsiteCommonEditable
        {
            static $h = 300229;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 300229
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$MDmQ.LCCWCE.IWebsiteEditable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Editables.IWebsiteCommonEditable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Editables${separator}IWebsiteCommonEditable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(300229)
        
        

        //--TRIMMABLE-BOUNDARY-START(2266309)
        $asm.$cls(`$MDmQ.LCCWC.WebsitePage`, ($self) => class WebsitePage extends $.$mac.MAC.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(270585205957)
            /*string */ get OptimizedComponentName()
            {
                return "websitepage";
            }
            //--TRIMMABLE-BOUNDARY-END(270585205957)
            
            //--TRIMMABLE-BOUNDARY-START(425204028613)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425204028613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Website":
                    this.Website = $.$cast(parameter.Value, $.$AEuu.LCCWCM.CommunityWebsiteHostModel);
                    return true;
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$AEuu.LCCWCM.CommunityWebsitePageModel);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(425204028613)
            
            //--TRIMMABLE-BOUNDARY-START(412319126725)
            /*Task */ SetParametersAsync(/*ParameterView*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412319126725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Task*/ let beginTask = ($.$cast(this, $.$hDPm.LCFCC$1.IBaseComponent)).LCFCC$1$IBaseComponent$BeginSetParametersAsync();
                $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                {
                    let $en2 = parameters.GetEnumerator();
                    while ($en2.MoveNext())
                    {
                        let parameter = $en2.Current;
                        {
                            /*bool*/ let set = this.TrySetParameter(parameter);
                        }
                    }
                }, $CtXKje ??= {"r":65537,"n":"","d":2266309,"h":0,"f":17825794}), 0, "SetParametersAsync " + $.$strNN(this.OptimizedComponentName), "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Website.Client.Blazor\\WebsitePage_WebsitePageParametertSetter.g.cs", "SetParametersAsync", 43);
                /*Task*/ let endTask = super.SetParametersAsync($.$mac.MAC.ParameterView.Empty);
                if (!beginTask.IsCompletedSuccessfully && !endTask.IsCompletedSuccessfully)
                {
                    return $.$$.STT.Task.WhenAll$1($.$$.S.ReadOnlySpan$$($.$$.STT.Task).op_Implicit$1([ beginTask, endTask ]));
                }
                if (!beginTask.IsCompletedSuccessfully)
                {
                    return beginTask;
                }
                if (!endTask.IsCompletedSuccessfully)
                {
                    return endTask;
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(412319126725)
            
            //--TRIMMABLE-BOUNDARY-START(47246906565)
            /*IAssetsCollection*/ Assets$1 = null;
            //--TRIMMABLE-BOUNDARY-END(47246906565)
            
            //--TRIMMABLE-BOUNDARY-START(240520434885)
            /*IJSRuntime*/ Javascript = null;
            //--TRIMMABLE-BOUNDARY-END(240520434885)
            
            //--TRIMMABLE-BOUNDARY-START(317829846213)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(317829846213)
            
            //--TRIMMABLE-BOUNDARY-START(55836841157)
            /*IApplicationContextProvider*/ Context = null;
            //--TRIMMABLE-BOUNDARY-END(55836841157)
            
            //--TRIMMABLE-BOUNDARY-START(287765075141)
            /*IResourcePathResolver*/ PathResolver = null;
            //--TRIMMABLE-BOUNDARY-END(287765075141)
            
            //--TRIMMABLE-BOUNDARY-START(322124813509)
            /*CommunityWebsiteService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(322124813509)
            
            //--TRIMMABLE-BOUNDARY-START(257700304069)
            /*NavigationManager*/ NavigationManager = null;
            //--TRIMMABLE-BOUNDARY-END(257700304069)
            
            //--TRIMMABLE-BOUNDARY-START(442383897797)
            /*CommunityWebsiteHostModel*/ Website = null;
            //--TRIMMABLE-BOUNDARY-END(442383897797)
            
            //--TRIMMABLE-BOUNDARY-START(274880173253)
            /*CommunityWebsitePageModel*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(274880173253)
            
            //--TRIMMABLE-BOUNDARY-START(51541873861)
            /*string */ get ContentFolder()
            {
                return new $.$spu.S.Uri().$ctor$5(this.Url).Authority;
            }
            //--TRIMMABLE-BOUNDARY-END(51541873861)
            
            //--TRIMMABLE-BOUNDARY-START(227635532997)
            /*bool */ get IsEditable()
            {
                return this.Service.CommunityService.IsOwnedByCurrentUser(this.Website);
            }
            //--TRIMMABLE-BOUNDARY-END(227635532997)
            
            //--TRIMMABLE-BOUNDARY-START(231930500293)
            /*bool*/ isEditting = false;
            //--TRIMMABLE-BOUNDARY-END(231930500293)
            
            //--TRIMMABLE-BOUNDARY-START(236225467589)
            /*bool */ get IsEditting()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851285189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEditable && this.isEditting;
            }
            /*bool */ set IsEditting(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894617285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.isEditting !== value)
                {
                    this.isEditting = value;
                    this.StateHasChanged();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236225467589)
            
            //--TRIMMABLE-BOUNDARY-START(283470107845)
            /*IWebsiteDataSource */ get Parent()
            {
                return this.Website;
            }
            //--TRIMMABLE-BOUNDARY-END(283470107845)
            
            //--TRIMMABLE-BOUNDARY-START(433793963205)
            /*Dictionary<string, string> */ UpdateStore(/*Action<Dictionary<string, string>>?*/ updateStore)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433793963205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let r = this.Page.UpdateStore(updateStore);
                if (updateStore !== null)
                {
                    this.pageDirty = true;
                }
                return r;
            }
            //--TRIMMABLE-BOUNDARY-END(433793963205)
            
            //--TRIMMABLE-BOUNDARY-START(429498995909)
            /*Dictionary<string, List<CommunityWebsiteDataSource>> */ UpdateRepeaterStore(/*Action<Dictionary<string, List<CommunityWebsiteDataSource>>>?*/ updateStore)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429498995909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let r = this.Page.UpdateRepeaterStore(updateStore);
                if (updateStore !== null)
                {
                    this.pageDirty = true;
                }
                return r;
            }
            //--TRIMMABLE-BOUNDARY-END(429498995909)
            
            //--TRIMMABLE-BOUNDARY-START(73016710341)
            /*List<IWebsiteEditable>*/ editables = null;
            //--TRIMMABLE-BOUNDARY-END(73016710341)
            
            //--TRIMMABLE-BOUNDARY-START(77311677637)
            /*IEnumerable<IWebsiteEditable> */ get Editables()
            {
                return this.editables;
            }
            //--TRIMMABLE-BOUNDARY-END(77311677637)
            
            //--TRIMMABLE-BOUNDARY-START(279175140549)
            /*bool*/ pageDirty = false;
            //--TRIMMABLE-BOUNDARY-END(279175140549)
            
            //--TRIMMABLE-BOUNDARY-START(446678865093)
            /*bool*/ websiteDirty = false;
            //--TRIMMABLE-BOUNDARY-END(446678865093)
            
            //--TRIMMABLE-BOUNDARY-START(292060042437)
            /*void */ Register(/*IWebsiteEditable*/ editable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292060042437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.editables.Contains(editable))
                {
                    this.editables.Add(editable);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(292060042437)
            
            //--TRIMMABLE-BOUNDARY-START(60131808453)
            /*void */ DeRegister(/*IWebsiteEditable*/ editable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131808453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.editables.Remove(editable);
            }
            //--TRIMMABLE-BOUNDARY-END(60131808453)
            
            //--TRIMMABLE-BOUNDARY-START(300649977029)
            /*Task */ RequiresMetas(/*params WebsitePageMeta[]*/ metas)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300649977029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(300649977029)
            
            //--TRIMMABLE-BOUNDARY-START(309239911621)
            /*Task *//*async*/  RequiresStyleSheets(/*params string[]*/ styles)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(309239911621);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = this.Assets$1.LCFCH$IAssetsCollection$Add($.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$$.S.String, styles, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                    {
                        return this.PathResolver.LCFCC$IResourcePathResolver$Resolve($.$$.S.Object.GetType.call(this).Assembly.GetName().Name, s, false);
                    }, $SgoFjf ??= {"r":1310721,"p":[{"n":"s","p":1310721}],"n":"","d":2266309,"h":0,"f":17825794})))), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(309239911621)
            
            //--TRIMMABLE-BOUNDARY-START(304944944325)
            /*Task *//*async*/  RequiresScripts(/*params string[]*/ scripts)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(304944944325);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = this.Assets$1.LCFCH$IAssetsCollection$Add($.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$$.S.String, scripts, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                    {
                        return this.PathResolver.LCFCC$IResourcePathResolver$Resolve($.$$.S.Object.GetType.call(this).Assembly.GetName().Name, s, false);
                    }, $BUhPvi ??= {"r":1310721,"p":[{"n":"s","p":1310721}],"n":"","d":2266309,"h":0,"f":17825794})))), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(304944944325)
            
            //--TRIMMABLE-BOUNDARY-START(313534878917)
            /*string */ ResolvePath(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313534878917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PathResolver.LCFCC$IResourcePathResolver$Resolve($.$$.S.Object.GetType.call(this).Assembly.GetName().Name, s, false);
            }
            //--TRIMMABLE-BOUNDARY-END(313534878917)
            
            //--TRIMMABLE-BOUNDARY-START(68721743045)
            /*bool*/ disposed = false;
            //--TRIMMABLE-BOUNDARY-END(68721743045)
            
            //--TRIMMABLE-BOUNDARY-START(420909061317)
            /*void */ StartAutoSave()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420909061317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        while(!this.disposed)
                        {
                            let $t5, $r5;
                            ($t5 = $.$$.STT.Task.Delay$1(5000), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                            if (this.pageDirty)
                            {
                                try
                                {
                                    let $t6, $r6;
                                    ($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$AEuu.LCCWCM.CommunityWebsitePageModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$AEuu.LCCWCM.CommunityWebsitePageModel), [ this.Page ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                    this.pageDirty = false;
                                }
                                catch($e)
                                {
                                }
                            }
                            if (this.websiteDirty)
                            {
                                try
                                {
                                    let $t7, $r7;
                                    ($t7 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$AEuu.LCCWCM.CommunityWebsiteHostModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$AEuu.LCCWCM.CommunityWebsiteHostModel), [ this.Website ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                    this.websiteDirty = false;
                                }
                                catch($e)
                                {
                                }
                            }
                        }
                    });
                }, $hVJMDc ??= {"r":178454529,"n":"","d":2266309,"h":0,"f":17829890}));
            }
            //--TRIMMABLE-BOUNDARY-END(420909061317)
            
            //--TRIMMABLE-BOUNDARY-START(219045598405)
            /*bool*/ initialized = false;
            //--TRIMMABLE-BOUNDARY-END(219045598405)
            
            //--TRIMMABLE-BOUNDARY-START(296355009733)
            /*bool*/ rendered = false;
            //--TRIMMABLE-BOUNDARY-END(296355009733)
            
            //--TRIMMABLE-BOUNDARY-START(244815402181)
            /*bool*/ jsInit = false;
            //--TRIMMABLE-BOUNDARY-END(244815402181)
            
            //--TRIMMABLE-BOUNDARY-START(223340565701)
            /*ValueTask */ InitJs()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340565701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.initialized && this.rendered && !this.jsInit)
                {
                    this.jsInit = true;
                    return $.$mj.MJ.JSRuntimeExtensions.InvokeVoidAsync(this.Javascript, "window.website.init", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mj.MJ.DotNetObjectReference.Create($.$MDmQ.LCCWC.WebsitePage, this), this.Context.LCFC$IApplicationContextProvider$LocalUri.Authority ], null, null));
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(223340565701)
            
            //--TRIMMABLE-BOUNDARY-START(253405336773)
            /*ValueTask */ NavigatingAway(/*LocationChangingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405336773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEditting)
                {
                    context.PreventNavigation();
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(253405336773)
            
            //--TRIMMABLE-BOUNDARY-START(450973832389)
            /*void */ WebsiteStoreUpdated(/*object?*/ sender, /*EventArgs*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450973832389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.websiteDirty = true;
            }
            //--TRIMMABLE-BOUNDARY-END(450973832389)
            
            //--TRIMMABLE-BOUNDARY-START(249110369477)
            /*IDisposable*/ navigatingAway = null;
            //--TRIMMABLE-BOUNDARY-END(249110369477)
            
            //--TRIMMABLE-BOUNDARY-START(266290238661)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(266290238661);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Website.add_StoreUpdated(new $.$$.S.EventHandler().$ctor(this, this.WebsiteStoreUpdated));
                    this.Service.CurrentPage = this;
                    this.navigatingAway = this.NavigationManager.RegisterLocationChangingHandler(new ($.$$.S.Func$$$($.$mac.MACR$3.LocationChangingContext, $.$$.STT.ValueTask))().$ctor(this, this.NavigatingAway));
                    this.StartAutoSave();
                    ($t8 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    this.initialized = true;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(266290238661)
            
            //--TRIMMABLE-BOUNDARY-START(261995271365)
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t9, $r9;
                    let $t10, $r10;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261995271365);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.rendered = true;
                    ($t9 = this.InitJs(), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    ($t10 = super.OnAfterRenderAsync(firstRender), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(261995271365)
            
            //--TRIMMABLE-BOUNDARY-START(64426775749)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426775749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Website.remove_StoreUpdated(new $.$$.S.EventHandler().$ctor(this, this.WebsiteStoreUpdated));
                this.disposed = true;
                this.navigatingAway?.S$IDisposable$Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(64426775749)
            
            //--TRIMMABLE-BOUNDARY-START(416614094021)
            /*void */ SetText(/*string*/ id, /*string*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416614094021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _text = $.$as($.$sl.SL.Enumerable.SingleOrDefault$1($.$MDmQ.LCCWCE.IWebsiteEditable, this.editables, new ($.$$.S.Func$$$($.$MDmQ.LCCWCE.IWebsiteEditable, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.LCCWCE$IWebsiteEditable$CId === id;
                }, $eSAgOh ??= {"r":262145,"p":[{"n":"t","p":365765}],"n":"","d":2266309,"h":0,"f":17825794})), $.$MDmQ.LCCWCE.WebsiteEditableText);
                if (_text !== null)
                {
                    text = $.$$.S.String.Trim.call(text);
                    if ($.$$.S.String.IsNullOrEmpty(text))
                    {
                        if ($.$is(_text, $.$MDmQ.LCCWCE.WebsiteEditableCommonText))
                        {
                            $.$MDmQ.LCCWC.WebsiteDataSourceExtension.ClearData(this.Website.Data, _text);
                        }
                        else 
                        {
                            $.$MDmQ.LCCWC.WebsiteDataSourceExtension.ClearData(this, _text);
                        }
                    }
                    else if (text !== ($.$MDmQ.LCCWC.WebsiteDataSourceExtension.GetData(this, _text) ?? _text.DefaultText))
                    {
                        if ($.$is(_text, $.$MDmQ.LCCWCE.WebsiteEditableCommonText))
                        {
                            $.$MDmQ.LCCWC.WebsiteDataSourceExtension.SetData(this.Website.Data, _text, text);
                        }
                        else 
                        {
                            $.$MDmQ.LCCWC.WebsiteDataSourceExtension.SetData(this, _text, text);
                        }
                    }
                    _text.Refresh();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(416614094021)
            
            //--TRIMMABLE-BOUNDARY-START(8591069313)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Common.Models.IWebsiteDataSource.Parent.get
            get LCCWCM$IWebsiteDataSource$Parent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886036609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Parent;
            }
            //--TRIMMABLE-BOUNDARY-END(8591069313)
            
            //--TRIMMABLE-BOUNDARY-START(21475971201)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Common.Models.IWebsiteDataSource.UpdateStore(System.Action<System.Collections.Generic.Dictionary<string, string>>?)
            LCCWCM$IWebsiteDataSource$UpdateStore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475971201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateStore(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475971201)
            
            //--TRIMMABLE-BOUNDARY-START(17181003905)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Common.Models.IWebsiteDataSource.UpdateRepeaterStore(System.Action<System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteDataSource>>>?)
            LCCWCM$IWebsiteDataSource$UpdateRepeaterStore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181003905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateRepeaterStore(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181003905)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(42951939269)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951939269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951939269)
            
            //--TRIMMABLE-BOUNDARY-START(42951939269)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(42951939269)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(47246906565)
                this.Assets$1 = null;
                //--TRIMMABLE-BOUNDARY-END(47246906565)
                
                //--TRIMMABLE-BOUNDARY-START(240520434885)
                this.Javascript = null;
                //--TRIMMABLE-BOUNDARY-END(240520434885)
                
                //--TRIMMABLE-BOUNDARY-START(317829846213)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(317829846213)
                
                //--TRIMMABLE-BOUNDARY-START(55836841157)
                this.Context = null;
                //--TRIMMABLE-BOUNDARY-END(55836841157)
                
                //--TRIMMABLE-BOUNDARY-START(287765075141)
                this.PathResolver = null;
                //--TRIMMABLE-BOUNDARY-END(287765075141)
                
                //--TRIMMABLE-BOUNDARY-START(322124813509)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(322124813509)
                
                //--TRIMMABLE-BOUNDARY-START(257700304069)
                this.NavigationManager = null;
                //--TRIMMABLE-BOUNDARY-END(257700304069)
                
                //--TRIMMABLE-BOUNDARY-START(73016710341)
                this.editables = new ($.$$.SCG.List$$($.$MDmQ.LCCWCE.IWebsiteEditable))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(73016710341)
                
            }
            static $h = 2266309;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.ComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(270585205957),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154621088965,
        "f": 50331649
      },
      "n": "OptimizedComponentName",
      "d": 2266309,
      "h": 270585205957,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270585205957),
//--TRIMMABLE-BOUNDARY-START(438088930501),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206160696517,
        "f": 50331908
      },
      "n": "Url",
      "d": 2266309,
      "h": 438088930501,
      "f": 2097412
    },
//--TRIMMABLE-BOUNDARY-END(438088930501),
//--TRIMMABLE-BOUNDARY-START(47246906565),
    {
      "p": 61691562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901612229,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330714748101,
        "f": 83886081
      },
      "n": "Assets",
      "o": "@$1",
      "d": 2266309,
      "h": 47246906565,
      "f": 538968065,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246906565),
//--TRIMMABLE-BOUNDARY-START(240520434885),
    {
      "p": 524402,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137441219781,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356484551877,
        "f": 83886081
      },
      "n": "Javascript",
      "d": 2266309,
      "h": 240520434885,
      "f": 2097153,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(240520434885),
//--TRIMMABLE-BOUNDARY-START(317829846213),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188980827333,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 390844290245,
        "f": 83886081
      },
      "n": "Server",
      "d": 2266309,
      "h": 317829846213,
      "f": 2097153,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(317829846213),
//--TRIMMABLE-BOUNDARY-START(55836841157),
    {
      "p": 46041430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081481413,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339304682693,
        "f": 83886081
      },
      "n": "Context",
      "d": 2266309,
      "h": 55836841157,
      "f": 2097153,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836841157),
//--TRIMMABLE-BOUNDARY-START(287765075141),
    {
      "p": 3825064,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180390892741,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 382254355653,
        "f": 83886081
      },
      "n": "PathResolver",
      "d": 2266309,
      "h": 287765075141,
      "f": 2097153,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(287765075141),
//--TRIMMABLE-BOUNDARY-START(322124813509),
    {
      "p": 1610949,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197570761925,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 399434224837,
        "f": 83886081
      },
      "n": "Service",
      "d": 2266309,
      "h": 322124813509,
      "f": 2097153,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(322124813509),
//--TRIMMABLE-BOUNDARY-START(257700304069),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146031154373,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 365074486469,
        "f": 83886081
      },
      "n": "NavigationManager",
      "d": 2266309,
      "h": 257700304069,
      "f": 2097153,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(257700304069),
//--TRIMMABLE-BOUNDARY-START(442383897797),
    {
      "p": 544897,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214750631109,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 408024159429,
        "f": 83886081
      },
      "n": "Website",
      "d": 2266309,
      "h": 442383897797,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(442383897797),
//--TRIMMABLE-BOUNDARY-START(274880173253),
    {
      "p": 807041,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163211023557,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 373664421061,
        "f": 83886081
      },
      "n": "Page",
      "d": 2266309,
      "h": 274880173253,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(274880173253),
//--TRIMMABLE-BOUNDARY-START(51541873861),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491546821,
        "f": 50331649
      },
      "n": "ContentFolder",
      "d": 2266309,
      "h": 51541873861,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541873861),
//--TRIMMABLE-BOUNDARY-START(227635532997),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261350597,
        "f": 50331649
      },
      "n": "IsEditable",
      "d": 2266309,
      "h": 227635532997,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227635532997),
//--TRIMMABLE-BOUNDARY-START(236225467589),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128851285189,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347894617285,
        "f": 83886081
      },
      "n": "IsEditting",
      "d": 2266309,
      "h": 236225467589,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236225467589),
//--TRIMMABLE-BOUNDARY-START(283470107845),
    {
      "p": 1134721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171800958149,
        "f": 50331649
      },
      "n": "Parent",
      "d": 2266309,
      "h": 283470107845,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(283470107845),
//--TRIMMABLE-BOUNDARY-START(77311677637),
    {
      "p": $.$$.SCG.IEnumerable$$($.$MDmQ.LCCWCE.IWebsiteEditable).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671416005,
        "f": 50331656
      },
      "n": "Editables",
      "d": 2266309,
      "h": 77311677637,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(77311677637)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(425204028613),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2266309,
      "h": 425204028613,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(425204028613),
//--TRIMMABLE-BOUNDARY-START(412319126725),
    {
      "r": 178454529,
      "p": [
        {
          "n": "parameters",
          "p": 5767283
        }
      ],
      "n": "SetParametersAsync",
      "d": 2266309,
      "h": 412319126725,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(412319126725),
//--TRIMMABLE-BOUNDARY-START(433793963205),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "p": [
        {
          "n": "updateStore",
          "p": $.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)).$h,
          "f": 65
        }
      ],
      "n": "UpdateStore",
      "d": 2266309,
      "h": 433793963205,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(433793963205),
//--TRIMMABLE-BOUNDARY-START(429498995909),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource)).$h,
      "p": [
        {
          "n": "updateStore",
          "p": $.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource))).$h,
          "f": 65
        }
      ],
      "n": "UpdateRepeaterStore",
      "d": 2266309,
      "h": 429498995909,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(429498995909),
//--TRIMMABLE-BOUNDARY-START(292060042437),
    {
      "r": 65537,
      "p": [
        {
          "n": "editable",
          "p": 365765
        }
      ],
      "n": "Register",
      "d": 2266309,
      "h": 292060042437,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(292060042437),
//--TRIMMABLE-BOUNDARY-START(60131808453),
    {
      "r": 65537,
      "p": [
        {
          "n": "editable",
          "p": 365765
        }
      ],
      "n": "DeRegister",
      "d": 2266309,
      "h": 60131808453,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131808453),
//--TRIMMABLE-BOUNDARY-START(300649977029),
    {
      "r": 178454529,
      "p": [
        {
          "n": "metas",
          "p": $.$typeArray($.$MDmQ.LCCWC.WebsitePageMeta).$h,
          "f": 16
        }
      ],
      "n": "RequiresMetas",
      "d": 2266309,
      "h": 300649977029,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(300649977029),
//--TRIMMABLE-BOUNDARY-START(309239911621),
    {
      "r": 178454529,
      "p": [
        {
          "n": "styles",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "RequiresStyleSheets",
      "d": 2266309,
      "h": 309239911621,
      "f": 16781316
    },
//--TRIMMABLE-BOUNDARY-END(309239911621),
//--TRIMMABLE-BOUNDARY-START(304944944325),
    {
      "r": 178454529,
      "p": [
        {
          "n": "scripts",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "RequiresScripts",
      "d": 2266309,
      "h": 304944944325,
      "f": 16781316
    },
//--TRIMMABLE-BOUNDARY-END(304944944325),
//--TRIMMABLE-BOUNDARY-START(313534878917),
    {
      "r": 1310721,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "ResolvePath",
      "d": 2266309,
      "h": 313534878917,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(313534878917),
//--TRIMMABLE-BOUNDARY-START(420909061317),
    {
      "r": 65537,
      "n": "StartAutoSave",
      "d": 2266309,
      "h": 420909061317,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(420909061317),
//--TRIMMABLE-BOUNDARY-START(223340565701),
    {
      "r": 181338113,
      "n": "InitJs",
      "d": 2266309,
      "h": 223340565701,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223340565701),
//--TRIMMABLE-BOUNDARY-START(253405336773),
    {
      "r": 181338113,
      "p": [
        {
          "n": "context",
          "p": 10616947
        }
      ],
      "n": "NavigatingAway",
      "d": 2266309,
      "h": 253405336773,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(253405336773),
//--TRIMMABLE-BOUNDARY-START(450973832389),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "args",
          "p": 80543745
        }
      ],
      "n": "WebsiteStoreUpdated",
      "d": 2266309,
      "h": 450973832389,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(450973832389),
//--TRIMMABLE-BOUNDARY-START(266290238661),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 2266309,
      "h": 266290238661,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(266290238661),
//--TRIMMABLE-BOUNDARY-START(261995271365),
    {
      "r": 178454529,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": 2266309,
      "h": 261995271365,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(261995271365),
//--TRIMMABLE-BOUNDARY-START(64426775749),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2266309,
      "h": 64426775749,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426775749),
//--TRIMMABLE-BOUNDARY-START(416614094021),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 1310721
        },
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "SetText",
      "d": 2266309,
      "h": 416614094021,
      "f": 16777217,
      "a": [
        {
          "t": 2818162,
          "c": 8592752754
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(416614094021)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(231930500293),
    {
      "t": 262145,
      "n": "isEditting",
      "d": 2266309,
      "h": 231930500293,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(231930500293),
//--TRIMMABLE-BOUNDARY-START(73016710341),
    {
      "t": $.$$.SCG.List$$($.$MDmQ.LCCWCE.IWebsiteEditable).$h,
      "n": "editables",
      "d": 2266309,
      "h": 73016710341,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73016710341),
//--TRIMMABLE-BOUNDARY-START(279175140549),
    {
      "t": 262145,
      "n": "pageDirty",
      "d": 2266309,
      "h": 279175140549,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(279175140549),
//--TRIMMABLE-BOUNDARY-START(446678865093),
    {
      "t": 262145,
      "n": "websiteDirty",
      "d": 2266309,
      "h": 446678865093,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(446678865093),
//--TRIMMABLE-BOUNDARY-START(68721743045),
    {
      "t": 262145,
      "n": "disposed",
      "d": 2266309,
      "h": 68721743045,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68721743045),
//--TRIMMABLE-BOUNDARY-START(219045598405),
    {
      "t": 262145,
      "n": "initialized",
      "d": 2266309,
      "h": 219045598405,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(219045598405),
//--TRIMMABLE-BOUNDARY-START(296355009733),
    {
      "t": 262145,
      "n": "rendered",
      "d": 2266309,
      "h": 296355009733,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(296355009733),
//--TRIMMABLE-BOUNDARY-START(244815402181),
    {
      "t": 262145,
      "n": "jsInit",
      "d": 2266309,
      "h": 244815402181,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(244815402181),
//--TRIMMABLE-BOUNDARY-START(249110369477),
    {
      "t": 91095041,
      "n": "navigatingAway",
      "d": 2266309,
      "h": 249110369477,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(249110369477)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42951939269),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2266309,
      "h": 42951939269,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(42951939269)
  ],
  "h": 2266309
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$AEuu.LCCWCM.IWebsiteDataSource, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.WebsitePage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}WebsitePage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2266309)
        
        

        //--TRIMMABLE-BOUNDARY-START(1021125)
        $asm.$cls(`$MDmQ.LCCWC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295988421)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295988421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MDmQ.LCCWCS$1.WebsitePageAdminCommands.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MDmQ.LCCWCS$1.WebsitePageAdminCommandsCustomAttributesProvider, $.$MDmQ.LCCWCS$1.WebsitePageAdminCommandsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295988421)
            
            static $h = 1021125;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295988421),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 1021125,
      "h": 4295988421,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295988421)
  ],
  "h": 1021125
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1021125)
        
        

        //--TRIMMABLE-BOUNDARY-START(1676485)
        $asm.$cls(`$MDmQ.LCCWCS$1.WebsiteEditableContext`, ($self) => class WebsiteEditableContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886578373)
            /*bool*/ Collapsed = false;
            //--TRIMMABLE-BOUNDARY-END(12886578373)
            
            //--TRIMMABLE-BOUNDARY-START(8591611077)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591611077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591611077)
            
            //--TRIMMABLE-BOUNDARY-START(8591611077)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591611077)
            
            static $h = 1676485;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886578373),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476512965,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066447557,
        "f": 83886081
      },
      "n": "Collapsed",
      "d": 1676485,
      "h": 12886578373,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886578373)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591611077),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1676485,
      "h": 8591611077,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591611077)
  ],
  "h": 1676485
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Shared.WebsiteEditableContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Shared${separator}WebsiteEditableContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1676485)
        
        

        //--TRIMMABLE-BOUNDARY-START(1086661)
        $asm.$cls(`$MDmQ.LCCWC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296053957)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296053957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4296053957)
            
            static $h = 1086661;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296053957),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 1086661,
      "h": 4296053957,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296053957)
  ],
  "h": 1086661
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1086661)
        
        

        //--TRIMMABLE-BOUNDARY-START(1938629)
        $asm.$cls(`$MDmQ.LCCWCS$1.WebsitePageAdminCommandsCustomAttributesProvider`, ($self) => class WebsitePageAdminCommandsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296905925)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296905925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296905925)
            
            static $h = 1938629;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296905925),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1938629,
      "h": 4296905925,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296905925)
  ],
  "h": 1938629
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Shared.WebsitePageAdminCommandsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Shared${separator}WebsitePageAdminCommandsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1938629)
        
        

        //--TRIMMABLE-BOUNDARY-START(234693)
        $asm.$cls(`$MDmQ.LCCWC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295201989)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295201989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$MDmQ.LCCWC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295201989)
            
            static $h = 234693;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295201989),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 234693,
      "h": 4295201989,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295201989)
  ],
  "h": 234693
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(234693)
        
        

        //--TRIMMABLE-BOUNDARY-START(1217733)
        $asm.$cls(`$MDmQ.LCCWC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591152325)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591152325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$MDmQ.LCCWCP.Website, "LivingThing.Core.Community.Website.Client", "Pages\\Website", "Website", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/WebsiteView/{*PageRoute}" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8591152325)
            
            //--TRIMMABLE-BOUNDARY-START(4296185029)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296185029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296185029)
            
            //--TRIMMABLE-BOUNDARY-START(4296185029)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296185029)
            
            static $h = 1217733;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591152325),
    {
      "r": 65537,
      "n": "Build",
      "d": 1217733,
      "h": 8591152325,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591152325)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296185029),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1217733,
      "h": 4296185029,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296185029)
  ],
  "h": 1217733
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1217733)
        
        

        //--TRIMMABLE-BOUNDARY-START(2200773)
        $asm.$cls(`$MDmQ.LCCWC.WebsiteDataSourceExtension`, ($self) => class WebsiteDataSourceExtension
        {
            //--TRIMMABLE-BOUNDARY-START(8592135365)
            static /*string? */ GetData(/*this IWebsiteDataSource*/ dataSource, /*IWebsiteEditable*/ editable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592135365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let val = null;
                if (!((dataSource.LCCWCM$IWebsiteDataSource$UpdateStore(null)?.TryGetValue(editable.LCCWCE$IWebsiteEditable$CId, $.$ref(() => val, ($v) => val = $v, $.$$.S.String)) ?? null) ?? false))
                {
                    dataSource.LCCWCM$IWebsiteDataSource$Parent?.LCCWCM$IWebsiteDataSource$UpdateStore(null)?.TryGetValue(editable.LCCWCE$IWebsiteEditable$CId, $.$ref(() => val, ($v) => val = $v, $.$$.S.String));
                }
                return val;
            }
            //--TRIMMABLE-BOUNDARY-END(8592135365)
            
            //--TRIMMABLE-BOUNDARY-START(17182069957)
            static /*void */ SetData(/*this IWebsiteDataSource*/ dataSource, /*IWebsiteEditable*/ editable, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182069957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    $.$MDmQ.LCCWC.WebsiteDataSourceExtension.ClearData(dataSource, editable);
                }
                else 
                {
                    if ($.$is(editable, $.$MDmQ.LCCWCE.IWebsiteCommonEditable) && dataSource.LCCWCM$IWebsiteDataSource$Parent !== null)
                    {
                        dataSource.LCCWCM$IWebsiteDataSource$Parent.LCCWCM$IWebsiteDataSource$UpdateStore(new ($.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)))().$ctor(this,  (/*store*/ store) =>
                        {
                            return store.set_Item(editable.LCCWCE$IWebsiteEditable$CId, value);
                        }, $fNvDsf ??= {"r":65537,"p":[{"n":"store","p":$.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h}],"n":"","d":2200773,"h":0,"f":17825794}));
                    }
                    else 
                    {
                        dataSource.LCCWCM$IWebsiteDataSource$UpdateStore(new ($.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)))().$ctor(this,  (/*store*/ store) =>
                        {
                            return store.set_Item(editable.LCCWCE$IWebsiteEditable$CId, value);
                        }, $Qauvcc ??= {"r":65537,"p":[{"n":"store","p":$.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h}],"n":"","d":2200773,"h":0,"f":17825794}));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182069957)
            
            //--TRIMMABLE-BOUNDARY-START(12887102661)
            static /*List<CommunityWebsiteDataSource>? */ GetRepeaterData(/*this IWebsiteDataSource*/ dataSource, /*IWebsiteEditable*/ editable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887102661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<CommunityWebsiteDataSource>?*/ let val = null;
                if (!((dataSource.LCCWCM$IWebsiteDataSource$UpdateRepeaterStore(null)?.TryGetValue(editable.LCCWCE$IWebsiteEditable$CId, $.$ref(() => val, ($v) => val = $v, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource))) ?? null) ?? false))
                {
                    dataSource.LCCWCM$IWebsiteDataSource$Parent?.LCCWCM$IWebsiteDataSource$UpdateRepeaterStore(null)?.TryGetValue(editable.LCCWCE$IWebsiteEditable$CId, $.$ref(() => val, ($v) => val = $v, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource)));
                }
                if (val === null)
                {
                    if ($.$is(editable, $.$MDmQ.LCCWCE.IWebsiteCommonEditable) && dataSource.LCCWCM$IWebsiteDataSource$Parent !== null)
                    {
                        dataSource.LCCWCM$IWebsiteDataSource$Parent.LCCWCM$IWebsiteDataSource$UpdateRepeaterStore(new ($.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource))))().$ctor(this,  (/*store*/ store) =>
                        {
                            val = new ($.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource))().$ctor$1();
                            store.set_Item(editable.LCCWCE$IWebsiteEditable$CId, val);
                        }, $icZOuh ??= {"r":65537,"p":[{"n":"store","p":$.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource)).$h}],"n":"","d":2200773,"h":0,"f":17825794}));
                    }
                    else 
                    {
                        dataSource.LCCWCM$IWebsiteDataSource$UpdateRepeaterStore(new ($.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource))))().$ctor(this,  (/*store*/ store) =>
                        {
                            val = new ($.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource))().$ctor$1();
                            store.set_Item(editable.LCCWCE$IWebsiteEditable$CId, val);
                        }, $QqPQZb ??= {"r":65537,"p":[{"n":"store","p":$.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource)).$h}],"n":"","d":2200773,"h":0,"f":17825794}));
                    }
                }
                return val;
            }
            //--TRIMMABLE-BOUNDARY-END(12887102661)
            
            //--TRIMMABLE-BOUNDARY-START(4297168069)
            static /*void */ ClearData(/*this IWebsiteDataSource*/ dataSource, /*IWebsiteEditable*/ editable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297168069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(editable, $.$MDmQ.LCCWCE.IWebsiteCommonEditable) && dataSource.LCCWCM$IWebsiteDataSource$Parent !== null)
                {
                    dataSource.LCCWCM$IWebsiteDataSource$Parent.LCCWCM$IWebsiteDataSource$UpdateStore(new ($.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)))().$ctor(this,  (/*store*/ store) =>
                    {
                        return store.Remove$1(editable.LCCWCE$IWebsiteEditable$CId);
                    }, $BqhbXf ??= {"r":65537,"p":[{"n":"store","p":$.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h}],"n":"","d":2200773,"h":0,"f":17825794}));
                    dataSource.LCCWCM$IWebsiteDataSource$Parent.LCCWCM$IWebsiteDataSource$UpdateRepeaterStore(new ($.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource))))().$ctor(this,  (/*store*/ store) =>
                    {
                        return store.Remove$1(editable.LCCWCE$IWebsiteEditable$CId);
                    }, $oSRdYh ??= {"r":65537,"p":[{"n":"store","p":$.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource)).$h}],"n":"","d":2200773,"h":0,"f":17825794}));
                }
                else 
                {
                    dataSource.LCCWCM$IWebsiteDataSource$UpdateStore(new ($.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)))().$ctor(this,  (/**/ store) =>
                    {
                        return store.Remove$1(editable.LCCWCE$IWebsiteEditable$CId);
                    }, $hNOWUb ??= {"r":65537,"p":[{"n":"store","p":$.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h}],"n":"","d":2200773,"h":0,"f":17825794}));
                    dataSource.LCCWCM$IWebsiteDataSource$UpdateRepeaterStore(new ($.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource))))().$ctor(this,  (/*store*/ store) =>
                    {
                        return store.Remove$1(editable.LCCWCE$IWebsiteEditable$CId);
                    }, $lAwSFj ??= {"r":65537,"p":[{"n":"store","p":$.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource)).$h}],"n":"","d":2200773,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297168069)
            
            static $h = 2200773;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592135365),
    {
      "r": 1310721,
      "p": [
        {
          "n": "dataSource",
          "p": 1134721
        },
        {
          "n": "editable",
          "p": 365765
        }
      ],
      "n": "GetData",
      "d": 2200773,
      "h": 8592135365,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592135365),
//--TRIMMABLE-BOUNDARY-START(17182069957),
    {
      "r": 65537,
      "p": [
        {
          "n": "dataSource",
          "p": 1134721
        },
        {
          "n": "editable",
          "p": 365765
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "SetData",
      "d": 2200773,
      "h": 17182069957,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182069957),
//--TRIMMABLE-BOUNDARY-START(12887102661),
    {
      "r": $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource).$h,
      "p": [
        {
          "n": "dataSource",
          "p": 1134721
        },
        {
          "n": "editable",
          "p": 365765
        }
      ],
      "n": "GetRepeaterData",
      "d": 2200773,
      "h": 12887102661,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887102661),
//--TRIMMABLE-BOUNDARY-START(4297168069),
    {
      "r": 65537,
      "p": [
        {
          "n": "dataSource",
          "p": 1134721
        },
        {
          "n": "editable",
          "p": 365765
        }
      ],
      "n": "ClearData",
      "d": 2200773,
      "h": 4297168069,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297168069)
  ],
  "h": 2200773
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.WebsiteDataSourceExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}WebsiteDataSourceExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2200773)
        
        

        //--TRIMMABLE-BOUNDARY-START(103621)
        $asm.$cls(`$MDmQ._LCCWCSW.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295070917)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.Object*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295070917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "title", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295070917)
            
            //--TRIMMABLE-BOUNDARY-START(8590038213)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590038213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "PlaceHolder", __arg0);
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590038213)
            
            static $h = 103621;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295070917),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 131073
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 103621,
      "h": 4295070917,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295070917),
//--TRIMMABLE-BOUNDARY-START(8590038213),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 103621,
      "h": 8590038213,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590038213)
  ],
  "h": 103621
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Website.Client.Shared.WebsitePageAdminComponentBrowser.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Shared${separator}WebsitePageAdminComponentBrowser${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(103621)
        
        

        //--TRIMMABLE-BOUNDARY-START(1152197)
        $asm.$cls(`$MDmQ.LCCWC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181021381)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MDmQ.LCCWCE.WebsiteEditableAnchor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MDmQ.LCCWCE.WebsiteEditableAnchor().$ctor$4();
                    }, $oHSlQe ??= {"r":2752627,"n":"","d":1152197,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MDmQ.LCCWCE.WebsiteEditableImage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MDmQ.LCCWCE.WebsiteEditableImage().$ctor$5();
                    }, $vBLjzk ??= {"r":2752627,"n":"","d":1152197,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MDmQ.LCCWCE.WebsiteEditableRepeater.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MDmQ.LCCWCE.WebsiteEditableRepeater().$ctor$4();
                    }, $UkQpsg ??= {"r":2752627,"n":"","d":1152197,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MDmQ.LCCWCE.WebsiteEditableSource.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MDmQ.LCCWCE.WebsiteEditableSource().$ctor$5();
                    }, $fimyIa ??= {"r":2752627,"n":"","d":1152197,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MDmQ.LCCWCE.WebsiteEditableText.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MDmQ.LCCWCE.WebsiteEditableText().$ctor$3();
                    }, $OqjMTe ??= {"r":2752627,"n":"","d":1152197,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MDmQ.LCCWCE.WebsiteEditableCommonText.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MDmQ.LCCWCE.WebsiteEditableCommonText().$ctor$4();
                    }, $tEAPUd ??= {"r":2752627,"n":"","d":1152197,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MDmQ.LCCWCP.CommunityWebsiteApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MDmQ.LCCWCP.CommunityWebsiteApp().$ctor$6();
                    }, $oGZstd ??= {"r":2752627,"n":"","d":1152197,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MDmQ.LCCWCP.Website.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MDmQ.LCCWCP.Website().$ctor$3();
                    }, $pVpDEh ??= {"r":2752627,"n":"","d":1152197,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MDmQ.LCCWCS$1.WebsiteMarketStore.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MDmQ.LCCWCS$1.WebsiteMarketStore().$ctor$4();
                    }, $YjQBHh ??= {"r":2752627,"n":"","d":1152197,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MDmQ.LCCWCS$1.WebsitePageAdminComponentBrowser.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MDmQ.LCCWCS$1.WebsitePageAdminComponentBrowser().$ctor$3();
                    }, $PXbtXj ??= {"r":2752627,"n":"","d":1152197,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MDmQ.LCCWCS$1.WebsitePageAdminPanel.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MDmQ.LCCWCS$1.WebsitePageAdminPanel().$ctor$3();
                    }, $SGehAa ??= {"r":2752627,"n":"","d":1152197,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MDmQ.LCCWCS$1.WebsitePageAdminTextEditor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MDmQ.LCCWCS$1.WebsitePageAdminTextEditor().$ctor$3();
                    }, $vxTFGe ??= {"r":2752627,"n":"","d":1152197,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MDmQ.LCCWC.WebsiteSection.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MDmQ.LCCWC.WebsiteSection().$ctor$2();
                    }, $MJSCZe ??= {"r":2752627,"n":"","d":1152197,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17181021381)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4296119493)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296119493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296119493)
            
            //--TRIMMABLE-BOUNDARY-START(4296119493)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296119493)
            
            static $h = 1152197;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181021381),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886054085,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 1152197,
      "h": 17181021381,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181021381)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296119493),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1152197,
      "h": 4296119493,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296119493)
  ],
  "h": 1152197
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1152197)
        
        

        //--TRIMMABLE-BOUNDARY-START(1414341)
        $asm.$cls(`$MDmQ.LCCWC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591348933)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591348933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$MDmQ.LCCWCS.CommunityWebsiteService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$AEuu.LCCWCM.CommunityWebsiteHostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$MDmQ.LCCWCS.CommunityWebsiteApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MDmQ.LCCWCS.CommunityWebsiteApplication, x);
                }, $vTOrBh ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":1414341,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MDmQ.LCCWCS.CommunityWebsiteApplication, x);
                }, $LmKkxi ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":1414341,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$MDmQ.LCCWCS.CommunityWebsiteFeedProvider, services);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$AEuu.LCCWCM.CommunityWebsiteHostModel, services, null);
                $.$MDmQ.LCCWC._Startup.AddGeneratedComponentOptimizers(services);
                if (startupOptions.Runtime === 1/*RuntimeType.WebServer*/)
                {
                    $.$hDPm.LCFC.StaticComponentServiceRegistrar.AddFixedComponent($.$MDmQ.LCCWCS$1.WebsitePageAdminPanel, services, new ($.$$.S.Action$$($.$hDPm.LCFCS.FixedComponentConfiguration))().$ctor(this,  (/*option*/ option) =>
                    {
                        option.Title = $.$fPer.LCFCO.OneOf$$$($.$$.S.String, $.$$.S.Func$$$$($.$hDPm.LCFCI.IClientUnitOfWork, $.$hDPm.LCFCS.IFixedComponentControl, $.$mac.MAC.RenderFragment)).op_Implicit("Web Admin");
                        option.Show = new ($.$$.S.Func$$$$($.$hDPm.LCFCI.IClientUnitOfWork, $.$hDPm.LCFCS.IFixedComponentControl, $.$$.S.Boolean))().$ctor(this,  (/**/ unitOfWork, /*control*/ control) =>
                        {
                            /*var*/ let website = $.$fPer.LCFCD.WorkSpaceExtension.Get($.$MDmQ.LCCWCP.Website, unitOfWork.LCFCI$IClientUnitOfWork$MessagingCenter, null, null, null, false, true);
                            return website !== null;
                        }, $AWzmBj ??= {"r":262145,"p":[{"n":"unitOfWork","p":63657642},{"n":"control","p":69621418}],"n":"","d":1414341,"h":0,"f":17825794});
                    }, $vmymTc ??= {"r":65537,"p":[{"n":"option","p":69359274}],"n":"","d":1414341,"h":0,"f":17825794}));
                    $.$hDPm.LCFC.StaticComponentServiceRegistrar.AddFixedFloatingComponent($.$MDmQ.LCCWCS$1.WebsitePageAdminComponentBrowser, services, new ($.$$.S.Action$$($.$hDPm.LCFCS.FixedComponentConfiguration))().$ctor(this,  (/**/ option) =>
                    {
                        option.Show = new ($.$$.S.Func$$$$($.$hDPm.LCFCI.IClientUnitOfWork, $.$hDPm.LCFCS.IFixedComponentControl, $.$$.S.Boolean))().$ctor(this,  (/**/ unitOfWork, /*control*/ control) =>
                        {
                            /*var*/ let website = $.$fPer.LCFCD.WorkSpaceExtension.Get($.$MDmQ.LCCWCP.Website, unitOfWork.LCFCI$IClientUnitOfWork$MessagingCenter, null, null, null, false, true);
                            return website !== null;
                        }, $lclgGb ??= {"r":262145,"p":[{"n":"unitOfWork","p":63657642},{"n":"control","p":69621418}],"n":"","d":1414341,"h":0,"f":17825794});
                    }, $JXAADd ??= {"r":65537,"p":[{"n":"option","p":69359274}],"n":"","d":1414341,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591348933)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$MDmQ.LCCWC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296381637)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296381637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296381637)
            
            //--TRIMMABLE-BOUNDARY-START(4296381637)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296381637)
            
            static $h = 1414341;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591348933),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1414341,
      "h": 8591348933,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591348933)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296381637),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1414341,
      "h": 4296381637,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296381637)
  ],
  "h": 1414341
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1414341)
        
        

        //--TRIMMABLE-BOUNDARY-START(1807557)
        $asm.$str(`$MDmQ.LCCWCS$1.WebsiteMarketStoreContext`, ($self) => class WebsiteMarketStoreContext extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21476644037)
            /*ICommunityMarketServiceProvider*/ Provider = null;
            //--TRIMMABLE-BOUNDARY-END(21476644037)
            
            //--TRIMMABLE-BOUNDARY-START(8591742149)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591742149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591742149)
            
            //--TRIMMABLE-BOUNDARY-START(8591742149)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8591742149)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Provider = this.Provider;
                return copy;
            }
            static $h = 1807557;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476644037),
    {
      "p": 17864128,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181676741,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066578629,
        "f": 83886081
      },
      "n": "Provider",
      "d": 1807557,
      "h": 21476644037,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476644037)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591742149),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1807557,
      "h": 8591742149,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591742149)
  ],
  "h": 1807557
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Shared.WebsiteMarketStoreContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Shared${separator}WebsiteMarketStoreContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1807557)
        
        

        //--TRIMMABLE-BOUNDARY-START(2331845)
        $asm.$str(`$MDmQ.LCCWC.WebsitePageMeta`, ($self) => class WebsitePageMeta extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12887233733)
            /*Dictionary<string, string>*/ Attributes = null;
            //--TRIMMABLE-BOUNDARY-END(12887233733)
            
            //--TRIMMABLE-BOUNDARY-START(8592266437)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592266437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592266437)
            
            //--TRIMMABLE-BOUNDARY-START(8592266437)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592266437)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Attributes = this.Attributes;
                return copy;
            }
            static $h = 2331845;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887233733),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477168325,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30067102917,
        "f": 83886081
      },
      "n": "Attributes",
      "d": 2331845,
      "h": 12887233733,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12887233733)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592266437),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2331845,
      "h": 8592266437,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592266437)
  ],
  "h": 2331845
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.WebsitePageMeta`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}WebsitePageMeta`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2331845)
        
        

        //--TRIMMABLE-BOUNDARY-START(2528453)
        $asm.$cls(`$MDmQ.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297495749)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297495749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297495749)
            
            //--TRIMMABLE-BOUNDARY-START(4297495749)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297495749)
            
            static $h = 2528453;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297495749),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2528453,
      "h": 4297495749,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297495749)
  ],
  "h": 2528453,
  "a": [
    {
      "t": 2462917,
      "c": 4297430213
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2528453)
        
        

        //--TRIMMABLE-BOUNDARY-START(2462917)
        $asm.$cls(`$MDmQ.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297430213)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297430213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297430213)
            
            //--TRIMMABLE-BOUNDARY-START(4297430213)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297430213)
            
            static $h = 2462917;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297430213),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2462917,
      "h": 4297430213,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297430213)
  ],
  "h": 2462917
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2462917)
        
        

        //--TRIMMABLE-BOUNDARY-START(2397381)
        $asm.$cls(`$MDmQ.LCCWC.WebsiteSection`, ($self) => class WebsiteSection extends $.$mac.MAC.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362135749)
            /*WebsitePage*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(34362135749)
            
            //--TRIMMABLE-BOUNDARY-START(30067168453)
            /*string */ get OptimizedComponentName()
            {
                return "websitesection";
            }
            //--TRIMMABLE-BOUNDARY-END(30067168453)
            
            //--TRIMMABLE-BOUNDARY-START(51542004933)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542004933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$MDmQ.LCCWC.WebsitePage);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(51542004933)
            
            //--TRIMMABLE-BOUNDARY-START(47247037637)
            /*Task */ SetParametersAsync(/*ParameterView*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247037637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Task*/ let beginTask = ($.$cast(this, $.$hDPm.LCFCC$1.IBaseComponent)).LCFCC$1$IBaseComponent$BeginSetParametersAsync();
                $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                {
                    let $en2 = parameters.GetEnumerator();
                    while ($en2.MoveNext())
                    {
                        let parameter = $en2.Current;
                        {
                            /*bool*/ let set = this.TrySetParameter(parameter);
                        }
                    }
                }, $DYSDCe ??= {"r":65537,"n":"","d":2397381,"h":0,"f":17825794}), 0, "SetParametersAsync " + $.$strNN(this.OptimizedComponentName), "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Website.Client.Blazor\\WebsiteSection_WebsiteSectionParametertSetter.g.cs", "SetParametersAsync", 32);
                /*Task*/ let endTask = super.SetParametersAsync($.$mac.MAC.ParameterView.Empty);
                if (!beginTask.IsCompletedSuccessfully && !endTask.IsCompletedSuccessfully)
                {
                    return $.$$.STT.Task.WhenAll$1($.$$.S.ReadOnlySpan$$($.$$.STT.Task).op_Implicit$1([ beginTask, endTask ]));
                }
                if (!beginTask.IsCompletedSuccessfully)
                {
                    return beginTask;
                }
                if (!endTask.IsCompletedSuccessfully)
                {
                    return endTask;
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(47247037637)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8592331973)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592331973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592331973)
            
            //--TRIMMABLE-BOUNDARY-START(8592331973)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592331973)
            
            static $h = 2397381;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.ComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362135749),
    {
      "p": 2266309,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772201157,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42952070341,
        "f": 83886081
      },
      "n": "Page",
      "d": 2397381,
      "h": 34362135749,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34362135749),
//--TRIMMABLE-BOUNDARY-START(30067168453),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182266565,
        "f": 50331649
      },
      "n": "OptimizedComponentName",
      "d": 2397381,
      "h": 30067168453,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067168453)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51542004933),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2397381,
      "h": 51542004933,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542004933),
//--TRIMMABLE-BOUNDARY-START(47247037637),
    {
      "r": 178454529,
      "p": [
        {
          "n": "parameters",
          "p": 5767283
        }
      ],
      "n": "SetParametersAsync",
      "d": 2397381,
      "h": 47247037637,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47247037637)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592331973),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2397381,
      "h": 8592331973,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592331973)
  ],
  "h": 2397381
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.WebsiteSection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}WebsiteSection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2397381)
        
        

        //--TRIMMABLE-BOUNDARY-START(1873093)
        $asm.$str(`$MDmQ.LCCWCS$1.WebsitePageAdminCommands`, ($self) => class WebsitePageAdminCommands extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static OpenBrowser = 0;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1873093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "OpenBrowser": 0n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296840389)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296840389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296840389)
            
            //--TRIMMABLE-BOUNDARY-START(4296840389)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296840389)
            
            static $h = 1873093;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591807685),
    {
      "t": 1873093,
      "n": "OpenBrowser",
      "d": 1873093,
      "h": 8591807685,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591807685)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296840389),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1873093,
      "h": 4296840389,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296840389)
  ],
  "h": 1873093
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Shared.WebsitePageAdminCommands`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Shared${separator}WebsitePageAdminCommands`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1873093)
        
        

        //--TRIMMABLE-BOUNDARY-START(2135237)
        $asm.$cls(`$MDmQ.LCCWCS$1.WebsitePageAdminTextEditor`, ($self) => class WebsitePageAdminTextEditor extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(34361873605)
            /*WebsiteEditableText*/ Text = null;
            //--TRIMMABLE-BOUNDARY-END(34361873605)
            
            //--TRIMMABLE-BOUNDARY-START(12887037125)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887037125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<h3>WebsitePageAdminTextEditor</h3>");
            }
            //--TRIMMABLE-BOUNDARY-END(12887037125)
            
            //--TRIMMABLE-BOUNDARY-START(8592069829)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592069829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592069829)
            
            //--TRIMMABLE-BOUNDARY-START(8592069829)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8592069829)
            
            static $h = 2135237;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361873605),
    {
      "p": 955589,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476971717,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066906309,
        "f": 83886081
      },
      "n": "Text",
      "d": 2135237,
      "h": 34361873605,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361873605)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887037125),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2135237,
      "h": 12887037125,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12887037125)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592069829),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2135237,
      "h": 8592069829,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592069829)
  ],
  "h": 2135237
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Shared.WebsitePageAdminTextEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Shared${separator}WebsitePageAdminTextEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2135237)
        
        

        //--TRIMMABLE-BOUNDARY-START(169157)
        $asm.$cls(`$MDmQ.LCCWC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590103749)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590103749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590103749)
            
            //--TRIMMABLE-BOUNDARY-START(4295136453)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295136453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295136453)
            
            //--TRIMMABLE-BOUNDARY-START(4295136453)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295136453)
            
            static $h = 169157;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590103749),
    {
      "r": 65537,
      "n": "Execute",
      "d": 169157,
      "h": 8590103749,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590103749)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295136453),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 169157,
      "h": 4295136453,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295136453)
  ],
  "h": 169157
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(169157)
        
        

        //--TRIMMABLE-BOUNDARY-START(2069701)
        $asm.$cls(`$MDmQ.LCCWCS$1.WebsitePageAdminPanel`, ($self) => class WebsitePageAdminPanel extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(17181938885)
            /*IFixedComponentControl*/ FixedControl = null;
            //--TRIMMABLE-BOUNDARY-END(17181938885)
            
            //--TRIMMABLE-BOUNDARY-START(30066840773)
            /*ValueTask */ OpenBrowser()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066840773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.UnitOfWork.LCFCI$IClientUnitOfWork$MessagingCenter.Send($.$MDmQ.LCCWCS$1.WebsitePageAdminCommands, 0/*WebsitePageAdminCommands.OpenBrowser*/, $.$box(true, $.$$.S.Boolean));
                return this.FixedControl.LCFCS$IFixedComponentControl$Close();
            }
            //--TRIMMABLE-BOUNDARY-END(30066840773)
            
            //--TRIMMABLE-BOUNDARY-START(12886971589)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886971589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 0);
                __builder.AddComponentParameter(1, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                __builder.AddComponentParameter(2, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.OpenBrowser))));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.AddContent$4(4, "Launch Editor");
                }), $LvMJhf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2069701,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12886971589)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8592004293)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592004293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592004293)
            
            //--TRIMMABLE-BOUNDARY-START(8592004293)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8592004293)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17181938885)
                this.FixedControl = null;
                //--TRIMMABLE-BOUNDARY-END(17181938885)
                
            }
            static $h = 2069701;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181938885),
    {
      "p": 69621418,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771873477,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38656775365,
        "f": 83886081
      },
      "n": "FixedControl",
      "d": 2069701,
      "h": 17181938885,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181938885)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066840773),
    {
      "r": 181338113,
      "n": "OpenBrowser",
      "d": 2069701,
      "h": 30066840773,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30066840773),
//--TRIMMABLE-BOUNDARY-START(12886971589),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2069701,
      "h": 12886971589,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886971589)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592004293),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2069701,
      "h": 8592004293,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592004293)
  ],
  "h": 2069701
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Shared.WebsitePageAdminPanel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Shared${separator}WebsitePageAdminPanel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2069701)
        
        

        //--TRIMMABLE-BOUNDARY-START(2004165)
        $asm.$cls(`$MDmQ.LCCWCS$1.WebsitePageAdminComponentBrowser`, ($self) => class WebsitePageAdminComponentBrowser extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(111671153861)
            /*string */ get OptimizedComponentName()
            {
                return "websitepageadmincomponentbrowser";
            }
            //--TRIMMABLE-BOUNDARY-END(111671153861)
            
            //--TRIMMABLE-BOUNDARY-START(90196317381)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196317381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.AuthenticationService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientAuthenticationService, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MDmQ.LCCWCS.CommunityWebsiteService, serviceProvider);
                this.Js = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(90196317381)
            
            //--TRIMMABLE-BOUNDARY-START(21476840645)
            /*IClientAuthenticationService*/ AuthenticationService = null;
            //--TRIMMABLE-BOUNDARY-END(21476840645)
            
            //--TRIMMABLE-BOUNDARY-START(115966121157)
            /*CommunityWebsiteService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(115966121157)
            
            //--TRIMMABLE-BOUNDARY-START(98786251973)
            /*IJavaScriptRunner*/ Js = null;
            //--TRIMMABLE-BOUNDARY-END(98786251973)
            
            //--TRIMMABLE-BOUNDARY-START(146030892229)
            /*bool*/ show = false;
            //--TRIMMABLE-BOUNDARY-END(146030892229)
            
            //--TRIMMABLE-BOUNDARY-START(85901350085)
            /*bool*/ hasShown = false;
            //--TRIMMABLE-BOUNDARY-END(85901350085)
            
            //--TRIMMABLE-BOUNDARY-START(42951677125)
            /*string*/ filterText = null;
            //--TRIMMABLE-BOUNDARY-END(42951677125)
            
            //--TRIMMABLE-BOUNDARY-START(34361742533)
            /*ElementReference*/ dragHandle;
            //--TRIMMABLE-BOUNDARY-END(34361742533)
            
            //--TRIMMABLE-BOUNDARY-START(38656709829)
            /*ElementReference*/ dragPosition;
            //--TRIMMABLE-BOUNDARY-END(38656709829)
            
            //--TRIMMABLE-BOUNDARY-START(47246644421)
            /*IWebsiteEditable*/ focused = null;
            //--TRIMMABLE-BOUNDARY-END(47246644421)
            
            //--TRIMMABLE-BOUNDARY-START(94491284677)
            /*bool */ IsCollapsed(/*IWebsiteEditable*/ ed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491284677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.focused !== ed;
            }
            //--TRIMMABLE-BOUNDARY-END(94491284677)
            
            //--TRIMMABLE-BOUNDARY-START(150325859525)
            /*void */ ToggleCollapsed(/*IWebsiteEditable*/ ed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325859525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.focused === ed)
                {
                    this.focused = null;
                }
                else 
                {
                    this.focused = ed;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150325859525)
            
            //--TRIMMABLE-BOUNDARY-START(107376186565)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376186565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let disposer = this.UnitOfWork.LCFCI$IClientUnitOfWork$MessagingCenter.Subscribe($.$MDmQ.LCCWCS$1.WebsitePageAdminCommands, new ($.$$.S.Action$$$($.$MDmQ.LCCWCS$1.WebsitePageAdminCommands, $.$$.S.Object))().$ctor(this,  (/*e*/ e, /*v*/ v) =>
                {
                    this.show = $.$cast(v, $.$$.S.Boolean);
                    if (this.show)
                    {
                        this.hasShown = true;
                    }
                    _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Website.Client.Blazor\\WebsitePageAdminComponentBrowser.razor.cs", "OnInitialized", 80);
                }, $SbKMuc ??= {"r":65537,"p":[{"n":"e","p":1873093},{"n":"v","p":131073}],"n":"","d":2004165,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$MDmQ.LCCWCS$1.WebsitePageAdminCommands, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e === 0/*WebsitePageAdminCommands.OpenBrowser*/;
                }, $lJdyii ??= {"r":262145,"p":[{"n":"e","p":1873093}],"n":"","d":2004165,"h":0,"f":17825794}));
                this.add_OnDisposed(new $.$$.S.EventHandler().$ctor(this,  (/*s*/ s, /*e*/ e) =>
                {
                    return disposer.Dispose();
                }, $xKpxuj ??= {"r":65537,"p":[{"n":"s","p":131073},{"n":"e","p":80543745}],"n":"","d":2004165,"h":0,"f":17825794}));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(107376186565)
            
            //--TRIMMABLE-BOUNDARY-START(30066775237)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066775237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.show = false;
            }
            //--TRIMMABLE-BOUNDARY-END(30066775237)
            
            //--TRIMMABLE-BOUNDARY-START(103081219269)
            /*void */ OnAfterRender(/*bool*/ firstRender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081219269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (firstRender && this.dragHandle.Id !== null)
                {
                    $.$hDPm.LCFCCD$7.DraggableExtension.Draggable(this.Js, null, 3/*DraggableFeatures.DragXY*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCCD$7.Draggabble), [ (() =>
                    {
                        //new $.$hDPm.LCFCCD$7.Draggabble()
                        const $t1 = $.$hDPm.LCFCCD$7.Draggabble;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.DragHandle = this.dragHandle;
                        $i1.DragPosition = this.dragPosition;
                        return $i1;
                    })() ], null, null));
                }
                super.OnAfterRender(firstRender);
            }
            //--TRIMMABLE-BOUNDARY-END(103081219269)
            
            //--TRIMMABLE-BOUNDARY-START(25771807941)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771807941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("lt" + " bg-dark") + " pos-fix") + " wx-3") + " mahv-100") + " stack") + " z-10") + " t-0") + " r-0") + " ") + $.$strNN((this.show ? "" : "d-hide")));
                __builder.AddElementReferenceCapture(2, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.dragPosition = __value;
                }, $VwoSub ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":2004165,"h":0,"f":17825794}));
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "toolbar bg-highlight-05 stack pd-2");
                __builder.AddElementReferenceCapture(5, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.dragHandle = __value;
                }, $RtYrma ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":2004165,"h":0,"f":17825794}));
                __builder.OpenElement(6, "div");
                __builder.AddAttribute$5(7, "class", "flex");
                __builder.AddMarkupContent(8, "<small class=\"mgy-a fill fw-bold\" draggable=\"true\">Page Editor</small>");
                if (this.Service.CurrentPage !== null && this.Service.CurrentPage.IsEditable)
                {
                    $.$MDmQ._LCCWCSW.TypeInference.CreateInputEditor_0($.$$.S.Boolean, __builder, 9, 10, "mgr mgy-a", 11, "Edit Mode", 12, this.Service.CurrentPage.IsEditting, 13, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Boolean, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Boolean, this, new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.Service.CurrentPage.IsEditting = __value;
                    }, $rGuSzd ??= {"r":65537,"p":[{"n":"__value","p":262145}],"n":"","d":2004165,"h":0,"f":17825794}), this.Service.CurrentPage.IsEditting)), 14, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                    {
                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Service"), "CurrentPage"), "IsEditting"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                    }, $UWANOc ??= {"r":38797349,"n":"","d":2004165,"h":0,"f":17825794})).Invoke()));
                }
                __builder.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountsToolBar, 15);
                __builder.AddComponentParameter(16, "Class", "mgr");
                __builder.CloseComponent();
                __builder.AddMarkupContent(17, "\r\n            ");
                __builder.OpenElement(18, "button");
                __builder.AddAttribute$5(19, "class", "lt button bg-transparent bd-0 mgy-a");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 20, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.Close)));
                __builder.AddContent$4(21, "X");
                __builder.CloseElement();
                __builder.CloseElement();
                if (this.Service.CurrentPage !== null && this.Service.CurrentPage.IsEditable)
                {
                    __builder.OpenComponent$1($.$macw.MACF.EditForm, 22);
                    __builder.AddComponentParameter(23, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                    __builder.AddComponentParameter(24, "class", "stack bdt pdy-2");
                    __builder.AddAttribute$3(25, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                        {
                            $.$MDmQ._LCCWCSW.TypeInference.CreateInputEditor_1($.$$.S.String, __builder2, 26, 27, "Search", 28, this.filterText, 29, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                return this.filterText = __value;
                            }, $weuaQi ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":2004165,"h":0,"f":17825794}), this.filterText)), 30, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                            {
                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "filterText"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                            }, $VOZTyi ??= {"r":38797349,"n":"","d":2004165,"h":0,"f":17825794})).Invoke()));
                        }, $LCXADj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2004165,"h":0,"f":17825794});
                    }), $zOhTAf ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":2004165,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                __builder.CloseElement();
                __builder.AddMarkupContent(31, "\r\n    ");
                __builder.OpenElement(32, "div");
                __builder.AddAttribute$5(33, "class", "scroll-y fill");
                if (this.Service.CurrentPage !== null)
                {
                    if (this.Service.CurrentPage.IsEditable)
                    {
                        if (this.Service.CurrentPage.IsEditting)
                        {
                            __builder.OpenComponent$1($.$macw.MACF.EditForm, 34);
                            __builder.AddComponentParameter(35, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                            __builder.AddAttribute$3(36, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                                {
                                    let $en2 = $.$sl.SL.Enumerable.Where($.$MDmQ.LCCWCE.IWebsiteEditable, $.$sl.SL.Enumerable.OrderBy$1($.$MDmQ.LCCWCE.IWebsiteEditable, $.$$.S.Int32, this.Service.CurrentPage.Editables, new ($.$$.S.Func$$$($.$MDmQ.LCCWCE.IWebsiteEditable, $.$$.S.Int32))().$ctor(this,  (/*e*/ e) =>
                                    {
                                        return $.$is(e, $.$MDmQ.LCCWCE.IWebsiteCommonEditable) ? 1 : 2;
                                    }, $zgGgIc ??= {"r":655361,"p":[{"n":"e","p":365765}],"n":"","d":2004165,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$MDmQ.LCCWCE.IWebsiteEditable, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                                    {
                                        return $.$$.S.String.IsNullOrEmpty(this.filterText) || $.$$.S.String.Contains$2.call($.$dsp(e, $.$$.S.Object, ($t) => $t.ToString), this.filterText, 3/*StringComparison.InvariantCultureIgnoreCase*/);
                                    }, $XXGcni ??= {"r":262145,"p":[{"n":"e","p":365765}],"n":"","d":2004165,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                                    while ($en2.SC$1$IEnumerator$MoveNext())
                                    {
                                        let element = $en2.SCG$IEnumerator$$$Current;
                                        {
                                            __builder2.OpenElement(37, "div");
                                            __builder2.AddAttribute$5(38, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("bdb" + " flex") + " pd-1") + " clickable") + " ") + $.$strNN(($.$is(element, $.$MDmQ.LCCWCE.IWebsiteCommonEditable) ? "bg-error-02" : ""))) + " ") + $.$strNN((!this.IsCollapsed(element) ? "bg-black-05" : "")));
                                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 39, "onclick", $.$mac.MAC.EventCallback.Factory.Create$8($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Action$$($.$macw.MACW.MouseEventArgs))().$ctor(this,  (/*e*/ e) =>
                                            {
                                                return this.ToggleCollapsed(element);
                                            }, $hGUKag ??= {"r":65537,"p":[{"n":"e","p":6750325}],"n":"","d":2004165,"h":0,"f":17825794})));
                                            __builder2.OpenElement(40, "i");
                                            __builder2.AddAttribute$5(41, "class", $.$strNN($.$strNN("mdi" + " mdi-chevron-") + $.$strNN((this.IsCollapsed(element) ? "right" : "down"))) + " mgr");
                                            __builder2.CloseElement();
                                            __builder2.AddMarkupContent(42, "\r\n                                ");
                                            __builder2.OpenElement(43, "small");
                                            __builder2.AddContent$4(44, $.$dspc(element, $.$$.S.Object, ($t) => $t.ToString));
                                            __builder2.CloseElement();
                                            __builder2.CloseElement();
                                            if (!this.IsCollapsed(element))
                                            {
                                                __builder2.OpenElement(45, "div");
                                                __builder2.AddAttribute$5(46, "class", "bg-black-05");
                                                let text;
                                                let anchor;
                                                let image;
                                                let source;
                                                if ($.$is(element, $.$MDmQ.LCCWCE.WebsiteEditableText, { set $v($v){ text = $v; } }))
                                                {
                                                    __builder2.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$($.$$.S.String), 47);
                                                    __builder2.AddComponentParameter(48, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.InputType, 16n), $.$fPer.LCFC.InputType));
                                                    __builder2.AddComponentParameter(49, "PlaceHolder", "Text");
                                                    __builder2.AddComponentParameter(50, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, text.Text));
                                                    __builder2.AddComponentParameter(51, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                                    {
                                                        return text.Text = __value;
                                                    }, $GVLIxc ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":2004165,"h":0,"f":17825794}), text.Text))));
                                                    __builder2.AddComponentParameter(52, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                    {
                                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(text), "Text"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                    }, $jOjMKe ??= {"r":38797349,"n":"","d":2004165,"h":0,"f":17825794})).Invoke())));
                                                    __builder2.CloseComponent();
                                                }
                                                else if ($.$is(element, $.$MDmQ.LCCWCE.WebsiteEditableAnchor, { set $v($v){ anchor = $v; } }))
                                                {
                                                    __builder2.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$($.$$.S.String), 53);
                                                    __builder2.AddComponentParameter(54, "PlaceHolder", "Link");
                                                    __builder2.AddComponentParameter(55, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, anchor.Href));
                                                    __builder2.AddComponentParameter(56, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                                    {
                                                        return anchor.Href = __value;
                                                    }, $vZyGbf ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":2004165,"h":0,"f":17825794}), anchor.Href))));
                                                    __builder2.AddComponentParameter(57, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                    {
                                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(anchor), "Href"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                    }, $dxUUMi ??= {"r":38797349,"n":"","d":2004165,"h":0,"f":17825794})).Invoke())));
                                                    __builder2.CloseComponent();
                                                }
                                                else if ($.$is(element, $.$MDmQ.LCCWCE.WebsiteEditableImage, { set $v($v){ image = $v; } }))
                                                {
                                                    __builder2.OpenElement(58, "div");
                                                    __builder2.AddAttribute$5(59, "class", "bd corner hx-1 flex mgy");
                                                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 60, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(image, image.OpenPrompt)));
                                                    __builder2.OpenElement(61, "img");
                                                    __builder2.AddAttribute$5(62, "class", "mawf mahf mg-a");
                                                    __builder2.AddAttribute$5(63, "src", image.Source);
                                                    __builder2.CloseElement();
                                                    __builder2.CloseElement();
                                                }
                                                else if ($.$is(element, $.$MDmQ.LCCWCE.WebsiteEditableSource, { set $v($v){ source = $v; } }))
                                                {
                                                    __builder2.OpenElement(64, "div");
                                                    __builder2.AddAttribute$5(65, "class", "bd corner hx-1 flex mgt");
                                                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 66, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(source, source.OpenPrompt)));
                                                    __builder2.OpenElement(67, "img");
                                                    __builder2.AddAttribute$5(68, "class", "mawf mahf mg-a");
                                                    __builder2.AddAttribute$5(69, "src", source.Source);
                                                    __builder2.CloseElement();
                                                    __builder2.CloseElement();
                                                }
                                                __builder2.CloseElement();
                                            }
                                        }
                                    }
                                }, $bUOoqk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2004165,"h":0,"f":17825794});
                            }), $QzAaJf ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":2004165,"h":0,"f":17825794}));
                            __builder.CloseComponent();
                        }
                    }
                    else 
                    {
                        __builder.AddMarkupContent(70, "<small class=\"cl-error\">You do not have permission to edit this page</small>");
                    }
                }
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(25771807941)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17181873349)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181873349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181873349)
            
            //--TRIMMABLE-BOUNDARY-START(17181873349)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17181873349)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21476840645)
                this.AuthenticationService = null;
                //--TRIMMABLE-BOUNDARY-END(21476840645)
                
                //--TRIMMABLE-BOUNDARY-START(115966121157)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(115966121157)
                
                //--TRIMMABLE-BOUNDARY-START(98786251973)
                this.Js = null;
                //--TRIMMABLE-BOUNDARY-END(98786251973)
                
                //--TRIMMABLE-BOUNDARY-START(34361742533)
                this.dragHandle = $.$default($.$mac.MAC.ElementReference);
                //--TRIMMABLE-BOUNDARY-END(34361742533)
                
                //--TRIMMABLE-BOUNDARY-START(38656709829)
                this.dragPosition = $.$default($.$mac.MAC.ElementReference);
                //--TRIMMABLE-BOUNDARY-END(38656709829)
                
            }
            static $h = 2004165;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111671153861),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016448197,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2004165,
      "h": 111671153861,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(111671153861),
//--TRIMMABLE-BOUNDARY-START(21476840645),
    {
      "p": 63592106,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836579013,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124556055749,
        "f": 83886081
      },
      "n": "AuthenticationService",
      "d": 2004165,
      "h": 21476840645,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476840645),
//--TRIMMABLE-BOUNDARY-START(115966121157),
    {
      "p": 1610949,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606382789,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735924933,
        "f": 83886081
      },
      "n": "Service",
      "d": 2004165,
      "h": 115966121157,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115966121157),
//--TRIMMABLE-BOUNDARY-START(98786251973),
    {
      "p": 64509610,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426513605,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145990341,
        "f": 83886081
      },
      "n": "Js",
      "d": 2004165,
      "h": 98786251973,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98786251973)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90196317381),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2004165,
      "h": 90196317381,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90196317381),
//--TRIMMABLE-BOUNDARY-START(94491284677),
    {
      "r": 262145,
      "p": [
        {
          "n": "ed",
          "p": 365765
        }
      ],
      "n": "IsCollapsed",
      "d": 2004165,
      "h": 94491284677,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94491284677),
//--TRIMMABLE-BOUNDARY-START(150325859525),
    {
      "r": 65537,
      "p": [
        {
          "n": "ed",
          "p": 365765
        }
      ],
      "n": "ToggleCollapsed",
      "d": 2004165,
      "h": 150325859525,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(150325859525),
//--TRIMMABLE-BOUNDARY-START(107376186565),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 2004165,
      "h": 107376186565,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(107376186565),
//--TRIMMABLE-BOUNDARY-START(30066775237),
    {
      "r": 65537,
      "n": "Close",
      "d": 2004165,
      "h": 30066775237,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30066775237),
//--TRIMMABLE-BOUNDARY-START(103081219269),
    {
      "r": 65537,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRender",
      "d": 2004165,
      "h": 103081219269,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(103081219269),
//--TRIMMABLE-BOUNDARY-START(25771807941),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2004165,
      "h": 25771807941,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25771807941)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(146030892229),
    {
      "t": 262145,
      "n": "show",
      "d": 2004165,
      "h": 146030892229,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(146030892229),
//--TRIMMABLE-BOUNDARY-START(85901350085),
    {
      "t": 262145,
      "n": "hasShown",
      "d": 2004165,
      "h": 85901350085,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85901350085),
//--TRIMMABLE-BOUNDARY-START(42951677125),
    {
      "t": 1310721,
      "n": "filterText",
      "d": 2004165,
      "h": 42951677125,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42951677125),
//--TRIMMABLE-BOUNDARY-START(34361742533),
    {
      "t": 1900659,
      "n": "dragHandle",
      "d": 2004165,
      "h": 34361742533,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361742533),
//--TRIMMABLE-BOUNDARY-START(38656709829),
    {
      "t": 1900659,
      "n": "dragPosition",
      "d": 2004165,
      "h": 38656709829,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656709829),
//--TRIMMABLE-BOUNDARY-START(47246644421),
    {
      "t": 365765,
      "n": "focused",
      "d": 2004165,
      "h": 47246644421,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47246644421)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181873349),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2004165,
      "h": 17181873349,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181873349)
  ],
  "h": 2004165
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Shared.WebsitePageAdminComponentBrowser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Shared${separator}WebsitePageAdminComponentBrowser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2004165)
        
        

        //--TRIMMABLE-BOUNDARY-START(955589)
        $asm.$cls(`$MDmQ.LCCWCE.WebsiteEditableText`, ($self) => class WebsiteEditableText extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(115965072581)
            /*WebsitePage*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(115965072581)
            
            //--TRIMMABLE-BOUNDARY-START(30065726661)
            /*string*/ CId = null;
            //--TRIMMABLE-BOUNDARY-END(30065726661)
            
            //--TRIMMABLE-BOUNDARY-START(38655661253)
            /*string*/ DefaultText = null;
            //--TRIMMABLE-BOUNDARY-END(38655661253)
            
            //--TRIMMABLE-BOUNDARY-START(124555007173)
            /*CommunityWebsiteDataSource*/ RepeaterData = null;
            //--TRIMMABLE-BOUNDARY-END(124555007173)
            
            //--TRIMMABLE-BOUNDARY-START(34360693957)
            /*IWebsiteDataSource */ get DataSource()
            {
                return this.RepeaterData ?? this.Page;
            }
            //--TRIMMABLE-BOUNDARY-END(34360693957)
            
            //--TRIMMABLE-BOUNDARY-START(171799647429)
            /*string */ get Text()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080170693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let text = $.$MDmQ.LCCWC.WebsiteDataSourceExtension.GetData(this.DataSource, this);
                if ($.$$.S.String.IsNullOrEmpty(text))
                {
                    text = this.DefaultText;
                }
                return text;
            }
            /*string */ set Text(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504680133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MDmQ.LCCWC.WebsiteDataSourceExtension.SetData(this.DataSource, this, value);
                this.StateHasChanged();
            }
            //--TRIMMABLE-BOUNDARY-END(171799647429)
            
            //--TRIMMABLE-BOUNDARY-START(176094614725)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094614725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCS$6.StringExtension.LimitLength(this.Text, 32, true);
            }
            //--TRIMMABLE-BOUNDARY-END(176094614725)
            
            //--TRIMMABLE-BOUNDARY-START(107375137989)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375137989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Page.Register(this);
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(107375137989)
            
            //--TRIMMABLE-BOUNDARY-START(42950628549)
            /*void */ Dispose$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950628549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Page.DeRegister(this);
            }
            //--TRIMMABLE-BOUNDARY-END(42950628549)
            
            //--TRIMMABLE-BOUNDARY-START(120260039877)
            /*void */ Refresh()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260039877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.StateHasChanged();
            }
            //--TRIMMABLE-BOUNDARY-END(120260039877)
            
            //--TRIMMABLE-BOUNDARY-START(111670105285)
            /*string */ get OptimizedComponentName()
            {
                return "websiteeditabletext";
            }
            //--TRIMMABLE-BOUNDARY-END(111670105285)
            
            //--TRIMMABLE-BOUNDARY-START(180389582021)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389582021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$MDmQ.LCCWC.WebsitePage);
                    return true;
                    case "CId":
                    this.CId = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "DefaultText":
                    this.DefaultText = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "RepeaterData":
                    this.RepeaterData = $.$cast(parameter.Value, $.$AEuu.LCCWCM.CommunityWebsiteDataSource);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(180389582021)
            
            //--TRIMMABLE-BOUNDARY-START(25770759365)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770759365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let text = this.Text;
                if (this.Page.IsEditting)
                {
                    __builder.OpenElement(0, "span");
                    __builder.AddAttribute$5(1, "id", this.CId);
                    __builder.AddAttribute$5(2, "contenteditable", "true");
                    __builder.SetKey($.$box($.$$.S.String.GetHashCode.call(text), $.$$.S.Int32));
                    __builder.AddContent$4(3, text);
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.AddContent$4(4, text);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770759365)
            
            //--TRIMMABLE-BOUNDARY-START(12885267653)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Client.Editables.IWebsiteEditable.CId.get
            get LCCWCE$IWebsiteEditable$CId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295333061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CId;
            }
            //--TRIMMABLE-BOUNDARY-END(12885267653)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21475792069)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475792069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475792069)
            
            //--TRIMMABLE-BOUNDARY-START(21475792069)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21475792069)
            
            static $h = 955589;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115965072581),
    {
      "p": 2266309,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900301509,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324810949,
        "f": 83886081
      },
      "n": "Page",
      "d": 955589,
      "h": 115965072581,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115965072581),
//--TRIMMABLE-BOUNDARY-START(30065726661),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540563141,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144941765,
        "f": 83886081
      },
      "n": "CId",
      "d": 955589,
      "h": 30065726661,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065726661),
//--TRIMMABLE-BOUNDARY-START(38655661253),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720432325,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734876357,
        "f": 83886081
      },
      "n": "DefaultText",
      "d": 955589,
      "h": 38655661253,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655661253),
//--TRIMMABLE-BOUNDARY-START(124555007173),
    {
      "p": 479361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490236101,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914745541,
        "f": 83886081
      },
      "n": "RepeaterData",
      "d": 955589,
      "h": 124555007173,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124555007173),
//--TRIMMABLE-BOUNDARY-START(34360693957),
    {
      "p": 1134721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130497733,
        "f": 50331650
      },
      "n": "DataSource",
      "d": 955589,
      "h": 34360693957,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(34360693957),
//--TRIMMABLE-BOUNDARY-START(171799647429),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080170693,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504680133,
        "f": 83886088
      },
      "n": "Text",
      "d": 955589,
      "h": 171799647429,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(171799647429),
//--TRIMMABLE-BOUNDARY-START(111670105285),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310366917,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 955589,
      "h": 111670105285,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(111670105285)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(176094614725),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 955589,
      "h": 176094614725,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094614725),
//--TRIMMABLE-BOUNDARY-START(107375137989),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 955589,
      "h": 107375137989,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(107375137989),
//--TRIMMABLE-BOUNDARY-START(42950628549),
    {
      "r": 65537,
      "n": "Dispose",
      "o": "@$1",
      "d": 955589,
      "h": 42950628549,
      "f": 553648129
    },
//--TRIMMABLE-BOUNDARY-END(42950628549),
//--TRIMMABLE-BOUNDARY-START(120260039877),
    {
      "r": 65537,
      "n": "Refresh",
      "d": 955589,
      "h": 120260039877,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120260039877),
//--TRIMMABLE-BOUNDARY-START(180389582021),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 955589,
      "h": 180389582021,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389582021),
//--TRIMMABLE-BOUNDARY-START(25770759365),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 955589,
      "h": 25770759365,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770759365)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475792069),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 955589,
      "h": 21475792069,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475792069)
  ],
  "h": 955589
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$$.S.IDisposable, $.$MDmQ.LCCWCE.IWebsiteEditable, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Editables.WebsiteEditableText`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Editables${separator}WebsiteEditableText`; }
        });
        //--TRIMMABLE-BOUNDARY-END(955589)
        
        

        //--TRIMMABLE-BOUNDARY-START(431301)
        $asm.$cls(`$MDmQ.LCCWCE.WebsiteEditableAnchor`, ($self) => class WebsiteEditableAnchor extends $.$hDPm.LCFCC$1.BaseContainer
        {
            //--TRIMMABLE-BOUNDARY-START(124554482885)
            /*WebsitePage*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(124554482885)
            
            //--TRIMMABLE-BOUNDARY-START(30065202373)
            /*string*/ CId = null;
            //--TRIMMABLE-BOUNDARY-END(30065202373)
            
            //--TRIMMABLE-BOUNDARY-START(38655136965)
            /*string*/ DefaultHref = null;
            //--TRIMMABLE-BOUNDARY-END(38655136965)
            
            //--TRIMMABLE-BOUNDARY-START(128849450181)
            /*CommunityWebsiteDataSource*/ RepeaterData = null;
            //--TRIMMABLE-BOUNDARY-END(128849450181)
            
            //--TRIMMABLE-BOUNDARY-START(34360169669)
            /*IWebsiteDataSource */ get DataSource()
            {
                return this.RepeaterData ?? this.Page;
            }
            //--TRIMMABLE-BOUNDARY-END(34360169669)
            
            //--TRIMMABLE-BOUNDARY-START(111669580997)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669580997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Page.Register(this);
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(111669580997)
            
            //--TRIMMABLE-BOUNDARY-START(42950104261)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950104261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Page.DeRegister(this);
            }
            //--TRIMMABLE-BOUNDARY-END(42950104261)
            
            //--TRIMMABLE-BOUNDARY-START(107374613701)
            /*string */ get Href()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309842629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let img = $.$MDmQ.LCCWC.WebsiteDataSourceExtension.GetData(this.DataSource, this);
                if (img !== null)
                {
                    return img;
                }
                return this.DefaultHref;
            }
            /*string */ set Href(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619253957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MDmQ.LCCWC.WebsiteDataSourceExtension.SetData(this.Page, this, value);
                this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Website.Client.Blazor\\WebsiteEditableAnchor.razor.cs", "Href", 50);
            }
            //--TRIMMABLE-BOUNDARY-END(107374613701)
            
            //--TRIMMABLE-BOUNDARY-START(115964548293)
            /*Task *//*async*/  Open()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964548293);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let link = ($t1 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Prompt($.$$.S.String, "Edit Link Url", null, "OK", "Cancel", "Link destination", this.Href), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (link === "")
                    {
                        link = null;
                    }
                    this.Href = link;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(115964548293)
            
            //--TRIMMABLE-BOUNDARY-START(176094090437)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094090437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Href;
            }
            //--TRIMMABLE-BOUNDARY-END(176094090437)
            
            //--TRIMMABLE-BOUNDARY-START(120259515589)
            /*string */ get OptimizedComponentName()
            {
                return "websiteeditableanchor";
            }
            //--TRIMMABLE-BOUNDARY-END(120259515589)
            
            //--TRIMMABLE-BOUNDARY-START(180389057733)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389057733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch2 = parameter.Name;
                switch($switch2)
                {
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$MDmQ.LCCWC.WebsitePage);
                    return true;
                    case "CId":
                    this.CId = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "DefaultHref":
                    this.DefaultHref = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "RepeaterData":
                    this.RepeaterData = $.$cast(parameter.Value, $.$AEuu.LCCWCM.CommunityWebsiteDataSource);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(180389057733)
            
            //--TRIMMABLE-BOUNDARY-START(25770235077)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770235077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.Page.IsEditting)
                {
                    __builder.OpenElement(0, "a");
                    __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$1(this.OwnAttributes(null), $.$fPer.LCFC.Stringy.op_Implicit$3("href"), this.Href))));
                    __builder.AddContent$1(2, this.ChildContent);
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(3, "a");
                    __builder.AddMultipleAttributes(4, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$1(this.OwnAttributes(null), $.$fPer.LCFC.Stringy.op_Implicit$3("href"), this.Href).AddProperty($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "edit"))));
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 5, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Open)));
                    __builder.SetKey($.$box($.$$.S.String.GetHashCode.call(this.Href), $.$$.S.Int32));
                    __builder.AddContent$1(6, this.ChildContent);
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770235077)
            
            //--TRIMMABLE-BOUNDARY-START(12885267653)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Client.Editables.IWebsiteEditable.CId.get
            get LCCWCE$IWebsiteEditable$CId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295333061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CId;
            }
            //--TRIMMABLE-BOUNDARY-END(12885267653)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21475267781)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475267781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475267781)
            
            //--TRIMMABLE-BOUNDARY-START(21475267781)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(21475267781)
            
            static $h = 431301;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseContainer; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124554482885),
    {
      "p": 2266309,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489711813,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209188549,
        "f": 83886081
      },
      "n": "Page",
      "d": 431301,
      "h": 124554482885,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124554482885),
//--TRIMMABLE-BOUNDARY-START(30065202373),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540038853,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439384773,
        "f": 83886081
      },
      "n": "CId",
      "d": 431301,
      "h": 30065202373,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065202373),
//--TRIMMABLE-BOUNDARY-START(38655136965),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719908037,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029319365,
        "f": 83886081
      },
      "n": "DefaultHref",
      "d": 431301,
      "h": 38655136965,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655136965),
//--TRIMMABLE-BOUNDARY-START(128849450181),
    {
      "p": 479361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079646405,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799123141,
        "f": 83886081
      },
      "n": "RepeaterData",
      "d": 431301,
      "h": 128849450181,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849450181),
//--TRIMMABLE-BOUNDARY-START(34360169669),
    {
      "p": 1134721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129973445,
        "f": 50331650
      },
      "n": "DataSource",
      "d": 431301,
      "h": 34360169669,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(34360169669),
//--TRIMMABLE-BOUNDARY-START(107374613701),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309842629,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619253957,
        "f": 83886088
      },
      "n": "Href",
      "d": 431301,
      "h": 107374613701,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(107374613701),
//--TRIMMABLE-BOUNDARY-START(120259515589),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899777221,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 431301,
      "h": 120259515589,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120259515589)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111669580997),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 431301,
      "h": 111669580997,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(111669580997),
//--TRIMMABLE-BOUNDARY-START(42950104261),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 431301,
      "h": 42950104261,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950104261),
//--TRIMMABLE-BOUNDARY-START(115964548293),
    {
      "r": 178454529,
      "n": "Open",
      "d": 431301,
      "h": 115964548293,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(115964548293),
//--TRIMMABLE-BOUNDARY-START(176094090437),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 431301,
      "h": 176094090437,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094090437),
//--TRIMMABLE-BOUNDARY-START(180389057733),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 431301,
      "h": 180389057733,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389057733),
//--TRIMMABLE-BOUNDARY-START(25770235077),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 431301,
      "h": 25770235077,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770235077)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475267781),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 431301,
      "h": 21475267781,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475267781)
  ],
  "h": 431301
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$MDmQ.LCCWCE.IWebsiteEditable, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Editables.WebsiteEditableAnchor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Editables${separator}WebsiteEditableAnchor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(431301)
        
        

        //--TRIMMABLE-BOUNDARY-START(693445)
        $asm.$cls(`$MDmQ.LCCWCE.WebsiteEditableCommonText`, ($self) => class WebsiteEditableCommonText extends $.$MDmQ.LCCWCE.WebsiteEditableText
        {
            //--TRIMMABLE-BOUNDARY-START(30065464517)
            /*string */ get OptimizedComponentName()
            {
                return "websiteeditablecommontext websiteeditabletext";
            }
            //--TRIMMABLE-BOUNDARY-END(30065464517)
            
            //--TRIMMABLE-BOUNDARY-START(47245333701)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245333701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Section":
                    this.Section = $.$cast(parameter.Value, $.$MDmQ.LCCWC.WebsiteSection);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(47245333701)
            
            //--TRIMMABLE-BOUNDARY-START(34360431813)
            /*WebsiteSection*/ Section = null;
            //--TRIMMABLE-BOUNDARY-END(34360431813)
            
            //--TRIMMABLE-BOUNDARY-START(8590628037)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590628037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590628037)
            
            //--TRIMMABLE-BOUNDARY-START(8590628037)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8590628037)
            
            static $h = 693445;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$MDmQ.LCCWCE.WebsiteEditableText; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065464517),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180562629,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 693445,
      "h": 30065464517,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065464517),
//--TRIMMABLE-BOUNDARY-START(34360431813),
    {
      "p": 2397381,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770497221,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950366405,
        "f": 83886081
      },
      "n": "Section",
      "d": 693445,
      "h": 34360431813,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360431813)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245333701),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 693445,
      "h": 47245333701,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245333701)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590628037),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 693445,
      "h": 8590628037,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590628037)
  ],
  "h": 693445
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$$.S.IDisposable, $.$hDPm.LCFCG.IOptimizedComponent, $.$MDmQ.LCCWCE.IWebsiteCommonEditable, $.$MDmQ.LCCWCE.IWebsiteEditable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Editables.WebsiteEditableCommonText`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Editables${separator}WebsiteEditableCommonText`; }
        });
        //--TRIMMABLE-BOUNDARY-END(693445)
        
        

        //--TRIMMABLE-BOUNDARY-START(496837)
        $asm.$cls(`$MDmQ.LCCWCE.WebsiteEditableCommonAnchor`, ($self) => class WebsiteEditableCommonAnchor extends $.$MDmQ.LCCWCE.WebsiteEditableAnchor
        {
            //--TRIMMABLE-BOUNDARY-START(21475333317)
            /*WebsiteSection*/ Section = null;
            //--TRIMMABLE-BOUNDARY-END(21475333317)
            
            //--TRIMMABLE-BOUNDARY-START(8590431429)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590431429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590431429)
            
            //--TRIMMABLE-BOUNDARY-START(8590431429)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590431429)
            
            static $h = 496837;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$MDmQ.LCCWCE.WebsiteEditableAnchor; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475333317),
    {
      "p": 2397381,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180366021,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065267909,
        "f": 83886081
      },
      "n": "Section",
      "d": 496837,
      "h": 21475333317,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475333317)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590431429),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 496837,
      "h": 8590431429,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590431429)
  ],
  "h": 496837
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent, $.$MDmQ.LCCWCE.IWebsiteCommonEditable, $.$MDmQ.LCCWCE.IWebsiteEditable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Editables.WebsiteEditableCommonAnchor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Editables${separator}WebsiteEditableCommonAnchor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(496837)
        
        

        //--TRIMMABLE-BOUNDARY-START(824517)
        $asm.$cls(`$MDmQ.LCCWCE.WebsiteEditableRepeater`, ($self) => class WebsiteEditableRepeater extends $.$hDPm.LCFCC$1.BaseModelContainer$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource)
        {
            //--TRIMMABLE-BOUNDARY-START(107375006917)
            /*WebsitePage*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(107375006917)
            
            //--TRIMMABLE-BOUNDARY-START(30065595589)
            /*string*/ CId = null;
            //--TRIMMABLE-BOUNDARY-END(30065595589)
            
            //--TRIMMABLE-BOUNDARY-START(154619647173)
            /*string*/ WrapperTag = null;
            //--TRIMMABLE-BOUNDARY-END(154619647173)
            
            //--TRIMMABLE-BOUNDARY-START(111669974213)
            /*CommunityWebsiteDataSource*/ RepeaterData = null;
            //--TRIMMABLE-BOUNDARY-END(111669974213)
            
            //--TRIMMABLE-BOUNDARY-START(38655530181)
            /*IWebsiteDataSource */ get DataSource()
            {
                return this.RepeaterData ?? this.Page;
            }
            //--TRIMMABLE-BOUNDARY-END(38655530181)
            
            //--TRIMMABLE-BOUNDARY-START(34360562885)
            /*List<CommunityWebsiteDataSource>*/ data = null;
            //--TRIMMABLE-BOUNDARY-END(34360562885)
            
            //--TRIMMABLE-BOUNDARY-START(42950497477)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950497477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Page.DeRegister(this);
            }
            //--TRIMMABLE-BOUNDARY-END(42950497477)
            
            //--TRIMMABLE-BOUNDARY-START(98785072325)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785072325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Page.Register(this);
                this.data = $.$MDmQ.LCCWC.WebsiteDataSourceExtension.GetRepeaterData(this.DataSource, this);
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(98785072325)
            
            //--TRIMMABLE-BOUNDARY-START(103080039621)
            /*string */ get OptimizedComponentName()
            {
                return "websiteeditablerepeater";
            }
            //--TRIMMABLE-BOUNDARY-END(103080039621)
            
            //--TRIMMABLE-BOUNDARY-START(150324679877)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324679877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$MDmQ.LCCWC.WebsitePage);
                    return true;
                    case "CId":
                    this.CId = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "WrapperTag":
                    this.WrapperTag = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "RepeaterData":
                    this.RepeaterData = $.$cast(parameter.Value, $.$AEuu.LCCWCM.CommunityWebsiteDataSource);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(150324679877)
            
            //--TRIMMABLE-BOUNDARY-START(25770628293)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770628293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.WrapperTag !== null)
                {
                    __builder.OpenElement(1, this.WrapperTag);
                }
                let $en2 = this.data.GetEnumerator();
                while ($en2.MoveNext())
                {
                    let d = $en2.Current;
                    {
                        __builder.AddContent$1(0, (this.ChildContent?.Invoke($.$hDPm.LCFCI.ContainerContext$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource).op_Implicit$1(d)) ?? null));
                    }
                }
                if (this.WrapperTag !== null)
                {
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770628293)
            
            //--TRIMMABLE-BOUNDARY-START(12885267653)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Client.Editables.IWebsiteEditable.CId.get
            get LCCWCE$IWebsiteEditable$CId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295333061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CId;
            }
            //--TRIMMABLE-BOUNDARY-END(12885267653)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21475660997)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475660997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475660997)
            
            //--TRIMMABLE-BOUNDARY-START(21475660997)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(21475660997)
            
            static $h = 824517;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseModelContainer$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107375006917),
    {
      "p": 2266309,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310235845,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849843397,
        "f": 83886081
      },
      "n": "Page",
      "d": 824517,
      "h": 107375006917,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107375006917),
//--TRIMMABLE-BOUNDARY-START(30065595589),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540432069,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259908805,
        "f": 83886081
      },
      "n": "CId",
      "d": 824517,
      "h": 30065595589,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065595589),
//--TRIMMABLE-BOUNDARY-START(154619647173),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490105029,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029712581,
        "f": 83886081
      },
      "n": "WrapperTag",
      "d": 824517,
      "h": 154619647173,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619647173),
//--TRIMMABLE-BOUNDARY-START(111669974213),
    {
      "p": 479361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900170437,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439777989,
        "f": 83886081
      },
      "n": "RepeaterData",
      "d": 824517,
      "h": 111669974213,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669974213),
//--TRIMMABLE-BOUNDARY-START(38655530181),
    {
      "p": 1134721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130366661,
        "f": 50331650
      },
      "n": "DataSource",
      "d": 824517,
      "h": 38655530181,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(38655530181),
//--TRIMMABLE-BOUNDARY-START(103080039621),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720301253,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 824517,
      "h": 103080039621,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(103080039621)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950497477),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 824517,
      "h": 42950497477,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950497477),
//--TRIMMABLE-BOUNDARY-START(98785072325),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 824517,
      "h": 98785072325,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(98785072325),
//--TRIMMABLE-BOUNDARY-START(150324679877),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 824517,
      "h": 150324679877,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324679877),
//--TRIMMABLE-BOUNDARY-START(25770628293),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 824517,
      "h": 25770628293,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770628293)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360562885),
    {
      "t": $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource).$h,
      "n": "data",
      "d": 824517,
      "h": 34360562885,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360562885)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475660997),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 824517,
      "h": 21475660997,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475660997)
  ],
  "h": 824517
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$MDmQ.LCCWCE.IWebsiteEditable, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Editables.WebsiteEditableRepeater`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Editables${separator}WebsiteEditableRepeater`; }
        });
        //--TRIMMABLE-BOUNDARY-END(824517)
        
        

        //--TRIMMABLE-BOUNDARY-START(1742021)
        $asm.$cls(`$MDmQ.LCCWCS$1.WebsiteMarketStore`, ($self) => class WebsiteMarketStore extends $.$hDPm.LCFCC$1.BaseModelContainer$$($.$MDmQ.LCCWCS$1.WebsiteMarketStoreContext)
        {
            //--TRIMMABLE-BOUNDARY-START(60131284165)
            /*WebsitePage*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(60131284165)
            
            //--TRIMMABLE-BOUNDARY-START(47246382277)
            /*ICommunityMarketServiceProvider*/ Market = null;
            //--TRIMMABLE-BOUNDARY-END(47246382277)
            
            //--TRIMMABLE-BOUNDARY-START(51541349573)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541349573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(51541349573)
            
            //--TRIMMABLE-BOUNDARY-START(55836316869)
            /*string */ get OptimizedComponentName()
            {
                return "websitemarketstore";
            }
            //--TRIMMABLE-BOUNDARY-END(55836316869)
            
            //--TRIMMABLE-BOUNDARY-START(81606120645)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606120645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$MDmQ.LCCWC.WebsitePage);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(81606120645)
            
            //--TRIMMABLE-BOUNDARY-START(42951414981)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951414981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Market = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.ICommunityMarketServiceProvider, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(42951414981)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886643909)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886643909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886643909)
            
            //--TRIMMABLE-BOUNDARY-START(12886643909)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12886643909)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(47246382277)
                this.Market = null;
                //--TRIMMABLE-BOUNDARY-END(47246382277)
                
            }
            static $h = 1742021;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseModelContainer$$($.$MDmQ.LCCWCS$1.WebsiteMarketStoreContext); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60131284165),
    {
      "p": 2266309,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656447685,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77311153349,
        "f": 83886081
      },
      "n": "Page",
      "d": 1742021,
      "h": 60131284165,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60131284165),
//--TRIMMABLE-BOUNDARY-START(47246382277),
    {
      "p": 17864128,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476578501,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68721218757,
        "f": 83886081
      },
      "n": "Market",
      "d": 1742021,
      "h": 47246382277,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246382277),
//--TRIMMABLE-BOUNDARY-START(55836316869),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066513093,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1742021,
      "h": 55836316869,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55836316869)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51541349573),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1742021,
      "h": 51541349573,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51541349573),
//--TRIMMABLE-BOUNDARY-START(81606120645),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1742021,
      "h": 81606120645,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81606120645),
//--TRIMMABLE-BOUNDARY-START(42951414981),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1742021,
      "h": 42951414981,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951414981)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886643909),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1742021,
      "h": 12886643909,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886643909)
  ],
  "h": 1742021
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Shared.WebsiteMarketStore`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Shared${separator}WebsiteMarketStore`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1742021)
        
        

        //--TRIMMABLE-BOUNDARY-START(1479877)
        $asm.$cls(`$MDmQ.LCCWCS.CommunityWebsiteApplication`, ($self) => class CommunityWebsiteApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12886381765)
            $ctor$5(/*CommunityWebsiteService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886381765);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886381765)
            
            //--TRIMMABLE-BOUNDARY-START(137440433349)
            /*string */ get Name()
            {
                return "Website";
            }
            //--TRIMMABLE-BOUNDARY-END(137440433349)
            
            //--TRIMMABLE-BOUNDARY-START(154620302533)
            /*string */ get Title()
            {
                return "Website";
            }
            //--TRIMMABLE-BOUNDARY-END(154620302533)
            
            //--TRIMMABLE-BOUNDARY-START(21476316357)
            /*string */ get Description()
            {
                return "Host a website using Zoey Template";
            }
            //--TRIMMABLE-BOUNDARY-END(21476316357)
            
            //--TRIMMABLE-BOUNDARY-START(133145466053)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-web"/*MaterialDesignIconNames.Web*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133145466053)
            
            //--TRIMMABLE-BOUNDARY-START(150325335237)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2E562B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(150325335237)
            
            //--TRIMMABLE-BOUNDARY-START(30066250949)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 97/*ApplicationServiceFeatures.DefaultInDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30066250949)
            
            //--TRIMMABLE-BOUNDARY-START(17181349061)
            /*Type? */ get ApplicationViewType()
            {
                return $.$MDmQ.LCCWCP.CommunityWebsiteApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17181349061)
            
            //--TRIMMABLE-BOUNDARY-START(128850498757)
            /*RenderFragment? */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850498757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$MDmQ.LCCWCP.CommunityWebsiteApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128850498757)
            
            //--TRIMMABLE-BOUNDARY-START(25771283653)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771283653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25771283653)
            
            //--TRIMMABLE-BOUNDARY-START(141735400645)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141735400645)
            
            //--TRIMMABLE-BOUNDARY-START(4296447173)
            /*CommunityWebsiteService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4296447173)
            
            //--TRIMMABLE-BOUNDARY-START(146030367941)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(146030367941)
            
            //--TRIMMABLE-BOUNDARY-START(158915269829)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(7168/*PostTypes.Website*/, 7172/*PostTypes.WebsiteEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(158915269829)
            
            static $h = 1479877;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137440433349),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605858501,
        "f": 50364417
      },
      "n": "Name",
      "d": 1479877,
      "h": 137440433349,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137440433349),
//--TRIMMABLE-BOUNDARY-START(154620302533),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965596869,
        "f": 50364417
      },
      "n": "Title",
      "d": 1479877,
      "h": 154620302533,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154620302533),
//--TRIMMABLE-BOUNDARY-START(21476316357),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836054725,
        "f": 50364417
      },
      "n": "Description",
      "d": 1479877,
      "h": 21476316357,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476316357),
//--TRIMMABLE-BOUNDARY-START(133145466053),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015923909,
        "f": 50364417
      },
      "n": "Icon",
      "d": 1479877,
      "h": 133145466053,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133145466053),
//--TRIMMABLE-BOUNDARY-START(150325335237),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375662277,
        "f": 50364417
      },
      "n": "Theme",
      "d": 1479877,
      "h": 150325335237,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150325335237),
//--TRIMMABLE-BOUNDARY-START(30066250949),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425989317,
        "f": 50364417
      },
      "n": "Features",
      "d": 1479877,
      "h": 30066250949,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30066250949),
//--TRIMMABLE-BOUNDARY-START(17181349061),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246120133,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 1479877,
      "h": 17181349061,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17181349061),
//--TRIMMABLE-BOUNDARY-START(141735400645),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195793093,
        "f": 50364417
      },
      "n": "Order",
      "d": 1479877,
      "h": 141735400645,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141735400645),
//--TRIMMABLE-BOUNDARY-START(4296447173),
    {
      "p": 1610949,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656185541,
        "f": 50331650
      },
      "n": "_Service",
      "d": 1479877,
      "h": 4296447173,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4296447173),
//--TRIMMABLE-BOUNDARY-START(146030367941),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785727685,
        "f": 50364417
      },
      "n": "Service",
      "d": 1479877,
      "h": 146030367941,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146030367941),
//--TRIMMABLE-BOUNDARY-START(158915269829),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555531461,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 1479877,
      "h": 158915269829,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158915269829)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128850498757),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 1479877,
      "h": 128850498757,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128850498757),
//--TRIMMABLE-BOUNDARY-START(25771283653),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 1479877,
      "h": 25771283653,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771283653)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886381765),
    {
      "p": [
        {
          "n": "service",
          "p": 1610949
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1479877,
      "h": 12886381765,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886381765)
  ],
  "h": 1479877
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Services.CommunityWebsiteApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Services${separator}CommunityWebsiteApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1479877)
        
        

        //--TRIMMABLE-BOUNDARY-START(758981)
        $asm.$cls(`$MDmQ.LCCWCE.WebsiteEditableImage`, ($self) => class WebsiteEditableImage extends $.$hDPm.LCFCCR$2.ResourceBrowser
        {
            //--TRIMMABLE-BOUNDARY-START(115964875973)
            /*string */ get OptimizedComponentName()
            {
                return "websiteeditableimage resourcebrowser";
            }
            //--TRIMMABLE-BOUNDARY-END(115964875973)
            
            //--TRIMMABLE-BOUNDARY-START(180389385413)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389385413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$MDmQ.LCCWC.WebsitePage);
                    return true;
                    case "CId":
                    this.CId = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "DefaultImage":
                    this.DefaultImage = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "RepeaterData":
                    this.RepeaterData = $.$cast(parameter.Value, $.$AEuu.LCCWCM.CommunityWebsiteDataSource);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(180389385413)
            
            //--TRIMMABLE-BOUNDARY-START(120259843269)
            /*WebsitePage*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(120259843269)
            
            //--TRIMMABLE-BOUNDARY-START(30065530053)
            /*string*/ CId = null;
            //--TRIMMABLE-BOUNDARY-END(30065530053)
            
            //--TRIMMABLE-BOUNDARY-START(38655464645)
            /*string*/ DefaultImage = null;
            //--TRIMMABLE-BOUNDARY-END(38655464645)
            
            //--TRIMMABLE-BOUNDARY-START(124554810565)
            /*CommunityWebsiteDataSource*/ RepeaterData = null;
            //--TRIMMABLE-BOUNDARY-END(124554810565)
            
            //--TRIMMABLE-BOUNDARY-START(34360497349)
            /*IWebsiteDataSource */ get DataSource()
            {
                return this.RepeaterData ?? this.Page;
            }
            //--TRIMMABLE-BOUNDARY-END(34360497349)
            
            //--TRIMMABLE-BOUNDARY-START(107374941381)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374941381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Page.Register(this);
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(107374941381)
            
            //--TRIMMABLE-BOUNDARY-START(42950431941)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950431941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Page.DeRegister(this);
            }
            //--TRIMMABLE-BOUNDARY-END(42950431941)
            
            //--TRIMMABLE-BOUNDARY-START(171799450821)
            /*string */ get Source()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079974085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let img = $.$MDmQ.LCCWC.WebsiteDataSourceExtension.GetData(this.DataSource, this);
                if (img !== null)
                {
                    return img;
                }
                if ($.$$.S.String.StartsWith$3.call(this.DefaultImage, "data:image"))
                {
                    return this.DefaultImage;
                }
                return this.ResolvePath$1(this.DefaultImage, $.$$.S.Object.GetType.call(this.Page).Assembly, false);
            }
            /*string */ set Source(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504483525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$MDmQ.LCCWC.WebsiteDataSourceExtension.SetData(this.DataSource, this, value);
            }
            //--TRIMMABLE-BOUNDARY-END(171799450821)
            
            //--TRIMMABLE-BOUNDARY-START(111669908677)
            /*Task *//*async*/  OpenPrompt()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111669908677);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.View$1($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/*o*/ o) =>
                    {
                        return this.PromptView;
                    }, $uTMSCj ??= {"r":6881395,"p":[{"n":"o","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":758981,"h":0,"f":17825794}), new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/*o*/ o) =>
                    {
                        return this.PromptTitle;
                    }, $IcfzQe ??= {"r":6881395,"p":[{"n":"o","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":758981,"h":0,"f":17825794}), null, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t3 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Theme = $.$clone(this.Theme);
                        $i3.ViewFeatures = 4/*ViewFeatures.Prompt*/ | 64/*ViewFeatures.Body*/ | 256/*ViewFeatures.CloseOnClickOut*/ | 32/*ViewFeatures.Header*/ | 1/*ViewFeatures.OKToolBar*/ | 2/*ViewFeatures.CancelToolBar*/;
                        $i3.BodyAttributes = this.AttributesFor("body");
                        $i3.ContentAttributes = this.AttributesFor("content");
                        $i3.HeadAttributes = this.AttributesFor("head");
                        $i3.FootAttributes = this.AttributesFor("foot");
                        return $i3;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>?*/ let __ca1__;
                    /*LivingThing.Core.Frameworks.Common.Models.ResourceModel?*/ let __ca2__;
                    this.Source = ((__ca1__ = this.selected) !== null ? ((__ca2__ = $.$sl.SL.Enumerable.FirstOrDefault$3($.$Iaui.LCFCM.ResourceModel, __ca1__)) !== null ? __ca2__.FullPath : null) : null);
                    this.selected = null;
                    ($t4 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Website.Client.Blazor\\WebsiteEditableImage.razor.cs", "OpenPrompt", 71), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111669908677)
            
            //--TRIMMABLE-BOUNDARY-START(176094418117)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094418117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Image";
            }
            //--TRIMMABLE-BOUNDARY-END(176094418117)
            
            //--TRIMMABLE-BOUNDARY-START(25770562757)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770562757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.Page.IsEditting)
                {
                    __builder.OpenElement(0, "img");
                    __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$1(this.OwnAttributes(null), $.$fPer.LCFC.Stringy.op_Implicit$3("src"), this.Source))));
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(2, "img");
                    __builder.AddMultipleAttributes(3, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$1(this.OwnAttributes(null), $.$fPer.LCFC.Stringy.op_Implicit$3("src"), this.Source))));
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 4, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.OpenPrompt)));
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770562757)
            
            //--TRIMMABLE-BOUNDARY-START(12885267653)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Client.Editables.IWebsiteEditable.CId.get
            get LCCWCE$IWebsiteEditable$CId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295333061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CId;
            }
            //--TRIMMABLE-BOUNDARY-END(12885267653)
            
            //--TRIMMABLE-BOUNDARY-START(21475595461)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475595461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475595461)
            
            //--TRIMMABLE-BOUNDARY-START(21475595461)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(21475595461)
            
            static $h = 758981;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCR$2.ResourceBrowser; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115964875973),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310170309,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 758981,
      "h": 115964875973,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115964875973),
//--TRIMMABLE-BOUNDARY-START(120259843269),
    {
      "p": 2266309,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900104901,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324614341,
        "f": 83886081
      },
      "n": "Page",
      "d": 758981,
      "h": 120259843269,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120259843269),
//--TRIMMABLE-BOUNDARY-START(30065530053),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540366533,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144745157,
        "f": 83886081
      },
      "n": "CId",
      "d": 758981,
      "h": 30065530053,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065530053),
//--TRIMMABLE-BOUNDARY-START(38655464645),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720235717,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734679749,
        "f": 83886081
      },
      "n": "DefaultImage",
      "d": 758981,
      "h": 38655464645,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655464645),
//--TRIMMABLE-BOUNDARY-START(124554810565),
    {
      "p": 479361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490039493,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914548933,
        "f": 83886081
      },
      "n": "RepeaterData",
      "d": 758981,
      "h": 124554810565,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124554810565),
//--TRIMMABLE-BOUNDARY-START(34360497349),
    {
      "p": 1134721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130301125,
        "f": 50331650
      },
      "n": "DataSource",
      "d": 758981,
      "h": 34360497349,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(34360497349),
//--TRIMMABLE-BOUNDARY-START(171799450821),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079974085,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504483525,
        "f": 83886088
      },
      "n": "Source",
      "d": 758981,
      "h": 171799450821,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(171799450821)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(180389385413),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 758981,
      "h": 180389385413,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389385413),
//--TRIMMABLE-BOUNDARY-START(107374941381),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 758981,
      "h": 107374941381,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(107374941381),
//--TRIMMABLE-BOUNDARY-START(42950431941),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 758981,
      "h": 42950431941,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950431941),
//--TRIMMABLE-BOUNDARY-START(111669908677),
    {
      "r": 178454529,
      "n": "OpenPrompt",
      "d": 758981,
      "h": 111669908677,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(111669908677),
//--TRIMMABLE-BOUNDARY-START(176094418117),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 758981,
      "h": 176094418117,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094418117),
//--TRIMMABLE-BOUNDARY-START(25770562757),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 758981,
      "h": 25770562757,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770562757)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475595461),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 758981,
      "h": 21475595461,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475595461)
  ],
  "h": 758981
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IProgress$$($.$$.S.ValueTuple$$$($.$vWqU.LCFCC.PickedFileInfo, $.$$.S.Int32)), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$Iaui.LCFCM.ResourceModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$Iaui.LCFCM.ResourceModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent, $.$MDmQ.LCCWCE.IWebsiteEditable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Editables.WebsiteEditableImage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Editables${separator}WebsiteEditableImage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(758981)
        
        

        //--TRIMMABLE-BOUNDARY-START(890053)
        $asm.$cls(`$MDmQ.LCCWCE.WebsiteEditableSource`, ($self) => class WebsiteEditableSource extends $.$hDPm.LCFCCR$2.ResourceBrowser
        {
            //--TRIMMABLE-BOUNDARY-START(133144876229)
            /*string */ get OptimizedComponentName()
            {
                return "websiteeditablesource resourcebrowser";
            }
            //--TRIMMABLE-BOUNDARY-END(133144876229)
            
            //--TRIMMABLE-BOUNDARY-START(206159320261)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159320261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$MDmQ.LCCWC.WebsitePage);
                    return true;
                    case "CId":
                    this.CId = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "DefaultSource":
                    this.DefaultSource = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "DefaultSourceSet":
                    this.DefaultSourceSet = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "RepeaterData":
                    this.RepeaterData = $.$cast(parameter.Value, $.$AEuu.LCCWCM.CommunityWebsiteDataSource);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(206159320261)
            
            //--TRIMMABLE-BOUNDARY-START(137439843525)
            /*WebsitePage*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(137439843525)
            
            //--TRIMMABLE-BOUNDARY-START(34360628421)
            /*string*/ CId = null;
            //--TRIMMABLE-BOUNDARY-END(34360628421)
            
            //--TRIMMABLE-BOUNDARY-START(42950563013)
            /*string*/ DefaultSource = null;
            //--TRIMMABLE-BOUNDARY-END(42950563013)
            
            //--TRIMMABLE-BOUNDARY-START(47245530309)
            /*string*/ DefaultSourceSet = null;
            //--TRIMMABLE-BOUNDARY-END(47245530309)
            
            //--TRIMMABLE-BOUNDARY-START(141734810821)
            /*CommunityWebsiteDataSource*/ RepeaterData = null;
            //--TRIMMABLE-BOUNDARY-END(141734810821)
            
            //--TRIMMABLE-BOUNDARY-START(38655595717)
            /*IWebsiteDataSource */ get DataSource()
            {
                return this.RepeaterData ?? this.Page;
            }
            //--TRIMMABLE-BOUNDARY-END(38655595717)
            
            //--TRIMMABLE-BOUNDARY-START(124554941637)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554941637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Page.Register(this);
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(124554941637)
            
            //--TRIMMABLE-BOUNDARY-START(51540497605)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540497605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Page.DeRegister(this);
            }
            //--TRIMMABLE-BOUNDARY-END(51540497605)
            
            //--TRIMMABLE-BOUNDARY-START(197569385669)
            /*string */ get Source()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259974341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let img = $.$MDmQ.LCCWC.WebsiteDataSourceExtension.GetData(this.DataSource, this);
                if (img !== null)
                {
                    return img;
                }
                if ($.$$.S.String.StartsWith$3.call((this.DefaultSourceSet ?? this.DefaultSource), "data:image"))
                {
                    return this.DefaultSourceSet ?? this.DefaultSource;
                }
                return this.ResolvePath$1(this.DefaultSourceSet ?? this.DefaultSource, $.$$.S.Object.GetType.call(this.Page).Assembly, false);
            }
            /*string */ set Source(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274418373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$MDmQ.LCCWC.WebsiteDataSourceExtension.SetData(this.DataSource, this, value);
            }
            //--TRIMMABLE-BOUNDARY-END(197569385669)
            
            //--TRIMMABLE-BOUNDARY-START(128849908933)
            /*Task *//*async*/  OpenPrompt()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128849908933);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.View$1($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/**/ o) =>
                    {
                        return this.PromptView;
                    }, $HAhnRb ??= {"r":6881395,"p":[{"n":"o","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":890053,"h":0,"f":17825794}), new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/*o*/ o) =>
                    {
                        return this.PromptTitle;
                    }, $TLBNjh ??= {"r":6881395,"p":[{"n":"o","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":890053,"h":0,"f":17825794}), null, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t3 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Theme = $.$clone(this.Theme);
                        $i3.ViewFeatures = 4/*ViewFeatures.Prompt*/ | 64/*ViewFeatures.Body*/ | 256/*ViewFeatures.CloseOnClickOut*/ | 32/*ViewFeatures.Header*/ | 1/*ViewFeatures.OKToolBar*/ | 2/*ViewFeatures.CancelToolBar*/;
                        $i3.BodyAttributes = this.AttributesFor("body");
                        $i3.ContentAttributes = this.AttributesFor("content");
                        $i3.HeadAttributes = this.AttributesFor("head");
                        $i3.FootAttributes = this.AttributesFor("foot");
                        return $i3;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>?*/ let __ca1__;
                    /*LivingThing.Core.Frameworks.Common.Models.ResourceModel?*/ let __ca2__;
                    this.Source = ((__ca1__ = this.selected) !== null ? ((__ca2__ = $.$sl.SL.Enumerable.FirstOrDefault$3($.$Iaui.LCFCM.ResourceModel, __ca1__)) !== null ? __ca2__.FullPath : null) : null);
                    this.selected = null;
                    ($t4 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Website.Client.Blazor\\WebsiteEditableSource.razor.cs", "OpenPrompt", 72), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(128849908933)
            
            //--TRIMMABLE-BOUNDARY-START(201864352965)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864352965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Image";
            }
            //--TRIMMABLE-BOUNDARY-END(201864352965)
            
            //--TRIMMABLE-BOUNDARY-START(30065661125)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065661125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.Page.IsEditting)
                {
                    __builder.OpenElement(0, "source");
                    __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$1(this.OwnAttributes(null), $.$fPer.LCFC.Stringy.op_Implicit$3("srcset"), this.Source))));
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(2, "source");
                    __builder.AddMultipleAttributes(3, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$1(this.OwnAttributes(null), $.$fPer.LCFC.Stringy.op_Implicit$3("srcset"), this.Source))));
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 4, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.OpenPrompt)));
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065661125)
            
            //--TRIMMABLE-BOUNDARY-START(12885267653)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Client.Editables.IWebsiteEditable.CId.get
            get LCCWCE$IWebsiteEditable$CId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295333061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CId;
            }
            //--TRIMMABLE-BOUNDARY-END(12885267653)
            
            //--TRIMMABLE-BOUNDARY-START(25770693829)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770693829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770693829)
            
            //--TRIMMABLE-BOUNDARY-START(25770693829)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(25770693829)
            
            static $h = 890053;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCR$2.ResourceBrowser; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133144876229),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490170565,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 890053,
      "h": 133144876229,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144876229),
//--TRIMMABLE-BOUNDARY-START(137439843525),
    {
      "p": 2266309,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080105157,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094549189,
        "f": 83886081
      },
      "n": "Page",
      "d": 890053,
      "h": 137439843525,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439843525),
//--TRIMMABLE-BOUNDARY-START(34360628421),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130432197,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324745413,
        "f": 83886081
      },
      "n": "CId",
      "d": 890053,
      "h": 34360628421,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360628421),
//--TRIMMABLE-BOUNDARY-START(42950563013),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310301381,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914680005,
        "f": 83886081
      },
      "n": "DefaultSource",
      "d": 890053,
      "h": 42950563013,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950563013),
//--TRIMMABLE-BOUNDARY-START(47245530309),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900235973,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504614597,
        "f": 83886081
      },
      "n": "DefaultSourceSet",
      "d": 890053,
      "h": 47245530309,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245530309),
//--TRIMMABLE-BOUNDARY-START(141734810821),
    {
      "p": 479361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670039749,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184684483781,
        "f": 83886081
      },
      "n": "RepeaterData",
      "d": 890053,
      "h": 141734810821,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141734810821),
//--TRIMMABLE-BOUNDARY-START(38655595717),
    {
      "p": 1134721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720366789,
        "f": 50331650
      },
      "n": "DataSource",
      "d": 890053,
      "h": 38655595717,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(38655595717),
//--TRIMMABLE-BOUNDARY-START(197569385669),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259974341,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193274418373,
        "f": 83886088
      },
      "n": "Source",
      "d": 890053,
      "h": 197569385669,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(197569385669)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(206159320261),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 890053,
      "h": 206159320261,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(206159320261),
//--TRIMMABLE-BOUNDARY-START(124554941637),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 890053,
      "h": 124554941637,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(124554941637),
//--TRIMMABLE-BOUNDARY-START(51540497605),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 890053,
      "h": 51540497605,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540497605),
//--TRIMMABLE-BOUNDARY-START(128849908933),
    {
      "r": 178454529,
      "n": "OpenPrompt",
      "d": 890053,
      "h": 128849908933,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(128849908933),
//--TRIMMABLE-BOUNDARY-START(201864352965),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 890053,
      "h": 201864352965,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(201864352965),
//--TRIMMABLE-BOUNDARY-START(30065661125),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 890053,
      "h": 30065661125,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30065661125)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770693829),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 890053,
      "h": 25770693829,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770693829)
  ],
  "h": 890053
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IProgress$$($.$$.S.ValueTuple$$$($.$vWqU.LCFCC.PickedFileInfo, $.$$.S.Int32)), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$Iaui.LCFCM.ResourceModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$Iaui.LCFCM.ResourceModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent, $.$MDmQ.LCCWCE.IWebsiteEditable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Editables.WebsiteEditableSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Editables${separator}WebsiteEditableSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(890053)
        
        

        //--TRIMMABLE-BOUNDARY-START(562373)
        $asm.$cls(`$MDmQ.LCCWCE.WebsiteEditableCommonImage`, ($self) => class WebsiteEditableCommonImage extends $.$MDmQ.LCCWCE.WebsiteEditableImage
        {
            //--TRIMMABLE-BOUNDARY-START(21475398853)
            /*WebsiteSection*/ Section = null;
            //--TRIMMABLE-BOUNDARY-END(21475398853)
            
            //--TRIMMABLE-BOUNDARY-START(8590496965)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590496965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590496965)
            
            //--TRIMMABLE-BOUNDARY-START(8590496965)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(8590496965)
            
            static $h = 562373;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$MDmQ.LCCWCE.WebsiteEditableImage; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475398853),
    {
      "p": 2397381,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180431557,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065333445,
        "f": 83886081
      },
      "n": "Section",
      "d": 562373,
      "h": 21475398853,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475398853)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590496965),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 562373,
      "h": 8590496965,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590496965)
  ],
  "h": 562373
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IProgress$$($.$$.S.ValueTuple$$$($.$vWqU.LCFCC.PickedFileInfo, $.$$.S.Int32)), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$Iaui.LCFCM.ResourceModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$Iaui.LCFCM.ResourceModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent, $.$MDmQ.LCCWCE.IWebsiteCommonEditable, $.$MDmQ.LCCWCE.IWebsiteEditable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Editables.WebsiteEditableCommonImage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Editables${separator}WebsiteEditableCommonImage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(562373)
        
        

        //--TRIMMABLE-BOUNDARY-START(627909)
        $asm.$cls(`$MDmQ.LCCWCE.WebsiteEditableCommonSource`, ($self) => class WebsiteEditableCommonSource extends $.$MDmQ.LCCWCE.WebsiteEditableSource
        {
            //--TRIMMABLE-BOUNDARY-START(21475464389)
            /*WebsiteSection*/ Section = null;
            //--TRIMMABLE-BOUNDARY-END(21475464389)
            
            //--TRIMMABLE-BOUNDARY-START(8590562501)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590562501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590562501)
            
            //--TRIMMABLE-BOUNDARY-START(8590562501)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(8590562501)
            
            static $h = 627909;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$MDmQ.LCCWCE.WebsiteEditableSource; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475464389),
    {
      "p": 2397381,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180497093,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065398981,
        "f": 83886081
      },
      "n": "Section",
      "d": 627909,
      "h": 21475464389,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475464389)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590562501),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 627909,
      "h": 8590562501,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590562501)
  ],
  "h": 627909
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IProgress$$($.$$.S.ValueTuple$$$($.$vWqU.LCFCC.PickedFileInfo, $.$$.S.Int32)), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$Iaui.LCFCM.ResourceModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$Iaui.LCFCM.ResourceModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent, $.$MDmQ.LCCWCE.IWebsiteCommonEditable, $.$MDmQ.LCCWCE.IWebsiteEditable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Editables.WebsiteEditableCommonSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Editables${separator}WebsiteEditableCommonSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(627909)
        
        

        //--TRIMMABLE-BOUNDARY-START(1545413)
        $asm.$cls(`$MDmQ.LCCWCS.CommunityWebsiteFeedProvider`, ($self) => class CommunityWebsiteFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296512709)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296512709);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296512709)
            
            //--TRIMMABLE-BOUNDARY-START(8591480005)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityWebsiteHostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591480005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`created a website`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8591480005)
            
            static $h = 1545413;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591480005),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 544897
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 1545413,
      "h": 8591480005,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591480005)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296512709),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1545413,
      "h": 4296512709,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296512709)
  ],
  "h": 1545413
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Services.CommunityWebsiteFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Services${separator}CommunityWebsiteFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1545413)
        
        

        //--TRIMMABLE-BOUNDARY-START(1283269)
        $asm.$cls(`$MDmQ.LCCWCP.CommunityWebsiteApp`, ($self) => class CommunityWebsiteApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$AEuu.LCCWCM.CommunityWebsiteHostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(128850302149)
            /*CommunityWebsiteService*/ WebsiteService = null;
            //--TRIMMABLE-BOUNDARY-END(128850302149)
            
            //--TRIMMABLE-BOUNDARY-START(124555334853)
            /*CommunityWebsiteApplication*/ WebsiteApplication = null;
            //--TRIMMABLE-BOUNDARY-END(124555334853)
            
            //--TRIMMABLE-BOUNDARY-START(17181152453)
            /*ICommunityClientApplication */ get Application()
            {
                return this.WebsiteApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(17181152453)
            
            //--TRIMMABLE-BOUNDARY-START(30066054341)
            /*CommunityPostView */ get CardView()
            {
                return 3/*CommunityPostView.CardFeed*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30066054341)
            
            //--TRIMMABLE-BOUNDARY-START(34361021637)
            /*int? */ get CardWidthHint()
            {
                return 250;
            }
            //--TRIMMABLE-BOUNDARY-END(34361021637)
            
            //--TRIMMABLE-BOUNDARY-START(25771087045)
            /*int? */ get CardSpaceHint()
            {
                return 20;
            }
            //--TRIMMABLE-BOUNDARY-END(25771087045)
            
            //--TRIMMABLE-BOUNDARY-START(103080498373)
            /*string */ get OptimizedComponentName()
            {
                return "communitywebsiteapp communitydefaultpages";
            }
            //--TRIMMABLE-BOUNDARY-END(103080498373)
            
            //--TRIMMABLE-BOUNDARY-START(98785531077)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785531077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.WebsiteService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MDmQ.LCCWCS.CommunityWebsiteService, serviceProvider);
                this.WebsiteApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MDmQ.LCCWCS.CommunityWebsiteApplication, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(98785531077)
            
            //--TRIMMABLE-BOUNDARY-START(21476119749)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476119749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "Name", "Website");
                __builder.AddComponentParameter(2, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                __builder.AddComponentParameter(3, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(4, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/**/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 5);
                        __builder2.AddComponentParameter(6, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                        __builder2.AddAttribute$3(7, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                        {
                            __builder3.AddContent$1(8, wrap.View);
                        }), $dxTTVc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1283269,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $mdhdQh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1283269,"h":0,"f":17825794});
                }), $hWKYgj ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":1283269,"h":0,"f":17825794}));
                __builder.AddAttribute$3(9, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/**/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 10);
                        __builder2.AddComponentParameter(11, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, splash.ViewModel));
                        __builder2.AddComponentParameter(12, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, splash.Message));
                        __builder2.CloseComponent();
                    }, $nnDMhe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1283269,"h":0,"f":17825794});
                }), $vsjwhk ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":1283269,"h":0,"f":17825794}));
                __builder.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.AddContent$1(14, this.GetPages());
                }), $qpUkHe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1283269,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21476119749)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886185157)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886185157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886185157)
            
            //--TRIMMABLE-BOUNDARY-START(12886185157)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12886185157)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(128850302149)
                this.WebsiteService = null;
                //--TRIMMABLE-BOUNDARY-END(128850302149)
                
                //--TRIMMABLE-BOUNDARY-START(124555334853)
                this.WebsiteApplication = null;
                //--TRIMMABLE-BOUNDARY-END(124555334853)
                
            }
            static $h = 1283269;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$AEuu.LCCWCM.CommunityWebsiteHostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(128850302149),
    {
      "p": 1610949,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490563781,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260367557,
        "f": 83886081
      },
      "n": "WebsiteService",
      "d": 1283269,
      "h": 128850302149,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128850302149),
//--TRIMMABLE-BOUNDARY-START(124555334853),
    {
      "p": 1479877,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900629189,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670432965,
        "f": 83886081
      },
      "n": "WebsiteApplication",
      "d": 1283269,
      "h": 124555334853,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124555334853),
//--TRIMMABLE-BOUNDARY-START(17181152453),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950956229,
        "f": 50364420
      },
      "n": "Application",
      "d": 1283269,
      "h": 17181152453,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(17181152453),
//--TRIMMABLE-BOUNDARY-START(30066054341),
    {
      "p": 31299008,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130825413,
        "f": 50364420
      },
      "n": "CardView",
      "d": 1283269,
      "h": 30066054341,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(30066054341),
//--TRIMMABLE-BOUNDARY-START(34361021637),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720760005,
        "f": 50364420
      },
      "n": "CardWidthHint",
      "d": 1283269,
      "h": 34361021637,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(34361021637),
//--TRIMMABLE-BOUNDARY-START(25771087045),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540890821,
        "f": 50364420
      },
      "n": "CardSpaceHint",
      "d": 1283269,
      "h": 25771087045,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(25771087045),
//--TRIMMABLE-BOUNDARY-START(103080498373),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310694597,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1283269,
      "h": 103080498373,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(103080498373)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98785531077),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1283269,
      "h": 98785531077,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98785531077),
//--TRIMMABLE-BOUNDARY-START(21476119749),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1283269,
      "h": 21476119749,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476119749)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886185157),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1283269,
      "h": 12886185157,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886185157)
  ],
  "h": 1283269
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Pages.CommunityWebsiteApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Pages${separator}CommunityWebsiteApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1283269)
        
        

        //--TRIMMABLE-BOUNDARY-START(1348805)
        $asm.$cls(`$MDmQ.LCCWCP.Website`, ($self) => class Website extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(51540956357)
            /*string*/ static DefaultDomain = null;
            //--TRIMMABLE-BOUNDARY-END(51540956357)
            
            //--TRIMMABLE-BOUNDARY-START(8591283397)
            /*string?*/ _Website = null;
            //--TRIMMABLE-BOUNDARY-END(8591283397)
            
            //--TRIMMABLE-BOUNDARY-START(158915138757)
            /*string*/ Host = null;
            //--TRIMMABLE-BOUNDARY-END(158915138757)
            
            //--TRIMMABLE-BOUNDARY-START(176095007941)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(176095007941)
            
            //--TRIMMABLE-BOUNDARY-START(4296316101)
            /*string */ get _Host()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425858245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let host = this._Website ?? this.Host;
                if (host === "website.zoey.africa"/*DefaultDomain*/)
                {
                    /*var*/ let uri = new $.$spu.S.Uri().$ctor$5(this.Navigation.Uri);
                    /*var*/ let q = $.$swh.SW.HttpUtility.ParseQueryString$1(uri.Query);
                    /*var*/ let dm = q.get_Item$2("domain");
                    host = dm ?? host;
                }
                return host;
            }
            //--TRIMMABLE-BOUNDARY-END(4296316101)
            
            //--TRIMMABLE-BOUNDARY-START(188979909829)
            /*string*/ PageRoute = null;
            //--TRIMMABLE-BOUNDARY-END(188979909829)
            
            //--TRIMMABLE-BOUNDARY-START(197569844421)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(197569844421)
            
            //--TRIMMABLE-BOUNDARY-START(154620171461)
            /*PageHeaderAccessor*/ Header = null;
            //--TRIMMABLE-BOUNDARY-END(154620171461)
            
            //--TRIMMABLE-BOUNDARY-START(201864811717)
            /*CommunityWebsiteService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(201864811717)
            
            //--TRIMMABLE-BOUNDARY-START(266289321157)
            /*string? */ get Template()
            {
                return $.$fPer.LCFC.Stringy.op_Implicit$1(this._Host === "website.zoey.africa"/*DefaultDomain*/ ? $.$fPer.LCFCS$6.StringExtension.SplitByPath($.$fPer.LCFC.StringyExtension.AsStringy$1(this.PageRoute).Trim$1(/*/*/ 47)).ElementAtOrDefault(1) : $.$fPer.LCFC.Stringy.op_Implicit$3(null));
            }
            //--TRIMMABLE-BOUNDARY-END(266289321157)
            
            //--TRIMMABLE-BOUNDARY-START(193274877125)
            /*string */ get Route()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555400389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let __ca1__;
                return this._Host === "website.zoey.africa"/*DefaultDomain*/ ? ($.$fPer.LCFCS$6.StringExtension.SplitByPath($.$fPer.LCFC.StringyExtension.AsStringy$1(this.PageRoute).Trim$1(/*/*/ 47)).ElementAtOrDefault(2).ToString() ?? "") : ((__ca1__ = this.PageRoute) !== null ? ($.$$.S.String.Trim$1.call(__ca1__, /*/*/ 47) ?? "") : "");
            }
            //--TRIMMABLE-BOUNDARY-END(193274877125)
            
            //--TRIMMABLE-BOUNDARY-START(180389975237)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(180389975237);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFCD.WorkSpaceExtension.Set($.$MDmQ.LCCWCP.Website, this.UnitOfWork.LCFCI$IClientUnitOfWork$MessagingCenter, this, null, null, true);
                    ($t1 = this.Service.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(180389975237)
            
            //--TRIMMABLE-BOUNDARY-START(55835923653)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835923653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCD.WorkSpaceExtension.Remove($.$MDmQ.LCCWCP.Website, this.UnitOfWork.LCFCI$IClientUnitOfWork$MessagingCenter, null, null, true);
            }
            //--TRIMMABLE-BOUNDARY-END(55835923653)
            
            //--TRIMMABLE-BOUNDARY-START(167505073349)
            /*ValueTask<WireTransportModel<CommunityWebsiteHostModel>> *//*async*/  InterceptResponse(/*WireTransportModel<CommunityWebsiteHostModel>*/ value, /*DataFilter*/ filter, /*object?*/ context)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel)), $.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167505073349);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let path = $.$fPer.LCFCS$6.StringExtension.SplitByPath($.$fPer.LCFC.StringyExtension.AsStringy$1(this.PageRoute));
                    if (!value.Success && value.Message === "Not found" && this._Host === "website.zoey.africa"/*DefaultDomain*/ && path.Length > 1)
                    {
                        let $t3, $r3;
                        /*var*/ let host = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$AEuu.LCCWCM.CommunityWebsiteHostModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$AEuu.LCCWCM.CommunityWebsiteHostModel), [ (() =>
                        {
                            //new $.$AEuu.LCCWCM.CommunityWebsiteHostModel()
                            const $t4 = $.$AEuu.LCCWCM.CommunityWebsiteHostModel;
                            const $i4 = new $t4();
                            $i4.$ctor$6();
                            $i4.Name = "DefaultWebsiteView";
                            $i4.UniqueId = "website.zoey.africa"/*DefaultDomain*/;
                            $i4.Summary = "Default Website Host";
                            $i4.Post = "Default Website Host";
                            return $i4;
                        })() ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        value = (() =>
                        {
                            //new $.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel)()
                            const $t5 = $.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel);
                            const $i5 = new $t5();
                            $i5.$ctor$2();
                            $i5.Success = true;
                            $i5.Data = $.$sl.SL.Enumerable.First$1($.$AEuu.LCCWCM.CommunityWebsiteHostModel, host.Data);
                            return $i5;
                        })();
                    }
                    if ((value.Data?.UniqueId ?? null) === "website.zoey.africa"/*DefaultDomain*/)
                    {
                        value.Data.Template = $.$with(value.Data.Template, ($clone) =>
                        {
                            $clone.Name = this.Template;
                        });
                    }
                    if (value.Data !== null)
                    {
                        this.Header.SetOpenGraphProvider(new $.$hDPm.LCFCH.PageHeaderContentProviderFromOpenGraphData().$ctor$1(value.Data, new $.$fPer.LCFC.Theme()));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$clone(value));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167505073349)
            
            //--TRIMMABLE-BOUNDARY-START(171800040645)
            /*ValueTask<WireTransportModel<CommunityWebsitePageModel>> *//*async*/  InterceptResponse$1(/*WireTransportModel<CommunityWebsitePageModel>*/ value, /*DataFilter*/ filter, /*object?*/ context)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsitePageModel)), $.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsitePageModel), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171800040645);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!value.Success && value.Message === "Not found")
                    {
                        let $t6, $r6;
                        /*CommunityWebsiteHostModel?*/ let website = $.$firstOf(($.$cast(context, $.$AEuu.LCCWCM.CommunityWebsiteHostModel)), () => { throw new $.$$.S.NullReferenceException().$ctor$12("context required") });
                        /*var*/ let pageRoute = filter.Value;
                        /*var*/ let page = ($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$AEuu.LCCWCM.CommunityWebsitePageModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$AEuu.LCCWCM.CommunityWebsitePageModel), [ (() =>
                        {
                            //new $.$AEuu.LCCWCM.CommunityWebsitePageModel()
                            const $t7 = $.$AEuu.LCCWCM.CommunityWebsitePageModel;
                            const $i7 = new $t7();
                            $i7.$ctor$6();
                            $i7.Name = this.PageRoute ?? "Home";
                            $i7.ParentId = website.Identifier;
                            $i7.Account = website.Account;
                            $i7.UniqueId = pageRoute;
                            return $i7;
                        })() ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModel>?*/ let __ca2__;
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsitePageModel)()
                            const $t8 = $.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsitePageModel);
                            const $i8 = new $t8();
                            $i8.$ctor$2();
                            $i8.Success = page.Success;
                            $i8.Data = ((__ca2__ = page.Data) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$AEuu.LCCWCM.CommunityWebsitePageModel, __ca2__) : null);
                            $i8.Message = page.Message;
                            return $i8;
                        })());
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$clone(value));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(171800040645)
            
            //--TRIMMABLE-BOUNDARY-START(184684942533)
            /*string */ get OptimizedComponentName()
            {
                return "website";
            }
            //--TRIMMABLE-BOUNDARY-END(184684942533)
            
            //--TRIMMABLE-BOUNDARY-START(270584288453)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584288453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch9 = parameter.Name;
                switch($switch9)
                {
                    case "_Website":
                    this._Website = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Host":
                    this.Host = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "PageRoute":
                    this.PageRoute = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(270584288453)
            
            //--TRIMMABLE-BOUNDARY-START(163210106053)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210106053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Header = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCH.PageHeaderAccessor, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MDmQ.LCCWCS.CommunityWebsiteService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(163210106053)
            
            //--TRIMMABLE-BOUNDARY-START(47245989061)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245989061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hf scroll");
                __builder.OpenComponent$1($.$hDPm.LCFCCR$1.RemoteDataDetail$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), 2);
                __builder.AddComponentParameter(3, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$23(null, this._Host, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741857/*PostFilterTypes.UniqueId*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 4194304n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)).WithResponseInterceptor(this, null)));
                __builder.AddComponentParameter(4, "Features", "RemoteFeatures.Default|RemoteFeatures.ResultCaching");
                __builder.AddAttribute$3(5, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel)))().$ctor(this, ( (/*website*/ website) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        /*var*/ let route = this.Route;
                        /*var*/ let pageType = website.Data.Template.Name !== null ? $.$AEuu.LCCWC.WebsiteTemplateFactory.GetPage(website.Data.Template.Name, this.Route) : null;
                        if (pageType === null)
                        {
                            pageType = website.Data.Template.Name !== null ? $.$AEuu.LCCWC.WebsiteTemplateFactory.GetPage(website.Data.Template.Name, "") : null;
                            if (pageType !== null)
                            {
                                route = "";
                            }
                        }
                        /*var*/ let pageRoute = `${$.$strNN(this._Host)}/${$.$strNN(route)}`;
                        if (pageType !== null)
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCR$1.RemoteDataDetail$$($.$AEuu.LCCWCM.CommunityWebsitePageModel), 6);
                            __builder2.AddComponentParameter(7, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$23(null, pageRoute, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741857/*PostFilterTypes.UniqueId*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 4194304n | 2251799813685248n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)).WithResponseInterceptor(this, website.Data)));
                            __builder2.AddComponentParameter(8, "Features", "RemoteFeatures.Default|RemoteFeatures.ResultCaching");
                            __builder2.AddAttribute$3(9, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$AEuu.LCCWCM.CommunityWebsitePageModel)))().$ctor(this, ( (/*page*/ page) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    /*var*/ let type = pageType;
                                    __builder3.OpenComponent$1($.$mac.MAC.DynamicComponent, 10);
                                    __builder3.AddComponentParameter(11, "Type", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Type, pageType));
                                    __builder3.AddComponentParameter(12, "Parameters", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), (() =>
                                    {
                                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                                        const $t10 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                                        const $i10 = new $t10();
                                        $i10.$ctor$1();
                                        $i10.set_Item("Website", website.Data);
                                        $i10.set_Item("Page", page.Data);
                                        return $i10;
                                    })()));
                                    __builder3.CloseComponent();
                                }, $dbxOWj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1348805,"h":0,"f":17825794});
                            }), $jhFRTj ??= {"r":6881395,"p":[{"n":"page","p":$.$hDPm.LCFCI.ContainerContext$$($.$AEuu.LCCWCM.CommunityWebsitePageModel).$h}],"n":"","d":1348805,"h":0,"f":17825794}));
                            __builder2.SetKey(pageType);
                            __builder2.CloseComponent();
                        }
                        else 
                        {
                            __builder2.OpenElement(13, "p");
                            __builder2.AddContent$4(14, "Unable to find template \"");
                            __builder2.AddContent$4(15, website.Data.Template.Name);
                            __builder2.AddContent$4(16, "\" or page \"");
                            __builder2.AddContent$4(17, this.PageRoute);
                            __builder2.AddContent$4(18, "\". If you are the owner of this website, edit it and choose a template in zoey website section.");
                            __builder2.CloseElement();
                        }
                    }, $hEPRdf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1348805,"h":0,"f":17825794});
                }), $zrHPNa ??= {"r":6881395,"p":[{"n":"website","p":$.$hDPm.LCFCI.ContainerContext$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$h}],"n":"","d":1348805,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(19, "\r\n\r\n");
                __builder.OpenElement(20, "div");
                __builder.AddAttribute$5(21, "class", "ltroot");
                __builder.OpenComponent$1($.$hDPm.LCFCCU.StaticComponents, 22);
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(47245989061)
            
            //--TRIMMABLE-BOUNDARY-START(4312303958)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFilterResponseInterceptor<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel>>.InterceptResponse(LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel>, LivingThing.Core.Frameworks.Common.Data.DataFilter, object?)
            [`LCFCD$IDataFilterResponseInterceptor$LivingThing$Core$Frameworks$Common$Data$WireTransportModel$LivingThing$Core$Community$Website$Common$Models$CommunityWebsiteHostModel$$InterceptResponse`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312303958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InterceptResponse(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312303958)
            
            //--TRIMMABLE-BOUNDARY-START(4312303958)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFilterResponseInterceptor<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModel>>.InterceptResponse(LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModel>, LivingThing.Core.Frameworks.Common.Data.DataFilter, object?)
            [`LCFCD$IDataFilterResponseInterceptor$LivingThing$Core$Frameworks$Common$Data$WireTransportModel$LivingThing$Core$Community$Website$Common$Models$CommunityWebsitePageModel$$InterceptResponse`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312303958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InterceptResponse$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312303958)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(42951021765)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951021765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951021765)
            
            //--TRIMMABLE-BOUNDARY-START(42951021765)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(42951021765)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(158915138757)
                this.Host = "website.zoey.africa";
                //--TRIMMABLE-BOUNDARY-END(158915138757)
                
                //--TRIMMABLE-BOUNDARY-START(176095007941)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(176095007941)
                
                //--TRIMMABLE-BOUNDARY-START(188979909829)
                this.PageRoute = "";
                //--TRIMMABLE-BOUNDARY-END(188979909829)
                
                //--TRIMMABLE-BOUNDARY-START(197569844421)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(197569844421)
                
                //--TRIMMABLE-BOUNDARY-START(154620171461)
                this.Header = null;
                //--TRIMMABLE-BOUNDARY-END(154620171461)
                
                //--TRIMMABLE-BOUNDARY-START(201864811717)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(201864811717)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51540956357)
                    this.DefaultDomain = "website.zoey.africa";
                    //--TRIMMABLE-BOUNDARY-END(51540956357)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 1348805;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591283397),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015792837,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454746309,
        "f": 83886081
      },
      "n": "_Website",
      "d": 1348805,
      "h": 8591283397,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 12386419,
          "c": 8602321011,
          "n": [
            {
              "n": "Name",
              "v": "domain",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591283397),
//--TRIMMABLE-BOUNDARY-START(158915138757),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195662021,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227634615493,
        "f": 83886081
      },
      "n": "Host",
      "d": 1348805,
      "h": 158915138757,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158915138757),
//--TRIMMABLE-BOUNDARY-START(176095007941),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785596613,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236224550085,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 1348805,
      "h": 176095007941,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176095007941),
//--TRIMMABLE-BOUNDARY-START(4296316101),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425858245,
        "f": 50331650
      },
      "n": "_Host",
      "d": 1348805,
      "h": 4296316101,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4296316101),
//--TRIMMABLE-BOUNDARY-START(188979909829),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965465797,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244814484677,
        "f": 83886081
      },
      "n": "PageRoute",
      "d": 1348805,
      "h": 188979909829,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188979909829),
//--TRIMMABLE-BOUNDARY-START(197569844421),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145334981,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253404419269,
        "f": 83886081
      },
      "n": "Server",
      "d": 1348805,
      "h": 197569844421,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197569844421),
//--TRIMMABLE-BOUNDARY-START(154620171461),
    {
      "p": 61888170,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605727429,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044680901,
        "f": 83886081
      },
      "n": "Header",
      "d": 1348805,
      "h": 154620171461,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154620171461),
//--TRIMMABLE-BOUNDARY-START(201864811717),
    {
      "p": 1610949,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735269573,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261994353861,
        "f": 83886081
      },
      "n": "Service",
      "d": 1348805,
      "h": 201864811717,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201864811717),
//--TRIMMABLE-BOUNDARY-START(266289321157),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325204165,
        "f": 50331650
      },
      "n": "Template",
      "d": 1348805,
      "h": 266289321157,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(266289321157),
//--TRIMMABLE-BOUNDARY-START(193274877125),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555400389,
        "f": 50331650
      },
      "n": "Route",
      "d": 1348805,
      "h": 193274877125,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(193274877125),
//--TRIMMABLE-BOUNDARY-START(184684942533),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375531205,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1348805,
      "h": 184684942533,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(184684942533)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(180389975237),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1348805,
      "h": 180389975237,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(180389975237),
//--TRIMMABLE-BOUNDARY-START(55835923653),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1348805,
      "h": 55835923653,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835923653),
//--TRIMMABLE-BOUNDARY-START(167505073349),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel)).$h,
      "p": [
        {
          "n": "value",
          "p": $.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$h
        },
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "context",
          "p": 131073
        }
      ],
      "n": "InterceptResponse",
      "d": 1348805,
      "h": 167505073349,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(167505073349),
//--TRIMMABLE-BOUNDARY-START(171800040645),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsitePageModel)).$h,
      "p": [
        {
          "n": "value",
          "p": $.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsitePageModel).$h
        },
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "context",
          "p": 131073
        }
      ],
      "n": "InterceptResponse",
      "o": "@$1",
      "d": 1348805,
      "h": 171800040645,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(171800040645),
//--TRIMMABLE-BOUNDARY-START(270584288453),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1348805,
      "h": 270584288453,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(270584288453),
//--TRIMMABLE-BOUNDARY-START(163210106053),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1348805,
      "h": 163210106053,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163210106053),
//--TRIMMABLE-BOUNDARY-START(47245989061),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1348805,
      "h": 47245989061,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47245989061)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540956357),
    {
      "t": 1310721,
      "n": "DefaultDomain",
      "d": 1348805,
      "h": 51540956357,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51540956357)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42951021765),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1348805,
      "h": 42951021765,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951021765)
  ],
  "h": 1348805,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/WebsiteView/{*PageRoute}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$fPer.LCFCD.IDataFilterResponseInterceptor$$($.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel)), $.$fPer.LCFCD.IDataFilterResponseInterceptor$$($.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsitePageModel)), $.$fPer.LCFCD.IDataFilterResponseInterceptor, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Pages.Website`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Pages${separator}Website`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1348805)
        
        

        //--TRIMMABLE-BOUNDARY-START(1610949)
        $asm.$cls(`$MDmQ.LCCWCS.CommunityWebsiteService`, ($self) => class CommunityWebsiteService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$AEuu.LCCWCM.CommunityWebsiteHostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8591545541)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591545541);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591545541)
            
            //--TRIMMABLE-BOUNDARY-START(12886512837)
            /*WebsitePage?*/ CurrentPage = null;
            //--TRIMMABLE-BOUNDARY-END(12886512837)
            
            static $h = 1610949;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$AEuu.LCCWCM.CommunityWebsiteHostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886512837),
    {
      "p": 2266309,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476447429,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066382021,
        "f": 83886081
      },
      "n": "CurrentPage",
      "d": 1610949,
      "h": 12886512837,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886512837)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591545541),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1610949,
      "h": 8591545541,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591545541)
  ],
  "h": 1610949
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$AEuu.LCCWCM.CommunityWebsiteHostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Client.Services.CommunityWebsiteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Client${separator}Services${separator}CommunityWebsiteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1610949)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Website.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(38085)
