"use strict";
class Website {
    init(page, host) {
        let editables = document.querySelectorAll("*[contenteditable='true']");
        editables.forEach(ed => {
            ed.addEventListener("blur", function () {
                page.invokeMethodAsync("SetText", ed.id, ed.textContent);
            });
            ed.addEventListener("click", function (e) {
                e.preventDefault();
                e.stopPropagation();
            });
        });
        let anchors = document.querySelectorAll("a.edit");
        anchors.forEach(ed => {
            ed.addEventListener("click", function (e) {
                e.preventDefault();
                //e.stopPropagation();
            });
        });
        var base = document.head.getElementsByTagName("base")[0];
        if (host.includes("localhost")) {
            base.href = "https://" + host + "/WebsiteView/";
        }
        else {
            base.href = "https://" + host + "/";
        }
    }
}
window["website"] = new Website();
//# sourceMappingURL=LivingThing.Core.Community.Website.Client.Blazor.js.map