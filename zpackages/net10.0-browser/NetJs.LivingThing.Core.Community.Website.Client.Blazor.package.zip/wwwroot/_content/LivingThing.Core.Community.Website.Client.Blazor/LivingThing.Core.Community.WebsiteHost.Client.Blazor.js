var Website = /** @class */ (function () {
    function Website() {
    }
    Website.prototype.init = function (page) {
        var editables = document.querySelectorAll("span[contenteditable='true']");
        editables.forEach(function (ed) {
            ed.addEventListener("blur", function () {
                page.invokeMethodAsync("SetText", ed.id, ed.textContent);
            });
            ed.addEventListener("click", function (e) {
                e.preventDefault();
                e.stopPropagation();
            });
        });
    };
    return Website;
}());
window["Website"] = new Website();
