
//--TRIMMABLE-BOUNDARY-START(20609)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $fKIVSb;
    let $BSdgbj;
    let $jDKrfd;
    let $SGdeTd;
    let $YYhiLh;
    let $hDnnde;
    let $pVLpfj;
    let $gtkYVa;
    let $sGjDXj;
    let $hmjiBk;
    let $fXDHdj;
    let $CttJwc;
    let $XSkNUe;
    let $usvKmj;
    let $QtDUOd;
    let $ZmWsRk;
    let $fnVoDh;
    let $dZUBTb;
    let $uvkqji;
    let $DEnFSg;
    let $ywEThh;
    let $rqcJoc;
    let $wyPLyk;
    let $UCbHAj;
    let $cOujEf;
    let $lcMZGk;
    let $cgYTUd;
    let $YpFQBb;
    let $ntfAJb;
    let $suupOf;
    let $giTOFf;
    let $VCNlKe;
    let $xFZeee;
    let $BRdmMe;
    let $yFnFtd;
    let $wdNDoa;
    let $SCAyGf;
    let $NfwOra;
    let $VmAAVb;
    let $ExXANe;
    let $NVbXfb;
    let $bJvtuj;
    let $Pxhuoe;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Website.Common", 
    {
  "h": 20609,
  "f": "LivingThing.Core.Community.Website.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Website.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Website.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1134721)
        $asm.$cls(`$AEuu.LCCWCM.IWebsiteDataSource`, ($self) => class IWebsiteDataSource
        {
            static $h = 1134721;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886036609),
    {
      "p": 1134721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591069313,
        "f": 50331905
      },
      "n": "Parent",
      "o": "LCCWCM$IWebsiteDataSource$Parent",
      "d": 1134721,
      "h": 12886036609,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886036609)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475971201),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "p": [
        {
          "n": "updateStore",
          "p": $.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)).$h,
          "f": 65
        }
      ],
      "n": "UpdateStore",
      "o": "LCCWCM$IWebsiteDataSource$UpdateStore",
      "d": 1134721,
      "h": 21475971201,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475971201),
//--TRIMMABLE-BOUNDARY-START(17181003905),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource)).$h,
      "p": [
        {
          "n": "updateStore",
          "p": $.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource))).$h,
          "f": 65
        }
      ],
      "n": "UpdateRepeaterStore",
      "o": "LCCWCM$IWebsiteDataSource$UpdateRepeaterStore",
      "d": 1134721,
      "h": 17181003905,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181003905)
  ],
  "h": 1134721
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.IWebsiteDataSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}IWebsiteDataSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1134721)
        
        

        //--TRIMMABLE-BOUNDARY-START(1527937)
        $asm.$cls(`$AEuu.LCCWCS.ICommunityWebsiteIntegrationProvider`, ($self) => class ICommunityWebsiteIntegrationProvider
        {
            static $h = 1527937;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591462529),
    {
      "r": 262145,
      "p": [
        {
          "n": "website",
          "p": 544897
        }
      ],
      "n": "IsIntegrated",
      "o": "LCCWCS$ICommunityWebsiteIntegrationProvider$IsIntegrated",
      "d": 1527937,
      "h": 8591462529,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591462529),
//--TRIMMABLE-BOUNDARY-START(4296495233),
    {
      "r": 178454529,
      "p": [
        {
          "n": "website",
          "p": 544897
        }
      ],
      "n": "IntegrateAsync",
      "o": "LCCWCS$ICommunityWebsiteIntegrationProvider$IntegrateAsync",
      "d": 1527937,
      "h": 4296495233,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296495233)
  ],
  "h": 1527937
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Services.ICommunityWebsiteIntegrationProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Services${separator}ICommunityWebsiteIntegrationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1527937)
        
        

        //--TRIMMABLE-BOUNDARY-START(2052225)
        $asm.$cls(`$AEuu.LCCWCS$2.CommunityWebsiteStatesCustomAttributesProvider`, ($self) => class CommunityWebsiteStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297019521)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297019521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297019521)
            
            static $h = 2052225;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297019521),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2052225,
      "h": 4297019521,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297019521)
  ],
  "h": 2052225
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.States.CommunityWebsiteStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}States${separator}CommunityWebsiteStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2052225)
        
        

        //--TRIMMABLE-BOUNDARY-START(282753)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsiteCategoryModelCustomAttributesProvider`, ($self) => class CommunityWebsiteCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295250049)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295250049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$AEuu.LCCWCM.CommunityWebsiteHostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295250049)
            
            static $h = 282753;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295250049),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 282753,
      "h": 4295250049,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295250049)
  ],
  "h": 282753
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsiteCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(282753)
        
        

        //--TRIMMABLE-BOUNDARY-START(1790081)
        $asm.$cls(`$AEuu.LCCWCS$1.CommunityWebsiteSettingsCustomAttributesProvider`, ($self) => class CommunityWebsiteSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296757377)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296757377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296757377)
            
            static $h = 1790081;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296757377),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1790081,
      "h": 4296757377,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296757377)
  ],
  "h": 1790081
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Settings.CommunityWebsiteSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Settings${separator}CommunityWebsiteSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1790081)
        
        

        //--TRIMMABLE-BOUNDARY-START(2248833)
        $asm.$cls(`$AEuu.LCCWC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297216129)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297216129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$AEuu.LCCWCM.CommunityWebsiteCategoryModelTypeDescriptorBuilder.Register();
                $.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptorBuilder.Register();
                $.$AEuu.LCCWCM.CommunityWebsitePageModelTypeDescriptorBuilder.Register();
                $.$AEuu.LCCWCS$1.CommunityWebsiteSettingsTypeDescriptorBuilder.Register();
                $.$AEuu.LCCWCS$2.CommunityWebsiteStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297216129)
            
            static $h = 2248833;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297216129),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2248833,
      "h": 4297216129,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297216129)
  ],
  "h": 2248833
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2248833)
        
        

        //--TRIMMABLE-BOUNDARY-START(86145)
        $asm.$cls(`$AEuu.LCCWC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295053441)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295053441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AEuu.LCCWCM.CommunityWebsiteCategoryModelCustomAttributesProvider, $.$AEuu.LCCWCM.CommunityWebsiteCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AEuu.LCCWCM.CommunityWebsiteHostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AEuu.LCCWCM.CommunityWebsiteHostModelCustomAttributesProvider, $.$AEuu.LCCWCM.CommunityWebsiteHostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AEuu.LCCWCM.CommunityWebsitePageModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AEuu.LCCWCM.CommunityWebsitePageModelCustomAttributesProvider, $.$AEuu.LCCWCM.CommunityWebsitePageModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AEuu.LCCWCS$1.CommunityWebsiteSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AEuu.LCCWCS$1.CommunityWebsiteSettingsCustomAttributesProvider, $.$AEuu.LCCWCS$1.CommunityWebsiteSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AEuu.LCCWCS$2.CommunityWebsiteStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AEuu.LCCWCS$2.CommunityWebsiteStatesCustomAttributesProvider, $.$AEuu.LCCWCS$2.CommunityWebsiteStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295053441)
            
            static $h = 86145;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295053441),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 86145,
      "h": 4295053441,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295053441)
  ],
  "h": 86145
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(86145)
        
        

        //--TRIMMABLE-BOUNDARY-START(872577)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsitePageModelCustomAttributesProvider`, ($self) => class CommunityWebsitePageModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295839873)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295839873)
            
            //--TRIMMABLE-BOUNDARY-START(8590807169)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590807169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$AEuu.LCCWCM.CommunityWebsitePageModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Route", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Data", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$AEuu.LCCWCM.CommunityWebsitePageModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $BSdgbj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":872577,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $jDKrfd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":872577,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590807169)
            
            static $h = 872577;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590807169),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 872577,
      "h": 8590807169,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590807169)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295839873),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 872577,
      "h": 4295839873,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295839873)
  ],
  "h": 872577
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsitePageModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(872577)
        
        

        //--TRIMMABLE-BOUNDARY-START(1921153)
        $asm.$cls(`$AEuu.LCCWCS$1.CommunityWebsiteSettingsTypeDescriptorBuilder`, ($self) => class CommunityWebsiteSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591855745)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591855745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AEuu.LCCWCS$1.CommunityWebsiteSettingsTypeDescriptor()
                        const $t1 = $.$AEuu.LCCWCS$1.CommunityWebsiteSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Website.Common.Settings.CommunityWebsiteSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dZUBTb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1921153,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AEuu.LCCWCS$1.CommunityWebsiteSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591855745)
            
            //--TRIMMABLE-BOUNDARY-START(4296888449)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296888449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296888449)
            
            //--TRIMMABLE-BOUNDARY-START(4296888449)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296888449)
            
            static $h = 1921153;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591855745),
    {
      "r": 65537,
      "n": "Register",
      "d": 1921153,
      "h": 8591855745,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591855745)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296888449),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1921153,
      "h": 4296888449,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296888449)
  ],
  "h": 1921153
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Settings.CommunityWebsiteSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Settings${separator}CommunityWebsiteSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1921153)
        
        

        //--TRIMMABLE-BOUNDARY-START(610433)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsiteHostModelCustomAttributesProvider`, ($self) => class CommunityWebsiteHostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295577729)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295577729)
            
            //--TRIMMABLE-BOUNDARY-START(8590545025)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590545025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$AEuu.LCCWCM.CommunityWebsiteHostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(5, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Data", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("UniqueId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (1024);
                            $i4.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i4.Title = "Domain";
                            $i4.Description = "Enter your website domain";
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=Identifier"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Template", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (1025);
                            $i5.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i5.InputType = $.$cast(25n, $.$fPer.LCFC.InputType);
                            $i5.Description = "Choose a template";
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=Table"], [-1], null);
                            $i5.OptionsReader = ($.$AEuu.LCCWCM.WebTemplateReader.$type);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ConnectedStoreId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Parent", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$AEuu.LCCWCM.CommunityWebsiteHostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $hDnnde ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":610433,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $pVLpfj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":610433,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590545025)
            
            static $h = 610433;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590545025),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 610433,
      "h": 8590545025,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590545025)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295577729),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 610433,
      "h": 4295577729,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295577729)
  ],
  "h": 610433
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsiteHostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(610433)
        
        

        //--TRIMMABLE-BOUNDARY-START(2379905)
        $asm.$cls(`$AEuu.LCCWC.WebsiteTemplateFactory`, ($self) => class WebsiteTemplateFactory
        {
            //--TRIMMABLE-BOUNDARY-START(30067150977)
            /*Dictionary<string, WebsiteTemplate>*/ static Templates = null;
            //--TRIMMABLE-BOUNDARY-END(30067150977)
            
            //--TRIMMABLE-BOUNDARY-START(25772183681)
            static /*void */ Register(T, /*string*/ name, /*string*/ title, /*string*/ route)
            {
                /*var*/ let urlTemplates;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772183681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$AEuu.LCCWC.WebsiteTemplateFactory.Templates.TryGetValue(name, $.$ref(() => urlTemplates, ($v) => urlTemplates = $v, $.$AEuu.LCCWC.WebsiteTemplate)))
                {
                    urlTemplates = (() =>
                    {
                        //new $.$AEuu.LCCWC.WebsiteTemplate()
                        const $t2 = $.$AEuu.LCCWC.WebsiteTemplate;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.Title = title;
                        return $i2;
                    })();
                    $.$AEuu.LCCWC.WebsiteTemplateFactory.Templates.set_Item(name, $.$clone(urlTemplates));
                }
                urlTemplates.Pages.Add((() =>
                {
                    //new $.$AEuu.LCCWC.WebsiteTemplatePage()
                    const $t3 = $.$AEuu.LCCWC.WebsiteTemplatePage;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.ComponentType = T.$type;
                    $i3.Route = route;
                    return $i3;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(25772183681)
            
            //--TRIMMABLE-BOUNDARY-START(21477216385)
            static /*Type */ GetPage(/*string*/ name, /*string*/ route)
            {
                /*var*/ let urlTemplates;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477216385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$AEuu.LCCWC.WebsiteTemplateFactory.Templates.TryGetValue(name, $.$ref(() => urlTemplates, ($v) => urlTemplates = $v, $.$AEuu.LCCWC.WebsiteTemplate)))
                {
                    return $.$sl.SL.Enumerable.SingleOrDefault$1($.$AEuu.LCCWC.WebsiteTemplatePage, urlTemplates.Pages, new ($.$$.S.Func$$$($.$AEuu.LCCWC.WebsiteTemplatePage, $.$$.S.Boolean))().$ctor(this,  (/**/ s) =>
                    {
                        return (s.Route ?? "") === (route ?? "");
                    }, $fKIVSb ??= {"r":262145,"p":[{"n":"s","p":2445441}],"n":"","d":2379905,"h":0,"f":17825794})).ComponentType;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(21477216385)
            
            //--TRIMMABLE-BOUNDARY-START(8592314497)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592314497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(30067150977)
                    this.Templates = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$AEuu.LCCWC.WebsiteTemplate))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(30067150977)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592314497)
            
            static $h = 2379905;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067150977),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$AEuu.LCCWC.WebsiteTemplate).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182249089,
        "f": 50331681
      },
      "n": "Templates",
      "d": 2379905,
      "h": 30067150977,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30067150977)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772183681),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "title",
          "p": 1310721
        },
        {
          "n": "route",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "Register",
      "d": 2379905,
      "h": 25772183681,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25772183681),
//--TRIMMABLE-BOUNDARY-START(21477216385),
    {
      "r": 188547073,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "route",
          "p": 1310721
        }
      ],
      "n": "GetPage",
      "d": 2379905,
      "h": 21477216385,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477216385)
  ],
  "h": 2379905
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.WebsiteTemplateFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}WebsiteTemplateFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2379905)
        
        

        //--TRIMMABLE-BOUNDARY-START(2183297)
        $asm.$cls(`$AEuu.LCCWCS$2.CommunityWebsiteStatesTypeDescriptorBuilder`, ($self) => class CommunityWebsiteStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592117889)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592117889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AEuu.LCCWCS$2.CommunityWebsiteStatesTypeDescriptor()
                        const $t1 = $.$AEuu.LCCWCS$2.CommunityWebsiteStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Website.Common.States.CommunityWebsiteStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $SGdeTd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2183297,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AEuu.LCCWCS$2.CommunityWebsiteStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592117889)
            
            //--TRIMMABLE-BOUNDARY-START(4297150593)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297150593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297150593)
            
            //--TRIMMABLE-BOUNDARY-START(4297150593)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297150593)
            
            static $h = 2183297;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592117889),
    {
      "r": 65537,
      "n": "Register",
      "d": 2183297,
      "h": 8592117889,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592117889)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297150593),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2183297,
      "h": 4297150593,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297150593)
  ],
  "h": 2183297
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.States.CommunityWebsiteStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}States${separator}CommunityWebsiteStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2183297)
        
        

        //--TRIMMABLE-BOUNDARY-START(151681)
        $asm.$cls(`$AEuu.LCCWC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295118977)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295118977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$AEuu.LCCWCS.ICommunityWebsiteFeedRemoteService, $.$AEuu.LCCWCS.ICommunityWebsiteFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$AEuu.LCCWCS.ICommunityWebsiteFeedRemoteService_Mocking().$ctor$3(impl);
                }, $gtkYVa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":151681,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$AEuu.LCCWCS.ICommunityWebsiteFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$AEuu.LCCWCS.ICommunityWebsiteFeedRemoteService_Mocking().$ctor$3(impl);
                }, $sGjDXj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":151681,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$AEuu.LCCWCS.IComunityWebsiteRemoteService, $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking().$ctor$3(impl);
                }, $hmjiBk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":151681,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking().$ctor$3(impl);
                }, $fXDHdj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":151681,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking().$ctor$3(impl);
                }, $CttJwc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":151681,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking().$ctor$3(impl);
                }, $XSkNUe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":151681,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking().$ctor$3(impl);
                }, $usvKmj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":151681,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking().$ctor$3(impl);
                }, $QtDUOd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":151681,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking().$ctor$3(impl);
                }, $ZmWsRk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":151681,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking().$ctor$3(impl);
                }, $fnVoDh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":151681,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295118977)
            
            static $h = 151681;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295118977),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 151681,
      "h": 4295118977,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295118977)
  ],
  "h": 151681
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(151681)
        
        

        //--TRIMMABLE-BOUNDARY-START(413825)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsiteCategoryModelTypeDescriptorBuilder`, ($self) => class CommunityWebsiteCategoryModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590348417)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590348417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AEuu.LCCWCM.CommunityWebsiteCategoryModelTypeDescriptor()
                        const $t1 = $.$AEuu.LCCWCM.CommunityWebsiteCategoryModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteCategoryModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ywEThh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":413825,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590348417)
            
            //--TRIMMABLE-BOUNDARY-START(4295381121)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295381121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295381121)
            
            //--TRIMMABLE-BOUNDARY-START(4295381121)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295381121)
            
            static $h = 413825;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590348417),
    {
      "r": 65537,
      "n": "Register",
      "d": 413825,
      "h": 8590348417,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590348417)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295381121),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 413825,
      "h": 4295381121,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295381121)
  ],
  "h": 413825
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteCategoryModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsiteCategoryModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(413825)
        
        

        //--TRIMMABLE-BOUNDARY-START(1003649)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsitePageModelTypeDescriptorBuilder`, ($self) => class CommunityWebsitePageModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590938241)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590938241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AEuu.LCCWCM.CommunityWebsitePageModelTypeDescriptor()
                        const $t1 = $.$AEuu.LCCWCM.CommunityWebsitePageModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $UCbHAj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1003649,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AEuu.LCCWCM.CommunityWebsitePageModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590938241)
            
            //--TRIMMABLE-BOUNDARY-START(4295970945)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295970945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295970945)
            
            //--TRIMMABLE-BOUNDARY-START(4295970945)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295970945)
            
            static $h = 1003649;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590938241),
    {
      "r": 65537,
      "n": "Register",
      "d": 1003649,
      "h": 8590938241,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590938241)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295970945),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1003649,
      "h": 4295970945,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295970945)
  ],
  "h": 1003649
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsitePageModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1003649)
        
        

        //--TRIMMABLE-BOUNDARY-START(741505)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptorBuilder`, ($self) => class CommunityWebsiteHostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590676097)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590676097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor()
                        const $t1 = $.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $VCNlKe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":741505,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AEuu.LCCWCM.CommunityWebsiteHostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590676097)
            
            //--TRIMMABLE-BOUNDARY-START(4295708801)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295708801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295708801)
            
            //--TRIMMABLE-BOUNDARY-START(4295708801)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295708801)
            
            static $h = 741505;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590676097),
    {
      "r": 65537,
      "n": "Register",
      "d": 741505,
      "h": 8590676097,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590676097)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295708801),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 741505,
      "h": 4295708801,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295708801)
  ],
  "h": 741505
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsiteHostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(741505)
        
        

        //--TRIMMABLE-BOUNDARY-START(1331329)
        $asm.$cls(`$AEuu.LCCWC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591265921)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591265921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$AEuu.LCCWCM.CommunityWebsiteHostModel, 7169/*PostTypes.WebsiteHost*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$AEuu.LCCWCM.CommunityWebsitePageModel, 7170/*PostTypes.WebsitePage*/);
                $.$AEuu.LCCWC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$AEuu.LCCWC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$AEuu.LCCWC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591265921)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$AEuu.LCCWC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296298625)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296298625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296298625)
            
            //--TRIMMABLE-BOUNDARY-START(4296298625)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296298625)
            
            static $h = 1331329;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591265921),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1331329,
      "h": 8591265921,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591265921)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296298625),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1331329,
      "h": 4296298625,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296298625)
  ],
  "h": 1331329
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1331329)
        
        

        //--TRIMMABLE-BOUNDARY-START(479361)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsiteDataSource`, ($self) => class CommunityWebsiteDataSource extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180348545)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180348545);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180348545)
            
            //--TRIMMABLE-BOUNDARY-START(73014923393)
            /*Dictionary<string, string>*/ Store = null;
            //--TRIMMABLE-BOUNDARY-END(73014923393)
            
            //--TRIMMABLE-BOUNDARY-START(51540086913)
            /*Dictionary<string, List<CommunityWebsiteDataSource>>*/ RepeaterStore = null;
            //--TRIMMABLE-BOUNDARY-END(51540086913)
            
            //--TRIMMABLE-BOUNDARY-START(47245119617)
            /*IWebsiteDataSource?*/ Parent = null;
            //--TRIMMABLE-BOUNDARY-END(47245119617)
            
            //--TRIMMABLE-BOUNDARY-START(81604857985)
            /*Dictionary<string, string> */ UpdateStore(/*Action<Dictionary<string, string>>?*/ updateStore)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604857985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                updateStore?.Invoke(this.Store);
                return this.Store;
            }
            //--TRIMMABLE-BOUNDARY-END(81604857985)
            
            //--TRIMMABLE-BOUNDARY-START(77309890689)
            /*Dictionary<string, List<CommunityWebsiteDataSource>> */ UpdateRepeaterStore(/*Action<Dictionary<string, List<CommunityWebsiteDataSource>>>?*/ updateStore)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309890689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                updateStore?.Invoke(this.RepeaterStore);
                return this.RepeaterStore;
            }
            //--TRIMMABLE-BOUNDARY-END(77309890689)
            
            //--TRIMMABLE-BOUNDARY-START(8591069313)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Common.Models.IWebsiteDataSource.Parent.get
            get LCCWCM$IWebsiteDataSource$Parent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886036609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Parent;
            }
            //--TRIMMABLE-BOUNDARY-END(8591069313)
            
            //--TRIMMABLE-BOUNDARY-START(21475971201)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Common.Models.IWebsiteDataSource.UpdateStore(System.Action<System.Collections.Generic.Dictionary<string, string>>?)
            LCCWCM$IWebsiteDataSource$UpdateStore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475971201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateStore(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475971201)
            
            //--TRIMMABLE-BOUNDARY-START(17181003905)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Common.Models.IWebsiteDataSource.UpdateRepeaterStore(System.Action<System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteDataSource>>>?)
            LCCWCM$IWebsiteDataSource$UpdateRepeaterStore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181003905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateRepeaterStore(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181003905)
            
            //--TRIMMABLE-BOUNDARY-START(17180348545)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180348545)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(73014923393)
                this.Store = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(73014923393)
                
                //--TRIMMABLE-BOUNDARY-START(51540086913)
                this.RepeaterStore = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(51540086913)
                
            }
            static $h = 479361;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014923393),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950152321,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719956097,
        "f": 83886081
      },
      "n": "Store",
      "d": 479361,
      "h": 73014923393,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014923393),
//--TRIMMABLE-BOUNDARY-START(51540086913),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360217729,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130021505,
        "f": 83886081
      },
      "n": "RepeaterStore",
      "d": 479361,
      "h": 51540086913,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540086913),
//--TRIMMABLE-BOUNDARY-START(47245119617),
    {
      "p": 1134721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770283137,
        "f": 50331649
      },
      "n": "Parent",
      "d": 479361,
      "h": 47245119617,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245119617)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81604857985),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "p": [
        {
          "n": "updateStore",
          "p": $.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)).$h,
          "f": 65
        }
      ],
      "n": "UpdateStore",
      "d": 479361,
      "h": 81604857985,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604857985),
//--TRIMMABLE-BOUNDARY-START(77309890689),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource)).$h,
      "p": [
        {
          "n": "updateStore",
          "p": $.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource))).$h,
          "f": 65
        }
      ],
      "n": "UpdateRepeaterStore",
      "d": 479361,
      "h": 77309890689,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309890689)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180348545),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 479361,
      "h": 17180348545,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180348545)
  ],
  "h": 479361
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$AEuu.LCCWCM.IWebsiteDataSource ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteDataSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsiteDataSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(479361)
        
        

        //--TRIMMABLE-BOUNDARY-START(2445441)
        $asm.$str(`$AEuu.LCCWC.WebsiteTemplatePage`, ($self) => class WebsiteTemplatePage extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17182314625)
            /*Type*/ ComponentType = null;
            //--TRIMMABLE-BOUNDARY-END(17182314625)
            
            //--TRIMMABLE-BOUNDARY-START(38657151105)
            /*string*/ Route = null;
            //--TRIMMABLE-BOUNDARY-END(38657151105)
            
            //--TRIMMABLE-BOUNDARY-START(12887347329)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887347329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887347329)
            
            //--TRIMMABLE-BOUNDARY-START(12887347329)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12887347329)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ComponentType = this.ComponentType;
                copy.Route = this.Route;
                return copy;
            }
            static $h = 2445441;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182314625),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772249217,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47247085697,
        "f": 83886081
      },
      "n": "ComponentType",
      "d": 2445441,
      "h": 17182314625,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182314625),
//--TRIMMABLE-BOUNDARY-START(38657151105),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362183809,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837020289,
        "f": 83886081
      },
      "n": "Route",
      "d": 2445441,
      "h": 38657151105,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657151105)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887347329),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2445441,
      "h": 12887347329,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887347329)
  ],
  "h": 2445441
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.WebsiteTemplatePage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}WebsiteTemplatePage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2445441)
        
        

        //--TRIMMABLE-BOUNDARY-START(2314369)
        $asm.$str(`$AEuu.LCCWC.WebsiteTemplate`, ($self) => class WebsiteTemplate extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12887216257)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887216257);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887216257)
            
            //--TRIMMABLE-BOUNDARY-START(47246954625)
            /*string*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(47246954625)
            
            //--TRIMMABLE-BOUNDARY-START(34362052737)
            /*List<WebsiteTemplatePage>*/ Pages = null;
            //--TRIMMABLE-BOUNDARY-END(34362052737)
            
            //--TRIMMABLE-BOUNDARY-START(12887216257)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12887216257)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Title = this.Title;
                copy.Pages = this.Pages;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34362052737)
                this.Pages = new ($.$$.SCG.List$$($.$AEuu.LCCWC.WebsiteTemplatePage))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(34362052737)
                
            }
            static $h = 2314369;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246954625),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067085441,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951987329,
        "f": 83886081
      },
      "n": "Title",
      "d": 2314369,
      "h": 47246954625,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246954625),
//--TRIMMABLE-BOUNDARY-START(34362052737),
    {
      "p": $.$$.SCG.List$$($.$AEuu.LCCWC.WebsiteTemplatePage).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477150849,
        "f": 50331649
      },
      "n": "Pages",
      "d": 2314369,
      "h": 34362052737,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362052737)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887216257),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2314369,
      "h": 12887216257,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887216257)
  ],
  "h": 2314369
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.WebsiteTemplate`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}WebsiteTemplate`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2314369)
        
        

        //--TRIMMABLE-BOUNDARY-START(1200257)
        $asm.$str(`$AEuu.LCCWCM.WebsiteTemplate`, ($self) => class WebsiteTemplate extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(68720676993)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(68720676993)
            
            //--TRIMMABLE-BOUNDARY-START(90195513473)
            /*string*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(90195513473)
            
            //--TRIMMABLE-BOUNDARY-START(25771004033)
            /*string*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(25771004033)
            
            //--TRIMMABLE-BOUNDARY-START(64425709697)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(64425709697)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(21476036737)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476036737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476036737)
            
            //--TRIMMABLE-BOUNDARY-START(21476036737)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21476036737)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Name = this.Name;
                copy.Title = this.Title;
                copy.Description = this.Description;
                copy.Icon = this.Icon.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64425709697)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(64425709697)
                
            }
            static $h = 1200257;
            static $z = 40;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720676993),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540807809,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310611585,
        "f": 83886081
      },
      "n": "Name",
      "d": 1200257,
      "h": 68720676993,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720676993),
//--TRIMMABLE-BOUNDARY-START(90195513473),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130742401,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900546177,
        "f": 83886081
      },
      "n": "Title",
      "d": 1200257,
      "h": 90195513473,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195513473),
//--TRIMMABLE-BOUNDARY-START(25771004033),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360938625,
        "f": 50331649
      },
      "n": "Description",
      "d": 1200257,
      "h": 25771004033,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771004033),
//--TRIMMABLE-BOUNDARY-START(64425709697),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950873217,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1200257,
      "h": 64425709697,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425709697)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476036737),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1200257,
      "h": 21476036737,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476036737)
  ],
  "h": 1200257
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.WebsiteTemplate`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}WebsiteTemplate`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1200257)
        
        

        //--TRIMMABLE-BOUNDARY-START(1069185)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsiteUserPreference`, ($self) => class CommunityWebsiteUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4296036481)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296036481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296036481)
            
            //--TRIMMABLE-BOUNDARY-START(4296036481)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296036481)
            
            static $h = 1069185;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296036481),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1069185,
      "h": 4296036481,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296036481)
  ],
  "h": 1069185
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsiteUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1069185)
        
        

        //--TRIMMABLE-BOUNDARY-START(1265793)
        $asm.$cls(`$AEuu.LCCWCM.WebTemplateReader`, ($self) => class WebTemplateReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591200385)
            /*Pager<ISelectOption<WebsiteTemplate>> */ GetOptions(/*object?*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591200385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.GetPager($.$fPer.LCFC.ISelectOption$$($.$AEuu.LCCWCM.WebsiteTemplate), $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$AEuu.LCCWC.WebsiteTemplate), $.$fPer.LCFC.ISelectOption$$($.$AEuu.LCCWCM.WebsiteTemplate), $.$AEuu.LCCWC.WebsiteTemplateFactory.Templates, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$AEuu.LCCWC.WebsiteTemplate), $.$fPer.LCFC.ISelectOption$$($.$AEuu.LCCWCM.WebsiteTemplate)))().$ctor(this,  (/*t*/ t) =>
                {
                    return (() =>
                    {
                        //new $.$fPer.LCFC.SelectOption$$($.$AEuu.LCCWCM.WebsiteTemplate)()
                        const $t1 = $.$fPer.LCFC.SelectOption$$($.$AEuu.LCCWCM.WebsiteTemplate);
                        const $i1 = new $t1();
                        $i1.$ctor$3((() =>
                        {
                            //new $.$AEuu.LCCWCM.WebsiteTemplate()
                            const $t2 = $.$AEuu.LCCWCM.WebsiteTemplate;
                            const $i2 = new $t2();
                            $i2.$ctor$2();
                            $i2.Name = t.Key;
                            $i2.Title = t.Value.Title;
                            return $i2;
                        })());
                        $i1.Title = t.Key;
                        return $i1;
                    })();
                }, $DEnFSg ??= {"r":$.$fPer.LCFC.ISelectOption$$($.$AEuu.LCCWCM.WebsiteTemplate).$h,"p":[{"n":"t","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$AEuu.LCCWC.WebsiteTemplate).$h}],"n":"","d":1265793,"h":0,"f":17825794})), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8591200385)
            
            //--TRIMMABLE-BOUNDARY-START(4297034070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaOptionReader<LivingThing.Core.Community.Website.Common.Models.WebsiteTemplate>.GetOptions(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaOptionReader$LivingThing$Core$Community$Website$Common$Models$WebsiteTemplate$GetOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297034070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOptions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297034070)
            
            //--TRIMMABLE-BOUNDARY-START(4296233089)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296233089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296233089)
            
            //--TRIMMABLE-BOUNDARY-START(4296233089)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296233089)
            
            static $h = 1265793;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591200385),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$AEuu.LCCWCM.WebsiteTemplate)).$h,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "GetOptions",
      "d": 1265793,
      "h": 8591200385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591200385)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296233089),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1265793,
      "h": 4296233089,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296233089)
  ],
  "h": 1265793
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$AEuu.LCCWCM.WebsiteTemplate) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.WebTemplateReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}WebTemplateReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1265793)
        
        

        //--TRIMMABLE-BOUNDARY-START(1986689)
        $asm.$cls(`$AEuu.LCCWCS$2.CommunityWebsiteStates`, ($self) => class CommunityWebsiteStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296953985)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296953985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296953985)
            
            //--TRIMMABLE-BOUNDARY-START(4296953985)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296953985)
            
            static $h = 1986689;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296953985),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1986689,
      "h": 4296953985,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296953985)
  ],
  "h": 1986689
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.States.CommunityWebsiteStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}States${separator}CommunityWebsiteStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1986689)
        
        

        //--TRIMMABLE-BOUNDARY-START(1724545)
        $asm.$cls(`$AEuu.LCCWCS$1.CommunityWebsiteSettings`, ($self) => class CommunityWebsiteSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296691841)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296691841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296691841)
            
            //--TRIMMABLE-BOUNDARY-START(4296691841)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296691841)
            
            static $h = 1724545;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296691841),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1724545,
      "h": 4296691841,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296691841)
  ],
  "h": 1724545
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Settings.CommunityWebsiteSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Settings${separator}CommunityWebsiteSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1724545)
        
        

        //--TRIMMABLE-BOUNDARY-START(1855617)
        $asm.$cls(`$AEuu.LCCWCS$1.CommunityWebsiteSettingsTypeDescriptor`, ($self) => class CommunityWebsiteSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AEuu.LCCWCS$1.CommunityWebsiteSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296822913)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296822913);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AEuu.LCCWCS$1.CommunityWebsiteSettingsTypeDescriptor.GenerateProperties($.$AEuu.LCCWCS$1.CommunityWebsiteSettings, this, factory);
                    }, $uvkqji ??= {"r":65537,"n":"","d":1855617,"h":0,"f":17825794}), 0, "CommunityWebsiteSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Website.Common\\Settings_CommunityWebsiteSettings_LivingThing.Core.Community.Website.Common.Settings.CommunityWebsiteSettingsTypeDescriptorBuilder.g.cs", "CommunityWebsiteSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296822913)
            
            //--TRIMMABLE-BOUNDARY-START(12886757505)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886757505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886757505)
            
            //--TRIMMABLE-BOUNDARY-START(17181724801)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Website.Common.Settings.CommunityWebsiteSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181724801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181724801)
            
            //--TRIMMABLE-BOUNDARY-START(8591790209)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Website.Common.Settings.CommunityWebsiteSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591790209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$AEuu.LCCWCS$1.CommunityWebsiteSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AEuu.LCCWCS$1.CommunityWebsiteSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCS$1.CommunityWebsiteSettings)))
                {
                    /*var*/ let result = $.$AEuu.LCCWCS$1.CommunityWebsiteSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCS$1.CommunityWebsiteSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AEuu.LCCWCS$1.CommunityWebsiteSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCS$1.CommunityWebsiteSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591790209)
            
            static $h = 1855617;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AEuu.LCCWCS$1.CommunityWebsiteSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886757505),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1855617,
      "h": 12886757505,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886757505),
//--TRIMMABLE-BOUNDARY-START(17181724801),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1724545,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1855617,
      "h": 17181724801,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181724801),
//--TRIMMABLE-BOUNDARY-START(8591790209),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1724545,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1855617,
      "h": 8591790209,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591790209)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296822913),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1855617,
      "h": 4296822913,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296822913)
  ],
  "h": 1855617
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AEuu.LCCWCS$1.CommunityWebsiteSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Settings.CommunityWebsiteSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Settings${separator}CommunityWebsiteSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1855617)
        
        

        //--TRIMMABLE-BOUNDARY-START(2117761)
        $asm.$cls(`$AEuu.LCCWCS$2.CommunityWebsiteStatesTypeDescriptor`, ($self) => class CommunityWebsiteStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AEuu.LCCWCS$2.CommunityWebsiteStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4297085057)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297085057);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AEuu.LCCWCS$2.CommunityWebsiteStatesTypeDescriptor.GenerateProperties($.$AEuu.LCCWCS$2.CommunityWebsiteStates, this, factory);
                    }, $YYhiLh ??= {"r":65537,"n":"","d":2117761,"h":0,"f":17825794}), 0, "CommunityWebsiteStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Website.Common\\States_CommunityWebsiteStates_LivingThing.Core.Community.Website.Common.States.CommunityWebsiteStatesTypeDescriptorBuilder.g.cs", "CommunityWebsiteStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297085057)
            
            //--TRIMMABLE-BOUNDARY-START(12887019649)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887019649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887019649)
            
            //--TRIMMABLE-BOUNDARY-START(17181986945)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Website.Common.States.CommunityWebsiteStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181986945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181986945)
            
            //--TRIMMABLE-BOUNDARY-START(8592052353)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Website.Common.States.CommunityWebsiteStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592052353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$AEuu.LCCWCS$2.CommunityWebsiteStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AEuu.LCCWCS$2.CommunityWebsiteStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCS$2.CommunityWebsiteStates)))
                {
                    /*var*/ let result = $.$AEuu.LCCWCS$2.CommunityWebsiteStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCS$2.CommunityWebsiteStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AEuu.LCCWCS$2.CommunityWebsiteStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCS$2.CommunityWebsiteStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592052353)
            
            static $h = 2117761;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AEuu.LCCWCS$2.CommunityWebsiteStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887019649),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2117761,
      "h": 12887019649,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887019649),
//--TRIMMABLE-BOUNDARY-START(17181986945),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1986689,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2117761,
      "h": 17181986945,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181986945),
//--TRIMMABLE-BOUNDARY-START(8592052353),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1986689,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2117761,
      "h": 8592052353,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592052353)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297085057),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2117761,
      "h": 4297085057,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297085057)
  ],
  "h": 2117761
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AEuu.LCCWCS$2.CommunityWebsiteStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.States.CommunityWebsiteStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}States${separator}CommunityWebsiteStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2117761)
        
        

        $asm.$typeProxy("$AEuu.LCCWCM.CommunityWebsiteHostModel", "$AEuu.LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel");
        //--TRIMMABLE-BOUNDARY-START(217217)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsiteCategoryModel`, ($self) => class CommunityWebsiteCategoryModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$AEuu.LCCWCM.CommunityWebsiteHostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180086401)
            /*PostTypes */ get Type()
            {
                return 7171/*PostTypes.WebsiteCategory*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180086401)
            
            //--TRIMMABLE-BOUNDARY-START(4295184513)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295184513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295184513)
            
            //--TRIMMABLE-BOUNDARY-START(4295184513)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295184513)
            
            static $h = 217217;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$AEuu.LCCWCM.CommunityWebsiteHostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180086401),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885119105,
        "f": 50364417
      },
      "n": "Type",
      "d": 217217,
      "h": 17180086401,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180086401)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295184513),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 217217,
      "h": 4295184513,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295184513)
  ],
  "h": 217217
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsiteCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(217217)
        
        

        //--TRIMMABLE-BOUNDARY-START(544897)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsiteHostModel`, ($self) => class CommunityWebsiteHostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(141734465665)
            /*PostTypes */ get Type()
            {
                return 7169/*PostTypes.WebsiteHost*/;
            }
            //--TRIMMABLE-BOUNDARY-END(141734465665)
            
            //--TRIMMABLE-BOUNDARY-START(25770348673)
            /*CommunityWebsiteDataSource? */ get Data()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950217857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$AEuu.LCCWCM.CommunityWebsiteDataSource, new $.$AEuu.LCCWCM.CommunityWebsiteDataSource().$ctor$1(), "Data", null);
            }
            /*CommunityWebsiteDataSource? */ set Data(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669694593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$AEuu.LCCWCM.CommunityWebsiteDataSource, value, "Data");
            }
            //--TRIMMABLE-BOUNDARY-END(25770348673)
            
            //--TRIMMABLE-BOUNDARY-START(146029432961)
            /*string? */ get UniqueId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309956225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.UniqueId;
            }
            /*string? */ set UniqueId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849563777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.UniqueId = value;
            }
            //--TRIMMABLE-BOUNDARY-END(146029432961)
            
            //--TRIMMABLE-BOUNDARY-START(137439498369)
            /*WebsiteTemplate */ get Template()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130087041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$AEuu.LCCWCM.WebsiteTemplate, new $.$AEuu.LCCWCM.WebsiteTemplate(), "Template", null);
            }
            /*WebsiteTemplate */ set Template(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259629185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$AEuu.LCCWCM.WebsiteTemplate, $.$clone(value), "Template");
            }
            //--TRIMMABLE-BOUNDARY-END(137439498369)
            
            //--TRIMMABLE-BOUNDARY-START(21475381377)
            /*DataId */ get ConnectedStoreId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360283265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCD.DataId, new $.$fPer.LCFCD.DataId(), "ConnectedStoreId", null);
            }
            /*DataId */ set ConnectedStoreId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079760001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCD.DataId, $.$clone(value), "ConnectedStoreId");
            }
            //--TRIMMABLE-BOUNDARY-END(21475381377)
            
            //--TRIMMABLE-BOUNDARY-START(81604923521)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604923521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "UniqueId", "Domain", null, null, null, null);
                super.ModifyDescriptor(propertyBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(81604923521)
            
            //--TRIMMABLE-BOUNDARY-START(85899890817)
            /*IWebsiteDataSource?*/ Parent$1 = null;
            //--TRIMMABLE-BOUNDARY-END(85899890817)
            
            //--TRIMMABLE-BOUNDARY-START(150324400257)
            /*Dictionary<string, List<CommunityWebsiteDataSource>> */ UpdateRepeaterStore(/*Action<Dictionary<string, List<CommunityWebsiteDataSource>>>?*/ updateStore)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324400257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let data = this.Data;
                /*var*/ let store = data.UpdateRepeaterStore(updateStore);
                this.Data = data;
                if (updateStore !== null)
                {
                    this.StoreUpdated?.Invoke(this, $.$$.S.EventArgs.Empty);
                }
                return store;
            }
            //--TRIMMABLE-BOUNDARY-END(150324400257)
            
            //--TRIMMABLE-BOUNDARY-START(154619367553)
            /*Dictionary<string, string> */ UpdateStore(/*Action<Dictionary<string, string>>?*/ updateStore)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619367553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let data = this.Data;
                /*var*/ let store = data.UpdateStore(updateStore);
                this.Data = data;
                if (updateStore !== null)
                {
                    this.StoreUpdated?.Invoke(this, $.$$.S.EventArgs.Empty);
                }
                return store;
            }
            //--TRIMMABLE-BOUNDARY-END(154619367553)
            
            //--TRIMMABLE-BOUNDARY-START(133144531073)
            /*EventHandler?*/ StoreUpdated = null;
            //--TRIMMABLE-BOUNDARY-END(133144531073)
            
            //--TRIMMABLE-BOUNDARY-START(133144531073)
            //--TRIMMABLE-BOUNDARY-START(17180414081)
            add_StoreUpdated(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180414081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.StoreUpdated = $.$$.S.Delegate.Combine$2(this.StoreUpdated, value);
            }
            //--TRIMMABLE-BOUNDARY-END(17180414081)
            
            //--TRIMMABLE-BOUNDARY-START(94489825409)
            remove_StoreUpdated(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489825409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.StoreUpdated = $.$$.S.Delegate.Remove(this.StoreUpdated, value);
            }
            //--TRIMMABLE-BOUNDARY-END(94489825409)
            
            //--TRIMMABLE-BOUNDARY-END(133144531073)
            
            //--TRIMMABLE-BOUNDARY-START(8591069313)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Common.Models.IWebsiteDataSource.Parent.get
            get LCCWCM$IWebsiteDataSource$Parent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886036609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Parent$1;
            }
            //--TRIMMABLE-BOUNDARY-END(8591069313)
            
            //--TRIMMABLE-BOUNDARY-START(21475971201)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Common.Models.IWebsiteDataSource.UpdateStore(System.Action<System.Collections.Generic.Dictionary<string, string>>?)
            LCCWCM$IWebsiteDataSource$UpdateStore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475971201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateStore(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475971201)
            
            //--TRIMMABLE-BOUNDARY-START(17181003905)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Common.Models.IWebsiteDataSource.UpdateRepeaterStore(System.Action<System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteDataSource>>>?)
            LCCWCM$IWebsiteDataSource$UpdateRepeaterStore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181003905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateRepeaterStore(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181003905)
            
            //--TRIMMABLE-BOUNDARY-START(8590479489)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590479489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590479489)
            
            //--TRIMMABLE-BOUNDARY-START(8590479489)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(8590479489)
            
            static $h = 544897;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(141734465665),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720021633,
        "f": 50364417
      },
      "n": "Type",
      "d": 544897,
      "h": 141734465665,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734465665),
//--TRIMMABLE-BOUNDARY-START(25770348673),
    {
      "p": 479361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950217857,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669694593,
        "f": 83886081
      },
      "n": "Data",
      "d": 544897,
      "h": 25770348673,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770348673),
//--TRIMMABLE-BOUNDARY-START(146029432961),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309956225,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849563777,
        "f": 83918849
      },
      "n": "UniqueId",
      "d": 544897,
      "h": 146029432961,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1024,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Title",
              "v": "Domain",
              "t": 1310721
            },
            {
              "n": "Description",
              "v": "Enter your website domain",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=Identifier"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029432961),
//--TRIMMABLE-BOUNDARY-START(137439498369),
    {
      "p": 1200257,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130087041,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259629185,
        "f": 83886081
      },
      "n": "Template",
      "d": 544897,
      "h": 137439498369,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1025,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "InputType",
              "v": 25,
              "t": 47614294
            },
            {
              "n": "Description",
              "v": "Choose a template",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=Table"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            },
            {
              "n": "OptionsReader",
              "v": 1265793,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439498369),
//--TRIMMABLE-BOUNDARY-START(21475381377),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360283265,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079760001,
        "f": 83886081
      },
      "n": "ConnectedStoreId",
      "d": 544897,
      "h": 21475381377,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475381377),
//--TRIMMABLE-BOUNDARY-START(85899890817),
    {
      "p": 1134721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540152449,
        "f": 50331649
      },
      "n": "Parent",
      "o": "@$1",
      "d": 544897,
      "h": 85899890817,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85899890817)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81604923521),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 544897,
      "h": 81604923521,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604923521),
//--TRIMMABLE-BOUNDARY-START(150324400257),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource)).$h,
      "p": [
        {
          "n": "updateStore",
          "p": $.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource))).$h,
          "f": 65
        }
      ],
      "n": "UpdateRepeaterStore",
      "d": 544897,
      "h": 150324400257,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324400257),
//--TRIMMABLE-BOUNDARY-START(154619367553),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "p": [
        {
          "n": "updateStore",
          "p": $.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)).$h,
          "f": 65
        }
      ],
      "n": "UpdateStore",
      "d": 544897,
      "h": 154619367553,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154619367553)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590479489),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 544897,
      "h": 8590479489,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590479489)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(133144531073),
    {
      "e": 80609281,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "add_StoreUpdated",
        "d": 544897,
        "h": 17180414081,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "remove_StoreUpdated",
        "d": 544897,
        "h": 94489825409,
        "f": 285212673
      },
      "n": "StoreUpdated",
      "d": 544897,
      "h": 133144531073,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(133144531073)
  ],
  "h": 544897
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$AEuu.LCCWCM.IWebsiteDataSource ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsiteHostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(544897)
        
        

        //--TRIMMABLE-BOUNDARY-START(1396865)
        $asm.$cls(`$AEuu.LCCWCS.ICommunityWebsiteFeedRemoteService`, ($self) => class ICommunityWebsiteFeedRemoteService
        {
            static $h = 1396865;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1396865,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Services.ICommunityWebsiteFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Services${separator}ICommunityWebsiteFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1396865)
        
        

        //--TRIMMABLE-BOUNDARY-START(1593473)
        $asm.$cls(`$AEuu.LCCWCS.IComunityWebsiteRemoteService`, ($self) => class IComunityWebsiteRemoteService
        {
            static $h = 1593473;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1593473,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.ICreateDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.IReadDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Services.IComunityWebsiteRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Services${separator}IComunityWebsiteRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1593473)
        
        

        //--TRIMMABLE-BOUNDARY-START(807041)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsitePageModel`, ($self) => class CommunityWebsitePageModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(107374989441)
            /*PostTypes */ get Type()
            {
                return 7170/*PostTypes.WebsitePage*/;
            }
            //--TRIMMABLE-BOUNDARY-END(107374989441)
            
            //--TRIMMABLE-BOUNDARY-START(77310218369)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310218369);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310218369)
            
            //--TRIMMABLE-BOUNDARY-START(73015251073)
            /*bool */ RequiresPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015251073);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015251073)
            
            //--TRIMMABLE-BOUNDARY-START(81605185665)
            /*string? */ get Route()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245447297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "Route", null);
            }
            /*string? */ set Route(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785054849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "Route");
            }
            //--TRIMMABLE-BOUNDARY-END(81605185665)
            
            //--TRIMMABLE-BOUNDARY-START(21475643521)
            /*CommunityWebsiteDataSource? */ get Data()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065578113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$AEuu.LCCWCM.CommunityWebsiteDataSource, new $.$AEuu.LCCWCM.CommunityWebsiteDataSource().$ctor$1(), "Data", null);
            }
            /*CommunityWebsiteDataSource? */ set Data(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195120257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$AEuu.LCCWCM.CommunityWebsiteDataSource, value, "Data");
            }
            //--TRIMMABLE-BOUNDARY-END(21475643521)
            
            //--TRIMMABLE-BOUNDARY-START(60130349185)
            /*IWebsiteDataSource?*/ Parent$1 = null;
            //--TRIMMABLE-BOUNDARY-END(60130349185)
            
            //--TRIMMABLE-BOUNDARY-START(111669956737)
            /*Dictionary<string, List<CommunityWebsiteDataSource>> */ UpdateRepeaterStore(/*Action<Dictionary<string, List<CommunityWebsiteDataSource>>>?*/ updateStore)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669956737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let data = this.Data;
                /*var*/ let store = data.UpdateRepeaterStore(updateStore);
                this.Data = data;
                if (updateStore !== null)
                {
                    this.StoreUpdated?.Invoke(this, $.$$.S.EventArgs.Empty);
                }
                return store;
            }
            //--TRIMMABLE-BOUNDARY-END(111669956737)
            
            //--TRIMMABLE-BOUNDARY-START(115964924033)
            /*Dictionary<string, string> */ UpdateStore(/*Action<Dictionary<string, string>>?*/ updateStore)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964924033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let data = this.Data;
                /*var*/ let store = data.UpdateStore(updateStore);
                this.Data = data;
                if (updateStore !== null)
                {
                    this.StoreUpdated?.Invoke(this, $.$$.S.EventArgs.Empty);
                }
                return store;
            }
            //--TRIMMABLE-BOUNDARY-END(115964924033)
            
            //--TRIMMABLE-BOUNDARY-START(103080022145)
            /*EventHandler?*/ StoreUpdated = null;
            //--TRIMMABLE-BOUNDARY-END(103080022145)
            
            //--TRIMMABLE-BOUNDARY-START(103080022145)
            //--TRIMMABLE-BOUNDARY-START(17180676225)
            add_StoreUpdated(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180676225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.StoreUpdated = $.$$.S.Delegate.Combine$2(this.StoreUpdated, value);
            }
            //--TRIMMABLE-BOUNDARY-END(17180676225)
            
            //--TRIMMABLE-BOUNDARY-START(68720283777)
            remove_StoreUpdated(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720283777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.StoreUpdated = $.$$.S.Delegate.Remove(this.StoreUpdated, value);
            }
            //--TRIMMABLE-BOUNDARY-END(68720283777)
            
            //--TRIMMABLE-BOUNDARY-END(103080022145)
            
            //--TRIMMABLE-BOUNDARY-START(8591069313)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Common.Models.IWebsiteDataSource.Parent.get
            get LCCWCM$IWebsiteDataSource$Parent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886036609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Parent$1;
            }
            //--TRIMMABLE-BOUNDARY-END(8591069313)
            
            //--TRIMMABLE-BOUNDARY-START(21475971201)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Common.Models.IWebsiteDataSource.UpdateStore(System.Action<System.Collections.Generic.Dictionary<string, string>>?)
            LCCWCM$IWebsiteDataSource$UpdateStore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475971201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateStore(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475971201)
            
            //--TRIMMABLE-BOUNDARY-START(17181003905)
            //Generated interface implemetation for LivingThing.Core.Community.Website.Common.Models.IWebsiteDataSource.UpdateRepeaterStore(System.Action<System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteDataSource>>>?)
            LCCWCM$IWebsiteDataSource$UpdateRepeaterStore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181003905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateRepeaterStore(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181003905)
            
            //--TRIMMABLE-BOUNDARY-START(8590741633)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590741633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590741633)
            
            //--TRIMMABLE-BOUNDARY-START(8590741633)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(8590741633)
            
            static $h = 807041;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107374989441),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835381889,
        "f": 50364417
      },
      "n": "Type",
      "d": 807041,
      "h": 107374989441,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107374989441),
//--TRIMMABLE-BOUNDARY-START(81605185665),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245447297,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785054849,
        "f": 83886081
      },
      "n": "Route",
      "d": 807041,
      "h": 81605185665,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605185665),
//--TRIMMABLE-BOUNDARY-START(21475643521),
    {
      "p": 479361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065578113,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195120257,
        "f": 83886081
      },
      "n": "Data",
      "d": 807041,
      "h": 21475643521,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475643521),
//--TRIMMABLE-BOUNDARY-START(60130349185),
    {
      "p": 1134721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655512705,
        "f": 50331649
      },
      "n": "Parent",
      "o": "@$1",
      "d": 807041,
      "h": 60130349185,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130349185)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77310218369),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 807041,
      "h": 77310218369,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310218369),
//--TRIMMABLE-BOUNDARY-START(73015251073),
    {
      "r": 262145,
      "n": "RequiresPost",
      "d": 807041,
      "h": 73015251073,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015251073),
//--TRIMMABLE-BOUNDARY-START(111669956737),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource)).$h,
      "p": [
        {
          "n": "updateStore",
          "p": $.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource))).$h,
          "f": 65
        }
      ],
      "n": "UpdateRepeaterStore",
      "d": 807041,
      "h": 111669956737,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669956737),
//--TRIMMABLE-BOUNDARY-START(115964924033),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "p": [
        {
          "n": "updateStore",
          "p": $.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)).$h,
          "f": 65
        }
      ],
      "n": "UpdateStore",
      "d": 807041,
      "h": 115964924033,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964924033)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590741633),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 807041,
      "h": 8590741633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590741633)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(103080022145),
    {
      "e": 80609281,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "add_StoreUpdated",
        "d": 807041,
        "h": 17180676225,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "remove_StoreUpdated",
        "d": 807041,
        "h": 68720283777,
        "f": 285212673
      },
      "n": "StoreUpdated",
      "d": 807041,
      "h": 103080022145,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(103080022145)
  ],
  "h": 807041
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$AEuu.LCCWCM.IWebsiteDataSource ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsitePageModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(807041)
        
        

        //--TRIMMABLE-BOUNDARY-START(1462401)
        $asm.$cls(`$AEuu.LCCWCS.ICommunityWebsiteFeedRemoteService_Mocking`, ($self) => class ICommunityWebsiteFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296429697)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296429697);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296429697)
            
            //--TRIMMABLE-BOUNDARY-START(8591396993)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Website$Common$Models$CommunityWebsiteHostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591396993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591396993)
            
            static $h = 1462401;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296429697),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1462401,
      "h": 4296429697,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296429697)
  ],
  "h": 1462401
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$AEuu.LCCWCS.ICommunityWebsiteFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Services.ICommunityWebsiteFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Services${separator}ICommunityWebsiteFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1462401)
        
        

        //--TRIMMABLE-BOUNDARY-START(1659009)
        $asm.$cls(`$AEuu.LCCWCS.IComunityWebsiteRemoteService_Mocking`, ($self) => class IComunityWebsiteRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296626305)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296626305);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296626305)
            
            //--TRIMMABLE-BOUNDARY-START(8591593601)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Website$Common$Models$CommunityWebsiteHostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591593601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591593601)
            
            //--TRIMMABLE-BOUNDARY-START(17181528193)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Website$Common$Models$CommunityWebsiteHostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181528193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$AEuu.LCCWCM.CommunityWebsiteHostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181528193)
            
            //--TRIMMABLE-BOUNDARY-START(21476495489)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Website$Common$Models$CommunityWebsiteHostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476495489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.WireTransportModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$AEuu.LCCWCM.CommunityWebsiteHostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476495489)
            
            //--TRIMMABLE-BOUNDARY-START(25771462785)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Website$Common$Models$CommunityWebsiteHostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771462785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771462785)
            
            //--TRIMMABLE-BOUNDARY-START(12886560897)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886560897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$AEuu.LCCWCM.CommunityWebsiteHostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886560897)
            
            static $h = 1659009;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296626305),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1659009,
      "h": 4296626305,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296626305)
  ],
  "h": 1659009
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$AEuu.LCCWCS.IComunityWebsiteRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.ICreateDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.IReadDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Services.IComunityWebsiteRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Services${separator}IComunityWebsiteRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1659009)
        
        

        //--TRIMMABLE-BOUNDARY-START(348289)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsiteCategoryModelTypeDescriptor`, ($self) => class CommunityWebsiteCategoryModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295315585)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295315585);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AEuu.LCCWCM.CommunityWebsiteCategoryModelTypeDescriptor.GenerateProperties($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, this, factory);
                    }, $rqcJoc ??= {"r":65537,"n":"","d":348289,"h":0,"f":17825794}), 0, "CommunityWebsiteCategoryModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Website.Common\\Models_CommunityWebsiteCategoryModel_LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteCategoryModelTypeDescriptorBuilder.g.cs", "CommunityWebsiteCategoryModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295315585)
            
            //--TRIMMABLE-BOUNDARY-START(12885250177)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885250177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AEuu.LCCWCM.CommunityWebsiteCategoryModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteCategoryModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsiteCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$AEuu.LCCWCM.CommunityWebsiteCategoryModel)).Type);
                        }, $wyPLyk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":348289,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$AEuu.LCCWCM.CommunityWebsiteHostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885250177)
            
            //--TRIMMABLE-BOUNDARY-START(17180217473)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteCategoryModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180217473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteCategoryModel, LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$AEuu.LCCWCM.CommunityWebsiteHostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$AEuu.LCCWCM.CommunityWebsiteHostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180217473)
            
            //--TRIMMABLE-BOUNDARY-START(8590282881)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteCategoryModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590282881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$AEuu.LCCWCM.CommunityWebsiteCategoryModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCM.CommunityWebsiteCategoryModel)))
                {
                    /*var*/ let result = $.$AEuu.LCCWCM.CommunityWebsiteCategoryModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCM.CommunityWebsiteCategoryModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCM.CommunityWebsiteCategoryModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590282881)
            
            static $h = 348289;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885250177),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 348289,
      "h": 12885250177,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885250177),
//--TRIMMABLE-BOUNDARY-START(17180217473),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 217217,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 348289,
      "h": 17180217473,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180217473),
//--TRIMMABLE-BOUNDARY-START(8590282881),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 217217,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 348289,
      "h": 8590282881,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590282881)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295315585),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 348289,
      "h": 4295315585,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295315585)
  ],
  "h": 348289
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteCategoryModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsiteCategoryModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(348289)
        
        

        //--TRIMMABLE-BOUNDARY-START(675969)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor`, ($self) => class CommunityWebsiteHostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295643265)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295643265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor.GenerateProperties($.$AEuu.LCCWCM.CommunityWebsiteHostModel, this, factory);
                    }, $xFZeee ??= {"r":65537,"n":"","d":675969,"h":0,"f":17825794}), 0, "CommunityWebsiteHostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Website.Common\\Models_CommunityWebsiteHostModel_LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModelTypeDescriptorBuilder.g.cs", "CommunityWebsiteHostModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295643265)
            
            //--TRIMMABLE-BOUNDARY-START(12885577857)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885577857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UniqueId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AEuu.LCCWCM.CommunityWebsiteHostModel.$type, $.$discardRef(), "UniqueId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UniqueId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "UniqueId";
                        $i1.DelaredOn = "LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AEuu.LCCWCM.CommunityWebsiteHostModel)).UniqueId);
                        }, $BRdmMe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":675969,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.UniqueId = value.AsReference($.$$.S.String);
                        }, $yFnFtd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":675969,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Template"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AEuu.LCCWCM.CommunityWebsiteHostModel.$type, $.$discardRef(), "Template", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Template")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$AEuu.LCCWCM.WebsiteTemplate, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Template";
                        $i3.DelaredOn = "LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$AEuu.LCCWCM.WebsiteTemplate, ($.$cast(target, $.$AEuu.LCCWCM.CommunityWebsiteHostModel)).Template);
                        }, $wdNDoa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":675969,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Template = value.AsValue($.$AEuu.LCCWCM.WebsiteTemplate);
                        }, $SCAyGf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":675969,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AEuu.LCCWCM.CommunityWebsiteHostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Type";
                        $i5.DelaredOn = "LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$AEuu.LCCWCM.CommunityWebsiteHostModel)).Type);
                        }, $NfwOra ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":675969,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Data"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AEuu.LCCWCM.CommunityWebsiteHostModel.$type, $.$discardRef(), "Data", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Data")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$AEuu.LCCWCM.CommunityWebsiteDataSource, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Data";
                        $i7.DelaredOn = "LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$AEuu.LCCWCM.CommunityWebsiteDataSource, ($.$cast(target, $.$AEuu.LCCWCM.CommunityWebsiteHostModel)).Data);
                        }, $VmAAVb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":675969,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Data = value.AsReference($.$AEuu.LCCWCM.CommunityWebsiteDataSource);
                        }, $ExXANe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":675969,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ConnectedStoreId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AEuu.LCCWCM.CommunityWebsiteHostModel.$type, $.$discardRef(), "ConnectedStoreId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ConnectedStoreId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "ConnectedStoreId";
                        $i9.DelaredOn = "LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$AEuu.LCCWCM.CommunityWebsiteHostModel)).ConnectedStoreId);
                        }, $NVbXfb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":675969,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ConnectedStoreId = value.AsValue($.$fPer.LCFCD.DataId);
                        }, $bJvtuj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":675969,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Parent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AEuu.LCCWCM.CommunityWebsiteHostModel.$type, $.$discardRef(), "Parent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Parent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$AEuu.LCCWCM.IWebsiteDataSource, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Parent";
                        $i11.DelaredOn = "LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$AEuu.LCCWCM.IWebsiteDataSource, ($.$cast(target, $.$AEuu.LCCWCM.CommunityWebsiteHostModel)).Parent$1);
                        }, $Pxhuoe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":675969,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885577857)
            
            //--TRIMMABLE-BOUNDARY-START(17180545153)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180545153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteCategoryModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _UniqueId = _target.UniqueId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UniqueId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _UniqueId, ($v) => _UniqueId = $v, $.$$.S.String)))
                    {
                        _target.UniqueId = _UniqueId;
                    }
                }
                {
                    /*var*/ let _Template = _target.Template;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Template"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$AEuu.LCCWCM.WebsiteTemplate));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$AEuu.LCCWCM.WebsiteTemplate, () => _Template, ($v) => _Template = $v, null, true)))
                    {
                        _target.Template = $.$clone(_Template);
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Data = _target.Data;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Data"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Data, ($v) => _Data = $v, $.$AEuu.LCCWCM.CommunityWebsiteDataSource)))
                    {
                        _target.Data = _Data;
                    }
                }
                {
                    /*var*/ let _ConnectedStoreId = _target.ConnectedStoreId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ConnectedStoreId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _ConnectedStoreId, ($v) => _ConnectedStoreId = $v, null, true)))
                    {
                        _target.ConnectedStoreId = $.$clone(_ConnectedStoreId);
                    }
                }
                {
                    /*var*/ let _Parent = _target.Parent$1;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Parent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$AEuu.LCCWCM.IWebsiteDataSource));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Parent, ($v) => _Parent = $v, $.$AEuu.LCCWCM.IWebsiteDataSource)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180545153)
            
            //--TRIMMABLE-BOUNDARY-START(8590610561)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590610561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$AEuu.LCCWCM.CommunityWebsiteHostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AEuu.LCCWCM.CommunityWebsiteHostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCM.CommunityWebsiteHostModel)))
                {
                    /*var*/ let result = $.$AEuu.LCCWCM.CommunityWebsiteHostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCM.CommunityWebsiteHostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AEuu.LCCWCM.CommunityWebsiteHostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCM.CommunityWebsiteHostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590610561)
            
            static $h = 675969;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885577857),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 675969,
      "h": 12885577857,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885577857),
//--TRIMMABLE-BOUNDARY-START(17180545153),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 544897,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 675969,
      "h": 17180545153,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180545153),
//--TRIMMABLE-BOUNDARY-START(8590610561),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 544897,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 675969,
      "h": 8590610561,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590610561)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295643265),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 675969,
      "h": 4295643265,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295643265)
  ],
  "h": 675969
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AEuu.LCCWCM.CommunityWebsiteHostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteHostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsiteHostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(675969)
        
        

        //--TRIMMABLE-BOUNDARY-START(938113)
        $asm.$cls(`$AEuu.LCCWCM.CommunityWebsitePageModelTypeDescriptor`, ($self) => class CommunityWebsitePageModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AEuu.LCCWCM.CommunityWebsitePageModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295905409)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295905409);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AEuu.LCCWCM.CommunityWebsitePageModelTypeDescriptor.GenerateProperties($.$AEuu.LCCWCM.CommunityWebsitePageModel, this, factory);
                    }, $cOujEf ??= {"r":65537,"n":"","d":938113,"h":0,"f":17825794}), 0, "CommunityWebsitePageModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Website.Common\\Models_CommunityWebsitePageModel_LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModelTypeDescriptorBuilder.g.cs", "CommunityWebsitePageModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295905409)
            
            //--TRIMMABLE-BOUNDARY-START(12885840001)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885840001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AEuu.LCCWCM.CommunityWebsitePageModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsitePageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$AEuu.LCCWCM.CommunityWebsitePageModel)).Type);
                        }, $lcMZGk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":938113,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Route"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AEuu.LCCWCM.CommunityWebsitePageModel.$type, $.$discardRef(), "Route", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Route")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Route";
                        $i3.DelaredOn = "LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsitePageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AEuu.LCCWCM.CommunityWebsitePageModel)).Route);
                        }, $cgYTUd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":938113,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsitePageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Route = value.AsReference($.$$.S.String);
                        }, $YpFQBb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":938113,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Data"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AEuu.LCCWCM.CommunityWebsitePageModel.$type, $.$discardRef(), "Data", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Data")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$AEuu.LCCWCM.CommunityWebsiteDataSource, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Data";
                        $i5.DelaredOn = "LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsitePageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$AEuu.LCCWCM.CommunityWebsiteDataSource, ($.$cast(target, $.$AEuu.LCCWCM.CommunityWebsitePageModel)).Data);
                        }, $ntfAJb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":938113,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsitePageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Data = value.AsReference($.$AEuu.LCCWCM.CommunityWebsiteDataSource);
                        }, $suupOf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":938113,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Parent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AEuu.LCCWCM.CommunityWebsitePageModel.$type, $.$discardRef(), "Parent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Parent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$AEuu.LCCWCM.IWebsiteDataSource, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Parent";
                        $i7.DelaredOn = "LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AEuu.LCCWCM.CommunityWebsitePageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$AEuu.LCCWCM.IWebsiteDataSource, ($.$cast(target, $.$AEuu.LCCWCM.CommunityWebsitePageModel)).Parent$1);
                        }, $giTOFf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":938113,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885840001)
            
            //--TRIMMABLE-BOUNDARY-START(17180807297)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180807297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.Website.Common.Models.CommunityWebsiteCategoryModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$AEuu.LCCWCM.CommunityWebsiteCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Route = _target.Route;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Route"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Route, ($v) => _Route = $v, $.$$.S.String)))
                    {
                        _target.Route = _Route;
                    }
                }
                {
                    /*var*/ let _Data = _target.Data;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Data"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$AEuu.LCCWCM.CommunityWebsiteDataSource));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Data, ($v) => _Data = $v, $.$AEuu.LCCWCM.CommunityWebsiteDataSource)))
                    {
                        _target.Data = _Data;
                    }
                }
                {
                    /*var*/ let _Parent = _target.Parent$1;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Parent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$AEuu.LCCWCM.IWebsiteDataSource));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Parent, ($v) => _Parent = $v, $.$AEuu.LCCWCM.IWebsiteDataSource)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180807297)
            
            //--TRIMMABLE-BOUNDARY-START(8590872705)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590872705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$AEuu.LCCWCM.CommunityWebsitePageModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AEuu.LCCWCM.CommunityWebsitePageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCM.CommunityWebsitePageModel)))
                {
                    /*var*/ let result = $.$AEuu.LCCWCM.CommunityWebsitePageModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCM.CommunityWebsitePageModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AEuu.LCCWCM.CommunityWebsitePageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AEuu.LCCWCM.CommunityWebsitePageModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590872705)
            
            static $h = 938113;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AEuu.LCCWCM.CommunityWebsitePageModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885840001),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 938113,
      "h": 12885840001,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885840001),
//--TRIMMABLE-BOUNDARY-START(17180807297),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 807041,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 938113,
      "h": 17180807297,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180807297),
//--TRIMMABLE-BOUNDARY-START(8590872705),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 807041,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 938113,
      "h": 8590872705,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590872705)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295905409),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 938113,
      "h": 4295905409,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295905409)
  ],
  "h": 938113
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AEuu.LCCWCM.CommunityWebsitePageModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Website.Common.Models.CommunityWebsitePageModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Website${separator}Common${separator}Models${separator}CommunityWebsitePageModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(938113)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(20609)
