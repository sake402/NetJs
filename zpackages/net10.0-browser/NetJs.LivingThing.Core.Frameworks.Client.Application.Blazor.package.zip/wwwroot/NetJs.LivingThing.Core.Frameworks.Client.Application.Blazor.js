
//--TRIMMABLE-BOUNDARY-START(33491)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ) {
    "use strict";
    let _;
    let $aDTYcd;
    let $DXKUFk;
    let $bUKeAa;
    let $MJYkOj;
    let $LoBaaf;
    let $lumybb;
    let $UrTUaf;
    let $aOsKOc;
    let $FLXdkg;
    let $WralMh;
    let $SDYMEg;
    let $hxGPBh;
    let $pSrYYe;
    let $ygeyif;
    let $lHxSDb;
    let $RFMEai;
    let $tIlvda;
    let $jyIUEf;
    let $FOxEkf;
    let $wotaOf;
    let $oBwUxd;
    let $wNbyCh;
    let $JAFlHj;
    let $DhLiUf;
    let $SZZsgc;
    let $gafhPb;
    let $ROdnck;
    let $ERxSHg;
    let $zFRwne;
    let $OJfjNh;
    let $QleFwk;
    let $QSVJWj;
    let $gBJLci;
    let $hhZuDa;
    let $cREpbf;
    let $lXtwhd;
    let $aFNhtb;
    let $dWSuGf;
    let $WRCcng;
    let $DZezii;
    let $LkUDpi;
    let $nXHyAh;
    let $ZUtbdf;
    let $cjDZsa;
    let $wnvBkg;
    let $iWiOFd;
    let $SLsHie;
    let $hDLyph;
    let $wtDNVa;
    let $NiBOZi;
    let $JZLXCi;
    let $NyYbdb;
    let $UAzgGk;
    let $HCeIqh;
    let $QlLuek;
    let $RMaqac;
    let $apeyuk;
    let $hxZJbg;
    let $bNpMei;
    let $Dfiihj;
    let $ojmoqd;
    let $FpnkNj;
    let $RIZRhk;
    let $fSPCtj;
    let $LHJnsg;
    let $FEBVJh;
    let $VAMmfd;
    let $HbKlAb;
    let $dLsOjg;
    let $iDNLxk;
    let $ZfMCGk;
    let $zUZytf;
    let $qkgUEh;
    let $ptSQbc;
    let $gQzmwi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", 
    {
  "h": 33491,
  "f": "LivingThing.Core.Frameworks.Client.Application.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.Application.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.Application.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1540819)
        $asm.$cls(`$sZVd.LCFCA.IClientApplicationModel`, ($self) => class IClientApplicationModel
        {
            static $h = 1540819;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1540819
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.IClientApplicationModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}IClientApplicationModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1540819)
        
        

        //--TRIMMABLE-BOUNDARY-START(1475283)
        $asm.$cls(`$sZVd.LCFCA.IClientApplicationHasId`, ($self) => class IClientApplicationHasId
        {
            static $h = 1475283;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4296442579),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886377171,
        "f": 50331905
      },
      "n": "ApplicationId",
      "o": "LCFCA$IClientApplicationHasId$ApplicationId",
      "d": 1475283,
      "h": 4296442579,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296442579)
  ],
  "h": 1475283
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.IClientApplicationHasId`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}IClientApplicationHasId`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1475283)
        
        

        //--TRIMMABLE-BOUNDARY-START(1344211)
        $asm.$cls(`$sZVd.LCFCA.IAppRootEntryProvider`, ($self) => class IAppRootEntryProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296311507)
            /*IEnumerable<string>? */ get LCFCA$IAppRootEntryProvider$Css()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(4296311507)
            
            //--TRIMMABLE-BOUNDARY-START(98785592019)
            /*IEnumerable<string>? */ get LCFCA$IAppRootEntryProvider$Js()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(98785592019)
            
            //--TRIMMABLE-BOUNDARY-START(8591278803)
            /*DefinedTheme */ get LCFCA$IAppRootEntryProvider$DefaultTheme()
            {
                return 1/*DefinedTheme.Light*/;
            }
            //--TRIMMABLE-BOUNDARY-END(8591278803)
            
            //--TRIMMABLE-BOUNDARY-START(103080559315)
            /*ThemePack? */ get LCFCA$IAppRootEntryProvider$Theme()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(103080559315)
            
            //--TRIMMABLE-BOUNDARY-START(17181213395)
            /*string? */ get LCFCA$IAppRootEntryProvider$Font()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(17181213395)
            
            //--TRIMMABLE-BOUNDARY-START(94490624723)
            /*string? */ get LCFCA$IAppRootEntryProvider$GoogleAnalyticsTag()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(94490624723)
            
            //--TRIMMABLE-BOUNDARY-START(107375526611)
            /*string? */ get LCFCA$IAppRootEntryProvider$TwitterAnalyticsTag()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(107375526611)
            
            //--TRIMMABLE-BOUNDARY-START(90195657427)
            /*IComponentRenderMode? */ LCFCA$IAppRootEntryProvider$GetDefaultRenderMode(/*Uri*/ uri)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195657427);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195657427)
            
            static $h = 1344211;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886246099),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951017171,
        "f": 50331905
      },
      "n": "Domains",
      "o": "LCFCA$IAppRootEntryProvider$Domains",
      "d": 1344211,
      "h": 12886246099,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886246099),
//--TRIMMABLE-BOUNDARY-START(4296311507),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771147987,
        "f": 50331777
      },
      "n": "Css",
      "o": "LCFCA$IAppRootEntryProvider$Css",
      "d": 1344211,
      "h": 4296311507,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(4296311507),
//--TRIMMABLE-BOUNDARY-START(98785592019),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720820947,
        "f": 50331777
      },
      "n": "Js",
      "o": "LCFCA$IAppRootEntryProvider$Js",
      "d": 1344211,
      "h": 98785592019,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(98785592019),
//--TRIMMABLE-BOUNDARY-START(8591278803),
    {
      "p": 1858984,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361082579,
        "f": 50331777
      },
      "n": "DefaultTheme",
      "o": "LCFCA$IAppRootEntryProvider$DefaultTheme",
      "d": 1344211,
      "h": 8591278803,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(8591278803),
//--TRIMMABLE-BOUNDARY-START(103080559315),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310755539,
        "f": 50331777
      },
      "n": "Theme",
      "o": "LCFCA$IAppRootEntryProvider$Theme",
      "d": 1344211,
      "h": 103080559315,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(103080559315),
//--TRIMMABLE-BOUNDARY-START(17181213395),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540951763,
        "f": 50331777
      },
      "n": "Font",
      "o": "LCFCA$IAppRootEntryProvider$Font",
      "d": 1344211,
      "h": 17181213395,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(17181213395),
//--TRIMMABLE-BOUNDARY-START(94490624723),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130886355,
        "f": 50331777
      },
      "n": "GoogleAnalyticsTag",
      "o": "LCFCA$IAppRootEntryProvider$GoogleAnalyticsTag",
      "d": 1344211,
      "h": 94490624723,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(94490624723),
//--TRIMMABLE-BOUNDARY-START(107375526611),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900690131,
        "f": 50331777
      },
      "n": "TwitterAnalyticsTag",
      "o": "LCFCA$IAppRootEntryProvider$TwitterAnalyticsTag",
      "d": 1344211,
      "h": 107375526611,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(107375526611)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90195657427),
    {
      "r": 2883699,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        }
      ],
      "n": "GetDefaultRenderMode",
      "o": "LCFCA$IAppRootEntryProvider$GetDefaultRenderMode",
      "d": 1344211,
      "h": 90195657427,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(90195657427)
  ],
  "h": 1344211
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.IApplicationRootEntryProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.IAppRootEntryProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}IAppRootEntryProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1344211)
        
        

        //--TRIMMABLE-BOUNDARY-START(1671891)
        $asm.$cls(`$sZVd.LCFCA.IClientApplicationPage`, ($self) => class IClientApplicationPage
        {
            //--TRIMMABLE-BOUNDARY-START(55836246739)
            /*string? */ get LCFCA$IApplicationProxy$ServiceType()
            {
                return $.$$.S.Object.GetType.call(this.LCFCA$IClientApplicationPage$Service).FullName;
            }
            //--TRIMMABLE-BOUNDARY-END(55836246739)
            
            //--TRIMMABLE-BOUNDARY-START(51541279443)
            /*IEnumerable<IApplicationServiceProxy>? */ get LCFCA$IApplicationProxy$Services()
            {
                return $.$$.N.InterfaceVarianceStubHandler.Create(this.LCFCA$IClientApplicationPage$Services, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService), $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy));
            }
            //--TRIMMABLE-BOUNDARY-END(51541279443)
            
            static $h = 1671891;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64426181331),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181541075,
        "f": 50331905
      },
      "n": "Service",
      "o": "LCFCA$IClientApplicationPage$Service",
      "d": 1671891,
      "h": 64426181331,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(64426181331),
//--TRIMMABLE-BOUNDARY-START(55836246739),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246312147,
        "f": 50331650
      },
      "n": "{1482208}.ServiceType",
      "o": "LCFCA$IApplicationProxy$ServiceType",
      "d": 1671891,
      "h": 55836246739,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55836246739),
//--TRIMMABLE-BOUNDARY-START(68721148627),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771475667,
        "f": 50331905
      },
      "n": "Services",
      "o": "LCFCA$IClientApplicationPage$Services",
      "d": 1671891,
      "h": 68721148627,
      "f": 538968321
    },
//--TRIMMABLE-BOUNDARY-END(68721148627),
//--TRIMMABLE-BOUNDARY-START(51541279443),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656377555,
        "f": 50331650
      },
      "n": "{1482208}.Services",
      "o": "LCFCA$IApplicationProxy$Services",
      "d": 1671891,
      "h": 51541279443,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51541279443),
//--TRIMMABLE-BOUNDARY-START(60131214035),
    {
      "p": $.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplicationPage).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591606483,
        "f": 50331905
      },
      "n": "Pages",
      "o": "LCFCA$IClientApplicationPage$Pages",
      "d": 1671891,
      "h": 60131214035,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(60131214035)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066442963),
    {
      "r": 6881395,
      "n": "GetPage",
      "o": "LCFCA$IClientApplicationPage$GetPage",
      "d": 1671891,
      "h": 30066442963,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30066442963)
  ],
  "h": 1671891
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.IClientApplicationPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}IClientApplicationPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1671891)
        
        

        //--TRIMMABLE-BOUNDARY-START(1409747)
        $asm.$cls(`$sZVd.LCFCA.IClientApplication`, ($self) => class IClientApplication
        {
            //--TRIMMABLE-BOUNDARY-START(25771213523)
            /*ValueTask */ LCFCA$IClientApplication$OnLazyLoaded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771213523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(25771213523)
            
            static $h = 1409747;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4296377043),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886311635,
        "f": 50331905
      },
      "n": "ApplicationViewType",
      "o": "LCFCA$IClientApplication$ApplicationViewType",
      "d": 1409747,
      "h": 4296377043,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296377043),
//--TRIMMABLE-BOUNDARY-START(30066180819),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476246227,
        "f": 50331905
      },
      "n": "SplashScreenViewType",
      "o": "LCFCA$IClientApplication$SplashScreenViewType",
      "d": 1409747,
      "h": 30066180819,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30066180819)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771213523),
    {
      "r": 181338113,
      "n": "OnLazyLoaded",
      "o": "LCFCA$IClientApplication$OnLazyLoaded",
      "d": 1409747,
      "h": 25771213523,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25771213523)
  ],
  "h": 1409747
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.IClientApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}IClientApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1409747)
        
        

        //--TRIMMABLE-BOUNDARY-START(754387)
        $asm.$cls(`$sZVd.LCFCA.BaseApplication<>`, (T) => $asm.$gt(`$sZVd.LCFCA.BaseApplication<>`, [T], ($self) => class BaseApplication$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(111669904083)
            /*string[]?*/ $Domains = null;
            /*string[]? */ get Domains()
            {
                return this.$Domains;
            }
             /*string[]? */ set Domains(value)
            {
                this.$Domains = value;
            }
            //--TRIMMABLE-BOUNDARY-END(111669904083)
            
            //--TRIMMABLE-BOUNDARY-START(420907549395)
            /*string[]?*/ $Paths = null;
            /*string[]? */ get Paths()
            {
                return this.$Paths;
            }
             /*string[]? */ set Paths(value)
            {
                this.$Paths = value;
            }
            //--TRIMMABLE-BOUNDARY-END(420907549395)
            
            //--TRIMMABLE-BOUNDARY-START(90195067603)
            /*Type?*/ $ApplicationViewType = null;
            /*Type? */ get ApplicationViewType()
            {
                return this.$ApplicationViewType;
            }
             /*Type? */ set ApplicationViewType(value)
            {
                this.$ApplicationViewType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(90195067603)
            
            //--TRIMMABLE-BOUNDARY-START(450972320467)
            /*Type?*/ $SplashScreenViewType = null;
            /*Type? */ get SplashScreenViewType()
            {
                return this.$SplashScreenViewType;
            }
             /*Type? */ set SplashScreenViewType(value)
            {
                this.$SplashScreenViewType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(450972320467)
            
            //--TRIMMABLE-BOUNDARY-START(442382385875)
            /*string?*/ $SKU = null;
            /*string? */ get SKU()
            {
                return this.$SKU;
            }
             /*string? */ set SKU(value)
            {
                this.$SKU = value;
            }
            //--TRIMMABLE-BOUNDARY-END(442382385875)
            
            //--TRIMMABLE-BOUNDARY-START(98785002195)
            /*IEnumerable<string>?*/ $Categories = null;
            /*IEnumerable<string>? */ get Categories()
            {
                return this.$Categories;
            }
             /*IEnumerable<string>? */ set Categories(value)
            {
                this.$Categories = value;
            }
            //--TRIMMABLE-BOUNDARY-END(98785002195)
            
            //--TRIMMABLE-BOUNDARY-START(94490034899)
            /*string?*/ $BannerImage = null;
            /*string? */ get BannerImage()
            {
                return this.$BannerImage;
            }
             /*string? */ set BannerImage(value)
            {
                this.$BannerImage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(94490034899)
            
            //--TRIMMABLE-BOUNDARY-START(382252843731)
            /*IEnumerable<string>?*/ $Images = null;
            /*IEnumerable<string>? */ get Images()
            {
                return this.$Images;
            }
             /*IEnumerable<string>? */ set Images(value)
            {
                this.$Images = value;
            }
            //--TRIMMABLE-BOUNDARY-END(382252843731)
            
            //--TRIMMABLE-BOUNDARY-START(386547811027)
            /*DateTime?*/ $LaunchDate = null;
            /*DateTime? */ get LaunchDate()
            {
                return this.$LaunchDate;
            }
             /*DateTime? */ set LaunchDate(value)
            {
                this.$LaunchDate = value;
            }
            //--TRIMMABLE-BOUNDARY-END(386547811027)
            
            //--TRIMMABLE-BOUNDARY-START(446677353171)
            /*int?*/ $Sold = null;
            /*int? */ get Sold()
            {
                return this.$Sold;
            }
             /*int? */ set Sold(value)
            {
                this.$Sold = value;
            }
            //--TRIMMABLE-BOUNDARY-END(446677353171)
            
            //--TRIMMABLE-BOUNDARY-START(399432712915)
            /*Money?*/ $OldCost = null;
            /*Money? */ get OldCost()
            {
                return this.$OldCost;
            }
             /*Money? */ set OldCost(value)
            {
                this.$OldCost = value;
            }
            //--TRIMMABLE-BOUNDARY-END(399432712915)
            
            //--TRIMMABLE-BOUNDARY-START(468152189651)
            /*Money*/ $UnitCost;
            /*Money */ get UnitCost()
            {
                return this.$UnitCost;
            }
             /*Money */ set UnitCost(value)
            {
                this.$UnitCost = value;
            }
            //--TRIMMABLE-BOUNDARY-END(468152189651)
            
            //--TRIMMABLE-BOUNDARY-START(438087418579)
            /*string?*/ $ShortDescription = null;
            /*string? */ get ShortDescription()
            {
                return this.$ShortDescription;
            }
             /*string? */ set ShortDescription(value)
            {
                this.$ShortDescription = value;
            }
            //--TRIMMABLE-BOUNDARY-END(438087418579)
            
            //--TRIMMABLE-BOUNDARY-START(390842778323)
            /*string? */ get Link()
            {
                return "/" + $.$strNN(this.Name);
            }
            //--TRIMMABLE-BOUNDARY-END(390842778323)
            
            //--TRIMMABLE-BOUNDARY-START(429497483987)
            /*IEnumerable<IApplicationSubService>?*/ $Services = null;
            /*IEnumerable<IApplicationSubService>? */ get Services()
            {
                return this.$Services;
            }
             /*IEnumerable<IApplicationSubService>? */ set Services(value)
            {
                this.$Services = value;
            }
            //--TRIMMABLE-BOUNDARY-END(429497483987)
            
            //--TRIMMABLE-BOUNDARY-START(416612582099)
            /*IEnumerable<IClientApplicationPage>?*/ $Pages = null;
            /*IEnumerable<IClientApplicationPage>? */ get Pages()
            {
                return this.$Pages;
            }
             /*IEnumerable<IClientApplicationPage>? */ set Pages(value)
            {
                this.$Pages = value;
            }
            //--TRIMMABLE-BOUNDARY-END(416612582099)
            
            //--TRIMMABLE-BOUNDARY-START(412317614803)
            /*int*/ $Order = 0;
            /*int */ get Order()
            {
                return this.$Order;
            }
             /*int */ set Order(value)
            {
                this.$Order = value;
            }
            //--TRIMMABLE-BOUNDARY-END(412317614803)
            
            //--TRIMMABLE-BOUNDARY-START(459562255059)
            /*ThemePack?*/ $Theme = null;
            /*ThemePack? */ get Theme()
            {
                return this.$Theme;
            }
             /*ThemePack? */ set Theme(value)
            {
                this.$Theme = value;
            }
            //--TRIMMABLE-BOUNDARY-END(459562255059)
            
            //--TRIMMABLE-BOUNDARY-START(115964871379)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(115964871379)
            
            //--TRIMMABLE-BOUNDARY-START(455267287763)
            /*IEnumerable<string>?*/ Tags = null;
            //--TRIMMABLE-BOUNDARY-END(455267287763)
            
            //--TRIMMABLE-BOUNDARY-START(472447156947)
            /*IEnumerable<string>?*/ Videos = null;
            //--TRIMMABLE-BOUNDARY-END(472447156947)
            
            //--TRIMMABLE-BOUNDARY-START(373662909139)
            /*RenderFragment? */ GetPage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662909139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(373662909139)
            
            //--TRIMMABLE-BOUNDARY-START(107374936787)
            /*AuthenticationClientDescriptor? */ get Descriptor()
            {
                return (($.$as(this.Service, $.$GfYa.LCFCA.IAuthenticationClient))?.LCFCA$IAuthenticationClient$Descriptor ?? null) ?? (() =>
                {
                    //new $.$GfYa.LCFCA.AuthenticationClientDescriptor()
                    const $t1 = $.$GfYa.LCFCA.AuthenticationClientDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.ApplicationName = this.Name;
                    $i1.ApplicationIcon = this.Icon.Icon;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(107374936787)
            
            //--TRIMMABLE-BOUNDARY-START(433792451283)
            /*ServiceType */ get ServiceType()
            {
                return 0/*ServiceType.None*/;
            }
            //--TRIMMABLE-BOUNDARY-END(433792451283)
            
            //--TRIMMABLE-BOUNDARY-START(120259838675)
            /*CatalogueFlags */ get Flags()
            {
                return 16/*CatalogueFlags.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(120259838675)
            
            //--TRIMMABLE-BOUNDARY-START(403727680211)
            /*ValueTask<bool> */ OnLoggedIn(/*DecodedAuthenticationTicket*/ ticket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727680211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (($.$as(this.Service, $.$GfYa.LCFCA.IAuthenticationClient))?.LCFCA$IAuthenticationClient$OnLoggedIn(ticket) ?? null) ?? $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, false);
            }
            //--TRIMMABLE-BOUNDARY-END(403727680211)
            
            //--TRIMMABLE-BOUNDARY-START(408022647507)
            /*ValueTask */ OnLoginAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022647507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (($.$as(this.Service, $.$GfYa.LCFCA.IAuthenticationClient))?.LCFCA$IAuthenticationClient$OnLoginAborted() ?? null) ?? $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(408022647507)
            
            //--TRIMMABLE-BOUNDARY-START(12886311635)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IClientApplication.ApplicationViewType.get
            get LCFCA$IClientApplication$ApplicationViewType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296377043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ApplicationViewType;
            }
            //--TRIMMABLE-BOUNDARY-END(12886311635)
            
            //--TRIMMABLE-BOUNDARY-START(21476246227)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IClientApplication.SplashScreenViewType.get
            get LCFCA$IClientApplication$SplashScreenViewType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066180819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SplashScreenViewType;
            }
            //--TRIMMABLE-BOUNDARY-END(21476246227)
            
            //--TRIMMABLE-BOUNDARY-START(17181541075)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IClientApplicationPage.Service.get
            get LCFCA$IClientApplicationPage$Service()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426181331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service;
            }
            //--TRIMMABLE-BOUNDARY-END(17181541075)
            
            //--TRIMMABLE-BOUNDARY-START(25771475667)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IClientApplicationPage.Services.get
            get LCFCA$IClientApplicationPage$Services()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721148627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services;
            }
            //--TRIMMABLE-BOUNDARY-END(25771475667)
            
            //--TRIMMABLE-BOUNDARY-START(8591606483)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IClientApplicationPage.Pages.get
            get LCFCA$IClientApplicationPage$Pages()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131214035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Pages;
            }
            //--TRIMMABLE-BOUNDARY-END(8591606483)
            
            //--TRIMMABLE-BOUNDARY-START(30066442963)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IClientApplicationPage.GetPage()
            LCFCA$IClientApplicationPage$GetPage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066442963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPage(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30066442963)
            
            //--TRIMMABLE-BOUNDARY-START(17181351392)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationProxy.Domains.get
            get LCFCA$IApplicationProxy$Domains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296449504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Domains;
            }
            //--TRIMMABLE-BOUNDARY-END(17181351392)
            
            //--TRIMMABLE-BOUNDARY-START(34361220576)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationProxy.Paths.get
            get LCFCA$IApplicationProxy$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836057056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(34361220576)
            
            //--TRIMMABLE-BOUNDARY-START(25771285984)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationProxy.Features.get
            get LCFCA$IApplicationProxy$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591416800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(25771285984)
            
            //--TRIMMABLE-BOUNDARY-START(8610351446)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOrderedData.Order.get
            get LCFCD$IOrderedData$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12905318742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(8610351446)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //--TRIMMABLE-BOUNDARY-START(8594174912)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IServiceCatalogueModel.ServiceType.get
            get LCFCP$IServiceCatalogueModel$ServiceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889142208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceType;
            }
            //--TRIMMABLE-BOUNDARY-END(8594174912)
            
            //--TRIMMABLE-BOUNDARY-START(150325801920)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.SKU.get
            get LCFCP$ICatalogueModel$SKU()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714428352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SKU;
            }
            //--TRIMMABLE-BOUNDARY-END(150325801920)
            
            //--TRIMMABLE-BOUNDARY-START(64426456000)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Categories.get
            get LCFCP$ICatalogueModel$Categories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181815744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Categories;
            }
            //--TRIMMABLE-BOUNDARY-END(64426456000)
            
            //--TRIMMABLE-BOUNDARY-START(90196259776)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Flags.get
            get LCFCP$ICatalogueModel$Flags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066717632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Flags;
            }
            //--TRIMMABLE-BOUNDARY-END(90196259776)
            
            //--TRIMMABLE-BOUNDARY-START(47246586816)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.BannerImage.get
            get LCFCP$ICatalogueModel$BannerImage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591881152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BannerImage;
            }
            //--TRIMMABLE-BOUNDARY-END(47246586816)
            
            //--TRIMMABLE-BOUNDARY-START(98786194368)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Images.get
            get LCFCP$ICatalogueModel$Images()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225147840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Images;
            }
            //--TRIMMABLE-BOUNDARY-END(98786194368)
            
            //--TRIMMABLE-BOUNDARY-START(107376128960)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.LaunchDate.get
            get LCFCP$ICatalogueModel$LaunchDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520115136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LaunchDate;
            }
            //--TRIMMABLE-BOUNDARY-END(107376128960)
            
            //--TRIMMABLE-BOUNDARY-START(176095605696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.UnitCost.get
            get LCFCP$ICatalogueModel$UnitCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343599330240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnitCost;
            }
            //--TRIMMABLE-BOUNDARY-END(176095605696)
            
            //--TRIMMABLE-BOUNDARY-START(124555998144)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.OldCost.get
            get LCFCP$ICatalogueModel$OldCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317829526464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OldCost;
            }
            //--TRIMMABLE-BOUNDARY-END(124555998144)
            
            //--TRIMMABLE-BOUNDARY-START(115966063552)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Link.get
            get LCFCP$ICatalogueModel$Link()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815082432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Link;
            }
            //--TRIMMABLE-BOUNDARY-END(115966063552)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(12886491522)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.Descriptor.get
            get LCFCA$IAuthenticationClient$Descriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296556930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Descriptor;
            }
            //--TRIMMABLE-BOUNDARY-END(12886491522)
            
            //--TRIMMABLE-BOUNDARY-START(17181458818)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.OnLoggedIn(LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket)
            LCFCA$IAuthenticationClient$OnLoggedIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181458818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnLoggedIn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181458818)
            
            //--TRIMMABLE-BOUNDARY-START(21476426114)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.OnLoginAborted()
            LCFCA$IAuthenticationClient$OnLoginAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476426114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnLoginAborted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476426114)
            
            //--TRIMMABLE-BOUNDARY-START(85900100307)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900100307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(85900100307)
            
            //--TRIMMABLE-BOUNDARY-START(85900100307)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(85900100307)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(386547811027)
                this.$LaunchDate = null;
                //--TRIMMABLE-BOUNDARY-END(386547811027)
                
                //--TRIMMABLE-BOUNDARY-START(399432712915)
                this.$OldCost = null;
                //--TRIMMABLE-BOUNDARY-END(399432712915)
                
                //--TRIMMABLE-BOUNDARY-START(468152189651)
                this.$UnitCost = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(468152189651)
                
            }
            static $H = 754387;
            static $h = 754387;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(395137745619),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 231928988371,
        "h": Number(BigInt(this.$h)|0x3600000000n),
        "f": 50331905
      },
      "n": "Name",
      "d": this.$h,
      "H": 395137745619,
      "h": Number(BigInt(this.$h)|0x5C00000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(395137745619),
//--TRIMMABLE-BOUNDARY-START(377957876435),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "H": 197569250003,
        "h": Number(BigInt(this.$h)|0x2E00000000n),
        "f": 50331905
      },
      "n": "Icon",
      "d": this.$h,
      "H": 377957876435,
      "h": Number(BigInt(this.$h)|0x5800000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(377957876435),
//--TRIMMABLE-BOUNDARY-START(463857222355),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 352188072659,
        "h": Number(BigInt(this.$h)|0x5200000000n),
        "f": 50331905
      },
      "n": "Title",
      "d": this.$h,
      "H": 463857222355,
      "h": Number(BigInt(this.$h)|0x6C00000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(463857222355),
//--TRIMMABLE-BOUNDARY-START(103079969491),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 154619577043,
        "h": Number(BigInt(this.$h)|0x2400000000n),
        "f": 50331905
      },
      "n": "Description",
      "d": this.$h,
      "H": 103079969491,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(103079969491),
//--TRIMMABLE-BOUNDARY-START(111669904083),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 171799446227,
        "h": Number(BigInt(this.$h)|0x2800000000n),
        "f": 50331777
      },
      "n": "Domains",
      "d": this.$h,
      "H": 111669904083,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(111669904083),
//--TRIMMABLE-BOUNDARY-START(420907549395),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 266288726739,
        "h": Number(BigInt(this.$h)|0x3E00000000n),
        "f": 50331777
      },
      "n": "Paths",
      "d": this.$h,
      "H": 420907549395,
      "h": Number(BigInt(this.$h)|0x6200000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(420907549395),
//--TRIMMABLE-BOUNDARY-START(90195067603),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 128849773267,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 50331777
      },
      "n": "ApplicationViewType",
      "d": this.$h,
      "H": 90195067603,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(90195067603),
//--TRIMMABLE-BOUNDARY-START(450972320467),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 326418268883,
        "h": Number(BigInt(this.$h)|0x4C00000000n),
        "f": 50331777
      },
      "n": "SplashScreenViewType",
      "d": this.$h,
      "H": 450972320467,
      "h": Number(BigInt(this.$h)|0x6900000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(450972320467),
//--TRIMMABLE-BOUNDARY-START(425202516691),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "H": 274878661331,
        "h": Number(BigInt(this.$h)|0x4000000000n),
        "f": 50331905
      },
      "n": "Service",
      "d": this.$h,
      "H": 425202516691,
      "h": Number(BigInt(this.$h)|0x6300000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(425202516691),
//--TRIMMABLE-BOUNDARY-START(442382385875),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 309238399699,
        "h": Number(BigInt(this.$h)|0x4800000000n),
        "f": 50331777
      },
      "n": "SKU",
      "d": this.$h,
      "H": 442382385875,
      "h": Number(BigInt(this.$h)|0x6700000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(442382385875),
//--TRIMMABLE-BOUNDARY-START(98785002195),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 146029642451,
        "h": Number(BigInt(this.$h)|0x2200000000n),
        "f": 50331777
      },
      "n": "Categories",
      "d": this.$h,
      "H": 98785002195,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(98785002195),
//--TRIMMABLE-BOUNDARY-START(94490034899),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 137439707859,
        "h": Number(BigInt(this.$h)|0x2000000000n),
        "f": 50331777
      },
      "n": "BannerImage",
      "d": this.$h,
      "H": 94490034899,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(94490034899),
//--TRIMMABLE-BOUNDARY-START(382252843731),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 206159184595,
        "h": Number(BigInt(this.$h)|0x3000000000n),
        "f": 50331777
      },
      "n": "Images",
      "d": this.$h,
      "H": 382252843731,
      "h": Number(BigInt(this.$h)|0x5900000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(382252843731),
//--TRIMMABLE-BOUNDARY-START(386547811027),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 214749119187,
        "h": Number(BigInt(this.$h)|0x3200000000n),
        "f": 50331777
      },
      "n": "LaunchDate",
      "d": this.$h,
      "H": 386547811027,
      "h": Number(BigInt(this.$h)|0x5A00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(386547811027),
//--TRIMMABLE-BOUNDARY-START(446677353171),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 317828334291,
        "h": Number(BigInt(this.$h)|0x4A00000000n),
        "f": 50331777
      },
      "n": "Sold",
      "d": this.$h,
      "H": 446677353171,
      "h": Number(BigInt(this.$h)|0x6800000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(446677353171),
//--TRIMMABLE-BOUNDARY-START(399432712915),
    {
      "p": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 240518922963,
        "h": Number(BigInt(this.$h)|0x3800000000n),
        "f": 50331777
      },
      "n": "OldCost",
      "d": this.$h,
      "H": 399432712915,
      "h": Number(BigInt(this.$h)|0x5D00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(399432712915),
//--TRIMMABLE-BOUNDARY-START(468152189651),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "H": 360778007251,
        "h": Number(BigInt(this.$h)|0x5400000000n),
        "f": 50331777
      },
      "n": "UnitCost",
      "d": this.$h,
      "H": 468152189651,
      "h": Number(BigInt(this.$h)|0x6D00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(468152189651),
//--TRIMMABLE-BOUNDARY-START(438087418579),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 300648465107,
        "h": Number(BigInt(this.$h)|0x4600000000n),
        "f": 50331777
      },
      "n": "ShortDescription",
      "d": this.$h,
      "H": 438087418579,
      "h": Number(BigInt(this.$h)|0x6600000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(438087418579),
//--TRIMMABLE-BOUNDARY-START(390842778323),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 223339053779,
        "h": Number(BigInt(this.$h)|0x3400000000n),
        "f": 50331777
      },
      "n": "Link",
      "d": this.$h,
      "H": 390842778323,
      "h": Number(BigInt(this.$h)|0x5B00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(390842778323),
//--TRIMMABLE-BOUNDARY-START(429497483987),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 283468595923,
        "h": Number(BigInt(this.$h)|0x4200000000n),
        "f": 50331777
      },
      "n": "Services",
      "d": this.$h,
      "H": 429497483987,
      "h": Number(BigInt(this.$h)|0x6400000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(429497483987),
//--TRIMMABLE-BOUNDARY-START(416612582099),
    {
      "p": $.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplicationPage).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 257698792147,
        "h": Number(BigInt(this.$h)|0x3C00000000n),
        "f": 50331777
      },
      "n": "Pages",
      "d": this.$h,
      "H": 416612582099,
      "h": Number(BigInt(this.$h)|0x6100000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(416612582099),
//--TRIMMABLE-BOUNDARY-START(412317614803),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 249108857555,
        "h": Number(BigInt(this.$h)|0x3A00000000n),
        "f": 50331777
      },
      "n": "Order",
      "d": this.$h,
      "H": 412317614803,
      "h": Number(BigInt(this.$h)|0x6000000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(412317614803),
//--TRIMMABLE-BOUNDARY-START(459562255059),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "H": 343598138067,
        "h": Number(BigInt(this.$h)|0x5000000000n),
        "f": 50331777
      },
      "n": "Theme",
      "d": this.$h,
      "H": 459562255059,
      "h": Number(BigInt(this.$h)|0x6B00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(459562255059),
//--TRIMMABLE-BOUNDARY-START(115964871379),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "H": 180389380819,
        "h": Number(BigInt(this.$h)|0x2A00000000n),
        "f": 50331777
      },
      "n": "Features",
      "d": this.$h,
      "H": 115964871379,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(115964871379),
//--TRIMMABLE-BOUNDARY-START(455267287763),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 335008203475,
        "h": Number(BigInt(this.$h)|0x4E00000000n),
        "f": 50331649
      },
      "n": "Tags",
      "d": this.$h,
      "H": 455267287763,
      "h": Number(BigInt(this.$h)|0x6A00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(455267287763),
//--TRIMMABLE-BOUNDARY-START(472447156947),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 369367941843,
        "h": Number(BigInt(this.$h)|0x5600000000n),
        "f": 50331649
      },
      "n": "Videos",
      "d": this.$h,
      "H": 472447156947,
      "h": Number(BigInt(this.$h)|0x6E00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(472447156947),
//--TRIMMABLE-BOUNDARY-START(107374936787),
    {
      "p": 82306,
      "g": {
        "r": 0,
        "d": 0,
        "H": 163209511635,
        "h": Number(BigInt(this.$h)|0x2600000000n),
        "f": 50331777
      },
      "n": "Descriptor",
      "d": this.$h,
      "H": 107374936787,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(107374936787),
//--TRIMMABLE-BOUNDARY-START(433792451283),
    {
      "p": 5682112,
      "g": {
        "r": 0,
        "d": 0,
        "H": 292058530515,
        "h": Number(BigInt(this.$h)|0x4400000000n),
        "f": 50331777
      },
      "n": "ServiceType",
      "d": this.$h,
      "H": 433792451283,
      "h": Number(BigInt(this.$h)|0x6500000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(433792451283),
//--TRIMMABLE-BOUNDARY-START(120259838675),
    {
      "p": 832448,
      "g": {
        "r": 0,
        "d": 0,
        "H": 188979315411,
        "h": Number(BigInt(this.$h)|0x2C00000000n),
        "f": 50331777
      },
      "n": "Flags",
      "d": this.$h,
      "H": 120259838675,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(120259838675)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(373662909139),
    {
      "r": 6881395,
      "n": "GetPage",
      "d": this.$h,
      "H": 373662909139,
      "h": Number(BigInt(this.$h)|0x5700000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(373662909139),
//--TRIMMABLE-BOUNDARY-START(403727680211),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "OnLoggedIn",
      "d": this.$h,
      "H": 403727680211,
      "h": Number(BigInt(this.$h)|0x5E00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(403727680211),
//--TRIMMABLE-BOUNDARY-START(408022647507),
    {
      "r": 181338113,
      "n": "OnLoginAborted",
      "d": this.$h,
      "H": 408022647507,
      "h": Number(BigInt(this.$h)|0x5F00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(408022647507)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(85900100307),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 85900100307,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(85900100307)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 754387,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$GfYa.LCFCA.IAuthenticationClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.BaseApplication<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}BaseApplication$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(754387)
        
        

        //--TRIMMABLE-BOUNDARY-START(688851)
        $asm.$cls(`$sZVd.LCFCA.BaseApplication`, ($self) => class BaseApplication extends $.$sZVd.LCFCA.BaseApplication$$($.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(4295656147)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295656147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295656147)
            
            //--TRIMMABLE-BOUNDARY-START(4295656147)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295656147)
            
            static $h = 688851;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sZVd.LCFCA.BaseApplication$$($.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295656147),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 688851,
      "h": 4295656147,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295656147)
  ],
  "h": 688851
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$GfYa.LCFCA.IAuthenticationClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.BaseApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}BaseApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(688851)
        
        

        //--TRIMMABLE-BOUNDARY-START(1213139)
        $asm.$cls(`$sZVd.LCFCA.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296180435)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296180435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$sZVd.LCFCA.IClientApplicationModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$sZVd.LCFCA.IClientApplicationModelCustomAttributesProvider, $.$sZVd.LCFCA.IClientApplicationModelCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4296180435)
            
            static $h = 1213139;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296180435),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 1213139,
      "h": 4296180435,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296180435)
  ],
  "h": 1213139
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1213139)
        
        

        //--TRIMMABLE-BOUNDARY-START(164563)
        $asm.$cls(`$sZVd.LCFCA._Imports`, ($self) => class _Imports extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590099155)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590099155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590099155)
            
            //--TRIMMABLE-BOUNDARY-START(4295131859)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295131859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295131859)
            
            //--TRIMMABLE-BOUNDARY-START(4295131859)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295131859)
            
            static $h = 164563;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590099155),
    {
      "r": 65537,
      "n": "Execute",
      "d": 164563,
      "h": 8590099155,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590099155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295131859),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 164563,
      "h": 4295131859,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295131859)
  ],
  "h": 164563
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(164563)
        
        

        //--TRIMMABLE-BOUNDARY-START(1606355)
        $asm.$cls(`$sZVd.LCFCA.IClientApplicationModelCustomAttributesProvider`, ($self) => class IClientApplicationModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296573651)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296573651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296573651)
            
            static $h = 1606355;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296573651),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1606355,
      "h": 4296573651,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296573651)
  ],
  "h": 1606355
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.IClientApplicationModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}IClientApplicationModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1606355)
        
        

        //--TRIMMABLE-BOUNDARY-START(1934035)
        $asm.$cls(`$sZVd.LCFCA.WebAssemblyJavascript`, ($self) => class WebAssemblyJavascript extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886835923)
            static /*string */ GetBlazorBootJson()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886835923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sZVd.LCFCA.WebAssemblyJavascript.__signature_GetBlazorBootJson_1310674786 === null)
                {
                    $.$sZVd.LCFCA.WebAssemblyJavascript.__signature_GetBlazorBootJson_1310674786 = $.$srij.SRIJ.JSFunctionBinding.BindJSFunction("globalThis.getBlazorConfig", null, $.$$.S.ReadOnlySpan$$($.$srij.SRIJ.JSMarshalerType).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerType), [$.$srij.SRIJ.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*string*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __retVal_native = __InvokeJSFunction.call(this, $.$clone(____arg_exception_native), $.$clone(____arg_return_native));
                    }
                    __retVal_native.ToManaged$37($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.S.String));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.S.Span$$($.$srij.SRIJ.JSMarshalerArgument).op_Implicit$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null));
                    $.$srij.SRIJ.JSFunctionBinding.InvokeJS($.$sZVd.LCFCA.WebAssemblyJavascript.__signature_GetBlazorBootJson_1310674786, __arguments_buffer);
                    return __arguments_buffer._reference.GetAt(1);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886835923)
            
            //--TRIMMABLE-BOUNDARY-START(4296901331)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetBlazorBootJson_1310674786 = null;
            //--TRIMMABLE-BOUNDARY-END(4296901331)
            
            //--TRIMMABLE-BOUNDARY-START(8591868627)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591868627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591868627)
            
            //--TRIMMABLE-BOUNDARY-START(8591868627)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591868627)
            
            static $h = 1934035;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886835923),
    {
      "r": 1310721,
      "n": "GetBlazorBootJson",
      "d": 1934035,
      "h": 12886835923,
      "f": 16777256,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "globalThis.getBlazorConfig",
              "t": 1310721
            }
          ]
        },
        {
          "t": 71237633,
          "c": 4366204929
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886835923)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296901331),
    {
      "t": 524299,
      "n": "__signature_GetBlazorBootJson_1310674786",
      "d": 1934035,
      "h": 4296901331,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296901331)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591868627),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1934035,
      "h": 8591868627,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591868627)
  ],
  "h": 1934035,
  "a": [
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.WebAssemblyJavascript`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}WebAssemblyJavascript`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1934035)
        
        

        //--TRIMMABLE-BOUNDARY-START(950995)
        $asm.$cls(`$sZVd.LCFCA.ClientApplicationModelCustomAttributesProvider<>`, (TApplication) => $asm.$gt(`$sZVd.LCFCA.ClientApplicationModelCustomAttributesProvider<>`, [TApplication], ($self) => class ClientApplicationModelCustomAttributesProvider$$
        {
            //--TRIMMABLE-BOUNDARY-START(4295918291)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295918291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295918291)
            
            static $H = 950995;
            static $h = 950995;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295918291),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": this.$h,
      "H": 4295918291,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295918291)
  ],
  "s": [
    {
      "h": TApplication?.$h??1572864,
      "n": "TApplication"
    }
  ],
  "r": 1,
  "H": 950995,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.ClientApplicationModelCustomAttributesProvider<${TApplication?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}ClientApplicationModelCustomAttributesProvider$${TApplication?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(950995)
        
        

        //--TRIMMABLE-BOUNDARY-START(1016531)
        $asm.$cls(`$sZVd.LCFCA.ClientApplicationModelCustomAttributesProviderRegistrar1`, ($self) => class ClientApplicationModelCustomAttributesProviderRegistrar1
        {
            //--TRIMMABLE-BOUNDARY-START(4295983827)
            static /*void */ AddGeneratedFastAttributesOfClientApplicationModel(TApplication, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295983827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$sZVd.LCFCA.ClientApplicationModelCustomAttributesProvider$$(TApplication), $.$sZVd.LCFCA.ClientApplicationModelCustomAttributesProvider$$(TApplication).GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295983827)
            
            static $h = 1016531;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295983827),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TApplication"
      ],
      "n": "AddGeneratedFastAttributesOfClientApplicationModel",
      "d": 1016531,
      "h": 4295983827,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4295983827)
  ],
  "h": 1016531
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.ClientApplicationModelCustomAttributesProviderRegistrar1`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}ClientApplicationModelCustomAttributesProviderRegistrar1`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1016531)
        
        

        //--TRIMMABLE-BOUNDARY-START(230099)
        $asm.$cls(`$sZVd.LCFCA._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295197395)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295197395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$sZVd.LCFCA.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295197395)
            
            static $h = 230099;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295197395),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 230099,
      "h": 4295197395,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295197395)
  ],
  "h": 230099
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(230099)
        
        

        //--TRIMMABLE-BOUNDARY-START(819923)
        $asm.$cls(`$sZVd.LCFCA.ClientApplicationExtension`, ($self) => class ClientApplicationExtension
        {
            //--TRIMMABLE-BOUNDARY-START(8590754515)
            static /*void */ AddApplication$1(TApplicationEntryPage, /*this IServiceCollection*/ services, /*string*/ name, /*string*/ title, /*string*/ description, /*IconDescriptor*/ icon, /*ThemePack*/ theme, /*Action<ClientApplicationModel<TApplicationEntryPage>>?*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590754515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$sZVd.LCFCA.ClientApplicationModel$$(TApplicationEntryPage), services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplicationEntryPage)))().$ctor(this,  (/*x*/ x) =>
                {
                    /*var*/ let app = new ($.$sZVd.LCFCA.ClientApplicationModel$$(TApplicationEntryPage))().$ctor$3(name, title, description, $.$clone(icon), theme);
                    configure?.Invoke(app);
                    return app;
                }, $MJYkOj ??= {"r":(TApplicationEntryPage) => $.$sZVd.LCFCA.ClientApplicationModel$$(TApplicationEntryPage).$h,"p":[{"n":"x","p":327718}],"n":"","d":819923,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$sZVd.LCFCA.ClientApplicationModel$$(TApplicationEntryPage), x);
                }, $LoBaaf ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":819923,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590754515)
            
            //--TRIMMABLE-BOUNDARY-START(4295787219)
            static /*void */ AddApplication(TApplicationEntryPage, /*this IServiceCollection*/ services, /*ClientApplicationModel<TApplicationEntryPage>*/ app)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295787219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$sZVd.LCFCA.ClientApplicationModel$$(TApplicationEntryPage), services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplicationEntryPage)))().$ctor(this,  (/*x*/ x) =>
                {
                    return app;
                }, $lumybb ??= {"r":(TApplicationEntryPage) => $.$sZVd.LCFCA.ClientApplicationModel$$(TApplicationEntryPage).$h,"p":[{"n":"x","p":327718}],"n":"","d":819923,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/**/ x) =>
                {
                    return app;
                }, $UrTUaf ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":819923,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295787219)
            
            static $h = 819923;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590754515),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "title",
          "p": 1310721
        },
        {
          "n": "description",
          "p": 1310721
        },
        {
          "n": "icon",
          "p": 46238038
        },
        {
          "n": "theme",
          "p": 9854376
        },
        {
          "n": "configure",
          "p": (TApplicationEntryPage) => $.$$.S.Action$$($.$sZVd.LCFCA.ClientApplicationModel$$(TApplicationEntryPage)).$h,
          "f": 65
        }
      ],
      "g": [
        "TApplicationEntryPage"
      ],
      "n": "AddApplication",
      "o": "@$1",
      "d": 819923,
      "h": 8590754515,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590754515),
//--TRIMMABLE-BOUNDARY-START(4295787219),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "app",
          "p": (TApplicationEntryPage) => $.$sZVd.LCFCA.ClientApplicationModel$$(TApplicationEntryPage).$h
        }
      ],
      "g": [
        "TApplicationEntryPage"
      ],
      "n": "AddApplication",
      "d": 819923,
      "h": 4295787219,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295787219)
  ],
  "h": 819923
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.ClientApplicationExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}ClientApplicationExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(819923)
        
        

        //--TRIMMABLE-BOUNDARY-START(99027)
        $asm.$cls(`$sZVd._LCFCAF.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295066323)
            static /*void */ CreateFormBuilder_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*T*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Client.Components.InputField.InputFieldFeatures*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Common.Client.IViewController*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295066323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Model", $.$box(__arg0, T));
                __builder.AddComponentParameter(__seq1, "FieldFeatures", $.$box(__arg1, $.$hDPm.LCFCCI$2.InputFieldFeatures));
                __builder.AddComponentParameter(__seq2, "Controller", __arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295066323)
            
            static $h = 99027;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295066323),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => T.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 30955178
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 5856680
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateFormBuilder_0",
      "d": 99027,
      "h": 4295066323,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295066323)
  ],
  "h": 99027
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Frameworks.Client.Application.FixedTypographySelector.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}FixedTypographySelector${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(99027)
        
        

        //--TRIMMABLE-BOUNDARY-START(1147603)
        $asm.$cls(`$sZVd.LCFCA.ClientApplicationModelTypeDescriptorBuilder<>`, (TApplication) => $asm.$gt(`$sZVd.LCFCA.ClientApplicationModelTypeDescriptorBuilder<>`, [TApplication], ($self) => class ClientApplicationModelTypeDescriptorBuilder$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591082195)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591082195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication)()
                        const $t1 = $.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication);
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iWiOFd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591082195)
            
            //--TRIMMABLE-BOUNDARY-START(4296114899)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296114899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296114899)
            
            //--TRIMMABLE-BOUNDARY-START(4296114899)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296114899)
            
            static $H = 1147603;
            static $h = 1147603;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591082195),
    {
      "r": 65537,
      "n": "Register",
      "d": this.$h,
      "H": 8591082195,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591082195)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296114899),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296114899,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296114899)
  ],
  "s": [
    {
      "h": TApplication?.$h??1572864,
      "n": "TApplication"
    }
  ],
  "r": 1,
  "H": 1147603,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.ClientApplicationModelTypeDescriptorBuilder<${TApplication?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}ClientApplicationModelTypeDescriptorBuilder$${TApplication?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1147603)
        
        

        //--TRIMMABLE-BOUNDARY-START(1868499)
        $asm.$cls(`$sZVd.LCFCA.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296835795)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296835795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCD$1.SystemTypeDescriptor.RegisterLazyTypeDescriptorRegistrar($.$sZVd.LCFCA.ClientApplicationModel$$().$type, new ($.$$.S.Action$$($.$typeArray($.$$.S.Type)))().$ctor(this,  (/*types*/ types) =>
                {
                    return $.$sZVd.LCFCA.ClientApplicationModelTypeDescriptorBuilder$$().$type.MakeGenericType(types).GetMethod$9("Register", 8/*System.Reflection.BindingFlags.Static*/ | 16/*System.Reflection.BindingFlags.Public*/).Invoke(null, null);
                }, $aOsKOc ??= {"r":65537,"p":[{"n":"types","p":$.$typeArray($.$$.S.Type).$h}],"n":"","d":1868499,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4296835795)
            
            static $h = 1868499;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296835795),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1868499,
      "h": 4296835795,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296835795)
  ],
  "h": 1868499
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1868499)
        
        

        //--TRIMMABLE-BOUNDARY-START(1737427)
        $asm.$cls(`$sZVd.LCFCA.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181606611)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$sZVd.LCFCA.ApplicationLoader.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$sZVd.LCFCA.ApplicationLoader().$ctor$3();
                    }, $bUKeAa ??= {"r":2752627,"n":"","d":1737427,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17181606611)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4296704723)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296704723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296704723)
            
            //--TRIMMABLE-BOUNDARY-START(4296704723)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296704723)
            
            static $h = 1737427;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181606611),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886639315,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 1737427,
      "h": 17181606611,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181606611)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296704723),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1737427,
      "h": 4296704723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296704723)
  ],
  "h": 1737427
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1737427)
        
        

        //--TRIMMABLE-BOUNDARY-START(1802963)
        $asm.$cls(`$sZVd.LCFCA.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591737555)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591737555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sZVd.LCFCA.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFCA.IApplicationModuleProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$hDPm.LCFCA$1.IApplicationRouteResolver, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$hDPm.LCFCA$1.IApplicationRouteRewriter, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$sZVd.LCFCA.ApplicationModulesProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCA$1.IApplicationRouteRewriter))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$sZVd.LCFCA.ApplicationModulesProvider, x);
                }, $FLXdkg ??= {"r":2774698,"p":[{"n":"x","p":327718}],"n":"","d":1802963,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCA$1.IApplicationRouteResolver))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$sZVd.LCFCA.ApplicationModulesProvider, x);
                }, $WralMh ??= {"r":2709162,"p":[{"n":"x","p":327718}],"n":"","d":1802963,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFCA.IApplicationModuleProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$sZVd.LCFCA.ApplicationModulesProvider, x);
                }, $SDYMEg ??= {"r":1345878,"p":[{"n":"x","p":327718}],"n":"","d":1802963,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8591737555)
            
            //--TRIMMABLE-BOUNDARY-START(12886704851)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886704851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_ApplicationModulesProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$sZVd.LCFCA.ApplicationModulesProvider().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$hDPm.LCFCI.IClientUnitOfWork, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientUnitOfWork, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$mac.MAC.NavigationManager, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration), provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration), provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$sZVd.LCFCA.ApplicationModulesProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$sZVd.LCFCA.ServiceRegistrar, Get_ApplicationModulesProvider, $hxGPBh ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ApplicationModulesProvider","d":1802963,"h":0,"f":16777250})));
                /*static object*/  function Get_IApplicationRouteRewriter(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$sZVd.LCFCA.ApplicationModulesProvider, x);
                    }), $pSrYYe ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1802963,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$hDPm.LCFCA$1.IApplicationRouteRewriter.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$sZVd.LCFCA.ServiceRegistrar, Get_IApplicationRouteRewriter, $ygeyif ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IApplicationRouteRewriter","d":1802963,"h":0,"f":16777250})));
                /*static object*/  function Get_IApplicationRouteResolver(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$sZVd.LCFCA.ApplicationModulesProvider, x);
                    }), $lHxSDb ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1802963,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$hDPm.LCFCA$1.IApplicationRouteResolver.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$sZVd.LCFCA.ServiceRegistrar, Get_IApplicationRouteResolver, $RFMEai ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IApplicationRouteResolver","d":1802963,"h":0,"f":16777250})));
                /*static object*/  function Get_IApplicationModuleProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$sZVd.LCFCA.ApplicationModulesProvider, x);
                    }), $tIlvda ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1802963,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$fPer.LCFCA.IApplicationModuleProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$sZVd.LCFCA.ServiceRegistrar, Get_IApplicationModuleProvider, $jyIUEf ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IApplicationModuleProvider","d":1802963,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12886704851)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sZVd.LCFCA.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296770259)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296770259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296770259)
            
            //--TRIMMABLE-BOUNDARY-START(4296770259)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296770259)
            
            static $h = 1802963;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591737555),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1802963,
      "h": 8591737555,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591737555),
//--TRIMMABLE-BOUNDARY-START(12886704851),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 1802963,
      "h": 12886704851,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886704851)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296770259),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1802963,
      "h": 4296770259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296770259)
  ],
  "h": 1802963
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1802963)
        
        

        //--TRIMMABLE-BOUNDARY-START(623315)
        $asm.$cls(`$sZVd.LCFCA.ApplicationModulesProvider`, ($self) => class ApplicationModulesProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(128849642195)
            /*IClientUnitOfWork*/ unitOfWork = null;
            //--TRIMMABLE-BOUNDARY-END(128849642195)
            
            //--TRIMMABLE-BOUNDARY-START(98784871123)
            /*IOptions<ApplicationRuntimeConfiguration>*/ runtimeConfig = null;
            //--TRIMMABLE-BOUNDARY-END(98784871123)
            
            //--TRIMMABLE-BOUNDARY-START(94489903827)
            /*NavigationManager*/ navigation = null;
            //--TRIMMABLE-BOUNDARY-END(94489903827)
            
            //--TRIMMABLE-BOUNDARY-START(25770427091)
            /*ApplicationsDescriptor?*/ Descriptor = null;
            //--TRIMMABLE-BOUNDARY-END(25770427091)
            
            //--TRIMMABLE-BOUNDARY-START(90194936531)
            /*IEnumerable<IClientApplication>? */ get LoadedApplications()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835198163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureAppsLoaded();
                return this.apps;
            }
            //--TRIMMABLE-BOUNDARY-END(90194936531)
            
            //--TRIMMABLE-BOUNDARY-START(8590557907)
            $ctor$1(/*IClientUnitOfWork*/ unitOfWork, /*NavigationManager*/ navigation, /*IOptions<ApplicationRuntimeConfiguration>*/ runtimeConfig)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590557907);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.unitOfWork = unitOfWork;
                    this.navigation = navigation;
                    this.runtimeConfig = runtimeConfig;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590557907)
            
            //--TRIMMABLE-BOUNDARY-START(17180492499)
            /*IRemoteModuleLoader?*/ assemblyLoader = null;
            //--TRIMMABLE-BOUNDARY-END(17180492499)
            
            //--TRIMMABLE-BOUNDARY-START(12885525203)
            /*IEnumerable<IClientApplication>?*/ apps = null;
            //--TRIMMABLE-BOUNDARY-END(12885525203)
            
            //--TRIMMABLE-BOUNDARY-START(64425132755)
            /*List<string>*/ lazyLoadedAssemblies = null;
            //--TRIMMABLE-BOUNDARY-END(64425132755)
            
            //--TRIMMABLE-BOUNDARY-START(30065394387)
            /*void */ EnsureAppsLoaded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065394387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.apps ??= $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplication), this.unitOfWork.LCFCI$IClientUnitOfWork$ServiceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(30065394387)
            
            //--TRIMMABLE-BOUNDARY-START(73015067347)
            /*ValueTask *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015067347);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.EnsureAppsLoaded();
                    ($t1 = this.EnsureDescriptorLoaded(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73015067347)
            
            //--TRIMMABLE-BOUNDARY-START(34360361683)
            /*ValueTask *//*async*/  EnsureDescriptorLoaded()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360361683);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.Descriptor !== null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    ($t2 = $.$fPer.LCFC.LockExtensions.LockAsync(this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t3, $r3;
                            this.Descriptor ??= (($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$yleQ.LCFCA.IApplicationRemoteService, $.$yleQ.LCFCA.ApplicationsDescriptor, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$yleQ.LCFCA.IApplicationRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$yleQ.LCFCA.ApplicationsDescriptor)))().$ctor(this,  (/*s*/ s) =>
                            {
                                return s.LCFCA$IApplicationRemoteService$GetApplicationsDescriptor(this.unitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$Runtime.Type, false, null);
                            }, $gafhPb ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$yleQ.LCFCA.ApplicationsDescriptor)).$h,"p":[{"n":"s","p":1547744}],"n":"","d":623315,"h":0,"f":17825794}), null, (() =>
                            {
                                //new $.$uvJL.LCFCR.RemoteProxyExecutionContext()
                                const $t4 = $.$uvJL.LCFCR.RemoteProxyExecutionContext;
                                const $i4 = new $t4();
                                $i4.$ctor$1();
                                $i4.RunInBackground = false;
                                $i4.DataCache = this.unitOfWork.LCFCI$IClientUnitOfWork$Cache;
                                $i4.CacheKey = `Descriptor/${$.$strNN($.$$.S.Enum.ToStringT($.$fPer.LCFC.RuntimeType, $.$$.S.UInt32, this.unitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$Runtime.Type))}/${$.$strNN(this.unitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$Runtime.Version)}`;
                                return $i4;
                            })()), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))));
                        });
                    }, $ROdnck ??= {"r":178454529,"n":"","d":623315,"h":0,"f":17829890}), null, true), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360361683)
            
            //--TRIMMABLE-BOUNDARY-START(111669773011)
            /*(Type? PageType, IApplicationServiceProxy? Descriptor) */ TryGetPageType(/*Router?*/ router, /*Uri*/ uri, /*RouteData?*/ defaultRoute)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669773011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureAppsLoaded();
                {
                    {
                        /*var*/ let descriptor = (this.Descriptor?.GetServiceAssemblyModule(uri, null, null) ?? null);
                        if ((descriptor?.LCFCA$IApplicationServiceProxy$UIEntryType ?? null) !== null)
                        {
                            $.$scsl.S.Console.WriteLine$17(`Routing ${$.$strNN(uri.ToString())} request to ${$.$strNN(descriptor.LCFC$INamed$Name)}`);
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationAssembly>?*/ let __ca1__;
                            /*var*/ let newPageType = $.$$.S.Type.GetType$8($.$strNN(descriptor.LCFCA$IApplicationServiceProxy$UIEntryType) + ", " + $.$strNN(((__ca1__ = descriptor.LCFCA$IApplicationServiceProxy$MainAssemblies) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCA.ApplicationAssembly, __ca1__) : null).ToString()));
                            if (newPageType === null)
                            {
                                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationAssembly>?*/ let __ca2__;
                                $.$scsl.S.Console.WriteLine$17(`Routing unable to find type ${$.$strNN($.$strNN(descriptor.LCFCA$IApplicationServiceProxy$UIEntryType) + ", " + $.$strNN(((__ca2__ = descriptor.LCFCA$IApplicationServiceProxy$MainAssemblies) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCA.ApplicationAssembly, __ca2__) : null).ToString()))}`);
                            }
                            if (newPageType !== null && $.$$.SR.Assembly.op_Equality((defaultRoute?.PageType.Assembly ?? null), newPageType.Assembly))
                            {
                                return new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$yleQ.LCFCA.IApplicationServiceProxy))().$ctor$3(null, null);
                            }
                            return new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$yleQ.LCFCA.IApplicationServiceProxy))().$ctor$3(newPageType, descriptor);
                        }
                    }
                }
                return new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$yleQ.LCFCA.IApplicationServiceProxy))().$ctor$3(null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(111669773011)
            
            //--TRIMMABLE-BOUNDARY-START(60130165459)
            /*RenderFragment? */ GetRouteView(/*Router?*/ router, /*Uri*/ uri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130165459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
                $.$scsl.S.Console.WriteLine$17("GetRewrite...");
                /*var*/ let type = this.TryGetPageType(router, uri, null);
                if (type.Item1 !== null)
                {
                    return $.$hDPm.LCFC.FragmentView.From(type.Item1, null, null, null);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(60130165459)
            
            //--TRIMMABLE-BOUNDARY-START(124554674899)
            /*bool */ TryRewrite(/*Router?*/ router, /*Uri*/ uri, /*ref RouteData*/ route)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554674899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
                if (this.unitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$Runtime.Type === 1/*RuntimeType.WebServer*/ || this.unitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$Runtime.Type === 3/*RuntimeType.Wasm*/)
                {
                    {
                        /*var*/ let type = this.TryGetPageType(router, uri, route.$v);
                        if (type.Item1 !== null)
                        {
                            if (type.Item2 !== null)
                            {
                                route.$v = new $.$mac.MAC.RouteData().$ctor$1($.$sZVd.LCFCA.ApplicationLoader.$type, (() =>
                                {
                                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                                    const $t5 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                                    const $i5 = new $t5();
                                    $i5.$ctor$1();
                                    $i5.set_Item("Descriptor", $.$fPer.LCFCO.OneOf$$$($.$yleQ.LCFCA.IApplicationProxy, $.$yleQ.LCFCA.IApplicationServiceProxy).FromT1(type.Item2));
                                    return $i5;
                                })());
                            }
                            else 
                            {
                                route.$v = new $.$mac.MAC.RouteData().$ctor$1(type.Item1, new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1());
                            }
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(124554674899)
            
            //--TRIMMABLE-BOUNDARY-START(81605001939)
            /*ValueTask<IEnumerable<Assembly>?> *//*async*/  LoadAssemblies(/*params string[]*/ assemblyNames)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)), $.$$.SCG.IEnumerable$$($.$$.SR.Assembly), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605001939);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ((this.Descriptor?.LazyLoadingEnabled ?? null) ?? false)
                    {
                        this.assemblyLoader ??= $.$mxdi.MED.ServiceProviderServiceExtensions.GetService($.$fPer.LCFCS$3.IRemoteModuleLoader, this.unitOfWork.LCFCI$IClientUnitOfWork$ServiceProvider);
                        if (this.assemblyLoader !== null)
                        {
                            let $t6, $r6;
                            /*var*/ let assemblies = ($t6 = this.assemblyLoader.LCFCS$3$IRemoteModuleLoader$LoadModulesAndRegisterServices(assemblyNames), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                            return $.$$.N.AsyncResolver.Result($asnycContext, assemblies);
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Empty($.$$.SR.Assembly));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(81605001939)
            
            //--TRIMMABLE-BOUNDARY-START(68720100051)
            /*string*/ static LazyLoadedAssembliesKey = null;
            //--TRIMMABLE-BOUNDARY-END(68720100051)
            
            //--TRIMMABLE-BOUNDARY-START(21475459795)
            /*BlazorBootJsonModel?*/ bootJson = null;
            //--TRIMMABLE-BOUNDARY-END(21475459795)
            
            //--TRIMMABLE-BOUNDARY-START(85899969235)
            /*ValueTask<IEnumerable<Assembly>?> *//*async*/  LoadAssembliesInternal(/*IEnumerable<IApplicationServiceProxy>*/ descriptors)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)), $.$$.SCG.IEnumerable$$($.$$.SR.Assembly), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899969235);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (((this.Descriptor?.LazyLoadingEnabled ?? null) ?? false) && $.$sl.SL.Enumerable.Any($.$yleQ.LCFCA.IApplicationServiceProxy, descriptors, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.S.Boolean))().$ctor(this,  (/*descriptor*/ descriptor) =>
                    {
                        return !$.$fPer.LCFCA.ApplicationAssembly.LazyLoadedApplications.Contains(descriptor.LCFCA$IApplicationServiceProxy$Id);
                    }, $ERxSHg ??= {"r":262145,"p":[{"n":"descriptor","p":2203104}],"n":"","d":623315,"h":0,"f":17825794})))
                    {
                        this.assemblyLoader ??= $.$mxdi.MED.ServiceProviderServiceExtensions.GetService($.$fPer.LCFCS$3.IRemoteModuleLoader, this.unitOfWork.LCFCI$IClientUnitOfWork$ServiceProvider);
                        if (this.assemblyLoader !== null)
                        {
                            let $t7, $r7;
                            $.$scsl.S.Console.WriteLine$17(`Lazy Loading ${$.$strNN($.$$.S.String.Join$5(", ", $.$sl.SL.Enumerable.Select$1($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.S.String, descriptors, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.S.String))().$ctor(this,  (/*descriptor*/ descriptor) =>
                            {
                                return descriptor.LCFC$INamed$Name ?? "";
                            }, $zFRwne ??= {"r":1310721,"p":[{"n":"descriptor","p":2203104}],"n":"","d":623315,"h":0,"f":17825794}))))} module...`);
                            /*var*/ let ass = $.$sl.SL.Enumerable.Where($.$fPer.LCFCA.ApplicationAssembly, $.$sl.SL.Enumerable.Concat($.$fPer.LCFCA.ApplicationAssembly, ($.$sl.SL.Enumerable.SelectMany$2($.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFCA.ApplicationAssembly, descriptors, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly)))().$ctor(this,  (/*descriptor*/ descriptor) =>
                            {
                                return descriptor.LCFCA$IApplicationServiceProxy$MainAssemblies ?? $.$sl.SL.Enumerable.Empty($.$fPer.LCFCA.ApplicationAssembly);
                            }, $OJfjNh ??= {"r":$.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly).$h,"p":[{"n":"descriptor","p":2203104}],"n":"","d":623315,"h":0,"f":17825794}))), $.$sl.SL.Enumerable.SelectMany$2($.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFCA.ApplicationAssembly, descriptors, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly)))().$ctor(this,  (/*descriptor*/ descriptor) =>
                            {
                                return descriptor.LCFCA$IApplicationServiceProxy$Dependencies ?? $.$sl.SL.Enumerable.Empty($.$fPer.LCFCA.ApplicationAssembly);
                            }, $QleFwk ??= {"r":$.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly).$h,"p":[{"n":"descriptor","p":2203104}],"n":"","d":623315,"h":0,"f":17825794}))), new ($.$$.S.Func$$$($.$fPer.LCFCA.ApplicationAssembly, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                            {
                                return a.Lazy;
                            }, $QSVJWj ??= {"r":262145,"p":[{"n":"a","p":690518}],"n":"","d":623315,"h":0,"f":17825794}));
                            /*string*/ let extension = ".js";
                            /*var*/ let assemblyNames = $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCA.ApplicationAssembly, $.$$.S.String, ass, new ($.$$.S.Func$$$($.$fPer.LCFCA.ApplicationAssembly, $.$$.S.String))().$ctor(this,  (/*a*/ a) =>
                            {
                                return $.$strNN(a.Name) + $.$strNN(extension);
                            }, $gBJLci ??= {"r":1310721,"p":[{"n":"a","p":690518}],"n":"","d":623315,"h":0,"f":17825794}));
                            this.bootJson ??= $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$fPer.LCFC.BlazorBootJsonModel, globalThis.getBlazorConfig(), false, "LoadAssembliesInternal", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor\\ApplicationModulesProvider.cs", "LoadAssembliesInternal", 259);
                            /*LivingThing.Core.Frameworks.Common.BlazorBootResources*/ let __ca3__;
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.BlazorAssembly>?*/ let __ca4__;
                            /*var*/ let lazyLoad = ((__ca3__ = this.bootJson.Resources) !== null ? ((__ca4__ = __ca3__.LazyAssembly) !== null ? $.$sl.SL.Enumerable.Select$1($.$fPer.LCFC.BlazorAssembly, $.$$.S.String, $.$sl.SL.Enumerable.Where($.$fPer.LCFC.BlazorAssembly, __ca4__, new ($.$$.S.Func$$$($.$fPer.LCFC.BlazorAssembly, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                            {
                                return $.$sl.SL.Enumerable.Contains$1($.$$.S.String, assemblyNames, a.VirtualPath);
                            }, $hhZuDa ??= {"r":262145,"p":[{"n":"a","p":2984278}],"n":"","d":623315,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$fPer.LCFC.BlazorAssembly, $.$$.S.String))().$ctor(this,  (/*a*/ a) =>
                            {
                                return a.VirtualPath;
                            }, $cREpbf ??= {"r":1310721,"p":[{"n":"a","p":2984278}],"n":"","d":623315,"h":0,"f":17825794})) : null) : null);
                            if (this.bootJson.Resources === null)
                            {
                                lazyLoad = assemblyNames;
                            }
                            /*var*/ let assemblies = lazyLoad !== null ? ($t7 = this.assemblyLoader.LCFCS$3$IRemoteModuleLoader$LoadModulesAndRegisterServices(lazyLoad), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7))) : $.$sl.SL.Enumerable.Empty($.$$.SR.Assembly);
                            let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                            while ($en8.SC$1$IEnumerator$MoveNext())
                            {
                                let d = $en8.SCG$IEnumerator$$$Current;
                                {
                                    if (!$.$fPer.LCFCA.ApplicationAssembly.LazyLoadedApplications.Contains(d.LCFCA$IApplicationServiceProxy$Id))
                                    {
                                        $.$fPer.LCFCA.ApplicationAssembly.LazyLoadedApplications.Add(d.LCFCA$IApplicationServiceProxy$Id);
                                    }
                                }
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, assemblies);
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Select$1($.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32), $.$$.SR.Assembly, $.$sl.SL.Enumerable.OrderBy$1($.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32), $.$$.S.Int32, $.$sl.SL.Enumerable.Where($.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32), $.$sl.SL.Enumerable.Select$1($.$$.SR.Assembly, $.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32), $.$$.S.AppDomain.CurrentDomain.GetAssemblies(), new ($.$$.S.Func$$$($.$$.SR.Assembly, $.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32)))().$ctor(this,  (/*a*/ a) =>
                    {
                        /*var*/ let assemblyName = a.GetName().Name;
                        if ($.$sl.SL.Enumerable.Any($.$yleQ.LCFCA.IApplicationServiceProxy, descriptors, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.S.Boolean))().$ctor(this,  (/*descriptor*/ descriptor) =>
                        {
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationAssembly>?*/ let __ca5__;
                            return $.$fPer.LCFCA.ApplicationAssembly.op_Implicit((__ca5__ = descriptor.LCFCA$IApplicationServiceProxy$MainAssemblies) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCA.ApplicationAssembly, __ca5__) : null) === assemblyName;
                        }, $lXtwhd ??= {"r":262145,"p":[{"n":"descriptor","p":2203104}],"n":"","d":623315,"h":0,"f":17825794})))
                        {
                            return new ($.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32))().$ctor$3(a, true, 1);
                        }
                        if ($.$sl.SL.Enumerable.Any($.$yleQ.LCFCA.IApplicationServiceProxy, descriptors, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.S.Boolean))().$ctor(this,  (/*descriptor*/ descriptor) =>
                        {
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationAssembly>?*/ let __ca6__;
                            return ((__ca6__ = descriptor.LCFCA$IApplicationServiceProxy$Dependencies) !== null ? $.$sl.SL.Enumerable.Any($.$fPer.LCFCA.ApplicationAssembly, __ca6__, new ($.$$.S.Func$$$($.$fPer.LCFCA.ApplicationAssembly, $.$$.S.Boolean))().$ctor(this,  (/*dep*/ dep) =>
                            {
                                return $.$fPer.LCFCA.ApplicationAssembly.op_Implicit(dep) === assemblyName;
                            }, $aFNhtb ??= {"r":262145,"p":[{"n":"dep","p":690518}],"n":"","d":623315,"h":0,"f":17825794})) : false);
                        }, $dWSuGf ??= {"r":262145,"p":[{"n":"descriptor","p":2203104}],"n":"","d":623315,"h":0,"f":17825794})))
                        {
                            return new ($.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32))().$ctor$3(a, true, 2);
                        }
                        return new ($.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32))().$ctor$3(a, false, 0);
                    }, $WRCcng ??= {"r":$.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32).$h,"p":[{"n":"a","p":107020289}],"n":"","d":623315,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32), $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                    {
                        return a.Item2;
                    }, $DZezii ??= {"r":262145,"p":[{"n":"a","p":$.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32).$h}],"n":"","d":623315,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32), $.$$.S.Int32))().$ctor(this,  (/*a*/ a) =>
                    {
                        return a.Item3;
                    }, $LkUDpi ??= {"r":655361,"p":[{"n":"a","p":$.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32).$h}],"n":"","d":623315,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32), $.$$.SR.Assembly))().$ctor(this,  (/*a*/ a) =>
                    {
                        return a.Item1;
                    }, $nXHyAh ??= {"r":107020289,"p":[{"n":"a","p":$.$$.S.ValueTuple$$$$($.$$.SR.Assembly, $.$$.S.Boolean, $.$$.S.Int32).$h}],"n":"","d":623315,"h":0,"f":17825794})));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85899969235)
            
            //--TRIMMABLE-BOUNDARY-START(120259707603)
            /*ValueTask<IEnumerable<Assembly>?> *//*async*/  TryLoadModulesByRoutePath(/*string*/ routePath)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)), $.$$.SCG.IEnumerable$$($.$$.SR.Assembly), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259707603);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.unitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$Runtime.IsWasm)
                    {
                        let $t9, $r9;
                        if ($.$$.S.String.IsNullOrEmpty(routePath) || routePath === "/")
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, null);
                        }
                        ($t9 = this.EnsureDescriptorLoaded(), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        /*var*/ let uri = new $.$spu.S.Uri().$ctor$5(this.navigation.Uri);
                        /*var*/ let pathPrefix = !$.$$.S.String.IsNullOrEmpty(routePath) ? $.$$.System.Array.$ReadT1.call($.$$.S.String.Split$6.call(routePath, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1([ /*/*/ 47, /*\\*/ 92, /*?*/ 63 ])), 0) : null;
                        /*var*/ let descriptor = (this.Descriptor?.GetServiceAssemblyModule(uri, null, pathPrefix) ?? null);
                        if (descriptor !== null)
                        {
                            let $t10, $r10;
                            /*var*/ let assemblies = ($t10 = this.LoadAssembliesInternal($.$$.SRC.RuntimeHelpers.CreateArray($.$yleQ.LCFCA.IApplicationServiceProxy.$type, [ descriptor ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                            /*System.Collections.Generic.IEnumerable<System.Reflection.Assembly>?*/ let __ca7__;
                            /*var*/ let appAssembly = ((__ca7__ = assemblies) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$$.SR.Assembly, __ca7__) : null);
                            if ($.$$.SR.Assembly.op_Inequality(appAssembly, null))
                            {
                                /*var*/ let app = this.FindApp(descriptor, appAssembly);
                                if (app !== null)
                                {
                                    let $t11, $r11;
                                    $.$scsl.S.Console.WriteLine$17(`Notifiying app ${$.$strNN(app.LCFC$INamed$Name)} of lazy loading...`);
                                    ($t11 = app.LCFCA$IClientApplication$OnLazyLoaded(), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                                }
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, assemblies);
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(120259707603)
            
            //--TRIMMABLE-BOUNDARY-START(115964740307)
            /*ValueTask<IEnumerable<Assembly>?> *//*async*/  TryLoadModulesByName(/*IEnumerable<string>*/ ids)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)), $.$$.SCG.IEnumerable$$($.$$.SR.Assembly), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964740307);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.unitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$Runtime.Type === 3/*RuntimeType.Wasm*/)
                    {
                        let $t12, $r12;
                        ($t12 = this.EnsureDescriptorLoaded(), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                        /*LivingThing.Core.Frameworks.Common.Application.ApplicationsDescriptor?*/ let __ca8__;
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor>?*/ let __ca9__;
                        /*var*/ let descriptors = ((__ca8__ = this.Descriptor) !== null ? ((__ca9__ = __ca8__.Applications) !== null ? $.$sl.SL.Enumerable.Where($.$yleQ.LCFCA.ApplicationDescriptor, __ca9__, new ($.$$.S.Func$$$($.$yleQ.LCFCA.ApplicationDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*app*/ app) =>
                        {
                            return $.$sl.SL.Enumerable.Contains$1($.$$.S.String, ids, app.Id);
                        }, $ZUtbdf ??= {"r":262145,"p":[{"n":"app","p":368096}],"n":"","d":623315,"h":0,"f":17825794})) : null) : null);
                        if (descriptors !== null)
                        {
                            let $t13, $r13;
                            return $.$$.N.AsyncResolver.Result($asnycContext, ($t13 = this.LoadAssembliesInternal($.$$.N.InterfaceVarianceStubHandler.Create(descriptors, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor), $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy))), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13))));
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(115964740307)
            
            //--TRIMMABLE-BOUNDARY-START(38655328979)
            /*IClientApplication? */ FindApp(/*IApplicationServiceProxy*/ descriptor, /*Assembly*/ appAssembly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655328979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.S.Console.WriteLine$17(`App Assembly is ${$.$strNN(appAssembly.GetName().Name)}! Finding ${$.$strNN(descriptor.LCFCA$IApplicationServiceProxy$Type)} in it.`);
                /*var*/ let appType = $.$sl.SL.Enumerable.FirstOrDefault$1($.$$.S.Type, appAssembly.GetTypes(), new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.FullName === descriptor.LCFCA$IApplicationServiceProxy$Type;
                }, $cjDZsa ??= {"r":262145,"p":[{"n":"t","p":188547073}],"n":"","d":623315,"h":0,"f":17825794}));
                if (appType === null)
                {
                    return null;
                }
                /*var*/ let app = $.$as(this.unitOfWork.LCFCI$IClientUnitOfWork$ServiceProvider.S$IServiceProvider$GetService(appType), $.$sZVd.LCFCA.IClientApplication);
                if (app === null)
                {
                    return null;
                }
                let lapps;
                if ($.$is(this.apps, $.$$.SCG.List$$($.$sZVd.LCFCA.IClientApplication), { set $v($v){ lapps = $v; } }))
                {
                    lapps.Add(app);
                }
                else 
                {
                    this.apps = $.$sl.SL.Enumerable.ToList($.$sZVd.LCFCA.IClientApplication, $.$sl.SL.Enumerable.Concat($.$sZVd.LCFCA.IClientApplication, this.apps, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sZVd.LCFCA.IClientApplication), [app], null, null)));
                }
                return app;
            }
            //--TRIMMABLE-BOUNDARY-END(38655328979)
            
            //--TRIMMABLE-BOUNDARY-START(77310034643)
            /*ValueTask<IClientApplication> *//*async*/  LoadApplication(/*ApplicationDescriptor*/ descriptor)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$sZVd.LCFCA.IClientApplication), $.$sZVd.LCFCA.IClientApplication, async ($asnycContext) => 
                {
                    let $t14, $r14;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310034643);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$scsl.S.Console.WriteLine$17(`Loading ${$.$strNN(descriptor.Name)} module...`);
                    this.EnsureAppsLoaded();
                    /*var*/ let app = $.$sl.SL.Enumerable.SingleOrDefault$1($.$sZVd.LCFCA.IClientApplication, this.apps, new ($.$$.S.Func$$$($.$sZVd.LCFCA.IClientApplication, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                    {
                        return $.$$.S.Object.GetType.call(a).FullName === descriptor.Type;
                    }, $wnvBkg ??= {"r":262145,"p":[{"n":"a","p":1409747}],"n":"","d":623315,"h":0,"f":17825794}));
                    if (app !== null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, app);
                    }
                    /*var*/ let appAssembly = $.$sl.SL.Enumerable.First$1($.$$.SR.Assembly, (($t14 = this.LoadAssembliesInternal($.$$.SRC.RuntimeHelpers.CreateArray($.$yleQ.LCFCA.ApplicationDescriptor.$type, [ descriptor ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)))));
                    const $t15 = () => descriptor.MainAssemblies;
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$firstOf(this.FindApp(descriptor, appAssembly), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`Cannot create app from ${$.$strNN($.$ifnn($t15, ($t) => $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCA.ApplicationAssembly, $t).Name))}`) }));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77310034643)
            
            //--TRIMMABLE-BOUNDARY-START(8591280470)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationModuleProvider.TryLoadModulesByRoutePath(string)
            LCFCA$IApplicationModuleProvider$TryLoadModulesByRoutePath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591280470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryLoadModulesByRoutePath(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591280470)
            
            //--TRIMMABLE-BOUNDARY-START(4296313174)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationModuleProvider.TryLoadModulesByName(System.Collections.Generic.IEnumerable<string>)
            LCFCA$IApplicationModuleProvider$TryLoadModulesByName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296313174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryLoadModulesByName(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296313174)
            
            //--TRIMMABLE-BOUNDARY-START(4297741994)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.App.IApplicationRouteRewriter.TryRewrite(Microsoft.AspNetCore.Components.Routing.Router?, System.Uri, ref Microsoft.AspNetCore.Components.RouteData)
            LCFCA$1$IApplicationRouteRewriter$TryRewrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297741994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryRewrite(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297741994)
            
            //--TRIMMABLE-BOUNDARY-START(4297676458)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.App.IApplicationRouteResolver.GetRouteView(Microsoft.AspNetCore.Components.Routing.Router?, System.Uri)
            LCFCA$1$IApplicationRouteResolver$GetRouteView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297676458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetRouteView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297676458)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64425132755)
                this.lazyLoadedAssemblies = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(64425132755)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(68720100051)
                    this.LazyLoadedAssembliesKey = "LazyLoadedAssemblies";
                    //--TRIMMABLE-BOUNDARY-END(68720100051)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 623315;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770427091),
    {
      "p": 630240,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245263571,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374805715,
        "f": 83886082
      },
      "n": "Descriptor",
      "d": 623315,
      "h": 25770427091,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770427091),
//--TRIMMABLE-BOUNDARY-START(90194936531),
    {
      "p": $.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplication).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835198163,
        "f": 50331649
      },
      "n": "LoadedApplications",
      "d": 623315,
      "h": 90194936531,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194936531)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065394387),
    {
      "r": 65537,
      "n": "EnsureAppsLoaded",
      "d": 623315,
      "h": 30065394387,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065394387),
//--TRIMMABLE-BOUNDARY-START(73015067347),
    {
      "r": 181338113,
      "n": "Load",
      "d": 623315,
      "h": 73015067347,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(73015067347),
//--TRIMMABLE-BOUNDARY-START(34360361683),
    {
      "r": 181338113,
      "n": "EnsureDescriptorLoaded",
      "d": 623315,
      "h": 34360361683,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(34360361683),
//--TRIMMABLE-BOUNDARY-START(111669773011),
    {
      "r": $.$$.S.ValueTuple$$$($.$$.S.Type, $.$yleQ.LCFCA.IApplicationServiceProxy).$h,
      "p": [
        {
          "n": "router",
          "p": 11337843
        },
        {
          "n": "uri",
          "p": 1703938
        },
        {
          "n": "defaultRoute",
          "p": 9961587,
          "f": 65
        }
      ],
      "n": "TryGetPageType",
      "d": 623315,
      "h": 111669773011,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(111669773011),
//--TRIMMABLE-BOUNDARY-START(60130165459),
    {
      "r": 6881395,
      "p": [
        {
          "n": "router",
          "p": 11337843
        },
        {
          "n": "uri",
          "p": 1703938
        }
      ],
      "n": "GetRouteView",
      "d": 623315,
      "h": 60130165459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130165459),
//--TRIMMABLE-BOUNDARY-START(124554674899),
    {
      "r": 262145,
      "p": [
        {
          "n": "router",
          "p": 11337843
        },
        {
          "n": "uri",
          "p": 1703938
        },
        {
          "n": "route",
          "p": 9961587,
          "f": 4
        }
      ],
      "n": "TryRewrite",
      "d": 623315,
      "h": 124554674899,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124554674899),
//--TRIMMABLE-BOUNDARY-START(81605001939),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)).$h,
      "p": [
        {
          "n": "assemblyNames",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "LoadAssemblies",
      "d": 623315,
      "h": 81605001939,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(81605001939),
//--TRIMMABLE-BOUNDARY-START(85899969235),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy).$h
        }
      ],
      "n": "LoadAssembliesInternal",
      "d": 623315,
      "h": 85899969235,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(85899969235),
//--TRIMMABLE-BOUNDARY-START(120259707603),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)).$h,
      "p": [
        {
          "n": "routePath",
          "p": 1310721
        }
      ],
      "n": "TryLoadModulesByRoutePath",
      "d": 623315,
      "h": 120259707603,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(120259707603),
//--TRIMMABLE-BOUNDARY-START(115964740307),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)).$h,
      "p": [
        {
          "n": "ids",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "TryLoadModulesByName",
      "d": 623315,
      "h": 115964740307,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(115964740307),
//--TRIMMABLE-BOUNDARY-START(38655328979),
    {
      "r": 1409747,
      "p": [
        {
          "n": "descriptor",
          "p": 2203104
        },
        {
          "n": "appAssembly",
          "p": 107020289
        }
      ],
      "n": "FindApp",
      "d": 623315,
      "h": 38655328979,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655328979),
//--TRIMMABLE-BOUNDARY-START(77310034643),
    {
      "r": $.$$.STT.ValueTask$$($.$sZVd.LCFCA.IClientApplication).$h,
      "p": [
        {
          "n": "descriptor",
          "p": 368096
        }
      ],
      "n": "LoadApplication",
      "d": 623315,
      "h": 77310034643,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(77310034643)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(128849642195),
    {
      "t": 63657642,
      "n": "unitOfWork",
      "d": 623315,
      "h": 128849642195,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(128849642195),
//--TRIMMABLE-BOUNDARY-START(98784871123),
    {
      "t": $.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration).$h,
      "n": "runtimeConfig",
      "d": 623315,
      "h": 98784871123,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98784871123),
//--TRIMMABLE-BOUNDARY-START(94489903827),
    {
      "t": 4980851,
      "n": "navigation",
      "d": 623315,
      "h": 94489903827,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(94489903827),
//--TRIMMABLE-BOUNDARY-START(17180492499),
    {
      "t": 61901142,
      "n": "assemblyLoader",
      "d": 623315,
      "h": 17180492499,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180492499),
//--TRIMMABLE-BOUNDARY-START(12885525203),
    {
      "t": $.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplication).$h,
      "n": "apps",
      "d": 623315,
      "h": 12885525203,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885525203),
//--TRIMMABLE-BOUNDARY-START(64425132755),
    {
      "t": $.$$.SCG.List$$($.$$.S.String).$h,
      "n": "lazyLoadedAssemblies",
      "d": 623315,
      "h": 64425132755,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425132755),
//--TRIMMABLE-BOUNDARY-START(68720100051),
    {
      "t": 1310721,
      "n": "LazyLoadedAssembliesKey",
      "d": 623315,
      "h": 68720100051,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68720100051),
//--TRIMMABLE-BOUNDARY-START(21475459795),
    {
      "t": 3246422,
      "n": "bootJson",
      "d": 623315,
      "h": 21475459795,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475459795)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590557907),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        },
        {
          "n": "navigation",
          "p": 4980851
        },
        {
          "n": "runtimeConfig",
          "p": $.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 623315,
      "h": 8590557907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590557907)
  ],
  "h": 623315
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA.IApplicationModuleProvider, $.$hDPm.LCFCA$1.IApplicationRouteRewriter, $.$hDPm.LCFCA$1.IApplicationRouteResolver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.ApplicationModulesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}ApplicationModulesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(623315)
        
        

        //--TRIMMABLE-BOUNDARY-START(1999571)
        $asm.$cls(`$sZVd.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296966867)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296966867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296966867)
            
            //--TRIMMABLE-BOUNDARY-START(4296966867)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296966867)
            
            static $h = 1999571;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296966867),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1999571,
      "h": 4296966867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296966867)
  ],
  "h": 1999571
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1999571)
        
        

        //--TRIMMABLE-BOUNDARY-START(2065107)
        $asm.$cls(`$sZVd.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297032403)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297032403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297032403)
            
            //--TRIMMABLE-BOUNDARY-START(4297032403)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297032403)
            
            static $h = 2065107;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297032403),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2065107,
      "h": 4297032403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297032403)
  ],
  "h": 2065107,
  "a": [
    {
      "t": 1999571,
      "c": 4296966867
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2065107)
        
        

        //--TRIMMABLE-BOUNDARY-START(426707)
        $asm.$cls(`$sZVd.LCFCA.ApplicationBaseService<>`, (TUserPreference) => $asm.$gt(`$sZVd.LCFCA.ApplicationBaseService<>`, [TUserPreference], ($self) => class ApplicationBaseService$$ extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(17180295891)
            $ctor$3(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180295891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.UnitOfWork = unitOfWork;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180295891)
            
            //--TRIMMABLE-BOUNDARY-START(98784674515)
            /*ReactiveObservable<string>*/ ShareUrl = null;
            //--TRIMMABLE-BOUNDARY-END(98784674515)
            
            //--TRIMMABLE-BOUNDARY-START(103079641811)
            /*IClientUnitOfWork*/ UnitOfWork = null;
            //--TRIMMABLE-BOUNDARY-END(103079641811)
            
            //--TRIMMABLE-BOUNDARY-START(25770230483)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(25770230483)
            
            //--TRIMMABLE-BOUNDARY-START(115964543699)
            /*Type */ get UserPreferenceType()
            {
                return TUserPreference.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(115964543699)
            
            //--TRIMMABLE-BOUNDARY-START(111669576403)
            /*TUserPreference?*/ UserPreference = null;
            //--TRIMMABLE-BOUNDARY-END(111669576403)
            
            //--TRIMMABLE-BOUNDARY-START(73014870739)
            /*ValueTask<ApplicationBaseUserPreference?> *//*async*/  GetUserPreference()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.ApplicationBaseUserPreference, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014870739);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (TUserPreference.$type.IsAbstract$1)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, null);
                    }
                    if (this.UserPreference !== null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, this.UserPreference);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = $.$fPer.LCFCS$5.LocalStorageExtension.GetItem(TUserPreference, this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage, this, TUserPreference.$type.FullName), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73014870739)
            
            //--TRIMMABLE-BOUNDARY-START(21475263187)
            /*ReactiveObservable<bool>*/ awaitUserPreference = null;
            //--TRIMMABLE-BOUNDARY-END(21475263187)
            
            //--TRIMMABLE-BOUNDARY-START(107374609107)
            /*ValueTask *//*async*/  UpdateUserPreference()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374609107);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let pref = this.UserPreference;
                    if (pref !== null)
                    {
                        let $t2, $r2;
                        ($t2 = this.SaveUserPreference(pref), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107374609107)
            
            //--TRIMMABLE-BOUNDARY-START(85899772627)
            /*ValueTask *//*async*/  SaveUserPreference(/*TUserPreference*/ preference)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899772627);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = $.$fPer.LCFCS$5.LocalStorageExtension.SetItem(TUserPreference, this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage, this, TUserPreference.$type.FullName, preference), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    this.UserPreference = preference;
                    this.awaitUserPreference.OnNext(true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85899772627)
            
            //--TRIMMABLE-BOUNDARY-START(81604805331)
            /*ValueTask */ ResetUserPreference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604805331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCS$5.LocalStorageExtension.RemoveItem(TUserPreference, this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage, this, TUserPreference.$type.FullName);
            }
            //--TRIMMABLE-BOUNDARY-END(81604805331)
            
            //--TRIMMABLE-BOUNDARY-START(77309838035)
            /*ValueTask *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309838035);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!TUserPreference.$type.IsAbstract$1)
                    {
                        let $t4, $r4;
                        /*var*/ let preference = ($t4 = $.$fPer.LCFCS$5.LocalStorageExtension.GetItem(TUserPreference, this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage, this, TUserPreference.$type.FullName), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        if (preference === null)
                        {
                            let $t5, $r5;
                            ($t5 = this.awaitUserPreference.AwaitAsync(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        }
                        else 
                        {
                            this.UserPreference = preference;
                        }
                    }
                    ($t6 = super.Load(), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77309838035)
            
            //--TRIMMABLE-BOUNDARY-START(12886711776)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationService.Features.get
            get LCFCA$IApplicationService$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296777184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(12886711776)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(98784674515)
                this.ShareUrl = new ($.$fPer.LCFCR.ReactiveObservable$$($.$$.S.String))().$ctor$2();
                //--TRIMMABLE-BOUNDARY-END(98784674515)
                
                //--TRIMMABLE-BOUNDARY-START(21475263187)
                this.awaitUserPreference = new ($.$fPer.LCFCR.ReactiveObservable$$($.$$.S.Boolean))().$ctor$2();
                //--TRIMMABLE-BOUNDARY-END(21475263187)
                
            }
            static $H = 426707;
            static $h = 426707;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98784674515),
    {
      "p": $.$fPer.LCFCR.ReactiveObservable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950099667,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "ShareUrl",
      "d": this.$h,
      "H": 98784674515,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784674515),
//--TRIMMABLE-BOUNDARY-START(103079641811),
    {
      "p": 63657642,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51540034259,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "UnitOfWork",
      "d": this.$h,
      "H": 103079641811,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079641811),
//--TRIMMABLE-BOUNDARY-START(25770230483),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360165075,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331777
      },
      "n": "Features",
      "d": this.$h,
      "H": 25770230483,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(25770230483),
//--TRIMMABLE-BOUNDARY-START(115964543699),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68719903443,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "UserPreferenceType",
      "d": this.$h,
      "H": 115964543699,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964543699),
//--TRIMMABLE-BOUNDARY-START(111669576403),
    {
      "p": TUserPreference?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60129968851,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 94489707219,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 83886082
      },
      "n": "UserPreference",
      "d": this.$h,
      "H": 111669576403,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669576403)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73014870739),
    {
      "r": $.$$.STT.ValueTask$$($.$yleQ.LCFCA.ApplicationBaseUserPreference).$h,
      "n": "GetUserPreference",
      "d": this.$h,
      "H": 73014870739,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(73014870739),
//--TRIMMABLE-BOUNDARY-START(107374609107),
    {
      "r": 181338113,
      "n": "UpdateUserPreference",
      "d": this.$h,
      "H": 107374609107,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(107374609107),
//--TRIMMABLE-BOUNDARY-START(85899772627),
    {
      "r": 181338113,
      "p": [
        {
          "n": "preference",
          "p": TUserPreference?.$h??1572864
        }
      ],
      "n": "SaveUserPreference",
      "d": this.$h,
      "H": 85899772627,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(85899772627),
//--TRIMMABLE-BOUNDARY-START(81604805331),
    {
      "r": 181338113,
      "n": "ResetUserPreference",
      "d": this.$h,
      "H": 81604805331,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604805331),
//--TRIMMABLE-BOUNDARY-START(77309838035),
    {
      "r": 181338113,
      "n": "Load",
      "d": this.$h,
      "H": 77309838035,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(77309838035)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475263187),
    {
      "t": $.$fPer.LCFCR.ReactiveObservable$$($.$$.S.Boolean).$h,
      "n": "awaitUserPreference",
      "d": this.$h,
      "H": 21475263187,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475263187)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180295891),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 17180295891,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180295891)
  ],
  "s": [
    {
      "h": TUserPreference?.$h??1572864,
      "n": "TUserPreference",
      "c": [105952
      ]
    }
  ],
  "r": 1,
  "H": 426707,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.ApplicationBaseService<${TUserPreference?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}ApplicationBaseService$${TUserPreference?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(426707)
        
        

        //--TRIMMABLE-BOUNDARY-START(492243)
        $asm.$cls(`$sZVd.LCFCA.ApplicationLoader`, ($self) => class ApplicationLoader extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(128849511123)
            /*string */ get OptimizedComponentName()
            {
                return "applicationloader";
            }
            //--TRIMMABLE-BOUNDARY-END(128849511123)
            
            //--TRIMMABLE-BOUNDARY-START(176094151379)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094151379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Descriptor":
                    this.Descriptor = $.$cast(parameter.Value, $.$fPer.LCFCO.OneOf$$$($.$yleQ.LCFCA.IApplicationProxy, $.$yleQ.LCFCA.IApplicationServiceProxy));
                    return true;
                    case "ApplyTheme":
                    this.ApplyTheme = $.$cast(parameter.Value, $.$$.S.Boolean);
                    return true;
                    case "ApplicationParameter":
                    this.ApplicationParameter = $.$cast(parameter.Value, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(176094151379)
            
            //--TRIMMABLE-BOUNDARY-START(111669641939)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669641939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.HeaderAccessor = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCH.PageHeaderAccessor, serviceProvider);
                this.ModuleLoader = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$sZVd.LCFCA.ApplicationModulesProvider, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(111669641939)
            
            //--TRIMMABLE-BOUNDARY-START(42950165203)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950165203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent(1, this.application.LCFCA$IClientApplication$ApplicationViewType);
                __builder.AddMultipleAttributes(2, this.ApplicationParameter);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(42950165203)
            
            //--TRIMMABLE-BOUNDARY-START(124554543827)
            /*RenderFragment? */ OnInitializingView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554543827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.application.LCFCA$IClientApplication$SplashScreenViewType !== null)
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder*/ __builder) =>
                    {
                        __builder.OpenComponent(1, this.application.LCFCA$IClientApplication$SplashScreenViewType);
                        __builder.AddAttribute$4(2, "Application", this.Descriptor.Match($.$yleQ.LCFCA.IApplicationProxy, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationProxy, $.$yleQ.LCFCA.IApplicationProxy))().$ctor(this,  (/**/ appProxy) =>
                        {
                            return appProxy;
                        }, $FOxEkf ??= {"r":1482208,"p":[{"n":"appProxy","p":1482208}],"n":"","d":492243,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$yleQ.LCFCA.IApplicationProxy))().$ctor(this,  (/*des*/ des) =>
                        {
                            return des.LCFCA$IApplicationServiceProxy$Application;
                        }, $wotaOf ??= {"r":1482208,"p":[{"n":"des","p":2203104}],"n":"","d":492243,"h":0,"f":17825794})));
                        __builder.AddMultipleAttributes(3, this.ApplicationParameter);
                        __builder.CloseComponent();
                    }, $oBwUxd ??= {"r":65537,"p":[{"n":"__builder","p":7536755}],"n":"","d":492243,"h":0,"f":17825794});
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(124554543827)
            
            //--TRIMMABLE-BOUNDARY-START(51540099795)
            /*RenderFragment? */ ErrorView(/*Exception*/ error, /*Func<Task>?*/ retry, /*Action?*/ cancel, /*ManagedComponentFeatures?*/ errorHandling)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540099795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*RenderFragment?*/ let splash = this.OnInitializingView();
                /*var*/ let overlay = super.ErrorView(error, retry, cancel, errorHandling);
                return $.$hDPm.LCFC.FragmentView.Join(null, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mac.MAC.RenderFragment), [ splash, overlay ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(51540099795)
            
            //--TRIMMABLE-BOUNDARY-START(107374674643)
            /*PageHeaderAccessor*/ HeaderAccessor = null;
            //--TRIMMABLE-BOUNDARY-END(107374674643)
            
            //--TRIMMABLE-BOUNDARY-START(47245132499)
            /*OneOf<IApplicationProxy, IApplicationServiceProxy>*/ Descriptor;
            //--TRIMMABLE-BOUNDARY-END(47245132499)
            
            //--TRIMMABLE-BOUNDARY-START(38655197907)
            /*bool*/ ApplyTheme = false;
            //--TRIMMABLE-BOUNDARY-END(38655197907)
            
            //--TRIMMABLE-BOUNDARY-START(34360230611)
            /*Dictionary<string, object>?*/ ApplicationParameter = null;
            //--TRIMMABLE-BOUNDARY-END(34360230611)
            
            //--TRIMMABLE-BOUNDARY-START(115964609235)
            /*ApplicationModulesProvider*/ ModuleLoader = null;
            //--TRIMMABLE-BOUNDARY-END(115964609235)
            
            //--TRIMMABLE-BOUNDARY-START(30065263315)
            /*IClientApplication?*/ application = null;
            //--TRIMMABLE-BOUNDARY-END(30065263315)
            
            //--TRIMMABLE-BOUNDARY-START(120259576531)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259576531);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let des = this.Descriptor.Match($.$yleQ.LCFCA.IApplicationServiceProxy, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationProxy, $.$yleQ.LCFCA.IApplicationServiceProxy))().$ctor(this,  (/*px*/ px) =>
                    {
                        return null;
                    }, $wNbyCh ??= {"r":2203104,"p":[{"n":"px","p":1482208}],"n":"","d":492243,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$yleQ.LCFCA.IApplicationServiceProxy))().$ctor(this,  (/*des*/ des) =>
                    {
                        return des;
                    }, $JAFlHj ??= {"r":2203104,"p":[{"n":"des","p":2203104}],"n":"","d":492243,"h":0,"f":17825794}));
                    /*var*/ let app = this.Descriptor.Match($.$yleQ.LCFCA.IApplicationProxy, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationProxy, $.$yleQ.LCFCA.IApplicationProxy))().$ctor(this,  (/*appProxy*/ appProxy) =>
                    {
                        return appProxy;
                    }, $DhLiUf ??= {"r":1482208,"p":[{"n":"appProxy","p":1482208}],"n":"","d":492243,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$yleQ.LCFCA.IApplicationProxy))().$ctor(this,  (/*des*/ des) =>
                    {
                        return des.LCFCA$IApplicationServiceProxy$Application;
                    }, $SZZsgc ??= {"r":1482208,"p":[{"n":"des","p":2203104}],"n":"","d":492243,"h":0,"f":17825794}));
                    if (this.application === null)
                    {
                        let $t2, $r2;
                        this.application = $.$as(app, $.$sZVd.LCFCA.IClientApplication) ?? ($t2 = this.ModuleLoader.LoadApplication($.$firstOf($.$cast(des, $.$yleQ.LCFCA.ApplicationDescriptor), () => { throw new $.$$.S.InvalidOperationException().$ctor$12("Descriptor not provided") })), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        this.HeaderAccessor.SetOpenGraphProvider$1((() =>
                        {
                            //new $.$fPer.LCFCD.OpenGraphDataProvider()
                            const $t3 = $.$fPer.LCFCD.OpenGraphDataProvider;
                            const $i3 = new $t3();
                            $i3.$ctor$1();
                            $i3.OpenGraphTitle = this.application.LCFC$IDisplayable$Title;
                            $i3.OpenGraphDescription = this.application.LCFC$IDescribable$Description;
                            $i3.OpenGraphPath = this.application.LCFC$INamed$Name;
                            $i3.OpenGraphType = 2/*OpenGraphType.Website*/;
                            $i3.OpenGraphImage = this.ResolvePath$1((($.$as(this.application, $.$fPer.LCFCD.IOpenGraphDataProvider))?.LCFCD$IOpenGraphDataProvider$OpenGraphImage ?? null) ?? "img/icon.jpg", $.$$.S.Object.GetType.call(this.application).Assembly, false);
                            return $i3;
                        })(), $.$vWqU.LCFCC.ThemePack.op_Implicit(this.application.LCFCC$IThemable$Theme));
                        if (this.ApplyTheme)
                        {
                            let $t4, $r4;
                            let $t6, $r6;
                            /*var*/ let theme = ($t4 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Theme.LCFCC$IThemeAccessor$GetTheme(), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                            /*var*/ let _theme = (() =>
                            {
                                //new $.$vWqU.LCFCC.ThemeColors()
                                const $t5 = $.$vWqU.LCFCC.ThemeColors;
                                const $i5 = new $t5();
                                $i5.$ctor$1();
                                $i5.PrimaryBackgroundColor = this.application.LCFCC$IThemable$Theme.Primary.BackgroundColor;
                                $i5.PrimaryForegroundColor = this.application.LCFCC$IThemable$Theme.Primary.ForegroundColor;
                                $i5.SecondaryBackgroundColor = this.application.LCFCC$IThemable$Theme.Secondary.BackgroundColor;
                                $i5.SecondaryForegroundColor = this.application.LCFCC$IThemable$Theme.Secondary.ForegroundColor;
                                $i5.TertiaryBackgroundColor = this.application.LCFCC$IThemable$Theme.Tertiatary.BackgroundColor;
                                $i5.TertiaryForegroundColor = this.application.LCFCC$IThemable$Theme.Tertiatary.ForegroundColor;
                                $i5.WarningBackgroundColor = this.application.LCFCC$IThemable$Theme.Warning.BackgroundColor;
                                $i5.WarningForegroundColor = this.application.LCFCC$IThemable$Theme.Warning.ForegroundColor;
                                $i5.ErrorBackgroundColor = this.application.LCFCC$IThemable$Theme.Error.BackgroundColor;
                                $i5.ErrorForegroundColor = this.application.LCFCC$IThemable$Theme.Error.ForegroundColor;
                                $i5.FatalBackgroundColor = this.application.LCFCC$IThemable$Theme.Fatal.BackgroundColor;
                                $i5.FatalForegroundColor = this.application.LCFCC$IThemable$Theme.Fatal.ForegroundColor;
                                $i5.MessageBackgroundColor = this.application.LCFCC$IThemable$Theme.Message.BackgroundColor;
                                $i5.MessageForegroundColor = this.application.LCFCC$IThemable$Theme.Message.ForegroundColor;
                                $i5.InfoBackgroundColor = this.application.LCFCC$IThemable$Theme.Info.BackgroundColor;
                                $i5.InfoForegroundColor = this.application.LCFCC$IThemable$Theme.Info.ForegroundColor;
                                return $i5;
                            })();
                            ($t6 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Theme.LCFCC$IThemeAccessor$SetTheme(_theme), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        }
                    }
                    try
                    {
                        let $t7, $r7;
                        ($t7 = this.application.LCFCA$IClientApplicationPage$Service.LCFCC$ILoadableViewModel$Load(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    }
                    catch($e)
                    {
                    }
                    ($t8 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(120259576531)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(25770296019)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770296019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770296019)
            
            //--TRIMMABLE-BOUNDARY-START(25770296019)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25770296019)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(107374674643)
                this.HeaderAccessor = null;
                //--TRIMMABLE-BOUNDARY-END(107374674643)
                
                //--TRIMMABLE-BOUNDARY-START(47245132499)
                this.Descriptor = $.$default($.$fPer.LCFCO.OneOf$$$($.$yleQ.LCFCA.IApplicationProxy, $.$yleQ.LCFCA.IApplicationServiceProxy));
                //--TRIMMABLE-BOUNDARY-END(47245132499)
                
                //--TRIMMABLE-BOUNDARY-START(38655197907)
                this.ApplyTheme = true;
                //--TRIMMABLE-BOUNDARY-END(38655197907)
                
                //--TRIMMABLE-BOUNDARY-START(115964609235)
                this.ModuleLoader = null;
                //--TRIMMABLE-BOUNDARY-END(115964609235)
                
            }
            static $h = 492243;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(128849511123),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079707347,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 492243,
      "h": 128849511123,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128849511123),
//--TRIMMABLE-BOUNDARY-START(107374674643),
    {
      "p": 61888170,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899838163,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209249491,
        "f": 83886081
      },
      "n": "HeaderAccessor",
      "d": 492243,
      "h": 107374674643,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107374674643),
//--TRIMMABLE-BOUNDARY-START(47245132499),
    {
      "p": $.$fPer.LCFCO.OneOf$$$($.$yleQ.LCFCA.IApplicationProxy, $.$yleQ.LCFCA.IApplicationServiceProxy).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309903571,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619314899,
        "f": 83886081
      },
      "n": "Descriptor",
      "d": 492243,
      "h": 47245132499,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245132499),
//--TRIMMABLE-BOUNDARY-START(38655197907),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719968979,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029380307,
        "f": 83886081
      },
      "n": "ApplyTheme",
      "d": 492243,
      "h": 38655197907,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655197907),
//--TRIMMABLE-BOUNDARY-START(34360230611),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130034387,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439445715,
        "f": 83886081
      },
      "n": "ApplicationParameter",
      "d": 492243,
      "h": 34360230611,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360230611),
//--TRIMMABLE-BOUNDARY-START(115964609235),
    {
      "p": 623315,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489772755,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799184083,
        "f": 83886088
      },
      "n": "ModuleLoader",
      "d": 492243,
      "h": 115964609235,
      "f": 2097160,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115964609235)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(176094151379),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 492243,
      "h": 176094151379,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094151379),
//--TRIMMABLE-BOUNDARY-START(111669641939),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 492243,
      "h": 111669641939,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669641939),
//--TRIMMABLE-BOUNDARY-START(42950165203),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 492243,
      "h": 42950165203,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(42950165203),
//--TRIMMABLE-BOUNDARY-START(124554543827),
    {
      "r": 6881395,
      "n": "OnInitializingView",
      "d": 492243,
      "h": 124554543827,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124554543827),
//--TRIMMABLE-BOUNDARY-START(51540099795),
    {
      "r": 6881395,
      "p": [
        {
          "n": "error",
          "p": 80805889
        },
        {
          "n": "retry",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h
        },
        {
          "n": "cancel",
          "p": 43122689
        },
        {
          "n": "errorHandling",
          "p": $.$typeNullable($.$hDPm.LCFCC$1.ManagedComponentFeatures).$h,
          "f": 65
        }
      ],
      "n": "ErrorView",
      "d": 492243,
      "h": 51540099795,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540099795),
//--TRIMMABLE-BOUNDARY-START(120259576531),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 492243,
      "h": 120259576531,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(120259576531)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065263315),
    {
      "t": 1409747,
      "n": "application",
      "d": 492243,
      "h": 30065263315,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065263315)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770296019),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 492243,
      "h": 25770296019,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770296019)
  ],
  "h": 492243
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCC$1.IManagedBaseComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.ApplicationLoader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}ApplicationLoader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(492243)
        
        

        //--TRIMMABLE-BOUNDARY-START(1278675)
        $asm.$cls(`$sZVd.LCFCA.FixedTypographySelector<>`, (TApp) => $asm.$gt(`$sZVd.LCFCA.FixedTypographySelector<>`, [TApp], ($self) => class FixedTypographySelector$$ extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(81605657299)
            /*string */ get OptimizedComponentName()
            {
                return "fixedtypographyselector";
            }
            //--TRIMMABLE-BOUNDARY-END(81605657299)
            
            //--TRIMMABLE-BOUNDARY-START(73015722707)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015722707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IClientRootService$$(TApp), serviceProvider);
                this.ThemeAccessor = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IThemeAccessor, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(73015722707)
            
            //--TRIMMABLE-BOUNDARY-START(85900624595)
            /*IClientRootService<TApp>*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(85900624595)
            
            //--TRIMMABLE-BOUNDARY-START(128850297555)
            /*IThemeAccessor*/ ThemeAccessor = null;
            //--TRIMMABLE-BOUNDARY-END(128850297555)
            
            //--TRIMMABLE-BOUNDARY-START(77310690003)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310690003);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77310690003)
            
            //--TRIMMABLE-BOUNDARY-START(17181147859)
            /*Task *//*async*/  Apply()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181147859);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Theme.LCFCC$IThemeAccessor$SetTheme$1(this.Service.LCFCC$IClientRootService$Preferences.Theme), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Theme.LCFCC$IThemeAccessor$SetFontSize(this.Service.LCFCC$IClientRootService$Preferences.FontSize), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    /*var*/ let _font = this.Service.LCFCC$IClientRootService$Preferences.Font;
                    /*var*/ let font = _font !== null ? $.$fPer.LCFCD.FontDescriptor.Get(_font) : new $.$fPer.LCFCD.FontDescriptor();
                    if (font.Name !== null)
                    {
                        let $t4, $r4;
                        ($t4 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Theme.LCFCC$IThemeAccessor$SetFont($.$clone(font), null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                    else 
                    {
                        let $t5, $r5;
                        ($t5 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Theme.LCFCC$IThemeAccessor$ResetFont(null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17181147859)
            
            //--TRIMMABLE-BOUNDARY-START(124555330259)
            /*ValueTask *//*async*/  SetTheme(/*DefinedTheme*/ theme)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124555330259);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = this.ThemeAccessor.LCFCC$IThemeAccessor$SetTheme$1(theme), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    if (this.Service.LCFCC$IClientRootService$Preferences !== null)
                    {
                        let $t7, $r7;
                        this.Service.LCFCC$IClientRootService$Preferences.Theme = theme;
                        ($t7 = this.Service.LCFCC$IClientRootService$SavePreferences(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(124555330259)
            
            //--TRIMMABLE-BOUNDARY-START(115965395667)
            /*ValueTask *//*async*/  SetFont(/*string*/ font)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965395667);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t8 = this.ThemeAccessor.LCFCC$IThemeAccessor$SetFont($.$fPer.LCFCD.FontDescriptor.Get(font), null), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    if (this.Service.LCFCC$IClientRootService$Preferences !== null)
                    {
                        let $t9, $r9;
                        this.Service.LCFCC$IClientRootService$Preferences.Font = font;
                        ($t9 = this.Service.LCFCC$IClientRootService$SavePreferences(), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(115965395667)
            
            //--TRIMMABLE-BOUNDARY-START(120260362963)
            /*ValueTask *//*async*/  SetFontSize(/*int*/ font)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t10, $r10;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120260362963);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t10 = this.ThemeAccessor.LCFCC$IThemeAccessor$SetFontSize(font), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    if (this.Service.LCFCC$IClientRootService$Preferences !== null)
                    {
                        let $t11, $r11;
                        this.Service.LCFCC$IClientRootService$Preferences.FontSize = font;
                        ($t11 = this.Service.LCFCC$IClientRootService$SavePreferences(), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(120260362963)
            
            //--TRIMMABLE-BOUNDARY-START(30066049747)
            /*bool */ FilterProperty(/*object*/ model, /*IPropertyDescriptor*/ property)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066049747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return property.LCFCD$1$IPropertyDescriptor$Name !== "_";
            }
            //--TRIMMABLE-BOUNDARY-END(30066049747)
            
            //--TRIMMABLE-BOUNDARY-START(25771082451)
            /*void */ Field(/*IObservableDataDescriptor*/ field)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771082451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                field.LCFCR$IReactiveObservable$Subscribe(new ($.$$.S.Action$$$($.$fPer.LCFCR.IReactiveObservable, $.$fPer.LCFCR.IReactiveObservableChanges))().$ctor(this, /*async*/  (/*f*/ f, /*e*/ e) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t12, $r12;
                        let $t13, $r13;
                        ($t12 = this.Apply(), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                        ($t13 = this.Service.LCFCC$IClientRootService$SavePreferences(), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                    });
                }, $DXKUFk ??= {"r":65537,"p":[{"n":"f","p":54167894},{"n":"e","p":54298966}],"n":"","d":this.$h,"H":0,"h":0,"f":17829890}), null, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(25771082451)
            
            //--TRIMMABLE-BOUNDARY-START(34361017043)
            /*string? */ get FontBind()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950951635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service.LCFCC$IClientRootService$Preferences.Font;
            }
            /*string? */ set FontBind(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490559187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service.LCFCC$IClientRootService$Preferences.Font = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34361017043)
            
            //--TRIMMABLE-BOUNDARY-START(21476115155)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476115155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sZVd._LCFCAF.TypeInference.CreateFormBuilder_0($.$vWqU.LCFCC.ClientUserPreference, __builder, 0, 1, this.Service.LCFCC$IClientRootService$Preferences, 2, 4/*InputFieldFeatures.Default*/ | 2/*InputFieldFeatures.Horizontal*/, 3, this);
            }
            //--TRIMMABLE-BOUNDARY-END(21476115155)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4319237802)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.FormBuilder.IFormFilterController.FilterProperty(object, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor)
            LCFCCF$2$IFormFilterController$FilterProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4319237802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FilterProperty(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4319237802)
            
            //--TRIMMABLE-BOUNDARY-START(4318975658)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.FormBuilder.IFormFieldEditController.Field(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor)
            LCFCCF$2$IFormFieldEditController$Field()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4318975658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Field(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4318975658)
            
            //--TRIMMABLE-BOUNDARY-START(12886180563)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886180563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886180563)
            
            //--TRIMMABLE-BOUNDARY-START(12886180563)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12886180563)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(85900624595)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(85900624595)
                
                //--TRIMMABLE-BOUNDARY-START(128850297555)
                this.ThemeAccessor = null;
                //--TRIMMABLE-BOUNDARY-END(128850297555)
                
            }
            static $H = 1278675;
            static $h = 1278675;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605657299),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51540886227,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 81605657299,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81605657299),
//--TRIMMABLE-BOUNDARY-START(85900624595),
    {
      "p": $.$vWqU.LCFCC.IClientRootService$$(TApp).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60130820819,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 103080493779,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 83886081
      },
      "n": "Service",
      "d": this.$h,
      "H": 85900624595,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900624595),
//--TRIMMABLE-BOUNDARY-START(128850297555),
    {
      "p": 4873640,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68720755411,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 111670428371,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 83886081
      },
      "n": "ThemeAccessor",
      "d": this.$h,
      "H": 128850297555,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128850297555),
//--TRIMMABLE-BOUNDARY-START(34361017043),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950951635,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 94490559187,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 83886082
      },
      "n": "FontBind",
      "d": this.$h,
      "H": 34361017043,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(34361017043)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015722707),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": this.$h,
      "H": 73015722707,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015722707),
//--TRIMMABLE-BOUNDARY-START(77310690003),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": this.$h,
      "H": 77310690003,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(77310690003),
//--TRIMMABLE-BOUNDARY-START(17181147859),
    {
      "r": 178454529,
      "n": "Apply",
      "d": this.$h,
      "H": 17181147859,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(17181147859),
//--TRIMMABLE-BOUNDARY-START(124555330259),
    {
      "r": 181338113,
      "p": [
        {
          "n": "theme",
          "p": 1858984
        }
      ],
      "n": "SetTheme",
      "d": this.$h,
      "H": 124555330259,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(124555330259),
//--TRIMMABLE-BOUNDARY-START(115965395667),
    {
      "r": 181338113,
      "p": [
        {
          "n": "font",
          "p": 1310721
        }
      ],
      "n": "SetFont",
      "d": this.$h,
      "H": 115965395667,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(115965395667),
//--TRIMMABLE-BOUNDARY-START(120260362963),
    {
      "r": 181338113,
      "p": [
        {
          "n": "font",
          "p": 655361
        }
      ],
      "n": "SetFontSize",
      "d": this.$h,
      "H": 120260362963,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(120260362963),
//--TRIMMABLE-BOUNDARY-START(30066049747),
    {
      "r": 262145,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "property",
          "p": 40733014
        }
      ],
      "n": "FilterProperty",
      "d": this.$h,
      "H": 30066049747,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066049747),
//--TRIMMABLE-BOUNDARY-START(25771082451),
    {
      "r": 65537,
      "p": [
        {
          "n": "field",
          "p": 40536406
        }
      ],
      "n": "Field",
      "d": this.$h,
      "H": 25771082451,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771082451),
//--TRIMMABLE-BOUNDARY-START(21476115155),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 21476115155,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476115155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886180563),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 12886180563,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886180563)
  ],
  "s": [
    {
      "h": TApp?.$h??1572864,
      "n": "TApp"
    }
  ],
  "r": 1,
  "H": 1278675,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCF$2.IFormFilterController, $.$hDPm.LCFCCF$2.IFormFieldEditController, $.$hDPm.LCFCCF$2.IFormController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.FixedTypographySelector<${TApp?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}FixedTypographySelector$${TApp?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1278675)
        
        

        //--TRIMMABLE-BOUNDARY-START(885459)
        $asm.$cls(`$sZVd.LCFCA.ClientApplicationModel<>`, (TApplication) => $asm.$gt(`$sZVd.LCFCA.ClientApplicationModel<>`, [TApplication], ($self) => class ClientApplicationModel$$ extends $.$yleQ.LCFCA.ApplicationDescriptor
        {
            //--TRIMMABLE-BOUNDARY-START(68720362195)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720362195);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Service = this;
                    this.Theme = $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$fPer.LCFC.Theme.Primary);
                    this.UIEntryType = this.ApplicationViewType.FullName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68720362195)
            
            //--TRIMMABLE-BOUNDARY-START(73015329491)
            $ctor$3(/*string*/ name, /*string*/ title, /*string*/ description, /*IconDescriptor*/ icon, /*ThemePack?*/ theme)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015329491);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Title = title;
                    this.Description = description;
                    this.Icon = $.$clone(icon);
                    this.Theme = theme;
                    this.Service = this;
                    this.UIEntryType = this.ApplicationViewType.FullName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73015329491)
            
            //--TRIMMABLE-BOUNDARY-START(90195198675)
            /*Type */ get ApplicationViewType()
            {
                return TApplication.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(90195198675)
            
            //--TRIMMABLE-BOUNDARY-START(420907680467)
            /*Type?*/ SplashScreenViewType = null;
            //--TRIMMABLE-BOUNDARY-END(420907680467)
            
            //--TRIMMABLE-BOUNDARY-START(287763694291)
            /*IApplicationService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(287763694291)
            
            //--TRIMMABLE-BOUNDARY-START(292058661587)
            /*IEnumerable<IApplicationSubService>?*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(292058661587)
            
            //--TRIMMABLE-BOUNDARY-START(270583825107)
            /*IEnumerable<IClientApplicationPage>?*/ Pages = null;
            //--TRIMMABLE-BOUNDARY-END(270583825107)
            
            //--TRIMMABLE-BOUNDARY-START(416612713171)
            /*string?*/ SKU = null;
            //--TRIMMABLE-BOUNDARY-END(416612713171)
            
            //--TRIMMABLE-BOUNDARY-START(240519054035)
            /*string?*/ Link = null;
            //--TRIMMABLE-BOUNDARY-END(240519054035)
            
            //--TRIMMABLE-BOUNDARY-START(425202647763)
            /*IEnumerable<string>?*/ Tags = null;
            //--TRIMMABLE-BOUNDARY-END(425202647763)
            
            //--TRIMMABLE-BOUNDARY-START(266288857811)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(266288857811)
            
            //--TRIMMABLE-BOUNDARY-START(261993890515)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(261993890515)
            
            //--TRIMMABLE-BOUNDARY-START(85900231379)
            /*string?*/ ApplicationId = null;
            //--TRIMMABLE-BOUNDARY-END(85900231379)
            
            //--TRIMMABLE-BOUNDARY-START(98785133267)
            /*CatalogueFlags*/ Flags = 0;
            //--TRIMMABLE-BOUNDARY-END(98785133267)
            
            //--TRIMMABLE-BOUNDARY-START(94490165971)
            /*string?*/ BannerImage = null;
            //--TRIMMABLE-BOUNDARY-END(94490165971)
            
            //--TRIMMABLE-BOUNDARY-START(236224086739)
            /*IEnumerable<string>?*/ Images = null;
            //--TRIMMABLE-BOUNDARY-END(236224086739)
            
            //--TRIMMABLE-BOUNDARY-START(429497615059)
            /*Money*/ UnitCost;
            //--TRIMMABLE-BOUNDARY-END(429497615059)
            
            //--TRIMMABLE-BOUNDARY-START(253403955923)
            /*ServiceType*/ LCFCP$IServiceCatalogueModel$ServiceType = 0;
            //--TRIMMABLE-BOUNDARY-END(253403955923)
            
            //--TRIMMABLE-BOUNDARY-START(274878792403)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(274878792403)
            
            //--TRIMMABLE-BOUNDARY-START(274878792403)
            //--TRIMMABLE-BOUNDARY-START(81605264083)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605264083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(81605264083)
            
            //--TRIMMABLE-BOUNDARY-START(283468726995)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468726995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(283468726995)
            
            //--TRIMMABLE-BOUNDARY-END(274878792403)
            
            //--TRIMMABLE-BOUNDARY-START(231929119443)
            /*RenderFragment? */ GetPage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929119443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(231929119443)
            
            //--TRIMMABLE-BOUNDARY-START(257698923219)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698923219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(257698923219)
            
            //--TRIMMABLE-BOUNDARY-START(12886311635)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IClientApplication.ApplicationViewType.get
            get LCFCA$IClientApplication$ApplicationViewType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296377043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ApplicationViewType;
            }
            //--TRIMMABLE-BOUNDARY-END(12886311635)
            
            //--TRIMMABLE-BOUNDARY-START(21476246227)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IClientApplication.SplashScreenViewType.get
            get LCFCA$IClientApplication$SplashScreenViewType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066180819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SplashScreenViewType;
            }
            //--TRIMMABLE-BOUNDARY-END(21476246227)
            
            //--TRIMMABLE-BOUNDARY-START(17181541075)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IClientApplicationPage.Service.get
            get LCFCA$IClientApplicationPage$Service()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426181331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service;
            }
            //--TRIMMABLE-BOUNDARY-END(17181541075)
            
            //--TRIMMABLE-BOUNDARY-START(25771475667)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IClientApplicationPage.Services.get
            get LCFCA$IClientApplicationPage$Services()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721148627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services;
            }
            //--TRIMMABLE-BOUNDARY-END(25771475667)
            
            //--TRIMMABLE-BOUNDARY-START(8591606483)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IClientApplicationPage.Pages.get
            get LCFCA$IClientApplicationPage$Pages()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131214035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Pages;
            }
            //--TRIMMABLE-BOUNDARY-END(8591606483)
            
            //--TRIMMABLE-BOUNDARY-START(30066442963)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IClientApplicationPage.GetPage()
            LCFCA$IClientApplicationPage$GetPage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066442963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPage(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30066442963)
            
            //--TRIMMABLE-BOUNDARY-START(150325801920)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.SKU.get
            get LCFCP$ICatalogueModel$SKU()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714428352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SKU;
            }
            //--TRIMMABLE-BOUNDARY-END(150325801920)
            
            //--TRIMMABLE-BOUNDARY-START(64426456000)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Categories.get
            get LCFCP$ICatalogueModel$Categories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181815744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Categories;
            }
            //--TRIMMABLE-BOUNDARY-END(64426456000)
            
            //--TRIMMABLE-BOUNDARY-START(90196259776)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Flags.get
            get LCFCP$ICatalogueModel$Flags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066717632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Flags;
            }
            //--TRIMMABLE-BOUNDARY-END(90196259776)
            
            //--TRIMMABLE-BOUNDARY-START(47246586816)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.BannerImage.get
            get LCFCP$ICatalogueModel$BannerImage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591881152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BannerImage;
            }
            //--TRIMMABLE-BOUNDARY-END(47246586816)
            
            //--TRIMMABLE-BOUNDARY-START(98786194368)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Images.get
            get LCFCP$ICatalogueModel$Images()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225147840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Images;
            }
            //--TRIMMABLE-BOUNDARY-END(98786194368)
            
            //--TRIMMABLE-BOUNDARY-START(176095605696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.UnitCost.get
            get LCFCP$ICatalogueModel$UnitCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343599330240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnitCost;
            }
            //--TRIMMABLE-BOUNDARY-END(176095605696)
            
            //--TRIMMABLE-BOUNDARY-START(115966063552)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Link.get
            get LCFCP$ICatalogueModel$Link()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815082432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Link;
            }
            //--TRIMMABLE-BOUNDARY-END(115966063552)
            
            //--TRIMMABLE-BOUNDARY-START(21475575576)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTier.Id.get
            get LCFCP$IPaymentTier$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130281240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(21475575576)
            
            //--TRIMMABLE-BOUNDARY-START(12886377171)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IClientApplicationHasId.ApplicationId.get
            get LCFCA$IClientApplicationHasId$ApplicationId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296442579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ApplicationId;
            }
            //--TRIMMABLE-BOUNDARY-END(12886377171)
            
            //--TRIMMABLE-BOUNDARY-START(12886711776)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationService.Features.get
            get LCFCA$IApplicationService$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296777184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(12886711776)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(68720362195)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(68720362195)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(266288857811)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(266288857811)
                
                //--TRIMMABLE-BOUNDARY-START(98785133267)
                this.Flags = 16;
                //--TRIMMABLE-BOUNDARY-END(98785133267)
                
                //--TRIMMABLE-BOUNDARY-START(429497615059)
                this.UnitCost = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(429497615059)
                
            }
            static $H = 885459;
            static $h = 885459;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationDescriptor; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90195198675),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 115965002451,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50331649
      },
      "n": "ApplicationViewType",
      "d": this.$h,
      "H": 90195198675,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195198675),
//--TRIMMABLE-BOUNDARY-START(420907680467),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 210454282963,
        "h": Number(BigInt(this.$h)|0x3100000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 395137876691,
        "h": Number(BigInt(this.$h)|0x5C00000000n),
        "f": 83886081
      },
      "n": "SplashScreenViewType",
      "d": this.$h,
      "H": 420907680467,
      "h": Number(BigInt(this.$h)|0x6200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(420907680467),
//--TRIMMABLE-BOUNDARY-START(287763694291),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "H": 184684479187,
        "h": Number(BigInt(this.$h)|0x2B00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 369368072915,
        "h": Number(BigInt(this.$h)|0x5600000000n),
        "f": 83886081
      },
      "n": "Service",
      "d": this.$h,
      "H": 287763694291,
      "h": Number(BigInt(this.$h)|0x4300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287763694291),
//--TRIMMABLE-BOUNDARY-START(292058661587),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 193274413779,
        "h": Number(BigInt(this.$h)|0x2D00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 377958007507,
        "h": Number(BigInt(this.$h)|0x5800000000n),
        "f": 83886081
      },
      "n": "Services",
      "d": this.$h,
      "H": 292058661587,
      "h": Number(BigInt(this.$h)|0x4400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(292058661587),
//--TRIMMABLE-BOUNDARY-START(270583825107),
    {
      "p": $.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplicationPage).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 176094544595,
        "h": Number(BigInt(this.$h)|0x2900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 360778138323,
        "h": Number(BigInt(this.$h)|0x5400000000n),
        "f": 83886081
      },
      "n": "Pages",
      "d": this.$h,
      "H": 270583825107,
      "h": Number(BigInt(this.$h)|0x3F00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270583825107),
//--TRIMMABLE-BOUNDARY-START(416612713171),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 201864348371,
        "h": Number(BigInt(this.$h)|0x2F00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 386547942099,
        "h": Number(BigInt(this.$h)|0x5A00000000n),
        "f": 83886081
      },
      "n": "SKU",
      "d": this.$h,
      "H": 416612713171,
      "h": Number(BigInt(this.$h)|0x6100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(416612713171),
//--TRIMMABLE-BOUNDARY-START(240519054035),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 150324740819,
        "h": Number(BigInt(this.$h)|0x2300000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 335008334547,
        "h": Number(BigInt(this.$h)|0x4E00000000n),
        "f": 83886081
      },
      "n": "Link",
      "d": this.$h,
      "H": 240519054035,
      "h": Number(BigInt(this.$h)|0x3800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240519054035),
//--TRIMMABLE-BOUNDARY-START(425202647763),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 219044217555,
        "h": Number(BigInt(this.$h)|0x3300000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 403727811283,
        "h": Number(BigInt(this.$h)|0x5E00000000n),
        "f": 83886081
      },
      "n": "Tags",
      "d": this.$h,
      "H": 425202647763,
      "h": Number(BigInt(this.$h)|0x6300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(425202647763),
//--TRIMMABLE-BOUNDARY-START(266288857811),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "H": 167504610003,
        "h": Number(BigInt(this.$h)|0x2700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 352188203731,
        "h": Number(BigInt(this.$h)|0x5200000000n),
        "f": 83886081
      },
      "n": "Loading",
      "d": this.$h,
      "H": 266288857811,
      "h": Number(BigInt(this.$h)|0x3E00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(266288857811),
//--TRIMMABLE-BOUNDARY-START(261993890515),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 158914675411,
        "h": Number(BigInt(this.$h)|0x2500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 343598269139,
        "h": Number(BigInt(this.$h)|0x5000000000n),
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": this.$h,
      "H": 261993890515,
      "h": Number(BigInt(this.$h)|0x3D00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(261993890515),
//--TRIMMABLE-BOUNDARY-START(85900231379),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107375067859,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 300648596179,
        "h": Number(BigInt(this.$h)|0x4600000000n),
        "f": 83886081
      },
      "n": "ApplicationId",
      "d": this.$h,
      "H": 85900231379,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900231379),
//--TRIMMABLE-BOUNDARY-START(98785133267),
    {
      "p": 832448,
      "g": {
        "r": 0,
        "d": 0,
        "H": 133144871635,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 317828465363,
        "h": Number(BigInt(this.$h)|0x4A00000000n),
        "f": 83886081
      },
      "n": "Flags",
      "d": this.$h,
      "H": 98785133267,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785133267),
//--TRIMMABLE-BOUNDARY-START(94490165971),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 124554937043,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 309238530771,
        "h": Number(BigInt(this.$h)|0x4800000000n),
        "f": 83886081
      },
      "n": "BannerImage",
      "d": this.$h,
      "H": 94490165971,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490165971),
//--TRIMMABLE-BOUNDARY-START(236224086739),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 141734806227,
        "h": Number(BigInt(this.$h)|0x2100000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 326418399955,
        "h": Number(BigInt(this.$h)|0x4C00000000n),
        "f": 83886081
      },
      "n": "Images",
      "d": this.$h,
      "H": 236224086739,
      "h": Number(BigInt(this.$h)|0x3700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224086739),
//--TRIMMABLE-BOUNDARY-START(429497615059),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "H": 227634152147,
        "h": Number(BigInt(this.$h)|0x3500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 412317745875,
        "h": Number(BigInt(this.$h)|0x6000000000n),
        "f": 83886081
      },
      "n": "UnitCost",
      "d": this.$h,
      "H": 429497615059,
      "h": Number(BigInt(this.$h)|0x6400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(429497615059),
//--TRIMMABLE-BOUNDARY-START(253403955923),
    {
      "p": 5682112,
      "g": {
        "r": 0,
        "d": 0,
        "H": 249108988627,
        "h": Number(BigInt(this.$h)|0x3A00000000n),
        "f": 50331650
      },
      "n": "{4240320}.ServiceType",
      "o": "LCFCP$IServiceCatalogueModel$ServiceType",
      "d": this.$h,
      "H": 253403955923,
      "h": Number(BigInt(this.$h)|0x3B00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(253403955923)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(231929119443),
    {
      "r": 6881395,
      "n": "GetPage",
      "d": this.$h,
      "H": 231929119443,
      "h": Number(BigInt(this.$h)|0x3600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231929119443),
//--TRIMMABLE-BOUNDARY-START(257698923219),
    {
      "r": 181338113,
      "n": "Load",
      "d": this.$h,
      "H": 257698923219,
      "h": Number(BigInt(this.$h)|0x3C00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(257698923219)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(68720362195),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 68720362195,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720362195),
//--TRIMMABLE-BOUNDARY-START(73015329491),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "title",
          "p": 1310721
        },
        {
          "n": "description",
          "p": 1310721
        },
        {
          "n": "icon",
          "p": 46238038
        },
        {
          "n": "theme",
          "p": 9854376
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 73015329491,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015329491)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(274878792403),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": this.$h,
        "H": 81605264083,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": this.$h,
        "H": 283468726995,
        "h": Number(BigInt(this.$h)|0x4200000000n),
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": this.$h,
      "H": 274878792403,
      "h": Number(BigInt(this.$h)|0x4000000000n),
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(274878792403)
  ],
  "s": [
    {
      "h": TApplication?.$h??1572864,
      "n": "TApplication"
    }
  ],
  "r": 1,
  "H": 885459,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.ICreatorApplicationProxy, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$sZVd.LCFCA.IClientApplicationModel, $.$sZVd.LCFCA.IClientApplicationHasId, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<${TApplication?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}ClientApplicationModel$${TApplication?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(885459)
        
        

        //--TRIMMABLE-BOUNDARY-START(557779)
        $asm.$cls(`$sZVd.LCFCA.ApplicationLoaderT<>`, (TApplication) => $asm.$gt(`$sZVd.LCFCA.ApplicationLoaderT<>`, [TApplication], ($self) => class ApplicationLoaderT$$ extends $.$sZVd.LCFCA.ApplicationLoader
        {
            //--TRIMMABLE-BOUNDARY-START(42950230739)
            /*string */ get OptimizedComponentName()
            {
                return "applicationloadert applicationloader";
            }
            //--TRIMMABLE-BOUNDARY-END(42950230739)
            
            //--TRIMMABLE-BOUNDARY-START(34360296147)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360296147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Application = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TApplication, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(34360296147)
            
            //--TRIMMABLE-BOUNDARY-START(12885459667)
            /*TApplication*/ Application = $.$default(TApplication);
            //--TRIMMABLE-BOUNDARY-END(12885459667)
            
            //--TRIMMABLE-BOUNDARY-START(38655263443)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655263443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Descriptor = $.$fPer.LCFCO.OneOf$$$($.$yleQ.LCFCA.IApplicationProxy, $.$yleQ.LCFCA.IApplicationServiceProxy).op_Implicit($.$box(this.Application, TApplication));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(38655263443)
            
            //--TRIMMABLE-BOUNDARY-START(8590492371)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590492371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590492371)
            
            //--TRIMMABLE-BOUNDARY-START(8590492371)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8590492371)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885459667)
                this.Application = $.$default(TApplication);
                //--TRIMMABLE-BOUNDARY-END(12885459667)
                
            }
            static $H = 557779;
            static $h = 557779;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sZVd.LCFCA.ApplicationLoader; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950230739),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30065328851,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 42950230739,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950230739),
//--TRIMMABLE-BOUNDARY-START(12885459667),
    {
      "p": TApplication?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21475394259,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 51540165331,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 83886081
      },
      "n": "Application",
      "d": this.$h,
      "H": 12885459667,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2097153,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        },
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885459667)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360296147),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": this.$h,
      "H": 34360296147,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360296147),
//--TRIMMABLE-BOUNDARY-START(38655263443),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": this.$h,
      "H": 38655263443,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38655263443)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590492371),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 8590492371,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590492371)
  ],
  "s": [
    {
      "h": TApplication?.$h??1572864,
      "n": "TApplication",
      "c": [1409747
      ]
    }
  ],
  "r": 1,
  "H": 557779,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.ApplicationLoaderT<${TApplication?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}ApplicationLoaderT$${TApplication?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(557779)
        
        

        //--TRIMMABLE-BOUNDARY-START(361171)
        $asm.$cls(`$sZVd.LCFCA.ApplicationBaseService`, ($self) => class ApplicationBaseService extends $.$sZVd.LCFCA.ApplicationBaseService$$($.$yleQ.LCFCA.ApplicationBaseUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(4295328467)
            $ctor$4(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$3(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295328467);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295328467)
            
            static $h = 361171;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sZVd.LCFCA.ApplicationBaseService$$($.$yleQ.LCFCA.ApplicationBaseUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295328467),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 361171,
      "h": 4295328467,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295328467)
  ],
  "h": 361171
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.ApplicationBaseService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}ApplicationBaseService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(361171)
        
        

        //--TRIMMABLE-BOUNDARY-START(295635)
        $asm.$cls(`$sZVd.LCFCA.AppEntryRouter<,,>`, (TApp, TAppRootEntryProvider, TLayout) => $asm.$gt(`$sZVd.LCFCA.AppEntryRouter<,,>`, [TApp, TAppRootEntryProvider, TLayout], ($self) => class AppEntryRouter$$$$ extends $.$hDPm.LCFCA$1.AppRouterBase$$$(TApp, TLayout)
        {
            //--TRIMMABLE-BOUNDARY-START(55834870483)
            /*string */ get OptimizedComponentName()
            {
                return "appentryrouter";
            }
            //--TRIMMABLE-BOUNDARY-END(55834870483)
            
            //--TRIMMABLE-BOUNDARY-START(51539903187)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539903187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.AppRootEntryProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TAppRootEntryProvider, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(51539903187)
            
            //--TRIMMABLE-BOUNDARY-START(17180164819)
            /*TAppRootEntryProvider*/ AppRootEntryProvider = $.$default(TAppRootEntryProvider);
            //--TRIMMABLE-BOUNDARY-END(17180164819)
            
            //--TRIMMABLE-BOUNDARY-START(12885197523)
            /*IEnumerable<Assembly> */ get AdditionalAssemblies()
            {
                return this.AppRootEntryProvider.LCFCA$IApplicationRootEntryProvider$ApplicationAssemblies ?? super.AdditionalAssemblies;
            }
            //--TRIMMABLE-BOUNDARY-END(12885197523)
            
            //--TRIMMABLE-BOUNDARY-START(21475132115)
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475132115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$($.$sZVd.LCFCA.IAppRootEntryProvider), 1);
                __builder.AddAttribute$4(2, "Value", $.$box(this.AppRootEntryProvider, TAppRootEntryProvider));
                __builder.AddAttribute$2(3, "IsFixed", true);
                __builder.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*builder*/ builder) =>
                {
                    super.BuildRenderTree(builder);
                }), $aDTYcd ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21475132115)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590230227)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590230227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590230227)
            
            //--TRIMMABLE-BOUNDARY-START(8590230227)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8590230227)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180164819)
                this.AppRootEntryProvider = $.$default(TAppRootEntryProvider);
                //--TRIMMABLE-BOUNDARY-END(17180164819)
                
            }
            static $H = 295635;
            static $h = 295635;
            static $g = 3;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCA$1.AppRouterBase$$$(TApp, TLayout); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834870483),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47244935891,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 55834870483,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55834870483),
//--TRIMMABLE-BOUNDARY-START(17180164819),
    {
      "p": TAppRootEntryProvider?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38655001299,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 64424805075,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 83886081
      },
      "n": "AppRootEntryProvider",
      "d": this.$h,
      "H": 17180164819,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180164819),
//--TRIMMABLE-BOUNDARY-START(12885197523),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SR.Assembly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30065066707,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50364417
      },
      "n": "AdditionalAssemblies",
      "d": this.$h,
      "H": 12885197523,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885197523)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539903187),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": this.$h,
      "H": 51539903187,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51539903187),
//--TRIMMABLE-BOUNDARY-START(21475132115),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 21475132115,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475132115)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590230227),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 8590230227,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590230227)
  ],
  "s": [
    {
      "h": TApp?.$h??1572864,
      "n": "TApp",
      "c": [2752627
      ]
    },
    {
      "h": TAppRootEntryProvider?.$h??1638400,
      "n": "TAppRootEntryProvider",
      "c": [1344211
      ]
    },
    {
      "h": TLayout?.$h??1703936,
      "n": "TLayout"
    }
  ],
  "r": 3,
  "H": 295635,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCA$1.IAppRouterBase, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$vWqU.LCFCC.IViewStackPresenter$$($.$hDPm.LCFCI.ViewConfiguration), $.$vWqU.LCFCC.IViewStackPresenter, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.AppEntryRouter<${TApp?.$fullName},${TAppRootEntryProvider?.$fullName},${TLayout?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}AppEntryRouter$${TApp?.$getFullName(separator)}$${TAppRootEntryProvider?.$getFullName(separator)}$${TLayout?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(295635)
        
        

        //--TRIMMABLE-BOUNDARY-START(1082067)
        $asm.$cls(`$sZVd.LCFCA.ClientApplicationModelTypeDescriptor<>`, (TApplication) => $asm.$gt(`$sZVd.LCFCA.ClientApplicationModelTypeDescriptor<>`, [TApplication], ($self) => class ClientApplicationModelTypeDescriptor$$ extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))
        {
            //--TRIMMABLE-BOUNDARY-START(4296049363)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296049363);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication).GenerateProperties($.$sZVd.LCFCA.ClientApplicationModel$$(TApplication), this, factory);
                    }, $SLsHie ??= {"r":65537,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), 0, "ClientApplicationModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor\\ClientApplicationModel_LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel_TApplication_TypeDescriptorBuilder.g.cs", "ClientApplicationModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296049363)
            
            //--TRIMMABLE-BOUNDARY-START(12885983955)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885983955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ApplicationViewType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "ApplicationViewType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ApplicationViewType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Type, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ApplicationViewType";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Type, ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).ApplicationViewType);
                        }, $hDLyph ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SplashScreenViewType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "SplashScreenViewType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SplashScreenViewType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Type, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "SplashScreenViewType";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Type, ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).SplashScreenViewType);
                        }, $wtDNVa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Service"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "Service", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Service")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$yleQ.LCFCA.IApplicationService, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Service";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$yleQ.LCFCA.IApplicationService, ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).Service);
                        }, $NiBOZi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Service = value.AsReference($.$yleQ.LCFCA.IApplicationService);
                        }, $JZLXCi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Services"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "Services", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Services")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Services";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService), ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).Services);
                        }, $NyYbdb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Services = value.AsReference($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService));
                        }, $UAzgGk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Pages"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "Pages", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Pages")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplicationPage), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Pages";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplicationPage), ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).Pages);
                        }, $HCeIqh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Pages = value.AsReference($.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplicationPage));
                        }, $QlLuek ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SKU"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "SKU", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SKU")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "SKU";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).SKU);
                        }, $RMaqac ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SKU = value.AsReference($.$$.S.String);
                        }, $apeyuk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Link";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).Link);
                        }, $hxZJbg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Link = value.AsReference($.$$.S.String);
                        }, $bNpMei ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Tags"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "Tags", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Tags")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Tags";
                        $i15.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).Tags);
                        }, $Dfiihj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Tags = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $ojmoqd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Loading"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "Loading", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Loading")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$vWqU.LCFCC.LoadState, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Loading";
                        $i17.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$vWqU.LCFCC.LoadState, ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).Loading);
                        }, $FpnkNj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Loading = value.AsValue($.$vWqU.LCFCC.LoadState);
                        }, $RIZRhk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LoadErrorMessage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "LoadErrorMessage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LoadErrorMessage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "LoadErrorMessage";
                        $i19.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).LoadErrorMessage);
                        }, $fSPCtj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LoadErrorMessage = value.AsReference($.$$.S.String);
                        }, $LHJnsg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ApplicationId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "ApplicationId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ApplicationId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "ApplicationId";
                        $i21.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).ApplicationId);
                        }, $FEBVJh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ApplicationId = value.AsReference($.$$.S.String);
                        }, $VAMmfd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Flags"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "Flags", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Flags")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$AvdQ.LCFCP.CatalogueFlags, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "Flags";
                        $i23.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$AvdQ.LCFCP.CatalogueFlags, ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).Flags);
                        }, $HbKlAb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i23.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Flags = value.AsEnumValue($.$AvdQ.LCFCP.CatalogueFlags);
                        }, $dLsOjg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BannerImage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "BannerImage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BannerImage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t25 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Name = "BannerImage";
                        $i25.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i25.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).BannerImage);
                        }, $iDNLxk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i25.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BannerImage = value.AsReference($.$$.S.String);
                        }, $ZfMCGk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i25;
                    })()), schemas, null, factory);
                    let $en26 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en26.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en26.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Images"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "Images", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Images")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t27 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i27 = new $t27();
                        $i27.$ctor$2();
                        $i27.Name = "Images";
                        $i27.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i27.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).Images);
                        }, $zUZytf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i27.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Images = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $qkgUEh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i27;
                    })()), schemas, null, factory);
                    let $en28 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en28.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en28.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UnitCost"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$type, $.$discardRef(), "UnitCost", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UnitCost")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Money, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t29 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i29 = new $t29();
                        $i29.$ctor$2();
                        $i29.Name = "UnitCost";
                        $i29.DelaredOn = "LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>";
                        $i29.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Money, ($.$cast(target, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))).UnitCost);
                        }, $ptSQbc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i29.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.UnitCost = value.AsValue($.$fPer.LCFCDM.Money);
                        }, $gQzmwi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i29;
                    })()), schemas, null, factory);
                    let $en30 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en30.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en30.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885983955)
            
            //--TRIMMABLE-BOUNDARY-START(17180951251)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180951251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor?*/ let targetBase = _target;
                $.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$yleQ.LCFCA.ApplicationDescriptor));
                {
                    /*var*/ let _ApplicationViewType = _target.ApplicationViewType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ApplicationViewType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Type));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ApplicationViewType, ($v) => _ApplicationViewType = $v, $.$$.S.Type)))
                    {
                    }
                }
                {
                    /*var*/ let _SplashScreenViewType = _target.SplashScreenViewType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SplashScreenViewType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Type));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _SplashScreenViewType, ($v) => _SplashScreenViewType = $v, $.$$.S.Type)))
                    {
                    }
                }
                {
                    /*var*/ let _Service = _target.Service;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Service"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$yleQ.LCFCA.IApplicationService));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Service, ($v) => _Service = $v, $.$yleQ.LCFCA.IApplicationService)))
                    {
                        _target.Service = _Service;
                    }
                }
                {
                    /*var*/ let _Services = _target.Services;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Services"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService), $.$yleQ.LCFCA.IApplicationSubService));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService), $.$yleQ.LCFCA.IApplicationSubService, property, $.$ref(() => _Services, ($v) => _Services = $v, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService))))
                    {
                        _target.Services = _Services;
                        if (_Services !== null)
                        {
                            let $en40 = _Services.SCG$IEnumerable$$$GetEnumerator();
                            while ($en40.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en40.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$yleQ.LCFCA.IApplicationSubService)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService), $.$yleQ.LCFCA.IApplicationSubService, property, $.$ref(() => _Services, ($v) => _Services = $v, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationSubService)));
                    }
                }
                {
                    /*var*/ let _Pages = _target.Pages;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Pages"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplicationPage)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplicationPage), $.$sZVd.LCFCA.IClientApplicationPage));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplicationPage), $.$sZVd.LCFCA.IClientApplicationPage, property, $.$ref(() => _Pages, ($v) => _Pages = $v, $.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplicationPage))))
                    {
                        _target.Pages = _Pages;
                        if (_Pages !== null)
                        {
                            let $en45 = _Pages.SCG$IEnumerable$$$GetEnumerator();
                            while ($en45.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en45.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$sZVd.LCFCA.IClientApplicationPage)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplicationPage), $.$sZVd.LCFCA.IClientApplicationPage, property, $.$ref(() => _Pages, ($v) => _Pages = $v, $.$$.SCG.IEnumerable$$($.$sZVd.LCFCA.IClientApplicationPage)));
                    }
                }
                {
                    /*var*/ let _SKU = _target.SKU;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SKU"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _SKU, ($v) => _SKU = $v, $.$$.S.String)))
                    {
                        _target.SKU = _SKU;
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                        _target.Link = _Link;
                    }
                }
                {
                    /*var*/ let _Tags = _target.Tags;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Tags"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Tags, ($v) => _Tags = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.Tags = _Tags;
                        if (_Tags !== null)
                        {
                            let $en52 = _Tags.SCG$IEnumerable$$$GetEnumerator();
                            while ($en52.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en52.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Tags, ($v) => _Tags = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _Loading = _target.Loading;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Loading"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$vWqU.LCFCC.LoadState));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$vWqU.LCFCC.LoadState, () => _Loading, ($v) => _Loading = $v, null, true)))
                    {
                        _target.Loading = $.$clone(_Loading);
                    }
                }
                {
                    /*var*/ let _LoadErrorMessage = _target.LoadErrorMessage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LoadErrorMessage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _LoadErrorMessage, ($v) => _LoadErrorMessage = $v, $.$$.S.String)))
                    {
                        _target.LoadErrorMessage = _LoadErrorMessage;
                    }
                }
                {
                    /*var*/ let _ApplicationId = _target.ApplicationId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ApplicationId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ApplicationId, ($v) => _ApplicationId = $v, $.$$.S.String)))
                    {
                        _target.ApplicationId = _ApplicationId;
                    }
                }
                {
                    /*var*/ let _Flags = _target.Flags;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Flags"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$AvdQ.LCFCP.CatalogueFlags));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$AvdQ.LCFCP.CatalogueFlags, () => _Flags, ($v) => _Flags = $v, null, true)))
                    {
                        _target.Flags = _Flags;
                    }
                }
                {
                    /*var*/ let _BannerImage = _target.BannerImage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BannerImage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _BannerImage, ($v) => _BannerImage = $v, $.$$.S.String)))
                    {
                        _target.BannerImage = _BannerImage;
                    }
                }
                {
                    /*var*/ let _Images = _target.Images;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Images"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Images, ($v) => _Images = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.Images = _Images;
                        if (_Images !== null)
                        {
                            let $en64 = _Images.SCG$IEnumerable$$$GetEnumerator();
                            while ($en64.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en64.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Images, ($v) => _Images = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _UnitCost = _target.UnitCost;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UnitCost"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Money));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Money, () => _UnitCost, ($v) => _UnitCost = $v, null, true)))
                    {
                        _target.UnitCost = $.$clone(_UnitCost);
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180951251)
            
            //--TRIMMABLE-BOUNDARY-START(8591016659)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Client.Application.ClientApplicationModel<TApplication>?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591016659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new ($.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication), null, $.$ref(() => _target, ($v) => _target = $v, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication))))
                {
                    /*var*/ let result = $.$sZVd.LCFCA.ClientApplicationModelTypeDescriptor$$(TApplication).VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication)));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication), null, $.$ref(() => _target, ($v) => _target = $v, $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication)));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591016659)
            
            static $H = 1082067;
            static $h = 1082067;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$sZVd.LCFCA.ClientApplicationModel$$(TApplication)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885983955),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": this.$h,
      "H": 12885983955,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885983955),
//--TRIMMABLE-BOUNDARY-START(17180951251),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": this.$h,
      "H": 17180951251,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180951251),
//--TRIMMABLE-BOUNDARY-START(8591016659),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$sZVd.LCFCA.ClientApplicationModel$$(TApplication).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": this.$h,
      "H": 8591016659,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591016659)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296049363),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4296049363,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296049363)
  ],
  "s": [
    {
      "h": TApplication?.$h??1572864,
      "n": "TApplication"
    }
  ],
  "r": 1,
  "H": 1082067,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$sZVd.LCFCA.ClientApplicationModel$$(TApplication)), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Application.ClientApplicationModelTypeDescriptor<${TApplication?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Application${separator}ClientApplicationModelTypeDescriptor$${TApplication?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1082067)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product"));
})();
//--TRIMMABLE-BOUNDARY-END(33491)
