"use strict";
Define("log", function (message, type) {
    var method = console[type];
    if (method) {
        method(message);
    }
    else {
        console.log(message);
    }
});
Define("logs", function (logs) {
    for (var log of logs) {
        var method = console[log.type];
        if (method) {
            method(log.message);
        }
        else {
            console.log(log.message);
        }
    }
});
Define("anonymous", function (funcBody, argsName, args) {
    //const args: Array<any> = Array.prototype.slice.call(arguments);
    var _function = new Function(argsName, funcBody);
    return _function.apply(this, args);
});
Define("snapScrollNext", function (element) {
    var ref = element.classList.contains("snap-items") ? element : null;
    if (ref == null) {
        element.childNodes.forEach(e => {
            if (ref == null && e instanceof HTMLElement && e.classList.contains("snap-items")) {
                ref = e;
            }
        });
    }
    if (ref != null) {
        var itemHeight = (ref.childNodes[0]).clientHeight;
        var ch = ref.clientHeight;
        var scrollHeight = ref.scrollHeight;
        var sscrollTop = ref.scrollTop;
        var items = (scrollHeight / itemHeight);
        var n = sscrollTop / itemHeight;
        var scrollTo;
        //if (scrollingDown) {
        scrollTo = Math.trunc(n) + 1;
        //} else {
        //scrollTo = Math.trunc(n);
        //}
        ref.scrollTo(0, scrollTo * ch);
    }
});
Define("proxy", {
    scopes: {},
    gens: {},
    storeProcedure: function (gkey, skey, code, parameters) {
        const scope = { f: new Function("p", "x", code), p: parameters };
        this.scopes[skey] = scope;
        this.gens[gkey] = { x: {} };
    },
    execute: function (code, parameters, gkey, skey) {
        const fun = new Function("p", "x", code);
        let gen;
        if (skey !== null) {
            gen = this.gens[gkey] = { x: {} };
            this.scopes[skey] = { f: fun };
        }
        const returns = fun.call(fun, parameters, gen.x);
        return returns;
    },
    executeStored: function (gkey, skey, parameters) {
        const scope = this.scopes[skey];
        const gen = this.gens[gkey];
        const p = { ...scope.p, ...parameters };
        const returns = scope.f.call(scope.f, p, gen.x);
        return returns;
    },
    createClass: function (gkey, skey, parameters) {
        const scope = this.scopes[skey];
        const gen = this.gens[gkey];
        const p = { ...scope.p, ...parameters };
        const mclass = scope.f.call(scope.f, p, gen.x);
        scope.class = mclass;
    },
    callMember: function (gkey, skey, member, parameters) {
        const scope = this.scopes[skey];
        const gen = this.gens[gkey];
        const p = { ...scope.p, ...parameters };
        const method = scope.class[member];
        const returns = method.call(scope.class, p, gen.x);
        returns;
    }
});
Define("setTitle", function (title) {
    document.title = title;
});
Define("setCookie", function (name, value, exdate, path) {
    (exdate) && (exdate = new Date(exdate).toUTCString());
    var c_value = escape(value) +
        ((exdate === null || exdate === undefined) ? "; expires=" + new Date('2099-01-03T15:50:48.521Z').toUTCString() : "; expires=" + exdate) +
        ((path === null || path === undefined) ? "; Path=/" : "; Path=" + path);
    document.cookie = name + '=' + c_value;
});
Define("setCookies", function (cookies) {
    cookies.forEach((cookie) => {
        document.cookie = cookie;
    });
});
Define("getCookie", function (name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) {
        return parts.pop().split(';').shift();
    }
    return null;
});
Define("removeCookie", function (name) {
    document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
});
Define("reload", function () {
    window.location.reload();
});
Define("scrollTo", function (element, mustScroll) {
    if (typeof (element) === "number") {
        document.documentElement.scrollTo({ top: element, behavior: mustScroll ? "smooth" : "instant" });
    }
    else {
        if (mustScroll)
            element.scrollIntoView();
        else
            element.scrollIntoViewIfNeeded();
        element.focus();
    }
});
Define("focus", function (element) {
    element.focus();
});
Define("focusOut", function (element) {
    element.blur();
});
let tabableInited;
Define("tabableInit", function () {
    if (tabableInited)
        return;
    var observer = new MutationObserver((changes) => {
        changes.forEach((change) => {
            if (change.type == "attributes" && change.attributeName == "class") {
                if (change.target.classList.contains("tabfocus")) {
                    change.target.scrollIntoViewIfNeeded();
                    change.target.focus();
                }
                else {
                    change.target.blur();
                }
            }
        });
    });
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["class"]
    });
    tabableInited = true;
});
Define("getLocation", function () {
    return new Promise((accept, reject) => {
        function gotPosition(position) {
            accept({ latitude: position.coords.latitude, longitude: position.coords.longitude, accuracy: position.coords.accuracy });
        }
        function errPosition(err) {
            reject(err.message);
        }
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(gotPosition, errPosition);
        }
        else {
            reject("Geolocation is not supported by this browser");
        }
    });
});
//Define("_localStorage", {
//    getItem: function (key) {
//        console.log("get " + key);
//        return localStorage.getItem(key);
//    },
//    setItem: function (key, value) {
//        return localStorage.setItem(key, value);
//    },
//    removeItem: function (key) {
//        return localStorage.remove(key);
//    }
//});
function callWasm() {
    //return DotNet.invokeMethodAsync('LivingThing.Web.Client.Blazor.Library.WebAssembly', 'Dispatch', arguments);
}
var nativePromises = {};
let native;
Define("callNative", function () {
    native.invoke(JSON.stringify(arguments[0]));
    if (arguments[1]) {
        var id = arguments[0].i;
        var promise = new Promise((resolve, reject) => {
            nativePromises[id] = { resolve, reject };
        });
        return promise;
    }
});
Define("completeNative", function (id, value, err) {
    var promise = nativePromises[id];
    delete nativePromises[id];
    if (value) {
        promise.resolve(value);
    }
    if (err) {
        promise.reject(err);
    }
});
//Define("localStorage", function () {
//    return localStorage;
//});
Define("get", function (method, target) {
    if (target) {
        var fn = new Function(method);
        return fn.apply(target);
    }
    return eval(method);
});
Define("promiseFnCall", function () {
    var argLen = arguments.length;
    var methodName = arguments[argLen - 2];
    var callback = arguments[argLen - 1];
    var pathsToMethod = methodName.split('.');
    var where = window;
    for (let i = 0; i < pathsToMethod.length; i++) {
        var m = pathsToMethod[i];
        if (m == 'window' && i == 0) {
            where = window;
        }
        else {
            where = where[m];
        }
    }
    var method = where;
    var promise = method.call(null, ...arguments);
    promise.then((result) => {
        callback.jsRunner.invokeMethodAsync("CompletePromise", callback.id, JSON.stringify(result), null);
    }).catch((e) => {
        callback.jsRunner.invokeMethodAsync("CompletePromise", callback.id, null, e.error);
    });
});
Define("waitForScriptLoad", (methodNames) => {
    return new Promise((resolve, reject) => {
        let timer;
        timer = setInterval(() => {
            if (methodNames.every((methodName) => {
                var pathsToMethod = methodName.split('.');
                var where = window;
                for (let i = 0; i < pathsToMethod.length; i++) {
                    var m = pathsToMethod[i];
                    if (m == 'window' && i == 0) {
                        where = window;
                    }
                    else {
                        where = where[m];
                    }
                    if (where == undefined)
                        break;
                }
                return where != undefined;
            })) {
                resolve(null);
                clearInterval(timer);
            }
        }, 100);
    });
});
Define("printElement", function (el, delay) {
    if (el) {
        if (typeof el == 'string') {
            el = document.getElementById(el);
        }
        var divContents = el.outerHTML;
        var a = window.open('', '', 'height=500, width=800');
        if (a) {
            a.document.write('<html class="ltroot">');
            a.document.write('<head>');
            var links = document.head.getElementsByTagName("link");
            for (let i = 0; i < links.length; i++) {
                a.document.write(links.item(i).outerHTML);
            }
            //a.document.write('<link href="/_content/LivingThing.Core.Frameworks.Client.Blazor/LivingThing.Core.Frameworks.Client.min.css" rel="stylesheet">');
            a.document.write('</head>');
            a.document.write('<body>');
            a.document.write(divContents);
            a.document.write('</body></html>');
            a.document.close();
            //wait a little while for css to load else it isnt applies
            setTimeout(function () {
                a.print();
            }, delay || 500);
            return true;
        }
    }
    return false;
});
Define("downloadFileFromStream", async function (fileName, contentStreamReference) {
    const arrayBuffer = await contentStreamReference.arrayBuffer();
    const blob = new Blob([arrayBuffer]);
    const url = URL.createObjectURL(blob);
    const anchorElement = document.createElement('a');
    anchorElement.href = url;
    anchorElement.download = fileName ?? '';
    anchorElement.click();
    anchorElement.remove();
    URL.revokeObjectURL(url);
});
Define("getTimeZone", () => {
    return window.Intl.DateTimeFormat().resolvedOptions().timeZone;
});
Define("getSize", (element) => {
    if (element == null)
        return null;
    var domRect = element.getBoundingClientRect();
    domRect.scrollLeft = element.scrollLeft;
    domRect.scrollTop = element.scrollTop;
    return domRect;
});
Define("openWindow", {
    _window: {},
    open: function (options, component) {
        options.windowName = options.windowName || 'ConnectWithOAuth'; // should not include space for IE
        options.windowOptions = options.windowOptions || 'location=0,status=0,width=800,height=400';
        var that = this;
        console.log(options.path);
        this._window = window;
        this._window = window.open(options.path, options.windowName, options.windowOptions);
        that._oauthInterval = window.setInterval(function () {
            if (that._window?.closed) {
                window.clearInterval(that._oauthInterval);
                component.invokeMethodAsync("WindowClosed");
            }
        }, 1000);
    },
    close: function () {
        this._window.close();
    }
});
function base64ToBytes(base64) {
    const key = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    let newBytes = [];
    let currentChar = 0;
    let currentByte = 0;
    for (let i = 0; i < base64.length; i++) { // Go over four 6-bit base64 chars to decode into three 8-bit bytes
        currentChar = key.indexOf(base64[i]);
        if (i % 4 === 0) { // First base64 char
            currentByte = (currentChar << 2); // Get the 6-bits from first base64 char
        }
        if (i % 4 === 1) { // Second base64 char
            currentByte += (currentChar >> 6); // Concat the first 2-bits from second base64 char
            newBytes.push(currentByte); // Push the first byte
            currentByte = (currentChar & 15) << 4; // Erase bits before last 4-bits, add last 4-bits for second byte
        }
        if (i % 4 === 2) { // Third base64 char
            currentByte += (currentChar >> 2); // Concat first 4-bits from third base64 char for second byte
            newBytes.push(currentByte); // Push second byte
            currentByte = (currentChar & 3) << 6; // Erase bits before last 2-bits, add last 2-bits for third byte
        }
        if (i % 4 === 3) { // Fourth base64 char
            currentByte += (currentChar); // Concat fourth base64 char for third byte
            newBytes.push(currentByte); // Push third byte
        }
    }
    if (newBytes[newBytes.length - 1] === -1) { // Remove single padding from the end (=)
        newBytes.pop();
    }
    if (newBytes[newBytes.length - 2] === -1) { // Remove double padding from the end (==)
        newBytes.pop();
        newBytes.pop();
    }
    return new Uint8Array(newBytes);
}
function bytesToBase64(_bytes) {
    const key = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    let bytes = _bytes instanceof Uint8Array ? _bytes : new Uint8Array(_bytes);
    let newBase64 = '';
    let currentChar = 0;
    for (let i = 0; i < bytes.length; i++) { // Go over three 8-bit bytes to encode four base64 6-bit chars
        if (i % 3 === 0) { // First Byte
            currentChar = (bytes[i] >> 2); // First 6-bits for first base64 char
            newBase64 += key[currentChar]; // Add the first base64 char to the string
            currentChar = (bytes[i] << 4) & 63; // Erase first 6-bits, add first 2 bits for second base64 char
        }
        if (i % 3 === 1) { // Second Byte
            currentChar += (bytes[i] >> 4); // Concat first 4-bits from second byte for second base64 char
            newBase64 += key[currentChar]; // Add the second base64 char to the string
            currentChar = (bytes[i] << 2) & 63; // Add two zeros, add 4-bits from second half of second byte
        }
        if (i % 3 === 2) { // Third Byte
            currentChar += (bytes[i] >> 6); // Concat first 2-bits of third byte for the third base64 char
            newBase64 += key[currentChar]; // Add the third base64 char to the string
            currentChar = bytes[i] & 63; // Add last 6-bits from third byte for the fourth base64 char
            newBase64 += key[currentChar]; // Add the fourth base64 char to the string
        }
    }
    if (bytes.length % 3 === 1) { // Pad for two missing bytes
        newBase64 += `${key[currentChar]}==`;
    }
    if (bytes.length % 3 === 2) { // Pad one missing byte
        newBase64 += `${key[currentChar]}=`;
    }
    return newBase64;
}
Define("localStorage", {
    setItem: function (key, value) {
        if (value instanceof Uint8Array) {
            value = "base64-" + bytesToBase64(value);
        }
        localStorage.setItem(key, value);
    },
    itemTypeIsByteArray: function (key) {
        var v = localStorage.getItem(key);
        if (v != null && v.startsWith("base64-")) {
            return true;
        }
        return false;
    },
    getItem: function (key) {
        var v = localStorage.getItem(key);
        if (v != null && v.startsWith("base64-")) {
            v = v.substring(7);
            return base64ToBytes(v);
        }
        return v;
    },
    removeItem: function (key) {
        localStorage.removeItem(key);
    },
    clear: function () {
        localStorage.clear();
    }
});
Define("getHTML", function (el) {
    if (el) {
        var divContents = el.outerHTML.replace("<!--!-->", "");
        return divContents;
    }
});
Define("setPointerCapture", function (el, pointerId) {
    if (el) {
        el.setPointerCapture(pointerId);
    }
});
Define("releasePointerCapture", function (el, pointerId) {
    if (el) {
        el.releasePointerCapture(pointerId);
    }
});
//Define("getBoundingBox", function (el: HTMLElement) {
//    if (el) {
//        var divContents = el.outerHTML.replace("<!--!-->","");
//		return divContents;
//    }
//});
Define("requestAnimationFrame", (canvasComponent) => {
    function refresh(time) {
        let num = window.requestAnimationFrame(refresh);
        try {
            canvasComponent.invokeMethodAsync("Update", time, num);
        }
        catch {
            window.cancelAnimationFrame(num);
        }
    }
    return window.requestAnimationFrame(refresh);
});
Define("cancelAnimationFrame", (num) => {
    window.cancelAnimationFrame(num);
});
(function () {
    const instances = {};
    function camelize(str) {
        return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function (word, index) {
            return index === 0 ? word.toLowerCase() : word.toUpperCase();
        }).replace(/\s+/g, '');
    }
    //function ExecuteClassMethod(param: ClassProxyParameter, _class:any) {
    //    if (param.method === "constructor") {
    //        instances[param.name] = instances[param.name] || {};
    //        instances[param.name][param.instanceId] = new window["lt"][param.name](...param.parameters)
    //    } else {
    //        _class = _class || instances[param.name][param.instanceId];
    //        let methodName = param.method;
    //        if (methodName.startsWith("get_")) {
    //            methodName = camelize(methodName.replace("get_", ""));
    //        } else if (methodName.startsWith("set_")) {
    //            methodName = camelize(methodName.replace("set_", ""));
    //        }
    //        const method = _class[methodName];
    //        var result = method.apply(_class, param.parameters);
    //        if (param.chains) {
    //            param.chains.forEach(chain => result = ExecuteClassMethod(chain, result));
    //        }
    //        return result;
    //    }
    //}
    function traverse(target, paths) {
        var split = paths.split('.');
        for (var path of split) {
            target = target[path];
            if (target == undefined || target == null)
                return target;
        }
        return target;
    }
    Define("class", function () {
        const args = Array.prototype.slice.call(arguments);
        const className = args[0];
        const instanceId = args[1];
        let methodName = args[2];
        const parameters = args[3];
        function readProperties(object) {
            var propertyNames = Object.getOwnPropertyNames(object);
            var kv = {};
            for (var name of propertyNames) {
                kv[name] = object[name];
            }
            return kv;
        }
        function writeProperties(object, target) {
            var propertyNames = Object.getOwnPropertyNames(object);
            for (var name of propertyNames) {
                var value = object[name];
                if (typeof (value) == 'object' && typeof (target[name]) == 'object') {
                    writeProperties(value, target[name]);
                }
                else {
                    target[name] = value;
                }
            }
        }
        if (methodName === "constructor") {
            instances[className] = instances[className] || {};
            var entry = className.startsWith("window") ? className : "window.lt." + className;
            var obj = traverse(window, entry.replace("window.", ""));
            var jsObject;
            var useConstructor = parameters[1];
            if (typeof (obj) == 'function' && useConstructor !== false)
                jsObject = new obj(...parameters.slice(2));
            else
                jsObject = obj;
            instances[className][instanceId] = { jsObject: jsObject, dotNetInterceptor: parameters[0] };
        }
        else if (methodName === "__readProperties__") {
            const _class = instances[className][instanceId].jsObject;
            return _class; // readProperties(_class);
        }
        else if (methodName === "__writeProperties__") {
            const _class = instances[className][instanceId];
            writeProperties(parameters[0], _class.jsObject);
            return _class.jsObject;
        }
        else {
            const _class = instances[className][instanceId];
            if (methodName.startsWith("get_")) {
                methodName = methodName.replace("get_", "");
            }
            else if (methodName.startsWith("set_")) {
                methodName = methodName.replace("set_", "");
            }
            for (var i in parameters) {
                var parameter = parameters[i];
                if (typeof (parameter) == 'string' && parameter.startsWith('@event')) {
                    parameters[i] = () => {
                        _class.dotNetInterceptor.invokeMethodAsync("InvokeEvent", methodName, parameter, args);
                    };
                    setTimeout(() => {
                        _class.dotNetInterceptor.invokeMethodAsync("InvokeEvent", methodName, parameter, [{ themeParams: {}, colorScheme: "light" }]);
                    }, 5000);
                }
            }
            const method = (traverse(_class.jsObject, methodName) ?? traverse(_class.jsObject, camelize(methodName)));
            return method.apply(_class.jsObject, parameters);
        }
    });
})();
//# sourceMappingURL=Components.js.map