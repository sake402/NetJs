﻿
declare var Define: (name: string, f: any) => void;
