"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
/// <reference path="../Heading/Heading.razor.ts"></reference>
Define("approuterInit", function (app) {
    var obox = {};
    new ResizeObserver(function () {
        var _box = document.documentElement.getBoundingClientRect();
        if (_box.width == 0 && _box.height == 0)
            return;
        _box = JSON.parse(JSON.stringify(_box));
        _box.scrollWidth = document.documentElement.scrollWidth;
        _box.scrollHeight = document.documentElement.scrollHeight;
        //const w = dom.clientWidth;
        //const h = dom.clientHeight;
        //const sw = dom.scrollWidth;
        //const sh = dom.scrollHeight;
        if (obox.width !== _box.width || /*obox.height !== _box.height ||*/ obox.scrollWidth !== _box.scrollWidth /*|| obox.scrollHeight !== _box.scrollHeight*/) {
            app.invokeMethodAsync("SetBox", _box);
            obox = _box;
        }
    }).observe(document.documentElement);
    var _box = document.documentElement.getBoundingClientRect();
    _box = JSON.parse(JSON.stringify(_box));
    _box.scrollWidth = document.documentElement.scrollWidth;
    _box.scrollHeight = document.documentElement.scrollHeight;
    obox = _box;
    document.onkeydown = function (evt) {
        return __awaiter(this, void 0, void 0, function () {
            var promise, stopPropagation;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        promise = app.invokeMethodAsync("Keyboard", {
                            key: evt.key,
                            code: evt.code,
                            location: evt.location,
                            repeat: evt.repeat,
                            ctrlKey: evt.ctrlKey,
                            shiftKey: evt.shiftKey,
                            altKey: evt.altKey,
                            metaKey: evt.metaKey
                        });
                        return [4 /*yield*/, promise];
                    case 1:
                        stopPropagation = _a.sent();
                        if (stopPropagation)
                            evt.stopPropagation();
                        return [2 /*return*/];
                }
            });
        });
    };
    var scrollPoint = 0;
    window.addEventListener("scrollend", function () {
        if (Math.abs(scrollPoint - document.documentElement.scrollTop) > 50) {
            scrollPoint = document.documentElement.scrollTop;
            app.invokeMethodAsync("SetScroll", scrollPoint, document.documentElement.scrollHeight);
        }
    });
    return obox;
});
Define("camera", function (video, canvas, photo, startButton, component) {
    var streaming;
    var width;
    var height;
    function clearPhoto() {
        var context = canvas.getContext("2d");
        context.fillStyle = "#AAA";
        context.fillRect(0, 0, canvas.width, canvas.height);
        var data = canvas.toDataURL("image/png");
        photo.setAttribute("src", data);
    }
    function takePicture() {
        var _this = this;
        var context = canvas.getContext("2d");
        if (width && height) {
            canvas.width = width;
            canvas.height = height;
            context.drawImage(video, 0, 0, width, height);
            var data = canvas.toDataURL("image/jpg");
            photo.setAttribute("src", data);
            canvas.toBlob(function (blob) { return __awaiter(_this, void 0, void 0, function () {
                var arr;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, blob.arrayBuffer()];
                        case 1:
                            arr = _a.sent();
                            component.invokeMethodAsync("PhotoTaken", new Uint8Array(arr));
                            return [2 /*return*/];
                    }
                });
            }); }, 'image/jpeg');
        }
        else {
            clearPhoto();
        }
    }
    video.addEventListener("canplay", function (ev) {
        if (!streaming) {
            width = video.width || video.clientWidth;
            height = (video.videoHeight / video.videoWidth) * width;
            video.setAttribute("width", width + "");
            video.setAttribute("height", height + "");
            canvas.setAttribute("width", width + "");
            canvas.setAttribute("height", height + "");
            streaming = true;
        }
    }, false);
    startButton.addEventListener("click", function (ev) {
        takePicture();
        ev.preventDefault();
    }, false);
    navigator.mediaDevices
        .getUserMedia({ video: true, audio: false })
        .then(function (stream) {
        video.srcObject = stream;
        video.play();
    })
        .catch(function (err) {
        console.error("An error occurred: ".concat(err));
    });
});
/// <reference path="../Heading/Heading.razor.ts"></reference>
//declare var ResizeObserver: any;
Define("boxInit", function (box, dom) {
    var obox = {};
    new ResizeObserver(function () {
        var _box = dom.getBoundingClientRect();
        if (_box.width == 0 && _box.height == 0)
            return;
        _box = JSON.parse(JSON.stringify(_box));
        _box.scrollWidth = dom.scrollWidth;
        _box.scrollHeight = dom.scrollHeight;
        //const w = dom.clientWidth;
        //const h = dom.clientHeight;
        //const sw = dom.scrollWidth;
        //const sh = dom.scrollHeight;
        if (obox.width !== _box.width || obox.height !== _box.height || obox.scrollWidth !== _box.scrollWidth || obox.scrollHeight !== _box.scrollHeight) {
            box.invokeMethodAsync("SetBoxDimension", _box);
            obox = _box;
        }
    }).observe(dom);
    //window.addEventListener("resize", () => {
    //    let _box: any = dom.getBoundingClientRect();
    //    _box = JSON.parse(JSON.stringify(_box));
    //    _box.scrollWidth = dom.scrollWidth;
    //    _box.scrollHeight = dom.scrollHeight;
    //    //const w = dom.clientWidth;
    //    //const h = dom.clientHeight;
    //    //const sw = dom.scrollWidth;
    //    //const sh = dom.scrollHeight;
    //    if (obox.width !== _box.width || obox.height !== _box.height || obox.scrollWidth !== _box.scrollWidth || obox.scrollHeight !== _box.scrollHeight) {
    //        box.invokeMethodAsync("SetDimension", _box);
    //        obox = _box;
    //    }
    //});
    var _box = dom.getBoundingClientRect();
    _box = JSON.parse(JSON.stringify(_box));
    obox = box;
    _box.scrollWidth = dom.scrollWidth;
    _box.scrollHeight = dom.scrollHeight;
    box.invokeMethodAsync("SetBoxDimension", _box);
});
/// <reference path="../../wwwroot/Define.ts"/>
Define("ICanvasGraphics", (function () {
    var CanvasDrawContext = /** @class */ (function () {
        function CanvasDrawContext(_component, canvas) {
            this.component = _component;
            this.canvas = canvas;
            this.context = canvas.getContext('2d');
        }
        return CanvasDrawContext;
    }());
    return CanvasDrawContext;
})());
/// <reference path="../Heading/Heading.razor.ts"></reference>
Define("carousel", {
    snappyScroll: function (root, config) {
        var _a;
        root.style.scrollBehavior = "smooth";
        var lastItemScrollProportion;
        var scrollingDown = true;
        var scrollEndimer;
        var scrollByUser = true;
        var lastScrollPosition;
        var isYDirection = ((_a = config.direction) !== null && _a !== void 0 ? _a : "y") == "y";
        root.addEventListener("scroll", function (e) {
            if (scrollEndimer) {
                clearTimeout(scrollEndimer);
            }
            scrollingDown = (isYDirection ? root.scrollTop : root.scrollLeft) > lastScrollPosition;
            lastScrollPosition = isYDirection ? root.scrollTop : root.scrollLeft;
            scrollEndimer = setTimeout(function () {
                if (!scrollByUser) {
                    scrollByUser = true;
                    return;
                }
                var itemSize = isYDirection ? root.clientHeight : root.clientWidth;
                var scrollSize = isYDirection ? root.scrollHeight : root.scrollWidth;
                var scrollPoint = isYDirection ? root.scrollTop : root.scrollLeft;
                var items = (scrollSize / itemSize);
                var itemScrolled = scrollPoint / itemSize;
                var currentItemScrollPosition = scrollPoint % itemSize;
                var currentItemScrollProportion = currentItemScrollPosition / itemSize;
                if (config.alwaysSnap) {
                    var scrollTo_1;
                    if (scrollingDown) {
                        scrollTo_1 = Math.trunc(itemScrolled) + 1;
                    }
                    else {
                        scrollTo_1 = Math.trunc(itemScrolled);
                    }
                    scrollByUser = false;
                    root.scrollTo(isYDirection ? 0 : scrollTo_1 * itemSize, isYDirection ? scrollTo_1 * itemSize : 0);
                }
                else if (lastItemScrollProportion < 0.5 && currentItemScrollProportion >= 0.5) {
                    var scrollTo = Math.trunc(itemScrolled) + 1;
                    root.scrollTo(isYDirection ? 0 : scrollTo * itemSize, isYDirection ? scrollTo * itemSize : 0);
                }
                else if (lastItemScrollProportion > 0.5 && currentItemScrollProportion <= 0.5) {
                    var scrollTo = Math.trunc(itemScrolled) - 1;
                    root.scrollTo(isYDirection ? 0 : scrollTo * itemSize, isYDirection ? scrollTo * itemSize : 0);
                }
                lastItemScrollProportion = currentItemScrollProportion;
                // console.log("CH:" + ch);
                // console.log("SH:" + sh);
                // console.log("SP:" + sp);
                // console.log("ASP:" + abssp);
                // console.log("PROP:" + currentViewScrollProportion);
                // console.log("N:" + n);
            }, 100);
        });
    }
});
//import * as Chart from '../../../../../node_modules/@types/chart.js/index.d';
/// <reference path="../../../../../../node_modules/@types/chart.js/index.d.ts" />
/// <reference path="../../wwwroot/Define.ts"/>
Define("chartjs", function () {
    var ChartJs = /** @class */ (function () {
        function ChartJs(canvas, parameters) {
            this.canvas = canvas;
            this.chart = new Chart(canvas.getContext("2d"), parameters);
        }
        ChartJs.prototype.update = function (parameter) {
            if (parameter.data)
                this.chart.data = parameter.data;
            if (parameter.options)
                this.chart.options = parameter.options;
            this.chart.update();
        };
        ChartJs.prototype.live = function (x, y, removeFirst) {
            this.chart.data.labels.push(x);
            if (removeFirst) {
                this.chart.config.data.labels.shift();
            }
            // this.chart.config.data.labels.push(Time(value.dateCreated));
            this.chart.data.datasets.forEach(function (dataset, i) {
                if (removeFirst) {
                    dataset.data.shift();
                }
                dataset.data.push(y[i]);
            });
            this.chart.update();
        };
        return ChartJs;
    }());
    var charts = {};
    var _this = this;
    _this.create = function (id, canvas, parameters) {
        var timer;
        timer = setInterval(function () {
            var _a, _b, _c;
            if (window.Chart) {
                (_c = (_b = (_a = parameters === null || parameters === void 0 ? void 0 : parameters.options) === null || _a === void 0 ? void 0 : _a.scales) === null || _b === void 0 ? void 0 : _b.yAxes) === null || _c === void 0 ? void 0 : _c.forEach(function (y) {
                    var _a;
                    (_a = y.ticks) !== null && _a !== void 0 ? _a : (y.ticks = {});
                    y.ticks.callback = function (value, index, values) {
                        return value.toFixed(2); // Get rounding to 2 decimal places
                    };
                });
                //parameters?.options?.plugins["tooltip"]?.callbacks.label = function (value, index, values) {
                //    return (<number>value).toFixed(2); // Get rounding to 2 decimal places
                //}
                var chart = new ChartJs(canvas, parameters);
                charts[id] = chart;
                clearInterval(timer);
            }
        }, 100);
    };
    _this.update = function (id, parameters) {
        var chart = charts[id];
        chart.update(parameters);
    };
    _this.live = function (id, x, y, removeFirst) {
        var chart = charts[id];
        chart.live(x, y, removeFirst);
    };
    _this.delete = function (id) {
        delete charts[id];
    };
    return _this;
}.call({}));
/// <reference path="../../Assets/Assets.razor.ts"></reference>
Define("contextMenu", function (component, dom, delay) {
    var eventType = {
        mousedown: 'ontouchstart' in window ? 'touchstart' : 'mousedown',
        mouseup: 'ontouchend' in window ? 'touchend' : 'mouseup'
    };
    var startTime;
    var x;
    var y;
    function Done() {
        if (startTime) {
            var now = new Date();
            var period = now.getTime() - startTime.getTime();
            startTime = undefined;
            if (period >= delay) {
                component.invokeMethodAsync("LongPressed", x, y);
            }
        }
    }
    dom.addEventListener(eventType.mousedown, function (e) {
        startTime = new Date();
        x = e.touches[0].clientX;
        y = e.touches[0].clientY;
        setTimeout(Done, delay);
    });
    dom.addEventListener(eventType.mouseup, Done);
});
/// <reference path="../Heading/Heading.razor.ts"></reference>
Define("DataListProxy", function () {
    var DataListProxy = /** @class */ (function () {
        function DataListProxy(component, listWrapper, options) {
            var _a, _b;
            this.dataContext = {};
            this.rowHeight = [];
            this.component = component;
            this.listWrapper = listWrapper;
            this.options = options || {};
            //this.listWrapper.style.scrollBehavior = "smooth";
            this.topSpacer = listWrapper.getElementsByClassName("top-spacer")[0];
            if (!this.topSpacer) {
                this.topSpacer = document.createElement((_a = options === null || options === void 0 ? void 0 : options.spacerTag) !== null && _a !== void 0 ? _a : "div");
                this.topSpacer.classList.add("top-spacer");
                listWrapper.parentElement.insertBefore(this.topSpacer, listWrapper);
                //listWrapper.prepend(this.topSpacer);
            }
            this.topSpacer.style.height = "0px";
            //this.topSpacer.style.gridColumnStart = "1";
            //this.topSpacer.style.gridColumnEnd = "auto";
            this.bottomSpacer = listWrapper.getElementsByClassName("bottom-spacer")[0];
            if (!this.bottomSpacer) {
                this.bottomSpacer = document.createElement((_b = options === null || options === void 0 ? void 0 : options.spacerTag) !== null && _b !== void 0 ? _b : "div");
                this.bottomSpacer.classList.add("bottom-spacer");
                listWrapper.parentElement.insertBefore(this.bottomSpacer, null);
                //listWrapper.append(this.bottomSpacer);
            }
            this.bottomSpacer.style.height = "0px";
            //this.bottomSpacer.style.gridColumnStart = "1";
            //this.bottomSpacer.style.gridColumnEnd = "auto";
            var that = this;
            //var mutationObserver = new MutationObserver(function (mutations) { //ensure bottom spacer is always below
            this.timer = setInterval(function () {
                if (that.bottomSpacer.nextSibling) {
                    that.listWrapper.insertBefore(that.bottomSpacer, null);
                }
            }, 500);
            //});
            //mutationObserver.observe(listWrapper, { childList: true });
            var topSpacerObserver = new IntersectionObserver(function (entries) {
                var _a;
                for (var i = 0; i < entries.length; i++) {
                    if (entries[i].isIntersecting) {
                        console.log("top");
                        var context = that.getItemsInView();
                        if ((context.rows > 0 || context.columns > 0) && context.firstIndexInView != 0) {
                            (_a = that.topSpacer.classList).add.apply(_a, that.topSpacerClass());
                            that.component.invokeMethodAsync("TopSpacerVisible", context).then(function (result) {
                                var _a;
                                (_a = that.topSpacer.classList).remove.apply(_a, that.topSpacerClass());
                                that.topSpacer.style.height = result.topSpacerHeight + "px";
                                that.bottomSpacer.style.height = result.bottomSpacerHeight + "px";
                            });
                        }
                    }
                }
            }, {
                threshold: 0
            });
            topSpacerObserver.observe(this.topSpacer);
            var bottomSpacerObserver = new IntersectionObserver(function (entries) {
                var _a;
                for (var i = 0; i < entries.length; i++) {
                    if (entries[i].isIntersecting) {
                        console.log("bottom");
                        var context = that.getItemsInView();
                        if (context.rows > 0 || context.columns > 0) {
                            (_a = that.bottomSpacer.classList).add.apply(_a, that.bottomSpacerClass());
                            that.component.invokeMethodAsync("BottomSpacerVisible", context).then(function (result) {
                                var _a;
                                (_a = that.bottomSpacer.classList).remove.apply(_a, that.bottomSpacerClass());
                                that.topSpacer.style.height = result.topSpacerHeight + "px";
                                that.bottomSpacer.style.height = result.bottomSpacerHeight + "px";
                            });
                        }
                    }
                }
            }, {
                threshold: 0
            });
            bottomSpacerObserver.observe(this.bottomSpacer);
        }
        DataListProxy.prototype.topSpacerClass = function () { return ["mdi", "mdi-loading", "mdi-spin", "flex", "mihx-2", "mgc-a", "fsz-100", "cl-primary", "mgtc-a"]; };
        DataListProxy.prototype.bottomSpacerClass = function () { return ["mdi", "mdi-loading", "mdi-spin", "flex", "mihx-2", "mgc-a", "fsz-100", "cl-primary", "mgbc-a"]; };
        DataListProxy.prototype.addElement = function (context) {
            context.element.classList.remove("d-hide");
            context.hidden = true;
        };
        DataListProxy.prototype.removeElement = function (context) {
            context.element.classList.add("d-hide");
            context.hidden = true;
        };
        //render(data: any[], start: number, end: number) {
        //    data = data || new Array(this.listWrapper.children);
        //    start -= this.options.itemsOverScan || 0;
        //    if (start < 0) {
        //        start = 0;
        //    }
        //    end += this.options.itemsOverScan || 0;
        //    if (end > data.length - 1) {
        //        end = data.length - 1;
        //    }
        //    this.topSpacer.style.height = (start * this.options.itemHeight) + "px";
        //    for (let i = 0; i < data.length; i++) {
        //        var key = 
        //        var context = this.dataContext[data[i]];
        //        if (i < start) {
        //            if (context) {
        //                this.removeElement(context);
        //            }
        //            continue;
        //        } else if (i > end) {
        //            if (context) {
        //                this.removeElement(context);
        //            }
        //            // break;
        //            continue;
        //        }
        //        if (!context) {
        //            var clon = temp.content.cloneNode(true);
        //            var li = clon.querySelector("li");
        //            var att = document.createAttribute("i");
        //            att.value = i.toString();
        //            li.attributes.setNamedItem(att);
        //            //li.innerText = data[i].toString();
        //            this.listWrapper.insertBefore(clon, this.bottomSpacer);
        //            this.dataContext[data[i]] = {
        //                element: li,
        //                hidden: false
        //            };
        //        } else {
        //            this.addElement(context);
        //        }
        //    }
        //    this.bottomSpacer.style.height = ((data.length - end) * this.options.itemHeight) + "px";
        //}
        DataListProxy.prototype.getItemsInView = function () {
            var lis = this.listWrapper.children;
            var firstIndex = -1;
            var lastIndex = -1;
            var firstIndexInView = -1;
            var lastIndexInView = -1;
            var firstItemTopOffset = 0;
            var lastItemBottomOffset = 0;
            var rows = 0;
            var columns = 0;
            var lbbox = null;
            var hasCol = false;
            var minimumItemHeight = 100000000;
            var maximumItemHeight = -100000000;
            var totalItemsHeight = 0;
            var totalRenderedItemsHeight = 0;
            var renderedItems = 0;
            for (var i = 0; i < lis.length; i++) {
                var item = lis.item(i);
                if (item.classList.contains("top-spacer") || item.classList.contains("bottom-spacer"))
                    continue;
                if (item.classList.contains("meta"))
                    continue;
                if (item.classList.contains("d-hide"))
                    continue;
                var bbox = lis.item(i).getBoundingClientRect();
                if (bbox.height > maximumItemHeight) {
                    maximumItemHeight = bbox.height;
                }
                if (bbox.height < minimumItemHeight) {
                    minimumItemHeight = bbox.height;
                }
                if (item.children.length > 0) {
                    renderedItems++;
                }
                if (!lbbox) {
                    rows++;
                    totalItemsHeight += item.clientHeight;
                    if (item.children.length > 0) {
                        totalRenderedItemsHeight += item.clientHeight;
                    }
                }
                else if (lbbox.top != bbox.top) {
                    this.rowHeight[rows] = item.clientHeight;
                    rows++;
                    totalItemsHeight += item.clientHeight;
                    if (item.children.length > 0) {
                        totalRenderedItemsHeight += item.clientHeight;
                    }
                    hasCol = true;
                }
                if (!hasCol) {
                    if (!lbbox) {
                        columns++;
                    }
                    else if (lbbox.left != bbox.left) {
                        columns++;
                    }
                }
                var n = item.getAttribute("n");
                var ni = i - 1; //remove the top spacer
                if (n) {
                    ni = parseInt(n);
                }
                if (firstIndex == -1) {
                    firstIndex = ni;
                }
                lastIndex = ni;
                if (bbox.top >= 0 &&
                    bbox.left >= 0 &&
                    bbox.bottom <= window.innerHeight &&
                    bbox.right <= window.innerWidth) {
                    if (firstIndexInView == -1) {
                        firstIndexInView = ni;
                        firstItemTopOffset = item.offsetTop;
                        lastIndexInView = ni;
                        lastItemBottomOffset = item.offsetTop + item.clientHeight;
                    }
                    else {
                        lastIndexInView = ni;
                        lastItemBottomOffset = item.offsetTop + item.clientHeight;
                    }
                }
                lbbox = bbox;
            }
            return {
                firstIndex: firstIndex,
                firstIndexInView: firstIndexInView,
                firstItemTopOffset: firstItemTopOffset,
                lastIndex: lastIndex,
                lastIndexInView: lastIndexInView,
                lastItemBottomOffset: lastItemBottomOffset,
                rows: rows,
                columns: columns,
                renderedItems: renderedItems,
                minimumItemHeight: minimumItemHeight,
                maximumItemHeight: maximumItemHeight,
                totalItemsHeight: totalItemsHeight,
                totalRenderedItemsHeight: totalRenderedItemsHeight
            };
        };
        //loadAndRender(topSpacerInView, bottomSpacerInView) {
        //    if (dataLoaded.length <= pageStart * itemsPerPage) {
        //        var data = loadMoreData(pageStart);
        //        dataLoaded = dataLoaded.concat(data.data);
        //        totalData = data.total;
        //    }
        //    var items = getItemsInView();
        //    // var itemStart = getFirstItemInView();// pageStart * itemsPerPage;
        //    // itemStart -= itemsPerScreen;
        //    var start;
        //    var end;
        //    if (topSpacerInView) {
        //        end = items.last;
        //        start = end - itemsPerScreen
        //    } else if (bottomSpacerInView) {
        //        start = items.first;
        //        end = start + itemsPerScreen;
        //    } else {
        //        start = 0;
        //        end = start + itemsPerScreen;
        //    }
        //    if (start < 0) {
        //        start = 0;
        //        end = 0;
        //    }
        //    render(dataLoaded, start, end);
        //    // render(dataStart * itemHeight, data.data.filter(function (value, index) {
        //    //     return index >= dataStart && index < dataStart + itemsToRender;
        //    // }), 0);
        //}
        DataListProxy.prototype.dispose = function () {
            clearInterval(this.timer);
        };
        return DataListProxy;
    }());
    var dataLists = {};
    this.init = function (key, component, listWrapper, options) {
        if (listWrapper != null) {
            dataLists[key] = new DataListProxy(component, listWrapper, options);
        }
    };
    this.dispose = function (key) {
        dataLists[key].dispose();
        delete dataLists[key];
    };
    return this;
}.call({}));
/// <reference path="../../Assets/Assets.razor.ts"></reference>
Define("displaySequence", {
    //c_tor: function () {
    //    this.sequencing = [];
    //    this.jobs = [];
    //},
    //init: function (dotnetComponent: any, domElement: HTMLElement) {
    //    domElement.addEventListener("animationend", (ev) => {
    //        if (ev.srcElement == domElement)
    //            dotnetComponent.invokeMethodAsync("Next");
    //    });
    //},
    sequence: function (domElement, id, attributes, _classes) {
        var complete = new Promise(function (resolvePromise, reject) {
            var _a, _b;
            var i = 0;
            var name = domElement.getAttribute("name");
            //console.log(`sequence ${name} => ${_classes}`)
            function Next() {
                var _a, _b;
                //console.log(`remove from ${name} => ${_classes[i-1]}`)
                (_a = domElement.classList).remove.apply(_a, _classes[i - 1].split(' ').filter(function (m) { return m != ' ' && m != ''; }));
                if (i < _classes.length) {
                    //console.log(`add to ${name} => ${_classes[i]}`)
                    (_b = domElement.classList).add.apply(_b, _classes[i].split(' ').filter(function (m) { return m != ' ' && m != ''; }));
                    i++;
                    //if (_classes[i].includes("hide") || _classes[i].includes("default")) {
                    //    i++;
                    //}
                    if (i >= _classes.length) {
                        domElement.removeEventListener("animationend", Next);
                        resolvePromise(null);
                    }
                }
            }
            for (var _i = 0, _c = Object.getOwnPropertyNames(attributes); _i < _c.length; _i++) {
                var key = _c[_i];
                if (key == "class")
                    continue;
                var value = attributes[key];
                domElement.setAttribute(key, value + "");
            }
            var initialClass = attributes["class"];
            var hasAnimation = _classes.some(function (c) { return !c.includes('default') && !c.includes('hide'); });
            if (hasAnimation) {
                domElement.addEventListener("animationend", Next);
            }
            (_a = domElement.classList).remove.apply(_a, domElement.className.split(' ').filter(function (m) { return m != ''; }));
            //domElement.classList.add(...initialClass.split(' ').filter((m) => m != ' ' && m != '' && m != 'animated'/*dont show it yet*/));
            //var hasAnimatedClass = initialClass.includes('animated');
            (_b = domElement.classList).add.apply(_b, (_classes[0] + ' ' + initialClass).split(' ').filter(function (m) { return m != ' ' && m != ''; }));
            if (!_classes.some(function (c) { return c.includes("hide"); })) {
                //console.log(`remove hide from ${name}`)
                //domElement.classList.remove("d-hide");
                domElement.classList.remove("hide");
            }
            if (!hasAnimation) {
                resolvePromise(null);
            }
            i++;
        });
        return complete;
    }
});
/// <reference path="../../Assets/Assets.razor.ts"></reference>
var DraggableFlags;
(function (DraggableFlags) {
    DraggableFlags[DraggableFlags["None"] = 0] = "None";
    DraggableFlags[DraggableFlags["DragX"] = 1] = "DragX";
    DraggableFlags[DraggableFlags["DragY"] = 2] = "DragY";
    DraggableFlags[DraggableFlags["SetDragHandlePosition"] = 4] = "SetDragHandlePosition";
    DraggableFlags[DraggableFlags["PositionFeedbackAsPercentage"] = 8] = "PositionFeedbackAsPercentage";
})(DraggableFlags || (DraggableFlags = {}));
Define("droppable", function (component, elements) {
    function dragOver(e) {
        e.preventDefault();
    }
    function dragEnter(e) {
        e.preventDefault();
    }
    function drop(e) {
        e.preventDefault();
        var dragId = e.dataTransfer.getData("text/plain");
        var t = document.getElementById(dragId);
        var elementReference;
        for (var i = 0; i < t.attributes.length; i++) {
            if (t.attributes.item(i).name.startsWith('_bl_')) {
                elementReference = { __internalId: t.attributes.item(i).name.substring(4) };
                break;
            }
        }
        var x = t.style.left || e.clientX;
        if (typeof x == 'string') {
            x = parseFloat(x.replace('px', ''));
        }
        var y = t.style.top || e.clientY;
        if (typeof y == 'string') {
            y = parseFloat(y.replace('px', ''));
        }
        component.invokeMethodAsync("OnDrop", elementReference, t.id, x, y);
    }
    elements.forEach(function (element) {
        element.addEventListener('dragover', dragOver);
        element.addEventListener('dragenter', dragEnter);
        element.addEventListener('drop', drop);
    });
});
Define("draggable", function (component, flags, draggables) {
    draggables.forEach(function (draggable) {
        var originalX;
        var originalY;
        var dragFromX;
        var dragFromY;
        var dragPosition = draggable.dragPosition instanceof HTMLElement ? draggable.dragPosition : draggable.dragHandle;
        //function dragTo(draggable: HTMLElement, e: DragEvent | MouseEvent) {
        //    var constraintWidth = document.documentElement.clientWidth;// draggable.parentElement.clientWidth;
        //    var constraintHeight = document.documentElement.clientHeight;// draggable.parentElement.clientHeight;
        //    var x = (e.offsetX/* - draggable.parentElement.offsetLeft*/) * 100 / constraintWidth;
        //    if (x < 0)
        //        x = 0;
        //    if (x > 100)
        //        x = 100;
        //    //if ((flags & DraggableFlags.DragX) == DraggableFlags.DragX && (flags & DraggableFlags.SetDragHandlePosition) == DraggableFlags.SetDragHandlePosition) {
        //    draggable.parentElement.style.left = "calc(" + x + "%)";
        //    //draggable.style.left = "calc(" + x + "% - " + draggable.clientWidth + "px)";
        //    //}
        //    var y = (e.offsetY/* - draggable.parentElement.offsetTop*/) * 100 / constraintHeight;
        //    if (y < 0)
        //        y = 0;
        //    if (y > 100)
        //        y = 100;
        //    //if ((flags & DraggableFlags.DragY) == DraggableFlags.DragY && (flags & DraggableFlags.SetDragHandlePosition) == DraggableFlags.SetDragHandlePosition) {
        //    draggable.parentElement.style.top = "calc(" + y + "%)";
        //    //draggable.style.top = "calc(" + y + "% - " + draggable.clientHeight + "px)";
        //    //}
        //    let elementReference;
        //    for (var i = 0; i < draggable.attributes.length; i++) {
        //        if (draggable.attributes.item(i).name.startsWith('_bl_')) {
        //            elementReference = { __internalId: draggable.attributes.item(i).name.substring(4) };
        //            break;
        //        }
        //    }
        //    //component.invokeMethodAsync("OnDragTo", elementReference, x, y);
        //}
        //draggable.dragHandle.addEventListener('click', (e) => {
        //    if (e.target == e.currentTarget) {
        //        dragTo(draggable, e);
        //    }
        //});
        var dragTime = new Date();
        var currentlyDragging;
        var cloneDraggable;
        function dragStart(e) {
            //e.preventDefault();
            currentlyDragging = e.currentTarget;
            if (!(e instanceof TouchEvent)) {
                e.dataTransfer.setData("text/plain", draggable.dragHandle.id);
                dragFromX = e.clientX;
                dragFromY = e.clientY;
                originalX = dragPosition.offsetLeft;
                originalY = dragPosition.offsetTop;
            }
            else {
                //prevent scrolling once touch starts
                e.preventDefault();
                if (!cloneDraggable) {
                    //currentlyDragging.style.touchAction = "none";
                    cloneDraggable = currentlyDragging.cloneNode(true);
                    cloneDraggable.style.position = "fixed";
                    cloneDraggable.style.left = (e.targetTouches[0].clientX - cloneDraggable.clientWidth / 2) + "px";
                    cloneDraggable.style.top = (e.targetTouches[0].clientY - cloneDraggable.clientHeight / 2) + "px";
                    document.body.append(cloneDraggable);
                }
                dragFromX = e.touches[0].clientX;
                dragFromY = e.touches[0].clientY;
                originalX = dragPosition.offsetLeft;
                originalY = dragPosition.offsetTop;
            }
        }
        function drag(e) {
            var _a, _b;
            //e.preventDefault();
            var clientX;
            var clientY;
            if (!(e instanceof TouchEvent)) {
                clientX = e.clientX;
                clientY = e.clientY;
            }
            else {
                //prevent scrolling once touch starts
                e.preventDefault();
                clientX = e.touches[0].clientX;
                clientY = e.touches[0].clientY;
                if (cloneDraggable) {
                    cloneDraggable.style.left = (e.targetTouches[0].clientX - cloneDraggable.clientWidth / 2) + "px";
                    cloneDraggable.style.top = (e.targetTouches[0].clientY - cloneDraggable.clientHeight / 2) + "px";
                }
            }
            if (clientX == 0) { //for some unknown reason yet clientX becomes zero when stop dragging
                return;
            }
            var now = new Date();
            var elapsed = now.getTime() - dragTime.getTime();
            if (elapsed > 50) {
                var draggableWidth = draggable.dragHandle.clientWidth;
                var draggableHeignt = draggable.dragHandle.clientHeight;
                var constraintWidth = ((_a = draggable.dragConstraint) !== null && _a !== void 0 ? _a : draggable.dragHandle.parentElement).clientWidth;
                var constraintHeight = ((_b = draggable.dragConstraint) !== null && _b !== void 0 ? _b : draggable.dragHandle.parentElement).clientHeight;
                var dx = clientX - dragFromX;
                var dy = clientY - dragFromY;
                var x = originalX + dx;
                var y = originalY + dy;
                if (x < 0) {
                    x = 0;
                }
                if (x > constraintWidth - draggableWidth) {
                    x = constraintWidth - draggableWidth;
                }
                if (y < 0) {
                    y = 0;
                }
                if (y > constraintHeight - draggableHeignt) {
                    y = constraintHeight - draggableHeignt;
                }
                if ((flags & DraggableFlags.SetDragHandlePosition) != 0) {
                    dragPosition.style.left = x + "px";
                    dragPosition.style.top = y + "px";
                }
                //dragTo(draggable, e);
                dragTime = now;
                if (component) {
                    var xx = dx; // e.offsetX;
                    if ((flags & DraggableFlags.PositionFeedbackAsPercentage) != 0) {
                        xx = x * 100 / constraintWidth;
                        if (xx < 0)
                            xx = 0;
                        if (xx > 100)
                            xx = 100;
                    }
                    //if ((flags & DraggableFlags.DragX) == DraggableFlags.DragX && (flags & DraggableFlags.SetDragHandlePosition) == DraggableFlags.SetDragHandlePosition) {
                    //draggable.parentElement.style.left = "calc(" + x + "%)";
                    //draggable.style.left = "calc(" + x + "% - " + draggable.clientWidth + "px)";
                    //}
                    var yy = dy; // e.offsetY;
                    if ((flags & DraggableFlags.PositionFeedbackAsPercentage) != 0) {
                        yy = y * 100 / constraintHeight;
                        if (yy < 0)
                            yy = 0;
                        if (yy > 100)
                            yy = 100;
                    }
                    //if ((flags & DraggableFlags.DragY) == DraggableFlags.DragY && (flags & DraggableFlags.SetDragHandlePosition) == DraggableFlags.SetDragHandlePosition) {
                    //draggable.parentElement.style.top = "calc(" + y + "%)";
                    var elementReference = void 0;
                    for (var i = 0; i < dragPosition.attributes.length; i++) {
                        if (dragPosition.attributes.item(i).name.startsWith('_bl_')) {
                            elementReference = { __internalId: dragPosition.attributes.item(i).name.substring(4) };
                            break;
                        }
                    }
                    component.invokeMethodAsync("OnDragTo", elementReference, dragPosition.id, xx, yy);
                }
            }
        }
        function dragEnd(e) {
            //e.preventDefault();
            if (e instanceof TouchEvent) {
                if (cloneDraggable) {
                    cloneDraggable.remove();
                    cloneDraggable = undefined;
                }
                if (currentlyDragging)
                    currentlyDragging.style.touchAction = "";
                var droppedOns = document.elementsFromPoint(e.changedTouches[0].clientX, e.changedTouches[0].clientY);
                //find the first/innermost element with droppable attribute
                droppedOns.forEach(function (droppedOn) {
                    if (droppedOn.attributes.getNamedItem("droppable") != null) {
                        var dt = new DataTransfer();
                        dt.setData("text/plain", draggable.dragHandle.id);
                        var event_1 = new DragEvent("drop", {
                            dataTransfer: dt,
                            clientX: e.changedTouches[0].clientX,
                            clientY: e.changedTouches[0].clientY,
                            screenX: e.changedTouches[0].screenX,
                            screenY: e.changedTouches[0].screenY,
                        });
                        droppedOn.dispatchEvent(event_1);
                    }
                });
            }
            originalX = draggable.dragPosition.offsetLeft;
            originalY = draggable.dragPosition.offsetTop;
        }
        draggable.dragHandle.setAttribute("draggable", "true");
        draggable.dragHandle.addEventListener('dragstart', dragStart);
        draggable.dragHandle.addEventListener('touchstart', dragStart);
        draggable.dragHandle.addEventListener('drag', drag);
        draggable.dragHandle.addEventListener('touchmove', drag);
        draggable.dragHandle.addEventListener('dragend', dragEnd);
        draggable.dragHandle.addEventListener('touchend', dragEnd);
    });
});
/// <reference path="../../../../../Libraries/LivingThing.Frameworks/LivingThing.Core.Frameworks.Client.Blazor.Library/wwwroot/Define.ts"/>
/// <reference path="../../../../../../node_modules/@types/three/src/Three.d.ts"/>
//import * as THREE from "../../../../../../node_modules/@types/three/src/Three";
//// <reference path="../../../../node_modules/three/examples/jsm/renderers/SVGRenderer.d.ts"/>
//declare namespace TTHREE {
//    export interface SVGObject extends THREE.Object3D {
//        constructor(node: SVGElement);
//        node: SVGElement;
//    }
//    export interface SVGRenderer {
//        constructor();
//        domElement: SVGElement;
//        autoClear: boolean;
//        sortObjects: boolean;
//        sortElements: boolean;
//        overdraw: number;
//        info: { render: { vertices: number, faces: number } };
//        getSize(): { width: number, height: number };
//        setQuality(quality: string): void;
//        setClearColor(color: THREE.Color, alpha: number): void;
//        setPixelRatio(): void;
//        setSize(width: number, height: number): void;
//        setPrecision(precision: number): void;
//        clear(): void;
//        render(scene: THREE.Scene, camera: THREE.Camera): void;
//    }
//}
Define("tanks", function () {
    var TankParameter = /** @class */ (function () {
        function TankParameter() {
        }
        return TankParameter;
    }());
    var TankTalksContainer = /** @class */ (function () {
        function TankTalksContainer(parameter) {
            this.parameter = parameter;
        }
        TankTalksContainer.DoAnimate = function (that) {
            function Animation() {
                if (that.scene && that.camera) {
                    var renderer = void 0;
                    if (that.parameter.canvas instanceof HTMLCanvasElement) {
                        renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, canvas: that.parameter.canvas });
                    }
                    else {
                        //@ts-ignore
                        renderer = new THREE.SVGRenderer(that.parameter.canvas);
                    }
                    //let renderer = parameterProvider.renderer;
                    renderer.domElement = that.parameter.canvas;
                    var alpha = 1;
                    var bcolor = that.parameter.backgroundColor;
                    if (bcolor === "transparent") {
                        bcolor = "#FFFFFF";
                        alpha = 0;
                    }
                    renderer.setClearColor(bcolor, alpha);
                    renderer.localClippingEnabled = true;
                    renderer.setSize(that.parameter.width, that.parameter.height);
                    that.Update();
                    renderer.render(that.scene, that.camera);
                    if (renderer.dispose)
                        renderer.dispose();
                    that.rendered = true;
                }
            }
            requestAnimationFrame(Animation);
        };
        TankTalksContainer.prototype.BeginUpdate = function () {
            if ((!this.rendered || document.hasFocus()) && this.scene && this.camera) {
                TankTalksContainer.DoAnimate(this);
            }
        };
        TankTalksContainer.prototype.SetHeight = function (height) {
            this.parameter.contentsHeight = height;
            this.BeginUpdate();
        };
        TankTalksContainer.providers = [];
        return TankTalksContainer;
    }());
    var TankTalksHorizontalCylinder = /** @class */ (function (_super) {
        __extends(TankTalksHorizontalCylinder, _super);
        function TankTalksHorizontalCylinder(parameter) {
            var _this = _super.call(this, parameter) || this;
            _this.liquidsSurface = []; // THREE.Mesh[] = [];
            _this.liquidClippingPlanes = []; // THREE.Plane[] = [];
            _this.tankRadius = 1.5;
            _this.tankHeight = 4;
            _this.scene = new THREE.Scene();
            _this.camera = new THREE.PerspectiveCamera(25, _this.parameter.width / _this.parameter.height, 0.01, 1000);
            _this.camera.position.set(-10.25, 2, 10.5);
            _this.camera.rotation.set(-(11.16 * 2 * Math.PI) / 360, -(44 * 2 * Math.PI) / 360, -(7.89 * 2 * Math.PI) / 360);
            // this.renderer = new THREE.WebGLRenderer({antialias:true, alpha: true});
            // let alpha = 1;
            // let bcolor = this.parameter.backgroundColor; 
            // if (bcolor == "transparent"){
            //   bcolor = "#FFFFFF";
            //   alpha = 0;
            // }
            // this.renderer.setClearColor(bcolor, alpha);
            // this.renderer.localClippingEnabled = true;
            // this.renderer.setSize( this.parameter.width, this.parameter.height );
            // this.chartContainer.nativeElement.appendChild( this.renderer.domElement );
            var openSlot = 0;
            var cylinderGeometry = new THREE.CylinderGeometry(_this.tankRadius, _this.tankRadius, _this.tankHeight, 32, 32, true, openSlot / 2, (2 * 3.142) - (openSlot / 2));
            var cylinderMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.tankColor, transparent: true, opacity: 0.6 });
            var cylinder = new THREE.Mesh(cylinderGeometry, cylinderMaterial);
            cylinder.rotation.set(0, 0, 90 * (2 * Math.PI) / 360);
            _this.scene.add(cylinder);
            for (var i in _this.parameter.contentsHeight) {
                var sectorHeight = _this.parameter.contentsHeight[i] * _this.tankRadius * 2;
                var traingleAdjacent = Math.abs(_this.tankRadius - sectorHeight);
                var sectorWidth = 2 * Math.sqrt(_this.tankRadius * _this.tankRadius - traingleAdjacent * traingleAdjacent);
                var segmentAngle = 2 * Math.acos((_this.tankRadius - sectorHeight) / _this.tankRadius);
                var theta = segmentAngle;
                var thetaStart = (2 * Math.PI) - ((2 * Math.PI) / 4 - segmentAngle / 2) - segmentAngle;
                var liquidClippingPlane = new THREE.Plane(new THREE.Vector3(0, -1, 0), sectorHeight - _this.tankRadius);
                _this.liquidClippingPlanes.push(liquidClippingPlane);
                var liquidGeometry = new THREE.CylinderGeometry(_this.tankRadius + 0.01, _this.tankRadius + 0.01, _this.tankHeight - 0.01, 32, 32, false /*, thetaStart, theta*/);
                var liquidMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.liquidColor[i] || _this.parameter.liquidColor[0], clippingPlanes: [liquidClippingPlane], transparent: true, opacity: 0.6 });
                var liquid = new THREE.Mesh(liquidGeometry, liquidMaterial);
                liquid.rotation.set(0, 0, 90 * (2 * Math.PI) / 360);
                _this.scene.add(liquid);
                var liquidSurfaceGeometry = new THREE.PlaneGeometry(_this.tankHeight, 2 * _this.tankRadius);
                var liquidSurfaceMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.liquidSurfaceColor[i] || _this.parameter.liquidSurfaceColor[0], transparent: false, opacity: 0.6, side: THREE.DoubleSide });
                var liquidSurface = new THREE.Mesh(liquidSurfaceGeometry, liquidSurfaceMaterial);
                _this.liquidsSurface.push(liquidSurface);
                liquidSurface.scale.y = sectorWidth / (2 * _this.tankRadius);
                liquidSurface.rotation.x = (2 * Math.PI) / 4;
                liquidSurface.position.y = -_this.tankRadius + sectorHeight; // + 0.01;
                _this.scene.add(liquidSurface);
            }
            var leftLidGeometry = new THREE.CircleGeometry(_this.tankRadius, 32);
            var leftLidMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.topLidColor, transparent: true, opacity: 0.6, side: THREE.DoubleSide });
            var leftLid = new THREE.Mesh(leftLidGeometry, leftLidMaterial);
            leftLid.rotation.y = (2 * Math.PI) / 4;
            leftLid.position.x = -(_this.tankHeight / 2);
            _this.scene.add(leftLid);
            var rightLidGeometry = new THREE.CircleGeometry(_this.tankRadius, 32);
            var rightLidMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.topLidColor, transparent: true, opacity: 0.6, side: THREE.DoubleSide });
            var rightLid = new THREE.Mesh(rightLidGeometry, rightLidMaterial);
            rightLid.rotation.y = (2 * Math.PI) / 4;
            rightLid.position.x = _this.tankHeight / 2;
            _this.scene.add(rightLid);
            _this.BeginUpdate();
            return _this;
        }
        TankTalksHorizontalCylinder.prototype.Update = function () {
            for (var i in this.liquidsSurface) {
                var sectorHeight = this.parameter.contentsHeight[i] * this.tankRadius * 2;
                var traingleAdjacent = Math.abs(this.tankRadius - sectorHeight);
                var sectorWidth = 2 * Math.sqrt(this.tankRadius * this.tankRadius - traingleAdjacent * traingleAdjacent);
                this.liquidsSurface[i].scale.y = sectorWidth / (2 * this.tankRadius);
                this.liquidsSurface[i].position.y = -this.tankRadius + sectorHeight; // + 0.01;
                this.liquidClippingPlanes[i].constant = sectorHeight - this.tankRadius;
            }
        };
        return TankTalksHorizontalCylinder;
    }(TankTalksContainer));
    var TankTalksVerticalCylinder = /** @class */ (function (_super) {
        __extends(TankTalksVerticalCylinder, _super);
        function TankTalksVerticalCylinder(parameter) {
            var _this = _super.call(this, parameter) || this;
            _this.liquidsSurface = []; // THREE.Mesh[] = [];
            _this.clippingPlanes = []; // THREE.Plane[] = [];
            _this.tankRadius = 1;
            _this.tankHeight = 4;
            _this.scene = new THREE.Scene();
            _this.camera = new THREE.PerspectiveCamera(25, _this.parameter.width / _this.parameter.height, 0.01, 1000);
            _this.camera.position.set(0, 3.2, 10);
            _this.camera.rotation.set(-(18 * 2 * Math.PI) / 360, 0, 0);
            // this.renderer = new THREE.WebGLRenderer({antialias:true, alpha: true });
            // let alpha = 1;
            // let bcolor = this.parameter.backgroundColor; 
            // if (bcolor == "transparent"){
            //   bcolor = "#FFFFFF";
            //   alpha = 0;
            // }
            // this.renderer.setClearColor(bcolor, alpha);
            // this.renderer.localClippingEnabled = true;
            // this.renderer.setSize( this.parameter.width, this.parameter.height );
            // this.chartContainer.nativeElement.appendChild( this.renderer.domElement );
            var openSlot = 0; //2*Math.PI/20;
            var cylinderGeometry = new THREE.CylinderGeometry(_this.tankRadius, _this.tankRadius, _this.tankHeight, 32, 32, true, openSlot / 2, (2 * Math.PI) - (openSlot / 2));
            var cylinderMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.tankColor, transparent: true, opacity: 0.6 });
            var cylinder = new THREE.Mesh(cylinderGeometry, cylinderMaterial);
            _this.scene.add(cylinder);
            for (var i in _this.parameter.contentsHeight) {
                var liquidHeight = _this.tankHeight * _this.parameter.contentsHeight[i];
                var clippingPlane = new THREE.Plane(new THREE.Vector3(0, -1, 0), liquidHeight - _this.tankHeight / 2);
                _this.clippingPlanes.push(clippingPlane);
                var liquidGeometry = new THREE.CylinderGeometry(_this.tankRadius /*0.96*/, _this.tankRadius /*0.96*/, _this.tankHeight, 32, 32);
                var liquidMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.liquidColor[i] || _this.parameter.liquidColor[0], clippingPlanes: [clippingPlane], transparent: true, opacity: 0.6 });
                var liquid = new THREE.Mesh(liquidGeometry, liquidMaterial);
                _this.scene.add(liquid);
                var liquidSurfaceGeometry = new THREE.CircleGeometry(_this.tankRadius /*0.96*/, 32);
                var liquidSurfaceMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.liquidSurfaceColor[i] || _this.parameter.liquidSurfaceColor[0], transparent: false, opacity: 0.6, side: THREE.DoubleSide });
                var liquidSurface = new THREE.Mesh(liquidSurfaceGeometry, liquidSurfaceMaterial);
                liquidSurface.rotation.x = (2 * Math.PI) / 4;
                liquidSurface.position.y = -(_this.tankHeight / 2) + liquidHeight; // + 0.01;
                _this.scene.add(liquidSurface);
                _this.liquidsSurface.push(liquidSurface);
            }
            var topLidGeometry = new THREE.CircleGeometry(_this.tankRadius, 32);
            var topLidMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.topLidColor, transparent: true, opacity: 0.6, side: THREE.DoubleSide });
            var topLid = new THREE.Mesh(topLidGeometry, topLidMaterial);
            topLid.rotation.x = (2 * Math.PI) / 4;
            topLid.position.y = _this.tankHeight / 2;
            _this.scene.add(topLid);
            var bottomLidGeometry = new THREE.CircleGeometry(_this.tankRadius, 32);
            var bottomLidMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.bottomLidColor, transparent: true, opacity: 0.4, side: THREE.DoubleSide });
            var bottomLid = new THREE.Mesh(bottomLidGeometry, bottomLidMaterial);
            bottomLid.rotation.x = (2 * Math.PI) / 4;
            bottomLid.position.y = -_this.tankHeight / 2;
            _this.scene.add(bottomLid);
            _this.BeginUpdate();
            return _this;
        }
        TankTalksVerticalCylinder.prototype.Update = function () {
            for (var i in this.parameter.contentsHeight) {
                var liquidHeight = this.tankHeight * this.parameter.contentsHeight[i];
                this.clippingPlanes[i].constant = liquidHeight - this.tankHeight / 2;
                this.liquidsSurface[i].position.y = -(this.tankHeight / 2) + liquidHeight; // + 0.01;
            }
        };
        return TankTalksVerticalCylinder;
    }(TankTalksContainer));
    var TankTalksRectangle = /** @class */ (function (_super) {
        __extends(TankTalksRectangle, _super);
        function TankTalksRectangle(parameter) {
            var _this = _super.call(this, parameter) || this;
            _this.liquidsSurface = []; // THREE.Mesh[] = [];
            _this.clippingPlanes = []; // THREE.Plane[] = [];
            _this.tankWidth = 2;
            _this.tankHeight = 4;
            _this.tankDepth = 2;
            _this.scene = new THREE.Scene();
            _this.camera = new THREE.PerspectiveCamera(27, _this.parameter.width / _this.parameter.height, 0.01, 1000);
            _this.camera.position.set(0, 3.2, 10);
            _this.camera.rotation.set(-(18 * 2 * Math.PI) / 360, 0, 0);
            // this.renderer = new THREE.WebGLRenderer({antialias:true, alpha: true });
            // let alpha = 1;
            // let bcolor = this.parameter.backgroundColor; 
            // if (bcolor == "transparent"){
            //   bcolor = "#FFFFFF";
            //   alpha = 0;
            // }
            // this.renderer.setClearColor(bcolor, alpha);
            // this.renderer.localClippingEnabled = true;
            // this.renderer.setSize( this.parameter.width, this.parameter.height );
            // this.chartContainer.nativeElement.appendChild( this.renderer.domElement );
            var tankGeometry = new THREE.BoxGeometry(_this.tankWidth, _this.tankHeight, _this.tankDepth);
            var tankMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.tankColor, transparent: true, opacity: 0.6 });
            var tank = new THREE.Mesh(tankGeometry, tankMaterial);
            // let tankEdgeGeometry = new THREE.BoxGeometry(parameter.width-0.01, parameter.height-0.01, parameter.depth-0.01, 0, 0, 0);
            var tankEdgeMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.borderColor, wireframe: true, transparent: true, opacity: 0.6 });
            var tankEdge = new THREE.Mesh(tankGeometry, tankEdgeMaterial);
            // tank.rotation.x = tankEdge.rotation.x = 0.1;
            // tank.rotation.y = tankEdge.rotation.y = 0.3;
            _this.scene.add(tank);
            _this.scene.add(tankEdge);
            for (var i in _this.parameter.contentsHeight) {
                var liquidHeight = _this.tankHeight * _this.parameter.contentsHeight[i];
                var clippingPlane = new THREE.Plane(new THREE.Vector3(0, -1, 0), liquidHeight - _this.tankHeight / 2);
                _this.clippingPlanes.push(clippingPlane);
                var liquidGeometry = new THREE.BoxGeometry(_this.tankWidth, _this.tankHeight, _this.tankDepth);
                var liquidMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.liquidColor[i] || _this.parameter.liquidColor[0], clippingPlanes: [clippingPlane], transparent: true, opacity: 0.6 });
                var liquid = new THREE.Mesh(liquidGeometry, liquidMaterial);
                _this.scene.add(liquid);
                var liquidSurfaceGeometry = new THREE.PlaneGeometry(_this.tankWidth, _this.tankDepth);
                var liquidSurfaceMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.liquidSurfaceColor[i] || _this.parameter.liquidSurfaceColor[0], transparent: false, opacity: 0.6, side: THREE.DoubleSide });
                var liquidSurface = new THREE.Mesh(liquidSurfaceGeometry, liquidSurfaceMaterial);
                liquidSurface.rotation.x = (2 * Math.PI) / 4;
                liquidSurface.position.y = -(_this.tankHeight / 2) + liquidHeight; // + 0.01;
                _this.scene.add(liquidSurface);
                _this.liquidsSurface.push(liquidSurface);
            }
            var topLidGeometry = new THREE.PlaneGeometry(_this.tankWidth, _this.tankDepth);
            var topLidMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.topLidColor, transparent: true, opacity: 0.6, side: THREE.DoubleSide });
            var topLid = new THREE.Mesh(topLidGeometry, topLidMaterial);
            topLid.rotation.x = (2 * Math.PI) / 4;
            topLid.position.y = (_this.tankHeight / 2) + 0.01;
            _this.scene.add(topLid);
            var bottomLidGeometry = new THREE.PlaneGeometry(_this.tankWidth, _this.tankDepth);
            var bottomLidMaterial = new THREE.MeshBasicMaterial({ color: _this.parameter.bottomLidColor, transparent: true, opacity: 0.4, side: THREE.DoubleSide });
            var bottomLid = new THREE.Mesh(bottomLidGeometry, bottomLidMaterial);
            bottomLid.rotation.x = (2 * Math.PI) / 4;
            bottomLid.position.y = -_this.tankHeight / 2;
            _this.scene.add(bottomLid);
            _this.scene.rotation.y = 0.4;
            _this.BeginUpdate();
            return _this;
        }
        TankTalksRectangle.prototype.Update = function () {
            for (var i in this.parameter.contentsHeight) {
                var liquidHeight = this.tankHeight * this.parameter.contentsHeight[i];
                this.clippingPlanes[i].constant = liquidHeight - this.tankHeight / 2;
                this.liquidsSurface[i].position.y = -(this.tankHeight / 2) + liquidHeight; // + 0.01;
            }
        };
        return TankTalksRectangle;
    }(TankTalksContainer));
    var tanks = {};
    this.createTank = function (key, type, parameter) {
        switch (type) {
            default:
                tanks[key] = new TankTalksVerticalCylinder(parameter);
                break;
            case "HorizontalCylinder":
                tanks[key] = new TankTalksHorizontalCylinder(parameter);
                break;
            case "Rectangular":
                tanks[key] = new TankTalksRectangle(parameter);
                break;
        }
    };
    this.updateHeight = function (key, height) {
        tanks[key].SetHeight(height);
    };
    return this;
}.call({}));
/// <reference path="../Heading/Heading.razor.ts"></reference>
Define("gesture", function (component, dom, events, delay) {
    var _this = this;
    var eventType = {
        mousedown: 'ontouchstart' in window ? 'touchstart' : 'mousedown',
        mousemove: 'ontouchmove' in window ? 'touchmove' : 'mousemove',
        mouseup: 'ontouchend' in window ? 'touchend' : 'mouseup',
    };
    var startTime;
    var moveTime;
    var moveRefx;
    var moveRefy;
    var swipeTime;
    var swipeRefx;
    var swipeRefy;
    var swiping;
    var down;
    function DonePressed() {
        if (startTime) {
            var now = new Date();
            var period = now.getTime() - startTime.getTime();
            startTime = undefined;
            if (period >= delay) {
                component.invokeMethodAsync("Event", 1 << 3, moveRefx, moveRefy);
            }
        }
        else {
            component.invokeMethodAsync("Event", 1 << 2, moveRefx, moveRefy);
        }
    }
    dom.addEventListener(eventType.mousedown, function (e) {
        //console.log(new Date().getTime() + ": Down");
        down = true;
        startTime = new Date();
        if (e.touches) {
            moveRefx = swipeRefx = e.touches[0].clientX;
            moveRefy = swipeRefy = e.touches[0].clientY;
        }
        else {
            var ee = e;
            moveRefx = ee.clientX;
            moveRefx = ee.clientY;
        }
        if ((events & 1) != 0) {
            component.invokeMethodAsync("Event", 1, moveRefx, moveRefy);
            setTimeout(DonePressed, delay);
        }
    });
    if ((events & 2) != 0 || (events & 8) != 0) {
        dom.addEventListener(eventType.mousemove, function (e) { return __awaiter(_this, void 0, void 0, function () {
            var now, _x, _y, ee, dx, dy, p;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        now = new Date();
                        if (e.touches) {
                            _x = e.touches[0].clientX;
                            _y = e.touches[0].clientY;
                        }
                        else {
                            ee = e;
                            _x = ee.clientX;
                            _y = ee.clientY;
                        }
                        if (!((events & 8) != 0)) return [3 /*break*/, 2];
                        dx = _x - swipeRefx;
                        dy = _y - swipeRefy;
                        if (!(!swiping && e.touches && (Math.abs(dx) > 50 || Math.abs(dy) > 50) && (!swipeTime || now.getTime() - swipeTime.getTime() > 1000))) return [3 /*break*/, 2];
                        swiping = true;
                        //console.log(new Date().getTime() + ": Swipe Accept " + dx + " " + dy);
                        swipeRefx = _x;
                        swipeRefy = _y;
                        swipeTime = now;
                        p = void 0;
                        if (Math.abs(dx) > Math.abs(dy)) {
                            if (dx > 0) {
                                //left
                                p = component.invokeMethodAsync("Event", 1 << 4, _x, _y);
                            }
                            else {
                                //right
                                p = component.invokeMethodAsync("Event", 1 << 5, _x, _y);
                            }
                        }
                        else {
                            if (dy > 0) {
                                //up
                                p = component.invokeMethodAsync("Event", 1 << 6, _x, _y);
                            }
                            else {
                                //down
                                p = component.invokeMethodAsync("Event", 1 << 7, _x, _y);
                            }
                        }
                        return [4 /*yield*/, p];
                    case 1:
                        _a.sent();
                        swiping = false;
                        _a.label = 2;
                    case 2:
                        if (!moveTime || now.getTime() - moveTime.getTime() > 300) {
                            moveTime = now;
                            moveRefx = _x;
                            moveRefy = _y;
                            //console.log(new Date().getTime() + ": TouchMove " + moveRefx + " " + moveRefy);
                            if ((events & 2) != 0) {
                                component.invokeMethodAsync("Event", 1 << 1, moveRefx, moveRefy);
                            }
                        }
                        return [2 /*return*/];
                }
            });
        }); });
    }
    dom.addEventListener(eventType.mouseup, function () {
        //console.log(new Date().getTime() + ": Up");
        if ((events & 4) != 0) {
            DonePressed();
        }
    });
});
//export interface DotNetInterface {
//    invokeMethodAsync(...args: any[]): any;
//}
//export function DefineClass(name: string, f: any){
//}
Define("assets", function (links, scripts, asset) {
    var head = document.head;
    var equals = function (asset1, asset2) {
        return asset1 === asset2 ||
            asset1 === document.location.href + asset2 ||
            asset1 === document.location.origin + asset2 ||
            asset2 === document.location.href + asset1 ||
            asset2 === document.location.origin + asset1;
    };
    //@ts-ignore
    var existingLinks = Array.from(head.getElementsByTagName("link"));
    var _loop_1 = function (link) {
        if (!existingLinks.some(function (lk) { return equals(link, lk.href); })) {
            var newlk = document.createElement("link");
            newlk.href = link;
            newlk.rel = "stylesheet";
            newlk.type = "text/css";
            head.appendChild(newlk);
        }
    };
    for (var _i = 0, links_1 = links; _i < links_1.length; _i++) {
        var link = links_1[_i];
        _loop_1(link);
    }
    //for (const link of existingLinks) {
    //    if (!links.some(lk => equals(link.href, lk))) {
    //        if (!link.hasAttribute("static"))
    //            link.remove();
    //    }
    //}
    //@ts-ignore
    var existingScripts = Array.from(head.getElementsByTagName("script"));
    var _loop_2 = function (script) {
        if (!existingScripts.some(function (sc) { return equals(sc.src, script); })) {
            var newsc = document.createElement("script");
            newsc.type = "text/javascript";
            head.appendChild(newsc);
            if (asset) {
                newsc.onload = function () {
                    asset.invokeMethodAsync("Loaded", script);
                };
            }
            newsc.src = script;
        }
        else {
            if (asset) {
                asset.invokeMethodAsync("Loaded", script);
            }
        }
    };
    for (var _a = 0, scripts_1 = scripts; _a < scripts_1.length; _a++) {
        var script = scripts_1[_a];
        _loop_2(script);
    }
    //for (const script of existingScripts) {
    //    if (!scripts.some(sc => equals(sc, script.src))) {
    //        if (!script.hasAttribute("static"))
    //            script.remove();
    //    }
    //}
    var loading = document.getElementById("loading");
    if (loading) {
        loading.remove();
    }
    var app = (document.getElementsByTagName("app").item(0));
    if (app) {
        app.style.display = "";
    }
});
/// <reference path="../../Heading/Heading.razor.ts"></reference>
Define("TypeScriptContentEditable", (function () {
    var ContentEditable = /** @class */ (function () {
        //input: any;
        function ContentEditable(input, contentEditable, textarea, features) {
            var _this = this;
            var focusOnLoad = (features & 1) != 0;
            var saveOnLostFocus = (features & 2) != 0;
            var cloneEditable = true;
            //this.input = input;
            //this.element = contentEditable;
            var clonedContentEditable = contentEditable;
            var wrapper = document.createElement("span");
            wrapper.className = "wrapper scroll pos-rel flex"; // scroll d-i-block
            wrapper.style.maxHeight = "70vh"; // "min(100%, 500px)";
            //wrapper.className = "wrapper mahx-5 scroll row";
            clonedContentEditable = contentEditable.cloneNode(true);
            if (clonedContentEditable != contentEditable)
                clonedContentEditable.classList.remove("d-hide");
            var observer = new MutationObserver(function (changes) {
                if (clonedContentEditable.innerHTML != contentEditable.innerHTML)
                    clonedContentEditable.innerHTML = contentEditable.innerHTML;
                clonedContentEditable.classList = contentEditable.classList;
                var style = contentEditable.attributes.getNamedItem("style").value;
                var attr = document.createAttribute("style");
                attr.value = style;
                clonedContentEditable.attributes.setNamedItem(attr);
                //const computedStyles = window.getComputedStyle(contentEditable);
                //clonedContentEditable.style.cssText = computedStyles.cssText;
                //clonedContentEditable.style = contentEditable.style;
                clonedContentEditable.classList.remove("d-hide");
            });
            observer.observe(contentEditable, { childList: true, subtree: true, attributes: true });
            if (clonedContentEditable.innerText.trim() == '') { //placeholder wont show up itll all the whitespace and comments in it
                clonedContentEditable.innerText = "";
            }
            //remove the clone when contentEditable is removed
            var removeObserver = new MutationObserver(function (mutationsList) {
                for (var _i = 0, mutationsList_1 = mutationsList; _i < mutationsList_1.length; _i++) {
                    var mutation = mutationsList_1[_i];
                    if (mutation.type === 'childList' && mutation.removedNodes.length > 0) {
                        mutation.removedNodes.forEach(function (removedNode) {
                            if (removedNode === contentEditable) {
                                clonedContentEditable.remove();
                                removeObserver.disconnect(); // Stop observing once removed
                            }
                        });
                    }
                }
            });
            removeObserver.observe(contentEditable.parentElement, { childList: true });
            if (clonedContentEditable.innerText.trim() == '') { //placeholder wont show up itll all the whitespace and comments in it
                clonedContentEditable.innerText = "";
            }
            this.clonedContentEditable = clonedContentEditable;
            wrapper.appendChild(clonedContentEditable);
            var button = null;
            if (!saveOnLostFocus) {
                button = document.createElement("button");
                button.className = "bg-primary bd shadow round mdi mdi-check hx-03 wx-03 clickable mgy-a";
                //button.style.right = "0px";
                wrapper.appendChild(button);
            }
            contentEditable.parentElement.insertBefore(wrapper, contentEditable.nextSibling);
            if (!saveOnLostFocus) {
                button.addEventListener("click", function () {
                    if (!textarea) {
                        input.invokeMethodAsync("Inputted", clonedContentEditable.innerText.trim());
                    }
                    else {
                        input.invokeMethodAsync("Inputted", clonedContentEditable.innerHTML);
                    }
                });
            }
            else {
                wrapper.addEventListener("focusout", function (ev) {
                    ev.stopPropagation();
                    if (!textarea) {
                        input.invokeMethodAsync("Inputted", clonedContentEditable.innerText.trim());
                    }
                    else {
                        input.invokeMethodAsync("Inputted", clonedContentEditable.innerHTML);
                    }
                });
            }
            if (!textarea) {
                clonedContentEditable.addEventListener("keydown", function (ev) {
                    ev.stopPropagation();
                    if (ev.code === "Enter") {
                        input.invokeMethodAsync("Inputted", clonedContentEditable.innerText.trim());
                    }
                });
            }
            clonedContentEditable.addEventListener("keyup", function (ev) {
                ev.stopPropagation();
            });
            //if (!(features & 1)) {
            //    const ok = document.createElement("i");
            //    ok.className = "mdi mdi-check-bold lt clickable canclick";
            //    wrapper.appendChild(ok);
            //    //ne.focus(); //comment because it steals focus in form, while not the first field
            //    ok.addEventListener("click", () => {
            //        if (!textarea) {
            //            input.invokeMethodAsync("Inputted", clonedContentEditable.innerText);
            //        } else {
            //            input.invokeMethodAsync("Inputted", clonedContentEditable.innerHTML);
            //        }
            //    });
            //}
            if (cloneEditable) {
                //contentEditable.style.display = 'hidden';
                //contentEditable.remove();
            }
            if (focusOnLoad) {
                clonedContentEditable.focus();
            }
            //clonedContentEditable.addEventListener("focusout", (ev) => {
            //    this.selection = window.getSelection();
            //    this.focused = this.selection.focusNode as HTMLElement;
            //    this.focused.tabIndex = -1;
            //    this.range = document.createRange();
            //});
            clonedContentEditable.addEventListener("focus", function (ev) {
                if (_this.pendingCommand) {
                    setTimeout(function () {
                        document.execCommand(_this.pendingCommand, true, _this.pendingArguments);
                        _this.pendingCommand = null;
                        _this.pendingArguments = null;
                    }, 0);
                }
            });
            document.execCommand('defaultParagraphSeparator', false, 'p');
            if (textarea) {
                //wrapper.scrollIntoView();
            }
            //element.addEventListener("input", (ev) => {
            //    input.invokeMethodAsync("Inputted", element.innerHTML);
            //});
        }
        ContentEditable.prototype.executeCommand = function (commandName, _arguments) {
            //this.clonedContentEditable.focus();
            //this.focused.focus();
            var active = document.activeElement;
            //if (this.clonedContentEditable === active || this.clonedContentEditable.contains(active)) {
            if (!document.execCommand(commandName, true, _arguments)) {
                this.pendingCommand = commandName;
                this.pendingArguments = _arguments;
                return false;
            }
            else {
                this.pendingCommand = undefined;
                this.pendingArguments = undefined;
                return true;
            }
            //} else {
            //}
        };
        return ContentEditable;
    }());
    return ContentEditable;
})());
/// <reference path="../../wwwroot/Define.ts"/>
/// <reference path="../../../../../../node_modules/@types/leaflet/index.d.ts"/>
function animateMarker(map, marker, parameter, speed) {
    //var target = 0;
    var delay = 100;
    var latlng = marker.getLatLng();
    var lat = latlng.lat;
    var lng = latlng.lng;
    var step = (speed * 1000 * delay) / 3600000; // in meters
    var distance = latlng.distanceTo(parameter);
    var numStep = distance / step;
    var i = 0;
    var deltaLat = (parameter.lat - lat) / numStep;
    var deltaLng = (parameter.lng - lng) / numStep;
    var timerId;
    function moveMarker() {
        lat += deltaLat;
        lng += deltaLng;
        i += step;
        if (i < distance) {
            var ll = L.latLng(lat, lng);
            map.panTo(ll);
            marker.setLatLng(ll);
            //@ts-ignore
            timerId = setTimeout(moveMarker, delay);
        }
        else {
            map.panTo(parameter);
            marker.setLatLng(parameter);
            //target++;
            //if (target == coords.length) { target = 0; }
            //setTimeout(goToPoint, delay);
        }
    }
    moveMarker();
    return function () {
        clearTimeout(timerId);
        marker.setLatLng(parameter);
    };
}
Define("TypeScriptLeafletMap", (function () {
    var LeafletMap = /** @class */ (function () {
        function LeafletMap(component, id, options) {
            this.markers = {};
            //polylines: { [key: string]: L.Polyline } = {};
            this.layers = {};
            var fullScreenButton = L.Control.extend({
                options: {
                    position: 'topleft'
                },
                onAdd: function (map) {
                    var element = document.getElementById(id);
                    var container = L.DomUtil.create("div", 'leaflet-bar leaflet-control leaflet-control-custom mdi mdi-fullscreen flex mgc-a fsz-18');
                    container.style.background = 'white';
                    container.style.width = '30px';
                    container.style.height = '30px';
                    var fs = false;
                    container.onclick = function () {
                        fs = !fs;
                        element.requestFullscreen();
                        map.invalidateSize();
                    };
                    return container;
                }
            });
            this.id = id;
            var googleRoadTile = L.tileLayer("https://mt0.google.com/vt/lyrs=m&hl=en&x={x}&y={y}&z={z}&s=Ga", {
                //attribution: `Map data ©${new Date().getFullYear()} Google`,
                maxZoom: 22,
                maxNativeZoom: 18
            });
            var googleSatelliteTile = L.tileLayer("https://mt0.google.com/vt/lyrs=s&hl=en&x={x}&y={y}&z={z}&s=Ga", {
                //attribution: `Map data ©${new Date().getFullYear()} Google`,
                maxZoom: 22,
                maxNativeZoom: 18
            });
            var googleHybridTile = L.tileLayer("https://mt0.google.com/vt/lyrs=y&hl=en&x={x}&y={y}&z={z}&s=Ga", {
                //attribution: `Map data ©${new Date().getFullYear()} Google`,
                maxZoom: 22,
                maxNativeZoom: 18
            });
            var osmTile = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                //attribution: "&copy; <a href=\"https://www.openstreetmap.org/copyright\">OpenStreetMap</a> contributors",
                maxZoom: 22,
                maxNativeZoom: 19
            });
            //var tileGroup = L.layerGroup(new Leaflet.Layer[]
            //{
            //        googleRoadTile,
            //        googleSatelliteTile,
            //        googleHybridTile,
            //        osmTile
            //}, scope.Instantiate<Leaflet.LayerOptions>((scope, options) =>
            //{
            //}));
            var layers = [];
            var dLayer = L.layerGroup(layers, {});
            this.deviceLayer = dLayer;
            var _map = L.map(id, {
                center: L.latLng(options.latitude, options.longitude),
                attributionControl: false,
                zoom: 8,
                maxZoom: 18,
                layers: [
                    googleRoadTile,
                    //googleSatelliteTile,
                    //googleHybridTile,
                    //osmTile
                    dLayer
                ]
            });
            this.map = _map;
            if (options.cluster) {
                this.markerCluster = L.markerClusterGroup({ chunkedLoading: true, /*chunkProgress: updateProgressBar */ });
            }
            var baseLayerObject = {
                "Google Road": googleRoadTile,
                "Google Satellite": googleSatelliteTile,
                "Google Hybrid": googleHybridTile,
                "Open Street Map": osmTile,
            };
            var overlayObject = {
                "Devices": dLayer
            };
            L.control.layers(baseLayerObject, overlayObject, {}).addTo(_map);
            if (options.handleClick) {
                _map.on('click', function (e) {
                    component.invokeMethodAsync("OnClicked", { latitude: e.latlng.lat, longitude: e.latlng.lng });
                });
            }
            this.editableLayer = new L.FeatureGroup();
            _map.addLayer(this.editableLayer);
            if (options.fullScreen) {
                _map.addControl(new fullScreenButton());
            }
            if (options.editable) {
                var _drawOptions = {
                    position: 'topright',
                    draw: {
                        polyline: {
                            shapeOptions: {
                                color: '#f357a1',
                                weight: 10
                            }
                        },
                        polygon: {
                            allowIntersection: false, // Restricts shapes to simple polygons
                            drawError: {
                                color: '#e1e100', // Color the shape will turn when intersects
                                message: '<strong>Oh snap!<strong> you can\'t draw that!' // Message that will show when intersect
                            },
                            shapeOptions: {
                                color: '#bada55'
                            }
                        },
                        circle: true,
                        rectangle: {
                            shapeOptions: {
                                clickable: false
                            }
                        },
                        marker: true
                    },
                    edit: {
                        featureGroup: this.editableLayer, //REQUIRED!!
                        remove: false
                    }
                };
                var control = L.Control;
                var drawControl = new control.Draw(_drawOptions);
                _map.addControl(drawControl);
                var that = this;
                _map.on("draw:created", function (e) {
                    var ev = e;
                    var type = ev.layerType, layer = ev.layer;
                    if (type === 'marker') {
                        var marker = layer;
                        var ll = marker.getLatLng();
                        component.invokeMethodAsync("OnCreated", 2, [{ latitude: ll.lat, longitude: ll.lng }], 0);
                    }
                    else if (type === 'circle') {
                        var circle = layer;
                        var ll = circle.getLatLng();
                        component.invokeMethodAsync("OnCreated", 3, [{ latitude: ll.lat, longitude: ll.lng }], circle.getRadius());
                    }
                    else if (type === 'rectangle') {
                        var rectangle = layer;
                        var lls = rectangle.getLatLngs();
                        component.invokeMethodAsync("OnCreated", 4, [{ latitude: lls[0][0].lat, longitude: lls[0][0].lng }, { latitude: lls[0][2].lat, longitude: lls[0][2].lng }], 0);
                    }
                    else if (type === 'polyline') {
                        var polyline = layer;
                        var llls = polyline.getLatLngs();
                        component.invokeMethodAsync("OnCreated", 5, llls.map(function (ll) { return { latitude: ll.lat, longitude: ll.lng }; }), 0);
                    }
                    else if (type === 'polygon') {
                        var polygon = layer;
                        var lls = polygon.getLatLngs();
                        component.invokeMethodAsync("OnCreated", 6, lls[0].map(function (ll) { return { latitude: ll.lat, longitude: ll.lng }; }), 0);
                    }
                    //that.editableLayer.addLayer(layer);
                });
            }
        }
        LeafletMap.prototype.remove = function (parameter) {
            this.layers[parameter.id].remove();
            delete this.layers[parameter.id];
        };
        LeafletMap.prototype.show = function (parameter) {
            var layer = this.layers[parameter.id];
            //if (parameter.opacity == null || parameter.opacity > 0) {
            if (parameter.editable)
                layer.addTo(this.editableLayer);
            else
                layer.addTo(this.map);
            //} else {
            //    //layer.removeFrom(this.map);
            //    layer.remove();
            //}
        };
        LeafletMap.prototype.label = function (parameter) {
            var layer = this.layers[parameter.id];
            if (parameter.label) {
                layer.bindTooltip(parameter.label, {
                    direction: "bottom",
                    permanent: true,
                    offset: L.point(0, parameter.markerHeight ? parameter.markerHeight / 2 : 0)
                });
            }
        };
        LeafletMap.prototype.createMarker = function (center, parameter) {
            var marker = L.marker(center);
            this.markers[parameter.id] = { marker: marker };
            if (parameter.hasHtmlView) {
                var icon = L.divIcon({
                    html: document.getElementById("".concat(this.id, "-marker-").concat(parameter.id)),
                    iconSize: L.point(parameter.markerWidth, parameter.markerHeight),
                    popupAnchor: L.point(0, -parameter.markerHeight / 2),
                    //options.iconAnchor = new Leaflet.PointExpression(L.point(0, parameter.Get(p => p.MarkerHeight / 2), false));
                });
                marker.setIcon(icon);
            }
            if (parameter.hasPopup) {
                marker.bindPopup(document.getElementById("".concat(this.id, "-popup-").concat(parameter.id)), { className: parameter.className });
            }
            if (parameter.opacity) {
                marker.setOpacity(parameter.opacity);
            }
            else {
                marker.setOpacity(1);
            }
            if (parameter.label) {
                marker.bindTooltip(parameter.label, {
                    direction: "bottom",
                    permanent: true,
                    offset: L.point(0, parameter.markerHeight / 2)
                });
            }
            this.layers[parameter.id] = marker;
            this.show(parameter);
        };
        LeafletMap.prototype.createMarkers = function (markers) {
            for (var _i = 0, markers_1 = markers; _i < markers_1.length; _i++) {
                var marker = markers_1[_i];
                this.createMarker(marker.center, marker.parameter);
            }
        };
        LeafletMap.prototype.removeMarker = function (id) {
            var _a;
            var marker = this.markers[id];
            (_a = marker.animatorDispose) === null || _a === void 0 ? void 0 : _a.call(this);
            marker.marker.remove();
            delete this.markers[id];
        };
        LeafletMap.prototype.removeMarkers = function (ids) {
            for (var _i = 0, ids_1 = ids; _i < ids_1.length; _i++) {
                var id = ids_1[_i];
                this.removeMarker(id);
            }
        };
        LeafletMap.prototype.setMarkerOpacity = function (id, opacity) {
            this.markers[id].marker.setOpacity(opacity);
        };
        LeafletMap.prototype.moveMarker = function (id, parameter, p) {
            var _a;
            var marker = this.markers[id];
            (_a = marker.animatorDispose) === null || _a === void 0 ? void 0 : _a.call(this);
            if (p === null || p === void 0 ? void 0 : p.speed) {
                marker.animatorDispose = animateMarker(this.map, marker.marker, parameter, p.speed);
            }
            else {
                marker.marker.setLatLng(parameter);
            }
        };
        LeafletMap.prototype.moveMap = function (parameter) {
            this.map.panTo(parameter);
        };
        LeafletMap.prototype.fitMap = function (parameter) {
            this.map.fitBounds(parameter);
        };
        LeafletMap.prototype.refresh = function () {
            this.map.invalidateSize();
        };
        LeafletMap.prototype.drawPath = function (path, parameter) {
            var polyline = L.polyline(path, { color: parameter.color || "blue" });
            this.layers[parameter.id] = polyline;
            this.show(parameter);
            this.label(parameter);
            //polyline.addTo(this.map);
        };
        LeafletMap.prototype.addPolyPoint = function (parameter) {
            var polyline = this.layers[parameter.id];
            polyline.addLatLng([parameter.latitude, parameter.longitude]);
        };
        LeafletMap.prototype.drawCircle = function (center, radius, parameter) {
            var circle = L.circle(center, { color: parameter.color || "blue", radius: radius });
            this.layers[parameter.id] = circle;
            this.show(parameter);
            this.label(parameter);
        };
        LeafletMap.prototype.editCircle = function (id, radius, parameter) {
            var circle = (this.layers[id]);
            circle.setRadius(radius);
            circle.setLatLng(parameter);
        };
        LeafletMap.prototype.drawRectangle = function (topLeft, bottomRight, parameter) {
            var rectangle = L.rectangle(L.latLngBounds(topLeft, bottomRight), { color: parameter.color || "blue" });
            this.layers[parameter.id] = rectangle;
            this.show(parameter);
            this.label(parameter);
        };
        LeafletMap.prototype.drawPolygon = function (points, parameter) {
            var polygon = L.polygon(points, { color: parameter.color || "blue" });
            this.layers[parameter.id] = polygon;
            this.show(parameter);
            this.label(parameter);
        };
        LeafletMap.prototype.editPolygon = function (id, points, parameter) {
            var polygon = this.layers[id];
            polygon.setLatLngs(points);
        };
        return LeafletMap;
    }());
    return LeafletMap;
})());
/// <reference path="../../../../../Libraries/LivingThing.Frameworks/LivingThing.Core.Frameworks.Client.Blazor.Library/wwwroot/Define.ts"/>
var clapprs = {};
var clapprsPlaying;
var observer;
var isMuted = true;
Define("vidPlayer", {
    beginStream: function (id, url, features, component) {
        isMuted = true; //new videos are always muted by default if they need to autoplay
        var autoPlay = (features & (1 << 16)) != 0;
        var fullScreen = (features & (1 << 17)) != 0;
        var autoPlayOnScrolledIn = (features & (1 << 18)) != 0;
        var loop = (features & (1 << 19)) != 0;
        observer !== null && observer !== void 0 ? observer : (observer = new IntersectionObserver(function (ee) {
            for (var _i = 0, ee_1 = ee; _i < ee_1.length; _i++) {
                var e = ee_1[_i];
                var player = clapprs[e.target.id];
                if (player) {
                    if (player.isPlaying() && (!e.isIntersecting || e.intersectionRatio < 0.5)) {
                        player.pause();
                    }
                    else if (!player.isPlaying() && player.__autoPlayOnScrolledIn__ && e.isIntersecting && e.intersectionRatio > 0.5) {
                        player.play();
                    }
                }
            }
        }, { threshold: 0.5 }));
        var playerProgress = document.getElementById(id + "-progress");
        var player = new Clappr.Player({
            source: url,
            poster: url + ".poster.jpg", // this poster url is implicit. We currently use a service on the server to generate it to disk on first request.
            parentId: "#" + id,
            autoPlay: autoPlay,
            mimeType: "video/mp4",
            width: '100%',
            height: '100%',
            loop: loop,
            mute: true, //mute to allow autoplay on scrolled in, lest browser will throw
            disableErrorScreen: true, // Disable the internal error screen plugin
            //plugins: [ClapprPip.PipButton, ClapprPip.PipPlugin],
            events: {
                onPlay: function () {
                    player.__isPaused__ = false;
                    component.invokeMethodAsync("VideoEvent", 1, null);
                },
                onPause: function () {
                    player.__isPaused__ = true;
                    component.invokeMethodAsync("VideoEvent", 2, null);
                },
                onStop: function () {
                    player.__isPaused__ = false;
                    component.invokeMethodAsync("VideoEvent", 3, null);
                },
                onEnded: function () {
                    player.__isPaused__ = false;
                    component.invokeMethodAsync("VideoEvent", 4, null);
                },
                onTimeUpdate: function (progress) {
                    if (playerProgress) {
                        var percent = (progress.current / progress.total) * 100;
                        playerProgress.style.width = percent + "%";
                    }
                },
                onError: function (e) {
                    //setTimeout(function () { player.configure(player.options); }, 500);
                }
            }
        });
        player.__isFullScreen__ = false;
        var container = document.getElementById(id);
        //On android the player looses focus on exit fullscreen
        player.on(Clappr.Events.PLAYER_FULLSCREEN, function (isFullscreen) {
            if (!isFullscreen) {
                if (player.__isFullScreen__)
                    container.scrollIntoView();
            }
            player.__isFullScreen__ = isFullscreen;
        });
        var button = container === null || container === void 0 ? void 0 : container.getElementsByClassName("mute-button")[0];
        button === null || button === void 0 ? void 0 : button.addEventListener("click", function () {
            var ids = Object.getOwnPropertyNames(clapprs);
            for (var _i = 0, ids_2 = ids; _i < ids_2.length; _i++) {
                var id = ids_2[_i];
                var container = document.getElementById(id);
                var button = container === null || container === void 0 ? void 0 : container.getElementsByClassName("mute-button")[0];
                button === null || button === void 0 ? void 0 : button.classList.remove("mdi-volume-mute");
                button === null || button === void 0 ? void 0 : button.classList.remove("mdi-volume-high");
                var player = clapprs[id];
                if (player.isReady) {
                    if (isMuted) {
                        player.unmute();
                        button === null || button === void 0 ? void 0 : button.classList.add("mdi-volume-mute");
                    }
                    else {
                        player.mute();
                        button === null || button === void 0 ? void 0 : button.classList.add("mdi-volume-high");
                    }
                }
            }
            isMuted = !isMuted;
            //    button.classList.toggle("mdi-volume-mute");
            //    button.classList.toggle("mdi-volume-high");
        });
        player.__autoPlayOnScrolledIn__ = autoPlayOnScrolledIn;
        player.on('play', function () {
            if (clapprsPlaying && clapprsPlaying !== player && clapprsPlaying.isPlaying()) {
                clapprsPlaying.pause();
            }
            clapprsPlaying = player;
        });
        clapprs[id] = player;
        var element = document.getElementById(id);
        if (element) {
            //var observer = new IntersectionObserver(function (ee) {
            //    for (var e of ee) {
            //        if (!e.isIntersecting || e.intersectionRatio < 0.5) {
            //            player.pause();
            //        }
            //    }
            //}, { threshold: 0.5 });
            observer.observe(element);
        }
        setTimeout(function () {
            if (autoPlay)
                player.play();
            if (fullScreen) {
                player.core.mediaControl.toggleFullscreen();
            }
        }, 500);
    },
    seekTo: function (id, ratio) {
        var player = clapprs[id];
        player.seek(ratio * player.getDuration());
    },
    pipStream: function (id) {
        var pip = window["pip"]; //.pip;
        if (pip) {
            pip.destroy();
        }
        var player = clapprs[id];
        player.enterPictureInPicture();
        window["pip"] = player;
        //window.pip = player;
    },
    destroyStream: function (id) {
        var player = clapprs[id];
        //if (player.isPlaying()) {
        //    pipStream(id);
        //} else {
        if (player == window["pip"]) {
            delete window["pip"];
        }
        //if (player == window.pip) {
        //    delete window.pip;
        //}
        player.destroy();
        delete clapprs[id];
        //}
    },
    playPause: function (id) {
        var player = clapprs[id];
        if (player.isPlaying()) {
            player.pause();
        }
        else {
            player.play();
        }
        clapprsPlaying = player;
    },
    streamFullScreen: function (id, go) {
        var player = clapprs[id];
        player.core.mediaControl.toggleFullscreen();
    }
    //var handler;
    ////var backHandler;
    ////var noMoreBack = false;
    //function handleButtons(component) {
    //    if (handler) {
    //        document.removeEventListener("keydown", handler);
    //        //document.removeEventListener("backbutton", backHandler);
    //    }
    //    handler = function (key) {
    //        //console.log(event);
    //        var keys = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Enter", "Back"];
    //        if (keys.includes(key.key)) {
    //            if (key.key != "Enter") {
    //                key.preventDefault();
    //            }
    //            component.invokeMethodAsync("ButtonPressed", key.key);
    //            buttonTick();
    //        }
    //    };
    //    //backHandler = function (ev) {
    //    //    if (!noMoreBack) {
    //    //        ev.preventDefault();
    //    //        result = component.invokeMethodAsync("ButtonPressed", "Back");
    //    //        result.then(function (backed) {
    //    //            noMoreBack = !backed;
    //    //        });
    //    //    }
    //    //};
    //    document.addEventListener("keydown", handler);
    //    //document.addEventListener('backbutton', backHandler);
    //}
    //var player;
    //function buttonTick() {
    //    if (!player) {
    //        player = new Audio();
    //    }
    //    player.src = "_content/LivingThing.Core.Community.TV.App.Blazor/tone.wav";
    //    player.play();
    //}
});
var _mediaRecorder;
var _chunks;
var _stream;
Define("audioRecorder", {
    recordAudioStart: function () {
        return new Promise(function (resolve) {
            try {
                // already recording
                if (_mediaRecorder && _mediaRecorder.state === 'recording') {
                    resolve(true);
                    return;
                }
                navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
                    var options = {};
                    // prefer webm if supported
                    if (MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
                        options.mimeType = 'audio/webm;codecs=opus';
                    }
                    var mediaRecorder = new MediaRecorder(stream, options);
                    var chunks = [];
                    mediaRecorder.ondataavailable = function (e) {
                        if (e.data && e.data.size > 0)
                            chunks.push(e.data);
                    };
                    mediaRecorder.onstop = function () {
                        // keep stream so stop() can be called explicitly later
                    };
                    _mediaRecorder = mediaRecorder;
                    _chunks = chunks;
                    _stream = stream;
                    mediaRecorder.start();
                    resolve(true);
                }).catch(function (err) {
                    console.error('recordAudioStart error', err);
                    resolve(false);
                });
            }
            catch (e) {
                console.error('recordAudioStart exception', e);
                resolve(false);
            }
        });
    },
    recordAudioStop: function () {
        return new Promise(function (resolve) {
            try {
                var mr = _mediaRecorder;
                var chunks = _chunks;
                var stream = _stream;
                if (!mr) {
                    resolve(null);
                    return;
                }
                var finish = function (blob) {
                    return __awaiter(this, void 0, void 0, function () {
                        var arrBuf, bytes, binary, chunkSize, i, sub, b64, mime, e_1;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    _a.trys.push([0, 2, , 3]);
                                    return [4 /*yield*/, blob.arrayBuffer()];
                                case 1:
                                    arrBuf = _a.sent();
                                    bytes = new Uint8Array(arrBuf);
                                    binary = '';
                                    chunkSize = 0x8000;
                                    for (i = 0; i < bytes.length; i += chunkSize) {
                                        sub = bytes.subarray(i, i + chunkSize);
                                        binary += String.fromCharCode.apply(null, Array.prototype.slice.call(sub));
                                    }
                                    b64 = btoa(binary);
                                    mime = blob.type || 'audio/webm';
                                    resolve('data:' + mime + ';base64,' + b64);
                                    return [3 /*break*/, 3];
                                case 2:
                                    e_1 = _a.sent();
                                    console.error('finish conversion error', e_1);
                                    resolve(null);
                                    return [3 /*break*/, 3];
                                case 3: return [2 /*return*/];
                            }
                        });
                    });
                };
                var onStopped = function () {
                    try {
                        var blob = new Blob(chunks, { type: (mr.mimeType || 'audio/webm') });
                        // stop tracks
                        try {
                            if (stream && stream.getTracks) {
                                stream.getTracks().forEach(function (t) { return t.stop(); });
                            }
                        }
                        catch (e) { }
                        // clear state
                        _mediaRecorder = null;
                        _chunks = null;
                        _stream = null;
                        finish(blob);
                    }
                    catch (e) {
                        console.error('recordAudioStop finish error', e);
                        resolve(null);
                    }
                };
                if (mr.state === 'recording') {
                    mr.onstop = onStopped;
                    mr.stop();
                }
                else {
                    // not recording but we may have chunks
                    var blob = new Blob(chunks || [], { type: (mr.mimeType || 'audio/webm') });
                    // stop tracks
                    try {
                        if (stream && stream.getTracks)
                            stream.getTracks().forEach(function (t) { return t.stop(); });
                    }
                    catch (e) { }
                    _mediaRecorder = null;
                    _chunks = null;
                    _stream = null;
                    finish(blob);
                }
            }
            catch (e) {
                console.error('recordAudioStop exception', e);
                try {
                    if (_stream && _stream.getTracks) {
                        _stream.getTracks().forEach(function (t) { return t.stop(); });
                    }
                }
                catch (ee) { }
                _mediaRecorder = null;
                _chunks = null;
                _stream = null;
                resolve(null);
            }
        });
    }
});
/// <reference path="../../Assets/Assets.razor.ts"></reference>
function computeBestPopupPosition(activatorBox, tipSize, popup) {
    popup.style.visibility = "hidden";
    popup.style.display = "unset";
    var popupBox = popup.getBoundingClientRect();
    var viewPortBox = document.body.getBoundingClientRect();
    viewPortBox.scrollWidth = document.body.scrollWidth;
    viewPortBox.scrollHeight = document.body.scrollHeight;
    if (popupBox.width > viewPortBox.width)
        popupBox.width = viewPortBox.width;
    if (popupBox.height > viewPortBox.height)
        popupBox.height = viewPortBox.height;
    var leftOffset;
    var rightOffset;
    var topOffset;
    var bottomOffset;
    var tipPosition;
    var side = null;
    var leftSpace = activatorBox.left;
    var rightSpace = viewPortBox.width - activatorBox.right;
    var topSpace = activatorBox.top;
    var bottomSpace = viewPortBox.scrollHeight - activatorBox.bottom;
    var useHorizontal;
    var spaces = [leftSpace, rightSpace, topSpace, bottomSpace];
    var max = spaces[0];
    var max_i = 0;
    spaces.forEach(function (s, i) {
        if (s > max) {
            max = s;
            max_i = i;
        }
    });
    if (max_i == 0 || max_i == 1) {
        useHorizontal = true;
    }
    else {
        useHorizontal = false;
    }
    if (useHorizontal) {
        if (leftSpace > rightSpace) {
            leftOffset = activatorBox.left - popupBox.width - tipSize;
            side = "righttoleft";
        }
        else {
            leftOffset = activatorBox.left + activatorBox.width;
            side = "lefttoright";
        }
        topOffset = activatorBox.top + (activatorBox.height / 2) - (popupBox.height / 2);
        if (topOffset < 0)
            topOffset = 0;
        if (topOffset + popupBox.height >= viewPortBox.height) {
            topOffset = viewPortBox.height - popupBox.height;
            if (topOffset < 0)
                topOffset = 0;
            var diff = activatorBox.top - topOffset + (activatorBox.height / 2) - (tipSize / 2);
            if (diff < 0)
                diff = 0;
            tipPosition = diff + "px";
        }
    }
    else {
        if (topSpace > bottomSpace) {
            topOffset = activatorBox.top - popupBox.height - tipSize;
            side = "bottomtotop";
        }
        else {
            topOffset = activatorBox.top + activatorBox.height;
            side = "toptobottom";
        }
        leftOffset = activatorBox.left + (activatorBox.width / 2) - (popupBox.width / 2);
        if (leftOffset < 0)
            leftOffset = 0;
        if (leftOffset + popupBox.width >= viewPortBox.width) {
            leftOffset = viewPortBox.width - popupBox.width;
            if (leftOffset < 0)
                leftOffset = 0;
            var diff = activatorBox.left - leftOffset + (activatorBox.width / 2) - (tipSize / 2);
            if (diff < 0)
                diff = 0;
            tipPosition = diff + "px";
        }
    }
    if (topOffset != undefined) {
        popup.style.top = topOffset + "px";
    }
    if (bottomOffset != undefined) {
        popup.style.bottom = bottomOffset + "px";
    }
    if (leftOffset != undefined) {
        popup.style.left = leftOffset + "px";
    }
    if (rightOffset != undefined) {
        popup.style.right = rightOffset + "px";
    }
    if (tipPosition != undefined) {
        popup.style.setProperty("--tip-position", tipPosition);
    }
    popup.classList.remove("toptobottom", "bottomtotop", "lefttoright", "righttoleft");
    popup.classList.add(side);
    popup.style.display = "";
    popup.style.visibility = "";
    return { leftOffset: leftOffset, topOffset: topOffset, side: side };
}
Define("popupInit", function (popup, activator, target, action) {
    var timer;
    activator.addEventListener(action === "hover" ? "mouseover" : "click", function () {
        var activatorBox = activator.getBoundingClientRect();
        computeBestPopupPosition(activatorBox, 10, target);
        activator.classList.add("show");
        timer = setInterval(function () {
            var newActivatorBox = activator.getBoundingClientRect();
            if (Math.abs(newActivatorBox.left - activatorBox.left) > 5 || Math.abs(newActivatorBox.top - activatorBox.top) > 5) {
                computeBestPopupPosition(newActivatorBox, 10, target);
                activatorBox = newActivatorBox;
            }
        }, 10);
    });
    activator.addEventListener(action === "hover" ? "mouseout" : "focusout", function () {
        clearTimeout(timer);
        activator.classList.remove("show");
    });
});
/// <reference path="../../Assets/Assets.razor.ts"></reference>
Define("scrollProgress", function (element, step, features, scrollProgress) {
    var last = 0;
    var reference = 0;
    var wasLess = true;
    if ((features & (1 << 3)) != 0) {
        reference = step;
        step = 0;
    }
    element.addEventListener("scroll", function () {
        var scrollTop = element.scrollTop;
        var clientHeight = element.clientHeight;
        var scrollHeight = element.scrollHeight;
        var percentage = scrollTop * 100 / (scrollHeight - clientHeight);
        if (percentage < 0)
            percentage = 0;
        if (percentage > 100)
            percentage = 100;
        if (reference != 0) {
            if ((wasLess && percentage > reference) || (!wasLess && percentage < reference)) {
                wasLess = percentage < reference;
                scrollProgress.invokeMethodAsync("SetProgress", percentage);
            }
        }
        else if (Math.abs(percentage - last) > step || (percentage == 0 && last != 0)) {
            scrollProgress.invokeMethodAsync("SetProgress", percentage);
            last = percentage;
        }
    });
});
/// <reference path="../../Assets/Assets.razor.ts"></reference>
Define("theme", {
    variables: [
        "--primary-background-color",
        "--primary-foreground-color",
        "--secondary-background-color",
        "--secondary-foreground-color",
        "--tertiary-background-color",
        "--tertiary-foreground-color",
        "--success-background-color",
        "--success-foreground-color",
        "--warning-background-color",
        "--warning-foreground-color",
        "--error-background-color",
        "--error-foreground-color",
        "--fatal-background-color",
        "--fatal-foreground-color",
        "--message-background-color",
        "--message-foreground-color",
        "--info-background-color",
        "--info-foreground-color",
        "--active-background-color",
        "--card-background-color",
        "--hover-background-color",
        "--shadow-background-color",
        "--border-background-color",
        "--text-background-color",
        "--heading-background-color",
        "--chart-color-\*"
    ],
    octet: function (val) {
        var hex = "0123456789ABCDEF";
        var u = val % 16;
        var t = Math.trunc(val / 16);
        return hex[t] + hex[u];
    },
    hex2Dec: function (val) {
        var n = 0;
        function charToDec(c) {
            switch (c) {
                case '0':
                    return 0;
                case '1':
                    return 1;
                case '2':
                    return 2;
                case '3':
                    return 3;
                case '4':
                    return 4;
                case '5':
                    return 5;
                case '6':
                    return 6;
                case '7':
                    return 7;
                case '8':
                    return 8;
                case '9':
                    return 9;
                case 'A':
                case 'a':
                    return 10;
                case 'B':
                case 'b':
                    return 11;
                case 'C':
                case 'c':
                    return 12;
                case 'D':
                case 'd':
                    return 13;
                case 'E':
                case 'e':
                    return 14;
                case 'F':
                case 'f':
                    return 15;
            }
            return 0;
        }
        for (var i = 0; i < val.length; i++) {
            n = n * 16;
            n += charToDec(val[i]);
        }
        return n;
    },
    hexColor: function (value) {
        var _this = this;
        if (value.startsWith("#"))
            return value;
        var vals = value.split(",").map(function (v) { return _this.octet(parseInt(v.trim())); });
        return "#" + vals.join("");
    },
    get: function () {
        var data = {};
        var v;
        for (var _i = 0, _a = this.variables; _i < _a.length; _i++) {
            v = _a[_i];
            var split = v.split("-").filter(function (v) { return v.length > 0; }).map(function (token, i) {
                if (i == 0)
                    return token;
                var c = token[0];
                c = c.toUpperCase();
                return c + token.substr(1);
                ;
            });
            var propertyName = split.join("");
            if (propertyName.endsWith("*")) {
                var name = propertyName.replace("*", "");
                var values = [];
                for (var i = 0;; i++) {
                    var mname = v.replace("*", "") + (i + 1);
                    var value = getComputedStyle(document.documentElement).getPropertyValue(mname);
                    if (!value)
                        break;
                    values.push(this.hexColor(value.trim()));
                }
                data[propertyName.replace("*", "s")] = values;
            }
            else {
                data[propertyName] = this.hexColor(getComputedStyle(document.documentElement).getPropertyValue(v).trim());
            }
        }
        return data;
    },
    set: function (theme) {
        if (theme && typeof (theme) == 'string') {
            document.documentElement.classList.forEach(function (c) {
                if (c.endsWith("-theme")) {
                    document.documentElement.classList.remove(c);
                }
            });
            document.documentElement.classList.add(theme + "-theme");
            window.lt.setCookie("theme", theme);
        }
        else {
            var v = void 0;
            for (var _i = 0, _a = this.variables; _i < _a.length; _i++) {
                v = _a[_i];
                var split = v.split("-").filter(function (v) { return v.length > 0; }).map(function (token, i) {
                    if (i == 0)
                        return token;
                    var c = token[0];
                    c = c.toUpperCase();
                    return c + token.substr(1);
                });
                var propertyName = split.join("");
                if (propertyName.endsWith("*")) {
                    var name = propertyName.replace("*", "");
                    var values = theme != null ? theme[propertyName.replace("*", "s")] : null;
                    if (values) {
                        for (var i = 0; i < values.length; i++) {
                            var mname = name + i;
                            document.documentElement.style.setProperty(mname, values[i]);
                        }
                    }
                }
                else if (theme && theme[propertyName]) {
                    var color = theme[propertyName];
                    if (color.startsWith('#')) {
                        color = color.substring(1);
                    }
                    var r = color.length == 3 ? color.substring(0, 1) + color.substring(0, 1) : color.substring(0, 2);
                    var g = color.length == 3 ? color.substring(1, 2) + color.substring(1, 2) : color.substring(2, 4);
                    var b = color.length == 3 ? color.substring(2, 3) + color.substring(2, 3) : color.substring(4, 6);
                    var rr = this.hex2Dec(r);
                    var gg = this.hex2Dec(g);
                    var bb = this.hex2Dec(b);
                    document.documentElement.style.setProperty(v, rr + ", " + gg + ", " + bb);
                }
                else {
                    document.documentElement.style.removeProperty(v);
                }
            }
        }
        return this.get();
    }
});
Define("font", {
    set: function (font, variableName) {
        window.lt.assets([font.link], []);
        if (!this.initialFontName) {
            this.initialFontName = getComputedStyle(document.documentElement).getPropertyValue(variableName || "--font");
        }
        document.documentElement.style.setProperty(variableName || "--font", font.name);
        window.lt.setCookie("font", font.name);
    },
    reset: function (variableName) {
        if (this.initialFontName) {
            document.documentElement.style.setProperty(variableName || "--font", this.initialFontName);
        }
    },
    setSize: function (fontSize) {
        //TODO: dont want user setting extraneous font-size
        //document.documentElement.style.setProperty("--font-size", fontSize);
    }
});
/// <reference path="../../Assets/Assets.razor.ts"></reference>
Define("tooltip", function () {
    var tooltip = document.getElementById("tooltip");
    function tooltipSubscribe(element) {
        function show(e) {
            tooltip.style.visibility = 'hidden';
            tooltip.classList.add("show");
            tooltip.innerHTML = e.target.title;
            var activatorBox = e.target.getBoundingClientRect();
            computeBestPopupPosition(activatorBox, 4, tooltip);
            //this.dataset.originalTitle = this.title; // Store original title in a data attribute
            //this.title = ''; // Clear the title to hide the tooltip
        }
        function hide() {
            tooltip.style.left = "-1000px";
            tooltip.style.top = "-1000px";
            tooltip.classList.remove("show");
            //this.title = this.dataset.originalTitle; // Restore the original title
        }
        if (element.title.length > 0) {
            element.addEventListener('mouseenter', show);
            element.addEventListener('focus', show);
            element.addEventListener('mouseleave', hide);
            element.addEventListener('blur', hide);
            //window.addEventListener("scroll", hide);
        }
    }
    var mutationObserver = new MutationObserver(function (mutations) {
        mutations.forEach(function (mutation) {
            mutation.addedNodes.forEach(function (node) {
                var _a;
                if (((_a = node.title) === null || _a === void 0 ? void 0 : _a.length) > 0) {
                    tooltipSubscribe(node);
                }
            });
        });
    });
    mutationObserver.observe(document.body, { childList: true, subtree: true, attributeFilter: ["title"] });
    var titles = document.querySelectorAll("*[title]");
    titles.forEach(function (i) {
        if (i.title && i.title.length > 0) {
            tooltipSubscribe(i);
        }
    });
});
/// <reference path="../../wwwroot/Define.ts"/>
var component;
var players;
Define("player", {
    init: function (_component) {
        component = _component;
        players = [new Audio(), new Audio()];
        var oldValue;
        setInterval(function () {
            var value = {
                position: players[0].currentTime,
                duration: players[0].duration || 0,
                flags: (players[0].paused ? 1 << 0 : 0) | (players[0].ended ? 1 << 1 : 0) | (players[0].muted ? 1 << 2 : 0) | (players[0].loop ? 1 << 3 : 0),
                file: players[0].currentSrc
            };
            if ((!oldValue && value.file.length > 0) ||
                (oldValue && (oldValue.position != value.position ||
                    oldValue.duration != value.duration ||
                    oldValue.flags != value.flags ||
                    oldValue.file != value.file))) {
                _component.invokeMethodAsync("Progress", value);
                oldValue = value;
            }
        }, 2000);
    },
    play: function (i, files, loop) {
        var _a;
        if (files) {
            var file = files[0];
            if (file.startsWith("/"))
                file = file.substring(1);
            var uri = ((_a = players[i].src) === null || _a === void 0 ? void 0 : _a.length) > 0 ? new URL(players[i].src) : null;
            if ((uri === null || uri === void 0 ? void 0 : uri.pathname.substring(1)) != file)
                players[i].src = file;
        }
        if (loop !== undefined)
            players[i].loop = loop;
        if (i != 0) {
            var volume = players[0].volume;
            players[0].volume = volume / 4;
            var ended = function () {
                players[0].volume = 1; // volume;
                players[i].removeEventListener("ended", ended);
            };
            players[i].addEventListener("ended", ended);
        }
        players[i].play();
    },
    update: function (i, flags) {
        players[i].muted = (flags & (1 << 2)) != 0;
        players[i].loop = (flags & (1 << 3)) != 0;
    },
    pause: function (i) {
        players[i].pause();
    },
    stop: function (i) {
        players[i].currentTime = 0;
        players[i].pause();
        players[i].src = null;
        //player.stop();
    },
    set: function (i, value) {
        players[i].currentTime = value;
        var _value = {
            position: players[i].currentTime,
            duration: players[i].duration || 0,
            flags: (players[i].paused ? 1 << 0 : 0) | (players[i].ended ? 1 << 1 : 0) | (players[i].muted ? 1 << 2 : 0) | (players[i].loop ? 1 << 3 : 0),
            file: players[i].currentSrc
        };
        component.invokeMethodAsync("Progress", _value);
    }
});
/// <reference path="../../Assets/Assets.razor.ts"></reference>
Define("visibleInit", function (box, dom, ratio) {
    var observer = new IntersectionObserver(function (entries) {
        if (!entries.some(function (entry) {
            if (entry.isIntersecting) {
                box.invokeMethodAsync("Show", true);
                return true;
            }
            return false;
        })) {
            box.invokeMethodAsync("Show", false);
        }
    }, { threshold: ratio || 0.5 });
    observer.observe(dom);
});
;
Define("log", function (message, type) {
    var method = console[type];
    if (method) {
        method(message);
    }
    else {
        console.log(message);
    }
});
Define("logs", function (logs) {
    for (var _i = 0, logs_1 = logs; _i < logs_1.length; _i++) {
        var log = logs_1[_i];
        var method = console[log.type];
        if (method) {
            method(log.message);
        }
        else {
            console.log(log.message);
        }
    }
});
Define("anonymous", function (funcBody, argsName, args) {
    //const args: Array<any> = Array.prototype.slice.call(arguments);
    var _function = new Function(argsName, funcBody);
    return _function.apply(this, args);
});
Define("snapScrollNext", function (element) {
    var ref = element.classList.contains("snap-items") ? element : null;
    if (ref == null) {
        element.childNodes.forEach(function (e) {
            if (ref == null && e instanceof HTMLElement && e.classList.contains("snap-items")) {
                ref = e;
            }
        });
    }
    if (ref != null) {
        var itemHeight = (ref.childNodes[0]).clientHeight;
        var ch = ref.clientHeight;
        var scrollHeight = ref.scrollHeight;
        var sscrollTop = ref.scrollTop;
        var items = (scrollHeight / itemHeight);
        var n = sscrollTop / itemHeight;
        var scrollTo;
        //if (scrollingDown) {
        scrollTo = Math.trunc(n) + 1;
        //} else {
        //scrollTo = Math.trunc(n);
        //}
        ref.scrollTo(0, scrollTo * ch);
    }
});
Define("proxy", {
    scopes: {},
    gens: {},
    storeProcedure: function (gkey, skey, code, parameters) {
        var scope = { f: new Function("p", "x", code), p: parameters };
        this.scopes[skey] = scope;
        this.gens[gkey] = { x: {} };
    },
    execute: function (code, parameters, gkey, skey) {
        var fun = new Function("p", "x", code);
        var gen;
        if (skey !== null) {
            gen = this.gens[gkey] = { x: {} };
            this.scopes[skey] = { f: fun };
        }
        var returns = fun.call(fun, parameters, gen.x);
        return returns;
    },
    executeStored: function (gkey, skey, parameters) {
        var scope = this.scopes[skey];
        var gen = this.gens[gkey];
        var p = __assign(__assign({}, scope.p), parameters);
        var returns = scope.f.call(scope.f, p, gen.x);
        return returns;
    },
    createClass: function (gkey, skey, parameters) {
        var scope = this.scopes[skey];
        var gen = this.gens[gkey];
        var p = __assign(__assign({}, scope.p), parameters);
        var mclass = scope.f.call(scope.f, p, gen.x);
        scope.class = mclass;
    },
    callMember: function (gkey, skey, member, parameters) {
        var scope = this.scopes[skey];
        var gen = this.gens[gkey];
        var p = __assign(__assign({}, scope.p), parameters);
        var method = scope.class[member];
        var returns = method.call(scope.class, p, gen.x);
        returns;
    }
});
Define("setTitle", function (title) {
    document.title = title;
});
Define("setCookie", function (name, value, exdate, path) {
    (exdate) && (exdate = new Date(exdate).toUTCString());
    var c_value = escape(value) +
        ((exdate === null || exdate === undefined) ? "; expires=" + new Date('2099-01-03T15:50:48.521Z').toUTCString() : "; expires=" + exdate) +
        ((path === null || path === undefined) ? "; Path=/" : "; Path=" + path);
    document.cookie = name + '=' + c_value;
});
Define("setCookies", function (cookies) {
    cookies.forEach(function (cookie) {
        document.cookie = cookie;
    });
});
Define("getCookie", function (name) {
    var value = "; ".concat(document.cookie);
    var parts = value.split("; ".concat(name, "="));
    if (parts.length === 2) {
        return parts.pop().split(';').shift();
    }
    return null;
});
Define("removeCookie", function (name) {
    document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
});
Define("reload", function () {
    window.location.reload();
});
Define("scrollTo", function (element, mustScroll) {
    if (typeof (element) === "number") {
        document.documentElement.scrollTo({ top: element, behavior: mustScroll ? "smooth" : "instant" });
    }
    else {
        if (mustScroll)
            element.scrollIntoView();
        else
            element.scrollIntoViewIfNeeded();
        element.focus();
    }
});
Define("focus", function (element) {
    element.focus();
});
Define("focusOut", function (element) {
    element.blur();
});
var tabableInited;
Define("tabableInit", function () {
    if (tabableInited)
        return;
    var observer = new MutationObserver(function (changes) {
        changes.forEach(function (change) {
            if (change.type == "attributes" && change.attributeName == "class") {
                if (change.target.classList.contains("tabfocus")) {
                    change.target.scrollIntoViewIfNeeded();
                    change.target.focus();
                }
                else {
                    change.target.blur();
                }
            }
        });
    });
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["class"]
    });
    tabableInited = true;
});
Define("getLocation", function () {
    return new Promise(function (accept, reject) {
        function gotPosition(position) {
            accept({ latitude: position.coords.latitude, longitude: position.coords.longitude, accuracy: position.coords.accuracy });
        }
        function errPosition(err) {
            reject(err.message);
        }
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(gotPosition, errPosition);
        }
        else {
            reject("Geolocation is not supported by this browser");
        }
    });
});
//Define("_localStorage", {
//    getItem: function (key) {
//        console.log("get " + key);
//        return localStorage.getItem(key);
//    },
//    setItem: function (key, value) {
//        return localStorage.setItem(key, value);
//    },
//    removeItem: function (key) {
//        return localStorage.remove(key);
//    }
//});
function callWasm() {
    //return DotNet.invokeMethodAsync('LivingThing.Web.Client.Blazor.Library.WebAssembly', 'Dispatch', arguments);
}
var nativePromises = {};
var native;
Define("callNative", function () {
    native.invoke(JSON.stringify(arguments[0]));
    if (arguments[1]) {
        var id = arguments[0].i;
        var promise = new Promise(function (resolve, reject) {
            nativePromises[id] = { resolve: resolve, reject: reject };
        });
        return promise;
    }
});
Define("completeNative", function (id, value, err) {
    var promise = nativePromises[id];
    delete nativePromises[id];
    if (value) {
        promise.resolve(value);
    }
    if (err) {
        promise.reject(err);
    }
});
//Define("localStorage", function () {
//    return localStorage;
//});
Define("get", function (method, target) {
    if (target) {
        var fn = new Function(method);
        return fn.apply(target);
    }
    return eval(method);
});
Define("promiseFnCall", function () {
    var _a;
    var argLen = arguments.length;
    var methodName = arguments[argLen - 2];
    var callback = arguments[argLen - 1];
    var pathsToMethod = methodName.split('.');
    var where = window;
    for (var i = 0; i < pathsToMethod.length; i++) {
        var m = pathsToMethod[i];
        if (m == 'window' && i == 0) {
            where = window;
        }
        else {
            where = where[m];
        }
    }
    var method = where;
    var promise = (_a = method).call.apply(_a, __spreadArray([null], arguments, false));
    promise.then(function (result) {
        callback.jsRunner.invokeMethodAsync("CompletePromise", callback.id, JSON.stringify(result), null);
    }).catch(function (e) {
        callback.jsRunner.invokeMethodAsync("CompletePromise", callback.id, null, e.error);
    });
});
Define("waitForScriptLoad", function (methodNames) {
    return new Promise(function (resolve, reject) {
        var timer;
        timer = setInterval(function () {
            if (methodNames.every(function (methodName) {
                var pathsToMethod = methodName.split('.');
                var where = window;
                for (var i = 0; i < pathsToMethod.length; i++) {
                    var m = pathsToMethod[i];
                    if (m == 'window' && i == 0) {
                        where = window;
                    }
                    else {
                        where = where[m];
                    }
                    if (where == undefined)
                        break;
                }
                return where != undefined;
            })) {
                resolve(null);
                clearInterval(timer);
            }
        }, 100);
    });
});
Define("printElement", function (el, delay) {
    if (el) {
        if (typeof el == 'string') {
            el = document.getElementById(el);
        }
        var divContents = el.outerHTML;
        var a = window.open('', '', 'height=500, width=800');
        if (a) {
            a.document.write('<html class="ltroot">');
            a.document.write('<head>');
            var links = document.head.getElementsByTagName("link");
            for (var i = 0; i < links.length; i++) {
                a.document.write(links.item(i).outerHTML);
            }
            //a.document.write('<link href="/_content/LivingThing.Core.Frameworks.Client.Blazor/LivingThing.Core.Frameworks.Client.min.css" rel="stylesheet">');
            a.document.write('</head>');
            a.document.write('<body>');
            a.document.write(divContents);
            a.document.write('</body></html>');
            a.document.close();
            //wait a little while for css to load else it isnt applies
            setTimeout(function () {
                a.print();
            }, delay || 500);
            return true;
        }
    }
    return false;
});
Define("downloadFileFromStream", function (fileName, contentStreamReference) {
    return __awaiter(this, void 0, void 0, function () {
        var arrayBuffer, blob, url, anchorElement;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, contentStreamReference.arrayBuffer()];
                case 1:
                    arrayBuffer = _a.sent();
                    blob = new Blob([arrayBuffer]);
                    url = URL.createObjectURL(blob);
                    anchorElement = document.createElement('a');
                    anchorElement.href = url;
                    anchorElement.download = fileName !== null && fileName !== void 0 ? fileName : '';
                    anchorElement.click();
                    anchorElement.remove();
                    URL.revokeObjectURL(url);
                    return [2 /*return*/];
            }
        });
    });
});
Define("getTimeZone", function () {
    return window.Intl.DateTimeFormat().resolvedOptions().timeZone;
});
Define("getSize", function (element) {
    if (element == null)
        return null;
    var domRect = element.getBoundingClientRect();
    domRect.scrollLeft = element.scrollLeft;
    domRect.scrollTop = element.scrollTop;
    return domRect;
});
Define("openWindow", {
    _window: {},
    open: function (options, component) {
        options.windowName = options.windowName || 'ConnectWithOAuth'; // should not include space for IE
        options.windowOptions = options.windowOptions || 'location=0,status=0,width=800,height=400';
        var that = this;
        console.log(options.path);
        this._window = window;
        this._window = window.open(options.path, options.windowName, options.windowOptions);
        that._oauthInterval = window.setInterval(function () {
            var _a;
            if ((_a = that._window) === null || _a === void 0 ? void 0 : _a.closed) {
                window.clearInterval(that._oauthInterval);
                component.invokeMethodAsync("WindowClosed");
            }
        }, 1000);
    },
    close: function () {
        this._window.close();
    }
});
function base64ToBytes(base64) {
    var key = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var newBytes = [];
    var currentChar = 0;
    var currentByte = 0;
    for (var i = 0; i < base64.length; i++) { // Go over four 6-bit base64 chars to decode into three 8-bit bytes
        currentChar = key.indexOf(base64[i]);
        if (i % 4 === 0) { // First base64 char
            currentByte = (currentChar << 2); // Get the 6-bits from first base64 char
        }
        if (i % 4 === 1) { // Second base64 char
            currentByte += (currentChar >> 6); // Concat the first 2-bits from second base64 char
            newBytes.push(currentByte); // Push the first byte
            currentByte = (currentChar & 15) << 4; // Erase bits before last 4-bits, add last 4-bits for second byte
        }
        if (i % 4 === 2) { // Third base64 char
            currentByte += (currentChar >> 2); // Concat first 4-bits from third base64 char for second byte
            newBytes.push(currentByte); // Push second byte
            currentByte = (currentChar & 3) << 6; // Erase bits before last 2-bits, add last 2-bits for third byte
        }
        if (i % 4 === 3) { // Fourth base64 char
            currentByte += (currentChar); // Concat fourth base64 char for third byte
            newBytes.push(currentByte); // Push third byte
        }
    }
    if (newBytes[newBytes.length - 1] === -1) { // Remove single padding from the end (=)
        newBytes.pop();
    }
    if (newBytes[newBytes.length - 2] === -1) { // Remove double padding from the end (==)
        newBytes.pop();
        newBytes.pop();
    }
    return new Uint8Array(newBytes);
}
function bytesToBase64(_bytes) {
    var key = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var bytes = _bytes instanceof Uint8Array ? _bytes : new Uint8Array(_bytes);
    var newBase64 = '';
    var currentChar = 0;
    for (var i = 0; i < bytes.length; i++) { // Go over three 8-bit bytes to encode four base64 6-bit chars
        if (i % 3 === 0) { // First Byte
            currentChar = (bytes[i] >> 2); // First 6-bits for first base64 char
            newBase64 += key[currentChar]; // Add the first base64 char to the string
            currentChar = (bytes[i] << 4) & 63; // Erase first 6-bits, add first 2 bits for second base64 char
        }
        if (i % 3 === 1) { // Second Byte
            currentChar += (bytes[i] >> 4); // Concat first 4-bits from second byte for second base64 char
            newBase64 += key[currentChar]; // Add the second base64 char to the string
            currentChar = (bytes[i] << 2) & 63; // Add two zeros, add 4-bits from second half of second byte
        }
        if (i % 3 === 2) { // Third Byte
            currentChar += (bytes[i] >> 6); // Concat first 2-bits of third byte for the third base64 char
            newBase64 += key[currentChar]; // Add the third base64 char to the string
            currentChar = bytes[i] & 63; // Add last 6-bits from third byte for the fourth base64 char
            newBase64 += key[currentChar]; // Add the fourth base64 char to the string
        }
    }
    if (bytes.length % 3 === 1) { // Pad for two missing bytes
        newBase64 += "".concat(key[currentChar], "==");
    }
    if (bytes.length % 3 === 2) { // Pad one missing byte
        newBase64 += "".concat(key[currentChar], "=");
    }
    return newBase64;
}
Define("localStorage", {
    setItem: function (key, value) {
        if (value instanceof Uint8Array) {
            value = "base64-" + bytesToBase64(value);
        }
        localStorage.setItem(key, value);
    },
    itemTypeIsByteArray: function (key) {
        var v = localStorage.getItem(key);
        if (v != null && v.startsWith("base64-")) {
            return true;
        }
        return false;
    },
    getItem: function (key) {
        var v = localStorage.getItem(key);
        if (v != null && v.startsWith("base64-")) {
            v = v.substring(7);
            return base64ToBytes(v);
        }
        return v;
    },
    removeItem: function (key) {
        localStorage.removeItem(key);
    },
    clear: function () {
        localStorage.clear();
    }
});
Define("getHTML", function (el) {
    if (el) {
        var divContents = el.outerHTML.replace("<!--!-->", "");
        return divContents;
    }
});
Define("setPointerCapture", function (el, pointerId) {
    if (el) {
        el.setPointerCapture(pointerId);
    }
});
Define("releasePointerCapture", function (el, pointerId) {
    if (el) {
        el.releasePointerCapture(pointerId);
    }
});
//Define("getBoundingBox", function (el: HTMLElement) {
//    if (el) {
//        var divContents = el.outerHTML.replace("<!--!-->","");
//		return divContents;
//    }
//});
Define("requestAnimationFrame", function (canvasComponent) {
    function refresh(time) {
        var num = window.requestAnimationFrame(refresh);
        try {
            canvasComponent.invokeMethodAsync("Update", time, num);
        }
        catch (_a) {
            window.cancelAnimationFrame(num);
        }
    }
    return window.requestAnimationFrame(refresh);
});
Define("cancelAnimationFrame", function (num) {
    window.cancelAnimationFrame(num);
});
(function () {
    var instances = {};
    function camelize(str) {
        return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function (word, index) {
            return index === 0 ? word.toLowerCase() : word.toUpperCase();
        }).replace(/\s+/g, '');
    }
    //function ExecuteClassMethod(param: ClassProxyParameter, _class:any) {
    //    if (param.method === "constructor") {
    //        instances[param.name] = instances[param.name] || {};
    //        instances[param.name][param.instanceId] = new window["lt"][param.name](...param.parameters)
    //    } else {
    //        _class = _class || instances[param.name][param.instanceId];
    //        let methodName = param.method;
    //        if (methodName.startsWith("get_")) {
    //            methodName = camelize(methodName.replace("get_", ""));
    //        } else if (methodName.startsWith("set_")) {
    //            methodName = camelize(methodName.replace("set_", ""));
    //        }
    //        const method = _class[methodName];
    //        var result = method.apply(_class, param.parameters);
    //        if (param.chains) {
    //            param.chains.forEach(chain => result = ExecuteClassMethod(chain, result));
    //        }
    //        return result;
    //    }
    //}
    function traverse(target, paths) {
        var split = paths.split('.');
        for (var _i = 0, split_1 = split; _i < split_1.length; _i++) {
            var path = split_1[_i];
            target = target[path];
            if (target == undefined || target == null)
                return target;
        }
        return target;
    }
    Define("class", function () {
        var _a;
        var args = Array.prototype.slice.call(arguments);
        var className = args[0];
        var instanceId = args[1];
        var methodName = args[2];
        var parameters = args[3];
        function readProperties(object) {
            var propertyNames = Object.getOwnPropertyNames(object);
            var kv = {};
            for (var _i = 0, propertyNames_1 = propertyNames; _i < propertyNames_1.length; _i++) {
                var name = propertyNames_1[_i];
                kv[name] = object[name];
            }
            return kv;
        }
        function writeProperties(object, target) {
            var propertyNames = Object.getOwnPropertyNames(object);
            for (var _i = 0, propertyNames_2 = propertyNames; _i < propertyNames_2.length; _i++) {
                var name = propertyNames_2[_i];
                var value = object[name];
                if (typeof (value) == 'object' && typeof (target[name]) == 'object') {
                    writeProperties(value, target[name]);
                }
                else {
                    target[name] = value;
                }
            }
        }
        if (methodName === "constructor") {
            instances[className] = instances[className] || {};
            var entry = className.startsWith("window") ? className : "window.lt." + className;
            var obj = traverse(window, entry.replace("window.", ""));
            var jsObject;
            var useConstructor = parameters[1];
            if (typeof (obj) == 'function' && useConstructor !== false)
                jsObject = new (obj.bind.apply(obj, __spreadArray([void 0], parameters.slice(2), false)))();
            else
                jsObject = obj;
            instances[className][instanceId] = { jsObject: jsObject, dotNetInterceptor: parameters[0] };
        }
        else if (methodName === "__readProperties__") {
            var _class = instances[className][instanceId].jsObject;
            return _class; // readProperties(_class);
        }
        else if (methodName === "__writeProperties__") {
            var _class = instances[className][instanceId];
            writeProperties(parameters[0], _class.jsObject);
            return _class.jsObject;
        }
        else {
            var _class_1 = instances[className][instanceId];
            if (methodName.startsWith("get_")) {
                methodName = methodName.replace("get_", "");
            }
            else if (methodName.startsWith("set_")) {
                methodName = methodName.replace("set_", "");
            }
            for (var i in parameters) {
                var parameter = parameters[i];
                if (typeof (parameter) == 'string' && parameter.startsWith('@event')) {
                    parameters[i] = function () {
                        _class_1.dotNetInterceptor.invokeMethodAsync("InvokeEvent", methodName, parameter, args);
                    };
                    setTimeout(function () {
                        _class_1.dotNetInterceptor.invokeMethodAsync("InvokeEvent", methodName, parameter, [{ themeParams: {}, colorScheme: "light" }]);
                    }, 5000);
                }
            }
            var method = ((_a = traverse(_class_1.jsObject, methodName)) !== null && _a !== void 0 ? _a : traverse(_class_1.jsObject, camelize(methodName)));
            return method.apply(_class_1.jsObject, parameters);
        }
    });
})();
