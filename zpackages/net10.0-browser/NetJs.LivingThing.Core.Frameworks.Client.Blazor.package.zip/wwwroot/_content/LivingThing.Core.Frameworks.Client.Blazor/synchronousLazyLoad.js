//import { loaderHelpers, runtimeHelpers } from "/_framework/dotnet.runtime.8.0.2.uiooi1ew9h.js";
import { dotnet } from "/_framework/dotnet.js";

window.loadLazyAssembly = function (assemblyNameToLoad) {
    var promise = dotnet.instance.INTERNAL.loadLazyAssembly(assemblyNameToLoad);
    let worker = new Worker(
        `data:text/javascript,
        onmessage = function(data)
        {
            await data.promise;
            postMessage(true);
        }
    `
    );
    let done;
    worker.onmessage = () => {
        done=true;
    }
    worker.postMessage(promise);
    while (!done);
    worker.terminate();
}
