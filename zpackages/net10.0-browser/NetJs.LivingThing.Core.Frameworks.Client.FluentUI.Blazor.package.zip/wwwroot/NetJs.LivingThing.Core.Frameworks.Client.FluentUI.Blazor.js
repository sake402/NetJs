
//--TRIMMABLE-BOUNDARY-START(50355)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $DJRY, $bMcF) {
    "use strict";
    let _;
    let $SODDMi;
    let $qrXrWk;
    let $AgUnMd;
    let $PkWiMj;
    let $nSGWjc;
    let $KUOKYa;
    let $oBaiDf;
    let $PHPeSd;
    let $iGIDOj;
    let $pnGVDi;
    let $uClfea;
    let $EfXadj;
    let $UzGdCi;
    let $oCGBBi;
    let $ghIPFe;
    let $mKPIbg;
    let $Gguxch;
    let $naUcOa;
    let $qldvna;
    let $fToaAg;
    let $RcATRj;
    let $uijlcj;
    let $dDBrNk;
    let $vAyUej;
    let $ZFYfde;
    let $LNAqtd;
    let $FYOZoe;
    let $yOFFGa;
    let $cVkUJi;
    let $sozhof;
    let $SPVpii;
    let $nrjcMf;
    let $NcHcaj;
    let $MODMti;
    let $xfwdvk;
    let $kqNCNd;
    let $HUPoQb;
    let $xfdlyj;
    let $KTwMSf;
    let $yYzFJc;
    let $eWZZQc;
    let $MAbIGe;
    let $QvVBRk;
    let $TpTSUg;
    let $RrbNLj;
    let $wIosdl;
    let $ypEjlj;
    let $auzFQf;
    let $gEcLjk;
    let $lYtCGh;
    let $WiIuBd;
    let $jcDjZg;
    let $dthaDi;
    let $BzBIRe;
    let $qMrnqf;
    let $iMLMIf;
    let $uDGtRb;
    let $YMDisb;
    let $HwYXhc;
    let $IHqPgi;
    let $DqiZMc;
    let $bTLKog;
    let $zcAQnd;
    let $tAEAce;
    let $urYrdl;
    let $NmZFPh;
    let $rnzLid;
    let $WhjCel;
    let $rONndg;
    let $aWbfBj;
    let $UEoqYe;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", 
    {
  "h": 50355,
  "f": "LivingThing.Core.Frameworks.Client.FluentUI.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.FluentUI.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.FluentUI.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2344115)
        $asm.$cls(`$rfUg.LCFCFR.RazorViewBase`, ($self) => class RazorViewBase extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887246003)
            /*void */ Write(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887246003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12887246003)
            
            //--TRIMMABLE-BOUNDARY-START(17182213299)
            /*void */ WriteLiteral(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182213299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17182213299)
            
            //--TRIMMABLE-BOUNDARY-START(4297311411)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297311411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297311411)
            
            //--TRIMMABLE-BOUNDARY-START(4297311411)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297311411)
            
            static $h = 2344115;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592278707),
    {
      "r": 65537,
      "n": "Execute",
      "d": 2344115,
      "h": 8592278707,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8592278707),
//--TRIMMABLE-BOUNDARY-START(12887246003),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Write",
      "d": 2344115,
      "h": 12887246003,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12887246003),
//--TRIMMABLE-BOUNDARY-START(17182213299),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "WriteLiteral",
      "d": 2344115,
      "h": 17182213299,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17182213299)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297311411),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2344115,
      "h": 4297311411,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297311411)
  ],
  "h": 2344115
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.RazorViewBase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}RazorViewBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2344115)
        
        

        //--TRIMMABLE-BOUNDARY-START(836787)
        $asm.$cls(`$rfUg.LCFCFR.BaseWidgetRenderer<>`, (TWidget) => $asm.$gt(`$rfUg.LCFCFR.BaseWidgetRenderer<>`, [TWidget], ($self) => class BaseWidgetRenderer$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475673267)
            /*RenderFragment */ Render(/*RenderFragment*/ view, /*TWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475673267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return view;
            }
            //--TRIMMABLE-BOUNDARY-END(21475673267)
            
            //--TRIMMABLE-BOUNDARY-START(8590771379)
            static /*void */ AddAttribute(/*Widget*/ widget, /*string*/ key, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590771379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value !== null)
                {
                    /*object?*/ let _value;
                    widget.Attributes.TryGetValue(key, $.$ref(() => _value, ($v) => _value = $v, $.$$.S.Object));
                    {
                        /*object?*/ let __ca1__;
                        /*var*/ let val = ((__ca1__ = _value) !== null ? ($.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString) ?? "") : "");
                        /*string?*/ let join = (key === "class" ? " " : key === "style" ? ";" : null);
                        if ($.$$.S.String.IsNullOrEmpty(val))
                        {
                            join = "";
                        }
                        if (join === null)
                        {
                            val = value;
                        }
                        else 
                        {
                            val += $.$strNN(join) + $.$strNN(value);
                        }
                        widget.Attributes.set_Item(key, val);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590771379)
            
            //--TRIMMABLE-BOUNDARY-START(17180705971)
            static /*string */ ClassSuffix(/*string*/ selector, /*string*/ suffix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180705971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(suffix))
                {
                    return selector;
                }
                return $.$strNN($.$strNN(selector) + "-") + $.$strNN(suffix);
            }
            //--TRIMMABLE-BOUNDARY-END(17180705971)
            
            //--TRIMMABLE-BOUNDARY-START(12885738675)
            /*void */ ApplyWidgetAttributes(/*TWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885738675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((widget.Styles?.Margin.Desktop.Unit ?? null) ?? 0/*WidgetDimensionUnit.None*/) !== 0/*WidgetDimensionUnit.None*/)
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TWidget).AddAttribute(widget, "style", `margin:${$.$strNN((widget.Styles?.Margin.Desktop ?? null).ToString())}`);
                }
                if (((widget.Styles?.Padding.Desktop.Unit ?? null) ?? 0/*WidgetDimensionUnit.None*/) !== 0/*WidgetDimensionUnit.None*/)
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TWidget).AddAttribute(widget, "style", `padding:${$.$strNN((widget.Styles?.Padding.Desktop ?? null).ToString())}`);
                }
                /*LivingThing.FluentUI.Core.Widgets.WidgetStyle?*/ let __ca2__;
                if ((__ca2__ = widget.Styles) !== null ? $.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Color, $.$fPer.LCFCDM.ColorUnitTypes, __ca2__.BackgroundColor) : false)
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TWidget).AddAttribute(widget, "style", `background-color:${$.$strNN(widget.Styles.BackgroundColor.ToString())}`);
                }
                if ((widget.Styles?.Width.Desktop.Value ?? null) !== null)
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TWidget).AddAttribute(widget, "style", `width:${$.$strNN(widget.Styles.Width.Desktop.ToString())}`);
                }
                if ((widget.Styles?.Height.Desktop.Value ?? null) !== null)
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TWidget).AddAttribute(widget, "style", `height:${$.$strNN(widget.Styles.Height.Desktop.ToString())}`);
                }
                if ((widget.Styles?.BorderRadius.Desktop.Value ?? null) !== null)
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TWidget).AddAttribute(widget, "style", `border-radius:${$.$strNN(widget.Styles.BorderRadius.Desktop.ToString())}`);
                }
                /*LivingThing.FluentUI.Core.Widgets.WidgetStyle?*/ let __ca3__;
                if ((__ca3__ = widget.Styles) !== null ? $.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Color, $.$fPer.LCFCDM.ColorUnitTypes, __ca3__.Shadow.Color) : false)
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TWidget).AddAttribute(widget, "style", `box-shadow:${$.$strNN(widget.Styles.Shadow.HOffset.Desktop.ToString())} ${$.$strNN(widget.Styles.Shadow.VOffset.Desktop.ToString())} ${$.$strNN(widget.Styles.Shadow.BlurRadius.Desktop.ToString())} ${$.$strNN(widget.Styles.Shadow.SpreadRadius.Desktop.ToString())} ${$.$strNN(widget.Styles.Shadow.Color.ToString())}`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885738675)
            
            //--TRIMMABLE-BOUNDARY-START(25770640563)
            /*object */ Render$1(/*TWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770640563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                widget.Attributes.Remove$1("class");
                widget.Attributes.Remove$1("style");
                this.ApplyWidgetAttributes(widget, dataSource, root);
                return this.RenderToFragment(widget, dataSource, root);
            }
            //--TRIMMABLE-BOUNDARY-END(25770640563)
            
            //--TRIMMABLE-BOUNDARY-START(4297076464)
            //Generated interface implemetation for LivingThing.FluentUI.Core.Renderer.IUIRenderer<TWidget>.Render(TWidget, LivingThing.FluentUI.Core.DataBinding.IWidgetDataSource, LivingThing.FluentUI.Core.Renderer.IRootWidgetRenderer)
            [`LFCR$IUIRenderer$${TWidget.$getFullName('$')}$Render`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297076464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Render$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297076464)
            
            //--TRIMMABLE-BOUNDARY-START(4295804083)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295804083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295804083)
            
            //--TRIMMABLE-BOUNDARY-START(4295804083)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295804083)
            
            static $H = 836787;
            static $h = 836787;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475673267),
    {
      "r": 6881395,
      "p": [
        {
          "n": "view",
          "p": 6881395
        },
        {
          "n": "widget",
          "p": TWidget?.$h??1572864
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "Render",
      "d": this.$h,
      "H": 21475673267,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475673267),
//--TRIMMABLE-BOUNDARY-START(30065607859),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": TWidget?.$h??1572864
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": this.$h,
      "H": 30065607859,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065607859),
//--TRIMMABLE-BOUNDARY-START(8590771379),
    {
      "r": 65537,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddAttribute",
      "d": this.$h,
      "H": 8590771379,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777252
    },
//--TRIMMABLE-BOUNDARY-END(8590771379),
//--TRIMMABLE-BOUNDARY-START(17180705971),
    {
      "r": 1310721,
      "p": [
        {
          "n": "selector",
          "p": 1310721
        },
        {
          "n": "suffix",
          "p": 1310721
        }
      ],
      "n": "ClassSuffix",
      "d": this.$h,
      "H": 17180705971,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777252
    },
//--TRIMMABLE-BOUNDARY-END(17180705971),
//--TRIMMABLE-BOUNDARY-START(12885738675),
    {
      "r": 65537,
      "p": [
        {
          "n": "widget",
          "p": TWidget?.$h??1572864
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "ApplyWidgetAttributes",
      "d": this.$h,
      "H": 12885738675,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(12885738675),
//--TRIMMABLE-BOUNDARY-START(25770640563),
    {
      "r": 131073,
      "p": [
        {
          "n": "widget",
          "p": TWidget?.$h??1572864
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "Render",
      "o": "@$1",
      "d": this.$h,
      "H": 25770640563,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25770640563)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295804083),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295804083,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295804083)
  ],
  "s": [
    {
      "h": TWidget?.$h??1572864,
      "n": "TWidget",
      "f": 4,
      "c": [9907952
      ]
    }
  ],
  "r": 1,
  "H": 836787,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$(TWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.BaseWidgetRenderer<${TWidget?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}BaseWidgetRenderer$${TWidget?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(836787)
        
        

        //--TRIMMABLE-BOUNDARY-START(3065011)
        $asm.$cls(`$rfUg.LCFCFW.ComponentWidgetRenderer<>`, (TWidget) => $asm.$gt(`$rfUg.LCFCFW.ComponentWidgetRenderer<>`, [TWidget], ($self) => class ComponentWidgetRenderer$$ extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(4298032307)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298032307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298032307)
            
            //--TRIMMABLE-BOUNDARY-START(4298032307)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298032307)
            
            static $H = 3065011;
            static $h = 3065011;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298032307),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4298032307,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4298032307)
  ],
  "s": [
    {
      "h": TWidget?.$h??1572864,
      "n": "TWidget",
      "f": 4,
      "c": [9907952
      ]
    }
  ],
  "r": 1,
  "H": 3065011,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$(TWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.WidgetComponent.ComponentWidgetRenderer<${TWidget?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}WidgetComponent${separator}ComponentWidgetRenderer$${TWidget?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3065011)
        
        

        //--TRIMMABLE-BOUNDARY-START(1754291)
        $asm.$cls(`$rfUg.LCFCFR.LabelRenderer<>`, (TLabelWidget) => $asm.$gt(`$rfUg.LCFCFR.LabelRenderer<>`, [TLabelWidget], ($self) => class LabelRenderer$$ extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TLabelWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8591688883)
            /*void */ ApplyWidgetAttributes(/*TLabelWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591688883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TLabelWidget).AddAttribute(widget, "class", `wf ${$.$strNN((((widget.FontStyle & (1/*WidgetFontStyle.Bold*/)) == (1/*WidgetFontStyle.Bold*/)) ? "fw-bold" : ""))}${$.$strNN((((widget.FontStyle & (2/*WidgetFontStyle.Italics*/)) == (2/*WidgetFontStyle.Italics*/)) ? " text-italic" : ""))}${$.$strNN((((widget.FontStyle & (4/*WidgetFontStyle.Underline*/)) == (4/*WidgetFontStyle.Underline*/)) ? " text-underline" : ""))}${$.$strNN((((widget.FontStyle & (8/*WidgetFontStyle.StrikeThrough*/)) == (8/*WidgetFontStyle.StrikeThrough*/)) ? " text-strike" : ""))}${$.$strNN((((widget.TextJustify & (16/*WidgetJustification.CenterX*/)) == (16/*WidgetJustification.CenterX*/)) ? " text-center" : ((widget.TextJustify & (2/*WidgetJustification.Right*/)) == (2/*WidgetJustification.Right*/)) ? " text-right" : ""))}${$.$strNN((((widget.TextJustify & (32/*WidgetJustification.CenterY*/)) == (32/*WidgetJustification.CenterY*/)) ? " mgy-a" : ""))}`);
                if (widget.FontSize !== 0)
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TLabelWidget).AddAttribute(widget, "class", `fsz-${$.$strNN(widget.FontSize)}`);
                }
                if ($.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Color, $.$fPer.LCFCDM.ColorUnitTypes, widget.TextColor))
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TLabelWidget).AddAttribute(widget, "style", `color:${$.$strNN(widget.TextColor.ToString())}`);
                }
                if (widget.Tag !== null)
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TLabelWidget).AddAttribute(widget, "tag", widget.Tag);
                }
                super.ApplyWidgetAttributes(widget, dataSource, root);
            }
            //--TRIMMABLE-BOUNDARY-END(8591688883)
            
            //--TRIMMABLE-BOUNDARY-START(17181623475)
            /*string */ GetTag(/*TLabelWidget*/ widget)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181623475);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return widget.Tag ?? (widget.FontWeight === 0 ? "span" : `h${$.$strNN((((($.trunc((((100 - widget.FontWeight) | 0)) / ($.trunc(100 / 5)))) + 1) | 0)))}`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181623475)
            
            //--TRIMMABLE-BOUNDARY-START(12886656179)
            /*string? */ GetContent(/*TLabelWidget*/ widget, /*IWidgetDataSource*/ dataSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886656179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let text = $.$bMcF.LFCD.DataBindingExtension.Bind((widget.Text ?? "Lorem Ipsum"), widget, dataSource, null, false);
                return text;
            }
            //--TRIMMABLE-BOUNDARY-END(12886656179)
            
            //--TRIMMABLE-BOUNDARY-START(21476590771)
            /*RenderFragment */ RenderToFragment(/*TLabelWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476590771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    /*int*/ let sequence = 1;
                    if (root.LFCR$IRootWidgetRenderer$EditMode === 1/*FluentUIEditMode.Editting*/)
                    {
                        builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$($.$$.S.String), sequence++);
                        builder.AddMultipleAttributes(sequence++, widget.Attributes);
                        const $t1 = () => widget.Text;
                        builder.AddAttribute$5(sequence++, "Value", $.$$.S.Int32.op_GreaterThan($.$ifnn($t1, ($t) => $t.length), 0) ? widget.Text : "Lorem Ipsum");
                        builder.AddAttribute$7($.$$.S.String, sequence++, "ValueChanged", $.$mac.MAC.EventCallback.Factory.Create$8($.$$.S.String, root, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*e*/ e) =>
                        {
                            widget.Text = e;
                            $.$dsp(widget, TLabelWidget, ($t) => $t.RaisePropertyChanged, this, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "Text" ], null, null));
                        }, $jcDjZg ??= {"r":65537,"p":[{"n":"e","p":1310721}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                        builder.AddAttribute$4(sequence++, "Features", $.$box(4131/*InputEditorFeatures.Default*/, $.$hDPm.LCFCCI$1.InputEditorFeatures));
                        builder.AddAttribute$4(sequence++, "Type", $.$box(9n, $.$fPer.LCFC.InputType));
                        builder.CloseComponent();
                    }
                    else if (root.LFCR$IRootWidgetRenderer$EditMode === 2/*FluentUIEditMode.Filling*/)
                    {
                        /*var*/ let texts = $.$fPer.LCFCS$6.StringExtension.SplitBy$5(widget.Text, $.$$.S.String.op_Implicit("\r\n"));
                        /*int*/ let n = 0;
                        let $en2 = texts.GetEnumerator();
                        while ($en2.MoveNext())
                        {
                            let content = $en2.Current;
                            {
                                if (content.Token.Length === 0)
                                {
                                    continue;
                                }
                                builder.OpenElement(sequence++, this.GetTag(widget));
                                builder.AddContent$1(sequence++, $.$hDPm.LCFCCI$1.InputUtilityExtensions.BindEditable$1(content.Token.ToString(), $.$as(root, $.$hDPm.LCFCCI$1.IEditableBindingValueProvider) ?? $.$as(dataSource, $.$hDPm.LCFCCI$1.IEditableBindingValueProvider) ?? new $.$rfUg.LCFCFR.LabelEditableBindingProvider().$ctor$1(dataSource, root, widget)));
                                builder.CloseElement();
                                n++;
                            }
                        }
                        if (n === 0)
                        {
                            builder.OpenElement(sequence++, this.GetTag(widget));
                            builder.AddContent$1(sequence++, $.$hDPm.LCFCCI$1.InputUtilityExtensions.BindEditable$1("{Text}", $.$as(root, $.$hDPm.LCFCCI$1.IEditableBindingValueProvider) ?? $.$as(dataSource, $.$hDPm.LCFCCI$1.IEditableBindingValueProvider) ?? new $.$rfUg.LCFCFR.LabelEditableBindingProvider().$ctor$1(dataSource, root, widget)));
                            builder.CloseElement();
                        }
                    }
                    else 
                    {
                        /*var*/ let contents = $.$fPer.LCFCS$6.StringExtension.SplitBy$5(this.GetContent(widget, dataSource), $.$$.S.String.op_Implicit("\r\n"));
                        let $en3 = contents.GetEnumerator();
                        while ($en3.MoveNext())
                        {
                            let content = $en3.Current;
                            {
                                if (content.Token.Length === 0)
                                {
                                    continue;
                                }
                                builder.OpenElement(sequence++, this.GetTag(widget));
                                builder.AddMultipleAttributes(sequence++, widget.Attributes);
                                builder.AddContent$4(sequence++, content.Token.ToString());
                                builder.CloseElement();
                            }
                        }
                    }
                }, $dthaDi ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(21476590771)
            
            //--TRIMMABLE-BOUNDARY-START(4296721587)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296721587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296721587)
            
            //--TRIMMABLE-BOUNDARY-START(4296721587)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296721587)
            
            static $H = 1754291;
            static $h = 1754291;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TLabelWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591688883),
    {
      "r": 65537,
      "p": [
        {
          "n": "widget",
          "p": TLabelWidget?.$h??1572864
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "ApplyWidgetAttributes",
      "d": this.$h,
      "H": 8591688883,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591688883),
//--TRIMMABLE-BOUNDARY-START(17181623475),
    {
      "r": 1310721,
      "p": [
        {
          "n": "widget",
          "p": TLabelWidget?.$h??1572864
        }
      ],
      "n": "GetTag",
      "d": this.$h,
      "H": 17181623475,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181623475),
//--TRIMMABLE-BOUNDARY-START(12886656179),
    {
      "r": 1310721,
      "p": [
        {
          "n": "widget",
          "p": TLabelWidget?.$h??1572864
        },
        {
          "n": "dataSource",
          "p": 1453808
        }
      ],
      "n": "GetContent",
      "d": this.$h,
      "H": 12886656179,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886656179),
//--TRIMMABLE-BOUNDARY-START(21476590771),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": TLabelWidget?.$h??1572864
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": this.$h,
      "H": 21476590771,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476590771)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296721587),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4296721587,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296721587)
  ],
  "s": [
    {
      "h": TLabelWidget?.$h??1572864,
      "n": "TLabelWidget",
      "f": 4,
      "c": [6893296
      ]
    }
  ],
  "r": 1,
  "H": 1754291,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$(TLabelWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.LabelRenderer<${TLabelWidget?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}LabelRenderer$${TLabelWidget?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1754291)
        
        

        //--TRIMMABLE-BOUNDARY-START(705715)
        $asm.$cls(`$rfUg.LCFCF.FluentUIUtility`, ($self) => class FluentUIUtility
        {
            //--TRIMMABLE-BOUNDARY-START(4295673011)
            static /*WidgetImage */ get DefaultImage()
            {
                return (() =>
                {
                    //new $.$bMcF.LFCW.WidgetImage()
                    const $t1 = $.$bMcF.LFCW.WidgetImage;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Url = "_content/LivingThing.Core.Frameworks.Client.FluentUI.Blazor/defaultImage.jpg";
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(4295673011)
            
            static $h = 705715;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295673011),
    {
      "p": 11808496,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885607603,
        "f": 50331681
      },
      "n": "DefaultImage",
      "d": 705715,
      "h": 4295673011,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(4295673011)
  ],
  "h": 705715
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.FluentUIUtility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}FluentUIUtility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(705715)
        
        

        //--TRIMMABLE-BOUNDARY-START(3261619)
        $asm.$cls(`$rfUg.LCFCFW.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(12888163507)
            static /*void */ AddWidget(TWidget, TWidgetRenderer, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888163507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bMcF.LFCW.WidgetFactory.Register(TWidget);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$bMcF.LFCR.IUIRenderer$$(TWidget), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6(TWidgetRenderer, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$bMcF.LFCR.IUIRenderer$$(TWidget)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$box($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(TWidgetRenderer, x), TWidgetRenderer);
                }, $PHPeSd ??= {"r":(TWidget, TWidgetRenderer) => $.$bMcF.LFCR.IUIRenderer$$(TWidget).$h,"p":[{"n":"x","p":327718}],"n":"","d":3261619,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(12888163507)
            
            //--TRIMMABLE-BOUNDARY-START(4298228915)
            static /*void */ AddRazorComponentWidget(TWidget, TComponent, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298228915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bMcF.LFCW.WidgetFactory.Register(TWidget);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$bMcF.LFCR.IUIRenderer$$(TWidget), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$rfUg.LCFCFW.RazorComponentWidgetRenderer$$$(TWidget, TComponent), services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$bMcF.LFCR.IUIRenderer$$(TWidget)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$rfUg.LCFCFW.RazorComponentWidgetRenderer$$$(TWidget, TComponent), x);
                }, $iGIDOj ??= {"r":(TWidget, TComponent) => $.$bMcF.LFCR.IUIRenderer$$(TWidget).$h,"p":[{"n":"x","p":327718}],"n":"","d":3261619,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4298228915)
            
            //--TRIMMABLE-BOUNDARY-START(8593196211)
            static /*void */ AddRazorContainerComponentWidget(TWidget, TComponent, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593196211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bMcF.LFCW.WidgetFactory.Register(TWidget);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$bMcF.LFCR.IUIRenderer$$(TWidget), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$rfUg.LCFCFW.RazorContainerComponentWidgetRenderer$$$(TWidget, TComponent), services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$bMcF.LFCR.IUIRenderer$$(TWidget)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$rfUg.LCFCFW.RazorContainerComponentWidgetRenderer$$$(TWidget, TComponent), x);
                }, $pnGVDi ??= {"r":(TWidget, TComponent) => $.$bMcF.LFCR.IUIRenderer$$(TWidget).$h,"p":[{"n":"x","p":327718}],"n":"","d":3261619,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8593196211)
            
            static $h = 3261619;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888163507),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TWidget",
        "TWidgetRenderer"
      ],
      "n": "AddWidget",
      "d": 3261619,
      "h": 12888163507,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888163507),
//--TRIMMABLE-BOUNDARY-START(4298228915),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TWidget",
        "TComponent"
      ],
      "n": "AddRazorComponentWidget",
      "d": 3261619,
      "h": 4298228915,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4298228915),
//--TRIMMABLE-BOUNDARY-START(8593196211),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TWidget",
        "TComponent"
      ],
      "n": "AddRazorContainerComponentWidget",
      "d": 3261619,
      "h": 8593196211,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8593196211)
  ],
  "h": 3261619
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.WidgetComponent.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}WidgetComponent${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3261619)
        
        

        //--TRIMMABLE-BOUNDARY-START(181427)
        $asm.$cls(`$rfUg.LCFCF._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295148723)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295148723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$rfUg.LCFCF.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295148723)
            
            static $h = 181427;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295148723),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 181427,
      "h": 4295148723,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295148723)
  ],
  "h": 181427
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(181427)
        
        

        //--TRIMMABLE-BOUNDARY-START(2999475)
        $asm.$cls(`$rfUg.LCFCF.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592934067)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592934067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.NopWidget), $.$rfUg.LCFCFR.NopRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.IconWidget), $.$rfUg.LCFCFR.IconRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ImageWidget), $.$rfUg.LCFCFR.ImageRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.CardWidget), $.$rfUg.LCFCFR.CardRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ContainerWidget), $.$rfUg.LCFCFR.ContainerRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.PlaceHolderWidget), $.$rfUg.LCFCFR.PlaceholderRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.RowWidget), $.$rfUg.LCFCFR.LayoutRowRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ColumnWidget), $.$rfUg.LCFCFR.LayoutColumnRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.StackWidget), $.$rfUg.LCFCFR.StackRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.HStackWidget), $.$rfUg.LCFCFR.HStackRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.VStackWidget), $.$rfUg.LCFCFR.VStackRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ZStackWidget), $.$rfUg.LCFCFR.ZStackRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.GridWidget), $.$rfUg.LCFCFR.GridRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.PositionedGridWidget), $.$rfUg.LCFCFR.PositionedGridRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.LabelWidget), $.$rfUg.LCFCFR.LabelRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ParagraphWidget), $.$rfUg.LCFCFR.ParagraphRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ComponentWidget), $.$rfUg.LCFCFR.ComponentRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.UIRootWidget), $.$rfUg.LCFCFR.UIRootRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ChartWidget), $.$rfUg.LCFCFR.ChartRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.RepeaterWidget), $.$rfUg.LCFCFR.RepeaterRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.HtmlWidget), $.$rfUg.LCFCFR.HtmlRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.RazorWidget), $.$rfUg.LCFCFR.RazorRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.TableWidget), $.$rfUg.LCFCFR.TableRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.SpacerWidget), $.$rfUg.LCFCFR.SpacerRenderer, services);
                $.$hDPm.LCFCI.InputFieldProviderExtension.AddInputField($.$bMcF.LFCW.WidgetResponsive$$($.$bMcF.LFCW.WidgetBoundingBox), $.$rfUg.LCFCFE.WidgetBoundingBoxEditor, services);
                $.$hDPm.LCFCI.InputFieldProviderExtension.AddInputField($.$bMcF.LFCW.WidgetResponsive$$($.$bMcF.LFCW.WidgetDimension), $.$rfUg.LCFCFE.WidgetDimensionEditor, services);
                $.$hDPm.LCFCI.InputEditorProviderExtension.AddInputEditor$1($.$bMcF.LFCW.WidgetShadow, $.$rfUg.LCFCFE.WidgetShadowEditor, services);
                $.$hDPm.LCFCI.InputEditorProviderExtension.AddInputEditor$1($.$bMcF.LFCW.WidgetImage, $.$rfUg.LCFCFE.WidgetImageEditor, services);
                $.$hDPm.LCFCI.InputEditorProviderExtension.AddInputEditor$1($.$bMcF.LFCW.WidgetIcon, $.$rfUg.LCFCFE.WidgetIconEditor, services);
                $.$hDPm.LCFCI.InputEditorProviderExtension.AddInputEditor$1($.$bMcF.LFCW.WidgetFontStyle, $.$rfUg.LCFCFE.WidgetFontStyleEditor, services);
                $.$hDPm.LCFCI.InputEditorProviderExtension.AddInputEditor$1($.$bMcF.LFCW.WidgetJustification, $.$rfUg.LCFCFE.WidgetJustificationEditor, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592934067)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$rfUg.LCFCF.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297966771)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297966771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297966771)
            
            //--TRIMMABLE-BOUNDARY-START(4297966771)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297966771)
            
            static $h = 2999475;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592934067),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2999475,
      "h": 8592934067,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592934067)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297966771),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2999475,
      "h": 4297966771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297966771)
  ],
  "h": 2999475
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2999475)
        
        

        //--TRIMMABLE-BOUNDARY-START(1623219)
        $asm.$cls(`$rfUg.LCFCFR.LabelEditableBindingProvider`, ($self) => class LabelEditableBindingProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591557811)
            /*IWidgetDataSource*/ dataSource = null;
            //--TRIMMABLE-BOUNDARY-END(8591557811)
            
            //--TRIMMABLE-BOUNDARY-START(21476459699)
            /*IRootWidgetRenderer*/ root = null;
            //--TRIMMABLE-BOUNDARY-END(21476459699)
            
            //--TRIMMABLE-BOUNDARY-START(30066394291)
            /*LabelWidget*/ widget = null;
            //--TRIMMABLE-BOUNDARY-END(30066394291)
            
            //--TRIMMABLE-BOUNDARY-START(4296590515)
            $ctor$1(/*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root, /*LabelWidget*/ widget)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296590515);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.dataSource = dataSource;
                    this.root = root;
                    this.widget = widget;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296590515)
            
            //--TRIMMABLE-BOUNDARY-START(12886525107)
            /*IEnumerable<KeyValuePair<string, object?>> */ GetAtttibutes(/*string*/ propertyName)
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)))().$ctor$1(function*()
                {
                    return;
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(12886525107)
            
            //--TRIMMABLE-BOUNDARY-START(17181492403)
            /*object? */ GetValue(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181492403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.dataSource.LFCD$IWidgetDataSource$Get($.$$.S.Object, this.widget, propertyName, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(17181492403)
            
            //--TRIMMABLE-BOUNDARY-START(25771426995)
            /*void */ SetValue(/*string*/ propertyName, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771426995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let sk;
                if ($.$is(this.dataSource, $.$bMcF.LFCD.IWidgetDataSink, { set $v($v){ sk = $v; } }))
                {
                    sk.LFCD$IWidgetDataSink$Set($.$$.S.Object, this.widget, propertyName, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771426995)
            
            //--TRIMMABLE-BOUNDARY-START(17206826666)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Input.IEditableBindingValueProvider.GetValue(string)
            LCFCCI$1$IEditableBindingValueProvider$GetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17206826666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17206826666)
            
            //--TRIMMABLE-BOUNDARY-START(25796761258)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Input.IEditableBindingValueProvider.SetValue(string, object?)
            LCFCCI$1$IEditableBindingValueProvider$SetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25796761258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25796761258)
            
            static $h = 1623219;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886525107),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).$h,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetAtttibutes",
      "d": 1623219,
      "h": 12886525107,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886525107),
//--TRIMMABLE-BOUNDARY-START(17181492403),
    {
      "r": 131073,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetValue",
      "d": 1623219,
      "h": 17181492403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181492403),
//--TRIMMABLE-BOUNDARY-START(25771426995),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetValue",
      "d": 1623219,
      "h": 25771426995,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771426995)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591557811),
    {
      "t": 1453808,
      "n": "dataSource",
      "d": 1623219,
      "h": 8591557811,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591557811),
//--TRIMMABLE-BOUNDARY-START(21476459699),
    {
      "t": 1978096,
      "n": "root",
      "d": 1623219,
      "h": 21476459699,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476459699),
//--TRIMMABLE-BOUNDARY-START(30066394291),
    {
      "t": 6893296,
      "n": "widget",
      "d": 1623219,
      "h": 30066394291,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066394291)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296590515),
    {
      "p": [
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        },
        {
          "n": "widget",
          "p": 6893296
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1623219,
      "h": 4296590515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296590515)
  ],
  "h": 1623219
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCI$1.IEditableBindingValueProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.LabelEditableBindingProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}LabelEditableBindingProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1623219)
        
        

        //--TRIMMABLE-BOUNDARY-START(771251)
        $asm.$cls(`$rfUg.LCFCF.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180640435)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$rfUg.LCFCFE.WidgetBoundingBoxEditor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$rfUg.LCFCFE.WidgetBoundingBoxEditor().$ctor$4();
                    }, $tAEAce ??= {"r":2752627,"n":"","d":771251,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$rfUg.LCFCFE.WidgetDimensionEditor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$rfUg.LCFCFE.WidgetDimensionEditor().$ctor$4();
                    }, $urYrdl ??= {"r":2752627,"n":"","d":771251,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$rfUg.LCFCFE.WidgetFontStyleEditor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$rfUg.LCFCFE.WidgetFontStyleEditor().$ctor$5();
                    }, $NmZFPh ??= {"r":2752627,"n":"","d":771251,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$rfUg.LCFCFE.WidgetIconEditor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$rfUg.LCFCFE.WidgetIconEditor().$ctor$5();
                    }, $rnzLid ??= {"r":2752627,"n":"","d":771251,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$rfUg.LCFCFE.WidgetImageEditor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$rfUg.LCFCFE.WidgetImageEditor().$ctor$5();
                    }, $WhjCel ??= {"r":2752627,"n":"","d":771251,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$rfUg.LCFCFE.WidgetJustificationEditor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$rfUg.LCFCFE.WidgetJustificationEditor().$ctor$5();
                    }, $rONndg ??= {"r":2752627,"n":"","d":771251,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$rfUg.LCFCFE.WidgetShadowEditor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$rfUg.LCFCFE.WidgetShadowEditor().$ctor$5();
                    }, $aWbfBj ??= {"r":2752627,"n":"","d":771251,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$rfUg.LCFCFR.PositionedGridRenderView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$rfUg.LCFCFR.PositionedGridRenderView().$ctor$5();
                    }, $UEoqYe ??= {"r":2752627,"n":"","d":771251,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180640435)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295738547)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295738547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295738547)
            
            //--TRIMMABLE-BOUNDARY-START(4295738547)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295738547)
            
            static $h = 771251;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180640435),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885673139,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 771251,
      "h": 17180640435,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180640435)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295738547),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 771251,
      "h": 4295738547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295738547)
  ],
  "h": 771251
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(771251)
        
        

        //--TRIMMABLE-BOUNDARY-START(3458227)
        $asm.$cls(`$rfUg.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298425523)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298425523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298425523)
            
            //--TRIMMABLE-BOUNDARY-START(4298425523)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298425523)
            
            static $h = 3458227;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298425523),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3458227,
      "h": 4298425523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298425523)
  ],
  "h": 3458227
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3458227)
        
        

        //--TRIMMABLE-BOUNDARY-START(3523763)
        $asm.$cls(`$rfUg.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298491059)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298491059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298491059)
            
            //--TRIMMABLE-BOUNDARY-START(4298491059)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298491059)
            
            static $h = 3523763;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298491059),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3523763,
      "h": 4298491059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298491059)
  ],
  "h": 3523763,
  "a": [
    {
      "t": 3458227,
      "c": 4298425523
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3523763)
        
        

        //--TRIMMABLE-BOUNDARY-START(1164467)
        $asm.$cls(`$rfUg.LCFCFR.ContainerRenderer<,>`, (TComponent, TContainerWidget) => $asm.$gt(`$rfUg.LCFCFR.ContainerRenderer<,>`, [TComponent, TContainerWidget], ($self) => class ContainerRenderer$$$ extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TContainerWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(12886066355)
            /*string? */ GetClass(/*TContainerWidget*/ widget)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886066355);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886066355)
            
            //--TRIMMABLE-BOUNDARY-START(8591099059)
            /*void */ ApplyWidgetAttributes(/*TContainerWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591099059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TContainerWidget).AddAttribute(widget, "class", this.GetClass(widget));
                super.ApplyWidgetAttributes(widget, dataSource, root);
            }
            //--TRIMMABLE-BOUNDARY-END(8591099059)
            
            //--TRIMMABLE-BOUNDARY-START(17181033651)
            /*RenderFragment */ RenderToFragment(/*TContainerWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181033651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    /*int*/ let sequence = 1;
                    builder.OpenComponent$1(TComponent, sequence++);
                    builder.AddMultipleAttributes(sequence++, widget.Attributes);
                    builder.AddAttribute$3(sequence++, "ChildContent", $.$cast(root.LFCR$IRootWidgetRenderer$RenderChildren(widget, dataSource), $.$mac.MAC.RenderFragment));
                    builder.CloseComponent();
                }, $uClfea ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(17181033651)
            
            //--TRIMMABLE-BOUNDARY-START(4296131763)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296131763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296131763)
            
            //--TRIMMABLE-BOUNDARY-START(4296131763)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296131763)
            
            static $H = 1164467;
            static $h = 1164467;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TContainerWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886066355),
    {
      "r": 1310721,
      "p": [
        {
          "n": "widget",
          "p": TContainerWidget?.$h??1638400
        }
      ],
      "n": "GetClass",
      "d": this.$h,
      "H": 12886066355,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886066355),
//--TRIMMABLE-BOUNDARY-START(8591099059),
    {
      "r": 65537,
      "p": [
        {
          "n": "widget",
          "p": TContainerWidget?.$h??1638400
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "ApplyWidgetAttributes",
      "d": this.$h,
      "H": 8591099059,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591099059),
//--TRIMMABLE-BOUNDARY-START(17181033651),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": TContainerWidget?.$h??1638400
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": this.$h,
      "H": 17181033651,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181033651)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296131763),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4296131763,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296131763)
  ],
  "s": [
    {
      "h": TComponent?.$h??1572864,
      "n": "TComponent",
      "c": [5133994
      ]
    },
    {
      "h": TContainerWidget?.$h??1638400,
      "n": "TContainerWidget",
      "f": 4,
      "c": [5517040
      ]
    }
  ],
  "r": 2,
  "H": 1164467,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$(TContainerWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.ContainerRenderer<${TComponent?.$fullName},${TContainerWidget?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}ContainerRenderer$${TComponent?.$getFullName(separator)}$${TContainerWidget?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1164467)
        
        

        //--TRIMMABLE-BOUNDARY-START(1230003)
        $asm.$cls(`$rfUg.LCFCFR.ContainerRenderer<>`, (TContainerWidget) => $asm.$gt(`$rfUg.LCFCFR.ContainerRenderer<>`, [TContainerWidget], ($self) => class ContainerRenderer$$ extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TContainerWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(12886131891)
            /*string? */ GetClass(/*TContainerWidget*/ widget)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886131891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886131891)
            
            //--TRIMMABLE-BOUNDARY-START(8591164595)
            /*void */ ApplyWidgetAttributes(/*TContainerWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591164595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TContainerWidget).AddAttribute(widget, "class", this.GetClass(widget));
                super.ApplyWidgetAttributes(widget, dataSource, root);
            }
            //--TRIMMABLE-BOUNDARY-END(8591164595)
            
            //--TRIMMABLE-BOUNDARY-START(17181099187)
            /*RenderFragment? */ GetCustomChildContent(/*TContainerWidget*/ widget)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181099187);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181099187)
            
            //--TRIMMABLE-BOUNDARY-START(21476066483)
            /*RenderFragment */ RenderToFragment(/*TContainerWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476066483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                {
                    /*int*/ let sequence = 1;
                    builder.OpenElement(sequence++, "div");
                    builder.AddMultipleAttributes(sequence++, widget.Attributes);
                    builder.AddContent$1(sequence++, this.GetCustomChildContent(widget));
                    builder.AddContent$1(sequence++, $.$cast(root.LFCR$IRootWidgetRenderer$RenderChildren(widget, dataSource), $.$mac.MAC.RenderFragment));
                    builder.CloseElement();
                }, $EfXadj ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(21476066483)
            
            //--TRIMMABLE-BOUNDARY-START(4296197299)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296197299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296197299)
            
            //--TRIMMABLE-BOUNDARY-START(4296197299)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296197299)
            
            static $H = 1230003;
            static $h = 1230003;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TContainerWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886131891),
    {
      "r": 1310721,
      "p": [
        {
          "n": "widget",
          "p": TContainerWidget?.$h??1572864
        }
      ],
      "n": "GetClass",
      "d": this.$h,
      "H": 12886131891,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886131891),
//--TRIMMABLE-BOUNDARY-START(8591164595),
    {
      "r": 65537,
      "p": [
        {
          "n": "widget",
          "p": TContainerWidget?.$h??1572864
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "ApplyWidgetAttributes",
      "d": this.$h,
      "H": 8591164595,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591164595),
//--TRIMMABLE-BOUNDARY-START(17181099187),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": TContainerWidget?.$h??1572864
        }
      ],
      "n": "GetCustomChildContent",
      "d": this.$h,
      "H": 17181099187,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(17181099187),
//--TRIMMABLE-BOUNDARY-START(21476066483),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": TContainerWidget?.$h??1572864
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": this.$h,
      "H": 21476066483,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476066483)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296197299),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4296197299,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296197299)
  ],
  "s": [
    {
      "h": TContainerWidget?.$h??1572864,
      "n": "TContainerWidget",
      "f": 4,
      "c": [5517040
      ]
    }
  ],
  "r": 1,
  "H": 1230003,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$(TContainerWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.ContainerRenderer<${TContainerWidget?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}ContainerRenderer$${TContainerWidget?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1230003)
        
        

        //--TRIMMABLE-BOUNDARY-START(3130547)
        $asm.$cls(`$rfUg.LCFCFW.RazorComponentWidgetRenderer<,>`, (TWidget, TComponent) => $asm.$gt(`$rfUg.LCFCFW.RazorComponentWidgetRenderer<,>`, [TWidget, TComponent], ($self) => class RazorComponentWidgetRenderer$$$ extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8593065139)
            /*RenderFragment */ RenderToFragment(/*TWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593065139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                {
                    builder.OpenComponent$1(TComponent, 1);
                    builder.AddAttribute$4(2, "ViewModel", $.$box(widget, TWidget));
                    builder.AddAttribute$4(3, "DataSource", dataSource);
                    builder.AddAttribute$4(4, "Renderer", root);
                    builder.CloseComponent();
                }, $yOFFGa ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(8593065139)
            
            //--TRIMMABLE-BOUNDARY-START(4298097843)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298097843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298097843)
            
            //--TRIMMABLE-BOUNDARY-START(4298097843)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298097843)
            
            static $H = 3130547;
            static $h = 3130547;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593065139),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": TWidget?.$h??1572864
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": this.$h,
      "H": 8593065139,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8593065139)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298097843),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4298097843,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298097843)
  ],
  "s": [
    {
      "h": TWidget?.$h??1572864,
      "n": "TWidget",
      "f": 4,
      "c": [9907952
      ]
    },
    {
      "h": TComponent?.$h??1638400,
      "n": "TComponent",
      "c": [$.$rfUg.LCFCFW.WidgetComponent$$(TWidget).$h
      ]
    }
  ],
  "r": 2,
  "H": 3130547,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$(TWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.WidgetComponent.RazorComponentWidgetRenderer<${TWidget?.$fullName},${TComponent?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}WidgetComponent${separator}RazorComponentWidgetRenderer$${TWidget?.$getFullName(separator)}$${TComponent?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3130547)
        
        

        //--TRIMMABLE-BOUNDARY-START(3196083)
        $asm.$cls(`$rfUg.LCFCFW.RazorContainerComponentWidgetRenderer<,>`, (TWidget, TComponent) => $asm.$gt(`$rfUg.LCFCFW.RazorContainerComponentWidgetRenderer<,>`, [TWidget, TComponent], ($self) => class RazorContainerComponentWidgetRenderer$$$ extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8593130675)
            /*RenderFragment */ RenderToFragment(/*TWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593130675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenComponent$1(TComponent, 1);
                    builder.AddAttribute$4(2, "ViewModel", $.$box(widget, TWidget));
                    /*var*/ let children = $.$cast(root.LFCR$IRootWidgetRenderer$RenderChildren(widget, dataSource), $.$mac.MAC.RenderFragment);
                    builder.AddAttribute$3(3, "ChildContent", children);
                    builder.AddAttribute$4(4, "DataSource", dataSource);
                    builder.AddAttribute$4(5, "Renderer", root);
                    builder.CloseComponent();
                }, $cVkUJi ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(8593130675)
            
            //--TRIMMABLE-BOUNDARY-START(4298163379)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298163379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298163379)
            
            //--TRIMMABLE-BOUNDARY-START(4298163379)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298163379)
            
            static $H = 3196083;
            static $h = 3196083;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593130675),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": TWidget?.$h??1572864
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": this.$h,
      "H": 8593130675,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8593130675)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298163379),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4298163379,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298163379)
  ],
  "s": [
    {
      "h": TWidget?.$h??1572864,
      "n": "TWidget",
      "f": 4,
      "c": [5517040
      ]
    },
    {
      "h": TComponent?.$h??1638400,
      "n": "TComponent",
      "c": [$.$rfUg.LCFCFW.WidgetContainer$$(TWidget).$h
      ]
    }
  ],
  "r": 2,
  "H": 3196083,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$(TWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.WidgetComponent.RazorContainerComponentWidgetRenderer<${TWidget?.$fullName},${TComponent?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}WidgetComponent${separator}RazorContainerComponentWidgetRenderer$${TWidget?.$getFullName(separator)}$${TComponent?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3196083)
        
        

        //--TRIMMABLE-BOUNDARY-START(2540723)
        $asm.$cls(`$rfUg.LCFCFR.StackBaseRenderer<>`, (TStackWidget) => $asm.$gt(`$rfUg.LCFCFR.StackBaseRenderer<>`, [TStackWidget], ($self) => class StackBaseRenderer$$ extends $.$rfUg.LCFCFR.ContainerRenderer$$(TStackWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(12887442611)
            /*string */ GetClass(/*TStackWidget*/ widget)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887442611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let justify = widget.ContentAlign === 16/*WidgetJustification.CenterX*/ || widget.ContentAlign === 32/*WidgetJustification.CenterY*/ ? " flex-center" : widget.ContentAlign === 4/*WidgetJustification.Top*/ || widget.ContentAlign === 1/*WidgetJustification.Left*/ ? " flex-start" : widget.ContentAlign === 8/*WidgetJustification.Bottom*/ || widget.ContentAlign === 2/*WidgetJustification.Right*/ ? " flex-end" : "";
                /*var*/ let space = widget.Space === 1/*StackSpaceDistribution.Between*/ ? " flex-spacebetween" : widget.Space === 2/*StackSpaceDistribution.Around*/ ? " flex-spacearound" : widget.Space === 4/*StackSpaceDistribution.Center*/ ? " flex-center" : widget.Space === 3/*StackSpaceDistribution.Even*/ ? " flex-spaceeven" : "";
                /*var*/ let flex = widget.StackDirection === 2/*Direction.ZPlane*/ ? "zstack" : `flex${$.$strNN((widget.StackDirection === 0/*Direction.Horizontal*/ ? " flex-h" : " flex-v"))}`;
                return `${$.$strNN(flex)}${$.$strNN(justify)}${$.$strNN(space)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(12887442611)
            
            //--TRIMMABLE-BOUNDARY-START(8592475315)
            /*void */ ApplyWidgetAttributes(/*TStackWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592475315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rfUg.LCFCFR.BaseWidgetRenderer$$(TStackWidget).AddAttribute(widget, "id", "w-" + $.$strNN($.$$.S.String.ToString.call(widget.Id)));
                super.ApplyWidgetAttributes(widget, dataSource, root);
            }
            //--TRIMMABLE-BOUNDARY-END(8592475315)
            
            //--TRIMMABLE-BOUNDARY-START(17182409907)
            /*RenderFragment? */ GetCustomChildContent(/*TStackWidget*/ widget)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182409907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sl.SL.Enumerable.Any($.$bMcF.LFCW.Widget, widget.Children, new ($.$$.S.Func$$$($.$bMcF.LFCW.Widget, $.$$.S.Boolean))().$ctor(this,  (/**/ c) =>
                {
                    return ((c.Styles?.Width.Desktop.Unit ?? null) ?? 0/*WidgetDimensionUnit.None*/) !== 0/*WidgetDimensionUnit.None*/;
                }, $sozhof ??= {"r":262145,"p":[{"n":"c","p":9907952}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})))
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                    {
                        builder.OpenElement(1, "style");
                        /*int*/ let i = 0;
                        let $en1 = widget.Children.SCG$IEnumerable$$$GetEnumerator();
                        while ($en1.SC$1$IEnumerator$MoveNext())
                        {
                            let c = $en1.SCG$IEnumerator$$$Current;
                            {
                                if (((c.Styles?.Width.Desktop.Unit ?? null) ?? 0/*WidgetDimensionUnit.None*/) !== 0/*WidgetDimensionUnit.None*/)
                                {
                                    builder.AddContent$4(2, `\r\n#w-${$.$strNN(widget.Id)} > *:nth-child(${$.$strNN(i)})\r\n{{\r\n    flex-basis:${$.$strNN(c.Styles.Width.Desktop.ToString())};\r\n}}\r\n`);
                                }
                            }
                        }
                        builder.CloseElement();
                    }, $SPVpii ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }
                return super.GetCustomChildContent(widget);
            }
            //--TRIMMABLE-BOUNDARY-END(17182409907)
            
            //--TRIMMABLE-BOUNDARY-START(4297508019)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297508019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297508019)
            
            //--TRIMMABLE-BOUNDARY-START(4297508019)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297508019)
            
            static $H = 2540723;
            static $h = 2540723;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.ContainerRenderer$$(TStackWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887442611),
    {
      "r": 1310721,
      "p": [
        {
          "n": "widget",
          "p": TStackWidget?.$h??1572864
        }
      ],
      "n": "GetClass",
      "d": this.$h,
      "H": 12887442611,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12887442611),
//--TRIMMABLE-BOUNDARY-START(8592475315),
    {
      "r": 65537,
      "p": [
        {
          "n": "widget",
          "p": TStackWidget?.$h??1572864
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "ApplyWidgetAttributes",
      "d": this.$h,
      "H": 8592475315,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592475315),
//--TRIMMABLE-BOUNDARY-START(17182409907),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": TStackWidget?.$h??1572864
        }
      ],
      "n": "GetCustomChildContent",
      "d": this.$h,
      "H": 17182409907,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17182409907)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297508019),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 4297508019,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297508019)
  ],
  "s": [
    {
      "h": TStackWidget?.$h??1572864,
      "n": "TStackWidget",
      "f": 4,
      "c": [9121520
      ]
    }
  ],
  "r": 1,
  "H": 2540723,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$(TStackWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.StackBaseRenderer<${TStackWidget?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}StackBaseRenderer$${TStackWidget?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2540723)
        
        

        //--TRIMMABLE-BOUNDARY-START(115891)
        $asm.$cls(`$rfUg.LCFCF._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590050483)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590050483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590050483)
            
            //--TRIMMABLE-BOUNDARY-START(4295083187)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295083187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295083187)
            
            //--TRIMMABLE-BOUNDARY-START(4295083187)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295083187)
            
            static $h = 115891;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590050483),
    {
      "r": 65537,
      "n": "Execute",
      "d": 115891,
      "h": 8590050483,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590050483)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295083187),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 115891,
      "h": 4295083187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295083187)
  ],
  "h": 115891
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(115891)
        
        

        //--TRIMMABLE-BOUNDARY-START(2671795)
        $asm.$cls(`$rfUg.LCFCFR.Table`, ($self) => class Table extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8592606387)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592606387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8592606387)
            
            //--TRIMMABLE-BOUNDARY-START(12887573683)
            static /*RenderFragment */ TableWrapper(/*RenderFragment*/ innerView, /*TableWidget*/ widget, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887573683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let attCPlus = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick($.$hDPm.LCFCC$1.ComponentExtension.AddClass($.$hDPm.LCFCC$1.ComponentAttributeBuilder.Empty(), "cl-success bg-transparent bd bd-primary wx-02 hx-02 pd-0 mgc-a round mdi mdi-plus mgy-a mgl-2"), new $.$$.S.Action().$ctor(this,  () =>
                {
                    return widget.Columns++;
                }, $wIosdl ??= {"r":65537,"n":"","d":2671795,"h":0,"f":17825794}), root, false, null, null, null, null, null, null);
                /*var*/ let attCMinus = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick($.$hDPm.LCFCC$1.ComponentExtension.AddClass($.$hDPm.LCFCC$1.ComponentAttributeBuilder.Empty(), "cl-success bg-transparent bd bd-primary wx-02 hx-02 pd-0 mgc-a round mdi mdi-minus mgy-a mgl-2"), new $.$$.S.Action().$ctor(this,  () =>
                {
                    return widget.Columns--;
                }, $ypEjlj ??= {"r":65537,"n":"","d":2671795,"h":0,"f":17825794}), root, false, null, null, null, null, null, null);
                /*var*/ let attRPlus = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick($.$hDPm.LCFCC$1.ComponentExtension.AddClass($.$hDPm.LCFCC$1.ComponentAttributeBuilder.Empty(), "cl-success bg-transparent bd bd-primary wx-02 hx-02 pd-0 mgc-a round mdi mdi-plus mgx-a mgt-2"), new $.$$.S.Action().$ctor(this,  () =>
                {
                    return widget.Rows++;
                }, $auzFQf ??= {"r":65537,"n":"","d":2671795,"h":0,"f":17825794}), root, false, null, null, null, null, null, null);
                /*var*/ let attRMinus = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick($.$hDPm.LCFCC$1.ComponentExtension.AddClass($.$hDPm.LCFCC$1.ComponentAttributeBuilder.Empty(), "cl-success bg-transparent bd bd-primary wx-02 hx-02 pd-0 mgc-a round mdi mdi-minus mgx-a mgt-2"), new $.$$.S.Action().$ctor(this,  () =>
                {
                    return widget.Rows--;
                }, $gEcLjk ??= {"r":65537,"n":"","d":2671795,"h":0,"f":17825794}), root, false, null, null, null, null, null, null);
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                {
                    __builder2.OpenElement(0, "div");
                    __builder2.AddAttribute$5(1, "class", "stack");
                    __builder2.OpenElement(2, "div");
                    __builder2.AddAttribute$5(3, "class", "flex");
                    __builder2.AddContent$1(4, innerView);
                    __builder2.AddMarkupContent(5, "\r\n            ");
                    __builder2.OpenElement(6, "div");
                    __builder2.AddAttribute$5(7, "class", "flex");
                    __builder2.OpenElement(8, "button");
                    __builder2.AddMultipleAttributes(9, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build(attCMinus)));
                    __builder2.AddAttribute$5(10, "title", "Reduce Column");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(11, "\r\n                ");
                    __builder2.OpenElement(12, "button");
                    __builder2.AddMultipleAttributes(13, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build(attCPlus)));
                    __builder2.AddAttribute$5(14, "title", "Add Column");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(15, "\r\n        ");
                    __builder2.OpenElement(16, "div");
                    __builder2.AddAttribute$5(17, "class", "stack");
                    __builder2.OpenElement(18, "button");
                    __builder2.AddMultipleAttributes(19, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build(attRMinus)));
                    __builder2.AddAttribute$5(20, "title", "Reduce Row");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(21, "\r\n            ");
                    __builder2.OpenElement(22, "button");
                    __builder2.AddMultipleAttributes(23, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build(attRPlus)));
                    __builder2.AddAttribute$5(24, "title", "Add Row");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }, $lYtCGh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2671795,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(12887573683)
            
            //--TRIMMABLE-BOUNDARY-START(4297639091)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297639091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297639091)
            
            //--TRIMMABLE-BOUNDARY-START(4297639091)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297639091)
            
            static $h = 2671795;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592606387),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2671795,
      "h": 8592606387,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592606387),
//--TRIMMABLE-BOUNDARY-START(12887573683),
    {
      "r": 6881395,
      "p": [
        {
          "n": "innerView",
          "p": 6881395
        },
        {
          "n": "widget",
          "p": 9318128
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "TableWrapper",
      "d": 2671795,
      "h": 12887573683,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887573683)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297639091),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2671795,
      "h": 4297639091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297639091)
  ],
  "h": 2671795
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.Table`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}Table`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2671795)
        
        

        //--TRIMMABLE-BOUNDARY-START(3327155)
        $asm.$cls(`$rfUg.LCFCFW.WidgetComponent<>`, (TViewModel) => $asm.$gt(`$rfUg.LCFCFW.WidgetComponent<>`, [TViewModel], ($self) => class WidgetComponent$$ extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$(TViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17183196339)
            /*IWidgetDataSource*/ DataSource = null;
            //--TRIMMABLE-BOUNDARY-END(17183196339)
            
            //--TRIMMABLE-BOUNDARY-START(38658032819)
            /*IRootWidgetRenderer*/ Renderer = null;
            //--TRIMMABLE-BOUNDARY-END(38658032819)
            
            //--TRIMMABLE-BOUNDARY-START(12888229043)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888229043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888229043)
            
            //--TRIMMABLE-BOUNDARY-START(12888229043)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12888229043)
            
            static $H = 3327155;
            static $h = 3327155;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$(TViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183196339),
    {
      "p": 1453808,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25773130931,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 47247967411,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 83886081
      },
      "n": "DataSource",
      "d": this.$h,
      "H": 17183196339,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17183196339),
//--TRIMMABLE-BOUNDARY-START(38658032819),
    {
      "p": 1978096,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34363065523,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 55837902003,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 83886081
      },
      "n": "Renderer",
      "d": this.$h,
      "H": 38658032819,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38658032819)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888229043),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 12888229043,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888229043)
  ],
  "s": [
    {
      "h": TViewModel?.$h??1572864,
      "n": "TViewModel"
    }
  ],
  "r": 1,
  "H": 3327155,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.WidgetComponent.WidgetComponent<${TViewModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}WidgetComponent${separator}WidgetComponent$${TViewModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3327155)
        
        

        //--TRIMMABLE-BOUNDARY-START(3392691)
        $asm.$cls(`$rfUg.LCFCFW.WidgetContainer<>`, (TViewModel) => $asm.$gt(`$rfUg.LCFCFW.WidgetContainer<>`, [TViewModel], ($self) => class WidgetContainer$$ extends $.$hDPm.LCFCC$1.BaseParameterizedContainer$$(TViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17183261875)
            /*IWidgetDataSource*/ DataSource = null;
            //--TRIMMABLE-BOUNDARY-END(17183261875)
            
            //--TRIMMABLE-BOUNDARY-START(38658098355)
            /*IRootWidgetRenderer*/ Renderer = null;
            //--TRIMMABLE-BOUNDARY-END(38658098355)
            
            //--TRIMMABLE-BOUNDARY-START(12888294579)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888294579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888294579)
            
            //--TRIMMABLE-BOUNDARY-START(12888294579)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12888294579)
            
            static $H = 3392691;
            static $h = 3392691;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedContainer$$(TViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183261875),
    {
      "p": 1453808,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25773196467,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 47248032947,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 83886081
      },
      "n": "DataSource",
      "d": this.$h,
      "H": 17183261875,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17183261875),
//--TRIMMABLE-BOUNDARY-START(38658098355),
    {
      "p": 1978096,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34363131059,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 55837967539,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 83886081
      },
      "n": "Renderer",
      "d": this.$h,
      "H": 38658098355,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38658098355)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888294579),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 12888294579,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888294579)
  ],
  "s": [
    {
      "h": TViewModel?.$h??1572864,
      "n": "TViewModel"
    }
  ],
  "r": 1,
  "H": 3392691,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.WidgetComponent.WidgetContainer<${TViewModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}WidgetComponent${separator}WidgetContainer$${TViewModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3392691)
        
        

        //--TRIMMABLE-BOUNDARY-START(1033395)
        $asm.$cls(`$rfUg.LCFCFR.ComponentRenderer`, ($self) => class ComponentRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.ComponentWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8590967987)
            /*RenderFragment */ RenderToFragment(/*ComponentWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590967987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                }, $SODDMi ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1033395,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(8590967987)
            
            //--TRIMMABLE-BOUNDARY-START(4296000691)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296000691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296000691)
            
            //--TRIMMABLE-BOUNDARY-START(4296000691)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296000691)
            
            static $h = 1033395;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.ComponentWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590967987),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 5123824
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 1033395,
      "h": 8590967987,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590967987)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296000691),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1033395,
      "h": 4296000691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296000691)
  ],
  "h": 1033395
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ComponentWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.ComponentRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}ComponentRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1033395)
        
        

        //--TRIMMABLE-BOUNDARY-START(2278579)
        $asm.$cls(`$rfUg.LCFCFR.RazorRenderer`, ($self) => class RazorRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.RazorWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8592213171)
            /*RenderFragment */ RenderToFragment(/*RazorWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592213171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8592213171)
            
            //--TRIMMABLE-BOUNDARY-START(4297245875)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297245875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297245875)
            
            //--TRIMMABLE-BOUNDARY-START(4297245875)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297245875)
            
            static $h = 2278579;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.RazorWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592213171),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 8138480
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 2278579,
      "h": 8592213171,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8592213171)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297245875),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2278579,
      "h": 4297245875,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297245875)
  ],
  "h": 2278579
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.RazorWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.RazorRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}RazorRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2278579)
        
        

        //--TRIMMABLE-BOUNDARY-START(2475187)
        $asm.$cls(`$rfUg.LCFCFR.SpacerRenderer`, ($self) => class SpacerRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.SpacerWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8592409779)
            /*void */ ApplyWidgetAttributes(/*SpacerWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592409779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (widget.Width > 0)
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.SpacerWidget).AddAttribute(widget, "style", `width:${$.$strNN(widget.Width)}px`);
                }
                if (widget.Height > 0)
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.SpacerWidget).AddAttribute(widget, "style", `height:${$.$strNN(widget.Height)}px`);
                }
                super.ApplyWidgetAttributes(widget, dataSource, root);
            }
            //--TRIMMABLE-BOUNDARY-END(8592409779)
            
            //--TRIMMABLE-BOUNDARY-START(12887377075)
            /*RenderFragment */ RenderToFragment(/*SpacerWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887377075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenElement(1, "div");
                    builder.AddMultipleAttributes(2, widget.Attributes);
                    builder.CloseElement();
                }, $oBaiDf ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":2475187,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(12887377075)
            
            //--TRIMMABLE-BOUNDARY-START(4297442483)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297442483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297442483)
            
            //--TRIMMABLE-BOUNDARY-START(4297442483)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297442483)
            
            static $h = 2475187;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.SpacerWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592409779),
    {
      "r": 65537,
      "p": [
        {
          "n": "widget",
          "p": 8728304
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "ApplyWidgetAttributes",
      "d": 2475187,
      "h": 8592409779,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592409779),
//--TRIMMABLE-BOUNDARY-START(12887377075),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 8728304
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 2475187,
      "h": 12887377075,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12887377075)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297442483),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2475187,
      "h": 4297442483,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297442483)
  ],
  "h": 2475187
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.SpacerWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.SpacerRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}SpacerRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2475187)
        
        

        //--TRIMMABLE-BOUNDARY-START(967859)
        $asm.$cls(`$rfUg.LCFCFR.ChartRenderer`, ($self) => class ChartRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.ChartWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8590902451)
            /*RenderFragment */ RenderToFragment(/*ChartWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590902451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                {
                    builder.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$$.S.Object), 1);
                    builder.AddAttribute$4(2, "Attributes", widget.Attributes);
                    builder.AddAttribute$4(3, "Data", widget.Data ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [$.$box(1, $.$$.S.Double), $.$box(2, $.$$.S.Double), $.$box(3, $.$$.S.Double), $.$box(4, $.$$.S.Double)], [-1], null));
                    builder.AddAttribute$4(4, "Type", $.$box($.$cast(widget.ChartType, $.$hDPm.LCFCCC$3.ChartType), $.$hDPm.LCFCCC$3.ChartType));
                    builder.AddAttribute$4(5, "Features", $.$box($.$cast(widget.Features, $.$hDPm.LCFCCC$3.ChartFeatures), $.$hDPm.LCFCCC$3.ChartFeatures));
                    builder.AddAttribute$3(6, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Object, $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*value*/ value) =>
                    {
                        /*object?*/ let __ca1__;
                        return _ = ((__ca1__ = $.$fPer.LCFCP$1.PropertyExtension.GetValue(value, widget.XAxis, null)) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString) : null);
                    }), $RcATRj ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"value","p":131073}],"n":"","d":967859,"h":0,"f":17825794}));
                    /*System.Collections.Generic.IEnumerable<LivingThing.FluentUI.Core.Widgets.ChartCurve>*/ let __ca2__;
                    builder.AddAttribute$4(7, "Contents", ((__ca2__ = widget.Curves) !== null ? $.$sl.SL.Enumerable.Select$1($.$bMcF.LFCW.ChartCurve, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Object), __ca2__, new ($.$$.S.Func$$$($.$bMcF.LFCW.ChartCurve, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Object)))().$ctor(this,  (/*curve*/ curve) =>
                    {
                        return (() =>
                        {
                            //new $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Object)()
                            const $t1 = $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Object);
                            const $i1 = new $t1();
                            $i1.$ctor$7();
                            $i1.Label = curve.Label;
                            $i1.BackgroundColor = $.$strNN(curve.Color) + "20";
                            $i1.PointColor = curve.Color;
                            $i1.BorderColor = curve.Color;
                            $i1.DataPoint = new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.S.Object))().$ctor(this,  (/*value*/ value) =>
                            {
                                return $.$box($.$cast($.$fPer.LCFCP$1.PropertyExtension.GetValue(value.LCFCCD$1$IDataListItemContext$$$Data, curve.Data, null), $.$$.S.Double), $.$$.S.Double);
                            }, $uijlcj ??= {"r":131073,"p":[{"n":"value","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.S.Object).$h}],"n":"","d":967859,"h":0,"f":17825794});
                            return $i1;
                        })();
                    }, $dDBrNk ??= {"r":$.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Object).$h,"p":[{"n":"curve","p":4271856}],"n":"","d":967859,"h":0,"f":17825794})) : null));
                    builder.CloseComponent();
                }, $vAyUej ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":967859,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(8590902451)
            
            //--TRIMMABLE-BOUNDARY-START(4295935155)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295935155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295935155)
            
            //--TRIMMABLE-BOUNDARY-START(4295935155)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295935155)
            
            static $h = 967859;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.ChartWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590902451),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 4730608
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 967859,
      "h": 8590902451,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590902451)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295935155),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 967859,
      "h": 4295935155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295935155)
  ],
  "h": 967859
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ChartWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.ChartRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}ChartRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(967859)
        
        

        //--TRIMMABLE-BOUNDARY-START(1557683)
        $asm.$cls(`$rfUg.LCFCFR.ImageRenderer`, ($self) => class ImageRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.ImageWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(4296524979)
            /*IClientUnitOfWork*/ _unitOfWork = null;
            //--TRIMMABLE-BOUNDARY-END(4296524979)
            
            //--TRIMMABLE-BOUNDARY-START(8591492275)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591492275);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._unitOfWork = unitOfWork;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591492275)
            
            //--TRIMMABLE-BOUNDARY-START(12886459571)
            /*void */ ApplyWidgetAttributes(/*ImageWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                /*var*/ let cls;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886459571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (widget.Width.Desktop.HasValue())
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.ImageWidget).AddAttribute(widget, "style", `width:${$.$strNN(widget.Width.Desktop.ToString())}`);
                }
                if (widget.Height.Desktop.HasValue())
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.ImageWidget).AddAttribute(widget, "style", `height:${$.$strNN(widget.Height.Desktop.ToString())}`);
                }
                $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.ImageWidget).AddAttribute(widget, "class", `mawf`);
                /*var*/ let url = dataSource.LFCD$IWidgetDataSource$Get($.$$.S.String, widget, "url", null, false) ?? widget.Source.Url;
                if (url === null && widget.Attributes.TryGetValue("class", $.$ref(() => cls, ($v) => cls = $v, $.$$.S.Object)))
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.ImageWidget).AddAttribute(widget, "class", " mdi mdi-image d-block text-center fsz-50 clickable");
                }
                super.ApplyWidgetAttributes(widget, dataSource, root);
            }
            //--TRIMMABLE-BOUNDARY-END(12886459571)
            
            //--TRIMMABLE-BOUNDARY-START(17181426867)
            /*RenderFragment */ RenderToFragment(/*ImageWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181426867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    /*Task*/ /*async*/  function OnClicked()
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t2, $r2;
                            /*ResourceBrowser?*/ let browser = null;
                            ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$hDPm.LCFCCR$2.ResourceBrowser, this._unitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*builder*/ builder, /*i*/ i) =>
                            {
                                builder.AddAttribute$4(i++, "Features", $.$box(7/*ResourceBrowserFeatures.Default*/ & ~1/*ResourceBrowserFeatures.Prompt*/, $.$hDPm.LCFCCR$2.ResourceBrowserFeatures));
                                builder.AddComponentReferenceCapture(i++, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*c*/ c) =>
                                {
                                    return browser = $.$cast(c, $.$hDPm.LCFCCR$2.ResourceBrowser);
                                }, $NcHcaj ??= {"r":65537,"p":[{"n":"c","p":131073}],"n":"","d":1557683,"h":0,"f":17825794}));
                            }, $MODMti ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"i","p":655361}],"n":"","d":1557683,"h":0,"f":17825794}), null, (() =>
                            {
                                //new $.$hDPm.LCFCI.ViewConfiguration()
                                const $t3 = $.$hDPm.LCFCI.ViewConfiguration;
                                const $i3 = new $t3();
                                $i3.$ctor$2();
                                $i3.ViewFeatures = 63203/*ViewFeatures.DrawerDefault*/;
                                return $i3;
                            })()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            if ((browser?.Selections ?? null) !== null)
                            {
                                if (root.LFCR$IRootWidgetRenderer$EditMode === 1/*FluentUIEditMode.Editting*/)
                                {
                                    widget.Source = $.$with(widget.Source, ($clone) =>
                                    {
                                        $clone.Url = $.$sl.SL.Enumerable.First$1($.$Iaui.LCFCM.ResourceModel, browser.Selections).FullPath;
                                    });
                                }
                                else 
                                {
                                    ($.$cast(dataSource, $.$bMcF.LFCD.IWidgetDataSink)).LFCD$IWidgetDataSink$Set($.$$.S.String, widget, "url", $.$sl.SL.Enumerable.First$1($.$Iaui.LCFCM.ResourceModel, browser.Selections).FullPath);
                                }
                            }
                        });
                    }
                    /*var*/ let url = dataSource.LFCD$IWidgetDataSource$Get($.$$.S.String, widget, "url", null, false) ?? widget.Source.Url;
                    if (url === null)
                    {
                        builder.OpenElement(1, "i");
                        builder.AddMultipleAttributes(2, widget.Attributes);
                        if ($.$is(dataSource, $.$bMcF.LFCD.IWidgetDataSink) && (root.LFCR$IRootWidgetRenderer$EditMode === 1/*FluentUIEditMode.Editting*/ || root.LFCR$IRootWidgetRenderer$EditMode === 2/*FluentUIEditMode.Filling*/))
                        {
                            builder.AddAttribute$1(3, "onclick", $.$mac.MAC.EventCallback.Factory.Create$4(($.$as(root, $.$mac.MAC.ComponentBase)) ?? ($.$as(dataSource, $.$mac.MAC.ComponentBase)) ?? $.$cast(this, $.$$.S.Object), new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, OnClicked.bind(this), $xfwdvk ??= {"r":178454529,"n":"OnClicked","d":1557683,"h":0,"f":16781314})));
                        }
                        builder.CloseElement();
                    }
                    else 
                    {
                        builder.OpenElement(1, "img");
                        builder.AddMultipleAttributes(2, widget.Attributes);
                        builder.AddAttribute$5(3, "src", url);
                        if ($.$is(dataSource, $.$bMcF.LFCD.IWidgetDataSink) && (root.LFCR$IRootWidgetRenderer$EditMode === 1/*FluentUIEditMode.Editting*/ || root.LFCR$IRootWidgetRenderer$EditMode === 2/*FluentUIEditMode.Filling*/))
                        {
                            builder.AddAttribute$1(4, "onclick", $.$mac.MAC.EventCallback.Factory.Create$4(($.$as(root, $.$mac.MAC.ComponentBase)) ?? ($.$as(dataSource, $.$mac.MAC.ComponentBase)) ?? $.$cast(this, $.$$.S.Object), new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, OnClicked.bind(this), $kqNCNd ??= {"r":178454529,"n":"OnClicked","d":1557683,"h":0,"f":16781314})));
                        }
                        builder.CloseElement();
                    }
                }, $HUPoQb ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1557683,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(17181426867)
            
            static $h = 1557683;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.ImageWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886459571),
    {
      "r": 65537,
      "p": [
        {
          "n": "widget",
          "p": 6631152
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "ApplyWidgetAttributes",
      "d": 1557683,
      "h": 12886459571,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886459571),
//--TRIMMABLE-BOUNDARY-START(17181426867),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 6631152
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 1557683,
      "h": 17181426867,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181426867)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296524979),
    {
      "t": 63657642,
      "n": "_unitOfWork",
      "d": 1557683,
      "h": 4296524979,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296524979)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591492275),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1557683,
      "h": 8591492275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591492275)
  ],
  "h": 1557683
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ImageWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.ImageRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}ImageRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1557683)
        
        

        //--TRIMMABLE-BOUNDARY-START(1426611)
        $asm.$cls(`$rfUg.LCFCFR.HtmlRenderer`, ($self) => class HtmlRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.HtmlWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8591361203)
            /*RenderFragment */ BuildeNode(/*HtmlNode*/ node, /*HtmlWidget*/ widget, /*IWidgetDataSource*/ dataSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591361203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let text;
                if ($.$is(node, $.$DcMY.H.HtmlTextNode, { set $v($v){ text = $v; } }))
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                    {
                        try
                        {
                            /*string*/ let __ca1__;
                            /*string*/ let __ca2__;
                            builder.AddContent$4(1, ((__ca1__ = text.Text) !== null ? ((__ca2__ = $.$$.S.String.Trim.call(__ca1__)) !== null ? $.$bMcF.LFCD.DataBindingExtension.Bind(__ca2__, widget, dataSource, null, true) : null) : null));
                        }
                        catch(e)
                        {
                            builder.AddContent$4(1, e.Message);
                        }
                    }, $xfdlyj ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1426611,"h":0,"f":17825794});
                }
                else if ($.$$.S.Char.IsLower$1($.$$.S.String.get_Chars.call(node.OriginalName, 0)) || $.$$.S.String.get_Chars.call(node.OriginalName, 0) === /*@*/ 64)
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                    {
                        /*void*/  function Build(/*IWidgetDataSource*/ dataSource)
                        {
                            builder.OpenElement(1, node.OriginalName);
                            try
                            {
                                /*System.Collections.Generic.IEnumerable<HtmlAgilityPack.HtmlAttribute>*/ let __ca3__;
                                builder.AddMultipleAttributes(2, ((__ca3__ = $.$sl.SL.Enumerable.Where($.$DcMY.H.HtmlAttribute, node.Attributes, new ($.$$.S.Func$$$($.$DcMY.H.HtmlAttribute, $.$$.S.Boolean))().$ctor(this,  (/*n*/ n) =>
                                {
                                    return $.$$.S.String.get_Chars.call(n.OriginalName, 0) !== /*@*/ 64;
                                }, $KTwMSf ??= {"r":262145,"p":[{"n":"n","p":390470}],"n":"","d":1426611,"h":0,"f":17825794}))) !== null ? $.$sl.SL.Enumerable.ToDictionary$5($.$DcMY.H.HtmlAttribute, $.$$.S.String, $.$$.S.Object, __ca3__, new ($.$$.S.Func$$$($.$DcMY.H.HtmlAttribute, $.$$.S.String))().$ctor(this,  (/**/ a) =>
                                {
                                    return a.OriginalName;
                                }, $yYzFJc ??= {"r":1310721,"p":[{"n":"a","p":390470}],"n":"","d":1426611,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$DcMY.H.HtmlAttribute, $.$$.S.Object))().$ctor(this,  (/**/ a) =>
                                {
                                    /*string?*/ let __ca4__;
                                    return ((__ca4__ = a.DeEntitizeValue) !== null ? $.$bMcF.LFCD.DataBindingExtension.Bind(__ca4__, widget, dataSource, null, true) : null);
                                }, $eWZZQc ??= {"r":131073,"p":[{"n":"a","p":390470}],"n":"","d":1426611,"h":0,"f":17825794})) : null));
                            }
                            catch(e)
                            {
                                builder.AddContent$4(1, e.Message);
                            }
                            if (node.ChildNodes !== null)
                            {
                                let $en1 = node.ChildNodes.GetEnumerator();
                                while ($en1.MoveNext())
                                {
                                    let child = $en1.Current;
                                    {
                                        builder.AddContent$1(3, this.BuildeNode(child, widget, dataSource));
                                    }
                                }
                            }
                            builder.CloseElement();
                        }
                        /*var*/ let ifAttribute = $.$sl.SL.Enumerable.SingleOrDefault$1($.$DcMY.H.HtmlAttribute, node.Attributes, new ($.$$.S.Func$$$($.$DcMY.H.HtmlAttribute, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                        {
                            return a.Name === "@if";
                        }, $MAbIGe ??= {"r":262145,"p":[{"n":"a","p":390470}],"n":"","d":1426611,"h":0,"f":17825794}));
                        /*var*/ let foreachAttribute = $.$sl.SL.Enumerable.SingleOrDefault$1($.$DcMY.H.HtmlAttribute, node.Attributes, new ($.$$.S.Func$$$($.$DcMY.H.HtmlAttribute, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                        {
                            return a.Name === "@foreach";
                        }, $QvVBRk ??= {"r":262145,"p":[{"n":"a","p":390470}],"n":"","d":1426611,"h":0,"f":17825794}));
                        if ((ifAttribute?.Value ?? null) !== null)
                        {
                            try
                            {
                                /*var*/ let value = $.$bMcF.LFCD.UIDataBindingExtension.EvaluateBoundExpression($.$bMcF.LFCD.IWidgetDataSource, $.$$.S.Object, dataSource, dataSource, widget, ifAttribute.Value, true);
                                /*object*/ let __ca5__;
                                if (value === null || (((__ca5__ = value) !== null ? $.$dsp(__ca5__, $.$$.S.Object, ($t) => $t.Equals$1, $.$box(false, $.$$.S.Boolean)) : false)))
                                {
                                    Build.call(this, dataSource);
                                }
                            }
                            catch(e)
                            {
                                builder.AddContent$4(1, e.Message);
                            }
                        }
                        else if ((foreachAttribute?.Value ?? null) !== null)
                        {
                            /*var*/ let match = $.$str.STR.Regex.Match$4(foreachAttribute.Value, "(\\d+)..(\\d+)");
                            /*IEnumerable?*/ let values = null;
                            if (match.Success)
                            {
                                values = $.$sl.SL.Enumerable.Range($.$$.S.Int32.Parse$7(match.Groups.get_Item$1(1).Value), $.$$.S.Int32.Parse$7(match.Groups.get_Item$1(2).Value));
                            }
                            else 
                            {
                                match = $.$str.STR.Regex.Match$4(foreachAttribute.Value, "(\\d+)(,?(\\d+)?)?");
                                if (match.Success)
                                {
                                    values = $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$$.S.Int32, $.$$.S.String.Split$1.call(foreachAttribute.Value, /*,*/ 44, 0), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Int32))().$ctor($.$$.S.Int32, $.$$.S.Int32.Parse$7));
                                }
                                else 
                                {
                                    try
                                    {
                                        values = $.$cast($.$bMcF.LFCD.UIDataBindingExtension.EvaluateBoundExpression($.$bMcF.LFCD.IWidgetDataSource, $.$$.S.Object, dataSource, dataSource, widget, foreachAttribute.Value, false), $.$$.SC$1.IEnumerable);
                                    }
                                    catch(e)
                                    {
                                        builder.AddContent$4(1, e.Message);
                                    }
                                }
                            }
                            if (values !== null)
                            {
                                /*int*/ let index = 0;
                                let $en2 = values.SC$1$IEnumerable$GetEnumerator();
                                while ($en2.SC$1$IEnumerator$MoveNext())
                                {
                                    let value = $en2.SC$1$IEnumerator$Current;
                                    {
                                        Build.call(this, dataSource.LFCD$IWidgetDataSource$With($.$$.S.Object, index, value));
                                        index++;
                                    }
                                }
                            }
                        }
                        else 
                        {
                            Build.call(this, dataSource);
                        }
                    }, $TpTSUg ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1426611,"h":0,"f":17825794});
                }
                else 
                {
                    throw new $.$$.S.NotImplementedException().$ctor$9();
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591361203)
            
            //--TRIMMABLE-BOUNDARY-START(12886328499)
            /*RenderFragment */ RenderToFragment(/*HtmlWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886328499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                widget.Html = "\r\n@\r\n<div class=\"grid gap-1 colm-15 pd\">\r\n\t<div @foreach=\"1..4\" class='@(\"pd bg-\" + (@i==0?\"primary \":@i==1?\"secondary \":@i==0?\"warning \":\"error \") + \"flex mihx-2\")'>\r\n\t\t<h1 class=\"mg-a\">Slot {@i}({@@@.DataSource.Device.Status})</h1>\r\n\t</div>\r\n</div>";
                /*HtmlDocument?*/ let document = null;
                /*string*/ let __ca6__;
                /*var*/ let hashCode = ((__ca6__ = widget.Html) !== null ? $.$$.S.String.GetHashCode.call(__ca6__) : 0);
                document = new $.$DcMY.H.HtmlDocument().$ctor$1();
                document.LoadHtml(widget.Html ?? "");
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    /*int*/ let seq = 1;
                    let $en3 = document.DocumentNode.ChildNodes.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        let node = $en3.Current;
                        {
                            builder.AddContent$1(seq, this.BuildeNode(node, widget, dataSource));
                        }
                    }
                }, $RrbNLj ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1426611,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(12886328499)
            
            //--TRIMMABLE-BOUNDARY-START(4296393907)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296393907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296393907)
            
            //--TRIMMABLE-BOUNDARY-START(4296393907)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296393907)
            
            static $h = 1426611;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.HtmlWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591361203),
    {
      "r": 6881395,
      "p": [
        {
          "n": "node",
          "p": 1111366
        },
        {
          "n": "widget",
          "p": 6237936
        },
        {
          "n": "dataSource",
          "p": 1453808
        }
      ],
      "n": "BuildeNode",
      "d": 1426611,
      "h": 8591361203,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8591361203),
//--TRIMMABLE-BOUNDARY-START(12886328499),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 6237936
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 1426611,
      "h": 12886328499,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886328499)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296393907),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1426611,
      "h": 4296393907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296393907)
  ],
  "h": 1426611
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.HtmlWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.HtmlRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}HtmlRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1426611)
        
        

        //--TRIMMABLE-BOUNDARY-START(2409651)
        $asm.$cls(`$rfUg.LCFCFR.RepeaterRenderer`, ($self) => class RepeaterRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.RepeaterWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8592344243)
            /*IWidgetDataSource */ GetBinding(T, /*IWidgetDataSource*/ dataSource, /*int*/ i, /*T*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592344243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let binding = (dataSource?.LFCD$IWidgetDataSource$With(T, i, data) ?? null) ?? new ($.$bMcF.LFCD.UIDataBinding$$(T))().$ctor$2(data, null, new ($.$bMcF.LFCD.BindingExpressionEvaluator$$$(T, $.$$.S.Object))().$ctor($.$bMcF.LFCD.UIDataBindingExtension, (...args) => $.$bMcF.LFCD.UIDataBindingExtension.EvaluateBoundExpression(T, $.$$.S.Object,  ...args)), null);
                return binding;
            }
            //--TRIMMABLE-BOUNDARY-END(8592344243)
            
            //--TRIMMABLE-BOUNDARY-START(12887311539)
            /*RenderFragment */ RenderToFragment(/*RepeaterWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887311539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    if (widget.BindingPath !== null)
                    {
                        /*var*/ let repeaterDataSource = (dataSource?.LFCD$IWidgetDataSource$Get($.$$.SCG.IEnumerable$$($.$$.S.Object), widget, widget.BindingPath, null, false) ?? null);
                        if (repeaterDataSource !== null && widget.Template !== null)
                        {
                            if ($.$sl.SL.Enumerable.Any$1($.$$.S.Object, repeaterDataSource))
                            {
                                /*int*/ let i = 0;
                                let $en1 = repeaterDataSource.SCG$IEnumerable$$$GetEnumerator();
                                while ($en1.SC$1$IEnumerator$MoveNext())
                                {
                                    let data = $en1.SCG$IEnumerator$$$Current;
                                    {
                                        /*IWidgetDataSource*/ let binding = this.GetBinding(T, dataSource, i, data);
                                        builder.AddContent$1(1, $.$bMcF.LFC.WidgetRendererExtension.Render($.$mac.MAC.RenderFragment, widget.Template, binding, root));
                                        i++;
                                    }
                                }
                            }
                            else 
                            {
                            }
                        }
                    }
                    else 
                    {
                        /*var*/ let repeaterDataSource = widget.DataSource;
                        if (repeaterDataSource !== null && widget.Template !== null)
                        {
                            if ($.$sl.SL.Enumerable.Any$1($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), repeaterDataSource))
                            {
                                /*int*/ let i = 0;
                                let $en2 = repeaterDataSource.SCG$IEnumerable$$$GetEnumerator();
                                while ($en2.SC$1$IEnumerator$MoveNext())
                                {
                                    let data = $en2.SCG$IEnumerator$$$Current;
                                    {
                                        /*var*/ let binding = (dataSource?.LFCD$IWidgetDataSource$With($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), i, data) ?? null) ?? new ($.$bMcF.LFCD.UIDataBinding$$($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object)))().$ctor$2(data, null, new ($.$bMcF.LFCD.BindingExpressionEvaluator$$$($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), $.$$.S.Object))().$ctor($.$bMcF.LFCD.UIDataBindingExtension, (...args) => $.$bMcF.LFCD.UIDataBindingExtension.EvaluateBoundExpression($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), $.$$.S.Object,  ...args)), null);
                                        builder.AddContent$1(1, $.$bMcF.LFC.WidgetRendererExtension.Render($.$mac.MAC.RenderFragment, widget.Template, binding, root));
                                        i++;
                                    }
                                }
                            }
                            else 
                            {
                            }
                        }
                    }
                }, $nrjcMf ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":2409651,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(12887311539)
            
            //--TRIMMABLE-BOUNDARY-START(4297376947)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297376947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297376947)
            
            //--TRIMMABLE-BOUNDARY-START(4297376947)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297376947)
            
            static $h = 2409651;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.RepeaterWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592344243),
    {
      "r": 1453808,
      "p": [
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "i",
          "p": 655361
        },
        {
          "n": "data",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetBinding",
      "d": 2409651,
      "h": 8592344243,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(8592344243),
//--TRIMMABLE-BOUNDARY-START(12887311539),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 8335088
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 2409651,
      "h": 12887311539,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12887311539)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297376947),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2409651,
      "h": 4297376947,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297376947)
  ],
  "h": 2409651
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.RepeaterWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.RepeaterRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}RepeaterRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2409651)
        
        

        //--TRIMMABLE-BOUNDARY-START(1688755)
        $asm.$cls(`$rfUg.LCFCFR.LabelRenderer`, ($self) => class LabelRenderer extends $.$rfUg.LCFCFR.LabelRenderer$$($.$bMcF.LFCW.LabelWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(4296656051)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296656051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296656051)
            
            //--TRIMMABLE-BOUNDARY-START(4296656051)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296656051)
            
            static $h = 1688755;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.LabelRenderer$$($.$bMcF.LFCW.LabelWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296656051),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1688755,
      "h": 4296656051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296656051)
  ],
  "h": 1688755
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.LabelWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.LabelRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}LabelRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1688755)
        
        

        //--TRIMMABLE-BOUNDARY-START(640179)
        $asm.$cls(`$rfUg.LCFCFE.WidgetShadowEditor`, ($self) => class WidgetShadowEditor extends $.$hDPm.LCFCI.BaseInputEditor$$($.$bMcF.LFCW.WidgetShadow)
        {
            //--TRIMMABLE-BOUNDARY-START(21475476659)
            /*string */ get OptimizedComponentName()
            {
                return "widgetshadoweditor";
            }
            //--TRIMMABLE-BOUNDARY-END(21475476659)
            
            //--TRIMMABLE-BOUNDARY-START(8590574771)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590574771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$3.Popup, 0);
                __builder.AddComponentParameter(1, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCP$3.PopupFeatures, (24/*PopupFeatures.Default*/ & ~4/*PopupFeatures.HoverOpen*/) | 8/*PopupFeatures.ClickOpen*/ | 64/*PopupFeatures.Tooltip*/ | 1/*PopupFeatures.Fixed*/ | 32/*PopupFeatures.CreatePopupOnLoad*/), $.$hDPm.LCFCCP$3.PopupFeatures));
                __builder.AddComponentParameter(2, "pop-class", "bg-card shadow pd wx-3 corner-2 z-2");
                __builder.AddAttribute$3(3, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 4);
                        __builder2.AddComponentParameter(5, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddComponentParameter(6, "Class", "mg-1 corner-1 mihx-02 miwx-02 bd bg-gray");
                        __builder2.CloseComponent();
                    }, $qrXrWk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":640179,"h":0,"f":17825794});
                }), $AgUnMd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":640179,"h":0,"f":17825794}));
                __builder.AddAttribute$3(7, "Pop", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCP$3.PopupContext))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$1(8, this.DefaultEditor);
                    }, $PkWiMj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":640179,"h":0,"f":17825794});
                }), $nSGWjc ??= {"r":6881395,"p":[{"n":"context","p":39540394}],"n":"","d":640179,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590574771)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295607475)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295607475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295607475)
            
            //--TRIMMABLE-BOUNDARY-START(4295607475)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295607475)
            
            static $h = 640179;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCI.BaseInputEditor$$($.$bMcF.LFCW.WidgetShadow); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475476659),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180509363,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 640179,
      "h": 21475476659,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475476659)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590574771),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 640179,
      "h": 8590574771,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590574771)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295607475),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 640179,
      "h": 4295607475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295607475)
  ],
  "h": 640179
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$$.S.IDisposable, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetShadow)), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$bMcF.LFCW.WidgetShadow), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetShadow)), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetShadow)), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$bMcF.LFCW.WidgetShadow), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$bMcF.LFCW.WidgetShadow), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Editor.WidgetShadowEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Editor${separator}WidgetShadowEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(640179)
        
        

        //--TRIMMABLE-BOUNDARY-START(509107)
        $asm.$cls(`$rfUg.LCFCFE.WidgetImageEditor`, ($self) => class WidgetImageEditor extends $.$hDPm.LCFCI.BaseInputEditor$$($.$bMcF.LFCW.WidgetImage)
        {
            //--TRIMMABLE-BOUNDARY-START(25770312883)
            /*ValueTask *//*async*/  Selected(/*IEnumerable<ResourceModel>*/ resources)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770312883);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.ValueChanged.InvokeAsync$1($.$with(this.Value, ($clone) =>
                    {
                        $clone.Url = ($.$sl.SL.Enumerable.FirstOrDefault$3($.$Iaui.LCFCM.ResourceModel, resources)?.FullPath ?? null);
                    })), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770312883)
            
            //--TRIMMABLE-BOUNDARY-START(21475345587)
            /*string */ get OptimizedComponentName()
            {
                return "widgetimageeditor";
            }
            //--TRIMMABLE-BOUNDARY-END(21475345587)
            
            //--TRIMMABLE-BOUNDARY-START(8590443699)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590443699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "miwx-25");
                __builder.OpenComponent$1($.$hDPm.LCFCCR$2.ResourceBrowser, 2);
                __builder.AddComponentParameter(3, "OnSelected", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel)), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), $.$$.STT.ValueTask))().$ctor(this, this.Selected))));
                __builder.AddComponentParameter(4, "Title", "Select Image");
                __builder.AddAttribute$3(5, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    /*var*/ let url = this.Value.Url;
                    if (url === null)
                    {
                        __builder2.AddMarkupContent(6, "<div class=\"wx-1 hx-1 flex bd mgx-a\"><i class=\"mdi mdi-plus fsz-50 mg-a\"></i></div>");
                    }
                    else 
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 7);
                        __builder2.AddComponentParameter(8, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, url));
                        __builder2.AddComponentParameter(9, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 200), $.$$.S.Int32));
                        __builder2.CloseComponent();
                    }
                }), $KUOKYa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":509107,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590443699)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295476403)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295476403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295476403)
            
            //--TRIMMABLE-BOUNDARY-START(4295476403)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295476403)
            
            static $h = 509107;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCI.BaseInputEditor$$($.$bMcF.LFCW.WidgetImage); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475345587),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180378291,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 509107,
      "h": 21475345587,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475345587)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770312883),
    {
      "r": 181338113,
      "p": [
        {
          "n": "resources",
          "p": $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel).$h
        }
      ],
      "n": "Selected",
      "d": 509107,
      "h": 25770312883,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(25770312883),
//--TRIMMABLE-BOUNDARY-START(8590443699),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 509107,
      "h": 8590443699,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590443699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295476403),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 509107,
      "h": 4295476403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295476403)
  ],
  "h": 509107
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$$.S.IDisposable, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetImage)), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$bMcF.LFCW.WidgetImage), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetImage)), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetImage)), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$bMcF.LFCW.WidgetImage), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$bMcF.LFCW.WidgetImage), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Editor.WidgetImageEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Editor${separator}WidgetImageEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(509107)
        
        

        //--TRIMMABLE-BOUNDARY-START(574643)
        $asm.$cls(`$rfUg.LCFCFE.WidgetJustificationEditor`, ($self) => class WidgetJustificationEditor extends $.$hDPm.LCFCI.BaseInputEditor$$($.$bMcF.LFCW.WidgetJustification)
        {
            //--TRIMMABLE-BOUNDARY-START(25770378419)
            /*ValueTask *//*async*/  ToggleJustification(/*WidgetJustification*/ style)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770378419);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.ValueChanged.InvokeAsync$1(this.Value ^ style), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770378419)
            
            //--TRIMMABLE-BOUNDARY-START(21475411123)
            /*string */ get OptimizedComponentName()
            {
                return "widgetjustificationeditor";
            }
            //--TRIMMABLE-BOUNDARY-END(21475411123)
            
            //--TRIMMABLE-BOUNDARY-START(8590509235)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590509235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "d-i-block bd corner pd fsz-25");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "flex flex-spacearound-x");
                __builder.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$bMcF.LFCW.WidgetJustification), 4);
                __builder.AddComponentParameter(5, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCW.WidgetJustification, 4/*WidgetJustification.Top*/), $.$bMcF.LFCW.WidgetJustification));
                __builder.AddComponentParameter(6, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$bMcF.LFCW.WidgetJustification), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$bMcF.LFCW.WidgetJustification, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$bMcF.LFCW.WidgetJustification, $.$$.STT.ValueTask))().$ctor(this, this.ToggleJustification))));
                __builder.AddComponentParameter(7, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                __builder.AddComponentParameter(8, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                __builder.AddComponentParameter(9, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi mdi-align-vertical-top mgx-2 ${$.$strNN((((this.Value & (4/*WidgetJustification.Top*/)) == (4/*WidgetJustification.Top*/)) ? "" : "op-5"))}`));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\r\n    ");
                __builder.OpenElement(11, "div");
                __builder.AddAttribute$5(12, "class", "flex");
                __builder.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$bMcF.LFCW.WidgetJustification), 13);
                __builder.AddComponentParameter(14, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCW.WidgetJustification, 1/*WidgetJustification.Left*/), $.$bMcF.LFCW.WidgetJustification));
                __builder.AddComponentParameter(15, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$bMcF.LFCW.WidgetJustification), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$bMcF.LFCW.WidgetJustification, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$bMcF.LFCW.WidgetJustification, $.$$.STT.ValueTask))().$ctor(this, this.ToggleJustification))));
                __builder.AddComponentParameter(16, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                __builder.AddComponentParameter(17, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                __builder.AddComponentParameter(18, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi mdi-align-horizontal-left mgy-a ${$.$strNN((((this.Value & (1/*WidgetJustification.Left*/)) == (1/*WidgetJustification.Left*/)) ? "" : "op-5"))}`));
                __builder.CloseComponent();
                __builder.AddMarkupContent(19, "\r\n        ");
                __builder.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$bMcF.LFCW.WidgetJustification), 20);
                __builder.AddComponentParameter(21, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCW.WidgetJustification, 16/*WidgetJustification.CenterX*/), $.$bMcF.LFCW.WidgetJustification));
                __builder.AddComponentParameter(22, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$bMcF.LFCW.WidgetJustification), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$bMcF.LFCW.WidgetJustification, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$bMcF.LFCW.WidgetJustification, $.$$.STT.ValueTask))().$ctor(this, this.ToggleJustification))));
                __builder.AddComponentParameter(23, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                __builder.AddComponentParameter(24, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                __builder.AddComponentParameter(25, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi mdi-align-horizontal-center mg-2 ${$.$strNN((((this.Value & (16/*WidgetJustification.CenterX*/)) == (16/*WidgetJustification.CenterX*/)) ? "" : "op-5"))}`));
                __builder.CloseComponent();
                __builder.AddMarkupContent(26, "\r\n        ");
                __builder.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$bMcF.LFCW.WidgetJustification), 27);
                __builder.AddComponentParameter(28, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCW.WidgetJustification, 2/*WidgetJustification.Right*/), $.$bMcF.LFCW.WidgetJustification));
                __builder.AddComponentParameter(29, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$bMcF.LFCW.WidgetJustification), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$bMcF.LFCW.WidgetJustification, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$bMcF.LFCW.WidgetJustification, $.$$.STT.ValueTask))().$ctor(this, this.ToggleJustification))));
                __builder.AddComponentParameter(30, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                __builder.AddComponentParameter(31, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                __builder.AddComponentParameter(32, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi mdi-align-horizontal-right mgy-a ${$.$strNN((((this.Value & (2/*WidgetJustification.Right*/)) == (2/*WidgetJustification.Right*/)) ? "" : "op-5"))}`));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(33, "\r\n    ");
                __builder.OpenElement(34, "div");
                __builder.AddAttribute$5(35, "class", "flex flex-spacearound-x");
                __builder.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$bMcF.LFCW.WidgetJustification), 36);
                __builder.AddComponentParameter(37, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCW.WidgetJustification, 8/*WidgetJustification.Bottom*/), $.$bMcF.LFCW.WidgetJustification));
                __builder.AddComponentParameter(38, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$bMcF.LFCW.WidgetJustification), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$bMcF.LFCW.WidgetJustification, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$bMcF.LFCW.WidgetJustification, $.$$.STT.ValueTask))().$ctor(this, this.ToggleJustification))));
                __builder.AddComponentParameter(39, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                __builder.AddComponentParameter(40, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                __builder.AddComponentParameter(41, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi mdi-align-vertical-bottom mgx-2 ${$.$strNN((((this.Value & (8/*WidgetJustification.Bottom*/)) == (8/*WidgetJustification.Bottom*/)) ? "" : "op-5"))}`));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590509235)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295541939)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295541939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295541939)
            
            //--TRIMMABLE-BOUNDARY-START(4295541939)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295541939)
            
            static $h = 574643;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCI.BaseInputEditor$$($.$bMcF.LFCW.WidgetJustification); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475411123),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180443827,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 574643,
      "h": 21475411123,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475411123)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770378419),
    {
      "r": 181338113,
      "p": [
        {
          "n": "style",
          "p": 12005104
        }
      ],
      "n": "ToggleJustification",
      "d": 574643,
      "h": 25770378419,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(25770378419),
//--TRIMMABLE-BOUNDARY-START(8590509235),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 574643,
      "h": 8590509235,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590509235)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295541939),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 574643,
      "h": 4295541939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295541939)
  ],
  "h": 574643
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$$.S.IDisposable, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetJustification)), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$bMcF.LFCW.WidgetJustification), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetJustification)), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetJustification)), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$bMcF.LFCW.WidgetJustification), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$bMcF.LFCW.WidgetJustification), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Editor.WidgetJustificationEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Editor${separator}WidgetJustificationEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(574643)
        
        

        //--TRIMMABLE-BOUNDARY-START(378035)
        $asm.$cls(`$rfUg.LCFCFE.WidgetFontStyleEditor`, ($self) => class WidgetFontStyleEditor extends $.$hDPm.LCFCI.BaseInputEditor$$($.$bMcF.LFCW.WidgetFontStyle)
        {
            //--TRIMMABLE-BOUNDARY-START(25770181811)
            /*ValueTask *//*async*/  ToggleStyle(/*WidgetFontStyle*/ style)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770181811);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.ValueChanged.InvokeAsync$1(this.Value ^ style), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770181811)
            
            //--TRIMMABLE-BOUNDARY-START(21475214515)
            /*string */ get OptimizedComponentName()
            {
                return "widgetfontstyleeditor";
            }
            //--TRIMMABLE-BOUNDARY-END(21475214515)
            
            //--TRIMMABLE-BOUNDARY-START(8590312627)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590312627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonSet, 0);
                __builder.AddComponentParameter(1, "Class", "mihx-03");
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$bMcF.LFCW.WidgetFontStyle), 3);
                    __builder2.AddComponentParameter(4, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCW.WidgetFontStyle, 1/*WidgetFontStyle.Bold*/), $.$bMcF.LFCW.WidgetFontStyle));
                    __builder2.AddComponentParameter(5, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$bMcF.LFCW.WidgetFontStyle), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$bMcF.LFCW.WidgetFontStyle, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$bMcF.LFCW.WidgetFontStyle, $.$$.STT.ValueTask))().$ctor(this, this.ToggleStyle))));
                    __builder2.AddComponentParameter(6, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(7, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                    __builder2.AddComponentParameter(8, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi mdi-format-bold ${$.$strNN((((this.Value & (1/*WidgetFontStyle.Bold*/)) == (1/*WidgetFontStyle.Bold*/)) ? "" : "op-5"))}`));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(9, "\r\n    ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$bMcF.LFCW.WidgetFontStyle), 10);
                    __builder2.AddComponentParameter(11, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCW.WidgetFontStyle, 2/*WidgetFontStyle.Italics*/), $.$bMcF.LFCW.WidgetFontStyle));
                    __builder2.AddComponentParameter(12, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$bMcF.LFCW.WidgetFontStyle), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$bMcF.LFCW.WidgetFontStyle, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$bMcF.LFCW.WidgetFontStyle, $.$$.STT.ValueTask))().$ctor(this, this.ToggleStyle))));
                    __builder2.AddComponentParameter(13, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(14, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                    __builder2.AddComponentParameter(15, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi mdi-format-italic ${$.$strNN((((this.Value & (2/*WidgetFontStyle.Italics*/)) == (2/*WidgetFontStyle.Italics*/)) ? "" : "op-5"))}`));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(16, "\r\n    ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$bMcF.LFCW.WidgetFontStyle), 17);
                    __builder2.AddComponentParameter(18, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCW.WidgetFontStyle, 4/*WidgetFontStyle.Underline*/), $.$bMcF.LFCW.WidgetFontStyle));
                    __builder2.AddComponentParameter(19, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$bMcF.LFCW.WidgetFontStyle), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$bMcF.LFCW.WidgetFontStyle, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$bMcF.LFCW.WidgetFontStyle, $.$$.STT.ValueTask))().$ctor(this, this.ToggleStyle))));
                    __builder2.AddComponentParameter(20, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(21, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                    __builder2.AddComponentParameter(22, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi mdi-format-underline ${$.$strNN((((this.Value & (4/*WidgetFontStyle.Underline*/)) == (4/*WidgetFontStyle.Underline*/)) ? "" : "op-5"))}`));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(23, "\r\n    ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$bMcF.LFCW.WidgetFontStyle), 24);
                    __builder2.AddComponentParameter(25, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCW.WidgetFontStyle, 8/*WidgetFontStyle.StrikeThrough*/), $.$bMcF.LFCW.WidgetFontStyle));
                    __builder2.AddComponentParameter(26, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$bMcF.LFCW.WidgetFontStyle), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$bMcF.LFCW.WidgetFontStyle, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$bMcF.LFCW.WidgetFontStyle, $.$$.STT.ValueTask))().$ctor(this, this.ToggleStyle))));
                    __builder2.AddComponentParameter(27, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(28, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                    __builder2.AddComponentParameter(29, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi mdi-format-strikethrough ${$.$strNN((((this.Value & (8/*WidgetFontStyle.StrikeThrough*/)) == (8/*WidgetFontStyle.StrikeThrough*/)) ? "" : "op-5"))}`));
                    __builder2.CloseComponent();
                }), $UzGdCi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":378035,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590312627)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295345331)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295345331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295345331)
            
            //--TRIMMABLE-BOUNDARY-START(4295345331)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295345331)
            
            static $h = 378035;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCI.BaseInputEditor$$($.$bMcF.LFCW.WidgetFontStyle); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475214515),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180247219,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 378035,
      "h": 21475214515,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475214515)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770181811),
    {
      "r": 181338113,
      "p": [
        {
          "n": "style",
          "p": 11480816
        }
      ],
      "n": "ToggleStyle",
      "d": 378035,
      "h": 25770181811,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(25770181811),
//--TRIMMABLE-BOUNDARY-START(8590312627),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 378035,
      "h": 8590312627,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590312627)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295345331),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 378035,
      "h": 4295345331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295345331)
  ],
  "h": 378035
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$$.S.IDisposable, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetFontStyle)), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$bMcF.LFCW.WidgetFontStyle), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetFontStyle)), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetFontStyle)), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$bMcF.LFCW.WidgetFontStyle), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$bMcF.LFCW.WidgetFontStyle), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Editor.WidgetFontStyleEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Editor${separator}WidgetFontStyleEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(378035)
        
        

        //--TRIMMABLE-BOUNDARY-START(1950899)
        $asm.$cls(`$rfUg.LCFCFR.NopRenderer`, ($self) => class NopRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.NopWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8591885491)
            /*RenderFragment */ RenderToFragment(/*NopWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591885491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8591885491)
            
            //--TRIMMABLE-BOUNDARY-START(4296918195)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296918195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296918195)
            
            //--TRIMMABLE-BOUNDARY-START(4296918195)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296918195)
            
            static $h = 1950899;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.NopWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591885491),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 7286512
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 1950899,
      "h": 8591885491,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591885491)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296918195),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1950899,
      "h": 4296918195,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296918195)
  ],
  "h": 1950899
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.NopWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.NopRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}NopRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1950899)
        
        

        //--TRIMMABLE-BOUNDARY-START(1098931)
        $asm.$cls(`$rfUg.LCFCFR.ContainerRenderer`, ($self) => class ContainerRenderer extends $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.ContainerWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(4296066227)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296066227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296066227)
            
            //--TRIMMABLE-BOUNDARY-START(4296066227)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296066227)
            
            static $h = 1098931;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.ContainerWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296066227),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1098931,
      "h": 4296066227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296066227)
  ],
  "h": 1098931
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ContainerWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.ContainerRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}ContainerRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1098931)
        
        

        //--TRIMMABLE-BOUNDARY-START(2737331)
        $asm.$cls(`$rfUg.LCFCFR.TableRenderer`, ($self) => class TableRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.TableWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8592671923)
            /*RenderFragment */ RenderTable(/*TableWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592671923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    /*int*/ let sequence = 1;
                    builder.OpenElement(sequence++, "table");
                    builder.AddAttribute$5(sequence++, "class", "wf");
                    builder.AddAttribute$5(sequence++, "style", "border-collapse:collapse");
                    builder.AddMultipleAttributes(sequence++, widget.Attributes);
                    for(/*int*/ let r = 0; r < widget.Rows; r++)
                    {
                        builder.OpenElement(sequence++, "tr");
                        for(/*int*/ let c = 0; c < widget.Columns; c++)
                        {
                            builder.OpenElement(sequence++, widget.UseHeader && r === 0 ? "th" : "td");
                            builder.AddAttribute$5(sequence++, "class", widget.Border ? "bd" : null);
                            /*var*/ let id = `${$.$strNN(r)}${$.$strNN(c)}`;
                            /*System.Collections.Generic.Dictionary<string, LivingThing.FluentUI.Core.Widgets.Widget>?*/ let __ca1__;
                            /*var*/ let innerWidget = ((__ca1__ = widget.Cells) !== null ? $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$bMcF.LFCW.Widget, __ca1__, id) : null);
                            if (innerWidget === null)
                            {
                                innerWidget = (widget.CreateCell?.Invoke(widget, r, c) ?? null);
                                if (innerWidget !== null)
                                {
                                    widget.Cells ??= new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$bMcF.LFCW.Widget))().$ctor$1();
                                    widget.Cells.set_Item(id, innerWidget);
                                }
                                innerWidget ??= (() =>
                                {
                                    //new $.$bMcF.LFCW.PlaceHolderWidget()
                                    const $t1 = $.$bMcF.LFCW.PlaceHolderWidget;
                                    const $i1 = new $t1();
                                    $i1.$ctor$6();
                                    $i1.Tag = id;
                                    $i1.Parent = widget;
                                    return $i1;
                                })();
                            }
                            builder.AddContent$1(sequence++, $.$cast(root.LFCR$IRootWidgetRenderer$Render(innerWidget, dataSource), $.$mac.MAC.RenderFragment));
                            builder.CloseElement();
                        }
                        builder.CloseElement();
                    }
                    builder.CloseElement();
                }, $WiIuBd ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":2737331,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(8592671923)
            
            //--TRIMMABLE-BOUNDARY-START(12887639219)
            /*RenderFragment */ RenderToFragment(/*TableWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887639219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (root.LFCR$IRootWidgetRenderer$IsEditting)
                {
                    return $.$rfUg.LCFCFR.Table.TableWrapper(this.RenderTable(widget, dataSource, root), widget, root);
                }
                return this.RenderTable(widget, dataSource, root);
            }
            //--TRIMMABLE-BOUNDARY-END(12887639219)
            
            //--TRIMMABLE-BOUNDARY-START(4297704627)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297704627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297704627)
            
            //--TRIMMABLE-BOUNDARY-START(4297704627)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297704627)
            
            static $h = 2737331;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.TableWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592671923),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 9318128
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderTable",
      "d": 2737331,
      "h": 8592671923,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8592671923),
//--TRIMMABLE-BOUNDARY-START(12887639219),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 9318128
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 2737331,
      "h": 12887639219,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12887639219)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297704627),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2737331,
      "h": 4297704627,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297704627)
  ],
  "h": 2737331
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.TableWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.TableRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}TableRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2737331)
        
        

        //--TRIMMABLE-BOUNDARY-START(2016435)
        $asm.$cls(`$rfUg.LCFCFR.ParagraphRenderer`, ($self) => class ParagraphRenderer extends $.$rfUg.LCFCFR.LabelRenderer$$($.$bMcF.LFCW.ParagraphWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(4296983731)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296983731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296983731)
            
            //--TRIMMABLE-BOUNDARY-START(4296983731)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296983731)
            
            static $h = 2016435;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.LabelRenderer$$($.$bMcF.LFCW.ParagraphWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296983731),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2016435,
      "h": 4296983731,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296983731)
  ],
  "h": 2016435
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ParagraphWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.ParagraphRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}ParagraphRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2016435)
        
        

        //--TRIMMABLE-BOUNDARY-START(1492147)
        $asm.$cls(`$rfUg.LCFCFR.IconRenderer`, ($self) => class IconRenderer extends $.$rfUg.LCFCFR.LabelRenderer$$($.$bMcF.LFCW.IconWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(17181361331)
            /*string */ GetTag(/*IconWidget*/ widget)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181361331);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return "div";
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181361331)
            
            //--TRIMMABLE-BOUNDARY-START(12886394035)
            /*string? */ GetContent(/*IconWidget*/ widget, /*IWidgetDataSource*/ dataSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886394035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(12886394035)
            
            //--TRIMMABLE-BOUNDARY-START(8591426739)
            /*void */ ApplyWidgetAttributes(/*IconWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591426739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.IconWidget).AddAttribute(widget, "class", (widget.Icon.Icon ?? widget.Text ?? "Image"));
                super.ApplyWidgetAttributes(widget, dataSource, root);
            }
            //--TRIMMABLE-BOUNDARY-END(8591426739)
            
            //--TRIMMABLE-BOUNDARY-START(4296459443)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296459443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296459443)
            
            //--TRIMMABLE-BOUNDARY-START(4296459443)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296459443)
            
            static $h = 1492147;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.LabelRenderer$$($.$bMcF.LFCW.IconWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181361331),
    {
      "r": 1310721,
      "p": [
        {
          "n": "widget",
          "p": 6434544
        }
      ],
      "n": "GetTag",
      "d": 1492147,
      "h": 17181361331,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181361331),
//--TRIMMABLE-BOUNDARY-START(12886394035),
    {
      "r": 1310721,
      "p": [
        {
          "n": "widget",
          "p": 6434544
        },
        {
          "n": "dataSource",
          "p": 1453808
        }
      ],
      "n": "GetContent",
      "d": 1492147,
      "h": 12886394035,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886394035),
//--TRIMMABLE-BOUNDARY-START(8591426739),
    {
      "r": 65537,
      "p": [
        {
          "n": "widget",
          "p": 6434544
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "ApplyWidgetAttributes",
      "d": 1492147,
      "h": 8591426739,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591426739)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296459443),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1492147,
      "h": 4296459443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296459443)
  ],
  "h": 1492147
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.IconWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.IconRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}IconRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1492147)
        
        

        //--TRIMMABLE-BOUNDARY-START(312499)
        $asm.$cls(`$rfUg.LCFCFE.WidgetDimensionEditor`, ($self) => class WidgetDimensionEditor extends $.$hDPm.LCFCI.BaseInputField$$($.$bMcF.LFCW.WidgetResponsive$$($.$bMcF.LFCW.WidgetDimension))
        {
            //--TRIMMABLE-BOUNDARY-START(51539920051)
            /*bool*/ isMobileEditor = false;
            //--TRIMMABLE-BOUNDARY-END(51539920051)
            
            //--TRIMMABLE-BOUNDARY-START(90194625715)
            /*void */ ToMobile()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194625715);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.isMobileEditor = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194625715)
            
            //--TRIMMABLE-BOUNDARY-START(85899658419)
            /*void */ ToDesktop()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899658419);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.isMobileEditor = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899658419)
            
            //--TRIMMABLE-BOUNDARY-START(12885214387)
            /*WidgetDimension */ get CurrentField()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475148979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.isMobileEditor ? this.Field.LCFCR$IReactiveObservable$$$Value.Mobile : this.Field.LCFCR$IReactiveObservable$$$Value.Desktop;
            }
            /*WidgetDimension */ set CurrentField(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719789235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.isMobileEditor)
                {
                    this.Field.LCFCR$IReactiveObservable$$$Value = $.$with(this.Field.LCFCR$IReactiveObservable$$$Value, ($clone) =>
                    {
                        $clone.Mobile = $.$clone(value);
                    });
                }
                else 
                {
                    this.Field.LCFCR$IReactiveObservable$$$Value = $.$with(this.Field.LCFCR$IReactiveObservable$$$Value, ($clone) =>
                    {
                        $clone.Desktop = $.$clone(value);
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885214387)
            
            //--TRIMMABLE-BOUNDARY-START(81604691123)
            /*void */ SetUnit(/*WidgetDimensionUnit*/ unit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604691123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CurrentField = $.$with(this.CurrentField, ($clone) =>
                {
                    $clone.Unit = unit;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(81604691123)
            
            //--TRIMMABLE-BOUNDARY-START(94489593011)
            /*int */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244952755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrentField.Value ?? 0;
            }
            /*int */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309723827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CurrentField = $.$with(this.CurrentField, ($clone) =>
                {
                    $clone.Value = value;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94489593011)
            
            //--TRIMMABLE-BOUNDARY-START(55834887347)
            /*int */ get Max()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065083571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = this.CurrentField.Unit;
                switch($switch1)
                {
                    case 2/*WidgetDimensionUnit.Percentage*/:
                    return 100;
                }
                return $.$$.S.Math.Max$4(100, (((this.CurrentField.Value ?? 0) * 2) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(55834887347)
            
            //--TRIMMABLE-BOUNDARY-START(60129854643)
            /*string */ get OptimizedComponentName()
            {
                return "widgetdimensioneditor";
            }
            //--TRIMMABLE-BOUNDARY-END(60129854643)
            
            //--TRIMMABLE-BOUNDARY-START(8590247091)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590247091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(this.OwnAttributes(null))));
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "row");
                __builder.OpenElement(4, "div");
                __builder.AddAttribute$5(5, "class", "col-10");
                __builder.AddContent$4(6, this.Field.LCFCD$1$IObservableDataDescriptor$Label);
                __builder.AddMarkupContent(7, "\r\n            ");
                __builder.OpenElement(8, "i");
                __builder.AddAttribute$5(9, "class", $.$strNN($.$strNN($.$strNN("mgl-1" + " mdi") + " mdi-desktop-mac") + " ") + $.$strNN((this.isMobileEditor ? "" : "op-7")));
                __builder.AddAttribute$5(10, "title", "Desktop");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 11, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToDesktop)));
                __builder.CloseElement();
                __builder.AddMarkupContent(12, "\r\n            ");
                __builder.OpenElement(13, "i");
                __builder.AddAttribute$5(14, "class", $.$strNN($.$strNN($.$strNN("mgl-1" + " mdi") + " mdi-snowmobile") + " ") + $.$strNN((!this.isMobileEditor ? "" : "op-7")));
                __builder.AddAttribute$5(15, "title", "Mobile");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 16, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToMobile)));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(17, "\r\n        ");
                __builder.OpenElement(18, "div");
                __builder.AddAttribute$5(19, "class", "col-a flex text-right fsz-smaller");
                let $i2 = 0;
                let $arr2 = $.$$.S.Enum.GetValues$1($.$bMcF.LFCW.WidgetDimensionUnit);
                while ($i2 < $arr2.length)
                {
                    let unit = $arr2[$i2++];
                    /*var*/ let title = $.$fPer.LCFCT.EnumExtensions.GetTitle($.$box(unit, $.$bMcF.LFCW.WidgetDimensionUnit));
                    __builder.OpenElement(20, "a");
                    __builder.AddAttribute$5(21, "class", $.$strNN($.$strNN("mgl-2" + " clickable") + " ") + $.$strNN((this.CurrentField.Unit === unit ? "text-underline" : "")));
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 22, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                    {
                        return this.SetUnit(unit);
                    }, $ZFYfde ??= {"r":65537,"n":"","d":312499,"h":0,"f":17825794})));
                    __builder.AddContent$4(23, title);
                    __builder.CloseElement();
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(24, "\r\n    ");
                __builder.OpenElement(25, "div");
                __builder.AddAttribute$5(26, "class", "row mgt");
                __builder.OpenElement(27, "div");
                __builder.AddAttribute$5(28, "class", "col-10");
                __builder.OpenElement(29, "input");
                __builder.AddAttribute$5(30, "class", "wf");
                __builder.AddAttribute$5(31, "type", "range");
                __builder.AddAttribute$5(32, "min", "0");
                __builder.AddAttribute$4(33, "max", $.$box(this.Max, $.$$.S.Int32));
                __builder.AddAttribute$5(34, "value", $.$mac.MAC.BindConverter.FormatValue$10(this.Value, null));
                __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 35, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$10($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.Int32))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.Value = __value;
                }, $LNAqtd ??= {"r":65537,"p":[{"n":"__value","p":655361}],"n":"","d":312499,"h":0,"f":17825794}), this.Value, null));
                __builder.SetUpdatesAttributeName("value");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(36, "\r\n        ");
                __builder.OpenElement(37, "div");
                __builder.AddAttribute$5(38, "class", "col-a mgl");
                __builder.OpenElement(39, "input");
                __builder.AddAttribute$5(40, "type", "number");
                __builder.AddAttribute$5(41, "class", "cl-text wx-05 bg-transparent bd corner-1 pd-1");
                __builder.AddAttribute$5(42, "value", $.$mac.MAC.BindConverter.FormatValue$10(this.Value, $.$$.SG.CultureInfo.InvariantCulture));
                __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 43, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$10($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.Int32))().$ctor(this,  (/**/ __value) =>
                {
                    return this.Value = __value;
                }, $FYOZoe ??= {"r":65537,"p":[{"n":"__value","p":655361}],"n":"","d":312499,"h":0,"f":17825794}), this.Value, $.$$.SG.CultureInfo.InvariantCulture));
                __builder.SetUpdatesAttributeName("value");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590247091)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295279795)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295279795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295279795)
            
            //--TRIMMABLE-BOUNDARY-START(4295279795)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295279795)
            
            static $h = 312499;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCI.BaseInputField$$($.$bMcF.LFCW.WidgetResponsive$$($.$bMcF.LFCW.WidgetDimension)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885214387),
    {
      "p": 10694384,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475148979,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719789235,
        "f": 83886082
      },
      "n": "CurrentField",
      "d": 312499,
      "h": 12885214387,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(12885214387),
//--TRIMMABLE-BOUNDARY-START(94489593011),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244952755,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309723827,
        "f": 83886082
      },
      "n": "Value",
      "d": 312499,
      "h": 94489593011,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(94489593011),
//--TRIMMABLE-BOUNDARY-START(55834887347),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065083571,
        "f": 50331650
      },
      "n": "Max",
      "d": 312499,
      "h": 55834887347,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55834887347),
//--TRIMMABLE-BOUNDARY-START(60129854643),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655018163,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 312499,
      "h": 60129854643,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60129854643)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90194625715),
    {
      "r": 65537,
      "n": "ToMobile",
      "d": 312499,
      "h": 90194625715,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90194625715),
//--TRIMMABLE-BOUNDARY-START(85899658419),
    {
      "r": 65537,
      "n": "ToDesktop",
      "d": 312499,
      "h": 85899658419,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85899658419),
//--TRIMMABLE-BOUNDARY-START(81604691123),
    {
      "r": 65537,
      "p": [
        {
          "n": "unit",
          "p": 10890992
        }
      ],
      "n": "SetUnit",
      "d": 312499,
      "h": 81604691123,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81604691123),
//--TRIMMABLE-BOUNDARY-START(8590247091),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 312499,
      "h": 8590247091,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590247091)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51539920051),
    {
      "t": 262145,
      "n": "isMobileEditor",
      "d": 312499,
      "h": 51539920051,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51539920051)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295279795),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 312499,
      "h": 4295279795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295279795)
  ],
  "h": 312499
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Editor.WidgetDimensionEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Editor${separator}WidgetDimensionEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(312499)
        
        

        //--TRIMMABLE-BOUNDARY-START(246963)
        $asm.$cls(`$rfUg.LCFCFE.WidgetBoundingBoxEditor`, ($self) => class WidgetBoundingBoxEditor extends $.$hDPm.LCFCI.BaseInputField$$($.$bMcF.LFCW.WidgetResponsive$$($.$bMcF.LFCW.WidgetBoundingBox))
        {
            //--TRIMMABLE-BOUNDARY-START(73014690995)
            /*bool*/ isMobileEditor = false;
            //--TRIMMABLE-BOUNDARY-END(73014690995)
            
            //--TRIMMABLE-BOUNDARY-START(167503971507)
            /*void */ ToMobile()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167503971507);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.isMobileEditor = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167503971507)
            
            //--TRIMMABLE-BOUNDARY-START(158914036915)
            /*void */ ToDesktop()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914036915);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.isMobileEditor = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914036915)
            
            //--TRIMMABLE-BOUNDARY-START(17180116147)
            /*WidgetBoundingBox */ get CurrentField()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359985331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.isMobileEditor ? this.Field.LCFCR$IReactiveObservable$$$Value.Mobile : this.Field.LCFCR$IReactiveObservable$$$Value.Desktop;
            }
            /*WidgetBoundingBox */ set CurrentField(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374429363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.isMobileEditor)
                {
                    this.Field.LCFCR$IReactiveObservable$$$Value = $.$with(this.Field.LCFCR$IReactiveObservable$$$Value, ($clone) =>
                    {
                        $clone.Mobile = $.$clone(value);
                    });
                }
                else 
                {
                    this.Field.LCFCR$IReactiveObservable$$$Value = $.$with(this.Field.LCFCR$IReactiveObservable$$$Value, ($clone) =>
                    {
                        $clone.Desktop = $.$clone(value);
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180116147)
            
            //--TRIMMABLE-BOUNDARY-START(81604625587)
            /*bool*/ linkedValues = false;
            //--TRIMMABLE-BOUNDARY-END(81604625587)
            
            //--TRIMMABLE-BOUNDARY-START(163209004211)
            /*void */ ToggleLinkValues()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209004211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.linkedValues = !this.linkedValues;
                if (this.linkedValues)
                {
                    this.CurrentField = $.$with(this.CurrentField, ($clone) =>
                    {
                        $clone.Top = this.CurrentField.Top;
                        $clone.Bottom = this.CurrentField.Top;
                        $clone.Left = this.CurrentField.Top;
                        $clone.Right = this.CurrentField.Top;
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209004211)
            
            //--TRIMMABLE-BOUNDARY-START(154619069619)
            /*void */ SetUnit(/*WidgetDimensionUnit*/ unit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619069619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CurrentField = $.$with(this.CurrentField, ($clone) =>
                {
                    $clone.Unit = unit;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(154619069619)
            
            //--TRIMMABLE-BOUNDARY-START(171798938803)
            /*int? */ get Top()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719723699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrentField.Top;
            }
            /*int? */ set Top(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144233139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetTop(value);
            }
            //--TRIMMABLE-BOUNDARY-END(171798938803)
            
            //--TRIMMABLE-BOUNDARY-START(8590181555)
            /*int? */ get Bottom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770050739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrentField.Bottom;
            }
            /*int? */ set Bottom(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784494771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetBottom(value);
            }
            //--TRIMMABLE-BOUNDARY-END(8590181555)
            
            //--TRIMMABLE-BOUNDARY-START(77309658291)
            /*int? */ get Left()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949919923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrentField.Left;
            }
            /*int? */ set Left(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964363955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetLeft(value);
            }
            //--TRIMMABLE-BOUNDARY-END(77309658291)
            
            //--TRIMMABLE-BOUNDARY-START(90194560179)
            /*int? */ get Right()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129789107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrentField.Right;
            }
            /*int? */ set Right(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554298547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetRight(value);
            }
            //--TRIMMABLE-BOUNDARY-END(90194560179)
            
            //--TRIMMABLE-BOUNDARY-START(150324102323)
            /*void */ SetTop(/*int?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324102323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.linkedValues)
                {
                    this.CurrentField = $.$with(this.CurrentField, ($clone) =>
                    {
                        $clone.Top = value;
                        $clone.Bottom = value;
                        $clone.Left = value;
                        $clone.Right = value;
                    });
                }
                else 
                {
                    this.CurrentField = $.$with(this.CurrentField, ($clone) =>
                    {
                        $clone.Top = value;
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324102323)
            
            //--TRIMMABLE-BOUNDARY-START(137439200435)
            /*void */ SetBottom(/*int?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439200435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.linkedValues)
                {
                    this.CurrentField = $.$with(this.CurrentField, ($clone) =>
                    {
                        $clone.Top = value;
                        $clone.Bottom = value;
                        $clone.Left = value;
                        $clone.Right = value;
                    });
                }
                else 
                {
                    this.CurrentField = $.$with(this.CurrentField, ($clone) =>
                    {
                        $clone.Bottom = value;
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439200435)
            
            //--TRIMMABLE-BOUNDARY-START(141734167731)
            /*void */ SetLeft(/*int?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734167731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.linkedValues)
                {
                    this.CurrentField = $.$with(this.CurrentField, ($clone) =>
                    {
                        $clone.Top = value;
                        $clone.Bottom = value;
                        $clone.Left = value;
                        $clone.Right = value;
                    });
                }
                else 
                {
                    this.CurrentField = $.$with(this.CurrentField, ($clone) =>
                    {
                        $clone.Left = value;
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734167731)
            
            //--TRIMMABLE-BOUNDARY-START(146029135027)
            /*void */ SetRight(/*int?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029135027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.linkedValues)
                {
                    this.CurrentField = $.$with(this.CurrentField, ($clone) =>
                    {
                        $clone.Top = value;
                        $clone.Bottom = value;
                        $clone.Left = value;
                        $clone.Right = value;
                    });
                }
                else 
                {
                    this.CurrentField = $.$with(this.CurrentField, ($clone) =>
                    {
                        $clone.Right = value;
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029135027)
            
            //--TRIMMABLE-BOUNDARY-START(85899592883)
            /*string */ get OptimizedComponentName()
            {
                return "widgetboundingboxeditor";
            }
            //--TRIMMABLE-BOUNDARY-END(85899592883)
            
            //--TRIMMABLE-BOUNDARY-START(12885148851)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885148851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(this.OwnAttributes(null))));
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "row");
                __builder.OpenElement(4, "div");
                __builder.AddAttribute$5(5, "class", "col-10");
                __builder.AddContent$4(6, this.Field.LCFCD$1$IObservableDataDescriptor$Label);
                __builder.AddMarkupContent(7, "\r\n            ");
                __builder.OpenElement(8, "i");
                __builder.AddAttribute$5(9, "class", $.$strNN($.$strNN($.$strNN("mgl-1" + " mdi") + " mdi-desktop-mac") + " ") + $.$strNN((this.isMobileEditor ? "" : "op-7")));
                __builder.AddAttribute$5(10, "title", "Desktop");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 11, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToDesktop)));
                __builder.CloseElement();
                __builder.AddMarkupContent(12, "\r\n            ");
                __builder.OpenElement(13, "i");
                __builder.AddAttribute$5(14, "class", $.$strNN($.$strNN($.$strNN("mgl-1" + " mdi") + " mdi-snowmobile") + " ") + $.$strNN((!this.isMobileEditor ? "" : "op-7")));
                __builder.AddAttribute$5(15, "title", "Mobile");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 16, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToMobile)));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(17, "\r\n        ");
                __builder.OpenElement(18, "div");
                __builder.AddAttribute$5(19, "class", "col-a flex text-right fsz-smaller");
                let $i1 = 0;
                let $arr1 = $.$$.S.Enum.GetValues$1($.$bMcF.LFCW.WidgetDimensionUnit);
                while ($i1 < $arr1.length)
                {
                    let unit = $arr1[$i1++];
                    /*var*/ let title = $.$fPer.LCFCT.EnumExtensions.GetTitle($.$box(unit, $.$bMcF.LFCW.WidgetDimensionUnit));
                    __builder.OpenElement(20, "a");
                    __builder.AddAttribute$5(21, "class", $.$strNN($.$strNN("mgl-2" + " clickable") + " ") + $.$strNN((this.CurrentField.Unit === unit ? "text-underline" : "")));
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 22, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                    {
                        return this.SetUnit(unit);
                    }, $BzBIRe ??= {"r":65537,"n":"","d":246963,"h":0,"f":17825794})));
                    __builder.AddContent$4(23, title);
                    __builder.CloseElement();
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(24, "\r\n    ");
                __builder.OpenElement(25, "div");
                __builder.AddAttribute$5(26, "class", "row mgt bd corner");
                __builder.OpenElement(27, "div");
                __builder.AddAttribute$5(28, "class", "col-2 bdr");
                __builder.OpenElement(29, "input");
                __builder.AddAttribute$5(30, "title", "Top");
                __builder.AddAttribute$5(31, "type", "text");
                __builder.AddAttribute$5(32, "class", "cl-text wf bg-transparent bd-0 pd-1");
                __builder.AddAttribute$5(33, "value", $.$mac.MAC.BindConverter.FormatValue$22(this.Top, null));
                __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 34, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$22($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.Nullable$$($.$$.S.Int32)))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.Top = __value;
                }, $qMrnqf ??= {"r":65537,"p":[{"n":"__value","p":$.$typeNullable($.$$.S.Int32).$h}],"n":"","d":246963,"h":0,"f":17825794}), this.Top, null));
                __builder.SetUpdatesAttributeName("value");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(35, "\r\n        ");
                __builder.OpenElement(36, "div");
                __builder.AddAttribute$5(37, "class", "col-2 bdr");
                __builder.OpenElement(38, "input");
                __builder.AddAttribute$5(39, "title", "Right");
                __builder.AddAttribute$5(40, "type", "text");
                __builder.AddAttribute$5(41, "class", "cl-text wf bg-transparent bd-0 pd-1");
                __builder.AddAttribute$5(42, "value", $.$mac.MAC.BindConverter.FormatValue$22(this.Right, null));
                __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 43, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$22($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.Nullable$$($.$$.S.Int32)))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.Right = __value;
                }, $iMLMIf ??= {"r":65537,"p":[{"n":"__value","p":$.$typeNullable($.$$.S.Int32).$h}],"n":"","d":246963,"h":0,"f":17825794}), this.Right, null));
                __builder.SetUpdatesAttributeName("value");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(44, "\r\n        ");
                __builder.OpenElement(45, "div");
                __builder.AddAttribute$5(46, "class", "col-2 bdr");
                __builder.OpenElement(47, "input");
                __builder.AddAttribute$5(48, "title", "Bottom");
                __builder.AddAttribute$5(49, "type", "text");
                __builder.AddAttribute$5(50, "class", "cl-text wf bg-transparent bd-0 pd-1");
                __builder.AddAttribute$5(51, "value", $.$mac.MAC.BindConverter.FormatValue$22(this.Bottom, null));
                __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 52, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$22($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.Nullable$$($.$$.S.Int32)))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.Bottom = __value;
                }, $uDGtRb ??= {"r":65537,"p":[{"n":"__value","p":$.$typeNullable($.$$.S.Int32).$h}],"n":"","d":246963,"h":0,"f":17825794}), this.Bottom, null));
                __builder.SetUpdatesAttributeName("value");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(53, "\r\n        ");
                __builder.OpenElement(54, "div");
                __builder.AddAttribute$5(55, "class", "col-2 bdr");
                __builder.OpenElement(56, "input");
                __builder.AddAttribute$5(57, "title", "Left");
                __builder.AddAttribute$5(58, "type", "text");
                __builder.AddAttribute$5(59, "class", "cl-text wf bg-transparent bd-0 pd-1");
                __builder.AddAttribute$5(60, "value", $.$mac.MAC.BindConverter.FormatValue$22(this.Left, null));
                __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 61, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$22($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.Nullable$$($.$$.S.Int32)))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.Left = __value;
                }, $YMDisb ??= {"r":65537,"p":[{"n":"__value","p":$.$typeNullable($.$$.S.Int32).$h}],"n":"","d":246963,"h":0,"f":17825794}), this.Left, null));
                __builder.SetUpdatesAttributeName("value");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(62, "\r\n        ");
                __builder.OpenElement(63, "div");
                __builder.AddAttribute$5(64, "class", "col-2 flex");
                __builder.OpenElement(65, "i");
                __builder.AddAttribute$5(66, "class", $.$strNN($.$strNN($.$strNN("mdi" + " mdi-link") + $.$strNN((!this.linkedValues ? "-off" : ""))) + " mg-a") + " clickable");
                __builder.AddAttribute$5(67, "title", "Link values");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 68, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToggleLinkValues)));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12885148851)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295214259)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295214259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295214259)
            
            //--TRIMMABLE-BOUNDARY-START(4295214259)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295214259)
            
            static $h = 246963;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCI.BaseInputField$$($.$bMcF.LFCW.WidgetResponsive$$($.$bMcF.LFCW.WidgetBoundingBox)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180116147),
    {
      "p": 10432240,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359985331,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374429363,
        "f": 83886082
      },
      "n": "CurrentField",
      "d": 246963,
      "h": 17180116147,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17180116147),
//--TRIMMABLE-BOUNDARY-START(171798938803),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719723699,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144233139,
        "f": 83886082
      },
      "n": "Top",
      "d": 246963,
      "h": 171798938803,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(171798938803),
//--TRIMMABLE-BOUNDARY-START(8590181555),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770050739,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784494771,
        "f": 83886082
      },
      "n": "Bottom",
      "d": 246963,
      "h": 8590181555,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8590181555),
//--TRIMMABLE-BOUNDARY-START(77309658291),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949919923,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964363955,
        "f": 83886082
      },
      "n": "Left",
      "d": 246963,
      "h": 77309658291,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(77309658291),
//--TRIMMABLE-BOUNDARY-START(90194560179),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129789107,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554298547,
        "f": 83886082
      },
      "n": "Right",
      "d": 246963,
      "h": 90194560179,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(90194560179),
//--TRIMMABLE-BOUNDARY-START(85899592883),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539854515,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 246963,
      "h": 85899592883,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(85899592883)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(167503971507),
    {
      "r": 65537,
      "n": "ToMobile",
      "d": 246963,
      "h": 167503971507,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167503971507),
//--TRIMMABLE-BOUNDARY-START(158914036915),
    {
      "r": 65537,
      "n": "ToDesktop",
      "d": 246963,
      "h": 158914036915,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158914036915),
//--TRIMMABLE-BOUNDARY-START(163209004211),
    {
      "r": 65537,
      "n": "ToggleLinkValues",
      "d": 246963,
      "h": 163209004211,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163209004211),
//--TRIMMABLE-BOUNDARY-START(154619069619),
    {
      "r": 65537,
      "p": [
        {
          "n": "unit",
          "p": 10890992
        }
      ],
      "n": "SetUnit",
      "d": 246963,
      "h": 154619069619,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(154619069619),
//--TRIMMABLE-BOUNDARY-START(150324102323),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Int32).$h
        }
      ],
      "n": "SetTop",
      "d": 246963,
      "h": 150324102323,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(150324102323),
//--TRIMMABLE-BOUNDARY-START(137439200435),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Int32).$h
        }
      ],
      "n": "SetBottom",
      "d": 246963,
      "h": 137439200435,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137439200435),
//--TRIMMABLE-BOUNDARY-START(141734167731),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Int32).$h
        }
      ],
      "n": "SetLeft",
      "d": 246963,
      "h": 141734167731,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141734167731),
//--TRIMMABLE-BOUNDARY-START(146029135027),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Int32).$h
        }
      ],
      "n": "SetRight",
      "d": 246963,
      "h": 146029135027,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(146029135027),
//--TRIMMABLE-BOUNDARY-START(12885148851),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 246963,
      "h": 12885148851,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885148851)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73014690995),
    {
      "t": 262145,
      "n": "isMobileEditor",
      "d": 246963,
      "h": 73014690995,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73014690995),
//--TRIMMABLE-BOUNDARY-START(81604625587),
    {
      "t": 262145,
      "n": "linkedValues",
      "d": 246963,
      "h": 81604625587,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81604625587)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295214259),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 246963,
      "h": 4295214259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295214259)
  ],
  "h": 246963
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Editor.WidgetBoundingBoxEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Editor${separator}WidgetBoundingBoxEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(246963)
        
        

        //--TRIMMABLE-BOUNDARY-START(2213043)
        $asm.$cls(`$rfUg.LCFCFR.PositionedGridRenderView`, ($self) => class PositionedGridRenderView extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$bMcF.LFCW.PositionedGridWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(111671362739)
            /*string */ get OptimizedComponentName()
            {
                return "positionedgridrenderview";
            }
            //--TRIMMABLE-BOUNDARY-END(111671362739)
            
            //--TRIMMABLE-BOUNDARY-START(193275741363)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275741363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Renderer":
                    this.Renderer = $.$cast(parameter.Value, $.$rfUg.LCFCFR.PositionedGridRenderer);
                    return true;
                    case "DataSource":
                    this.DataSource = $.$cast(parameter.Value, $.$bMcF.LFCD.IWidgetDataSource);
                    return true;
                    case "Root":
                    this.Root = $.$cast(parameter.Value, $.$bMcF.LFCR.IRootWidgetRenderer);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(193275741363)
            
            //--TRIMMABLE-BOUNDARY-START(94491493555)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491493555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.JS = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(94491493555)
            
            //--TRIMMABLE-BOUNDARY-START(98786460851)
            /*IJavaScriptRunner*/ JS = null;
            //--TRIMMABLE-BOUNDARY-END(98786460851)
            
            //--TRIMMABLE-BOUNDARY-START(137441166515)
            /*PositionedGridRenderer*/ Renderer = null;
            //--TRIMMABLE-BOUNDARY-END(137441166515)
            
            //--TRIMMABLE-BOUNDARY-START(38656918707)
            /*IWidgetDataSource*/ DataSource = null;
            //--TRIMMABLE-BOUNDARY-END(38656918707)
            
            //--TRIMMABLE-BOUNDARY-START(141736133811)
            /*IRootWidgetRenderer*/ Root = null;
            //--TRIMMABLE-BOUNDARY-END(141736133811)
            
            //--TRIMMABLE-BOUNDARY-START(201865675955)
            /*ElementReference*/ workArea;
            //--TRIMMABLE-BOUNDARY-END(201865675955)
            
            //--TRIMMABLE-BOUNDARY-START(30066984115)
            /*Dictionary<Widget, ElementReference>*/ childrenElement = null;
            //--TRIMMABLE-BOUNDARY-END(30066984115)
            
            //--TRIMMABLE-BOUNDARY-START(34361951411)
            /*Dictionary<Widget, (double Left, double Top, string Transition)>*/ childrenState = null;
            //--TRIMMABLE-BOUNDARY-END(34361951411)
            
            //--TRIMMABLE-BOUNDARY-START(206160643251)
            /*BoxSize?*/ workAreaSize = null;
            //--TRIMMABLE-BOUNDARY-END(206160643251)
            
            //--TRIMMABLE-BOUNDARY-START(107376395443)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376395443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = this.UnitOfWork.LCFCI$IClientUnitOfWork$Assets.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResolvePath(this.Assets.get_Item$1("LivingThing.Core.Frameworks.Client.FluentUI.Blazor.bundle.scp.css"), true, false, false) ], null, null));
                this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$add_BoxChanged(new ($.$fPer.LCFC.AsyncEventHandler$$($.$vWqU.LCFCC.BoxSize))().$ctor(this, this.UI_BoxChanged));
                let $en2 = this.ViewModel.Children.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let w = $en2.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let placement = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$bMcF.LFCW.PositionedGridWidget.Point, this.ViewModel.Placements, w.Id);
                        /*var*/ let origLeft = placement.Left;
                        /*var*/ let origTop = placement.Top;
                        this.childrenState.set_Item(w, new ($.$$.S.ValueTuple$$$$($.$$.S.Double, $.$$.S.Double, $.$$.S.String))().$ctor$3(origLeft, origTop, "none"));
                    }
                }
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(107376395443)
            
            //--TRIMMABLE-BOUNDARY-START(42951886003)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951886003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$add_BoxChanged(new ($.$fPer.LCFC.AsyncEventHandler$$($.$vWqU.LCFCC.BoxSize))().$ctor(this, this.UI_BoxChanged));
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(42951886003)
            
            //--TRIMMABLE-BOUNDARY-START(197570708659)
            /*Task *//*async*/  UI_BoxChanged(/*object*/ sender, /*BoxSize?*/ e)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197570708659);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.workAreaSize = ($t3 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.GetSize(this.JS, this.workArea), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(197570708659)
            
            //--TRIMMABLE-BOUNDARY-START(103081428147)
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103081428147);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (firstRender)
                    {
                        let $t4, $r4;
                        this.workAreaSize = ($t4 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.GetSize(this.JS, this.workArea), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                    ($t5 = super.OnAfterRenderAsync(firstRender), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103081428147)
            
            //--TRIMMABLE-BOUNDARY-START(47246853299)
            /*Widget?*/ dragging = null;
            //--TRIMMABLE-BOUNDARY-END(47246853299)
            
            //--TRIMMABLE-BOUNDARY-START(184685806771)
            /*double*/ startX = 0;
            //--TRIMMABLE-BOUNDARY-END(184685806771)
            
            //--TRIMMABLE-BOUNDARY-START(188980774067)
            /*double*/ startY = 0;
            //--TRIMMABLE-BOUNDARY-END(188980774067)
            
            //--TRIMMABLE-BOUNDARY-START(115966330035)
            /*double*/ origLeft = 0;
            //--TRIMMABLE-BOUNDARY-END(115966330035)
            
            //--TRIMMABLE-BOUNDARY-START(120261297331)
            /*double*/ origTop = 0;
            //--TRIMMABLE-BOUNDARY-END(120261297331)
            
            //--TRIMMABLE-BOUNDARY-START(124556264627)
            /*Task *//*async*/  PointerDown(/*Widget*/ widget, /*PointerEventArgs*/ ev)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124556264627);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.Root.LFCR$IRootWidgetRenderer$EditMode !== 1/*FluentUIEditMode.Editting*/)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    this.dragging = widget;
                    ($t6 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.SetPointerCapture(this.JS, this.childrenElement.get_Item(widget), ev.PointerId), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    this.startX = ev.ClientX;
                    this.startY = ev.ClientY;
                    /*var*/ let placement = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$bMcF.LFCW.PositionedGridWidget.Point, this.ViewModel.Placements, widget.Id);
                    this.origLeft = placement.Left;
                    this.origTop = placement.Top;
                    this.childrenState.set_Item(widget, $.$with($.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$bMcF.LFCW.Widget, $.$$.S.ValueTuple$$$$($.$$.S.Double, $.$$.S.Double, $.$$.S.String), this.childrenState, widget), ($clone) =>
                    {
                        $clone.Item1 = this.origLeft;
                        $clone.Item2 = this.origTop;
                        $clone.Item3 = "none";
                    }));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(124556264627)
            
            //--TRIMMABLE-BOUNDARY-START(180390839475)
            /*void */ snapToGrid(/*ref double*/ x, /*ref double*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390839475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let gWPx = this.ViewModel.GridSize * this.workAreaSize.Width / 100;
                /*var*/ let gHPx = this.ViewModel.GridSize * this.workAreaSize.Height / 100;
                /*var*/ let snappedX = $.$$.S.Math.Round$7(x.$v / gWPx) * gWPx;
                /*var*/ let snappedY = $.$$.S.Math.Round$7(y.$v / gHPx) * gHPx;
                x.$v = snappedX * 100 / this.workAreaSize.Width;
                y.$v = snappedY * 100 / this.workAreaSize.Height;
                if (x.$v > 100)
                {
                    x.$v = 100;
                }
                if (x.$v < 0)
                {
                    x.$v = 0;
                }
                if (y.$v > 100)
                {
                    y.$v = 100;
                }
                if (y.$v < 0)
                {
                    y.$v = 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180390839475)
            
            //--TRIMMABLE-BOUNDARY-START(128851231923)
            /*Task *//*async*/  PointerMove(/*Widget*/ widget, /*PointerEventArgs*/ ev)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128851231923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.Root.LFCR$IRootWidgetRenderer$EditMode !== 1/*FluentUIEditMode.Editting*/)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    if (this.dragging === null || this.workAreaSize === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    /*var*/ let origLeftPx = this.origLeft * this.workAreaSize.Width / 100;
                    /*var*/ let origTopPx = this.origTop * this.workAreaSize.Height / 100;
                    /*var*/ let deltaX = ev.ClientX - this.startX;
                    /*var*/ let deltaY = ev.ClientY - this.startY;
                    /*var*/ let newLeft = origLeftPx + deltaX + this.workAreaSize.ScrollLeft;
                    /*var*/ let newTop = origTopPx + deltaY + this.workAreaSize.ScrollTop;
                    newLeft = (ev.ClientX - this.workAreaSize.Left) + this.workAreaSize.ScrollLeft - (this.startX - this.workAreaSize.Left - origLeftPx);
                    newTop = (ev.ClientY - this.workAreaSize.Top) + this.workAreaSize.ScrollTop - (this.startY - this.workAreaSize.Top - origTopPx);
                    this.snapToGrid($.$ref(() => newLeft, ($v) => newLeft = $v, $.$$.S.Double), $.$ref(() => newTop, ($v) => newTop = $v, $.$$.S.Double));
                    this.childrenState.set_Item(widget, $.$with($.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$bMcF.LFCW.Widget, $.$$.S.ValueTuple$$$$($.$$.S.Double, $.$$.S.Double, $.$$.S.String), this.childrenState, widget), ($clone) =>
                    {
                        $clone.Item1 = $.$$.S.Math.Max$2(0, newLeft);
                        $clone.Item2 = $.$$.S.Math.Max$2(0, newTop);
                    }));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(128851231923)
            
            //--TRIMMABLE-BOUNDARY-START(133146199219)
            /*Task *//*async*/  PointerUp(/*Widget*/ widget, /*PointerEventArgs*/ ev)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133146199219);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.Root.LFCR$IRootWidgetRenderer$EditMode !== 1/*FluentUIEditMode.Editting*/)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    if (this.dragging === null || this.workAreaSize === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    this.dragging = null;
                    ($t9 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.ReleasePointerCapture(this.JS, this.childrenElement.get_Item(widget), ev.PointerId), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    /*var*/ let lt = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$bMcF.LFCW.Widget, $.$$.S.ValueTuple$$$$($.$$.S.Double, $.$$.S.Double, $.$$.S.String), this.childrenState, widget);
                    this.childrenState.set_Item(widget, $.$with(lt, ($clone) =>
                    {
                        $clone.Item3 = "";
                    }));
                    this.ViewModel.Placements.set_Item(widget.Id, (() =>
                    {
                        //new $.$bMcF.LFCW.PositionedGridWidget.Point()
                        const $t10 = $.$bMcF.LFCW.PositionedGridWidget.Point;
                        const $i10 = new $t10();
                        $i10.$ctor$2();
                        $i10.Left = lt.Item1;
                        $i10.Top = lt.Item2;
                        return $i10;
                    })());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(133146199219)
            
            //--TRIMMABLE-BOUNDARY-START(25772016819)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772016819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddStyle($.$hDPm.LCFCC$1.ComponentExtension.AddClass($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$3(this.OwnAttributes(null), this.ViewModel.Attributes), "grid-view"), $.$strNN("--grid-size:" + this.ViewModel.GridSize) + "%"))));
                __builder.AddAttribute$5(2, "ondragover", "event.preventDefault();");
                __builder.AddAttribute$5(3, "ondrop", "");
                __builder.AddAttribute$6(4, "b-mhoj1z35m9");
                __builder.AddElementReferenceCapture(5, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.workArea = __value;
                }, $HwYXhc ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":2213043,"h":0,"f":17825794}));
                let $en11 = this.ViewModel.Children.SCG$IEnumerable$$$GetEnumerator();
                while ($en11.SC$1$IEnumerator$MoveNext())
                {
                    let d = $en11.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let state = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$bMcF.LFCW.Widget, $.$$.S.ValueTuple$$$$($.$$.S.Double, $.$$.S.Double, $.$$.S.String), this.childrenState, d);
                        __builder.OpenElement(6, "div");
                        __builder.AddAttribute$5(7, "class", "widget");
                        __builder.AddAttribute$7($.$macw.MACW.PointerEventArgs, 8, "onpointerdown", $.$mac.MAC.EventCallback.Factory.Create$10($.$macw.MACW.PointerEventArgs, this, new ($.$$.S.Func$$$($.$macw.MACW.PointerEventArgs, $.$$.STT.Task))().$ctor(this,  (/*e*/ e) =>
                        {
                            return this.PointerDown(d, e);
                        }, $IHqPgi ??= {"r":178454529,"p":[{"n":"e","p":6946933}],"n":"","d":2213043,"h":0,"f":17825794})));
                        __builder.AddAttribute$7($.$macw.MACW.PointerEventArgs, 9, "onpointermove", $.$mac.MAC.EventCallback.Factory.Create$10($.$macw.MACW.PointerEventArgs, this, new ($.$$.S.Func$$$($.$macw.MACW.PointerEventArgs, $.$$.STT.Task))().$ctor(this,  (/*e*/ e) =>
                        {
                            return this.PointerMove(d, e);
                        }, $DqiZMc ??= {"r":178454529,"p":[{"n":"e","p":6946933}],"n":"","d":2213043,"h":0,"f":17825794})));
                        __builder.AddAttribute$7($.$macw.MACW.PointerEventArgs, 10, "onpointerup", $.$mac.MAC.EventCallback.Factory.Create$10($.$macw.MACW.PointerEventArgs, this, new ($.$$.S.Func$$$($.$macw.MACW.PointerEventArgs, $.$$.STT.Task))().$ctor(this,  (/*e*/ e) =>
                        {
                            return this.PointerUp(d, e);
                        }, $bTLKog ??= {"r":178454529,"p":[{"n":"e","p":6946933}],"n":"","d":2213043,"h":0,"f":17825794})));
                        __builder.AddAttribute$5(11, "style", `left:${$.$strNN(state.Item1)}%;top:${$.$strNN(state.Item2)}%;transistion:${$.$strNN(state.Item3)}`);
                        __builder.AddAttribute$6(12, "b-mhoj1z35m9");
                        __builder.AddElementReferenceCapture(13, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            this.childrenElement.set_Item(d, __value);
                        }, $zcAQnd ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":2213043,"h":0,"f":17825794}));
                        __builder.AddContent$1(14, $.$cast(this.Root.LFCR$IRootWidgetRenderer$Render(d, this.DataSource), $.$mac.MAC.RenderFragment));
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(25772016819)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21477049523)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477049523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477049523)
            
            //--TRIMMABLE-BOUNDARY-START(21477049523)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(21477049523)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(98786460851)
                this.JS = null;
                //--TRIMMABLE-BOUNDARY-END(98786460851)
                
                //--TRIMMABLE-BOUNDARY-START(137441166515)
                this.Renderer = null;
                //--TRIMMABLE-BOUNDARY-END(137441166515)
                
                //--TRIMMABLE-BOUNDARY-START(38656918707)
                this.DataSource = null;
                //--TRIMMABLE-BOUNDARY-END(38656918707)
                
                //--TRIMMABLE-BOUNDARY-START(141736133811)
                this.Root = null;
                //--TRIMMABLE-BOUNDARY-END(141736133811)
                
                //--TRIMMABLE-BOUNDARY-START(201865675955)
                this.workArea = $.$default($.$mac.MAC.ElementReference);
                //--TRIMMABLE-BOUNDARY-END(201865675955)
                
                //--TRIMMABLE-BOUNDARY-START(30066984115)
                this.childrenElement = new ($.$$.SCG.Dictionary$$$($.$bMcF.LFCW.Widget, $.$mac.MAC.ElementReference))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(30066984115)
                
                //--TRIMMABLE-BOUNDARY-START(34361951411)
                this.childrenState = new ($.$$.SCG.Dictionary$$$($.$bMcF.LFCW.Widget, $.$$.S.ValueTuple$$$$($.$$.S.Double, $.$$.S.Double, $.$$.S.String)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(34361951411)
                
            }
            static $h = 2213043;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$bMcF.LFCW.PositionedGridWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111671362739),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016657075,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2213043,
      "h": 111671362739,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(111671362739),
//--TRIMMABLE-BOUNDARY-START(98786460851),
    {
      "p": 64509610,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426722483,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158916002995,
        "f": 83886081
      },
      "n": "JS",
      "d": 2213043,
      "h": 98786460851,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98786460851),
//--TRIMMABLE-BOUNDARY-START(137441166515),
    {
      "p": 2147507,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606591667,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505937587,
        "f": 83886081
      },
      "n": "Renderer",
      "d": 2213043,
      "h": 137441166515,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137441166515),
//--TRIMMABLE-BOUNDARY-START(38656918707),
    {
      "p": 1453808,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836787891,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150326068403,
        "f": 83886081
      },
      "n": "DataSource",
      "d": 2213043,
      "h": 38656918707,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656918707),
//--TRIMMABLE-BOUNDARY-START(141736133811),
    {
      "p": 1978096,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196526259,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176095872179,
        "f": 83886081
      },
      "n": "Root",
      "d": 2213043,
      "h": 141736133811,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141736133811)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(193275741363),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2213043,
      "h": 193275741363,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193275741363),
//--TRIMMABLE-BOUNDARY-START(94491493555),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2213043,
      "h": 94491493555,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94491493555),
//--TRIMMABLE-BOUNDARY-START(107376395443),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 2213043,
      "h": 107376395443,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(107376395443),
//--TRIMMABLE-BOUNDARY-START(42951886003),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2213043,
      "h": 42951886003,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951886003),
//--TRIMMABLE-BOUNDARY-START(197570708659),
    {
      "r": 178454529,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 417192
        }
      ],
      "n": "UI_BoxChanged",
      "d": 2213043,
      "h": 197570708659,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(197570708659),
//--TRIMMABLE-BOUNDARY-START(103081428147),
    {
      "r": 178454529,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": 2213043,
      "h": 103081428147,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(103081428147),
//--TRIMMABLE-BOUNDARY-START(124556264627),
    {
      "r": 178454529,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        },
        {
          "n": "ev",
          "p": 6946933
        }
      ],
      "n": "PointerDown",
      "d": 2213043,
      "h": 124556264627,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(124556264627),
//--TRIMMABLE-BOUNDARY-START(180390839475),
    {
      "r": 65537,
      "p": [
        {
          "n": "x",
          "p": 1179649,
          "f": 4
        },
        {
          "n": "y",
          "p": 1179649,
          "f": 4
        }
      ],
      "n": "snapToGrid",
      "d": 2213043,
      "h": 180390839475,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180390839475),
//--TRIMMABLE-BOUNDARY-START(128851231923),
    {
      "r": 178454529,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        },
        {
          "n": "ev",
          "p": 6946933
        }
      ],
      "n": "PointerMove",
      "d": 2213043,
      "h": 128851231923,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(128851231923),
//--TRIMMABLE-BOUNDARY-START(133146199219),
    {
      "r": 178454529,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        },
        {
          "n": "ev",
          "p": 6946933
        }
      ],
      "n": "PointerUp",
      "d": 2213043,
      "h": 133146199219,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(133146199219),
//--TRIMMABLE-BOUNDARY-START(25772016819),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2213043,
      "h": 25772016819,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25772016819)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(201865675955),
    {
      "t": 1900659,
      "n": "workArea",
      "d": 2213043,
      "h": 201865675955,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(201865675955),
//--TRIMMABLE-BOUNDARY-START(30066984115),
    {
      "t": $.$$.SCG.Dictionary$$$($.$bMcF.LFCW.Widget, $.$mac.MAC.ElementReference).$h,
      "n": "childrenElement",
      "d": 2213043,
      "h": 30066984115,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066984115),
//--TRIMMABLE-BOUNDARY-START(34361951411),
    {
      "t": $.$$.SCG.Dictionary$$$($.$bMcF.LFCW.Widget, $.$$.S.ValueTuple$$$$($.$$.S.Double, $.$$.S.Double, $.$$.S.String)).$h,
      "n": "childrenState",
      "d": 2213043,
      "h": 34361951411,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361951411),
//--TRIMMABLE-BOUNDARY-START(206160643251),
    {
      "t": 417192,
      "n": "workAreaSize",
      "d": 2213043,
      "h": 206160643251,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(206160643251),
//--TRIMMABLE-BOUNDARY-START(47246853299),
    {
      "t": 9907952,
      "n": "dragging",
      "d": 2213043,
      "h": 47246853299,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47246853299),
//--TRIMMABLE-BOUNDARY-START(184685806771),
    {
      "t": 1179649,
      "n": "startX",
      "d": 2213043,
      "h": 184685806771,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(184685806771),
//--TRIMMABLE-BOUNDARY-START(188980774067),
    {
      "t": 1179649,
      "n": "startY",
      "d": 2213043,
      "h": 188980774067,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(188980774067),
//--TRIMMABLE-BOUNDARY-START(115966330035),
    {
      "t": 1179649,
      "n": "origLeft",
      "d": 2213043,
      "h": 115966330035,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(115966330035),
//--TRIMMABLE-BOUNDARY-START(120261297331),
    {
      "t": 1179649,
      "n": "origTop",
      "d": 2213043,
      "h": 120261297331,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120261297331)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477049523),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2213043,
      "h": 21477049523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477049523)
  ],
  "h": 2213043
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.PositionedGridRenderView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}PositionedGridRenderView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2213043)
        
        

        //--TRIMMABLE-BOUNDARY-START(2081971)
        $asm.$cls(`$rfUg.LCFCFR.PlaceholderRenderer`, ($self) => class PlaceholderRenderer extends $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.PlaceHolderWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(4297049267)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297049267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297049267)
            
            //--TRIMMABLE-BOUNDARY-START(4297049267)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297049267)
            
            static $h = 2081971;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.PlaceHolderWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297049267),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2081971,
      "h": 4297049267,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297049267)
  ],
  "h": 2081971
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.PlaceHolderWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.PlaceholderRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}PlaceholderRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2081971)
        
        

        //--TRIMMABLE-BOUNDARY-START(2147507)
        $asm.$cls(`$rfUg.LCFCFR.PositionedGridRenderer`, ($self) => class PositionedGridRenderer extends $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.PositionedGridWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8592082099)
            /*RenderFragment */ RenderToFragment(/*PositionedGridWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592082099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$rfUg.LCFCFR.PositionedGridRenderView, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("ViewModel", widget);
                    $i1.set_Item("Renderer", this);
                    $i1.set_Item("Root", root);
                    $i1.set_Item("DataSource", dataSource);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8592082099)
            
            //--TRIMMABLE-BOUNDARY-START(4297114803)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297114803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297114803)
            
            //--TRIMMABLE-BOUNDARY-START(4297114803)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297114803)
            
            static $h = 2147507;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.PositionedGridWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592082099),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 7876336
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 2147507,
      "h": 8592082099,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8592082099)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297114803),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2147507,
      "h": 4297114803,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297114803)
  ],
  "h": 2147507
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.PositionedGridWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.PositionedGridRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}PositionedGridRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2147507)
        
        

        //--TRIMMABLE-BOUNDARY-START(1885363)
        $asm.$cls(`$rfUg.LCFCFR.LayoutRowRenderer`, ($self) => class LayoutRowRenderer extends $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.RowWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8591819955)
            /*string */ GetClass(/*RowWidget*/ widget)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591819955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `row${$.$strNN((widget.Responsive ? " responsive" : ""))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(8591819955)
            
            //--TRIMMABLE-BOUNDARY-START(4296852659)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296852659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296852659)
            
            //--TRIMMABLE-BOUNDARY-START(4296852659)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296852659)
            
            static $h = 1885363;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.RowWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591819955),
    {
      "r": 1310721,
      "p": [
        {
          "n": "widget",
          "p": 8531696
        }
      ],
      "n": "GetClass",
      "d": 1885363,
      "h": 8591819955,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591819955)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296852659),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1885363,
      "h": 4296852659,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296852659)
  ],
  "h": 1885363
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.RowWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.LayoutRowRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}LayoutRowRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1885363)
        
        

        //--TRIMMABLE-BOUNDARY-START(1295539)
        $asm.$cls(`$rfUg.LCFCFR.GridRenderer`, ($self) => class GridRenderer extends $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.GridWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8591230131)
            /*string */ GetClass(/*GridWidget*/ widget)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591230131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `grid colm-${$.$strNN($.$hDPm.LCFC.UtilityExtensions.Class(widget.GridWidth, false))}${$.$strNN((widget.GridGap > 0 ? ` gap-${$.$strNN($.$hDPm.LCFC.UtilityExtensions.Class10(widget.GridGap))}` : ""))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(8591230131)
            
            //--TRIMMABLE-BOUNDARY-START(12886197427)
            /*RenderFragment */ RenderToFragment(/*GridWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886197427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.RenderToFragment(widget, dataSource, root);
            }
            //--TRIMMABLE-BOUNDARY-END(12886197427)
            
            //--TRIMMABLE-BOUNDARY-START(4296262835)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296262835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296262835)
            
            //--TRIMMABLE-BOUNDARY-START(4296262835)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296262835)
            
            static $h = 1295539;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.GridWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591230131),
    {
      "r": 1310721,
      "p": [
        {
          "n": "widget",
          "p": 5844720
        }
      ],
      "n": "GetClass",
      "d": 1295539,
      "h": 8591230131,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591230131),
//--TRIMMABLE-BOUNDARY-START(12886197427),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 5844720
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 1295539,
      "h": 12886197427,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886197427)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296262835),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1295539,
      "h": 4296262835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296262835)
  ],
  "h": 1295539
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.GridWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.GridRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}GridRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1295539)
        
        

        //--TRIMMABLE-BOUNDARY-START(1819827)
        $asm.$cls(`$rfUg.LCFCFR.LayoutColumnRenderer`, ($self) => class LayoutColumnRenderer extends $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.ColumnWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8591754419)
            /*void */ ApplyWidgetAttributes(/*ColumnWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591754419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (widget.MinimumWidth !== 0)
                {
                    $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$bMcF.LFCW.ColumnWidget).AddAttribute(widget, "class", `miwx-${$.$strNN($.trunc(widget.MinimumWidth / 100))}`);
                }
                super.ApplyWidgetAttributes(widget, dataSource, root);
            }
            //--TRIMMABLE-BOUNDARY-END(8591754419)
            
            //--TRIMMABLE-BOUNDARY-START(12886721715)
            /*string */ GetClass(/*ColumnWidget*/ widget)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886721715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN((widget.Percentage < 0 ? " col-a" : widget.Percentage !== 0 ? `col-${$.$strNN($.trunc(widget.Percentage / 10))}` : ""))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(12886721715)
            
            //--TRIMMABLE-BOUNDARY-START(4296787123)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296787123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296787123)
            
            //--TRIMMABLE-BOUNDARY-START(4296787123)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296787123)
            
            static $h = 1819827;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.ColumnWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591754419),
    {
      "r": 65537,
      "p": [
        {
          "n": "widget",
          "p": 4927216
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "ApplyWidgetAttributes",
      "d": 1819827,
      "h": 8591754419,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591754419),
//--TRIMMABLE-BOUNDARY-START(12886721715),
    {
      "r": 1310721,
      "p": [
        {
          "n": "widget",
          "p": 4927216
        }
      ],
      "n": "GetClass",
      "d": 1819827,
      "h": 12886721715,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886721715)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296787123),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1819827,
      "h": 4296787123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296787123)
  ],
  "h": 1819827
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ColumnWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.LayoutColumnRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}LayoutColumnRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1819827)
        
        

        //--TRIMMABLE-BOUNDARY-START(1361075)
        $asm.$cls(`$rfUg.LCFCFR.HStackRenderer`, ($self) => class HStackRenderer extends $.$rfUg.LCFCFR.StackBaseRenderer$$($.$bMcF.LFCW.HStackWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(4296328371)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296328371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296328371)
            
            //--TRIMMABLE-BOUNDARY-START(4296328371)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296328371)
            
            static $h = 1361075;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.StackBaseRenderer$$($.$bMcF.LFCW.HStackWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296328371),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1361075,
      "h": 4296328371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296328371)
  ],
  "h": 1361075
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.HStackWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.HStackRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}HStackRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1361075)
        
        

        //--TRIMMABLE-BOUNDARY-START(2868403)
        $asm.$cls(`$rfUg.LCFCFR.VStackRenderer`, ($self) => class VStackRenderer extends $.$rfUg.LCFCFR.StackBaseRenderer$$($.$bMcF.LFCW.VStackWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(4297835699)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297835699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297835699)
            
            //--TRIMMABLE-BOUNDARY-START(4297835699)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297835699)
            
            static $h = 2868403;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.StackBaseRenderer$$($.$bMcF.LFCW.VStackWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297835699),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2868403,
      "h": 4297835699,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297835699)
  ],
  "h": 2868403
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.VStackWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.VStackRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}VStackRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2868403)
        
        

        //--TRIMMABLE-BOUNDARY-START(2933939)
        $asm.$cls(`$rfUg.LCFCFR.ZStackRenderer`, ($self) => class ZStackRenderer extends $.$rfUg.LCFCFR.StackBaseRenderer$$($.$bMcF.LFCW.ZStackWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(4297901235)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297901235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297901235)
            
            //--TRIMMABLE-BOUNDARY-START(4297901235)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297901235)
            
            static $h = 2933939;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.StackBaseRenderer$$($.$bMcF.LFCW.ZStackWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297901235),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2933939,
      "h": 4297901235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297901235)
  ],
  "h": 2933939
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.ZStackWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.ZStackRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}ZStackRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2933939)
        
        

        //--TRIMMABLE-BOUNDARY-START(2606259)
        $asm.$cls(`$rfUg.LCFCFR.StackRenderer`, ($self) => class StackRenderer extends $.$rfUg.LCFCFR.StackBaseRenderer$$($.$bMcF.LFCW.StackWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(4297573555)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297573555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297573555)
            
            //--TRIMMABLE-BOUNDARY-START(4297573555)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297573555)
            
            static $h = 2606259;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.StackBaseRenderer$$($.$bMcF.LFCW.StackWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297573555),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2606259,
      "h": 4297573555,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297573555)
  ],
  "h": 2606259
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.StackWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.StackRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}StackRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2606259)
        
        

        //--TRIMMABLE-BOUNDARY-START(2802867)
        $asm.$cls(`$rfUg.LCFCFR.UIRootRenderer`, ($self) => class UIRootRenderer extends $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.UIRootWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(4297770163)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297770163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297770163)
            
            //--TRIMMABLE-BOUNDARY-START(4297770163)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297770163)
            
            static $h = 2802867;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.ContainerRenderer$$($.$bMcF.LFCW.UIRootWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297770163),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2802867,
      "h": 4297770163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297770163)
  ],
  "h": 2802867
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.UIRootWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.UIRootRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}UIRootRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2802867)
        
        

        //--TRIMMABLE-BOUNDARY-START(902323)
        $asm.$cls(`$rfUg.LCFCFR.CardRenderer`, ($self) => class CardRenderer extends $.$rfUg.LCFCFR.ContainerRenderer$$$($.$hDPm.LCFCCC$1.Card, $.$bMcF.LFCW.CardWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(4295869619)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295869619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295869619)
            
            //--TRIMMABLE-BOUNDARY-START(4295869619)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295869619)
            
            static $h = 902323;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.ContainerRenderer$$$($.$hDPm.LCFCCC$1.Card, $.$bMcF.LFCW.CardWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295869619),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 902323,
      "h": 4295869619,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295869619)
  ],
  "h": 902323
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$bMcF.LFCW.CardWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Renderers.CardRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Renderers${separator}CardRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(902323)
        
        

        //--TRIMMABLE-BOUNDARY-START(443571)
        $asm.$cls(`$rfUg.LCFCFE.WidgetIconEditor`, ($self) => class WidgetIconEditor extends $.$hDPm.LCFCI.BaseInputEditor$$($.$bMcF.LFCW.WidgetIcon)
        {
            //--TRIMMABLE-BOUNDARY-START(12885345459)
            /*IEnumerable<KeyValuePair<string, string>> */ Filter$2(/*IEnumerable<KeyValuePair<string, string>>*/ models, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885345459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(key))
                {
                    return models;
                }
                return $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String), models, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String), $.$$.S.Boolean))().$ctor(this,  (/*m*/ m) =>
                {
                    return $.$$.S.String.Contains$2.call(m.Key, key, 3/*StringComparison.InvariantCultureIgnoreCase*/);
                }, $oCGBBi ??= {"r":262145,"p":[{"n":"m","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String).$h}],"n":"","d":443571,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(12885345459)
            
            //--TRIMMABLE-BOUNDARY-START(25770247347)
            /*ValueTask *//*async*/  OnSelected$2(/*IEnumerable<KeyValuePair<string, string>>*/ icon)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770247347);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.ValueChanged.InvokeAsync$1($.$with(this.Value, ($clone) =>
                    {
                        $clone.Icon = $.$sl.SL.Enumerable.FirstOrDefault$3($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String), icon).Value;
                    })), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770247347)
            
            //--TRIMMABLE-BOUNDARY-START(30065214643)
            /*string */ get OptimizedComponentName()
            {
                return "widgeticoneditor";
            }
            //--TRIMMABLE-BOUNDARY-END(30065214643)
            
            //--TRIMMABLE-BOUNDARY-START(8590378163)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590378163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$3.Popup, 0);
                __builder.AddComponentParameter(1, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCP$3.PopupFeatures, (24/*PopupFeatures.Default*/ & ~4/*PopupFeatures.HoverOpen*/) | 8/*PopupFeatures.ClickOpen*/ | 64/*PopupFeatures.Tooltip*/ | 1/*PopupFeatures.Fixed*/), $.$hDPm.LCFCCP$3.PopupFeatures));
                __builder.AddComponentParameter(2, "pop-class", "bg-card shadow pd wx-3 corner-2 z-2");
                __builder.AddAttribute$3(3, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 4);
                        __builder2.AddComponentParameter(5, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddComponentParameter(6, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mg-1 corner-1 wx-03 hx-03 bd pd-0 fsz-15 ${$.$strNN(this.Value.Icon)}`));
                        __builder2.CloseComponent();
                    }, $ghIPFe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":443571,"h":0,"f":17825794});
                }), $mKPIbg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":443571,"h":0,"f":17825794}));
                __builder.AddAttribute$3(7, "Pop", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCP$3.PopupContext))().$ctor(this, ( (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)), 8);
                        __builder2.AddComponentParameter(9, "ItemName", "Icon");
                        __builder2.AddComponentParameter(10, "_Data", "MaterialDesignIconNames.Icons");
                        __builder2.AddComponentParameter(11, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n | 8n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                        __builder2.AddComponentParameter(12, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                        __builder2.AddComponentParameter(13, "SelectedChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String))), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)), $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)), $.$$.STT.ValueTask))().$ctor(this, this.OnSelected$2))));
                        __builder2.AddComponentParameter(14, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                        __builder2.AddComponentParameter(15, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                        __builder2.AddComponentParameter(16, "content-class", "mahx-3");
                        __builder2.AddComponentParameter(17, "li-class", "flex bd corner hx-05 wx-05 mgx-a");
                        __builder2.AddAttribute$3(18, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String), $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)))))().$ctor(this, ( (/*icon*/ icon) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                            {
                                __builder3.OpenElement(19, "i");
                                __builder3.AddAttribute$5(20, "class", $.$strNN($.$strNN("fsz-30" + " mg-a") + " ") + $.$strNN((icon.Data.Value)));
                                __builder3.CloseElement();
                            }, $Gguxch ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":443571,"h":0,"f":17825794});
                        }), $naUcOa ??= {"r":6881395,"p":[{"n":"icon","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String), $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String))).$h}],"n":"","d":443571,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $qldvna ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":443571,"h":0,"f":17825794});
                }), $fToaAg ??= {"r":6881395,"p":[{"n":"context","p":39540394}],"n":"","d":443571,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590378163)
            
            //--TRIMMABLE-BOUNDARY-START(4313011882)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListPreFilterController<System.Collections.Generic.KeyValuePair<string, string>>.Filter(System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, string>>?, string?)
            [`LCFCCD$1$IDataListPreFilterController$System$Collections$Generic$KeyValuePair$System$String$System$String$$Filter`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313011882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313011882)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295410867)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295410867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295410867)
            
            //--TRIMMABLE-BOUNDARY-START(4295410867)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295410867)
            
            static $h = 443571;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCI.BaseInputEditor$$($.$bMcF.LFCW.WidgetIcon); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065214643),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475280051,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 443571,
      "h": 30065214643,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065214643)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885345459),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h,
      "p": [
        {
          "n": "models",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h
        },
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "Filter",
      "o": "@$2",
      "d": 443571,
      "h": 12885345459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885345459),
//--TRIMMABLE-BOUNDARY-START(25770247347),
    {
      "r": 181338113,
      "p": [
        {
          "n": "icon",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h
        }
      ],
      "n": "OnSelected",
      "o": "@$2",
      "d": 443571,
      "h": 25770247347,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(25770247347),
//--TRIMMABLE-BOUNDARY-START(8590378163),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 443571,
      "h": 8590378163,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590378163)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295410867),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 443571,
      "h": 4295410867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295410867)
  ],
  "h": 443571
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$$.S.IDisposable, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetIcon)), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$bMcF.LFCW.WidgetIcon), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetIcon)), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.WidgetIcon)), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$bMcF.LFCW.WidgetIcon), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$bMcF.LFCW.WidgetIcon), $.$hDPm.LCFCCD$1.IDataListPreFilterController$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Editor.WidgetIconEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Editor${separator}WidgetIconEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(443571)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core"));
})();
//--TRIMMABLE-BOUNDARY-END(50355)
