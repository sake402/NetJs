
//--TRIMMABLE-BOUNDARY-START(41472)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $DJRY, $bMcF, $rfUg) {
    "use strict";
    let _;
    let $gekslc;
    let $uYwJRe;
    let $HTPdKk;
    let $IjINqg;
    let $xZIXUe;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", 
    {
  "h": 41472,
  "f": "LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(303616)
        $asm.$cls(`$aElv.LCFCFGF.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295270912)
            static /*void */ AddFuelGaugeWidget(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295270912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rfUg.LCFCFW.Startup.AddWidget($.$aElv.LCFCFGF.FuelGaugeWidget, $.$aElv.LCFCFGF.FuelGaugeWidgetRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295270912)
            
            static $h = 303616;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295270912),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddFuelGaugeWidget",
      "d": 303616,
      "h": 4295270912,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295270912)
  ],
  "h": 303616
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Fuel.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}Fuel${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(303616)
        
        

        //--TRIMMABLE-BOUNDARY-START(696832)
        $asm.$cls(`$aElv.LCFCFGS.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295664128)
            static /*void */ AddSevenSegmentWidget(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295664128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rfUg.LCFCFW.Startup.AddWidget($.$aElv.LCFCFGS.SevenSegmentWidget, $.$aElv.LCFCFGS.SevenSegmentWidgetRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295664128)
            
            static $h = 696832;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295664128),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddSevenSegmentWidget",
      "d": 696832,
      "h": 4295664128,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295664128)
  ],
  "h": 696832
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.SevenSegments.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}SevenSegments${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(696832)
        
        

        //--TRIMMABLE-BOUNDARY-START(500224)
        $asm.$cls(`$aElv.LCFCFGI.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295467520)
            static /*void */ AddIndicatorWidget(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295467520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rfUg.LCFCFW.Startup.AddWidget($.$aElv.LCFCFGI.IndicatorWidget, $.$aElv.LCFCFGI.IndicatorWidgetRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295467520)
            
            static $h = 500224;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295467520),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddIndicatorWidget",
      "d": 500224,
      "h": 4295467520,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295467520)
  ],
  "h": 500224
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Indicator.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}Indicator${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(500224)
        
        

        //--TRIMMABLE-BOUNDARY-START(1024512)
        $asm.$cls(`$aElv.LCFCFGT.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295991808)
            static /*void */ AddTankWidget(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295991808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rfUg.LCFCFW.Startup.AddWidget($.$aElv.LCFCFGT.TankWidget, $.$aElv.LCFCFGT.TankWidgetRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295991808)
            
            static $h = 1024512;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295991808),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddTankWidget",
      "d": 1024512,
      "h": 4295991808,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295991808)
  ],
  "h": 1024512
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Tank.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}Tank${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1024512)
        
        

        //--TRIMMABLE-BOUNDARY-START(958976)
        $asm.$cls(`$aElv.LCFCFG.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295926272)
            static /*void */ AddGaugeWidgets(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295926272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$aElv.LCFCFGF.Startup.AddFuelGaugeWidget(services);
                $.$aElv.LCFCFGS$1.Startup.AddSpeedGaugeWidget(services);
                $.$aElv.LCFCFGT.Startup.AddTankWidget(services);
                $.$aElv.LCFCFGI.Startup.AddIndicatorWidget(services);
                $.$aElv.LCFCFGS.Startup.AddSevenSegmentWidget(services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295926272)
            
            static $h = 958976;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295926272),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGaugeWidgets",
      "d": 958976,
      "h": 4295926272,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295926272)
  ],
  "h": 958976
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(958976)
        
        

        //--TRIMMABLE-BOUNDARY-START(893440)
        $asm.$cls(`$aElv.LCFCFGS$1.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295860736)
            static /*void */ AddSpeedGaugeWidget(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295860736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rfUg.LCFCFW.Startup.AddWidget($.$aElv.LCFCFGS$1.SpeedGaugeWidget, $.$aElv.LCFCFGS$1.SpeedGaugeWidgetRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295860736)
            
            static $h = 893440;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295860736),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddSpeedGaugeWidget",
      "d": 893440,
      "h": 4295860736,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295860736)
  ],
  "h": 893440
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Speed.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}Speed${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(893440)
        
        

        //--TRIMMABLE-BOUNDARY-START(1221120)
        $asm.$cls(`$aElv.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296188416)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296188416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296188416)
            
            //--TRIMMABLE-BOUNDARY-START(4296188416)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296188416)
            
            static $h = 1221120;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296188416),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1221120,
      "h": 4296188416,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296188416)
  ],
  "h": 1221120
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1221120)
        
        

        //--TRIMMABLE-BOUNDARY-START(1286656)
        $asm.$cls(`$aElv.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296253952)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296253952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296253952)
            
            //--TRIMMABLE-BOUNDARY-START(4296253952)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296253952)
            
            static $h = 1286656;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296253952),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1286656,
      "h": 4296253952,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296253952)
  ],
  "h": 1286656,
  "a": [
    {
      "t": 1221120,
      "c": 4296188416
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1286656)
        
        

        //--TRIMMABLE-BOUNDARY-START(565760)
        $asm.$cls(`$aElv.LCFCFGS.SevenSegmentWidget`, ($self) => class SevenSegmentWidget extends $.$bMcF.LFCW.Widget
        {
            //--TRIMMABLE-BOUNDARY-START(25770369536)
            $ctor$3()
            {
                super.$ctor$2("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor\\SevenSegmentWidget.cs", 11);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770369536);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770369536)
            
            //--TRIMMABLE-BOUNDARY-START(30065336832)
            $ctor$4(/*string*/ component, /*int*/ line)
            {
                super.$ctor$2(component, line);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065336832);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065336832)
            
            //--TRIMMABLE-BOUNDARY-START(34360304128)
            /*int*/ Digits = 0;
            //--TRIMMABLE-BOUNDARY-END(34360304128)
            
            //--TRIMMABLE-BOUNDARY-START(137439519232)
            /*double*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(137439519232)
            
            //--TRIMMABLE-BOUNDARY-START(133144551936)
            /*string*/ StrokeColor = null;
            //--TRIMMABLE-BOUNDARY-END(133144551936)
            
            //--TRIMMABLE-BOUNDARY-START(85899911680)
            /*string*/ OnColor = null;
            //--TRIMMABLE-BOUNDARY-END(85899911680)
            
            //--TRIMMABLE-BOUNDARY-START(81604944384)
            /*string*/ OffColor = null;
            //--TRIMMABLE-BOUNDARY-END(81604944384)
            
            //--TRIMMABLE-BOUNDARY-START(25770369536)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25770369536)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34360304128)
                this.Digits = 2;
                //--TRIMMABLE-BOUNDARY-END(34360304128)
                
            }
            static $h = 565760;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$bMcF.LFCW.Widget; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360304128),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950238720,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489846272,
        "f": 83886081
      },
      "n": "Digits",
      "d": 565760,
      "h": 34360304128,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360304128),
//--TRIMMABLE-BOUNDARY-START(137439519232),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309977088,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849584640,
        "f": 83886081
      },
      "n": "Value",
      "d": 565760,
      "h": 137439519232,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439519232),
//--TRIMMABLE-BOUNDARY-START(133144551936),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720042496,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259650048,
        "f": 83886081
      },
      "n": "StrokeColor",
      "d": 565760,
      "h": 133144551936,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144551936),
//--TRIMMABLE-BOUNDARY-START(85899911680),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130107904,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669715456,
        "f": 83886081
      },
      "n": "OnColor",
      "d": 565760,
      "h": 85899911680,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899911680),
//--TRIMMABLE-BOUNDARY-START(81604944384),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540173312,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079780864,
        "f": 83886081
      },
      "n": "OffColor",
      "d": 565760,
      "h": 81604944384,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604944384)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770369536),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 565760,
      "h": 25770369536,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770369536),
//--TRIMMABLE-BOUNDARY-START(30065336832),
    {
      "p": [
        {
          "n": "component",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126025729,
              "c": 4420993025
            }
          ]
        },
        {
          "n": "line",
          "p": 655361,
          "f": 65,
          "v": 0,
          "a": [
            {
              "t": 126091265,
              "c": 4421058561
            }
          ]
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 565760,
      "h": 30065336832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065336832)
  ],
  "h": 565760
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.SevenSegments.SevenSegmentWidget`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}SevenSegments${separator}SevenSegmentWidget`; }
        });
        //--TRIMMABLE-BOUNDARY-END(565760)
        
        

        //--TRIMMABLE-BOUNDARY-START(762368)
        $asm.$cls(`$aElv.LCFCFGS$1.SpeedGaugeWidget`, ($self) => class SpeedGaugeWidget extends $.$bMcF.LFCW.Widget
        {
            //--TRIMMABLE-BOUNDARY-START(12885664256)
            $ctor$3()
            {
                super.$ctor$2("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor\\SpeedGaugeWidget.cs", 11);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885664256);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885664256)
            
            //--TRIMMABLE-BOUNDARY-START(17180631552)
            $ctor$4(/*string*/ component, /*int*/ line)
            {
                super.$ctor$2(component, line);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180631552);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180631552)
            
            //--TRIMMABLE-BOUNDARY-START(21475598848)
            /*double*/ Gauge = 0;
            //--TRIMMABLE-BOUNDARY-END(21475598848)
            
            //--TRIMMABLE-BOUNDARY-START(60130304512)
            /*string*/ Unit = null;
            //--TRIMMABLE-BOUNDARY-END(60130304512)
            
            //--TRIMMABLE-BOUNDARY-START(12885664256)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885664256)
            
            static $h = 762368;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$bMcF.LFCW.Widget; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475598848),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065533440,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245402624,
        "f": 83886081
      },
      "n": "Gauge",
      "d": 762368,
      "h": 21475598848,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475598848),
//--TRIMMABLE-BOUNDARY-START(60130304512),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655468032,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835337216,
        "f": 83886081
      },
      "n": "Unit",
      "d": 762368,
      "h": 60130304512,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130304512)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885664256),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 762368,
      "h": 12885664256,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885664256),
//--TRIMMABLE-BOUNDARY-START(17180631552),
    {
      "p": [
        {
          "n": "component",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126025729,
              "c": 4420993025
            }
          ]
        },
        {
          "n": "line",
          "p": 655361,
          "f": 65,
          "v": 0,
          "a": [
            {
              "t": 126091265,
              "c": 4421058561
            }
          ]
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 762368,
      "h": 17180631552,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180631552)
  ],
  "h": 762368
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Speed.SpeedGaugeWidget`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}Speed${separator}SpeedGaugeWidget`; }
        });
        //--TRIMMABLE-BOUNDARY-END(762368)
        
        

        //--TRIMMABLE-BOUNDARY-START(369152)
        $asm.$cls(`$aElv.LCFCFGI.IndicatorWidget`, ($self) => class IndicatorWidget extends $.$bMcF.LFCW.Widget
        {
            //--TRIMMABLE-BOUNDARY-START(8590303744)
            $ctor$3()
            {
                super.$ctor$2("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor\\IndicatorWidget.cs", 11);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590303744);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590303744)
            
            //--TRIMMABLE-BOUNDARY-START(12885271040)
            $ctor$4(/*string*/ component, /*int*/ line)
            {
                super.$ctor$2(component, line);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885271040);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885271040)
            
            //--TRIMMABLE-BOUNDARY-START(25770172928)
            /*bool*/ On = false;
            //--TRIMMABLE-BOUNDARY-END(25770172928)
            
            //--TRIMMABLE-BOUNDARY-START(8590303744)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590303744)
            
            static $h = 369152;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$bMcF.LFCW.Widget; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770172928),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475205632,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360107520,
        "f": 83886081
      },
      "n": "On",
      "d": 369152,
      "h": 25770172928,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770172928)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590303744),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 369152,
      "h": 8590303744,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590303744),
//--TRIMMABLE-BOUNDARY-START(12885271040),
    {
      "p": [
        {
          "n": "component",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126025729,
              "c": 4420993025
            }
          ]
        },
        {
          "n": "line",
          "p": 655361,
          "f": 65,
          "v": 0,
          "a": [
            {
              "t": 126091265,
              "c": 4421058561
            }
          ]
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 369152,
      "h": 12885271040,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885271040)
  ],
  "h": 369152
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Indicator.IndicatorWidget`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}Indicator${separator}IndicatorWidget`; }
        });
        //--TRIMMABLE-BOUNDARY-END(369152)
        
        

        //--TRIMMABLE-BOUNDARY-START(1090048)
        $asm.$cls(`$aElv.LCFCFGT.TankWidget`, ($self) => class TankWidget extends $.$bMcF.LFCW.Widget
        {
            //--TRIMMABLE-BOUNDARY-START(21475926528)
            $ctor$3()
            {
                super.$ctor$2("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor\\TankWidget.cs", 12);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475926528);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475926528)
            
            //--TRIMMABLE-BOUNDARY-START(25770893824)
            $ctor$4(/*string*/ component, /*int*/ line)
            {
                super.$ctor$2(component, line);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770893824);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770893824)
            
            //--TRIMMABLE-BOUNDARY-START(111670239744)
            /*TankShapeTypes*/ Shape = 0;
            //--TRIMMABLE-BOUNDARY-END(111670239744)
            
            //--TRIMMABLE-BOUNDARY-START(73015534080)
            /*bool*/ HighDetails = false;
            //--TRIMMABLE-BOUNDARY-END(73015534080)
            
            //--TRIMMABLE-BOUNDARY-START(30065861120)
            /*string*/ Color = null;
            //--TRIMMABLE-BOUNDARY-END(30065861120)
            
            //--TRIMMABLE-BOUNDARY-START(34360828416)
            /*double*/ ContentHeight = 0;
            //--TRIMMABLE-BOUNDARY-END(34360828416)
            
            //--TRIMMABLE-BOUNDARY-START(21475926528)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21475926528)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(111670239744)
                this.Shape = 3;
                //--TRIMMABLE-BOUNDARY-END(111670239744)
                
            }
            static $h = 1090048;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$bMcF.LFCW.Widget; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111670239744),
    {
      "p": 29002070,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720566784,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375272448,
        "f": 83886081
      },
      "n": "Shape",
      "d": 1090048,
      "h": 111670239744,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670239744),
//--TRIMMABLE-BOUNDARY-START(73015534080),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130632192,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785337856,
        "f": 83886081
      },
      "n": "HighDetails",
      "d": 1090048,
      "h": 73015534080,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015534080),
//--TRIMMABLE-BOUNDARY-START(30065861120),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950763008,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605468672,
        "f": 83886081
      },
      "n": "Color",
      "d": 1090048,
      "h": 30065861120,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065861120),
//--TRIMMABLE-BOUNDARY-START(34360828416),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540697600,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195403264,
        "f": 83886081
      },
      "n": "ContentHeight",
      "d": 1090048,
      "h": 34360828416,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360828416)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475926528),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1090048,
      "h": 21475926528,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475926528),
//--TRIMMABLE-BOUNDARY-START(25770893824),
    {
      "p": [
        {
          "n": "component",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126025729,
              "c": 4420993025
            }
          ]
        },
        {
          "n": "line",
          "p": 655361,
          "f": 65,
          "v": 0,
          "a": [
            {
              "t": 126091265,
              "c": 4421058561
            }
          ]
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1090048,
      "h": 25770893824,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770893824)
  ],
  "h": 1090048
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Tank.TankWidget`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}Tank${separator}TankWidget`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1090048)
        
        

        //--TRIMMABLE-BOUNDARY-START(172544)
        $asm.$cls(`$aElv.LCFCFGF.FuelGaugeWidget`, ($self) => class FuelGaugeWidget extends $.$bMcF.LFCW.Widget
        {
            //--TRIMMABLE-BOUNDARY-START(12885074432)
            $ctor$3()
            {
                super.$ctor$2("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor\\FuelGaugeWidget.cs", 11);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885074432);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885074432)
            
            //--TRIMMABLE-BOUNDARY-START(17180041728)
            $ctor$4(/*string*/ component, /*int*/ line)
            {
                super.$ctor$2(component, line);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180041728);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180041728)
            
            //--TRIMMABLE-BOUNDARY-START(21475009024)
            /*double*/ Gauge = 0;
            //--TRIMMABLE-BOUNDARY-END(21475009024)
            
            //--TRIMMABLE-BOUNDARY-START(60129714688)
            /*string*/ Unit = null;
            //--TRIMMABLE-BOUNDARY-END(60129714688)
            
            //--TRIMMABLE-BOUNDARY-START(12885074432)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885074432)
            
            static $h = 172544;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$bMcF.LFCW.Widget; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475009024),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064943616,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244812800,
        "f": 83886081
      },
      "n": "Gauge",
      "d": 172544,
      "h": 21475009024,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475009024),
//--TRIMMABLE-BOUNDARY-START(60129714688),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654878208,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834747392,
        "f": 83886081
      },
      "n": "Unit",
      "d": 172544,
      "h": 60129714688,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129714688)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885074432),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 172544,
      "h": 12885074432,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885074432),
//--TRIMMABLE-BOUNDARY-START(17180041728),
    {
      "p": [
        {
          "n": "component",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126025729,
              "c": 4420993025
            }
          ]
        },
        {
          "n": "line",
          "p": 655361,
          "f": 65,
          "v": 0,
          "a": [
            {
              "t": 126091265,
              "c": 4421058561
            }
          ]
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 172544,
      "h": 17180041728,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180041728)
  ],
  "h": 172544
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Fuel.FuelGaugeWidget`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}Fuel${separator}FuelGaugeWidget`; }
        });
        //--TRIMMABLE-BOUNDARY-END(172544)
        
        

        //--TRIMMABLE-BOUNDARY-START(107008)
        $asm.$cls(`$aElv.LCFCFG._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590041600)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590041600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590041600)
            
            //--TRIMMABLE-BOUNDARY-START(4295074304)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295074304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295074304)
            
            //--TRIMMABLE-BOUNDARY-START(4295074304)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295074304)
            
            static $h = 107008;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590041600),
    {
      "r": 65537,
      "n": "Execute",
      "d": 107008,
      "h": 8590041600,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590041600)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295074304),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 107008,
      "h": 4295074304,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295074304)
  ],
  "h": 107008
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(107008)
        
        

        //--TRIMMABLE-BOUNDARY-START(1155584)
        $asm.$cls(`$aElv.LCFCFGT.TankWidgetRenderer`, ($self) => class TankWidgetRenderer extends $.$rfUg.LCFCFW.ComponentWidgetRenderer$$($.$aElv.LCFCFGT.TankWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8591090176)
            /*RenderFragment */ RenderToFragment(/*TankWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591090176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                }, $HTPdKk ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1155584,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(8591090176)
            
            //--TRIMMABLE-BOUNDARY-START(4296122880)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296122880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296122880)
            
            //--TRIMMABLE-BOUNDARY-START(4296122880)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296122880)
            
            static $h = 1155584;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFW.ComponentWidgetRenderer$$($.$aElv.LCFCFGT.TankWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591090176),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 1090048
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 1155584,
      "h": 8591090176,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591090176)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296122880),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1155584,
      "h": 4296122880,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296122880)
  ],
  "h": 1155584
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$aElv.LCFCFGT.TankWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Tank.TankWidgetRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}Tank${separator}TankWidgetRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1155584)
        
        

        //--TRIMMABLE-BOUNDARY-START(827904)
        $asm.$cls(`$aElv.LCFCFGS$1.SpeedGaugeWidgetRenderer`, ($self) => class SpeedGaugeWidgetRenderer extends $.$rfUg.LCFCFW.ComponentWidgetRenderer$$($.$aElv.LCFCFGS$1.SpeedGaugeWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8590762496)
            /*RenderFragment */ RenderToFragment(/*SpeedGaugeWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590762496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                }, $gekslc ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":827904,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(8590762496)
            
            //--TRIMMABLE-BOUNDARY-START(4295795200)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295795200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295795200)
            
            //--TRIMMABLE-BOUNDARY-START(4295795200)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295795200)
            
            static $h = 827904;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFW.ComponentWidgetRenderer$$($.$aElv.LCFCFGS$1.SpeedGaugeWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590762496),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 762368
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 827904,
      "h": 8590762496,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590762496)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295795200),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 827904,
      "h": 4295795200,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295795200)
  ],
  "h": 827904
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$aElv.LCFCFGS$1.SpeedGaugeWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Speed.SpeedGaugeWidgetRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}Speed${separator}SpeedGaugeWidgetRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(827904)
        
        

        //--TRIMMABLE-BOUNDARY-START(434688)
        $asm.$cls(`$aElv.LCFCFGI.IndicatorWidgetRenderer`, ($self) => class IndicatorWidgetRenderer extends $.$rfUg.LCFCFW.ComponentWidgetRenderer$$($.$aElv.LCFCFGI.IndicatorWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8590369280)
            /*object */ Render$1(/*IndicatorWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590369280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.Render$1(widget, dataSource, root);
            }
            //--TRIMMABLE-BOUNDARY-END(8590369280)
            
            //--TRIMMABLE-BOUNDARY-START(12885336576)
            /*RenderFragment */ RenderToFragment(/*IndicatorWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885336576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                }, $IjINqg ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":434688,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(12885336576)
            
            //--TRIMMABLE-BOUNDARY-START(4295401984)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295401984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295401984)
            
            //--TRIMMABLE-BOUNDARY-START(4295401984)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295401984)
            
            static $h = 434688;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFW.ComponentWidgetRenderer$$($.$aElv.LCFCFGI.IndicatorWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590369280),
    {
      "r": 131073,
      "p": [
        {
          "n": "widget",
          "p": 369152
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "Render",
      "o": "@$1",
      "d": 434688,
      "h": 8590369280,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590369280),
//--TRIMMABLE-BOUNDARY-START(12885336576),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 369152
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 434688,
      "h": 12885336576,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885336576)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295401984),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 434688,
      "h": 4295401984,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295401984)
  ],
  "h": 434688
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$aElv.LCFCFGI.IndicatorWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Indicator.IndicatorWidgetRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}Indicator${separator}IndicatorWidgetRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(434688)
        
        

        //--TRIMMABLE-BOUNDARY-START(631296)
        $asm.$cls(`$aElv.LCFCFGS.SevenSegmentWidgetRenderer`, ($self) => class SevenSegmentWidgetRenderer extends $.$rfUg.LCFCFW.ComponentWidgetRenderer$$($.$aElv.LCFCFGS.SevenSegmentWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8590565888)
            /*RenderFragment */ RenderToFragment(/*SevenSegmentWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590565888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                {
                }, $uYwJRe ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":631296,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(8590565888)
            
            //--TRIMMABLE-BOUNDARY-START(4295598592)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295598592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295598592)
            
            //--TRIMMABLE-BOUNDARY-START(4295598592)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295598592)
            
            static $h = 631296;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFW.ComponentWidgetRenderer$$($.$aElv.LCFCFGS.SevenSegmentWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590565888),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 565760
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 631296,
      "h": 8590565888,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590565888)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295598592),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 631296,
      "h": 4295598592,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295598592)
  ],
  "h": 631296
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$aElv.LCFCFGS.SevenSegmentWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.SevenSegments.SevenSegmentWidgetRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}SevenSegments${separator}SevenSegmentWidgetRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(631296)
        
        

        //--TRIMMABLE-BOUNDARY-START(238080)
        $asm.$cls(`$aElv.LCFCFGF.FuelGaugeWidgetRenderer`, ($self) => class FuelGaugeWidgetRenderer extends $.$rfUg.LCFCFW.ComponentWidgetRenderer$$($.$aElv.LCFCFGF.FuelGaugeWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8590172672)
            /*RenderFragment */ RenderToFragment(/*FuelGaugeWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590172672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenComponent$1($.$hDPm.LCFCCG.FuelGauge, 1);
                    builder.AddAttribute$5(2, "Unit", widget.Unit);
                    builder.AddAttribute$4(3, "Gauge", $.$box(dataSource.LFCD$IWidgetDataSource$Get($.$$.S.Double, widget, "Gauge", widget.Gauge, false), $.$$.S.Double));
                    builder.CloseComponent();
                }, $xZIXUe ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":238080,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(8590172672)
            
            //--TRIMMABLE-BOUNDARY-START(4295205376)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295205376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295205376)
            
            //--TRIMMABLE-BOUNDARY-START(4295205376)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295205376)
            
            static $h = 238080;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFW.ComponentWidgetRenderer$$($.$aElv.LCFCFGF.FuelGaugeWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590172672),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 172544
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 238080,
      "h": 8590172672,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590172672)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295205376),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 238080,
      "h": 4295205376,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295205376)
  ],
  "h": 238080
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$aElv.LCFCFGF.FuelGaugeWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Fuel.FuelGaugeWidgetRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}FluentUI${separator}Gauges${separator}Fuel${separator}FuelGaugeWidgetRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(238080)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(41472)
