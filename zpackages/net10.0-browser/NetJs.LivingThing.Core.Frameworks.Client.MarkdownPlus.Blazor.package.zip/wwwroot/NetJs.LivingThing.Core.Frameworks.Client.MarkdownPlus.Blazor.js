
//--TRIMMABLE-BOUNDARY-START(36386)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $DJRY, $EVvT) {
    "use strict";
    let _;
    let $THmcCg;
    let $vpObah;
    let $qNPTlh;
    let $aInOdl;
    let $HcKJEg;
    let $QVPEth;
    let $mkaxCb;
    let $YJdyub;
    let $VRXnsf;
    let $aXdOrb;
    let $htDPlk;
    let $aWrtDk;
    let $zOaCTk;
    let $pcLiVa;
    let $uAKUGe;
    let $olOHfd;
    let $qJAgkj;
    let $wHzrbl;
    let $ZtcCnh;
    let $rsmFqc;
    let $RrTJsa;
    let $JMJOVe;
    let $mMOVPe;
    let $TSAHBg;
    let $lSrKRe;
    let $hmwDNg;
    let $YLuPxe;
    let $nTXJDd;
    let $kopeYa;
    let $YvXrUb;
    let $qksjKe;
    let $OjsZib;
    let $KSdxml;
    let $ERMPSd;
    let $ptfZfb;
    let $JlNXUd;
    let $PRyEkf;
    let $qHEEZb;
    let $nWZjml;
    let $bvEVmf;
    let $aKCcxd;
    let $ZCaSol;
    let $gWDsse;
    let $oGfRkc;
    let $mKilQg;
    let $jMquJi;
    let $nPwzwb;
    let $RIugHf;
    let $fMFcwb;
    let $PidLea;
    let $DbUvNc;
    let $CAmVLk;
    let $YFHAHh;
    let $ecVzJb;
    let $CevMjg;
    let $EotFvd;
    let $SFkvSb;
    let $JlTBfl;
    let $KHJnqa;
    let $lgcJni;
    let $RYkCDh;
    let $zfKNVb;
    let $AyQleb;
    let $uzPEXa;
    let $bHzhYj;
    let $Wshqek;
    let $aAgiUe;
    let $iWQaHi;
    let $lOjtlb;
    let $IzaJck;
    let $nDQhkb;
    let $eANPcg;
    let $gwplTe;
    let $PfgAeb;
    let $QgJIZk;
    let $qUEKUj;
    let $EOzABe;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", 
    {
  "h": 36386,
  "f": "LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(364066)
        $asm.$cls(`$MdeX.LCFCM.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295331362)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295331362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MdeX.LCFCMR.DroppableItemMode.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MdeX.LCFCMR.DroppableItemModeCustomAttributesProvider, $.$MdeX.LCFCMR.DroppableItemModeCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295331362)
            
            static $h = 364066;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295331362),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 364066,
      "h": 4295331362,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295331362)
  ],
  "h": 364066
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(364066)
        
        

        //--TRIMMABLE-BOUNDARY-START(298530)
        $asm.$cls(`$MdeX.LCFCM.ComponentFluentBuilderGeneratedExtension`, ($self) => class ComponentFluentBuilderGeneratedExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295265826)
            static /*MarkdownPlusFluentBuilder */ MarkdownPlusBuilder(/*this ComponentBase?*/ component, /*IServiceProvider?*/ provider, /*bool*/ stateless, /*object?*/ key)
            {
                /*var*/ let result;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295265826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                provider = provider ?? $.$firstOf((($.$as(component, $.$hDPm.LCFCG.IComponentHasServiceProvider))?.LCFCG$IComponentHasServiceProvider$ServiceProvider ?? null), () => { throw new $.$$.S.NullReferenceException().$ctor$12("provider") });
                $.$hDPm.LCFCG.ComponentFluentBuilderExtensions.GetOrCreate($.$MdeX.LCFCM.MarkdownPlusFluentBuilder, $.$MdeX.LCFCM._MarkdownPlus, component, provider, stateless, key, new ($.$$.S.Func$$$$$($.$mac.MAC.ComponentBase, $.$scm.S.IServiceProvider, $.$$.S.Boolean, $.$MdeX.LCFCM.MarkdownPlusFluentBuilder))().$ctor($.$MdeX.LCFCM.MarkdownPlusFluentBuilder, $.$hDPm.LCFCG.ComponentBaseFluentBuilder$$$($.$MdeX.LCFCM.MarkdownPlusFluentBuilder, $.$MdeX.LCFCM._MarkdownPlus).Create), $.$ref(() => result, ($v) => result = $v, $.$MdeX.LCFCM.MarkdownPlusFluentBuilder));
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(4295265826)
            
            static $h = 298530;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295265826),
    {
      "r": 560674,
      "p": [
        {
          "n": "component",
          "p": 1245299
        },
        {
          "n": "provider",
          "p": 327718,
          "f": 65
        },
        {
          "n": "stateless",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "key",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "MarkdownPlusBuilder",
      "d": 298530,
      "h": 4295265826,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295265826)
  ],
  "h": 298530
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.ComponentFluentBuilderGeneratedExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}ComponentFluentBuilderGeneratedExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(298530)
        
        

        //--TRIMMABLE-BOUNDARY-START(888354)
        $asm.$cls(`$MdeX.LCFCMR.DroppableItemModeCustomAttributesProvider`, ($self) => class DroppableItemModeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295855650)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295855650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295855650)
            
            static $h = 888354;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295855650),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 888354,
      "h": 4295855650,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295855650)
  ],
  "h": 888354
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.DroppableItemModeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}DroppableItemModeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(888354)
        
        

        //--TRIMMABLE-BOUNDARY-START(232994)
        $asm.$cls(`$MdeX.LCFCM._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295200290)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295200290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$MdeX.LCFCM.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295200290)
            
            static $h = 232994;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295200290),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 232994,
      "h": 4295200290,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295200290)
  ],
  "h": 232994
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(232994)
        
        

        //--TRIMMABLE-BOUNDARY-START(3051042)
        $asm.$cls(`$MdeX.LCFCMR.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4298018338)
            static /*void */ AddMarkdownPlusResolvers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298018338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MdeX.LCFCMR.Startup.RegisterGenerated(services);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusTextBoxEntryTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusPanelTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusGridTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusOptionSelectTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusOptionsSelectTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusOptionCheckboxTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusObjectTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusSpaceTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusTableTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusShapeSVGTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusShapeCircleTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusShapeRectangleTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusShapeEllipseTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusShapeLineTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusShapeTextTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusShapeLineGraphTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusHighlightTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusBoldTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusClickTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusMathTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusIconTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusDraggableTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusDroppableTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusPlayTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusTextToSpeechResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusButtonStyleTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusBackgroundImageTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusBackgroundSoundTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$MdeX.LCFCMR.MarkdownPlusFontTokenResolver, services, null);
            }
            //--TRIMMABLE-BOUNDARY-END(4298018338)
            
            //--TRIMMABLE-BOUNDARY-START(8592985634)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592985634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8592985634)
            
            static $h = 3051042;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298018338),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddMarkdownPlusResolvers",
      "d": 3051042,
      "h": 4298018338,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4298018338),
//--TRIMMABLE-BOUNDARY-START(8592985634),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "RegisterGenerated",
      "d": 3051042,
      "h": 8592985634,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8592985634)
  ],
  "h": 3051042
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3051042)
        
        

        //--TRIMMABLE-BOUNDARY-START(3116578)
        $asm.$cls(`$MdeX.LCFCMR.Utility`, ($self) => class Utility
        {
            //--TRIMMABLE-BOUNDARY-START(17182985762)
            static /*RenderFragment */ Space()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182985762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenElement(4, "div");
                    builder.AddAttribute$5(5, "class", "mg");
                    builder.CloseElement();
                }, $RrTJsa ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":3116578,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(17182985762)
            
            //--TRIMMABLE-BOUNDARY-START(4298083874)
            static /*void */ AddParameter(/*this RenderTreeBuilder*/ builder, /*object?*/ parameter, /*object?*/ separator)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298083874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let resolved;
                while($.$is(parameter, $.$EVvT.LCFCM.MarkdownPlusToken, { set $v($v){ resolved = $v; } }))
                {
                    parameter = resolved.Value;
                }
                let view;
                let tview;
                let en;
                if ($.$is(parameter, $.$mac.MAC.RenderFragment, { set $v($v){ view = $v; } }))
                {
                    builder.AddContent$1(3000, view);
                }
                else if ($.$is(parameter, $.$mac.MAC.RenderFragment$$($.$$.S.Object), { set $v($v){ tview = $v; } }))
                {
                    builder.AddContent$1(3000, tview.Invoke(null));
                }
                else if ($.$is(parameter, $.$$.SC$1.IEnumerable, { set $v($v){ en = $v; } }) && !(parameter !== null && ($.$is(parameter, $.$$.S.String))))
                {
                    /*int*/ let i = 0;
                    let $en1 = en.SC$1$IEnumerable$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let obj = $en1.SC$1$IEnumerator$Current;
                        {
                            if (i !== 0 && separator !== null)
                            {
                                $.$MdeX.LCFCMR.Utility.AddParameter(builder, separator, null);
                            }
                            $.$MdeX.LCFCMR.Utility.AddParameter(builder, obj, null);
                            i++;
                        }
                    }
                }
                else 
                {
                    builder.AddContent$3(3000, parameter);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298083874)
            
            //--TRIMMABLE-BOUNDARY-START(8593051170)
            static /*void */ AddParameters(/*this RenderTreeBuilder*/ builder, /*IEnumerable<KeyValuePair<string, MarkdownPlusToken>>*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593051170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en2 = parameters.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let parameter = $en2.SCG$IEnumerator$$$Current;
                    {
                        $.$MdeX.LCFCMR.Utility.AddParameter(builder, parameter.Value.Value, null);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8593051170)
            
            //--TRIMMABLE-BOUNDARY-START(12888018466)
            static /*ISVGBuilder */ GetSVG(/*this MarkdownPlusTokenResolverBase*/ _this, /*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ context, /*out MarkdownPlusShapeSVGTokenResolver?*/ parent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888018466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                parent.$v = _this.GetParent($.$MdeX.LCFCMR.MarkdownPlusShapeSVGTokenResolver);
                if ((parent.$v?.SVG ?? null) !== null)
                {
                    return parent.$v.SVG;
                }
                /*var*/ let width = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "w", "width" ], null, null));
                /*var*/ let height = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "h", "height" ], null, null));
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), context, null);
                /*double*/ let w = 1;
                /*double*/ let h = 1;
                if (!$.$$.S.Double.TryParse$6(width, $.$ref(() => w, ($v) => w = $v, $.$$.S.Double)))
                {
                    w = 1;
                }
                if (!$.$$.S.Double.TryParse$6(height, $.$ref(() => h, ($v) => h = $v, $.$$.S.Double)))
                {
                    h = 1;
                }
                /*var*/ let builder = $.$hDPm.LCFCCSF.SVGBuilder.Create(w, h, 3/*DimensionUnit.Proportional*/, true, 0, 0).LCFCCSF$ISVGBuilder$Attribute("style", style);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(12888018466)
            
            static $h = 3116578;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182985762),
    {
      "r": 6881395,
      "n": "Space",
      "d": 3116578,
      "h": 17182985762,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182985762),
//--TRIMMABLE-BOUNDARY-START(4298083874),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536755
        },
        {
          "n": "parameter",
          "p": 131073
        },
        {
          "n": "separator",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "AddParameter",
      "d": 3116578,
      "h": 4298083874,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298083874),
//--TRIMMABLE-BOUNDARY-START(8593051170),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536755
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken)).$h
        }
      ],
      "n": "AddParameters",
      "d": 3116578,
      "h": 8593051170,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593051170),
//--TRIMMABLE-BOUNDARY-START(12888018466),
    {
      "r": 46945962,
      "p": [
        {
          "n": "_this",
          "p": 1607932
        },
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        },
        {
          "n": "parent",
          "p": 2461218,
          "f": 2
        }
      ],
      "n": "GetSVG",
      "d": 3116578,
      "h": 12888018466,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12888018466)
  ],
  "h": 3116578
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.Utility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}Utility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3116578)
        
        

        //--TRIMMABLE-BOUNDARY-START(101922)
        $asm.$cls(`$MdeX.LCFCM._Imports`, ($self) => class _Imports extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590036514)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590036514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590036514)
            
            //--TRIMMABLE-BOUNDARY-START(4295069218)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295069218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295069218)
            
            //--TRIMMABLE-BOUNDARY-START(4295069218)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295069218)
            
            static $h = 101922;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590036514),
    {
      "r": 65537,
      "n": "Execute",
      "d": 101922,
      "h": 8590036514,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590036514)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295069218),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 101922,
      "h": 4295069218,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295069218)
  ],
  "h": 101922
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(101922)
        
        

        //--TRIMMABLE-BOUNDARY-START(691746)
        $asm.$cls(`$MdeX.LCFCM.MarkdownPlusUtility`, ($self) => class MarkdownPlusUtility
        {
            //--TRIMMABLE-BOUNDARY-START(4295659042)
            static /*RenderFragment */ Button(/*this MarkdownPlusTokenResolverClosure*/ closure, /*string*/ icon, /*Func<Task>*/ onclick, /*int*/ buttonWidth, /*int*/ buttonHeight, /*string?*/ fontSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295659042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    fontSize ??= closure.Context.ButtonControlFontSize;
                    builder.OpenElement(1, "button");
                    builder.AddAttribute$5(2, "type", "button");
                    builder.AddAttribute$5(3, "class", `${$.$strNN((fontSize === null ? "fsz-35 " : ""))}wx-${$.$strNN((buttonWidth < 0 ? "05" : $.$hDPm.LCFC.UtilityExtensions.Class(buttonWidth, true)))} hx-${$.$strNN((buttonHeight < 0 ? "05" : $.$hDPm.LCFC.UtilityExtensions.Class(buttonHeight, true)))} round${$.$strNN((closure.Context.ButtonControlBackgroundColor === null ? " bg-success" : ""))} ${$.$strNN(icon)}`);
                    builder.AddAttribute$5(4, "style", $.$strNN($.$strNN((fontSize !== null ? `font-size:${$.$strNN(fontSize)};` : "")) + $.$strNN((closure.Context.ButtonControlBackgroundColor !== null ? `background-color:${$.$strNN(closure.Context.ButtonControlBackgroundColor)};` : ""))) + $.$strNN((closure.Context.ButtonControlColor !== null ? `color:${$.$strNN(closure.Context.ButtonControlColor)};` : "")));
                    builder.AddAttribute$1(5, "onclick", $.$mac.MAC.EventCallback.Factory.Create$4(closure, onclick));
                    builder.CloseElement();
                }, $JMJOVe ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":691746,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(4295659042)
            
            static $h = 691746;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295659042),
    {
      "r": 6881395,
      "p": [
        {
          "n": "closure",
          "p": 1673468
        },
        {
          "n": "icon",
          "p": 1310721
        },
        {
          "n": "onclick",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h
        },
        {
          "n": "buttonWidth",
          "p": 655361,
          "f": 65,
          "v": -1
        },
        {
          "n": "buttonHeight",
          "p": 655361,
          "f": 65,
          "v": -1
        },
        {
          "n": "fontSize",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "Button",
      "d": 691746,
      "h": 4295659042,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295659042)
  ],
  "h": 691746
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.MarkdownPlusUtility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}MarkdownPlusUtility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(691746)
        
        

        //--TRIMMABLE-BOUNDARY-START(3182114)
        $asm.$cls(`$MdeX.LCFCM.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593116706)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593116706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MdeX.LCFCM.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$MdeX.LCFCMR.Startup.AddMarkdownPlusResolvers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593116706)
            
            //--TRIMMABLE-BOUNDARY-START(12888084002)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888084002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12888084002)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$MdeX.LCFCM.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298149410)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298149410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298149410)
            
            //--TRIMMABLE-BOUNDARY-START(4298149410)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298149410)
            
            static $h = 3182114;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593116706),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3182114,
      "h": 8593116706,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8593116706),
//--TRIMMABLE-BOUNDARY-START(12888084002),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 3182114,
      "h": 12888084002,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12888084002)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298149410),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3182114,
      "h": 4298149410,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298149410)
  ],
  "h": 3182114
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3182114)
        
        

        //--TRIMMABLE-BOUNDARY-START(757282)
        $asm.$cls(`$MdeX.LCFCM.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180626466)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MdeX.LCFCM.MarkdownPlus.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MdeX.LCFCM.MarkdownPlus().$ctor$7();
                    }, $uAKUGe ??= {"r":2752627,"n":"","d":757282,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180626466)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295724578)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295724578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295724578)
            
            //--TRIMMABLE-BOUNDARY-START(4295724578)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295724578)
            
            static $h = 757282;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180626466),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885659170,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 757282,
      "h": 17180626466,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180626466)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295724578),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 757282,
      "h": 4295724578,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295724578)
  ],
  "h": 757282
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(757282)
        
        

        //--TRIMMABLE-BOUNDARY-START(3247650)
        $asm.$cls(`$MdeX.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298214946)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298214946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298214946)
            
            //--TRIMMABLE-BOUNDARY-START(4298214946)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298214946)
            
            static $h = 3247650;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298214946),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3247650,
      "h": 4298214946,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298214946)
  ],
  "h": 3247650
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3247650)
        
        

        //--TRIMMABLE-BOUNDARY-START(3313186)
        $asm.$cls(`$MdeX.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298280482)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298280482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298280482)
            
            //--TRIMMABLE-BOUNDARY-START(4298280482)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298280482)
            
            static $h = 3313186;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298280482),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3313186,
      "h": 4298280482,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298280482)
  ],
  "h": 3313186,
  "a": [
    {
      "t": 3247650,
      "c": 4298214946
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3313186)
        
        

        //--TRIMMABLE-BOUNDARY-START(1805858)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusOptionCheckboxTokenResolver`, ($self) => class MarkdownPlusOptionCheckboxTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34361544226)
            /*string */ get Invocation()
            {
                return "checkbox";
            }
            //--TRIMMABLE-BOUNDARY-END(34361544226)
            
            //--TRIMMABLE-BOUNDARY-START(8591740450)
            /*string */ get Description()
            {
                return "Shows a checkbox the user can select.\r\n\r\nExample: ``checkbox(1, Option 1)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8591740450)
            
            //--TRIMMABLE-BOUNDARY-START(30066576930)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["0", "id"], null, null), "The unique id of the checkbox");
                        $i1.Required = true;
                        return $i1;
                    })();
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t2 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i2 = new $t2();
                        $i2.$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["1", "text"], null, null), "The text to show in the checkbox");
                        $i2.Required = true;
                        return $i2;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30066576930)
            
            //--TRIMMABLE-BOUNDARY-START(38656511522)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656511522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$MdeX.LCFCMR.MarkdownPlusViews.SelectCheckbox$1($.$clone(method), parameters, closure.RootClosure, null, false));
            }
            //--TRIMMABLE-BOUNDARY-END(38656511522)
            
            //--TRIMMABLE-BOUNDARY-START(4296773154)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296773154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296773154)
            
            //--TRIMMABLE-BOUNDARY-START(4296773154)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296773154)
            
            static $h = 1805858;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361544226),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771609634,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1805858,
      "h": 34361544226,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361544226),
//--TRIMMABLE-BOUNDARY-START(8591740450),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181675042,
        "f": 50364417
      },
      "n": "Description",
      "d": 1805858,
      "h": 8591740450,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591740450)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066576930),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1805858,
      "h": 30066576930,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066576930),
//--TRIMMABLE-BOUNDARY-START(38656511522),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1805858,
      "h": 38656511522,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656511522)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296773154),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1805858,
      "h": 4296773154,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296773154)
  ],
  "h": 1805858
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusOptionCheckboxTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusOptionCheckboxTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1805858)
        
        

        //--TRIMMABLE-BOUNDARY-START(2723362)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusSpaceTokenResolver`, ($self) => class MarkdownPlusSpaceTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362461730)
            /*string */ get Invocation()
            {
                return "space";
            }
            //--TRIMMABLE-BOUNDARY-END(34362461730)
            
            //--TRIMMABLE-BOUNDARY-START(8592657954)
            /*string */ get Description()
            {
                return "Create an empty lin space.\r\n\r\nExample: ``space``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592657954)
            
            //--TRIMMABLE-BOUNDARY-START(30067494434)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    return;
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067494434)
            
            //--TRIMMABLE-BOUNDARY-START(38657429026)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657429026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenElement(1, "div");
                    builder.AddAttribute$5(3, "class", "mg hx-005");
                    builder.AddAttribute$5(4, "style", style);
                    builder.CloseElement();
                }, $aInOdl ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":2723362,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(38657429026)
            
            //--TRIMMABLE-BOUNDARY-START(4297690658)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297690658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297690658)
            
            //--TRIMMABLE-BOUNDARY-START(4297690658)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297690658)
            
            static $h = 2723362;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362461730),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772527138,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2723362,
      "h": 34362461730,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362461730),
//--TRIMMABLE-BOUNDARY-START(8592657954),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182592546,
        "f": 50364417
      },
      "n": "Description",
      "d": 2723362,
      "h": 8592657954,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592657954)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067494434),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2723362,
      "h": 30067494434,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067494434),
//--TRIMMABLE-BOUNDARY-START(38657429026),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2723362,
      "h": 38657429026,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657429026)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297690658),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2723362,
      "h": 4297690658,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297690658)
  ],
  "h": 2723362
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusSpaceTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusSpaceTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2723362)
        
        

        //--TRIMMABLE-BOUNDARY-START(1674786)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusMathTokenResolver`, ($self) => class MarkdownPlusMathTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34361413154)
            /*string */ get Invocation()
            {
                return "math";
            }
            //--TRIMMABLE-BOUNDARY-END(34361413154)
            
            //--TRIMMABLE-BOUNDARY-START(8591609378)
            /*string */ get Description()
            {
                return "Insert a mathematical expression in LaTEX.\r\n\r\nExample: ``math(1/2)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8591609378)
            
            //--TRIMMABLE-BOUNDARY-START(30066445858)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("-1", "The latex expression");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30066445858)
            
            //--TRIMMABLE-BOUNDARY-START(38656380450)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656380450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.AddContent$4(1, "\\(");
                    let $en2 = parameters.GetEnumerator();
                    while ($en2.MoveNext())
                    {
                        let p = $en2.Current;
                        {
                            builder.AddContent$4(2, $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$3(p.Value));
                        }
                    }
                    builder.AddContent$4(3, "\\)");
                }, $THmcCg ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1674786,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(38656380450)
            
            //--TRIMMABLE-BOUNDARY-START(4296642082)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296642082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296642082)
            
            //--TRIMMABLE-BOUNDARY-START(4296642082)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296642082)
            
            static $h = 1674786;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361413154),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771478562,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1674786,
      "h": 34361413154,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361413154),
//--TRIMMABLE-BOUNDARY-START(8591609378),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181543970,
        "f": 50364417
      },
      "n": "Description",
      "d": 1674786,
      "h": 8591609378,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591609378)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066445858),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1674786,
      "h": 30066445858,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066445858),
//--TRIMMABLE-BOUNDARY-START(38656380450),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1674786,
      "h": 38656380450,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656380450)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296642082),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1674786,
      "h": 4296642082,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296642082)
  ],
  "h": 1674786
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusMathTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusMathTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1674786)
        
        

        //--TRIMMABLE-BOUNDARY-START(1150498)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusButtonStyleTokenResolver`, ($self) => class MarkdownPlusButtonStyleTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34360888866)
            /*string */ get Invocation()
            {
                return "buttonstyle";
            }
            //--TRIMMABLE-BOUNDARY-END(34360888866)
            
            //--TRIMMABLE-BOUNDARY-START(8591085090)
            /*string */ get Description()
            {
                return "Style control buttons\r\n\r\nExample: ``buttonstyle(color:red,bgcolor:white)``\r\n";
            }
            //--TRIMMABLE-BOUNDARY-END(8591085090)
            
            //--TRIMMABLE-BOUNDARY-START(30065921570)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("color", "Button text/icon color");
                        $i1.Required = true;
                        return $i1;
                    })();
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t2 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i2 = new $t2();
                        $i2.$ctor$3("bgcolor", "Button background color");
                        $i2.Required = true;
                        return $i2;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30065921570)
            
            //--TRIMMABLE-BOUNDARY-START(38655856162)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655856162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let fontSize = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "fontSize" ], null, null));
                /*var*/ let color = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "cl", "color" ], null, null));
                /*var*/ let bgcolor = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bgc", "bgcolor" ], null, null));
                closure.Context.ButtonControlFontSize = fontSize;
                closure.Context.ButtonControlColor = color;
                closure.Context.ButtonControlBackgroundColor = bgcolor;
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38655856162)
            
            //--TRIMMABLE-BOUNDARY-START(4296117794)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296117794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296117794)
            
            //--TRIMMABLE-BOUNDARY-START(4296117794)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296117794)
            
            static $h = 1150498;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360888866),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770954274,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1150498,
      "h": 34360888866,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360888866),
//--TRIMMABLE-BOUNDARY-START(8591085090),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181019682,
        "f": 50364417
      },
      "n": "Description",
      "d": 1150498,
      "h": 8591085090,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591085090)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065921570),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1150498,
      "h": 30065921570,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065921570),
//--TRIMMABLE-BOUNDARY-START(38655856162),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1150498,
      "h": 38655856162,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655856162)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296117794),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1150498,
      "h": 4296117794,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296117794)
  ],
  "h": 1150498
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusButtonStyleTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusButtonStyleTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1150498)
        
        

        //--TRIMMABLE-BOUNDARY-START(1609250)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusIconTokenResolver`, ($self) => class MarkdownPlusIconTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34361347618)
            /*string */ get Invocation()
            {
                return "icon";
            }
            //--TRIMMABLE-BOUNDARY-END(34361347618)
            
            //--TRIMMABLE-BOUNDARY-START(8591543842)
            /*string */ get Description()
            {
                return "Display an icon by its name.\r\n\r\nExample: ``icon(Cog)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8591543842)
            
            //--TRIMMABLE-BOUNDARY-START(30066380322)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("-1", "The name of the icon");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30066380322)
            
            //--TRIMMABLE-BOUNDARY-START(38656314914)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656314914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let icon = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "name" ], null, null));
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), context, null);
                /*string?*/ let _iconName = null;
                if (icon !== null && _iconName === null)
                {
                    _iconName = "mdi mdi-" + $.$strNN($.$$.S.String.ToLower.call($.$fPer.LCFCS$6.StringExtension.CamelCaseToHyphen(icon)));
                }
                if (icon !== null && _iconName !== null)
                {
                    /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                    {
                        builder.OpenElement(1, "i");
                        builder.AddAttribute$5(2, "class", _iconName);
                        builder.AddAttribute$5(3, "style", style);
                        $.$MdeX.LCFCMR.Utility.AddParameters(builder, parameters);
                        builder.CloseElement();
                    }, $HcKJEg ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1609250,"h":0,"f":17825794});
                    return (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusToken()
                        const $t2 = $.$EVvT.LCFCM.MarkdownPlusToken;
                        const $i2 = new $t2();
                        $i2.$ctor$3(view);
                        $i2.Name = icon;
                        return $i2;
                    })();
                }
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6(icon);
            }
            //--TRIMMABLE-BOUNDARY-END(38656314914)
            
            //--TRIMMABLE-BOUNDARY-START(4296576546)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296576546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296576546)
            
            //--TRIMMABLE-BOUNDARY-START(4296576546)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296576546)
            
            static $h = 1609250;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361347618),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771413026,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1609250,
      "h": 34361347618,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361347618),
//--TRIMMABLE-BOUNDARY-START(8591543842),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181478434,
        "f": 50364417
      },
      "n": "Description",
      "d": 1609250,
      "h": 8591543842,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591543842)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066380322),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1609250,
      "h": 30066380322,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066380322),
//--TRIMMABLE-BOUNDARY-START(38656314914),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1609250,
      "h": 38656314914,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656314914)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296576546),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1609250,
      "h": 4296576546,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296576546)
  ],
  "h": 1609250
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusIconTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusIconTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1609250)
        
        

        //--TRIMMABLE-BOUNDARY-START(1478178)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusGridTokenResolver`, ($self) => class MarkdownPlusGridTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34361216546)
            /*string */ get Invocation()
            {
                return "grid";
            }
            //--TRIMMABLE-BOUNDARY-END(34361216546)
            
            //--TRIMMABLE-BOUNDARY-START(8591412770)
            /*string */ get Description()
            {
                return "Arrange items in a grid cell.\r\n\r\nExample: ``grid(1,2,3,4,5,6,,7,8,9,c:2,g:1)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8591412770)
            
            //--TRIMMABLE-BOUNDARY-START(30066249250)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("-1", "Items to arrange");
                        $i1.Required = true;
                        return $i1;
                    })();
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["c", "cell"], null, null), "Gap to put between elements in the grid");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["g", "gap"], null, null), "The minimum size of each cell");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30066249250)
            
            //--TRIMMABLE-BOUNDARY-START(38656183842)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656183842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*var*/ let gap = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "g", "gap" ], null, null));
                /*var*/ let cell = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "c", "cell" ], null, null)) ?? "1";
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenElement(1, "div");
                    builder.AddAttribute$5(2, "class", `grid ${$.$strNN((gap !== null ? `gap-${$.$strNN(gap)}` : ""))} colm-${$.$strNN(cell)}`);
                    builder.AddAttribute$5(3, "style", style);
                    let $en2 = parameters.GetEnumerator();
                    while ($en2.MoveNext())
                    {
                        let parameter = $en2.Current;
                        {
                            $.$MdeX.LCFCMR.Utility.AddParameter(builder, parameter.Value, null);
                        }
                    }
                    builder.CloseElement();
                }, $qNPTlh ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1478178,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(38656183842)
            
            //--TRIMMABLE-BOUNDARY-START(4296445474)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296445474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296445474)
            
            //--TRIMMABLE-BOUNDARY-START(4296445474)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296445474)
            
            static $h = 1478178;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361216546),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771281954,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1478178,
      "h": 34361216546,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361216546),
//--TRIMMABLE-BOUNDARY-START(8591412770),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181347362,
        "f": 50364417
      },
      "n": "Description",
      "d": 1478178,
      "h": 8591412770,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591412770)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066249250),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1478178,
      "h": 30066249250,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066249250),
//--TRIMMABLE-BOUNDARY-START(38656183842),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1478178,
      "h": 38656183842,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656183842)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296445474),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1478178,
      "h": 4296445474,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296445474)
  ],
  "h": 1478178
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusGridTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusGridTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1478178)
        
        

        //--TRIMMABLE-BOUNDARY-START(1871394)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusOptionSelectTokenResolver`, ($self) => class MarkdownPlusOptionSelectTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34361609762)
            /*string */ get Invocation()
            {
                return "option";
            }
            //--TRIMMABLE-BOUNDARY-END(34361609762)
            
            //--TRIMMABLE-BOUNDARY-START(8591805986)
            /*string */ get Description()
            {
                return "Shows one option the user can select.\r\n\r\nExample: ``option(1, Option 1)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8591805986)
            
            //--TRIMMABLE-BOUNDARY-START(30066642466)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["0", "id"], null, null), "The unique id of the option");
                        $i1.Required = true;
                        return $i1;
                    })();
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t2 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i2 = new $t2();
                        $i2.$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["1", "text"], null, null), "The text to show in the option");
                        $i2.Required = true;
                        return $i2;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30066642466)
            
            //--TRIMMABLE-BOUNDARY-START(38656577058)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656577058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$MdeX.LCFCMR.MarkdownPlusViews.SelectButton$1($.$clone(method), parameters, closure.RootClosure, null));
            }
            //--TRIMMABLE-BOUNDARY-END(38656577058)
            
            //--TRIMMABLE-BOUNDARY-START(4296838690)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296838690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296838690)
            
            //--TRIMMABLE-BOUNDARY-START(4296838690)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296838690)
            
            static $h = 1871394;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361609762),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771675170,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1871394,
      "h": 34361609762,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361609762),
//--TRIMMABLE-BOUNDARY-START(8591805986),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181740578,
        "f": 50364417
      },
      "n": "Description",
      "d": 1871394,
      "h": 8591805986,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591805986)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066642466),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1871394,
      "h": 30066642466,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066642466),
//--TRIMMABLE-BOUNDARY-START(38656577058),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1871394,
      "h": 38656577058,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656577058)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296838690),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1871394,
      "h": 4296838690,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296838690)
  ],
  "h": 1871394
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusOptionSelectTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusOptionSelectTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1871394)
        
        

        //--TRIMMABLE-BOUNDARY-START(1084962)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusBoldTokenResolver`, ($self) => class MarkdownPlusBoldTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34360823330)
            /*string */ get Invocation()
            {
                return "bold";
            }
            //--TRIMMABLE-BOUNDARY-END(34360823330)
            
            //--TRIMMABLE-BOUNDARY-START(8591019554)
            /*string */ get Description()
            {
                return "Bolden a text differently from the rest.\r\n\r\nExample: ``Hello bold(World)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8591019554)
            
            //--TRIMMABLE-BOUNDARY-START(30065856034)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("-1", "The texts to bolden");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30065856034)
            
            //--TRIMMABLE-BOUNDARY-START(38655790626)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655790626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), context, null);
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenElement(1, "b");
                    builder.AddAttribute$5(4, "style", style);
                    $.$MdeX.LCFCMR.Utility.AddParameters(builder, parameters);
                    builder.CloseElement();
                }, $vpObah ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1084962,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(38655790626)
            
            //--TRIMMABLE-BOUNDARY-START(4296052258)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296052258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296052258)
            
            //--TRIMMABLE-BOUNDARY-START(4296052258)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296052258)
            
            static $h = 1084962;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360823330),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770888738,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1084962,
      "h": 34360823330,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360823330),
//--TRIMMABLE-BOUNDARY-START(8591019554),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180954146,
        "f": 50364417
      },
      "n": "Description",
      "d": 1084962,
      "h": 8591019554,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591019554)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065856034),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1084962,
      "h": 30065856034,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065856034),
//--TRIMMABLE-BOUNDARY-START(38655790626),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1084962,
      "h": 38655790626,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655790626)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296052258),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1084962,
      "h": 4296052258,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296052258)
  ],
  "h": 1084962
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusBoldTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusBoldTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1084962)
        
        

        //--TRIMMABLE-BOUNDARY-START(2461218)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusShapeSVGTokenResolver`, ($self) => class MarkdownPlusShapeSVGTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(47247101474)
            /*string */ get Invocation()
            {
                return "svg";
            }
            //--TRIMMABLE-BOUNDARY-END(47247101474)
            
            //--TRIMMABLE-BOUNDARY-START(12887363106)
            /*string */ get Description()
            {
                return "Create an svg on which graphics can be drawn.\r\n\r\nExample: ``svg``";
            }
            //--TRIMMABLE-BOUNDARY-END(12887363106)
            
            //--TRIMMABLE-BOUNDARY-START(42952134178)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["0", "w"], null, null), "The viewBox width of the svg. Default to 1.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["1", "h"], null, null), "The viewBox height of the svg. Default to 1.");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(42952134178)
            
            //--TRIMMABLE-BOUNDARY-START(64426970658)
            /*ISVGBuilder?*/ SVG = null;
            //--TRIMMABLE-BOUNDARY-END(64426970658)
            
            //--TRIMMABLE-BOUNDARY-START(51542068770)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542068770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let width = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "w", "width" ], null, null));
                /*var*/ let height = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "h", "height" ], null, null));
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), context, null);
                /*double*/ let w = 1;
                /*double*/ let h = 1;
                if (!$.$$.S.Double.TryParse$6(width, $.$ref(() => w, ($v) => w = $v, $.$$.S.Double)))
                {
                    w = 1;
                }
                if (!$.$$.S.Double.TryParse$6(height, $.$ref(() => h, ($v) => h = $v, $.$$.S.Double)))
                {
                    h = 1;
                }
                this.SVG = $.$hDPm.LCFCCSF.SVGBuilder.Create(w, h, 3/*DimensionUnit.Proportional*/, true, 0, 0).LCFCCSF$ISVGBuilder$Attribute("style", style);
                let $en3 = parameters.GetEnumerator();
                while ($en3.MoveNext())
                {
                    let parameter = $en3.Current;
                    {
                        let def;
                        if ($.$is(parameter.Value.Value, $.$EVvT.LCFCM.MarkdownPlusDeferedParameterResolver, { set $v($v){ def = $v; } }))
                        {
                            def.GetValue(context);
                        }
                    }
                }
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(this.SVG.LCFCCSF$ISVGBuilder$Build());
            }
            //--TRIMMABLE-BOUNDARY-END(51542068770)
            
            //--TRIMMABLE-BOUNDARY-START(8592395810)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592395810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592395810)
            
            //--TRIMMABLE-BOUNDARY-START(8592395810)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592395810)
            
            static $h = 2461218;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47247101474),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067232290,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2461218,
      "h": 47247101474,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47247101474),
//--TRIMMABLE-BOUNDARY-START(12887363106),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477297698,
        "f": 50364417
      },
      "n": "Description",
      "d": 2461218,
      "h": 12887363106,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12887363106),
//--TRIMMABLE-BOUNDARY-START(64426970658),
    {
      "p": 46945962,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657166882,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132003362,
        "f": 83886082
      },
      "n": "SVG",
      "d": 2461218,
      "h": 64426970658,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426970658)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42952134178),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2461218,
      "h": 42952134178,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42952134178),
//--TRIMMABLE-BOUNDARY-START(51542068770),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2461218,
      "h": 51542068770,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51542068770)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592395810),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2461218,
      "h": 8592395810,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592395810)
  ],
  "h": 2461218
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusShapeSVGTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusShapeSVGTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2461218)
        
        

        //--TRIMMABLE-BOUNDARY-START(2068002)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusPlayTokenResolver`, ($self) => class MarkdownPlusPlayTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(47246708258)
            /*IResourcePathResolver*/ resourceResolver = null;
            //--TRIMMABLE-BOUNDARY-END(47246708258)
            
            //--TRIMMABLE-BOUNDARY-START(38656773666)
            /*IMediaPlayer*/ player = null;
            //--TRIMMABLE-BOUNDARY-END(38656773666)
            
            //--TRIMMABLE-BOUNDARY-START(34361806370)
            /*string */ get Invocation()
            {
                return "play";
            }
            //--TRIMMABLE-BOUNDARY-END(34361806370)
            
            //--TRIMMABLE-BOUNDARY-START(8592002594)
            /*string */ get Description()
            {
                return "Play a sound when a button is clicked.\r\n\r\nExample: ``play(1)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592002594)
            
            //--TRIMMABLE-BOUNDARY-START(30066839074)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The file to play when clicked. eg ``play(1)`` to play a sound saying one");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30066839074)
            
            //--TRIMMABLE-BOUNDARY-START(4297035298)
            $ctor$2(/*IResourcePathResolver*/ resourceResolver, /*IMediaPlayer*/ player)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297035298);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.resourceResolver = resourceResolver;
                    this.player = player;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297035298)
            
            //--TRIMMABLE-BOUNDARY-START(42951740962)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951740962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let file = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                {
                    builder.OpenElement(1, "button");
                    builder.AddAttribute$5(2, "class", "pos-rel mdi mdi-play hx-1 wx-1 fsz-80 round bg-success");
                    builder.AddAttribute$5(3, "style", style);
                    builder.AddAttribute$1(4, "onclick", $.$mac.MAC.EventCallback.Factory.Create$1(this, new $.$$.S.Action().$ctor(this,  () =>
                    {
                        /*var*/ let ext = ".mp3";
                        this.player.LCFCS$3$IMediaPlayer$Play$1((() =>
                        {
                            //new $.$fPer.LCFCD.MediaModel()
                            const $t2 = $.$fPer.LCFCD.MediaModel;
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.MediaUrls = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [this.resourceResolver.LCFCC$IResourcePathResolver$Resolve("LivingThing.Core.Community.School.Resources", `skillassets/sound/${$.$strNN(($.$$.S.Int32.TryParse$6(file, $.$discardRef()) ? "number" : ""))}/${$.$strNN(file)}${$.$strNN(ext)}`, false)], [-1], null);
                            return $i2;
                        })(), false, null);
                    }, $YJdyub ??= {"r":65537,"n":"","d":2068002,"h":0,"f":17825794})));
                    builder.AddContent$1(5, new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                    {
                        builder.OpenElement(1, "i");
                        builder.AddAttribute$5(2, "class", "mdi mdi-hand-pointing-up pos-abs r-0 b-0 cl-warning fsz-40 mgr-10");
                        builder.CloseElement();
                    }, $VRXnsf ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":2068002,"h":0,"f":17825794}));
                    builder.CloseElement();
                }, $aXdOrb ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":2068002,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(42951740962)
            
            static $h = 2068002;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361806370),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771871778,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2068002,
      "h": 34361806370,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361806370),
//--TRIMMABLE-BOUNDARY-START(8592002594),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181937186,
        "f": 50364417
      },
      "n": "Description",
      "d": 2068002,
      "h": 8592002594,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592002594)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066839074),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2068002,
      "h": 30066839074,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066839074),
//--TRIMMABLE-BOUNDARY-START(42951740962),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2068002,
      "h": 42951740962,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951740962)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47246708258),
    {
      "t": 3825064,
      "n": "resourceResolver",
      "d": 2068002,
      "h": 47246708258,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47246708258),
//--TRIMMABLE-BOUNDARY-START(38656773666),
    {
      "t": 61704534,
      "n": "player",
      "d": 2068002,
      "h": 38656773666,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656773666)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297035298),
    {
      "p": [
        {
          "n": "resourceResolver",
          "p": 3825064
        },
        {
          "n": "player",
          "p": 61704534
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2068002,
      "h": 4297035298,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297035298)
  ],
  "h": 2068002
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusPlayTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusPlayTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2068002)
        
        

        //--TRIMMABLE-BOUNDARY-START(1412642)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusFontTokenResolver`, ($self) => class MarkdownPlusFontTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34361151010)
            /*string */ get Invocation()
            {
                return "font";
            }
            //--TRIMMABLE-BOUNDARY-END(34361151010)
            
            //--TRIMMABLE-BOUNDARY-START(8591347234)
            /*string */ get Description()
            {
                return "Use a font.\r\n\r\nExample: ``font(url/name)``\r\n";
            }
            //--TRIMMABLE-BOUNDARY-END(8591347234)
            
            //--TRIMMABLE-BOUNDARY-START(30066183714)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The name/url of the font file");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30066183714)
            
            //--TRIMMABLE-BOUNDARY-START(38656118306)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                /*var*/ let index;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656118306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let font = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null)) ?? closure.Context.DefaultBackgroundSound;
                /*var*/ let fontSize = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "sz", "size" ], null, null));
                /*var*/ let fontColor = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "cl", "color" ], null, null));
                /*var*/ let fontHighlightColor = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "hcolor" ], null, null));
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                /*var*/ let fontCount = ((__ca1__ = closure.Context.Fonts) !== null ? $.$sl.SL.Enumerable.Count$1($.$$.S.String, __ca1__) : 0);
                if ($.$$.S.Int32.TryParse$6(font, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32)))
                {
                    if (index < 0)
                    {
                        font = null;
                    }
                    else if (fontCount > 0)
                    {
                        /*System.Collections.Generic.IEnumerable<string>?*/ let __ca2__;
                        font = ((__ca2__ = closure.Context.Fonts) !== null ? ($.$sl.SL.Enumerable.ElementAtOrDefault$1($.$$.S.String, __ca2__, index % fontCount) ?? font) : font);
                    }
                }
                else if (font !== null && !$.$$.S.String.Contains$1.call(font, /*/*/ 47))
                {
                    /*System.Collections.Generic.IEnumerable<string>?*/ let __ca3__;
                    font = ((__ca3__ = closure.Context.Fonts) !== null ? ($.$sl.SL.Enumerable.FirstOrDefault$1($.$$.S.String, __ca3__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*b*/ b) =>
                    {
                        return $.$$.S.String.Equals$2.call($.$$.SI.Path.GetFileNameWithoutExtension$1(b), font, 3/*StringComparison.InvariantCultureIgnoreCase*/);
                    }, $mkaxCb ??= {"r":262145,"p":[{"n":"b","p":1310721}],"n":"","d":1412642,"h":0,"f":17825794})) ?? font) : font);
                }
                if (font === null)
                {
                    /*System.Collections.Generic.IEnumerable<string>?*/ let __ca4__;
                    font = ((__ca4__ = closure.Context.Fonts) !== null ? $.$sl.SL.Enumerable.ElementAtOrDefault$1($.$$.S.String, __ca4__, $.$$.S.Random.Shared.Next$2(fontCount)) : null);
                }
                closure.Context.Font = font;
                closure.Context.FontSize = fontSize;
                closure.Context.FontColor = fontColor;
                closure.Context.FontHighlightColor = fontHighlightColor;
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38656118306)
            
            //--TRIMMABLE-BOUNDARY-START(4296379938)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296379938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296379938)
            
            //--TRIMMABLE-BOUNDARY-START(4296379938)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296379938)
            
            static $h = 1412642;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361151010),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771216418,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1412642,
      "h": 34361151010,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361151010),
//--TRIMMABLE-BOUNDARY-START(8591347234),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181281826,
        "f": 50364417
      },
      "n": "Description",
      "d": 1412642,
      "h": 8591347234,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591347234)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066183714),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1412642,
      "h": 30066183714,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066183714),
//--TRIMMABLE-BOUNDARY-START(38656118306),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1412642,
      "h": 38656118306,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656118306)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296379938),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1412642,
      "h": 4296379938,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296379938)
  ],
  "h": 1412642
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusFontTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusFontTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1412642)
        
        

        //--TRIMMABLE-BOUNDARY-START(2199074)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusShapeEllipseTokenResolver`, ($self) => class MarkdownPlusShapeEllipseTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34361937442)
            /*string */ get Invocation()
            {
                return "ellipse";
            }
            //--TRIMMABLE-BOUNDARY-END(34361937442)
            
            //--TRIMMABLE-BOUNDARY-START(8592133666)
            /*string */ get Description()
            {
                return "Draw an ellipse.\r\n\r\nExample: ``ellipse``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592133666)
            
            //--TRIMMABLE-BOUNDARY-START(30066970146)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["0", "cx"], null, null), "The relative x center of the ellipse (0..1)");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["1", "cy"], null, null), "The relative y center of the ellipse (0..1)");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["2", "rx"], null, null), "The relative x radius of the ellipse (0..1)");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["3", "ry"], null, null), "The relative y radius of the ellipse (0..1)");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bdc", "s", "stroke"], null, null), "The line color of the ellipse");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bdw", "sw", "strokeWidth"], null, null), "The line width of the ellipse");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bgc", "f", "fill"], null, null), "The fill color of the ellipse");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30066970146)
            
            //--TRIMMABLE-BOUNDARY-START(38656904738)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                /*var*/ let parent;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656904738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let centerx = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "cx", "centerx" ], null, null));
                /*var*/ let centery = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "cy", "centery" ], null, null));
                /*var*/ let radiusx = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 2, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "rx", "radiusx" ], null, null));
                /*var*/ let radiusy = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 3, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "ry", "radiusy" ], null, null));
                /*var*/ let stroke = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bdc", "s", "stroke" ], null, null));
                /*var*/ let strokeWidth = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bdw", "sw", "strokeWidth" ], null, null));
                /*var*/ let fill = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bgc", "f", "fill" ], null, null));
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*double*/ let cx = 0.5;
                /*double*/ let cy = 0.5;
                /*double*/ let rx = 0.49;
                /*double*/ let ry = 0.25;
                if (!$.$$.S.Double.TryParse$6(centerx, $.$ref(() => cx, ($v) => cx = $v, $.$$.S.Double)))
                {
                    cx = 0.5;
                }
                if (!$.$$.S.Double.TryParse$6(centery, $.$ref(() => cy, ($v) => cy = $v, $.$$.S.Double)))
                {
                    cy = 0.5;
                }
                if (!$.$$.S.Double.TryParse$6(radiusx, $.$ref(() => rx, ($v) => rx = $v, $.$$.S.Double)))
                {
                    rx = 0.49;
                }
                if (!$.$$.S.Double.TryParse$6(radiusy, $.$ref(() => ry, ($v) => ry = $v, $.$$.S.Double)))
                {
                    ry = 0.49;
                }
                /*var*/ let builder = $.$MdeX.LCFCMR.Utility.GetSVG(this, $.$clone(method), parameters, closure, $.$ref(() => parent, ($v) => parent = $v, $.$MdeX.LCFCMR.MarkdownPlusShapeSVGTokenResolver));
                builder.LCFCCSF$ISVGBuilder$MoveTo(cx, cy).LCFCCSF$ISVGEllipseBuilder$Ellipse(rx, ry);
                if (stroke !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$StrokeColor(stroke);
                }
                if (strokeWidth !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$StrokeWidth($.$$.S.Double.Parse$7(strokeWidth));
                }
                if (fill !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$FillColor(fill);
                }
                if ((parent?.SVG ?? null) === null)
                {
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(builder.LCFCCSF$ISVGBuilder$Build());
                }
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38656904738)
            
            //--TRIMMABLE-BOUNDARY-START(4297166370)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297166370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297166370)
            
            //--TRIMMABLE-BOUNDARY-START(4297166370)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297166370)
            
            static $h = 2199074;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361937442),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772002850,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2199074,
      "h": 34361937442,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361937442),
//--TRIMMABLE-BOUNDARY-START(8592133666),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182068258,
        "f": 50364417
      },
      "n": "Description",
      "d": 2199074,
      "h": 8592133666,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592133666)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066970146),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2199074,
      "h": 30066970146,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066970146),
//--TRIMMABLE-BOUNDARY-START(38656904738),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2199074,
      "h": 38656904738,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656904738)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297166370),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2199074,
      "h": 4297166370,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297166370)
  ],
  "h": 2199074
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusShapeEllipseTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusShapeEllipseTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2199074)
        
        

        //--TRIMMABLE-BOUNDARY-START(1543714)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusHighlightTokenResolver`, ($self) => class MarkdownPlusHighlightTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34361282082)
            /*string */ get Invocation()
            {
                return "highlight";
            }
            //--TRIMMABLE-BOUNDARY-END(34361282082)
            
            //--TRIMMABLE-BOUNDARY-START(8591478306)
            /*string */ get Description()
            {
                return "Highlight a text differently from the rest.\r\n\r\nExample: ``Hello highlight(World)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8591478306)
            
            //--TRIMMABLE-BOUNDARY-START(30066314786)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("-1", "The texts to highlight");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30066314786)
            
            //--TRIMMABLE-BOUNDARY-START(38656249378)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656249378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenElement(1, "b");
                    if (closure.Context.FontHighlightColor === null)
                    {
                        builder.AddAttribute$5(2, "class", "highlight");
                    }
                    builder.AddAttribute$5(4, "style", $.$strNN(style) + $.$strNN((closure.Context.FontHighlightColor !== null ? `color:${$.$strNN(closure.Context.FontHighlightColor)}` : "")));
                    $.$MdeX.LCFCMR.Utility.AddParameters(builder, parameters);
                    builder.CloseElement();
                }, $QVPEth ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1543714,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(38656249378)
            
            //--TRIMMABLE-BOUNDARY-START(4296511010)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296511010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296511010)
            
            //--TRIMMABLE-BOUNDARY-START(4296511010)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296511010)
            
            static $h = 1543714;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361282082),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771347490,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1543714,
      "h": 34361282082,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361282082),
//--TRIMMABLE-BOUNDARY-START(8591478306),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181412898,
        "f": 50364417
      },
      "n": "Description",
      "d": 1543714,
      "h": 8591478306,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591478306)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066314786),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1543714,
      "h": 30066314786,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066314786),
//--TRIMMABLE-BOUNDARY-START(38656249378),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1543714,
      "h": 38656249378,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656249378)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296511010),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1543714,
      "h": 4296511010,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296511010)
  ],
  "h": 1543714
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusHighlightTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusHighlightTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1543714)
        
        

        //--TRIMMABLE-BOUNDARY-START(1216034)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusClickTokenResolver`, ($self) => class MarkdownPlusClickTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34360954402)
            /*string */ get Invocation()
            {
                return "button/action";
            }
            //--TRIMMABLE-BOUNDARY-END(34360954402)
            
            //--TRIMMABLE-BOUNDARY-START(8591150626)
            /*string */ get Description()
            {
                return "Evaluate an expression when a click is made.\r\n\r\nExample: ``button($.Int[\"name\"]=$.Int[\"name\"]+1)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8591150626)
            
            //--TRIMMABLE-BOUNDARY-START(30065987106)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The expression to evaluate.");
                        $i1.Required = true;
                        return $i1;
                    })();
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("1", "Score to be awarded for this question, if correct.");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30065987106)
            
            //--TRIMMABLE-BOUNDARY-START(38655921698)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655921698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _class = $.$EVvT.LCFCM.MarkdownPlusUtility.GetClass(parameters);
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), context, null);
                /*var*/ let action = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "act", "click", "action" ], null, null));
                /*var*/ let answerId = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "answerId" ], null, null));
                /*var*/ let rootClosure = context.RootClosure;
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenElement(1, "button");
                    builder.AddAttribute$5(2, "class", "bg-transparent " + $.$strNN($.$dspc(_class, $.$$.S.Object, ($t) => $t.ToString)));
                    builder.AddAttribute$5(3, "style", style);
                    if (action !== null)
                    {
                        builder.AddAttribute$1(4, "onclick", $.$mac.MAC.EventCallback.Factory.Create$1(this, new $.$$.S.Action().$ctor(this,  () =>
                        {
                            rootClosure.Context.SafeExecute(new $.$$.S.Action().$ctor(this,  () =>
                            {
                                /*var*/ let result = rootClosure.EvaluateExpression(action, null);
                                if (answerId !== null)
                                {
                                    ($.$cast((rootClosure.ChosenAnswers), $.$EVvT.LCFCM.IMarkdownPlusMarkdownAnswerEditor)).LCFCM$IMarkdownPlusMarkdownAnswerEditor$SetAnswer$1(answerId, $.$clone(result), 0);
                                }
                            }, $aWrtDk ??= {"r":65537,"n":"","d":1216034,"h":0,"f":17825794}));
                            rootClosure.Context.RequestRendering();
                        }, $zOaCTk ??= {"r":65537,"n":"","d":1216034,"h":0,"f":17825794})));
                    }
                    $.$MdeX.LCFCMR.Utility.AddParameters(builder, parameters);
                    builder.CloseElement();
                }, $pcLiVa ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1216034,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(38655921698)
            
            //--TRIMMABLE-BOUNDARY-START(4296183330)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296183330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296183330)
            
            //--TRIMMABLE-BOUNDARY-START(4296183330)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296183330)
            
            static $h = 1216034;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360954402),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771019810,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1216034,
      "h": 34360954402,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360954402),
//--TRIMMABLE-BOUNDARY-START(8591150626),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181085218,
        "f": 50364417
      },
      "n": "Description",
      "d": 1216034,
      "h": 8591150626,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591150626)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065987106),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1216034,
      "h": 30065987106,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065987106),
//--TRIMMABLE-BOUNDARY-START(38655921698),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1216034,
      "h": 38655921698,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655921698)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296183330),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1216034,
      "h": 4296183330,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296183330)
  ],
  "h": 1216034
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusClickTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusClickTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1216034)
        
        

        //--TRIMMABLE-BOUNDARY-START(953890)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusBackgroundImageTokenResolver`, ($self) => class MarkdownPlusBackgroundImageTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34360692258)
            /*string */ get Invocation()
            {
                return "bg/background";
            }
            //--TRIMMABLE-BOUNDARY-END(34360692258)
            
            //--TRIMMABLE-BOUNDARY-START(8590888482)
            /*string */ get Description()
            {
                return "Show a background image.\r\n\r\nExample: ``bg(url/name)``\r\n";
            }
            //--TRIMMABLE-BOUNDARY-END(8590888482)
            
            //--TRIMMABLE-BOUNDARY-START(30065724962)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The name/url of the image file");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30065724962)
            
            //--TRIMMABLE-BOUNDARY-START(38655659554)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                /*var*/ let index;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655659554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let image = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null)) ?? closure.Context.DefaultBackgroundSound;
                /*var*/ let color = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "cl", "color" ], null, null));
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                /*var*/ let bannerCount = ((__ca1__ = closure.Context.Banners) !== null ? $.$sl.SL.Enumerable.Count$1($.$$.S.String, __ca1__) : 0);
                if ($.$$.S.Int32.TryParse$6(image, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32)))
                {
                    if (index < 0)
                    {
                        image = null;
                    }
                    else if (bannerCount > 0)
                    {
                        /*System.Collections.Generic.IEnumerable<string>?*/ let __ca2__;
                        image = ((__ca2__ = closure.Context.Banners) !== null ? ($.$sl.SL.Enumerable.ElementAtOrDefault$1($.$$.S.String, __ca2__, index % bannerCount) ?? image) : image);
                    }
                }
                else if (image !== null && !$.$$.S.String.Contains$1.call(image, /*/*/ 47))
                {
                    /*System.Collections.Generic.IEnumerable<string>?*/ let __ca3__;
                    image = ((__ca3__ = closure.Context.Banners) !== null ? ($.$sl.SL.Enumerable.FirstOrDefault$1($.$$.S.String, __ca3__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*b*/ b) =>
                    {
                        return $.$$.S.String.Equals$2.call($.$$.SI.Path.GetFileNameWithoutExtension$1(b), image, 3/*StringComparison.InvariantCultureIgnoreCase*/);
                    }, $htDPlk ??= {"r":262145,"p":[{"n":"b","p":1310721}],"n":"","d":953890,"h":0,"f":17825794})) ?? image) : image);
                }
                if (image === null)
                {
                    /*System.Collections.Generic.IEnumerable<string>?*/ let __ca4__;
                    image = ((__ca4__ = closure.Context.Banners) !== null ? $.$sl.SL.Enumerable.ElementAtOrDefault$1($.$$.S.String, __ca4__, $.$$.S.Random.Shared.Next$2(bannerCount)) : null);
                }
                if (image !== null)
                {
                    closure.Context.BackgroundBanner = image;
                    closure.Context.BackgroundColor = color;
                }
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38655659554)
            
            //--TRIMMABLE-BOUNDARY-START(4295921186)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295921186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295921186)
            
            //--TRIMMABLE-BOUNDARY-START(4295921186)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295921186)
            
            static $h = 953890;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360692258),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770757666,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 953890,
      "h": 34360692258,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360692258),
//--TRIMMABLE-BOUNDARY-START(8590888482),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180823074,
        "f": 50364417
      },
      "n": "Description",
      "d": 953890,
      "h": 8590888482,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590888482)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065724962),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 953890,
      "h": 30065724962,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065724962),
//--TRIMMABLE-BOUNDARY-START(38655659554),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 953890,
      "h": 38655659554,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655659554)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295921186),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 953890,
      "h": 4295921186,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295921186)
  ],
  "h": 953890
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusBackgroundImageTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusBackgroundImageTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(953890)
        
        

        //--TRIMMABLE-BOUNDARY-START(1019426)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusBackgroundSoundTokenResolver`, ($self) => class MarkdownPlusBackgroundSoundTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(42950692386)
            /*IMediaPlayer*/ player = null;
            //--TRIMMABLE-BOUNDARY-END(42950692386)
            
            //--TRIMMABLE-BOUNDARY-START(4295986722)
            $ctor$2(/*IMediaPlayer*/ player)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295986722);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.player = player;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295986722)
            
            //--TRIMMABLE-BOUNDARY-START(38655725090)
            /*string */ get Invocation()
            {
                return "sound/music";
            }
            //--TRIMMABLE-BOUNDARY-END(38655725090)
            
            //--TRIMMABLE-BOUNDARY-START(8590954018)
            /*string */ get Description()
            {
                return "Play a background sound.\r\n\r\nExample: ``sound(url/name)``\r\n";
            }
            //--TRIMMABLE-BOUNDARY-END(8590954018)
            
            //--TRIMMABLE-BOUNDARY-START(34360757794)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The name/url of the sound file");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(34360757794)
            
            //--TRIMMABLE-BOUNDARY-START(12885921314)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885921314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.player.LCFCS$3$IMediaPlayer$Stop();
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(12885921314)
            
            //--TRIMMABLE-BOUNDARY-START(47245659682)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                /*var*/ let index;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245659682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sound = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null)) ?? closure.Context.DefaultBackgroundSound;
                /*var*/ let play = $.$EVvT.LCFCM.MarkdownPlusUtility.GetBoolParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "play", "autoplay" ], null, null)) ?? false;
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                /*var*/ let musicCount = ((__ca1__ = closure.Context.Musics) !== null ? $.$sl.SL.Enumerable.Count$1($.$$.S.String, __ca1__) : 0);
                if ($.$$.S.Int32.TryParse$6(sound, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32)))
                {
                    if (index < 0)
                    {
                        sound = null;
                    }
                    else if (musicCount > 0)
                    {
                        /*System.Collections.Generic.IEnumerable<string>?*/ let __ca2__;
                        sound = ((__ca2__ = closure.Context.Musics) !== null ? ($.$sl.SL.Enumerable.ElementAtOrDefault$1($.$$.S.String, __ca2__, index % musicCount) ?? sound) : sound);
                    }
                }
                else if (sound !== null && !$.$$.S.String.Contains$1.call(sound, /*/*/ 47))
                {
                    /*System.Collections.Generic.IEnumerable<string>?*/ let __ca3__;
                    sound = ((__ca3__ = closure.Context.Musics) !== null ? ($.$sl.SL.Enumerable.FirstOrDefault$1($.$$.S.String, __ca3__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/**/ b) =>
                    {
                        return $.$$.S.String.Equals$2.call($.$$.SI.Path.GetFileNameWithoutExtension$1(b), sound, 3/*StringComparison.InvariantCultureIgnoreCase*/);
                    }, $wHzrbl ??= {"r":262145,"p":[{"n":"b","p":1310721}],"n":"","d":1019426,"h":0,"f":17825794})) ?? sound) : sound);
                }
                if (sound === null)
                {
                    /*System.Collections.Generic.IEnumerable<string>?*/ let __ca4__;
                    sound = ((__ca4__ = closure.Context.Musics) !== null ? $.$sl.SL.Enumerable.ElementAtOrDefault$1($.$$.S.String, __ca4__, $.$$.S.Random.Shared.Next$2(musicCount)) : null);
                }
                if (sound !== null && !closure.Context.Controls.ContainsKey("sound"))
                {
                    /*bool*/ let firstRender = true;
                    /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                    {
                        if (play && firstRender)
                        {
                            $.$fPer.LCFCS$3.MediaPlayerExtension.Play(this.player, sound, true, null);
                            closure.Context.BgMusicPlaying = true;
                        }
                        builder.AddContent$1(1, $.$MdeX.LCFCM.MarkdownPlusUtility.Button(closure, `mdi mdi-music${$.$strNN((!closure.Context.BgMusicPlaying ? "-off" : ""))}`, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                        {
                            if (!closure.Context.BgMusicPlaying)
                            {
                                $.$fPer.LCFCS$3.MediaPlayerExtension.Play(this.player, sound, true, null);
                            }
                            else 
                            {
                                this.player.LCFCS$3$IMediaPlayer$Pause();
                            }
                            closure.Context.BgMusicPlaying = !closure.Context.BgMusicPlaying;
                            closure.Context.RequestRendering();
                            return $.$$.STT.Task.CompletedTask;
                        }, $ZtcCnh ??= {"r":178454529,"n":"","d":1019426,"h":0,"f":17825794}), -1, -1, null));
                        firstRender = false;
                    }, $rsmFqc ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1019426,"h":0,"f":17825794});
                    closure.Context.Controls.set_Item("sound", view);
                }
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(47245659682)
            
            static $h = 1019426;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655725090),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065790498,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1019426,
      "h": 38655725090,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655725090),
//--TRIMMABLE-BOUNDARY-START(8590954018),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475855906,
        "f": 50364417
      },
      "n": "Description",
      "d": 1019426,
      "h": 8590954018,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590954018)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360757794),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1019426,
      "h": 34360757794,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360757794),
//--TRIMMABLE-BOUNDARY-START(12885921314),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1019426,
      "h": 12885921314,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885921314),
//--TRIMMABLE-BOUNDARY-START(47245659682),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1019426,
      "h": 47245659682,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245659682)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950692386),
    {
      "t": 61704534,
      "n": "player",
      "d": 1019426,
      "h": 42950692386,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950692386)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295986722),
    {
      "p": [
        {
          "n": "player",
          "p": 61704534
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1019426,
      "h": 4295986722,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295986722)
  ],
  "h": 1019426
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusBackgroundSoundTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusBackgroundSoundTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1019426)
        
        

        //--TRIMMABLE-BOUNDARY-START(2133538)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusShapeCircleTokenResolver`, ($self) => class MarkdownPlusShapeCircleTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34361871906)
            /*string */ get Invocation()
            {
                return "circle";
            }
            //--TRIMMABLE-BOUNDARY-END(34361871906)
            
            //--TRIMMABLE-BOUNDARY-START(8592068130)
            /*string */ get Description()
            {
                return "Draw a circle.\r\n\r\nExample: ``circle``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592068130)
            
            //--TRIMMABLE-BOUNDARY-START(30066904610)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["0", "cx"], null, null), "The relative x center of the circle (0..1)");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["1", "cy"], null, null), "The relative y center of the circle (0..1)");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["0", "radius"], null, null), "The relative radius of the circle (0..1)");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bdc", "s", "stroke"], null, null), "The line color of the circle");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bdw", "sw", "strokeWidth"], null, null), "The line width of the circle");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bgc", "f", "fill"], null, null), "The fill color of the circle");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30066904610)
            
            //--TRIMMABLE-BOUNDARY-START(38656839202)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                /*var*/ let parent;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656839202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let centerx = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "cx", "centerx" ], null, null));
                /*var*/ let centery = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "cy", "centery" ], null, null));
                /*var*/ let radius = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 2, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "r", "radius" ], null, null));
                /*var*/ let stroke = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bdc", "s", "stroke" ], null, null));
                /*var*/ let strokeWidth = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bdw", "sw", "strokeWidth" ], null, null));
                /*var*/ let fill = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bgc", "f", "fill" ], null, null));
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*double*/ let cx = 0.5;
                /*double*/ let cy = 0.5;
                /*double*/ let r = 0.49;
                if (!$.$$.S.Double.TryParse$6(centerx, $.$ref(() => cx, ($v) => cx = $v, $.$$.S.Double)))
                {
                    cx = 0.5;
                }
                if (!$.$$.S.Double.TryParse$6(centery, $.$ref(() => cy, ($v) => cy = $v, $.$$.S.Double)))
                {
                    cy = 0.5;
                }
                if (!$.$$.S.Double.TryParse$6(radius, $.$ref(() => r, ($v) => r = $v, $.$$.S.Double)))
                {
                    r = 0.49;
                }
                /*var*/ let builder = $.$MdeX.LCFCMR.Utility.GetSVG(this, $.$clone(method), parameters, closure, $.$ref(() => parent, ($v) => parent = $v, $.$MdeX.LCFCMR.MarkdownPlusShapeSVGTokenResolver));
                builder.LCFCCSF$ISVGBuilder$MoveTo(cx, cy).LCFCCSF$ISVGCircleBuilder$Circle($.$hDPm.LCFCC$1.Dimension.op_Implicit(r));
                if (stroke !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$StrokeColor(stroke);
                }
                if (strokeWidth !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$StrokeWidth($.$$.S.Double.Parse$7(strokeWidth));
                }
                if (fill !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$FillColor(fill);
                }
                if ((parent?.SVG ?? null) === null)
                {
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(builder.LCFCCSF$ISVGBuilder$Build());
                }
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38656839202)
            
            //--TRIMMABLE-BOUNDARY-START(4297100834)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297100834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297100834)
            
            //--TRIMMABLE-BOUNDARY-START(4297100834)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297100834)
            
            static $h = 2133538;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361871906),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771937314,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2133538,
      "h": 34361871906,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361871906),
//--TRIMMABLE-BOUNDARY-START(8592068130),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182002722,
        "f": 50364417
      },
      "n": "Description",
      "d": 2133538,
      "h": 8592068130,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592068130)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066904610),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2133538,
      "h": 30066904610,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066904610),
//--TRIMMABLE-BOUNDARY-START(38656839202),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2133538,
      "h": 38656839202,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656839202)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297100834),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2133538,
      "h": 4297100834,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297100834)
  ],
  "h": 2133538
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusShapeCircleTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusShapeCircleTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2133538)
        
        

        //--TRIMMABLE-BOUNDARY-START(1740322)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusObjectTokenResolver`, ($self) => class MarkdownPlusObjectTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34361478690)
            /*string */ get Invocation()
            {
                return "object";
            }
            //--TRIMMABLE-BOUNDARY-END(34361478690)
            
            //--TRIMMABLE-BOUNDARY-START(8591674914)
            /*string */ get Description()
            {
                return "Display an object.\r\n\r\nExample: ``object(icon(heart))``";
            }
            //--TRIMMABLE-BOUNDARY-END(8591674914)
            
            //--TRIMMABLE-BOUNDARY-START(30066511394)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "An icon, ``object(icon(heart))``, an image ``object(image/alphabet/letter_a)``");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30066511394)
            
            //--TRIMMABLE-BOUNDARY-START(38656445986)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656445986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let object = $.$EVvT.LCFCM.MarkdownPlusUtility.GetParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*string?*/ let resolvedObject = null;
                /*string?*/ let objectName = null;
                let icon;
                if ($.$is(object.Value, $.$fPer.LCFC.IconDescriptor, { set $v($v){ icon = $v; } }))
                {
                    objectName = icon.Title;
                    resolvedObject = icon.Icon;
                }
                else 
                {
                    objectName = object.ToString();
                    /*var*/ let objName = $.$strNN("/" + $.$strNN(object.ToString())) + ".";
                    /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                    resolvedObject = ((__ca1__ = closure.Context.Assets) !== null ? $.$sl.SL.Enumerable.SingleOrDefault$1($.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                    {
                        return $.$$.S.String.Contains$2.call(a, objName, 3/*StringComparison.InvariantCultureIgnoreCase*/);
                    }, $olOHfd ??= {"r":262145,"p":[{"n":"a","p":1310721}],"n":"","d":1740322,"h":0,"f":17825794})) : null);
                }
                if (resolvedObject !== null)
                {
                    /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                    {
                        builder.OpenElement(1, "div");
                        builder.AddAttribute$5(2, "style", style);
                        {
                            builder.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 3);
                            builder.AddAttribute$5(4, "Url", resolvedObject);
                            builder.AddAttribute$4(5, "Features", $.$box(387/*MediaFeatures.Default*/ & ~3/*MediaFeatures.Responsive*/, $.$hDPm.LCFCCM$3.MediaFeatures));
                            builder.CloseComponent();
                        }
                        builder.CloseElement();
                    }, $qJAgkj ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1740322,"h":0,"f":17825794});
                    return (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusToken()
                        const $t2 = $.$EVvT.LCFCM.MarkdownPlusToken;
                        const $i2 = new $t2();
                        $i2.$ctor$3(view);
                        $i2.Name = objectName;
                        return $i2;
                    })();
                }
                return $.$with(object, ($clone) =>
                {
                    $clone.Name = objectName ?? object.Name;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38656445986)
            
            //--TRIMMABLE-BOUNDARY-START(4296707618)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296707618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296707618)
            
            //--TRIMMABLE-BOUNDARY-START(4296707618)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296707618)
            
            static $h = 1740322;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361478690),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771544098,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1740322,
      "h": 34361478690,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361478690),
//--TRIMMABLE-BOUNDARY-START(8591674914),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181609506,
        "f": 50364417
      },
      "n": "Description",
      "d": 1740322,
      "h": 8591674914,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591674914)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066511394),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1740322,
      "h": 30066511394,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066511394),
//--TRIMMABLE-BOUNDARY-START(38656445986),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1740322,
      "h": 38656445986,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656445986)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296707618),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1740322,
      "h": 4296707618,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296707618)
  ],
  "h": 1740322
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusObjectTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusObjectTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1740322)
        
        

        //--TRIMMABLE-BOUNDARY-START(2330146)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusShapeLineTokenResolver`, ($self) => class MarkdownPlusShapeLineTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362068514)
            /*string */ get Invocation()
            {
                return "line";
            }
            //--TRIMMABLE-BOUNDARY-END(34362068514)
            
            //--TRIMMABLE-BOUNDARY-START(8592264738)
            /*string */ get Description()
            {
                return "Draw a line.\r\n\r\nExample: ``line``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592264738)
            
            //--TRIMMABLE-BOUNDARY-START(30067101218)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["0", "x0"], null, null), "The relative x starting point 1 of the line. Default to 0.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["1", "y0"], null, null), "The relative y starting point 1 of the line. Default to 0.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["2", "x1"], null, null), "The relative x starting point 2 of the line. Default to 1.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["3", "y1"], null, null), "The relative y starting point 2 of the line. Default to 1.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bdc", "s", "stroke"], null, null), "The color of the line");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bdw", "sw", "strokeWidth"], null, null), "The line width");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bgc", "f", "fill"], null, null), "The fill color");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067101218)
            
            //--TRIMMABLE-BOUNDARY-START(38657035810)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                /*var*/ let parent;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657035810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let x0 = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "x0" ], null, null));
                /*var*/ let y0 = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "y0" ], null, null));
                /*var*/ let x1 = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 2, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "x1" ], null, null));
                /*var*/ let y1 = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 3, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "y1" ], null, null));
                /*var*/ let stroke = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bdc", "s", "stroke" ], null, null));
                /*var*/ let strokeWidth = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bdw", "sw", "strokeWidth" ], null, null));
                /*var*/ let fill = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bgc", "f", "fill" ], null, null));
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*double*/ let _x0 = 0;
                /*double*/ let _y0 = 0;
                /*double*/ let _x1 = 1;
                /*double*/ let _y1 = 1;
                if (!$.$$.S.Double.TryParse$6(x0, $.$ref(() => _x0, ($v) => _x0 = $v, $.$$.S.Double)))
                {
                    _x0 = 0;
                }
                if (!$.$$.S.Double.TryParse$6(y0, $.$ref(() => _y0, ($v) => _y0 = $v, $.$$.S.Double)))
                {
                    _y0 = 0;
                }
                if (!$.$$.S.Double.TryParse$6(x1, $.$ref(() => _x1, ($v) => _x1 = $v, $.$$.S.Double)))
                {
                    _x1 = 1;
                }
                if (!$.$$.S.Double.TryParse$6(y1, $.$ref(() => _y1, ($v) => _y1 = $v, $.$$.S.Double)))
                {
                    _y1 = 1;
                }
                /*var*/ let builder = $.$MdeX.LCFCMR.Utility.GetSVG(this, $.$clone(method), parameters, closure, $.$ref(() => parent, ($v) => parent = $v, $.$MdeX.LCFCMR.MarkdownPlusShapeSVGTokenResolver));
                builder.LCFCCSF$ISVGBuilder$MoveTo(_x0, _y0).LCFCCSF$ISVGLineBuilder$LineTo(_x1, _y1, false);
                if (stroke !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$StrokeColor(stroke);
                }
                if (strokeWidth !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$StrokeWidth($.$$.S.Double.Parse$7(strokeWidth));
                }
                if (fill !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$FillColor(fill);
                }
                if ((parent?.SVG ?? null) === null)
                {
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(builder.LCFCCSF$ISVGBuilder$Build());
                }
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38657035810)
            
            //--TRIMMABLE-BOUNDARY-START(4297297442)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297297442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297297442)
            
            //--TRIMMABLE-BOUNDARY-START(4297297442)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297297442)
            
            static $h = 2330146;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362068514),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772133922,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2330146,
      "h": 34362068514,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362068514),
//--TRIMMABLE-BOUNDARY-START(8592264738),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182199330,
        "f": 50364417
      },
      "n": "Description",
      "d": 2330146,
      "h": 8592264738,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592264738)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067101218),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2330146,
      "h": 30067101218,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067101218),
//--TRIMMABLE-BOUNDARY-START(38657035810),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2330146,
      "h": 38657035810,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657035810)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297297442),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2330146,
      "h": 4297297442,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297297442)
  ],
  "h": 2330146
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusShapeLineTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusShapeLineTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2330146)
        
        

        //--TRIMMABLE-BOUNDARY-START(2526754)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusShapeTextTokenResolver`, ($self) => class MarkdownPlusShapeTextTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362265122)
            /*string */ get Invocation()
            {
                return "text";
            }
            //--TRIMMABLE-BOUNDARY-END(34362265122)
            
            //--TRIMMABLE-BOUNDARY-START(8592461346)
            /*string */ get Description()
            {
                return "Draw an svg text.\r\n\r\nExample: ``text(t:Hello)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592461346)
            
            //--TRIMMABLE-BOUNDARY-START(30067297826)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["0", "x0"], null, null), "The relative x starting point of the rectangle. Default to 0.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["1", "y0"], null, null), "The relative y starting point of the rectangle. Default to 0.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["2", "t", "text"], null, null), "The text to draw. Default to  text");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bdc", "s", "stroke"], null, null), "The color of the line");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bdw", "sw", "strokeWidth"], null, null), "The line width");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bgc", "f", "fill"], null, null), "The fill color");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["b", "baseline"], null, null), "The baseline of the text.\r\nauto,\r\ntextbottom,\r\nalphabetic,\r\nideographic,\r\nmiddle,\r\ncentral,\r\nmathematical,\r\nhanging,\r\ntexttop");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["a", "anchor"], null, null), "The anchor of the text.\r\nnone,\r\nstart,\r\nmiddle,\r\nend\r\n");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067297826)
            
            //--TRIMMABLE-BOUNDARY-START(38657232418)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                /*var*/ let parent;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657232418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let x0 = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "x0" ], null, null));
                /*var*/ let y0 = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "y0" ], null, null));
                /*var*/ let text = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 2, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "t", "text" ], null, null));
                /*var*/ let stroke = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bdc", "s", "stroke" ], null, null));
                /*var*/ let strokeWidth = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bdw", "sw", "strokeWidth" ], null, null));
                /*var*/ let fill = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bgc", "f", "fill" ], null, null));
                /*var*/ let baseLine = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "b", "baseline" ], null, null));
                /*var*/ let textAnchor = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "a", "anchor" ], null, null));
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*double*/ let _x0 = 0;
                /*double*/ let _y0 = 0;
                /*BaseLine*/ let bl = 0/*BaseLine.Auto*/;
                /*TextAnchor*/ let ta = 0/*TextAnchor.None*/;
                if (!$.$$.S.Double.TryParse$6(x0, $.$ref(() => _x0, ($v) => _x0 = $v, $.$$.S.Double)))
                {
                    _x0 = 0;
                }
                if (!$.$$.S.Double.TryParse$6(y0, $.$ref(() => _y0, ($v) => _y0 = $v, $.$$.S.Double)))
                {
                    _y0 = 0;
                }
                $.$$.S.Enum.TryParse$9($.$hDPm.LCFCCSA.BaseLine, baseLine, true, $.$ref(() => bl, ($v) => bl = $v, $.$hDPm.LCFCCSA.BaseLine));
                $.$$.S.Enum.TryParse$9($.$hDPm.LCFCCSA.TextAnchor, textAnchor, true, $.$ref(() => ta, ($v) => ta = $v, $.$hDPm.LCFCCSA.TextAnchor));
                /*var*/ let builder = $.$MdeX.LCFCMR.Utility.GetSVG(this, $.$clone(method), parameters, closure, $.$ref(() => parent, ($v) => parent = $v, $.$MdeX.LCFCMR.MarkdownPlusShapeSVGTokenResolver));
                builder.LCFCCSF$ISVGBuilder$MoveTo(_x0, _y0).LCFCCSF$ISVGTextBuilder$Text(text ?? "text").LCFCCSF$ISVGBuilder$BaseLine(bl).LCFCCSF$ISVGBuilder$TextAnchor(ta);
                if (stroke !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$StrokeColor(stroke);
                }
                if (strokeWidth !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$StrokeWidth($.$$.S.Double.Parse$7(strokeWidth));
                }
                if (fill !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$FillColor(fill);
                }
                if ((parent?.SVG ?? null) === null)
                {
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(builder.LCFCCSF$ISVGBuilder$Build());
                }
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38657232418)
            
            //--TRIMMABLE-BOUNDARY-START(4297494050)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297494050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297494050)
            
            //--TRIMMABLE-BOUNDARY-START(4297494050)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297494050)
            
            static $h = 2526754;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362265122),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772330530,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2526754,
      "h": 34362265122,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362265122),
//--TRIMMABLE-BOUNDARY-START(8592461346),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182395938,
        "f": 50364417
      },
      "n": "Description",
      "d": 2526754,
      "h": 8592461346,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592461346)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067297826),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2526754,
      "h": 30067297826,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067297826),
//--TRIMMABLE-BOUNDARY-START(38657232418),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2526754,
      "h": 38657232418,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657232418)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297494050),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2526754,
      "h": 4297494050,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297494050)
  ],
  "h": 2526754
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusShapeTextTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusShapeTextTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2526754)
        
        

        //--TRIMMABLE-BOUNDARY-START(1936930)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusOptionsSelectTokenResolver`, ($self) => class MarkdownPlusOptionsSelectTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34361675298)
            /*string */ get Invocation()
            {
                return "options/voptions/hoptions";
            }
            //--TRIMMABLE-BOUNDARY-END(34361675298)
            
            //--TRIMMABLE-BOUNDARY-START(8591871522)
            /*string */ get Description()
            {
                return "Display many options with series of texts inside each option.\r\nThe id of the options is the index of that option in the list starting from 1.\r\n\r\nExample: ``option(A, B, C, D)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8591871522)
            
            //--TRIMMABLE-BOUNDARY-START(30066708002)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("-1", "The text to show in the option");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30066708002)
            
            //--TRIMMABLE-BOUNDARY-START(38656642594)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656642594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let separator = $.$EVvT.LCFCM.MarkdownPlusUtility.GetSeparator(parameters) ?? $.$MdeX.LCFCMR.Utility.Space();
                /*var*/ let shuffle = $.$EVvT.LCFCM.MarkdownPlusUtility.GetBoolParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "sf", "shuffle" ], null, null)) ?? true;
                /*var*/ let multipleSelect = $.$EVvT.LCFCM.MarkdownPlusUtility.GetParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "multiple", "mp" ], null, null));
                /*object*/ let __ca1__;
                /*object?*/ let __ca2__;
                if ((((__ca1__ = separator) !== null ? $.$dsp(__ca1__, $.$$.S.Object, ($t) => $t.Equals$1, "null") : false)) || (((__ca2__ = separator) !== null ? $.$dspc(__ca2__, $.$$.S.Object, ($t) => $t.Equals$1, "no") : false)))
                {
                    separator = null;
                }
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*var*/ let shuffledOptions = $.$sl.SL.Enumerable.ToList($.$$.S.ValueTuple$$$($.$fPer.LCFCD.QueryOption, $.$$.S.Int32), $.$sl.SL.Enumerable.OrderBy$1($.$$.S.ValueTuple$$$($.$fPer.LCFCD.QueryOption, $.$$.S.Int32), $.$$.S.Int32, $.$sl.SL.Enumerable.Select($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.ValueTuple$$$($.$fPer.LCFCD.QueryOption, $.$$.S.Int32), parameters, new ($.$$.S.Func$$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32, $.$$.S.ValueTuple$$$($.$fPer.LCFCD.QueryOption, $.$$.S.Int32)))().$ctor(this,  (/*p*/ p, /*i*/ i) =>
                {
                    return new ($.$$.S.ValueTuple$$$($.$fPer.LCFCD.QueryOption, $.$$.S.Int32))().$ctor$3((() =>
                    {
                        //new $.$fPer.LCFCD.QueryOption()
                        const $t2 = $.$fPer.LCFCD.QueryOption;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.Option = $.$$.S.Int32.ToString.call((((i + 1) | 0)));
                        $i2.Value = p.Value;
                        return $i2;
                    })(), i);
                }, $mMOVPe ??= {"r":$.$$.S.ValueTuple$$$($.$fPer.LCFCD.QueryOption, $.$$.S.Int32).$h,"p":[{"n":"p","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h},{"n":"i","p":655361}],"n":"","d":1936930,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$fPer.LCFCD.QueryOption, $.$$.S.Int32), $.$$.S.Int32))().$ctor(this,  (/*o*/ o) =>
                {
                    return shuffle ? $.$$.S.Random.Shared.Next() : 0;
                }, $TSAHBg ??= {"r":655361,"p":[{"n":"o","p":$.$$.S.ValueTuple$$$($.$fPer.LCFCD.QueryOption, $.$$.S.Int32).$h}],"n":"","d":1936930,"h":0,"f":17825794})));
                closure.Options.AddRange($.$sl.SL.Enumerable.Select$1($.$$.S.ValueTuple$$$($.$fPer.LCFCD.QueryOption, $.$$.S.Int32), $.$fPer.LCFCD.QueryOption, shuffledOptions, new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$fPer.LCFCD.QueryOption, $.$$.S.Int32), $.$fPer.LCFCD.QueryOption))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.Item1;
                }, $lSrKRe ??= {"r":32934230,"p":[{"n":"s","p":$.$$.S.ValueTuple$$$($.$fPer.LCFCD.QueryOption, $.$$.S.Int32).$h}],"n":"","d":1936930,"h":0,"f":17825794})));
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenElement(1, "div");
                    builder.AddAttribute$5(2, "class", "mgt-10 " + $.$strNN(($.$fPer.LCFC.Stringy.op_Implicit$1(method) === "voptions" ? "stack" : `flex flow`)));
                    builder.AddAttribute$5(3, "style", style);
                    /*int*/ let i = 0;
                    let $en3 = shuffledOptions.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        let option = $en3.Current;
                        {
                            if (i !== 0 && separator !== null)
                            {
                                $.$MdeX.LCFCMR.Utility.AddParameter(builder, separator, null);
                            }
                            /*var*/ let dic = (() =>
                            {
                                //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken)()
                                const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken);
                                const $i4 = new $t4();
                                $i4.$ctor$1();
                                $i4.set_Item("0", new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(option.Item1));
                                $i4.set_Item("1", new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(option.Item1.Value));
                                return $i4;
                            })();
                            builder.AddContent$1(4, multipleSelect.Value !== null ? $.$MdeX.LCFCMR.MarkdownPlusViews.SelectCheckbox$1($.$clone(method), dic, closure.RootClosure, "mg", false) : $.$MdeX.LCFCMR.MarkdownPlusViews.SelectButton$1($.$clone(method), dic, closure.RootClosure, "mg"));
                            i++;
                        }
                    }
                    builder.CloseElement();
                }, $hmwDNg ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1936930,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(38656642594)
            
            //--TRIMMABLE-BOUNDARY-START(4296904226)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296904226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296904226)
            
            //--TRIMMABLE-BOUNDARY-START(4296904226)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296904226)
            
            static $h = 1936930;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361675298),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771740706,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1936930,
      "h": 34361675298,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361675298),
//--TRIMMABLE-BOUNDARY-START(8591871522),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181806114,
        "f": 50364417
      },
      "n": "Description",
      "d": 1936930,
      "h": 8591871522,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591871522)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066708002),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1936930,
      "h": 30066708002,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066708002),
//--TRIMMABLE-BOUNDARY-START(38656642594),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1936930,
      "h": 38656642594,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656642594)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296904226),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1936930,
      "h": 4296904226,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296904226)
  ],
  "h": 1936930
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusOptionsSelectTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusOptionsSelectTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1936930)
        
        

        //--TRIMMABLE-BOUNDARY-START(2002466)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusPanelTokenResolver`, ($self) => class MarkdownPlusPanelTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34361740834)
            /*string */ get Invocation()
            {
                return "panel/flex/horizontal/hor/stack/vertical/vert";
            }
            //--TRIMMABLE-BOUNDARY-END(34361740834)
            
            //--TRIMMABLE-BOUNDARY-START(8591937058)
            /*string */ get Description()
            {
                return "A container.\r\n\r\nExample: ``panel(1)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8591937058)
            
            //--TRIMMABLE-BOUNDARY-START(30066773538)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("-1", "The contents of the container");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30066773538)
            
            //--TRIMMABLE-BOUNDARY-START(38656708130)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656708130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let $class = $.$EVvT.LCFCM.MarkdownPlusUtility.GetClass(parameters);
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*var*/ let separator = $.$EVvT.LCFCM.MarkdownPlusUtility.GetSeparator(parameters);
                /*var*/ let flow = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "f", "flow" ], null, null)) === "true";
                /*var*/ let spaceBetween = separator !== null && $.$dspc(separator, $.$$.S.Object, ($t) => $t.ToString) !== "false";
                /*var*/ let action = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "act", "click", "action" ], null, null));
                /*object?*/ let __ca1__;
                /*string?*/ let __ca2__;
                if ((__ca1__ = separator) !== null ? ((__ca2__ = $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString)) !== null ? $.$$.S.String.Equals$2.call(__ca2__, "true", 3/*StringComparison.InvariantCultureIgnoreCase*/) : false) : false)
                {
                    separator = null;
                }
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenElement(1, "div");
                    builder.AddAttribute$5(2, "class", `${$.$strNN(($.$fPer.LCFC.Stringy.op_Implicit$1(method) === "flex" || $.$fPer.LCFC.Stringy.op_Implicit$1(method) === "horizontal" || $.$fPer.LCFC.Stringy.op_Implicit$1(method) === "hor" ? "flex" : $.$fPer.LCFC.Stringy.op_Implicit$1(method) === "stack" || $.$fPer.LCFC.Stringy.op_Implicit$1(method) === "vertical" || $.$fPer.LCFC.Stringy.op_Implicit$1(method) === "vert" ? "stack" : ""))}${$.$strNN((flow ? " flow" : ""))}${$.$strNN((action !== null ? " clickable" : ""))} ${$.$strNN($.$dspc($class, $.$$.S.Object, ($t) => $t.ToString))}`);
                    builder.AddAttribute$5(3, "style", style);
                    if (action !== null)
                    {
                        builder.AddAttribute$1(4, "onclick", $.$mac.MAC.EventCallback.Factory.Create$1(this, new $.$$.S.Action().$ctor(this,  () =>
                        {
                            closure.Context.SafeExecute(new $.$$.S.Action().$ctor(this,  () =>
                            {
                                closure.EvaluateExpression(action, null);
                            }, $YLuPxe ??= {"r":65537,"n":"","d":2002466,"h":0,"f":17825794}));
                            closure.Context.RequestRendering();
                        }, $nTXJDd ??= {"r":65537,"n":"","d":2002466,"h":0,"f":17825794})));
                    }
                    /*int*/ let len = parameters.Count;
                    /*int*/ let i = 0;
                    let $en1 = parameters.Values.GetEnumerator();
                    while ($en1.MoveNext())
                    {
                        let parameter = $en1.Current;
                        {
                            if (spaceBetween && i !== 0)
                            {
                                if (separator !== null)
                                {
                                    $.$MdeX.LCFCMR.Utility.AddParameter(builder, separator, null);
                                }
                                else 
                                {
                                    $.$MdeX.LCFCMR.Utility.Space().Invoke(builder);
                                }
                            }
                            $.$MdeX.LCFCMR.Utility.AddParameter(builder, $.$clone(parameter), spaceBetween ? (separator ?? $.$MdeX.LCFCMR.Utility.Space()) : null);
                            i++;
                        }
                    }
                    builder.CloseElement();
                }, $kopeYa ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":2002466,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(38656708130)
            
            //--TRIMMABLE-BOUNDARY-START(4296969762)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296969762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296969762)
            
            //--TRIMMABLE-BOUNDARY-START(4296969762)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296969762)
            
            static $h = 2002466;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361740834),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771806242,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2002466,
      "h": 34361740834,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361740834),
//--TRIMMABLE-BOUNDARY-START(8591937058),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181871650,
        "f": 50364417
      },
      "n": "Description",
      "d": 2002466,
      "h": 8591937058,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591937058)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066773538),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2002466,
      "h": 30066773538,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066773538),
//--TRIMMABLE-BOUNDARY-START(38656708130),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2002466,
      "h": 38656708130,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656708130)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296969762),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2002466,
      "h": 4296969762,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296969762)
  ],
  "h": 2002466
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusPanelTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusPanelTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2002466)
        
        

        //--TRIMMABLE-BOUNDARY-START(2788898)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusTableTokenResolver`, ($self) => class MarkdownPlusTableTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362527266)
            /*string */ get Invocation()
            {
                return "table";
            }
            //--TRIMMABLE-BOUNDARY-END(34362527266)
            
            //--TRIMMABLE-BOUNDARY-START(8592723490)
            /*string */ get Description()
            {
                return "Draw a table. The cell contents can access variables defined by the repeater as \r\n\r\n$i: the current overall iterator index of the repeater\r\n\r\n$ix: the current x index of the repeater\r\n\r\n$iy: the current y index of the repeater\r\n\r\nExample: ``table(2,2,$i)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592723490)
            
            //--TRIMMABLE-BOUNDARY-START(30067559970)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The number of columns");
                        $i1.Required = true;
                        return $i1;
                    })();
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t2 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i2 = new $t2();
                        $i2.$ctor$3("1", "The number of rows");
                        $i2.Required = true;
                        return $i2;
                    })();
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("i", "The name to use in place of $i for the overall iterator index");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("ix", "The name to use in place of $ix for the x iterator index");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("iy", "The name to use in place of $i for the y iterator index");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("-1", "The content to be repeated");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067559970)
            
            //--TRIMMABLE-BOUNDARY-START(38657494562)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657494562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let nX = $.$$.S.Int32.Parse$7($.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null)));
                /*var*/ let nY = $.$$.S.Int32.Parse$7($.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredStringParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null)));
                /*var*/ let separator = $.$EVvT.LCFCM.MarkdownPlusUtility.GetSeparator(parameters);
                /*var*/ let repeatIteratorName = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "i" ], null, null));
                if (repeatIteratorName !== null)
                {
                    repeatIteratorName = "$" + $.$strNN(repeatIteratorName);
                }
                /*var*/ let xRepeatIteratorName = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "ix" ], null, null));
                if (xRepeatIteratorName !== null)
                {
                    xRepeatIteratorName = "$" + $.$strNN(xRepeatIteratorName);
                }
                /*var*/ let yRepeatIteratorName = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "iy" ], null, null));
                if (yRepeatIteratorName !== null)
                {
                    yRepeatIteratorName = "$" + $.$strNN(yRepeatIteratorName);
                }
                /*var*/ let _class = $.$EVvT.LCFCM.MarkdownPlusUtility.GetClass(parameters);
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*var*/ let rowClass = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "r_class" ], null, null));
                /*var*/ let rowStyle = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, "r_");
                /*var*/ let cellClass = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "c_class" ], null, null));
                /*var*/ let cellStyle = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, "c_");
                /*var*/ let val = $.$sl.SL.Enumerable.Last$1($.$EVvT.LCFCM.MarkdownPlusToken, parameters.Values);
                /*Dictionary<(int, int), IEnumerable<MarkdownPlusToken>>*/ let keyedColumn = new ($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32), $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken)))().$ctor$1();
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                {
                    builder.OpenElement(1, "table");
                    builder.AddAttribute$4(2, "class", _class);
                    const $t3 = style;
                    builder.AddAttribute$5(3, "style", $.$strNN($.$strNN(style) + $.$strNN(($.$$.S.Int32.op_GreaterThan($.$ifnn($t3, ($t) => $t.length), 0) ? ";" : ""))) + $.$strNN(`border-collapse:collapse;border-spacing:0`));
                    builder.OpenElement(4, "tbody");
                    for(/*int*/ let iY = 0; iY < nY; iY++)
                    {
                        builder.OpenElement(5, "tr");
                        builder.AddAttribute$5(6, "style", rowStyle);
                        builder.AddAttribute$5(7, "class", rowClass);
                        for(/*int*/ let iX = 0; iX < nX; iX++)
                        {
                            /*var*/ let views;
                            /*int*/ let iteratorIndex = (((((((iY * nX) | 0) + iX) | 0)) + 1) | 0);
                            builder.OpenElement(8, "td");
                            builder.AddAttribute$5(9, "style", cellStyle);
                            builder.AddAttribute$5(10, "class", cellClass);
                            if (!keyedColumn.TryGetValue(new ($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$3(iX, iY), $.$ref(() => views, ($v) => views = $v, $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken))))
                            {
                                let defered;
                                if ($.$is(val.Value, $.$EVvT.LCFCM.MarkdownPlusDeferedParameterResolver, { set $v($v){ defered = $v; } }))
                                {
                                    /*var*/ let iclosure = new $.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure().$ctor$2(closure);
                                    iclosure.Set($.$$.S.Int32, $.$fPer.LCFC.Stringy.op_Implicit$3(repeatIteratorName ?? "$i"/*MarkdownPlusConst.DefaultRepeatIteratorIndexName*/), iteratorIndex);
                                    iclosure.Set($.$$.S.Int32, $.$fPer.LCFC.Stringy.op_Implicit$3(xRepeatIteratorName ?? $.$strNN("$i"/*MarkdownPlusConst.DefaultRepeatIteratorIndexName*/) + "x"), iX);
                                    iclosure.Set($.$$.S.Int32, $.$fPer.LCFC.Stringy.op_Implicit$3(yRepeatIteratorName ?? $.$strNN("$i"/*MarkdownPlusConst.DefaultRepeatIteratorIndexName*/) + "y"), iY);
                                    views = defered.GetValue(iclosure);
                                    if (views !== null)
                                    {
                                        keyedColumn.set_Item(new ($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$3(iX, iY), views);
                                    }
                                }
                                else 
                                {
                                    $.$MdeX.LCFCMR.Utility.AddParameter(builder, $.$clone(val), null);
                                }
                            }
                            if (views !== null)
                            {
                                let $en5 = views.SCG$IEnumerable$$$GetEnumerator();
                                while ($en5.SC$1$IEnumerator$MoveNext())
                                {
                                    let view = $en5.SCG$IEnumerator$$$Current;
                                    {
                                        $.$MdeX.LCFCMR.Utility.AddParameter(builder, view.Value, null);
                                    }
                                }
                            }
                            builder.CloseElement();
                        }
                        builder.CloseElement();
                    }
                    builder.CloseElement();
                    builder.CloseElement();
                }, $JlNXUd ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":2788898,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(38657494562)
            
            //--TRIMMABLE-BOUNDARY-START(4297756194)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297756194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297756194)
            
            //--TRIMMABLE-BOUNDARY-START(4297756194)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297756194)
            
            static $h = 2788898;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362527266),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772592674,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2788898,
      "h": 34362527266,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362527266),
//--TRIMMABLE-BOUNDARY-START(8592723490),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182658082,
        "f": 50364417
      },
      "n": "Description",
      "d": 2788898,
      "h": 8592723490,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592723490)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067559970),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2788898,
      "h": 30067559970,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067559970),
//--TRIMMABLE-BOUNDARY-START(38657494562),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2788898,
      "h": 38657494562,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657494562)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297756194),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2788898,
      "h": 4297756194,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297756194)
  ],
  "h": 2788898
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusTableTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusTableTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2788898)
        
        

        //--TRIMMABLE-BOUNDARY-START(2395682)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusShapeRectangleTokenResolver`, ($self) => class MarkdownPlusShapeRectangleTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362134050)
            /*string */ get Invocation()
            {
                return "rectangle";
            }
            //--TRIMMABLE-BOUNDARY-END(34362134050)
            
            //--TRIMMABLE-BOUNDARY-START(8592330274)
            /*string */ get Description()
            {
                return "Draw a rectangle.\r\n\r\nExample: ``rectangle``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592330274)
            
            //--TRIMMABLE-BOUNDARY-START(30067166754)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["0", "x0"], null, null), "The relative x starting point of the rectangle. Default to 0.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["1", "y0"], null, null), "The relative y starting point of the rectangle. Default to 0.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["2", "rw"], null, null), "The relative width of the rectangle. Default to 1.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["3", "rh"], null, null), "The relative height of the rectangle. Default to 1.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bdc", "s", "stroke"], null, null), "The color of the line");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bdw", "sw", "strokeWidth"], null, null), "The line width");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bgc", "f", "fill"], null, null), "The fill color");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067166754)
            
            //--TRIMMABLE-BOUNDARY-START(38657101346)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                /*var*/ let parent;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657101346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let x0 = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "x0" ], null, null));
                /*var*/ let y0 = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "y0" ], null, null));
                /*var*/ let rw = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 2, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "rw" ], null, null));
                /*var*/ let rh = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 3, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "rh" ], null, null));
                /*var*/ let stroke = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bdc", "s", "stroke" ], null, null));
                /*var*/ let strokeWidth = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bdw", "sw", "strokeWidth" ], null, null));
                /*var*/ let fill = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bgc", "f", "fill" ], null, null));
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*double*/ let _x0 = 0;
                /*double*/ let _y0 = 0;
                /*double*/ let _rw = 1;
                /*double*/ let _rh = 1;
                if (!$.$$.S.Double.TryParse$6(x0, $.$ref(() => _x0, ($v) => _x0 = $v, $.$$.S.Double)))
                {
                    _x0 = 0;
                }
                if (!$.$$.S.Double.TryParse$6(rw, $.$ref(() => _rw, ($v) => _rw = $v, $.$$.S.Double)))
                {
                    _rw = 1;
                }
                if (!$.$$.S.Double.TryParse$6(y0, $.$ref(() => _y0, ($v) => _y0 = $v, $.$$.S.Double)))
                {
                    _y0 = 0;
                }
                if (!$.$$.S.Double.TryParse$6(rh, $.$ref(() => _rh, ($v) => _rh = $v, $.$$.S.Double)))
                {
                    _rh = 1;
                }
                /*var*/ let builder = $.$MdeX.LCFCMR.Utility.GetSVG(this, $.$clone(method), parameters, closure, $.$ref(() => parent, ($v) => parent = $v, $.$MdeX.LCFCMR.MarkdownPlusShapeSVGTokenResolver));
                builder.LCFCCSF$ISVGBuilder$MoveTo(_x0, _y0).LCFCCSF$ISVGRectangleBuilder$Rectangle(_rw, _rh);
                if (stroke !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$StrokeColor(stroke);
                }
                if (strokeWidth !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$StrokeWidth($.$$.S.Double.Parse$7(strokeWidth));
                }
                if (fill !== null)
                {
                    builder.LCFCCSF$ISVGBuilder$FillColor(fill);
                }
                if ((parent?.SVG ?? null) === null)
                {
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(builder.LCFCCSF$ISVGBuilder$Build());
                }
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38657101346)
            
            //--TRIMMABLE-BOUNDARY-START(4297362978)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297362978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297362978)
            
            //--TRIMMABLE-BOUNDARY-START(4297362978)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297362978)
            
            static $h = 2395682;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362134050),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772199458,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2395682,
      "h": 34362134050,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362134050),
//--TRIMMABLE-BOUNDARY-START(8592330274),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182264866,
        "f": 50364417
      },
      "n": "Description",
      "d": 2395682,
      "h": 8592330274,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592330274)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067166754),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2395682,
      "h": 30067166754,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067166754),
//--TRIMMABLE-BOUNDARY-START(38657101346),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2395682,
      "h": 38657101346,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657101346)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297362978),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2395682,
      "h": 4297362978,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297362978)
  ],
  "h": 2395682
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusShapeRectangleTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusShapeRectangleTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2395682)
        
        

        //--TRIMMABLE-BOUNDARY-START(2264610)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusShapeLineGraphTokenResolver`, ($self) => class MarkdownPlusShapeLineGraphTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362002978)
            /*string */ get Invocation()
            {
                return "linegraph";
            }
            //--TRIMMABLE-BOUNDARY-END(34362002978)
            
            //--TRIMMABLE-BOUNDARY-START(8592199202)
            /*string */ get Description()
            {
                return "Draw a mathematics line graph.\r\n\r\nExample: ``linegraph``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592199202)
            
            //--TRIMMABLE-BOUNDARY-START(30067035682)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["0", "w"], null, null), "The viewBox width of the svg. Default to 1.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["1", "h"], null, null), "The viewBox height of the svg. Default to 1.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bdc", "s", "stroke"], null, null), "The color of the line");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bdw", "sw", "strokeWidth"], null, null), "The line width");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["bgc", "f", "fill"], null, null), "The fill color");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["i", "initial", "start"], null, null), "The start number");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["n", "count"], null, null), "The number of steps");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["step"], null, null), "The difference between each step number");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["t", "text"], null, null), "Show or hide the text");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067035682)
            
            //--TRIMMABLE-BOUNDARY-START(38656970274)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                /*var*/ let parent;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656970274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let stroke = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bdc", "s", "stroke" ], null, null)) ?? "#00AEFF";
                /*var*/ let strokeWidth = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "bdw", "sw", "strokeWidth" ], null, null));
                /*var*/ let startNumber = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "i", "initial", "start" ], null, null));
                /*var*/ let count = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "n", "count" ], null, null));
                /*var*/ let step = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "step" ], null, null));
                /*var*/ let text = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "t", "text" ], null, null)) !== "0";
                /*int*/ let initial = 1;
                /*int*/ let icount = 10;
                /*int*/ let istep = 1;
                if (!$.$$.S.Int32.TryParse$6(startNumber, $.$ref(() => initial, ($v) => initial = $v, $.$$.S.Int32)))
                {
                    initial = 1;
                }
                if (!$.$$.S.Int32.TryParse$6(count, $.$ref(() => icount, ($v) => icount = $v, $.$$.S.Int32)))
                {
                    icount = 10;
                }
                if (!$.$$.S.Int32.TryParse$6(step, $.$ref(() => istep, ($v) => istep = $v, $.$$.S.Int32)))
                {
                    istep = 1;
                }
                /*var*/ let builder = $.$MdeX.LCFCMR.Utility.GetSVG(this, $.$clone(method), parameters, closure, $.$ref(() => parent, ($v) => parent = $v, $.$MdeX.LCFCMR.MarkdownPlusShapeSVGTokenResolver));
                /*void*/  function Line(/*double*/ x0, /*double*/ y0, /*double*/ x1, /*double*/ y1)
                {
                    builder.LCFCCSF$ISVGBuilder$MoveTo(x0, y0).LCFCCSF$ISVGLineBuilder$LineTo(x1, y1, false);
                    if (stroke !== null)
                    {
                        builder.LCFCCSF$ISVGBuilder$StrokeColor(stroke);
                    }
                    if (strokeWidth !== null)
                    {
                        builder.LCFCCSF$ISVGBuilder$StrokeWidth($.$$.S.Double.Parse$7(strokeWidth));
                    }
                }
                /*void*/  function Text(/*double*/ x0, /*double*/ y0, /*string*/ text)
                {
                    builder.LCFCCSF$ISVGBuilder$MoveTo(x0, y0).LCFCCSF$ISVGTextBuilder$Text(text).LCFCCSF$ISVGBuilder$BaseLine(7/*BaseLine.Hanging*/).LCFCCSF$ISVGBuilder$TextAnchor(2/*TextAnchor.Middle*/);
                    if (stroke !== null)
                    {
                        builder.LCFCCSF$ISVGBuilder$StrokeColor(stroke);
                    }
                    if (strokeWidth !== null)
                    {
                        builder.LCFCCSF$ISVGBuilder$StrokeWidth($.$$.S.Double.Parse$7(strokeWidth));
                    }
                }
                Line.call(this, 0, 0.5, 1, 0.5);
                Line.call(this, 0, 0.5, 0.02, 0.45);
                Line.call(this, 0, 0.5, 0.02, 0.55);
                Line.call(this, 1, 0.5, 0.98, 0.45);
                Line.call(this, 1, 0.5, 0.98, 0.55);
                for(/*int*/ let i = 0; i < icount; i++)
                {
                    Line.call(this, (i / 10) + 0.05, 0.45, (i / 10) + 0.05, 0.55);
                    if (text)
                    {
                        Text.call(this, (i / 10) + 0.05, 0.7, $.$$.S.Int32.ToString.call((((initial + ((i * istep) | 0)) | 0))));
                    }
                }
                if ((parent?.SVG ?? null) === null)
                {
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(builder.LCFCCSF$ISVGBuilder$Build());
                }
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38656970274)
            
            //--TRIMMABLE-BOUNDARY-START(4297231906)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297231906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297231906)
            
            //--TRIMMABLE-BOUNDARY-START(4297231906)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297231906)
            
            static $h = 2264610;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362002978),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772068386,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2264610,
      "h": 34362002978,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362002978),
//--TRIMMABLE-BOUNDARY-START(8592199202),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182133794,
        "f": 50364417
      },
      "n": "Description",
      "d": 2264610,
      "h": 8592199202,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592199202)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067035682),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2264610,
      "h": 30067035682,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067035682),
//--TRIMMABLE-BOUNDARY-START(38656970274),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2264610,
      "h": 38656970274,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656970274)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297231906),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2264610,
      "h": 4297231906,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297231906)
  ],
  "h": 2264610
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusShapeLineGraphTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusShapeLineGraphTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2264610)
        
        

        //--TRIMMABLE-BOUNDARY-START(2919970)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusTextToSpeechResolver`, ($self) => class MarkdownPlusTextToSpeechResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(47247560226)
            /*IClientUnitOfWork*/ unitOfWork = null;
            //--TRIMMABLE-BOUNDARY-END(47247560226)
            
            //--TRIMMABLE-BOUNDARY-START(38657625634)
            /*IMediaPlayer*/ player = null;
            //--TRIMMABLE-BOUNDARY-END(38657625634)
            
            //--TRIMMABLE-BOUNDARY-START(34362658338)
            /*string */ get Invocation()
            {
                return "tts";
            }
            //--TRIMMABLE-BOUNDARY-END(34362658338)
            
            //--TRIMMABLE-BOUNDARY-START(8592854562)
            /*string */ get Description()
            {
                return "Convert the given text to speech, when clicked. \r\n\r\nExample: ``tts(Hello World, g:male)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592854562)
            
            //--TRIMMABLE-BOUNDARY-START(30067691042)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("0", "The text to show and say");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["g", "gender"], null, null), "The gender to use to voice the text. ``male or female``");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067691042)
            
            //--TRIMMABLE-BOUNDARY-START(4297887266)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork, /*IMediaPlayer*/ player)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297887266);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.unitOfWork = unitOfWork;
                    this.player = player;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297887266)
            
            //--TRIMMABLE-BOUNDARY-START(42952592930)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952592930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let text = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                /*var*/ let gender = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "g", "gender" ], null, null));
                /*Gender*/ let g;
                $.$$.S.Enum.TryParse$9($.$fPer.LCFCD.Gender, gender, false, $.$ref(() => g, ($v) => g = $v, $.$fPer.LCFCD.Gender));
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenElement(1, "div");
                    builder.AddAttribute$5(2, "class", "flex");
                    builder.OpenElement(3, "button");
                    builder.AddAttribute$5(4, "class", "bg-transparent bd-0 fsz-30 cl-primary mdi mdi-volume-high mgr");
                    builder.AddAttribute$1(5, "onclick", $.$mac.MAC.EventCallback.Factory.Create$4(this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t2, $r2;
                            ($t2 = closure.Context.SafeExecute$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                            {
                                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                                {
                                    let $t3, $r3;
                                    let $t5, $r5;
                                    /*var*/ let speech = ($t3 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.TextToSpeech(this.unitOfWork.LCFCI$IClientUnitOfWork$Server, (() =>
                                    {
                                        //new $.$vWqU.LCFCCR.TextToSpeechRequest()
                                        const $t4 = $.$vWqU.LCFCCR.TextToSpeechRequest;
                                        const $i4 = new $t4();
                                        $i4.$ctor$2();
                                        $i4.Text = text;
                                        $i4.VoiceGender = g;
                                        return $i4;
                                    })()), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                    /*string?*/ let tts = `data:audio/mpeg;base64,${$.$strNN($.$$.S.Convert.ToBase64String$3(speech.Data))}`;
                                    ($t5 = $.$fPer.LCFCS$3.MediaPlayerExtension.Play(this.player, tts, false, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                                });
                            }, $PRyEkf ??= {"r":178454529,"n":"","d":2919970,"h":0,"f":17829890})), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        });
                    }, $qHEEZb ??= {"r":178454529,"n":"","d":2919970,"h":0,"f":17829890})));
                    builder.CloseElement();
                    builder.OpenElement(2, "span");
                    builder.AddAttribute$5(3, "class", "mgy-a");
                    builder.AddContent$4(4, text);
                    builder.CloseElement();
                    builder.CloseElement();
                }, $nWZjml ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":2919970,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(42952592930)
            
            static $h = 2919970;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362658338),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772723746,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2919970,
      "h": 34362658338,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362658338),
//--TRIMMABLE-BOUNDARY-START(8592854562),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182789154,
        "f": 50364417
      },
      "n": "Description",
      "d": 2919970,
      "h": 8592854562,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592854562)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067691042),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2919970,
      "h": 30067691042,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067691042),
//--TRIMMABLE-BOUNDARY-START(42952592930),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2919970,
      "h": 42952592930,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42952592930)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47247560226),
    {
      "t": 63657642,
      "n": "unitOfWork",
      "d": 2919970,
      "h": 47247560226,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47247560226),
//--TRIMMABLE-BOUNDARY-START(38657625634),
    {
      "t": 61704534,
      "n": "player",
      "d": 2919970,
      "h": 38657625634,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38657625634)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297887266),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        },
        {
          "n": "player",
          "p": 61704534
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2919970,
      "h": 4297887266,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297887266)
  ],
  "h": 2919970
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusTextToSpeechResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusTextToSpeechResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2919970)
        
        

        //--TRIMMABLE-BOUNDARY-START(2854434)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusTextBoxEntryTokenResolver`, ($self) => class MarkdownPlusTextBoxEntryTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(47247494690)
            /*string */ get Invocation()
            {
                return "input";
            }
            //--TRIMMABLE-BOUNDARY-END(47247494690)
            
            //--TRIMMABLE-BOUNDARY-START(12887756322)
            /*string */ get Description()
            {
                return "Allows the user to enter a value.\r\n\r\nExample: ``input``";
            }
            //--TRIMMABLE-BOUNDARY-END(12887756322)
            
            //--TRIMMABLE-BOUNDARY-START(42952527394)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["0", "ph", "placeholder"], null, null), "The placeholder to show");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["1", "f", "focus"], null, null), "Automatically focus into the textbox");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(42952527394)
            
            //--TRIMMABLE-BOUNDARY-START(64427363874)
            /*string?*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(64427363874)
            
            //--TRIMMABLE-BOUNDARY-START(51542461986)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542461986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = $.$EVvT.LCFCM.MarkdownPlusUtility.GetId(parameters);
                /*var*/ let placehoder = $.$EVvT.LCFCM.MarkdownPlusUtility.GetParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "ph", "placeholder" ], null, null));
                /*var*/ let setFocus = $.$EVvT.LCFCM.MarkdownPlusUtility.GetBoolParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "f", "focus" ], null, null)) ?? true;
                /*var*/ let multiline = $.$EVvT.LCFCM.MarkdownPlusUtility.GetBoolParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "ml", "multiline" ], null, null)) ?? false;
                this.Type = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "t", "type" ], null, null));
                if (this.Type === "num" || this.Type === "int")
                {
                    this.Type = "number";
                }
                /*var*/ let onKey = $.$EVvT.LCFCM.MarkdownPlusUtility.GetBoolParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "k", "key" ], null, null)) ?? false;
                if (closure.Context.IsEditor)
                {
                    setFocus = false;
                }
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                if (closure.Context.FontColor !== null)
                {
                    style += `color:${$.$strNN(closure.Context.FontColor)};`;
                }
                if (closure.Context.Font !== null)
                {
                    style += `font-family:${$.$strNN($.$$.SI.Path.GetFileNameWithoutExtension$1(closure.Context.Font))};`;
                }
                if (closure.Context.FontSize !== null)
                {
                    style += `font-size:${$.$strNN(closure.Context.FontSize)};`;
                }
                /*ElementReference*/ let element = new $.$mac.MAC.ElementReference();
                if (setFocus)
                {
                    closure.Context.add_OnAfterRender(new ($.$$.S.EventHandler$$($.$$.S.Boolean))().$ctor(this,  (/**/ s, /*e*/ e) =>
                    {
                        if (element.Id !== null)
                        {
                            $.$macw.MAC.ElementReferenceExtensions.FocusAsync$1(element);
                        }
                    }, $bvEVmf ??= {"r":65537,"p":[{"n":"s","p":131073},{"n":"e","p":262145}],"n":"","d":2854434,"h":0,"f":17825794}));
                }
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    /*var*/ let ans = id !== null ? $.$sl.SL.Enumerable.FirstOrDefault$1($.$fPer.LCFCD.IQueryOption, closure.RootClosure.ChosenAnswers, new ($.$$.S.Func$$$($.$fPer.LCFCD.IQueryOption, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                    {
                        return a.LCFCD$IQueryOption$Option === id;
                    }, $aKCcxd ??= {"r":262145,"p":[{"n":"a","p":21924182}],"n":"","d":2854434,"h":0,"f":17825794})) : $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCD.IQueryOption, closure.RootClosure.ChosenAnswers);
                    builder.OpenElement(1, multiline ? "textarea" : "input");
                    if (!multiline)
                    {
                        builder.AddAttribute$5(2, "type", this.Type ?? "text");
                    }
                    builder.AddAttribute$5(3, "class", "bd-0 bdb bdw-2 bd-primary bg-gray-01 pd-2 fsz-20" + $.$strNN((multiline ? " mawf" : "")));
                    builder.AddAttribute$5(4, "style", style);
                    builder.AddAttribute$4(5, "placeholder", placehoder.Value ?? "Answer here");
                    builder.AddAttribute$5(6, "id", id);
                    builder.AddAttribute$4(7, "value", (ans?.LCFCD$IQueryOption$Value ?? null) ?? (ans?.LCFCD$IQueryOption$Option ?? null));
                    builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 8, onKey ? "oninput" : "onchange", $.$mac.MAC.EventCallback.Factory.Create$8($.$mac.MAC.ChangeEventArgs, this, new ($.$$.S.Action$$($.$mac.MAC.ChangeEventArgs))().$ctor(this,  (/*ChangeEventArgs*/ arg) =>
                    {
                        if (id !== null)
                        {
                            /*var*/ let existings = $.$sl.SL.Enumerable.ToList($.$fPer.LCFCD.IQueryOption, $.$sl.SL.Enumerable.Where($.$fPer.LCFCD.IQueryOption, closure.RootClosure.ChosenAnswers, new ($.$$.S.Func$$$($.$fPer.LCFCD.IQueryOption, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                            {
                                return a.LCFCD$IQueryOption$Option === id;
                            }, $ZCaSol ??= {"r":262145,"p":[{"n":"a","p":21924182}],"n":"","d":2854434,"h":0,"f":17825794})));
                            existings.ForEach(new ($.$$.S.Action$$($.$fPer.LCFCD.IQueryOption))().$ctor(this,  (/*existing*/ existing) =>
                            {
                                return closure.RootClosure.ChosenAnswers.Remove(existing);
                            }, $gWDsse ??= {"r":65537,"p":[{"n":"existing","p":21924182}],"n":"","d":2854434,"h":0,"f":17825794}));
                            /*object?*/ let __ca1__;
                            ((closure.RootClosure)).LCFCM$IMarkdownPlusMarkdownAnswerEditor$SetAnswer$1(id, ((__ca1__ = arg.Value) !== null ? ($.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString) ?? "") : ""), 0);
                        }
                        else 
                        {
                            closure.RootClosure.ChosenAnswers.Clear();
                            /*object?*/ let __ca2__;
                            /*object?*/ let __ca3__;
                            ((closure.RootClosure)).LCFCM$IMarkdownPlusMarkdownAnswerEditor$SetAnswer$1(((__ca2__ = arg.Value) !== null ? ($.$dspc(__ca2__, $.$$.S.Object, ($t) => $t.ToString) ?? "") : ""), ((__ca3__ = arg.Value) !== null ? ($.$dspc(__ca3__, $.$$.S.Object, ($t) => $t.ToString) ?? "") : ""), 0);
                        }
                    }, $oGfRkc ??= {"r":65537,"p":[{"n":"arg","p":1114227}],"n":"","d":2854434,"h":0,"f":17825794})));
                    if (setFocus)
                    {
                        builder.AddElementReferenceCapture(9, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*el*/ el) =>
                        {
                            element = el;
                        }, $mKilQg ??= {"r":65537,"p":[{"n":"el","p":1900659}],"n":"","d":2854434,"h":0,"f":17825794}));
                    }
                    builder.CloseElement();
                }, $jMquJi ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":2854434,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(51542461986)
            
            //--TRIMMABLE-BOUNDARY-START(8592789026)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592789026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592789026)
            
            //--TRIMMABLE-BOUNDARY-START(8592789026)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592789026)
            
            static $h = 2854434;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47247494690),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067625506,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2854434,
      "h": 47247494690,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47247494690),
//--TRIMMABLE-BOUNDARY-START(12887756322),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477690914,
        "f": 50364417
      },
      "n": "Description",
      "d": 2854434,
      "h": 12887756322,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12887756322),
//--TRIMMABLE-BOUNDARY-START(64427363874),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657560098,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132396578,
        "f": 83886082
      },
      "n": "Type",
      "d": 2854434,
      "h": 64427363874,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64427363874)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42952527394),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2854434,
      "h": 42952527394,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42952527394),
//--TRIMMABLE-BOUNDARY-START(51542461986),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2854434,
      "h": 51542461986,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51542461986)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592789026),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2854434,
      "h": 8592789026,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592789026)
  ],
  "h": 2854434
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusTextBoxEntryTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusTextBoxEntryTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2854434)
        
        

        //--TRIMMABLE-BOUNDARY-START(1281570)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusDraggableTokenResolver`, ($self) => class MarkdownPlusDraggableTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(64425791010)
            /*IJavaScriptRunner*/ javascript = null;
            //--TRIMMABLE-BOUNDARY-END(64425791010)
            
            //--TRIMMABLE-BOUNDARY-START(60130823714)
            /*string */ get Invocation()
            {
                return "draggable";
            }
            //--TRIMMABLE-BOUNDARY-END(60130823714)
            
            //--TRIMMABLE-BOUNDARY-START(8591216162)
            /*string */ get Description()
            {
                return "Make an element draggable with the mouse.\r\n\r\nExample: ``draggable(object(icon(circle)))``";
            }
            //--TRIMMABLE-BOUNDARY-END(8591216162)
            
            //--TRIMMABLE-BOUNDARY-START(51540889122)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("-1", "The element that can be dragged");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(51540889122)
            
            //--TRIMMABLE-BOUNDARY-START(4296248866)
            $ctor$2(/*IJavaScriptRunner*/ javascript)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296248866);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.javascript = javascript;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296248866)
            
            //--TRIMMABLE-BOUNDARY-START(73015725602)
            /*Dictionary<string, MarkdownPlusToken>?*/ parameters = null;
            //--TRIMMABLE-BOUNDARY-END(73015725602)
            
            //--TRIMMABLE-BOUNDARY-START(12886183458)
            /*object?*/ draggableElementId = null;
            //--TRIMMABLE-BOUNDARY-END(12886183458)
            
            //--TRIMMABLE-BOUNDARY-START(55835856418)
            /*string? */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066052642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca1__;
                return _ = ((__ca1__ = this.draggableElementId) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(55835856418)
            
            //--TRIMMABLE-BOUNDARY-START(77310692898)
            /*Dictionary<string, MarkdownPlusToken>? */ get Parameters()
            {
                return this.parameters;
            }
            //--TRIMMABLE-BOUNDARY-END(77310692898)
            
            //--TRIMMABLE-BOUNDARY-START(68720758306)
            /*ValueTask */ OnDragTo(/*ElementReference*/ draggableElement, /*string*/ draggableElementId, /*float*/ dx, /*float*/ dy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720758306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(68720758306)
            
            //--TRIMMABLE-BOUNDARY-START(81605660194)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605660194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.parameters = parameters;
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                this.draggableElementId = $.$EVvT.LCFCM.MarkdownPlusUtility.GetId(parameters) ?? $.$fPer.LCFCS$6.StringExtension.GetRandomString(16, true, true, false);
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                {
                    /*ElementReference*/ let element = new $.$mac.MAC.ElementReference();
                    closure.Context.add_OnAfterRender(new ($.$$.S.EventHandler$$($.$$.S.Boolean))().$ctor(this,  (/*s*/ s, /*e*/ e) =>
                    {
                        if (e && element.Id !== null)
                        {
                            $.$hDPm.LCFCCD$7.DraggableExtension.Draggable(this.javascript, this, 3/*DraggableFeatures.DragXY*/ | 4/*DraggableFeatures.SetDragHandlePosition*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCCD$7.Draggabble), [ (() =>
                            {
                                //new $.$hDPm.LCFCCD$7.Draggabble()
                                const $t2 = $.$hDPm.LCFCCD$7.Draggabble;
                                const $i2 = new $t2();
                                $i2.$ctor$2();
                                $i2.DragHandle = element;
                                $i2.DragPosition = element;
                                $i2.DragConstraint = closure.Context.RenderingContainer !== null ? $.$cast(closure.Context.RenderingContainer, $.$mac.MAC.ElementReference) : new $.$mac.MAC.ElementReference();
                                return $i2;
                            })() ], null, null));
                        }
                    }, $YvXrUb ??= {"r":65537,"p":[{"n":"s","p":131073},{"n":"e","p":262145}],"n":"","d":1281570,"h":0,"f":17825794}));
                    /*var*/ let answer = $.$sl.SL.Enumerable.FirstOrDefault$1($.$fPer.LCFCD.IQueryOption, closure.RootClosure.ChosenAnswers, new ($.$$.S.Func$$$($.$fPer.LCFCD.IQueryOption, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                    {
                        return a.LCFCD$IQueryOption$Option === $.$dspc(this.draggableElementId, $.$$.S.Object, ($t) => $t.ToString);
                    }, $qksjKe ??= {"r":262145,"p":[{"n":"a","p":21924182}],"n":"","d":1281570,"h":0,"f":17825794}));
                    /*var*/ let draggedOut = (answer?.LCFCD$IQueryOption$Option ?? null) !== null;
                    /*LivingThing.Core.Frameworks.Common.Data.IQueryOption?*/ let __ca2__;
                    /*var*/ let droppedOn = ((__ca2__ = answer) !== null ? $.$fPer.LCFCP$1.PropertyExtension.GetAttachedProperty($.$MdeX.LCFCMR.MarkdownPlusDroppableTokenResolver, __ca2__, "droppable") : null);
                    /*bool*/ let positionDraggedOutItem = draggedOut && (droppedOn?.DropMode ?? null) === 0/*DroppableItemMode.None*/;
                    builder.OpenElement(1, "div");
                    builder.AddAttribute$5(2, "class", `flex miwx-07 mihx-07 bd bdw-2 corner bd-${$.$strNN((draggedOut ? "primary" : "gray"))}`);
                    builder.AddAttribute$5(3, "style", style);
                    if (droppedOn === null || droppedOn.DropMode === 0/*DroppableItemMode.None*/ || droppedOn.DropMode === 2/*DroppableItemMode.Clone*/)
                    {
                        builder.AddContent$1(4, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                        {
                            builder.OpenElement(1, "div");
                            builder.AddAttribute$5(2, "draggable", "true");
                            builder.AddAttribute$4(3, "id", this.draggableElementId);
                            if (positionDraggedOutItem)
                            {
                                builder.AddAttribute$5(4, "style", `position:absolute;left:${$.$strNN($.$dspc($.$fPer.LCFCP$1.PropertyExtension.GetAttachedProperty($.$$.S.Object, answer, "x"), $.$$.S.Object, ($t) => $t.ToString))}px;top:${$.$strNN($.$dspc($.$fPer.LCFCP$1.PropertyExtension.GetAttachedProperty($.$$.S.Object, answer, "y"), $.$$.S.Object, ($t) => $t.ToString))}px`);
                                builder.AddAttribute$5(5, "class", "pos-rel animate");
                            }
                            else 
                            {
                                builder.AddAttribute$5(5, "class", "mg-a");
                            }
                            builder.AddElementReferenceCapture(3, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*e*/ e) =>
                            {
                                element = e;
                            }, $OjsZib ??= {"r":65537,"p":[{"n":"e","p":1900659}],"n":"","d":1281570,"h":0,"f":17825794}));
                            if (positionDraggedOutItem)
                            {
                                builder.OpenElement(10, "i");
                                builder.AddAttribute$5(11, "class", "clickable, pos-abs r-0 t-0 mdi mdi-delete cl-error fade-in-hover");
                                builder.AddAttribute$1(12, "onclick", $.$mac.MAC.EventCallback.Factory.Create$1(this, new $.$$.S.Action().$ctor(this,  () =>
                                {
                                    closure.RootClosure.ChosenAnswers.Remove(answer);
                                }, $KSdxml ??= {"r":65537,"n":"","d":1281570,"h":0,"f":17825794})));
                                builder.CloseElement();
                            }
                            let $en3 = parameters.GetEnumerator();
                            while ($en3.MoveNext())
                            {
                                let parameter = $en3.Current;
                                {
                                    if (parameter.Key !== "id")
                                    {
                                        $.$MdeX.LCFCMR.Utility.AddParameter(builder, parameter.Value, null);
                                    }
                                }
                            }
                            builder.CloseElement();
                        }, $ERMPSd ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1281570,"h":0,"f":17825794}));
                    }
                    builder.CloseElement();
                }, $ptfZfb ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1281570,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(81605660194)
            
            //--TRIMMABLE-BOUNDARY-START(4317009578)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Draggable.IDraggableComponent.OnDragTo(Microsoft.AspNetCore.Components.ElementReference, string, float, float)
            LCFCCD$7$IDraggableComponent$OnDragTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4317009578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnDragTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4317009578)
            
            static $h = 1281570;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130823714),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655987234,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1281570,
      "h": 60130823714,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130823714),
//--TRIMMABLE-BOUNDARY-START(8591216162),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476118050,
        "f": 50364417
      },
      "n": "Description",
      "d": 1281570,
      "h": 8591216162,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591216162),
//--TRIMMABLE-BOUNDARY-START(55835856418),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066052642,
        "f": 50331649
      },
      "n": "Id",
      "d": 1281570,
      "h": 55835856418,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835856418),
//--TRIMMABLE-BOUNDARY-START(77310692898),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245921826,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 1281570,
      "h": 77310692898,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310692898)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540889122),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1281570,
      "h": 51540889122,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540889122),
//--TRIMMABLE-BOUNDARY-START(68720758306),
    {
      "r": 181338113,
      "p": [
        {
          "n": "draggableElement",
          "p": 1900659
        },
        {
          "n": "draggableElementId",
          "p": 1310721
        },
        {
          "n": "dx",
          "p": 1114113
        },
        {
          "n": "dy",
          "p": 1114113
        }
      ],
      "n": "OnDragTo",
      "d": 1281570,
      "h": 68720758306,
      "f": 16777217,
      "a": [
        {
          "t": 2818162,
          "c": 8592752754
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720758306),
//--TRIMMABLE-BOUNDARY-START(81605660194),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1281570,
      "h": 81605660194,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605660194)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64425791010),
    {
      "t": 64509610,
      "n": "javascript",
      "d": 1281570,
      "h": 64425791010,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425791010),
//--TRIMMABLE-BOUNDARY-START(73015725602),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h,
      "n": "parameters",
      "d": 1281570,
      "h": 73015725602,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015725602),
//--TRIMMABLE-BOUNDARY-START(12886183458),
    {
      "t": 131073,
      "n": "draggableElementId",
      "d": 1281570,
      "h": 12886183458,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886183458)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296248866),
    {
      "p": [
        {
          "n": "javascript",
          "p": 64509610
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1281570,
      "h": 4296248866,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296248866)
  ],
  "h": 1281570
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable, $.$hDPm.LCFCCD$7.IDraggableComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusDraggableTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusDraggableTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1281570)
        
        

        //--TRIMMABLE-BOUNDARY-START(1347106)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusDroppableTokenResolver`, ($self) => class MarkdownPlusDroppableTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(64425856546)
            /*IJavaScriptRunner*/ javascript = null;
            //--TRIMMABLE-BOUNDARY-END(64425856546)
            
            //--TRIMMABLE-BOUNDARY-START(60130889250)
            /*string */ get Invocation()
            {
                return "droppable";
            }
            //--TRIMMABLE-BOUNDARY-END(60130889250)
            
            //--TRIMMABLE-BOUNDARY-START(17181216290)
            /*string */ get Description()
            {
                return "Make an container that can accept content from a draggable.\r\n\r\nExample: ``droppable(w:100,h:100)``";
            }
            //--TRIMMABLE-BOUNDARY-END(17181216290)
            
            //--TRIMMABLE-BOUNDARY-START(55835921954)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("md", "The dropping mode. To move the item from the draggable to this use ``md:move``, clone with ``md:clone``");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(55835921954)
            
            //--TRIMMABLE-BOUNDARY-START(8591281698)
            $ctor$2(/*IJavaScriptRunner*/ javascript)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591281698);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.javascript = javascript;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591281698)
            
            //--TRIMMABLE-BOUNDARY-START(21476183586)
            /*DroppableItemMode*/ DropMode = 0;
            //--TRIMMABLE-BOUNDARY-END(21476183586)
            
            //--TRIMMABLE-BOUNDARY-START(12886248994)
            /*MarkdownPlusTokenResolverClosure?*/ closure = null;
            //--TRIMMABLE-BOUNDARY-END(12886248994)
            
            //--TRIMMABLE-BOUNDARY-START(25771150882)
            /*Dictionary<MarkdownPlusDraggableTokenResolver, List<QueryOption>>*/ droppedDraggables = null;
            //--TRIMMABLE-BOUNDARY-END(25771150882)
            
            //--TRIMMABLE-BOUNDARY-START(68720823842)
            /*ValueTask */ OnDrop(/*ElementReference*/ droppableElement, /*string*/ draggableElementId, /*float*/ x, /*float*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720823842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let draggable = $.$cast($.$sl.SL.Enumerable.FirstOrDefault$1($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, this.closure.RootClosure.NestedResolvers, new ($.$$.S.Func$$$($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                {
                    let resolver;
                    return $.$is(r, $.$MdeX.LCFCMR.MarkdownPlusDraggableTokenResolver, { set $v($v){ resolver = $v; } }) && resolver.Id === draggableElementId;
                }, $nDQhkb ??= {"r":262145,"p":[{"n":"r","p":624892}],"n":"","d":1347106,"h":0,"f":17825794})), $.$MdeX.LCFCMR.MarkdownPlusDraggableTokenResolver);
                /*var*/ let answer = (() =>
                {
                    //new $.$fPer.LCFCD.QueryOption()
                    const $t1 = $.$fPer.LCFCD.QueryOption;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Option = draggableElementId;
                    $i1.set_Item$1("x", $.$box(x, $.$$.S.Single));
                    $i1.set_Item$1("y", $.$box(y, $.$$.S.Single));
                    $i1.set_Item$1("droppable", this);
                    return $i1;
                })();
                ((this.closure.RootClosure)).LCFCM$IMarkdownPlusMarkdownAnswerEditor$SetAnswer($.$clone(answer));
                if (draggable !== null && this.DropMode !== 0/*DroppableItemMode.None*/)
                {
                    /*var*/ let list;
                    if (!this.droppedDraggables.TryGetValue(draggable, $.$ref(() => list, ($v) => list = $v, $.$$.SCG.List$$($.$fPer.LCFCD.QueryOption))))
                    {
                        list = new ($.$$.SCG.List$$($.$fPer.LCFCD.QueryOption))().$ctor$1();
                        this.droppedDraggables.set_Item(draggable, list);
                    }
                    list.Add($.$clone(answer));
                }
                this.closure.Context.RequestRendering();
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(68720823842)
            
            //--TRIMMABLE-BOUNDARY-START(73015791138)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015791138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.closure = closure;
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*var*/ let move = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "md", "mode" ], null, null));
                this.DropMode = move === "clone" ? 2/*DroppableItemMode.Clone*/ : move === "move" ? 1/*DroppableItemMode.Move*/ : 0/*DroppableItemMode.None*/;
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    /*ElementReference*/ let element = new $.$mac.MAC.ElementReference();
                    closure.Context.add_OnAfterRender(new ($.$$.S.EventHandler$$($.$$.S.Boolean))().$ctor(this,  (/*s*/ s, /*e*/ e) =>
                    {
                        if (e && element.Id !== null)
                        {
                            $.$hDPm.LCFCCD$7.DraggableExtension.Droppable(this.javascript, this, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mac.MAC.ElementReference), [ element ], null, null));
                        }
                    }, $eANPcg ??= {"r":65537,"p":[{"n":"s","p":131073},{"n":"e","p":262145}],"n":"","d":1347106,"h":0,"f":17825794}));
                    builder.OpenElement(1, "div");
                    builder.AddAttribute$2(2, "droppable", true);
                    builder.AddAttribute$5(3, "style", style);
                    builder.AddElementReferenceCapture(4, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*e*/ e) =>
                    {
                        element = e;
                    }, $gwplTe ??= {"r":65537,"p":[{"n":"e","p":1900659}],"n":"","d":1347106,"h":0,"f":17825794}));
                    $.$MdeX.LCFCMR.Utility.AddParameters(builder, parameters);
                    if (this.DropMode !== 0/*DroppableItemMode.None*/ && $.$sl.SL.Enumerable.Count$1($.$fPer.LCFCD.QueryOption, $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.List$$($.$fPer.LCFCD.QueryOption), $.$fPer.LCFCD.QueryOption, this.droppedDraggables.Values, new ($.$$.S.Func$$$($.$$.SCG.List$$($.$fPer.LCFCD.QueryOption), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.QueryOption)))().$ctor(this,  (/*v*/ v) =>
                    {
                        return v;
                    }, $PfgAeb ??= {"r":$.$$.SCG.IEnumerable$$($.$fPer.LCFCD.QueryOption).$h,"p":[{"n":"v","p":$.$$.SCG.List$$($.$fPer.LCFCD.QueryOption).$h}],"n":"","d":1347106,"h":0,"f":17825794}))) > 0)
                    {
                        builder.OpenElement(15, "div");
                        builder.AddAttribute$5(16, "class", "grid colm-07");
                        let $en3 = this.droppedDraggables.GetEnumerator();
                        while ($en3.MoveNext())
                        {
                            let draggable = $en3.Current;
                            {
                                if (draggable.Key.Parameters !== null)
                                {
                                    let $en4 = draggable.Value.GetEnumerator();
                                    while ($en4.MoveNext())
                                    {
                                        let answer = $en4.Current;
                                        {
                                            builder.OpenElement(18, "div");
                                            builder.AddAttribute$5(19, "class", "pos-rel animate");
                                            builder.OpenElement(20, "i");
                                            builder.AddAttribute$5(21, "class", "clickable pos-abs r-0 t-0 mdi mdi-delete cl-error fade-in-hover");
                                            builder.AddAttribute$1(22, "onclick", $.$mac.MAC.EventCallback.Factory.Create$1(this, new $.$$.S.Action().$ctor(this,  () =>
                                            {
                                                closure.RootClosure.ChosenAnswers.Remove($.$clone(answer));
                                                draggable.Value.Remove($.$clone(answer));
                                            }, $QgJIZk ??= {"r":65537,"n":"","d":1347106,"h":0,"f":17825794})));
                                            builder.CloseElement();
                                            $.$MdeX.LCFCMR.Utility.AddParameters(builder, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), draggable.Key.Parameters, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                                            {
                                                return $.$is(e.Value.Value, $.$mac.MAC.RenderFragment);
                                            }, $qUEKUj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h}],"n":"","d":1347106,"h":0,"f":17825794})));
                                            builder.CloseElement();
                                        }
                                    }
                                }
                            }
                        }
                        builder.CloseElement();
                    }
                    builder.CloseElement();
                }, $EOzABe ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1347106,"h":0,"f":17825794});
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(73015791138)
            
            //--TRIMMABLE-BOUNDARY-START(4317075114)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Draggable.IDroppableComponent.OnDrop(Microsoft.AspNetCore.Components.ElementReference, string, float, float)
            LCFCCD$7$IDroppableComponent$OnDrop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4317075114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnDrop(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4317075114)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25771150882)
                this.droppedDraggables = new ($.$$.SCG.Dictionary$$$($.$MdeX.LCFCMR.MarkdownPlusDraggableTokenResolver, $.$$.SCG.List$$($.$fPer.LCFCD.QueryOption)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(25771150882)
                
            }
            static $h = 1347106;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130889250),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540954658,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 1347106,
      "h": 60130889250,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130889250),
//--TRIMMABLE-BOUNDARY-START(17181216290),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361085474,
        "f": 50364417
      },
      "n": "Description",
      "d": 1347106,
      "h": 17181216290,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17181216290),
//--TRIMMABLE-BOUNDARY-START(21476183586),
    {
      "p": 822818,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951020066,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605725730,
        "f": 83886082
      },
      "n": "DropMode",
      "d": 1347106,
      "h": 21476183586,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476183586)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835921954),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1347106,
      "h": 55835921954,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835921954),
//--TRIMMABLE-BOUNDARY-START(68720823842),
    {
      "r": 181338113,
      "p": [
        {
          "n": "droppableElement",
          "p": 1900659
        },
        {
          "n": "draggableElementId",
          "p": 1310721
        },
        {
          "n": "x",
          "p": 1114113
        },
        {
          "n": "y",
          "p": 1114113
        }
      ],
      "n": "OnDrop",
      "d": 1347106,
      "h": 68720823842,
      "f": 16777217,
      "a": [
        {
          "t": 2818162,
          "c": 8592752754
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720823842),
//--TRIMMABLE-BOUNDARY-START(73015791138),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1347106,
      "h": 73015791138,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015791138)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64425856546),
    {
      "t": 64509610,
      "n": "javascript",
      "d": 1347106,
      "h": 64425856546,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425856546),
//--TRIMMABLE-BOUNDARY-START(12886248994),
    {
      "t": 1673468,
      "n": "closure",
      "d": 1347106,
      "h": 12886248994,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886248994),
//--TRIMMABLE-BOUNDARY-START(25771150882),
    {
      "t": $.$$.SCG.Dictionary$$$($.$MdeX.LCFCMR.MarkdownPlusDraggableTokenResolver, $.$$.SCG.List$$($.$fPer.LCFCD.QueryOption)).$h,
      "n": "droppedDraggables",
      "d": 1347106,
      "h": 25771150882,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771150882)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591281698),
    {
      "p": [
        {
          "n": "javascript",
          "p": 64509610
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1347106,
      "h": 8591281698,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591281698)
  ],
  "h": 1347106
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable, $.$hDPm.LCFCCD$7.IDroppableComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusDroppableTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusDroppableTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1347106)
        
        

        //--TRIMMABLE-BOUNDARY-START(2592290)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver`, ($self) => class MarkdownPlusSortableTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(47247232546)
            /*IJavaScriptRunner*/ javascript = null;
            //--TRIMMABLE-BOUNDARY-END(47247232546)
            
            //--TRIMMABLE-BOUNDARY-START(42952265250)
            /*string */ get Invocation()
            {
                return "sortable";
            }
            //--TRIMMABLE-BOUNDARY-END(42952265250)
            
            //--TRIMMABLE-BOUNDARY-START(12887494178)
            /*string */ get Description()
            {
                return "Allows to rearrange contents.\r\n\r\nExample: ``sortable(1,2,3,4)``";
            }
            //--TRIMMABLE-BOUNDARY-END(12887494178)
            
            //--TRIMMABLE-BOUNDARY-START(38657297954)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("dir", "The sorting direction v/h.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("-1", "Contents to sort");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(38657297954)
            
            //--TRIMMABLE-BOUNDARY-START(4297559586)
            $ctor$2(/*IJavaScriptRunner*/ javascript)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297559586);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.javascript = javascript;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297559586)
            
            //--TRIMMABLE-BOUNDARY-START(2657826)
            static $_SortableOrder;
            static get SortableOrder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2657826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver;
                return $cls.$_SortableOrder ??= $asm.$ncls(`$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder`, ($self) => class SortableOrder extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(90196971042)
                    /*string*/ Id = null;
                    //--TRIMMABLE-BOUNDARY-END(90196971042)
                    
                    //--TRIMMABLE-BOUNDARY-START(163211415074)
                    /*object?*/ View = null;
                    //--TRIMMABLE-BOUNDARY-END(163211415074)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362396194)
                    /*ElementReference*/ Element;
                    //--TRIMMABLE-BOUNDARY-END(34362396194)
                    
                    //--TRIMMABLE-BOUNDARY-START(94491938338)
                    /*int*/ Order = 0;
                    //--TRIMMABLE-BOUNDARY-END(94491938338)
                    
                    //--TRIMMABLE-BOUNDARY-START(98786905634)
                    /*double*/ ReferenceX = 0;
                    //--TRIMMABLE-BOUNDARY-END(98786905634)
                    
                    //--TRIMMABLE-BOUNDARY-START(103081872930)
                    /*double*/ ReferenceY = 0;
                    //--TRIMMABLE-BOUNDARY-END(103081872930)
                    
                    //--TRIMMABLE-BOUNDARY-START(158916447778)
                    /*string */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(158916447778);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return `${$.$strNN(this.Order)}, ${$.$strNN(this.ReferenceX)}, ${$.$strNN(this.ReferenceY)}, ${$.$strNN(this.Id)},`;
                    }
                    //--TRIMMABLE-BOUNDARY-END(158916447778)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067428898)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067428898);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067428898)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067428898)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067428898)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(34362396194)
                        this.Element = $.$default($.$mac.MAC.ElementReference);
                        //--TRIMMABLE-BOUNDARY-END(34362396194)
                        
                    }
                    static $h = 2657826;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90196971042),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542265378,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120261742114,
        "f": 83886081
      },
      "n": "Id",
      "d": 2657826,
      "h": 90196971042,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196971042),
//--TRIMMABLE-BOUNDARY-START(163211415074),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85902003746,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154621480482,
        "f": 83886081
      },
      "n": "View",
      "d": 2657826,
      "h": 163211415074,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163211415074),
//--TRIMMABLE-BOUNDARY-START(34362396194),
    {
      "p": 1900659,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952330786,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111671807522,
        "f": 83886081
      },
      "n": "Element",
      "d": 2657826,
      "h": 34362396194,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362396194),
//--TRIMMABLE-BOUNDARY-START(94491938338),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132199970,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128851676706,
        "f": 83886081
      },
      "n": "Order",
      "d": 2657826,
      "h": 94491938338,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94491938338),
//--TRIMMABLE-BOUNDARY-START(98786905634),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722134562,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137441611298,
        "f": 83886081
      },
      "n": "ReferenceX",
      "d": 2657826,
      "h": 98786905634,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98786905634),
//--TRIMMABLE-BOUNDARY-START(103081872930),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77312069154,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146031545890,
        "f": 83886081
      },
      "n": "ReferenceY",
      "d": 2657826,
      "h": 103081872930,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103081872930)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(158916447778),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2657826,
      "h": 158916447778,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158916447778)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30067428898),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2657826,
      "h": 30067428898,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067428898)
  ],
  "d": 2592290,
  "h": 2657826
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusSortableTokenResolver+SortableOrder`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusSortableTokenResolver${separator}SortableOrder`; }
                }, $cls, ($v) => $cls.$_SortableOrder = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2657826)
            
            //--TRIMMABLE-BOUNDARY-START(8592526882)
            /*MarkdownPlusTokenResolverClosure?*/ closure = null;
            //--TRIMMABLE-BOUNDARY-END(8592526882)
            
            //--TRIMMABLE-BOUNDARY-START(85901938210)
            /*ElementReference*/ wrapper;
            //--TRIMMABLE-BOUNDARY-END(85901938210)
            
            //--TRIMMABLE-BOUNDARY-START(73017036322)
            /*SortableOrder[]*/ sortings = null;
            //--TRIMMABLE-BOUNDARY-END(73017036322)
            
            //--TRIMMABLE-BOUNDARY-START(17182461474)
            /*string?*/ draggingElementId = null;
            //--TRIMMABLE-BOUNDARY-END(17182461474)
            
            //--TRIMMABLE-BOUNDARY-START(77312003618)
            /*void */ UpdateAnswer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312003618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ordered = $.$$.S.String.Join$5("", $.$sl.SL.Enumerable.Select$1($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, $.$$.S.String, this.sortings, new ($.$$.S.Func$$$($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                {
                    return $.$sl.SL.Enumerable.Last$1($.$$.S.String, $.$$.S.String.Split$1.call(s.Id, /*/*/ 47, 0));
                }, $EotFvd ??= {"r":1310721,"p":[{"n":"s","p":2657826}],"n":"","d":2592290,"h":0,"f":17825794})));
                this.closure.RootClosure.ChosenAnswers.Clear();
                ((this.closure.RootClosure)).LCFCM$IMarkdownPlusMarkdownAnswerEditor$SetAnswer((() =>
                {
                    //new $.$fPer.LCFCD.QueryOption()
                    const $t1 = $.$fPer.LCFCD.QueryOption;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Option = ordered;
                    $i1.Value = ordered;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(77312003618)
            
            //--TRIMMABLE-BOUNDARY-START(60132134434)
            /*ValueTask */ OnDragTo(/*ElementReference*/ draggableElement, /*string*/ draggableElementId, /*float*/ dx, /*float*/ dy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132134434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.draggingElementId = draggableElementId;
                /*var*/ let index = $.$$.S.Int32.Parse$7($.$sl.SL.Enumerable.Last$1($.$$.S.String, $.$$.S.String.Split$1.call(draggableElementId, /*/*/ 47, 0)));
                /*var*/ let target = $.$$.System.Array.$ReadT1.call(this.sortings, index);
                /*var*/ let x = target.ReferenceX + dx;
                /*var*/ let y = target.ReferenceY + dy;
                /*var*/ let targetBefore = $.$sl.SL.Enumerable.MaxBy$1($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, $.$$.S.Double, $.$sl.SL.Enumerable.Where($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, this.sortings, new ($.$$.S.Func$$$($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, $.$$.S.Boolean))().$ctor(this,  (/**/ o) =>
                {
                    return o !== target && o.ReferenceX < x;
                }, $SFkvSb ??= {"r":262145,"p":[{"n":"o","p":2657826}],"n":"","d":2592290,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, $.$$.S.Double))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.ReferenceX;
                }, $JlTBfl ??= {"r":1179649,"p":[{"n":"o","p":2657826}],"n":"","d":2592290,"h":0,"f":17825794}));
                /*var*/ let targetAfter = $.$sl.SL.Enumerable.MinBy$1($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, $.$$.S.Double, $.$sl.SL.Enumerable.Where($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, this.sortings, new ($.$$.S.Func$$$($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, $.$$.S.Boolean))().$ctor(this,  (/*o*/ o) =>
                {
                    return o !== target && o.ReferenceX > x;
                }, $KHJnqa ??= {"r":262145,"p":[{"n":"o","p":2657826}],"n":"","d":2592290,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, $.$$.S.Double))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.ReferenceX;
                }, $lgcJni ??= {"r":1179649,"p":[{"n":"o","p":2657826}],"n":"","d":2592290,"h":0,"f":17825794}));
                /*var*/ let items = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder), null, [this.sortings.length], null);
                /*int*/ let where = 0;
                if (targetBefore === null && targetAfter === null)
                {
                    $.$$.System.Array.$WriteT1.call(items, target, where++);
                }
                /*bool*/ let targetPlaced = false;
                let $i2 = 0;
                let $arr2 = this.sortings;
                while ($i2 < $arr2.length)
                {
                    let item = $arr2[$i2++];
                    if (targetBefore !== null && item === targetBefore)
                    {
                        $.$$.System.Array.$WriteT1.call(items, targetBefore, where++);
                        if (!targetPlaced)
                        {
                            $.$$.System.Array.$WriteT1.call(items, target, where++);
                        }
                        targetPlaced = true;
                    }
                    else if (targetAfter !== null && item === targetAfter)
                    {
                        if (!targetPlaced)
                        {
                            $.$$.System.Array.$WriteT1.call(items, target, where++);
                        }
                        targetPlaced = true;
                        $.$$.System.Array.$WriteT1.call(items, targetAfter, where++);
                    }
                    else if (item !== target && item !== targetBefore && item !== targetAfter)
                    {
                        $.$$.System.Array.$WriteT1.call(items, item, where++);
                    }
                }
                this.sortings = items;
                this.UpdateAnswer();
                this.closure.Context.RequestRendering();
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(60132134434)
            
            //--TRIMMABLE-BOUNDARY-START(64427101730)
            /*ValueTask */ OnDrop(/*ElementReference*/ droppableElement, /*string*/ draggableElementId, /*float*/ x, /*float*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427101730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateOffsetFromDOM();
            }
            //--TRIMMABLE-BOUNDARY-END(64427101730)
            
            //--TRIMMABLE-BOUNDARY-START(81606970914)
            /*ValueTask *//*async*/  UpdateOffsetFromDOM()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81606970914);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let wrapperBox = ($t3 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.Get($.$vWqU.LCFCC.BoxSize, this.javascript, "return this.getBoundingClientRect()", this.wrapper), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    /*var*/ let boxes = ($t4 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.Get($.$typeArray($.$vWqU.LCFCC.BoxSize), this.javascript, "return this.map(function(t){return t.getBoundingClientRect()})", $.$sl.SL.Enumerable.Select$1($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, $.$mac.MAC.ElementReference, this.sortings, new ($.$$.S.Func$$$($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, $.$mac.MAC.ElementReference))().$ctor(this,  (/*o*/ o) =>
                    {
                        return o.Element;
                    }, $RYkCDh ??= {"r":1900659,"p":[{"n":"o","p":2657826}],"n":"","d":2592290,"h":0,"f":17825794}))), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    /*int*/ let i = 0;
                    let $i5 = 0;
                    let $arr5 = boxes;
                    while ($i5 < $arr5.length)
                    {
                        let box = $arr5[$i5++];
                        $.$sl.SL.Enumerable.ElementAt$1($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, this.sortings, i).ReferenceX = (box.Left - wrapperBox.Left) + box.Width / 2;
                        $.$sl.SL.Enumerable.ElementAt$1($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, this.sortings, i).ReferenceY = (box.Top - wrapperBox.Top) + box.Height / 2;
                        i++;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(81606970914)
            
            //--TRIMMABLE-BOUNDARY-START(51542199842)
            /*void */ MoveLeft(/*SortableOrder*/ sort)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542199842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = $.$$.S.Array.IndexOf$5($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, this.sortings, sort);
                if (index > 0)
                {
                    /*var*/ let temp = $.$$.System.Array.$ReadT1.call(this.sortings, ((index - 1) | 0));
                    $.$$.System.Array.$WriteT1.call(this.sortings, sort, ((index - 1) | 0));
                    $.$$.System.Array.$WriteT1.call(this.sortings, temp, index);
                    this.UpdateAnswer();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51542199842)
            
            //--TRIMMABLE-BOUNDARY-START(55837167138)
            /*void */ MoveRight(/*SortableOrder*/ sort)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837167138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let index = $.$$.S.Array.IndexOf$5($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, this.sortings, sort);
                if (index < ((this.sortings.length - 1) | 0))
                {
                    /*var*/ let temp = $.$$.System.Array.$ReadT1.call(this.sortings, ((index + 1) | 0));
                    $.$$.System.Array.$WriteT1.call(this.sortings, sort, ((index + 1) | 0));
                    $.$$.System.Array.$WriteT1.call(this.sortings, temp, index);
                    this.UpdateAnswer();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55837167138)
            
            //--TRIMMABLE-BOUNDARY-START(68722069026)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722069026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.closure = closure;
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*var*/ let dir = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "dir" ], null, null));
                /*var*/ let separator = $.$EVvT.LCFCM.MarkdownPlusUtility.GetSeparator(parameters);
                /*IEnumerable<MarkdownPlusToken>*/ let values = parameters.Values;
                let en;
                if (parameters.Count === 1 && $.$is($.$sl.SL.Enumerable.Single$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), parameters).Value.Value, $.$$.SC$1.IEnumerable, { set $v($v){ en = $v; } }))
                {
                    values = $.$sl.SL.Enumerable.Select$1($.$$.S.Object, $.$EVvT.LCFCM.MarkdownPlusToken, $.$sl.SL.Enumerable.Cast($.$$.S.Object, en), new ($.$$.S.Func$$$($.$$.S.Object, $.$EVvT.LCFCM.MarkdownPlusToken))().$ctor(this,  (/*c*/ c) =>
                    {
                        return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(c);
                    }, $zfKNVb ??= {"r":1411324,"p":[{"n":"c","p":131073}],"n":"","d":2592290,"h":0,"f":17825794}));
                }
                this.sortings = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder), null, [$.$sl.SL.Enumerable.Count$1($.$EVvT.LCFCM.MarkdownPlusToken, values)], null);
                /*int*/ let i = 0;
                /*var*/ let id = $.$fPer.LCFCS$6.StringExtension.GetRandomString(16, true, true, false);
                let $en6 = values.SCG$IEnumerable$$$GetEnumerator();
                while ($en6.SC$1$IEnumerator$MoveNext())
                {
                    let parameter = $en6.SCG$IEnumerator$$$Current;
                    {
                        $.$$.System.Array.$WriteT1.call(this.sortings, (() =>
                        {
                            //new $.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder()
                            const $t7 = $.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder;
                            const $i7 = new $t7();
                            $i7.$ctor$1();
                            $i7.Id = ($.$strNN(id) + "/" + ($.$box(parameter.Order !== null ? $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(parameter.Order) : (((i + 1) | 0)), $.$$.S.Int32)));
                            $i7.View = $.$clone(parameter);
                            return $i7;
                        })(), i);
                        i++;
                    }
                }
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    closure.Context.add_OnAfterRender(new ($.$$.S.EventHandler$$($.$$.S.Boolean))().$ctor(this, /*async*/  (/*s*/ s, /*e*/ e) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                        {
                            if (e)
                            {
                                let $t8, $r8;
                                let $t9, $r9;
                                let $t11, $r11;
                                ($t8 = this.UpdateOffsetFromDOM(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                                ($t9 = $.$hDPm.LCFCCD$7.DraggableExtension.Draggable(this.javascript, this, 0/*DraggableFeatures.None*/, $.$sl.SL.Enumerable.ToArray($.$hDPm.LCFCCD$7.Draggabble, $.$sl.SL.Enumerable.Select$1($.$mac.MAC.ElementReference, $.$hDPm.LCFCCD$7.Draggabble, $.$sl.SL.Enumerable.Select$1($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, $.$mac.MAC.ElementReference, this.sortings, new ($.$$.S.Func$$$($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder, $.$mac.MAC.ElementReference))().$ctor(this,  (/*o*/ o) =>
                                {
                                    return o.Element;
                                }, $AyQleb ??= {"r":1900659,"p":[{"n":"o","p":2657826}],"n":"","d":2592290,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$mac.MAC.ElementReference, $.$hDPm.LCFCCD$7.Draggabble))().$ctor(this,  (/*e*/ e) =>
                                {
                                    return (() =>
                                    {
                                        //new $.$hDPm.LCFCCD$7.Draggabble()
                                        const $t10 = $.$hDPm.LCFCCD$7.Draggabble;
                                        const $i10 = new $t10();
                                        $i10.$ctor$2();
                                        $i10.DragHandle = e;
                                        $i10.DragConstraint = this.wrapper;
                                        return $i10;
                                    })();
                                }, $uzPEXa ??= {"r":21780138,"p":[{"n":"e","p":1900659}],"n":"","d":2592290,"h":0,"f":17825794})))), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                                ($t11 = $.$hDPm.LCFCCD$7.DraggableExtension.Droppable(this.javascript, this, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mac.MAC.ElementReference), [ this.wrapper ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                            }
                        });
                    }, $bHzhYj ??= {"r":65537,"p":[{"n":"s","p":131073},{"n":"e","p":262145}],"n":"","d":2592290,"h":0,"f":17829890}));
                    builder.OpenElement(1, "div");
                    builder.AddAttribute$5(2, "class", `pos-rel ${$.$strNN((dir === "v" ? "stack" : "flex flow"))}`);
                    builder.AddAttribute$5(4, "style", style);
                    builder.AddElementReferenceCapture(2, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*e*/ e) =>
                    {
                        return this.wrapper = e;
                    }, $Wshqek ??= {"r":65537,"p":[{"n":"e","p":1900659}],"n":"","d":2592290,"h":0,"f":17825794}));
                    /*int*/ let i = 0;
                    let $i12 = 0;
                    let $arr12 = this.sortings;
                    while ($i12 < $arr12.length)
                    {
                        let _sorted = $arr12[$i12++];
                        /*var*/ let sorted = _sorted;
                        if (i !== 0)
                        {
                            $.$MdeX.LCFCMR.Utility.AddParameter(builder, separator, null);
                        }
                        /*var*/ let ii = i;
                        builder.OpenElement(((((i * 20) | 0) + 7) | 0), "div");
                        builder.AddAttribute$5(((((i * 20) | 0) + 8) | 0), "draggable", "true");
                        builder.AddAttribute$5(((((i * 20) | 0) + 9) | 0), "id", sorted.Id);
                        builder.AddAttribute$5(((((i * 20) | 0) + 10) | 0), "class", `${$.$strNN((dir === "v" ? "flex" : "stack"))} mg-2 animated`);
                        builder.AddElementReferenceCapture(((((i * 20) | 0) + 11) | 0), new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*e*/ e) =>
                        {
                            return sorted.Element = e;
                        }, $aAgiUe ??= {"r":65537,"p":[{"n":"e","p":1900659}],"n":"","d":2592290,"h":0,"f":17825794}));
                        $.$MdeX.LCFCMR.Utility.AddParameter(builder, sorted.View, null);
                        {
                            builder.OpenElement(((((i * 21) | 0) + 1) | 0), "div");
                            builder.AddAttribute$5(((((i * 21) | 0) + 2) | 0), "class", dir === "v" ? "mgl-a stack" : "mgt-a flex");
                            {
                                {
                                    builder.AddContent$1(((((i * 21) | 0) + 3) | 0), $.$MdeX.LCFCM.MarkdownPlusUtility.Button(closure, `mdi mdi-chevron-${$.$strNN((dir === "v" ? "up mgt-a" : "left mgl-a"))}`, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                    {
                                        this.MoveLeft(sorted);
                                        closure.Context.RequestRendering();
                                        return $.$$.STT.Task.CompletedTask;
                                    }, $iWQaHi ??= {"r":178454529,"n":"","d":2592290,"h":0,"f":17825794}), -1, -1, null));
                                }
                                {
                                    builder.OpenElement(((((i * 21) | 0) + 6) | 0), "div");
                                    builder.AddAttribute$5(((((i * 21) | 0) + 7) | 0), "class", "mg-1");
                                    builder.CloseElement();
                                }
                                {
                                    builder.AddContent$1(((((i * 21) | 0) + 8) | 0), $.$MdeX.LCFCM.MarkdownPlusUtility.Button(closure, `mdi mdi-chevron-${$.$strNN((dir === "v" ? "down mgb-a" : "right mgr-a"))}`, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                    {
                                        this.MoveRight(sorted);
                                        closure.Context.RequestRendering();
                                        return $.$$.STT.Task.CompletedTask;
                                    }, $lOjtlb ??= {"r":178454529,"n":"","d":2592290,"h":0,"f":17825794}), -1, -1, null));
                                }
                            }
                            builder.CloseElement();
                        }
                        builder.CloseElement();
                        i++;
                    }
                    builder.CloseElement();
                }, $IzaJck ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":2592290,"h":0,"f":17825794});
                this.UpdateAnswer();
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(view);
            }
            //--TRIMMABLE-BOUNDARY-END(68722069026)
            
            //--TRIMMABLE-BOUNDARY-START(4317009578)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Draggable.IDraggableComponent.OnDragTo(Microsoft.AspNetCore.Components.ElementReference, string, float, float)
            LCFCCD$7$IDraggableComponent$OnDragTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4317009578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnDragTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4317009578)
            
            //--TRIMMABLE-BOUNDARY-START(4317075114)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Draggable.IDroppableComponent.OnDrop(Microsoft.AspNetCore.Components.ElementReference, string, float, float)
            LCFCCD$7$IDroppableComponent$OnDrop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4317075114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnDrop(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4317075114)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(85901938210)
                this.wrapper = $.$default($.$mac.MAC.ElementReference);
                //--TRIMMABLE-BOUNDARY-END(85901938210)
                
                //--TRIMMABLE-BOUNDARY-START(73017036322)
                this.sortings = $.$$.S.Array.Empty($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder);
                //--TRIMMABLE-BOUNDARY-END(73017036322)
                
            }
            static $h = 2592290;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952265250),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362330658,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2592290,
      "h": 42952265250,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42952265250),
//--TRIMMABLE-BOUNDARY-START(12887494178),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772396066,
        "f": 50364417
      },
      "n": "Description",
      "d": 2592290,
      "h": 12887494178,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12887494178)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38657297954),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2592290,
      "h": 38657297954,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657297954),
//--TRIMMABLE-BOUNDARY-START(77312003618),
    {
      "r": 65537,
      "n": "UpdateAnswer",
      "d": 2592290,
      "h": 77312003618,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77312003618),
//--TRIMMABLE-BOUNDARY-START(60132134434),
    {
      "r": 181338113,
      "p": [
        {
          "n": "draggableElement",
          "p": 1900659
        },
        {
          "n": "draggableElementId",
          "p": 1310721
        },
        {
          "n": "dx",
          "p": 1114113
        },
        {
          "n": "dy",
          "p": 1114113
        }
      ],
      "n": "OnDragTo",
      "d": 2592290,
      "h": 60132134434,
      "f": 16777217,
      "a": [
        {
          "t": 2818162,
          "c": 8592752754
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60132134434),
//--TRIMMABLE-BOUNDARY-START(64427101730),
    {
      "r": 181338113,
      "p": [
        {
          "n": "droppableElement",
          "p": 1900659
        },
        {
          "n": "draggableElementId",
          "p": 1310721
        },
        {
          "n": "x",
          "p": 1114113
        },
        {
          "n": "y",
          "p": 1114113
        }
      ],
      "n": "OnDrop",
      "d": 2592290,
      "h": 64427101730,
      "f": 16777217,
      "a": [
        {
          "t": 2818162,
          "c": 8592752754
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64427101730),
//--TRIMMABLE-BOUNDARY-START(81606970914),
    {
      "r": 181338113,
      "n": "UpdateOffsetFromDOM",
      "d": 2592290,
      "h": 81606970914,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(81606970914),
//--TRIMMABLE-BOUNDARY-START(51542199842),
    {
      "r": 65537,
      "p": [
        {
          "n": "sort",
          "p": 2657826
        }
      ],
      "n": "MoveLeft",
      "d": 2592290,
      "h": 51542199842,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51542199842),
//--TRIMMABLE-BOUNDARY-START(55837167138),
    {
      "r": 65537,
      "p": [
        {
          "n": "sort",
          "p": 2657826
        }
      ],
      "n": "MoveRight",
      "d": 2592290,
      "h": 55837167138,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55837167138),
//--TRIMMABLE-BOUNDARY-START(68722069026),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2592290,
      "h": 68722069026,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68722069026)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47247232546),
    {
      "t": 64509610,
      "n": "javascript",
      "d": 2592290,
      "h": 47247232546,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47247232546),
//--TRIMMABLE-BOUNDARY-START(8592526882),
    {
      "t": 1673468,
      "n": "closure",
      "d": 2592290,
      "h": 8592526882,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592526882),
//--TRIMMABLE-BOUNDARY-START(85901938210),
    {
      "t": 1900659,
      "n": "wrapper",
      "d": 2592290,
      "h": 85901938210,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85901938210),
//--TRIMMABLE-BOUNDARY-START(73017036322),
    {
      "t": $.$typeArray($.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder).$h,
      "n": "sortings",
      "d": 2592290,
      "h": 73017036322,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73017036322),
//--TRIMMABLE-BOUNDARY-START(17182461474),
    {
      "t": 1310721,
      "n": "draggingElementId",
      "d": 2592290,
      "h": 17182461474,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182461474)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297559586),
    {
      "p": [
        {
          "n": "javascript",
          "p": 64509610
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2592290,
      "h": 4297559586,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297559586)
  ],
  "h": 2592290
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable, $.$hDPm.LCFCCD$7.IDraggableComponent, $.$hDPm.LCFCCD$7.IDroppableComponent ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$MdeX.LCFCMR.MarkdownPlusSortableTokenResolver.SortableOrder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusSortableTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusSortableTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2592290)
        
        

        //--TRIMMABLE-BOUNDARY-START(822818)
        $asm.$str(`$MdeX.LCFCMR.DroppableItemMode`, ($self) => class DroppableItemMode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Move = 1;
            static Clone = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(822818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Move": 1n,
                    "Clone": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295790114)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295790114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295790114)
            
            //--TRIMMABLE-BOUNDARY-START(4295790114)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295790114)
            
            static $h = 822818;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180692002),
    {
      "t": 822818,
      "n": "None",
      "d": 822818,
      "h": 17180692002,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180692002),
//--TRIMMABLE-BOUNDARY-START(12885724706),
    {
      "t": 822818,
      "n": "Move",
      "d": 822818,
      "h": 12885724706,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885724706),
//--TRIMMABLE-BOUNDARY-START(8590757410),
    {
      "t": 822818,
      "n": "Clone",
      "d": 822818,
      "h": 8590757410,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590757410)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295790114),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 822818,
      "h": 4295790114,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295790114)
  ],
  "h": 822818
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.DroppableItemMode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}DroppableItemMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(822818)
        
        

        //--TRIMMABLE-BOUNDARY-START(2985506)
        $asm.$cls(`$MdeX.LCFCMR.MarkdownPlusViews`, ($self) => class MarkdownPlusViews extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8592920098)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592920098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8592920098)
            
            //--TRIMMABLE-BOUNDARY-START(25772789282)
            static /*RenderFragment */ SelectCheckbox$1(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverRootClosure*/ closure, /*string?*/ _class, /*bool*/ singleSelect)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772789282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "id" ], null, null));
                /*var*/ let text = $.$EVvT.LCFCM.MarkdownPlusUtility.GetParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "text" ], null, null));
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*var*/ let option = $.$as(id.Value, $.$fPer.LCFCD.IQueryOption) ?? (() =>
                {
                    //new $.$fPer.LCFCD.QueryOption()
                    const $t1 = $.$fPer.LCFCD.QueryOption;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Option = id.ToString();
                    return $i1;
                })();
                return $.$MdeX.LCFCMR.MarkdownPlusViews.SelectCheckbox(closure.Context, closure, option, $.$clone(text), style, _class, singleSelect);
            }
            //--TRIMMABLE-BOUNDARY-END(25772789282)
            
            //--TRIMMABLE-BOUNDARY-START(21477821986)
            static /*RenderFragment */ SelectCheckbox(/*MarkdownPlusContext*/ context, /*IMarkdownPlusMarkdownAnswerEditor*/ answerStore, /*IQueryOption*/ option, /*object?*/ text, /*string?*/ style, /*string?*/ _class, /*bool*/ singleSelect)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477821986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    /*var*/ let selected = answerStore.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers.Contains(option);
                    /*var*/ let theme = $.$fPer.LCFC.Theme.FirstOf($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$typeNullable($.$fPer.LCFC.Theme)), [ $.$fPer.LCFC.Theme.Primary ], null, null)).WithOpacity(selected ? 1 : 0.5);
                    /*IEnumerable<KeyValuePair<Stringy, object?>>?*/ let attributes = null;
                    attributes = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick($.$hDPm.LCFCC$1.ComponentExtension.AddStyle($.$hDPm.LCFCC$1.ComponentExtension.AddClass(attributes, `bd ${$.$strNN(_class)} ${$.$strNN(theme.ToString$1("bd-", null))} fsz-25 flex corner clickable`), style), new $.$$.S.Action().$ctor(this,  () =>
                    {
                        if (!answerStore.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers.Contains(option))
                        {
                            if (singleSelect)
                            {
                                answerStore.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers.Clear();
                            }
                            answerStore.LCFCM$IMarkdownPlusMarkdownAnswerEditor$SetAnswer(option);
                        }
                        else 
                        {
                            answerStore.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers.Remove(option);
                        }
                    }, $nPwzwb ??= {"r":65537,"n":"","d":2985506,"h":0,"f":17825794}), null, false, null, null, null, null, null, null);
                    __builder2.OpenElement(0, "div");
                    __builder2.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(attributes)));
                    __builder2.OpenElement(2, "div");
                    __builder2.AddAttribute$5(3, "class", $.$strNN($.$strNN((theme.ToString$1("bg-", null))) + " pd") + " flex");
                    __builder2.OpenElement(4, "i");
                    __builder2.AddAttribute$5(5, "class", $.$strNN($.$strNN($.$strNN("mgy-a" + " mdi") + " ") + $.$strNN((selected ? "mdi-check" : "mdi-checkbox-blank"))) + " cl-white");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(6, "\r\n            ");
                    __builder2.OpenElement(7, "div");
                    __builder2.AddAttribute$5(8, "class", "flex pd");
                    __builder2.OpenElement(9, "b");
                    __builder2.AddAttribute$5(10, "class", "mg-a");
                    let rs;
                    if ($.$is(text, $.$EVvT.LCFCM.MarkdownPlusToken, { set $v($v){ rs = $v; } }))
                    {
                        text = rs.Value;
                    }
                    let view;
                    if ($.$is(text, $.$mac.MAC.RenderFragment, { set $v($v){ view = $v; } }))
                    {
                        __builder2.AddContent$1(11, view);
                    }
                    else 
                    {
                        __builder2.AddContent$3(12, text);
                    }
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(13, "\r\n    ");
                }, $RIugHf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2985506,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(21477821986)
            
            //--TRIMMABLE-BOUNDARY-START(17182854690)
            static /*RenderFragment */ SelectButton$1(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverRootClosure*/ closure, /*string?*/ _class)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182854690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "id" ], null, null));
                /*var*/ let text = $.$EVvT.LCFCM.MarkdownPlusUtility.GetParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "text" ], null, null));
                /*var*/ let style = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStylesParameter(parameters, $.$clone(method), closure, null);
                /*var*/ let option = $.$as(id.Value, $.$fPer.LCFCD.IQueryOption) ?? (() =>
                {
                    //new $.$fPer.LCFCD.QueryOption()
                    const $t2 = $.$fPer.LCFCD.QueryOption;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Option = id.ToString();
                    return $i2;
                })();
                return $.$MdeX.LCFCMR.MarkdownPlusViews.SelectButton(closure.Context, closure, option, $.$clone(text), style, _class);
            }
            //--TRIMMABLE-BOUNDARY-END(17182854690)
            
            //--TRIMMABLE-BOUNDARY-START(12887887394)
            static /*RenderFragment */ SelectButton(/*MarkdownPlusContext*/ context, /*IMarkdownPlusMarkdownAnswerEditor*/ answerStore, /*IQueryOption*/ option, /*object?*/ text, /*string?*/ style, /*string?*/ _class)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887887394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    /*var*/ let selected = answerStore.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers.Contains(option);
                    /*var*/ let theme = $.$fPer.LCFC.Theme.FirstOf($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$typeNullable($.$fPer.LCFC.Theme)), [ selected ? $.$fPer.LCFC.Theme.Primary : $.$fPer.LCFC.Theme.Gray ], null, null));
                    /*IEnumerable<KeyValuePair<Stringy, object?>>?*/ let attributes = null;
                    attributes = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick($.$hDPm.LCFCC$1.ComponentExtension.AddStyle($.$hDPm.LCFCC$1.ComponentExtension.AddClass(attributes, `d-block bd bdw-2 ${$.$strNN(_class)} ${$.$strNN(theme.ToString$1("bd-", null))} fsz-25 pd-2 corner bg-transparent bd-0 miwx-07`), style), new $.$$.S.Action().$ctor(this,  () =>
                    {
                        if (!answerStore.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers.Contains(option))
                        {
                            answerStore.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers.Clear();
                            answerStore.LCFCM$IMarkdownPlusMarkdownAnswerEditor$SetAnswer(option);
                        }
                        else 
                        {
                            answerStore.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers.Remove(option);
                        }
                    }, $fMFcwb ??= {"r":65537,"n":"","d":2985506,"h":0,"f":17825794}), null, false, null, null, null, null, null, null);
                    __builder2.OpenElement(14, "button");
                    __builder2.AddMultipleAttributes(15, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(attributes)));
                    let rs;
                    if ($.$is(text, $.$EVvT.LCFCM.MarkdownPlusToken, { set $v($v){ rs = $v; } }))
                    {
                        text = rs.Value;
                    }
                    let view;
                    if ($.$is(text, $.$mac.MAC.RenderFragment, { set $v($v){ view = $v; } }))
                    {
                        __builder2.AddContent$1(16, view);
                    }
                    else 
                    {
                        __builder2.AddContent$3(17, text);
                    }
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(18, "\r\n    ");
                }, $PidLea ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2985506,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(12887887394)
            
            //--TRIMMABLE-BOUNDARY-START(4297952802)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297952802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297952802)
            
            //--TRIMMABLE-BOUNDARY-START(4297952802)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297952802)
            
            static $h = 2985506;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592920098),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2985506,
      "h": 8592920098,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592920098),
//--TRIMMABLE-BOUNDARY-START(25772789282),
    {
      "r": 6881395,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 2066684
        },
        {
          "n": "_class",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "singleSelect",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "SelectCheckbox",
      "o": "@$1",
      "d": 2985506,
      "h": 25772789282,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772789282),
//--TRIMMABLE-BOUNDARY-START(21477821986),
    {
      "r": 6881395,
      "p": [
        {
          "n": "context",
          "p": 821500
        },
        {
          "n": "answerStore",
          "p": 428284
        },
        {
          "n": "option",
          "p": 21924182
        },
        {
          "n": "text",
          "p": 131073
        },
        {
          "n": "style",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "_class",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "singleSelect",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "SelectCheckbox",
      "d": 2985506,
      "h": 21477821986,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477821986),
//--TRIMMABLE-BOUNDARY-START(17182854690),
    {
      "r": 6881395,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 2066684
        },
        {
          "n": "_class",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "SelectButton",
      "o": "@$1",
      "d": 2985506,
      "h": 17182854690,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182854690),
//--TRIMMABLE-BOUNDARY-START(12887887394),
    {
      "r": 6881395,
      "p": [
        {
          "n": "context",
          "p": 821500
        },
        {
          "n": "answerStore",
          "p": 428284
        },
        {
          "n": "option",
          "p": 21924182
        },
        {
          "n": "text",
          "p": 131073
        },
        {
          "n": "style",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "_class",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "SelectButton",
      "d": 2985506,
      "h": 12887887394,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887887394)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297952802),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2985506,
      "h": 4297952802,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297952802)
  ],
  "h": 2985506
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.Resolvers.MarkdownPlusViews`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusViews`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2985506)
        
        

        //--TRIMMABLE-BOUNDARY-START(429602)
        $asm.$cls(`$MdeX.LCFCM.MarkdownPlus`, ($self) => class MarkdownPlus extends $.$hDPm.LCFCCM$1.MarkDown
        {
            //--TRIMMABLE-BOUNDARY-START(90194742818)
            /*string */ get OptimizedComponentName()
            {
                return "markdownplus markdown editable inputeditor";
            }
            //--TRIMMABLE-BOUNDARY-END(90194742818)
            
            //--TRIMMABLE-BOUNDARY-START(120259513890)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259513890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "MarkdownPlusResolverFactory":
                    this.MarkdownPlusResolverFactory = $.$cast(parameter.Value, $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory);
                    return true;
                    case "MarkdownPlusResolverKey":
                    this.MarkdownPlusResolverKey = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(120259513890)
            
            //--TRIMMABLE-BOUNDARY-START(68719906338)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719906338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.DefaultMarkdownPlusResolverFactory = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(68719906338)
            
            //--TRIMMABLE-BOUNDARY-START(25770233378)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770233378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$hDPm.LCFCG.ComponentFluentBuilderExtensions.IsFluent(this))
                {
                    __builder.OpenElement(1, this.Tag ?? "div");
                    __builder.AddMultipleAttributes(2, $.$hDPm.LCFCC$1.ComponentExtension.Build$1(this.OwnAttributes(null)));
                    __builder.AddContent$1(3, this._MarkdownPlus());
                    __builder.CloseElement();
                }
                else 
                {
                    if (this.ChildContent === null)
                    {
                        this.ChildContent = new ($.$mac.MAC.RenderFragment$$($.$$.S.String))().$ctor(this,  (/*value*/ value) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                            {
                                __builder2.AddMarkupContent(0, "\r\n    ");
                                __builder2.AddContent$1(1, this._MarkdownPlus());
                                __builder2.AddMarkupContent(2, "\r\n");
                            }, $DbUvNc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":429602,"h":0,"f":17825794});
                        }, $CAmVLk ??= {"r":6881395,"p":[{"n":"value","p":1310721}],"n":"","d":429602,"h":0,"f":17825794});
                    }
                    /*RenderFragment*/ let fragment = new $.$mac.MAC.RenderFragment().$ctor(this, super.BuildRenderTree);
                    __builder.AddContent$1(3, fragment);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770233378)
            
            //--TRIMMABLE-BOUNDARY-START(30065200674)
            /*MarkdownPlusTokenMethodResolverFactory*/ DefaultMarkdownPlusResolverFactory = null;
            //--TRIMMABLE-BOUNDARY-END(30065200674)
            
            //--TRIMMABLE-BOUNDARY-START(77309840930)
            /*MarkdownPlusTokenMethodResolverFactory?*/ MarkdownPlusResolverFactory = null;
            //--TRIMMABLE-BOUNDARY-END(77309840930)
            
            //--TRIMMABLE-BOUNDARY-START(81604808226)
            /*string?*/ MarkdownPlusResolverKey = null;
            //--TRIMMABLE-BOUNDARY-END(81604808226)
            
            //--TRIMMABLE-BOUNDARY-START(495138)
            static $_Paragraph;
            static get Paragraph()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(495138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$MdeX.LCFCM.MarkdownPlus;
                return $cls.$_Paragraph ??= $asm.$nstr(`$MdeX.LCFCM.MarkdownPlus.Paragraph`, ($self) => class Paragraph extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(25770298914)
                    /*List<OneOf<StringBuilder, MarkdownPlusToken>>?*/ tokens = null;
                    //--TRIMMABLE-BOUNDARY-END(25770298914)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295462434)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295462434);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295462434)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885397026)
                    /*void */ Add$1(/*char*/ c)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885397026);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (c !== /*\r*/ 13 && c !== /*\n*/ 10)
                        {
                            this.tokens ??= new ($.$$.SCG.List$$($.$fPer.LCFCO.OneOf$$$($.$$.ST.StringBuilder, $.$EVvT.LCFCM.MarkdownPlusToken)))().$ctor$1();
                            if (this.tokens.Count === 0)
                            {
                                /*var*/ let sb = new $.$$.ST.StringBuilder().$ctor$1();
                                sb.Append$5(c);
                                this.tokens.Add($.$fPer.LCFCO.OneOf$$$($.$$.ST.StringBuilder, $.$EVvT.LCFCM.MarkdownPlusToken).op_Implicit(sb));
                            }
                            else 
                            {
                                /*var*/ let last = this.tokens.get_Item(((this.tokens.Count - 1) | 0));
                                if (last.IsT0)
                                {
                                    last.AsT0.Append$5(c);
                                }
                                else 
                                {
                                    /*var*/ let sb = new $.$$.ST.StringBuilder().$ctor$1();
                                    sb.Append$5(c);
                                    this.tokens.Add($.$fPer.LCFCO.OneOf$$$($.$$.ST.StringBuilder, $.$EVvT.LCFCM.MarkdownPlusToken).op_Implicit(sb));
                                }
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885397026)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180364322)
                    /*void */ Add$2(/*string*/ c)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180364322);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.tokens ??= new ($.$$.SCG.List$$($.$fPer.LCFCO.OneOf$$$($.$$.ST.StringBuilder, $.$EVvT.LCFCM.MarkdownPlusToken)))().$ctor$1();
                        if (this.tokens.Count === 0)
                        {
                            /*var*/ let sb = new $.$$.ST.StringBuilder().$ctor$1();
                            sb.Append$21(c);
                            this.tokens.Add($.$fPer.LCFCO.OneOf$$$($.$$.ST.StringBuilder, $.$EVvT.LCFCM.MarkdownPlusToken).op_Implicit(sb));
                        }
                        else 
                        {
                            /*var*/ let last = this.tokens.get_Item(((this.tokens.Count - 1) | 0));
                            if (last.IsT0)
                            {
                                last.AsT0.Append$21(c);
                            }
                            else 
                            {
                                /*var*/ let sb = new $.$$.ST.StringBuilder().$ctor$1();
                                sb.Append$21(c);
                                this.tokens.Add($.$fPer.LCFCO.OneOf$$$($.$$.ST.StringBuilder, $.$EVvT.LCFCM.MarkdownPlusToken).op_Implicit(sb));
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180364322)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590429730)
                    /*void */ Add(/*MarkdownPlusToken*/ c)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590429730);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.tokens ??= new ($.$$.SCG.List$$($.$fPer.LCFCO.OneOf$$$($.$$.ST.StringBuilder, $.$EVvT.LCFCM.MarkdownPlusToken)))().$ctor$1();
                        this.tokens.Add($.$fPer.LCFCO.OneOf$$$($.$$.ST.StringBuilder, $.$EVvT.LCFCM.MarkdownPlusToken).op_Implicit$1(c));
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590429730)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475331618)
                    /*void */ Render(/*RenderTreeBuilder*/ builder, /*IServiceProvider*/ serviceProvider)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475331618);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this.tokens === null)
                        {
                            builder.OpenElement(1, "br");
                            builder.CloseElement();
                        }
                        else 
                        {
                            builder.OpenElement(1, "p");
                            let $en2 = this.tokens.GetEnumerator();
                            while ($en2.MoveNext())
                            {
                                let token = $en2.Current;
                                {
                                    if (token.IsT0)
                                    {
                                        /*var*/ let str = token.AsT0.ToString();
                                        /*var*/ let html = $.$$.S.String.Trim.call($.$ljzt.LCFCWM.MarkdownProcessor.ToHtml(str, serviceProvider));
                                        html = $.$$.S.String.StartsWith$3.call(html, "<p>") ? $.$$.S.String.Substring.call(html, 3, ((html.length - 7) | 0)) : html;
                                        builder.AddContent(2, new $.$mac.MAC.MarkupString().$ctor$3(html));
                                    }
                                    else 
                                    {
                                        /*var*/ let tokenValue = token.AsT1.Value;
                                        let vp;
                                        if ($.$is(tokenValue, $.$fPer.LCFCD.IReadOnlyValueProvider, { set $v($v){ vp = $v; } }))
                                        {
                                            tokenValue = vp.LCFCD$IReadOnlyValueProvider$Value;
                                        }
                                        let view;
                                        let en;
                                        if ($.$is(tokenValue, $.$mac.MAC.RenderFragment, { set $v($v){ view = $v; } }))
                                        {
                                            builder.AddContent$1(3, view);
                                        }
                                        else if ($.$is(tokenValue, $.$$.SC$1.IEnumerable, { set $v($v){ en = $v; } }) && !(tokenValue !== null && ($.$is(tokenValue, $.$$.S.String))))
                                        {
                                            let $en3 = en.SC$1$IEnumerable$GetEnumerator();
                                            while ($en3.SC$1$IEnumerator$MoveNext())
                                            {
                                                let obj = $en3.SC$1$IEnumerator$Current;
                                                {
                                                    let view2;
                                                    if ($.$is(obj, $.$mac.MAC.RenderFragment, { set $v($v){ view2 = $v; } }))
                                                    {
                                                        builder.AddContent$1(4, view2);
                                                    }
                                                    else 
                                                    {
                                                        /*object*/ let __ca1__;
                                                        /*var*/ let str = ((__ca1__ = obj) !== null ? $.$dsp(__ca1__, $.$$.S.Object, ($t) => $t.ToString) : null);
                                                        if (str !== null)
                                                        {
                                                            /*var*/ let html = $.$$.S.String.Trim.call($.$ljzt.LCFCWM.MarkdownProcessor.ToHtml(str, null));
                                                            html = $.$$.S.String.StartsWith$3.call(html, "<p>") ? $.$$.S.String.Substring.call(html, 3, ((html.length - 7) | 0)) : html;
                                                            builder.AddContent(5, new $.$mac.MAC.MarkupString().$ctor$3(html));
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else 
                                        {
                                            /*object?*/ let __ca2__;
                                            /*var*/ let str = ((__ca2__ = tokenValue) !== null ? $.$dspc(__ca2__, $.$$.S.Object, ($t) => $t.ToString) : null);
                                            if (str !== null)
                                            {
                                                /*var*/ let html = $.$$.S.String.Trim.call($.$ljzt.LCFCWM.MarkdownProcessor.ToHtml(str, null));
                                                html = $.$$.S.String.StartsWith$3.call(html, "<p>") ? $.$$.S.String.Substring.call(html, 3, ((html.length - 7) | 0)) : html;
                                                builder.AddContent(6, new $.$mac.MAC.MarkupString().$ctor$3(html));
                                            }
                                        }
                                    }
                                }
                            }
                            builder.CloseElement();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475331618)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295462434)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295462434)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.tokens = this.tokens;
                        return copy;
                    }
                    static $h = 495138;
                    static $z = 4;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885397026),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 495138,
      "h": 12885397026,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885397026),
//--TRIMMABLE-BOUNDARY-START(17180364322),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 1310721
        }
      ],
      "n": "Add",
      "o": "@$2",
      "d": 495138,
      "h": 17180364322,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180364322),
//--TRIMMABLE-BOUNDARY-START(8590429730),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 1411324
        }
      ],
      "n": "Add",
      "d": 495138,
      "h": 8590429730,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590429730),
//--TRIMMABLE-BOUNDARY-START(21475331618),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536755
        },
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "Render",
      "d": 495138,
      "h": 21475331618,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475331618)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770298914),
    {
      "t": $.$$.SCG.List$$($.$fPer.LCFCO.OneOf$$$($.$$.ST.StringBuilder, $.$EVvT.LCFCM.MarkdownPlusToken)).$h,
      "n": "tokens",
      "d": 495138,
      "h": 25770298914,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(25770298914)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295462434),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 495138,
      "h": 4295462434,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295462434)
  ],
  "d": 429602,
  "h": 495138
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.MarkdownPlus+Paragraph`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}MarkdownPlus${separator}Paragraph`; }
                }, $cls, ($v) => $cls.$_Paragraph = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(495138)
            
            //--TRIMMABLE-BOUNDARY-START(73014873634)
            /*IEnumerable<Paragraph>?*/ markdownPlusParagraphs = null;
            //--TRIMMABLE-BOUNDARY-END(73014873634)
            
            //--TRIMMABLE-BOUNDARY-START(85899775522)
            /*Task<bool> */ OnChanged(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899775522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.markdownPlusParagraphs = null;
                return super.OnChanged(value);
            }
            //--TRIMMABLE-BOUNDARY-END(85899775522)
            
            //--TRIMMABLE-BOUNDARY-START(4295396898)
            /*RenderFragment? */ _MarkdownPlus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295396898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca3__;
                if (!(((__ca3__ = this.Value) !== null ? $.$$.S.String.Contains$1.call(__ca3__, /*{*/ 123) : false)))
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*b*/ b) =>
                    {
                        return b.AddContent(1, this.Html());
                    }, $YFHAHh ??= {"r":65537,"p":[{"n":"b","p":7536755}],"n":"","d":429602,"h":0,"f":17825794});
                }
                /*var*/ let tokens = this.markdownPlusParagraphs;
                if (tokens === null)
                {
                    /*var*/ let context = new $.$EVvT.LCFCM.MarkdownPlusContext().$ctor$1(this.MarkdownPlusResolverFactory ?? this.DefaultMarkdownPlusResolverFactory, this.MarkdownPlusResolverKey);
                    /*var*/ let global = new $.$EVvT.LCFCM.MarkdownPlusTokenResolverGlobalClosure().$ctor$3(context);
                    /*var*/ let root = new $.$EVvT.LCFCM.MarkdownPlusTokenResolverRootClosure().$ctor$3(global, context, this.Value);
                    if (this.bindingSource !== null)
                    {
                        global.Set($.$$.S.Object, $.$fPer.LCFC.Stringy.op_Implicit$3("source"), this.bindingSource);
                    }
                    /*bool*/ let allowMultipleNewLine = false;
                    /*Paragraph*/ let currentParagraph = new $.$MdeX.LCFCM.MarkdownPlus.Paragraph().$ctor$2();
                    /*List<Paragraph>*/ let paragraphs = new ($.$$.SCG.List$$($.$MdeX.LCFCM.MarkdownPlus.Paragraph))().$ctor$1();
                    /*char[]*/ let bufferedCR = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), null, [128], null);
                    /*int*/ let buffer_i = 0;
                    $.$EVvT.LCFCM.MarkdownPlusParser.ParseToView($.$fPer.LCFC.Stringy.op_Implicit$3(this.Value), root, new ($.$$.S.Action$$($.$fPer.LCFCO.OneOf$$$($.$$.S.Char, $.$EVvT.LCFCM.MarkdownPlusToken)))().$ctor(this,  (/**/ token) =>
                    {
                        /*void*/  function TryCollectBufferedNewline()
                        {
                            if (buffer_i > 0)
                            {
                                /*int*/ let countNewline = 0;
                                for(/*int*/ let i = 0; i < buffer_i; i++)
                                {
                                    if ($.$$.System.Array.$ReadT1.call(bufferedCR, i) === /*\n*/ 10)
                                    {
                                        countNewline++;
                                    }
                                }
                                while(countNewline >= 2)
                                {
                                    paragraphs.Add($.$clone(currentParagraph));
                                    currentParagraph = new $.$MdeX.LCFCM.MarkdownPlus.Paragraph().$ctor$2();
                                    countNewline -= 2;
                                    //if (!allowMultipleNewLine)
                                    {
                                        break;
                                    }
                                }
                                buffer_i = 0;
                            }
                        }
                        if (token.IsT0)
                        {
                            if (token.AsT0 === /*\r*/ 13 || token.AsT0 === /*\n*/ 10)
                            {
                                $.$$.System.Array.$WriteT1.call(bufferedCR, token.AsT0, buffer_i++);
                            }
                            else 
                            {
                                TryCollectBufferedNewline.call(this);
                                currentParagraph.Add$1(token.AsT0);
                            }
                        }
                        else 
                        {
                            TryCollectBufferedNewline.call(this);
                            currentParagraph.Add(token.AsT1);
                        }
                    }, $ecVzJb ??= {"r":65537,"p":[{"n":"token","p":$.$fPer.LCFCO.OneOf$$$($.$$.S.Char, $.$EVvT.LCFCM.MarkdownPlusToken).$h}],"n":"","d":429602,"h":0,"f":17825794}));
                    if ($.$$.S.Int32.op_GreaterThan((currentParagraph.tokens?.Count ?? null), 0))
                    {
                        paragraphs.Add($.$clone(currentParagraph));
                    }
                    tokens = paragraphs;
                    if (!$.$hDPm.LCFCG.ComponentFluentBuilderExtensions.IsFluent(this))
                    {
                        this.markdownPlusParagraphs = paragraphs;
                    }
                }
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    let $en4 = tokens.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let t = $en4.SCG$IEnumerator$$$Current;
                        {
                            t.Render(builder, this.ServiceProvider);
                        }
                    }
                }, $CevMjg ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":429602,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(4295396898)
            
            //--TRIMMABLE-BOUNDARY-START(21475266082)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475266082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475266082)
            
            //--TRIMMABLE-BOUNDARY-START(21475266082)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(21475266082)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30065200674)
                this.DefaultMarkdownPlusResolverFactory = null;
                //--TRIMMABLE-BOUNDARY-END(30065200674)
                
            }
            static $h = 429602;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCM$1.MarkDown; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90194742818),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424939042,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 429602,
      "h": 90194742818,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90194742818),
//--TRIMMABLE-BOUNDARY-START(30065200674),
    {
      "p": 1476860,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655135266,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784677410,
        "f": 83886081
      },
      "n": "DefaultMarkdownPlusResolverFactory",
      "d": 429602,
      "h": 30065200674,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065200674),
//--TRIMMABLE-BOUNDARY-START(77309840930),
    {
      "p": 1476860,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245069858,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374612002,
        "f": 83886081
      },
      "n": "MarkdownPlusResolverFactory",
      "d": 429602,
      "h": 77309840930,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77309840930),
//--TRIMMABLE-BOUNDARY-START(81604808226),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835004450,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964546594,
        "f": 83886081
      },
      "n": "MarkdownPlusResolverKey",
      "d": 429602,
      "h": 81604808226,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81604808226)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(120259513890),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 429602,
      "h": 120259513890,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120259513890),
//--TRIMMABLE-BOUNDARY-START(68719906338),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 429602,
      "h": 68719906338,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68719906338),
//--TRIMMABLE-BOUNDARY-START(25770233378),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 429602,
      "h": 25770233378,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770233378),
//--TRIMMABLE-BOUNDARY-START(85899775522),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "OnChanged",
      "d": 429602,
      "h": 85899775522,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(85899775522),
//--TRIMMABLE-BOUNDARY-START(4295396898),
    {
      "r": 6881395,
      "n": "_MarkdownPlus",
      "d": 429602,
      "h": 4295396898,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(4295396898)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73014873634),
    {
      "t": $.$$.SCG.IEnumerable$$($.$MdeX.LCFCM.MarkdownPlus.Paragraph).$h,
      "n": "markdownPlusParagraphs",
      "d": 429602,
      "h": 73014873634,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73014873634)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475266082),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 429602,
      "h": 21475266082,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475266082)
  ],
  "h": 429602,
  "a": [
    {
      "t": 61429418,
      "c": 8651364010,
      "n": [
        {
          "n": "Stateless",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCCI$1.IInputEditor, $.$fPer.LCFCD.IDataValidator, $.$vWqU.LCFCC.ITabable, $.$vWqU.LCFCC.IPullResultComponent$$($.$$.S.String), $.$vWqU.LCFCC.IPullResultComponent, $.$vWqU.LCFCC.IResultComponent$$($.$$.S.String), $.$vWqU.LCFCC.IResultComponent, $.$vWqU.LCFCC.IHostedView, $.$vWqU.LCFCC.IViewBase, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$MdeX.LCFCM.MarkdownPlus.Paragraph ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.MarkdownPlus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}MarkdownPlus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(429602)
        
        

        //--TRIMMABLE-BOUNDARY-START(167458)
        $asm.$cls(`$MdeX.LCFCM._MarkdownPlus`, ($self) => class _MarkdownPlus extends $.$MdeX.LCFCM.MarkdownPlus
        {
            //--TRIMMABLE-BOUNDARY-START(4295134754)
            /*bool*/ _hasInitialized = false;
            //--TRIMMABLE-BOUNDARY-END(4295134754)
            
            //--TRIMMABLE-BOUNDARY-START(8590102050)
            /*bool*/ _stateless = false;
            //--TRIMMABLE-BOUNDARY-END(8590102050)
            
            //--TRIMMABLE-BOUNDARY-START(30064938530)
            /*bool */ get LCFCG$IFluentComponent$IsStateless()
            {
                return this._stateless;
            }
            //--TRIMMABLE-BOUNDARY-END(30064938530)
            
            //--TRIMMABLE-BOUNDARY-START(17180036642)
            /*RenderFragment */ Build(/*bool*/ stateless)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180036642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._stateless = stateless;
                this.OnParametersSet();
                _ = this.OnParametersSetAsync();
                if (!this._hasInitialized || stateless)
                {
                    this.OnInitialized();
                    _ = this.OnInitializedAsync();
                    this._hasInitialized = true;
                }
                return new $.$mac.MAC.RenderFragment().$ctor(this, this.BuildRenderTree);
            }
            //--TRIMMABLE-BOUNDARY-END(17180036642)
            
            //--TRIMMABLE-BOUNDARY-START(4355741354)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IFluentComponent.Build(bool)
            LCFCG$IFluentComponent$Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355741354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Build(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355741354)
            
            //--TRIMMABLE-BOUNDARY-START(12885069346)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$7();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885069346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885069346)
            
            //--TRIMMABLE-BOUNDARY-START(12885069346)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(12885069346)
            
            static $h = 167458;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$MdeX.LCFCM.MarkdownPlus; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064938530),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769971234,
        "f": 50331650
      },
      "n": "{60774058}.IsStateless",
      "o": "LCFCG$IFluentComponent$IsStateless",
      "d": 167458,
      "h": 30064938530,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30064938530)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180036642),
    {
      "r": 6881395,
      "p": [
        {
          "n": "stateless",
          "p": 262145
        }
      ],
      "n": "Build",
      "d": 167458,
      "h": 17180036642,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180036642)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295134754),
    {
      "t": 262145,
      "n": "_hasInitialized",
      "d": 167458,
      "h": 4295134754,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295134754),
//--TRIMMABLE-BOUNDARY-START(8590102050),
    {
      "t": 262145,
      "n": "_stateless",
      "d": 167458,
      "h": 8590102050,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590102050)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885069346),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 167458,
      "h": 12885069346,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885069346)
  ],
  "h": 167458
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCCI$1.IInputEditor, $.$fPer.LCFCD.IDataValidator, $.$vWqU.LCFCC.ITabable, $.$vWqU.LCFCC.IPullResultComponent$$($.$$.S.String), $.$vWqU.LCFCC.IPullResultComponent, $.$vWqU.LCFCC.IResultComponent$$($.$$.S.String), $.$vWqU.LCFCC.IResultComponent, $.$vWqU.LCFCC.IHostedView, $.$vWqU.LCFCC.IViewBase, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCG.IFluentComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus._MarkdownPlus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}_MarkdownPlus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(167458)
        
        

        //--TRIMMABLE-BOUNDARY-START(626210)
        $asm.$cls(`$MdeX.LCFCM.MarkdownPlusFluentBuilder<,>`, (TBuilder, TComponent) => $asm.$gt(`$MdeX.LCFCM.MarkdownPlusFluentBuilder<,>`, [TBuilder, TComponent], ($self) => class MarkdownPlusFluentBuilder$$$ extends $.$hDPm.LCFCCM$1.MarkDownFluentBuilder$$$(TBuilder, TComponent)
        {
            //--TRIMMABLE-BOUNDARY-START(12885528098)
            /*TBuilder */ MarkdownPlusResolverFactory(/*LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenMethodResolverFactory?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885528098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._target.MarkdownPlusResolverFactory = value;
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885528098)
            
            //--TRIMMABLE-BOUNDARY-START(17180495394)
            /*TBuilder */ MarkdownPlusResolverKey(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180495394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._target.MarkdownPlusResolverKey = value;
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180495394)
            
            //--TRIMMABLE-BOUNDARY-START(21475462690)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475462690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.Reset();
                this._target.MarkdownPlusResolverFactory = null;
                this._target.MarkdownPlusResolverKey = null;
            }
            //--TRIMMABLE-BOUNDARY-END(21475462690)
            
            //--TRIMMABLE-BOUNDARY-START(8590560802)
            /*TBuilder */ Initialize(/*ComponentBase?*/ caller, /*IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590560802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._target.DefaultMarkdownPlusResolverFactory = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory, provider);
                return super.Initialize(caller, provider);
            }
            //--TRIMMABLE-BOUNDARY-END(8590560802)
            
            //--TRIMMABLE-BOUNDARY-START(4295593506)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295593506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295593506)
            
            //--TRIMMABLE-BOUNDARY-START(4295593506)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295593506)
            
            static $H = 626210;
            static $h = 626210;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCM$1.MarkDownFluentBuilder$$$(TBuilder, TComponent); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885528098),
    {
      "r": TBuilder?.$h??1572864,
      "p": [
        {
          "n": "value",
          "p": 1476860
        }
      ],
      "n": "MarkdownPlusResolverFactory",
      "d": this.$h,
      "H": 12885528098,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885528098),
//--TRIMMABLE-BOUNDARY-START(17180495394),
    {
      "r": TBuilder?.$h??1572864,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "MarkdownPlusResolverKey",
      "d": this.$h,
      "H": 17180495394,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180495394),
//--TRIMMABLE-BOUNDARY-START(21475462690),
    {
      "r": 65537,
      "n": "Reset",
      "d": this.$h,
      "H": 21475462690,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475462690),
//--TRIMMABLE-BOUNDARY-START(8590560802),
    {
      "r": TBuilder?.$h??1572864,
      "p": [
        {
          "n": "caller",
          "p": 1245299
        },
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "n": "Initialize",
      "d": this.$h,
      "H": 8590560802,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590560802)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295593506),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": this.$h,
      "H": 4295593506,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295593506)
  ],
  "s": [
    {
      "h": TBuilder?.$h??1572864,
      "n": "TBuilder",
      "f": 4,
      "c": [this.$h
      ]
    },
    {
      "h": TComponent?.$h??1638400,
      "n": "TComponent",
      "f": 4,
      "c": [429602,60774058
      ]
    }
  ],
  "r": 2,
  "H": 626210,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IFluentComponentBuilder$$(TComponent) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.MarkdownPlusFluentBuilder<${TBuilder?.$fullName},${TComponent?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}MarkdownPlusFluentBuilder$${TBuilder?.$getFullName(separator)}$${TComponent?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(626210)
        
        

        //--TRIMMABLE-BOUNDARY-START(560674)
        $asm.$cls(`$MdeX.LCFCM.MarkdownPlusFluentBuilder`, ($self) => class MarkdownPlusFluentBuilder extends $.$MdeX.LCFCM.MarkdownPlusFluentBuilder$$$($self, $.$MdeX.LCFCM._MarkdownPlus)
        {
            //--TRIMMABLE-BOUNDARY-START(4295527970)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$7();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295527970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295527970)
            
            //--TRIMMABLE-BOUNDARY-START(4295527970)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295527970)
            
            static $h = 560674;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$MdeX.LCFCM.MarkdownPlusFluentBuilder$$$($.$MdeX.LCFCM.MarkdownPlusFluentBuilder, $.$MdeX.LCFCM._MarkdownPlus); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295527970),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 560674,
      "h": 4295527970,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295527970)
  ],
  "h": 560674
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IFluentComponentBuilder$$($.$MdeX.LCFCM._MarkdownPlus) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.MarkdownPlus.MarkdownPlusFluentBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}MarkdownPlus${separator}MarkdownPlusFluentBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(560674)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus"));
})();
//--TRIMMABLE-BOUNDARY-END(36386)
