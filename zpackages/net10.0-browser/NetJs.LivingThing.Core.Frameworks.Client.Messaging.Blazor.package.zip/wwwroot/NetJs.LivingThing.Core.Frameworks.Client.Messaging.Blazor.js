
//--TRIMMABLE-BOUNDARY-START(8719)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm) {
    "use strict";
    let _;
    let $mfyCsc;
    let $ppRhCf;
    let $XVgQLf;
    let $cXLJGb;
    let $WUWTCk;
    let $TTGZNg;
    let $quiqsc;
    let $KxVnze;
    let $cSBxKa;
    let $WXJfqj;
    let $WaOKNg;
    let $tkXLRi;
    let $tfsiXk;
    let $iGGuIj;
    let $DjxQed;
    let $VmPtAb;
    let $RaTZIb;
    let $xcgash;
    let $uhRZVe;
    let $bhgtOe;
    let $pbYHBj;
    let $hRwTEh;
    let $vavHfd;
    let $MWZAIc;
    let $tukVid;
    let $DGciOf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Client.Messaging.Blazor", 
    {
  "h": 8719,
  "f": "LivingThing.Core.Frameworks.Client.Messaging.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.Messaging.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.Messaging.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(139791)
        $asm.$cls(`$cDXw.LCFCM._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295107087)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295107087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$cDXw.LCFCM.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295107087)
            
            static $h = 139791;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295107087),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 139791,
      "h": 4295107087,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295107087)
  ],
  "h": 139791
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Messaging._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Messaging${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(139791)
        
        

        //--TRIMMABLE-BOUNDARY-START(74255)
        $asm.$cls(`$cDXw.LCFCM._Imports`, ($self) => class _Imports extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590008847)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590008847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590008847)
            
            //--TRIMMABLE-BOUNDARY-START(4295041551)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295041551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295041551)
            
            //--TRIMMABLE-BOUNDARY-START(4295041551)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295041551)
            
            static $h = 74255;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590008847),
    {
      "r": 65537,
      "n": "Execute",
      "d": 74255,
      "h": 8590008847,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590008847)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295041551),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 74255,
      "h": 4295041551,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295041551)
  ],
  "h": 74255
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Messaging._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Messaging${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(74255)
        
        

        //--TRIMMABLE-BOUNDARY-START(270863)
        $asm.$cls(`$cDXw.LCFCM.Notification`, ($self) => class Notification extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68719747599)
            /*string?*/ SenderId = null;
            //--TRIMMABLE-BOUNDARY-END(68719747599)
            
            //--TRIMMABLE-BOUNDARY-START(25770074639)
            /*MessageChannelTypes*/ Channel = 0;
            //--TRIMMABLE-BOUNDARY-END(25770074639)
            
            //--TRIMMABLE-BOUNDARY-START(107374453263)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(107374453263)
            
            //--TRIMMABLE-BOUNDARY-START(64424780303)
            /*string?*/ Message = null;
            //--TRIMMABLE-BOUNDARY-END(64424780303)
            
            //--TRIMMABLE-BOUNDARY-START(21475107343)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475107343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475107343)
            
            //--TRIMMABLE-BOUNDARY-START(21475107343)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21475107343)
            
            static $h = 270863;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719747599),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539878415,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489551375,
        "f": 83886081
      },
      "n": "SenderId",
      "d": 270863,
      "h": 68719747599,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719747599),
//--TRIMMABLE-BOUNDARY-START(25770074639),
    {
      "p": 48728406,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360009231,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309682191,
        "f": 83886081
      },
      "n": "Channel",
      "d": 270863,
      "h": 25770074639,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770074639),
//--TRIMMABLE-BOUNDARY-START(107374453263),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129813007,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079485967,
        "f": 83886081
      },
      "n": "Title",
      "d": 270863,
      "h": 107374453263,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374453263),
//--TRIMMABLE-BOUNDARY-START(64424780303),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949943823,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899616783,
        "f": 83886081
      },
      "n": "Message",
      "d": 270863,
      "h": 64424780303,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 10,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64424780303)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475107343),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 270863,
      "h": 21475107343,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475107343)
  ],
  "h": 270863
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Messaging.Notification`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Messaging${separator}Notification`; }
        });
        //--TRIMMABLE-BOUNDARY-END(270863)
        
        

        //--TRIMMABLE-BOUNDARY-START(205327)
        $asm.$cls(`$cDXw.LCFCM.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180074511)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cDXw.LCFCMS.NewsletterComposer.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cDXw.LCFCMS.NewsletterComposer().$ctor$3();
                    }, $mfyCsc ??= {"r":2752627,"n":"","d":205327,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180074511)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295172623)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295172623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295172623)
            
            //--TRIMMABLE-BOUNDARY-START(4295172623)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295172623)
            
            static $h = 205327;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180074511),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885107215,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 205327,
      "h": 17180074511,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180074511)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295172623),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 205327,
      "h": 4295172623,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295172623)
  ],
  "h": 205327
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Messaging.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Messaging${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(205327)
        
        

        //--TRIMMABLE-BOUNDARY-START(401935)
        $asm.$cls(`$cDXw.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295369231)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295369231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295369231)
            
            //--TRIMMABLE-BOUNDARY-START(4295369231)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295369231)
            
            static $h = 401935;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295369231),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 401935,
      "h": 4295369231,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295369231)
  ],
  "h": 401935
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(401935)
        
        

        //--TRIMMABLE-BOUNDARY-START(467471)
        $asm.$cls(`$cDXw.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295434767)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295434767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295434767)
            
            //--TRIMMABLE-BOUNDARY-START(4295434767)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295434767)
            
            static $h = 467471;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295434767),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 467471,
      "h": 4295434767,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295434767)
  ],
  "h": 467471,
  "a": [
    {
      "t": 401935,
      "c": 4295369231
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(467471)
        
        

        //--TRIMMABLE-BOUNDARY-START(336399)
        $asm.$cls(`$cDXw.LCFCMS.NewsletterComposer`, ($self) => class NewsletterComposer extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(137439289871)
            /*string */ get OptimizedComponentName()
            {
                return "newslettercomposer";
            }
            //--TRIMMABLE-BOUNDARY-END(137439289871)
            
            //--TRIMMABLE-BOUNDARY-START(214748701199)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748701199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "EmailLayoutRoute":
                    this.EmailLayoutRoute = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Provider":
                    this.Provider = $.$cast(parameter.Value, $.$UrvY.LCFCM.IMessageComposerProvider);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(214748701199)
            
            //--TRIMMABLE-BOUNDARY-START(111669486095)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669486095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Clipboard = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IClipboardAccessor, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(111669486095)
            
            //--TRIMMABLE-BOUNDARY-START(42950009359)
            /*IClipboardAccessor*/ Clipboard = null;
            //--TRIMMABLE-BOUNDARY-END(42950009359)
            
            //--TRIMMABLE-BOUNDARY-START(55834911247)
            /*string?*/ EmailLayoutRoute = null;
            //--TRIMMABLE-BOUNDARY-END(55834911247)
            
            //--TRIMMABLE-BOUNDARY-START(146029224463)
            /*IMessageComposerProvider*/ Provider = null;
            //--TRIMMABLE-BOUNDARY-END(146029224463)
            
            //--TRIMMABLE-BOUNDARY-START(128849355279)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(128849355279)
            
            //--TRIMMABLE-BOUNDARY-START(124554387983)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(124554387983)
            
            //--TRIMMABLE-BOUNDARY-START(141734257167)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(141734257167)
            
            //--TRIMMABLE-BOUNDARY-START(141734257167)
            //--TRIMMABLE-BOUNDARY-START(34360074767)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360074767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360074767)
            
            //--TRIMMABLE-BOUNDARY-START(154619159055)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619159055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(154619159055)
            
            //--TRIMMABLE-BOUNDARY-END(141734257167)
            
            //--TRIMMABLE-BOUNDARY-START(133144322575)
            /*Notification*/ newsletter = null;
            //--TRIMMABLE-BOUNDARY-END(133144322575)
            
            //--TRIMMABLE-BOUNDARY-START(158914126351)
            /*IEnumerable<IContact>?*/ selectedContacts = null;
            //--TRIMMABLE-BOUNDARY-END(158914126351)
            
            //--TRIMMABLE-BOUNDARY-START(210453733903)
            /*IDataList?*/ table = null;
            //--TRIMMABLE-BOUNDARY-END(210453733903)
            
            //--TRIMMABLE-BOUNDARY-START(51539943951)
            /*Task *//*async*/  CopySelectedContactsPhoneNumber()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539943951);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Contacts.IContact>?*/ let __ca1__;
                    /*var*/ let s = $.$$.S.String.Join$5(" ", ((__ca1__ = this.selectedContacts) !== null ? ($.$sl.SL.Enumerable.Where($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCC$2.IContact, $.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$fPer.LCFCC$2.IContact, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LCFCC$2$IContact$PhoneNumber;
                    }, $ppRhCf ??= {"r":1310721,"p":[{"n":"s","p":5081430}],"n":"","d":336399,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                    {
                        return !$.$$.S.String.IsNullOrEmpty(s);
                    }, $XVgQLf ??= {"r":262145,"p":[{"n":"s","p":1310721}],"n":"","d":336399,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$$.S.String)) : $.$sl.SL.Enumerable.Empty($.$$.S.String)));
                    ($t2 = this.Clipboard.LCFCC$IClipboardAccessor$SetAsync(s), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51539943951)
            
            //--TRIMMABLE-BOUNDARY-START(47244976655)
            /*Task *//*async*/  CopySelectedContactsEmail()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244976655);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Contacts.IContact>?*/ let __ca2__;
                    /*var*/ let s = $.$$.S.String.Join$5(" ", ((__ca2__ = this.selectedContacts) !== null ? ($.$sl.SL.Enumerable.Where($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCC$2.IContact, $.$$.S.String, __ca2__, new ($.$$.S.Func$$$($.$fPer.LCFCC$2.IContact, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LCFCC$2$IContact$Email;
                    }, $cXLJGb ??= {"r":1310721,"p":[{"n":"s","p":5081430}],"n":"","d":336399,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                    {
                        return !$.$$.S.String.IsNullOrEmpty(s);
                    }, $WUWTCk ??= {"r":262145,"p":[{"n":"s","p":1310721}],"n":"","d":336399,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$$.S.String)) : $.$sl.SL.Enumerable.Empty($.$$.S.String)));
                    ($t3 = this.Clipboard.LCFCC$IClipboardAccessor$SetAsync(s), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47244976655)
            
            //--TRIMMABLE-BOUNDARY-START(120259420687)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259420687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(120259420687)
            
            //--TRIMMABLE-BOUNDARY-START(163209093647)
            /*ValueTask *//*async*/  Send()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209093647);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.newsletter !== null && this.newsletter.Title !== null && this.newsletter.Message !== null)
                    {
                        let $t4, $r4;
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Contacts.IContact>?*/ let __ca3__;
                        /*var*/ let contacts = ((((__ca3__ = this.selectedContacts) !== null ? $.$sl.SL.Enumerable.Any$1($.$fPer.LCFCC$2.IContact, __ca3__) : false)) ? this.selectedContacts : null) ?? (($t4 = this.Provider.LCFCM$IMessageComposerProvider$GetContacts().Invoke($.$with(((this.table?.LCFCCD$1$IDataEnumerable$DataFilter ?? null) ?? $.$fPer.LCFCD.DataFilter.Default), ($clone) =>
                        {
                            $clone.Page = 1;
                            $clone.Count = 2147483647/*int.MaxValue*/;
                        })), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)))).Data;
                        if (contacts !== null)
                        {
                            let $t5, $r5;
                            let $t6, $r6;
                            ($t5 = $.$hDPm.LCFCI.ViewPresenterExtensions.MessageBox($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Send to ${$.$strNN($.$sl.SL.Enumerable.Count$1($.$fPer.LCFCC$2.IContact, contacts))} contacts`, false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "OK to Send?", false), null, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                            ($t6 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                            {
                                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                                {
                                    if (((this.newsletter.Channel & (8/*MessageChannelTypes.Email*/)) == (8/*MessageChannelTypes.Email*/)))
                                    {
                                        /*var*/ let emailRoute = this.EmailLayoutRoute ?? this.Provider.LCFCM$IMessageComposerProvider$EmailLayoutRoute;
                                        if (emailRoute !== null)
                                        {
                                            let $t7, $r7;
                                            ($t7 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.SendHTMLEmail(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, !$.$$.S.String.IsNullOrEmpty(this.newsletter.SenderId) ? this.newsletter.SenderId : this.Provider.LCFC$IDisplayable$Title ?? "LivingThing", this.newsletter.Title, emailRoute, (() =>
                                            {
                                                //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)()
                                                const $t8 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String);
                                                const $i8 = new $t8();
                                                $i8.$ctor$1();
                                                $i8.set_Item("Body", this.newsletter.Message);
                                                return $i8;
                                            })(), $.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Where($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCC$2.IContact, $.$$.S.String, contacts, new ($.$$.S.Func$$$($.$fPer.LCFCC$2.IContact, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                                            {
                                                return c.LCFCC$2$IContact$Email;
                                            }, $TTGZNg ??= {"r":1310721,"p":[{"n":"c","p":5081430}],"n":"","d":336399,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                                            {
                                                return e !== null;
                                            }, $quiqsc ??= {"r":262145,"p":[{"n":"e","p":1310721}],"n":"","d":336399,"h":0,"f":17825794})))), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                        }
                                        else 
                                        {
                                            let $t9, $r9;
                                            ($t9 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.SendEmail(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, !$.$$.S.String.IsNullOrEmpty(this.newsletter.SenderId) ? this.newsletter.SenderId : this.Provider.LCFC$IDisplayable$Title ?? "LivingThing", this.newsletter.Title, $.$UrvY.LCFCM.MessageBody.op_Implicit$1(this.newsletter.Message), $.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Where($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCC$2.IContact, $.$$.S.String, contacts, new ($.$$.S.Func$$$($.$fPer.LCFCC$2.IContact, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                                            {
                                                return c.LCFCC$2$IContact$Email;
                                            }, $KxVnze ??= {"r":1310721,"p":[{"n":"c","p":5081430}],"n":"","d":336399,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                                            {
                                                return e !== null;
                                            }, $cSBxKa ??= {"r":262145,"p":[{"n":"e","p":1310721}],"n":"","d":336399,"h":0,"f":17825794})))), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                                        }
                                    }
                                    if (((this.newsletter.Channel & (4/*MessageChannelTypes.SMS*/)) == (4/*MessageChannelTypes.SMS*/)))
                                    {
                                        let $t10, $r10;
                                        /*var*/ let text = $.$ljzt.LCFCWM.MarkdownProcessor.FromHtml(this.newsletter.Message, false);
                                        ($t10 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.SendSMS(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, !$.$$.S.String.IsNullOrEmpty(this.newsletter.SenderId) ? this.newsletter.SenderId : this.Provider.LCFC$IDisplayable$Title ?? "LivingThing", text, $.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Where($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCC$2.IContact, $.$$.S.String, contacts, new ($.$$.S.Func$$$($.$fPer.LCFCC$2.IContact, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                                        {
                                            return $.$fPer.LCFCD.PhoneNumber.Normalize(c.LCFCC$2$IContact$PhoneNumber, true);
                                        }, $WXJfqj ??= {"r":1310721,"p":[{"n":"c","p":5081430}],"n":"","d":336399,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                                        {
                                            return e !== null;
                                        }, $WaOKNg ??= {"r":262145,"p":[{"n":"e","p":1310721}],"n":"","d":336399,"h":0,"f":17825794})))), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                                    }
                                });
                            }, $tkXLRi ??= {"r":181338113,"n":"","d":336399,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                            {
                                return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                            }, $tfsiXk ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":336399,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(163209093647)
            
            //--TRIMMABLE-BOUNDARY-START(38655042063)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655042063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, (336/*LoadingFeatures.Default*/ & ~32/*LoadingFeatures.Retry*/) | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(4, "div");
                    __builder2.AddAttribute$5(5, "class", "container");
                    __builder2.OpenElement(6, "div");
                    __builder2.AddAttribute$5(7, "class", "flex mgb pdr-10");
                    __builder2.OpenElement(8, "h2");
                    __builder2.AddAttribute$5(9, "class", "mgy-a fill");
                    __builder2.AddContent$4(10, this.Provider.LCFC$IDisplayable$Title);
                    __builder2.AddContent$4(11, " / Newsletter Composer");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(12, "\r\n        ");
                    __builder2.OpenElement(13, "div");
                    __builder2.AddAttribute$5(14, "class", "row responsive");
                    __builder2.OpenElement(15, "div");
                    __builder2.AddAttribute$5(16, "class", "col-3 miwx-25");
                    __builder2.OpenElement(17, "div");
                    __builder2.AddMultipleAttributes(18, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass(this.AttributesFor("card"), "bg-card"))));
                    __builder2.AddMarkupContent(19, "<div class=\"pd bdb\"><h3 class=\"mg-0\">Compose Newsletter</h3></div>\r\n                    ");
                    __builder2.OpenElement(20, "div");
                    __builder2.AddAttribute$5(21, "class", "pd fill -scroll");
                    __builder2.OpenElement(22, "FormBuilder");
                    __builder2.AddAttribute$5(23, "T", "Notification");
                    __builder2.AddAttribute$5(24, "Model", "newsletter");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(25, "\r\n                    ");
                    __builder2.OpenElement(26, "div");
                    __builder2.AddAttribute$5(27, "class", "bdt pd");
                    __builder2.OpenElement(28, "button");
                    __builder2.AddAttribute$5(29, "class", "d-block mgl-a bg-primary pdx-3 pdy-2 corner miwx-1 fsz-15");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 30, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Send)));
                    __builder2.AddContent$4(31, "Send");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(32, "\r\n            ");
                    __builder2.OpenElement(33, "div");
                    __builder2.AddAttribute$5(34, "class", "col-7 miwx-35");
                    __builder2.OpenElement(35, "div");
                    __builder2.AddMultipleAttributes(36, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass(this.AttributesFor("card"), "bg-card"))));
                    __builder2.AddMarkupContent(37, "<div class=\"pd bdb flex\"><h3 class=\"fill mgy-a\">Receiver List</h3></div>\r\n                    ");
                    __builder2.OpenElement(38, "div");
                    __builder2.AddContent(39, this.Listing(TContact, this.Provider));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }), $iGGuIj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":336399,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(38655042063)
            
            //--TRIMMABLE-BOUNDARY-START(115964453391)
            /*RenderFragment */ Listing(TContact, /*IMessageComposerProvider<TContact>*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964453391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Contacts.IContact>?*/ let __ca1__;
                /*var*/ let binder = new ($.$hDPm.LCFCU.DelegateValueBinder$$($.$$.SCG.IEnumerable$$(TContact)))().$ctor$7(((__ca1__ = this.selectedContacts) !== null ? $.$sl.SL.Enumerable.Cast(TContact, __ca1__) : null), new ($.$$.S.Action$$($.$$.SCG.IEnumerable$$(TContact)))().$ctor(this,  (/*v*/ v) =>
                {
                    return this.selectedContacts = $.$sl.SL.Enumerable.Cast($.$fPer.LCFCC$2.IContact, v);
                }, $DjxQed ??= {"r":65537,"p":[{"n":"v","p":(TContact) => $.$$.SCG.IEnumerable$$(TContact).$h}],"n":"","d":336399,"h":0,"f":17825794}));
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListFilter$$(TContact), 40);
                    __builder2.AddComponentParameter(41, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFilterFeatures, 0/*DataListFilterFeatures.Default*/ | 1/*DataListFilterFeatures.Query*/), $.$hDPm.LCFCCD$1.DataListFilterFeatures));
                    __builder2.AddAttribute$3(42, "RightToolBars", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*filter*/ filter) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(43, "button");
                            __builder3.AddAttribute$5(44, "class", "mgy-a flex bd-0 bg-transparent mdi mdi-phone fsz-20 mgc-a");
                            __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 45, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.CopySelectedContactsPhoneNumber)));
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(46, "\r\n            ");
                            __builder3.OpenElement(47, "button");
                            __builder3.AddAttribute$5(48, "class", "mgy-a flex bd-0 bg-transparent mdi mdi-email fsz-20 mgc-a");
                            __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 49, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.CopySelectedContactsEmail)));
                            __builder3.CloseElement();
                        }, $VmPtAb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":336399,"h":0,"f":17825794});
                    }), $RaTZIb ??= {"r":6881395,"p":[{"n":"filter","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":336399,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(50, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$fPer.LCFCD.DataFilter)))().$ctor(this, ( (/*filter*/ filter) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTable$$(TContact), 51);
                            __builder3.AddComponentParameter(52, "Pager", (provider.LCFCM$IMessageComposerProvider$$$GetContacts()));
                            __builder3.AddComponentParameter(53, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 4n | 8388608n | 65536n | 131072n | 524288n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddComponentParameter(54, "MaximumSelections", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 2147483647/*int.MaxValue*/), $.$$.S.Int32));
                            __builder3.AddComponentParameter(55, "PaginatorButtonFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder3.AddComponentParameter(56, "LoadingFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ & ~32/*LoadingFeatures.Retry*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                            __builder3.AddComponentParameter(57, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, filter.Data));
                            __builder3.AddComponentParameter(58, "Selected", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$(TContact), binder.Value));
                            __builder3.AddComponentParameter(59, "SelectedChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$(TContact)), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.SCG.IEnumerable$$(TContact), this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.SCG.IEnumerable$$(TContact), this, new ($.$$.S.Action$$($.$$.SCG.IEnumerable$$(TContact)))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                return binder.Value = __value;
                            }, $xcgash ??= {"r":65537,"p":[{"n":"__value","p":(TContact) => $.$$.SCG.IEnumerable$$(TContact).$h}],"n":"","d":336399,"h":0,"f":17825794}), binder.Value))));
                            __builder3.AddAttribute$3(60, "CustomToolBar", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListToolBarContext$$$(TContact, $.$hDPm.LCFCCD$2.DataTableColumn$$(TContact))))().$ctor(this, ( (/*toolbar*/ toolbar) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                }, $uhRZVe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":336399,"h":0,"f":17825794});
                            }), $bhgtOe ??= {"r":6881395,"p":[{"n":"toolbar","p":(TContact) => $.$hDPm.LCFCCD$1.DataListToolBarContext$$$(TContact, $.$hDPm.LCFCCD$2.DataTableColumn$$(TContact)).$h}],"n":"","d":336399,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(61, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(TContact, $.$hDPm.LCFCCD$2.DataTableColumn$$(TContact))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumnsFromSchema$$(TContact), 62);
                                    __builder4.CloseComponent();
                                }, $pbYHBj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":336399,"h":0,"f":17825794});
                            }), $hRwTEh ??= {"r":6881395,"p":[{"n":"context","p":(TContact) => $.$hDPm.LCFCCD$1.DataListItemContext$$$(TContact, $.$hDPm.LCFCCD$2.DataTableColumn$$(TContact)).$h}],"n":"","d":336399,"h":0,"f":17825794}));
                            __builder3.SetKey(filter.Data);
                            __builder3.AddComponentReferenceCapture(63, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                this.table = $.$cast(__value, $.$hDPm.LCFCCD$2.DataTable$$(TContact));
                            }, $vavHfd ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":336399,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $MWZAIc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":336399,"h":0,"f":17825794});
                    }), $tukVid ??= {"r":6881395,"p":[{"n":"filter","p":$.$hDPm.LCFCI.ContainerContext$$($.$fPer.LCFCD.DataFilter).$h}],"n":"","d":336399,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $DGciOf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":336399,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(115964453391)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(25770140175)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770140175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770140175)
            
            //--TRIMMABLE-BOUNDARY-START(25770140175)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25770140175)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42950009359)
                this.Clipboard = null;
                //--TRIMMABLE-BOUNDARY-END(42950009359)
                
                //--TRIMMABLE-BOUNDARY-START(128849355279)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(128849355279)
                
                //--TRIMMABLE-BOUNDARY-START(133144322575)
                this.newsletter = new $.$cDXw.LCFCM.Notification().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(133144322575)
                
            }
            static $h = 336399;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439289871),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784584207,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 336399,
      "h": 137439289871,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439289871),
//--TRIMMABLE-BOUNDARY-START(42950009359),
    {
      "p": 2776488,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424845839,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799028239,
        "f": 83886081
      },
      "n": "Clipboard",
      "d": 336399,
      "h": 42950009359,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950009359),
//--TRIMMABLE-BOUNDARY-START(55834911247),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014780431,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180388962831,
        "f": 83886081
      },
      "n": "EmailLayoutRoute",
      "d": 336399,
      "h": 55834911247,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834911247),
//--TRIMMABLE-BOUNDARY-START(146029224463),
    {
      "p": 210396,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374518799,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206158766607,
        "f": 83886081
      },
      "n": "Provider",
      "d": 336399,
      "h": 146029224463,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029224463),
//--TRIMMABLE-BOUNDARY-START(128849355279),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194649615,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197568832015,
        "f": 83886081
      },
      "n": "Loading",
      "d": 336399,
      "h": 128849355279,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849355279),
//--TRIMMABLE-BOUNDARY-START(124554387983),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604715023,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188978897423,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 336399,
      "h": 124554387983,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124554387983)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(214748701199),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 336399,
      "h": 214748701199,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(214748701199),
//--TRIMMABLE-BOUNDARY-START(111669486095),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 336399,
      "h": 111669486095,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669486095),
//--TRIMMABLE-BOUNDARY-START(51539943951),
    {
      "r": 178454529,
      "n": "CopySelectedContactsPhoneNumber",
      "d": 336399,
      "h": 51539943951,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(51539943951),
//--TRIMMABLE-BOUNDARY-START(47244976655),
    {
      "r": 178454529,
      "n": "CopySelectedContactsEmail",
      "d": 336399,
      "h": 47244976655,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(47244976655),
//--TRIMMABLE-BOUNDARY-START(120259420687),
    {
      "r": 181338113,
      "n": "Load",
      "d": 336399,
      "h": 120259420687,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120259420687),
//--TRIMMABLE-BOUNDARY-START(163209093647),
    {
      "r": 181338113,
      "n": "Send",
      "d": 336399,
      "h": 163209093647,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(163209093647),
//--TRIMMABLE-BOUNDARY-START(38655042063),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 336399,
      "h": 38655042063,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38655042063),
//--TRIMMABLE-BOUNDARY-START(115964453391),
    {
      "r": 6881395,
      "p": [
        {
          "n": "provider",
          "p": (TContact) => $.$UrvY.LCFCM.IMessageComposerProvider$$(TContact).$h
        }
      ],
      "g": [
        "TContact"
      ],
      "n": "Listing",
      "d": 336399,
      "h": 115964453391,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(115964453391)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(133144322575),
    {
      "t": 270863,
      "n": "newsletter",
      "d": 336399,
      "h": 133144322575,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(133144322575),
//--TRIMMABLE-BOUNDARY-START(158914126351),
    {
      "t": $.$$.SCG.IEnumerable$$($.$fPer.LCFCC$2.IContact).$h,
      "n": "selectedContacts",
      "d": 336399,
      "h": 158914126351,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(158914126351),
//--TRIMMABLE-BOUNDARY-START(210453733903),
    {
      "t": 16799402,
      "n": "table",
      "d": 336399,
      "h": 210453733903,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(210453733903)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770140175),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 336399,
      "h": 25770140175,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770140175)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(141734257167),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 336399,
        "h": 34360074767,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 336399,
        "h": 154619159055,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 336399,
      "h": 141734257167,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(141734257167)
  ],
  "h": 336399
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Messaging.Shared.NewsletterComposer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Messaging${separator}Shared${separator}NewsletterComposer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(336399)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(8719)
