
//--TRIMMABLE-BOUNDARY-START(31666)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $DJRY, $bMcF, $rfUg) {
    "use strict";
    let _;
    let $TWudth;
    let $gDfvld;
    let $BsxSgl;
    let $ANrfhg;
    let $IckPZj;
    let $ginMjb;
    let $CxVnCk;
    let $RpShHf;
    let $zBRuei;
    let $uZmqpj;
    let $nLOBcb;
    let $ZtXHre;
    let $pIuEma;
    let $LIZLtc;
    let $ccrFba;
    let $ZQrNJa;
    let $cILpvi;
    let $LdPbwc;
    let $SvojSa;
    let $XsxLfe;
    let $dOpKqd;
    let $jloQlj;
    let $EIANFi;
    let $SKgDbd;
    let $HCaPye;
    let $sFuKFg;
    let $rEsjEc;
    let $ivfbhl;
    let $TWaeWb;
    let $IedFyg;
    let $ybDgel;
    let $UpNEFb;
    let $CiPHxj;
    let $SZSGkl;
    let $LxGhRj;
    let $lPmXnd;
    let $JVrFFk;
    let $fhMyji;
    let $dcAGJa;
    let $NTWyLe;
    let $pAWrzk;
    let $QeIIsj;
    let $TMepJc;
    let $jMGtRh;
    let $aNsdRc;
    let $UxFGmb;
    let $IacnEe;
    let $KpwMmc;
    let $KFUPnd;
    let $sHmMPd;
    let $FNGLKe;
    let $yzpmok;
    let $mcCXea;
    let $irXjsa;
    let $kNIDKh;
    let $HGlqya;
    let $oBzYzd;
    let $auZeYe;
    let $LpeqEf;
    let $VPeeOk;
    let $nsMExk;
    let $WjNYRb;
    let $oqqXub;
    let $lEgiZa;
    let $vwoNle;
    let $Jclaoj;
    let $jRQwha;
    let $TeGche;
    let $PTmqXd;
    let $FIDWpj;
    let $MCZMVf;
    let $GVhnPd;
    let $zWlGWc;
    let $CbqJye;
    let $vknIEf;
    let $mJybQg;
    let $AhJqge;
    let $AXkhEc;
    let $KmzAtd;
    let $pvIgbi;
    let $LYhrka;
    let $wwSnFh;
    let $helfWk;
    let $UXTMvh;
    let $NYeegf;
    let $kkriTb;
    let $eBnJmk;
    let $epwsFd;
    let $tiEgMa;
    let $tFiyPi;
    let $ffchgj;
    let $LFhQCh;
    let $zZowqh;
    let $YCFwza;
    let $MbTKtg;
    let $lvRUMh;
    let $NofZMd;
    let $YLsAbj;
    let $IeeYXi;
    let $lxTplj;
    let $mvZkrh;
    let $ATqYbk;
    let $ACDFFd;
    let $HrPadl;
    let $yBHcCd;
    let $EnoNFg;
    let $NIYvjf;
    let $OoQLLc;
    let $VqzwZi;
    let $tVZTgk;
    let $Gagddg;
    let $vVqTlh;
    let $YPSBrb;
    let $dGLkua;
    let $TuNmEk;
    let $hLxgjh;
    let $CDnEAa;
    let $RkgRtd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", 
    {
  "h": 31666,
  "f": "LivingThing.Core.Frameworks.Client.PageBuilder.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.PageBuilder.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.PageBuilder.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(883634)
        $asm.$cls(`$yyXP.LCFCP.IWidgetAttributeProvider`, ($self) => class IWidgetAttributeProvider
        {
            static $h = 883634;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295850930),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        }
      ],
      "n": "Apply",
      "o": "LCFCP$IWidgetAttributeProvider$Apply",
      "d": 883634,
      "h": 4295850930,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295850930)
  ],
  "h": 883634
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.IWidgetAttributeProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}IWidgetAttributeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(883634)
        
        

        //--TRIMMABLE-BOUNDARY-START(752562)
        $asm.$cls(`$yyXP.LCFCP.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295719858)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295719858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yyXP.LCFCP.PageBuilderFeatures.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yyXP.LCFCP.PageBuilderFeaturesCustomAttributesProvider, $.$yyXP.LCFCP.PageBuilderFeaturesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yyXP.LCFCPWB.BackgroundImageSize.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yyXP.LCFCPWB.BackgroundImageSizeCustomAttributesProvider, $.$yyXP.LCFCPWB.BackgroundImageSizeCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295719858)
            
            static $h = 752562;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295719858),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 752562,
      "h": 4295719858,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295719858)
  ],
  "h": 752562
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(752562)
        
        

        //--TRIMMABLE-BOUNDARY-START(1801138)
        $asm.$cls(`$yyXP.LCFCPWB.BackgroundImageSizeCustomAttributesProvider`, ($self) => class BackgroundImageSizeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296768434)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296768434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296768434)
            
            static $h = 1801138;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296768434),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1801138,
      "h": 4296768434,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296768434)
  ],
  "h": 1801138
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.Banner.BackgroundImageSizeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}Banner${separator}BackgroundImageSizeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1801138)
        
        

        //--TRIMMABLE-BOUNDARY-START(818098)
        $asm.$cls(`$yyXP.LCFCP.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295785394)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295785394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295785394)
            
            static $h = 818098;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295785394),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 818098,
      "h": 4295785394,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295785394)
  ],
  "h": 818098
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(818098)
        
        

        //--TRIMMABLE-BOUNDARY-START(1014706)
        $asm.$cls(`$yyXP.LCFCP.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590949298)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590949298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$yyXP.LCFCP.PageBuilder, "LivingThing.Core.Frameworks.Client.PageBuilder", "PageBuilder", "Page Builder", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/PageBuilder" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590949298)
            
            //--TRIMMABLE-BOUNDARY-START(4295982002)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295982002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295982002)
            
            //--TRIMMABLE-BOUNDARY-START(4295982002)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295982002)
            
            static $h = 1014706;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590949298),
    {
      "r": 65537,
      "n": "Build",
      "d": 1014706,
      "h": 8590949298,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590949298)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295982002),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1014706,
      "h": 4295982002,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295982002)
  ],
  "h": 1014706
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1014706)
        
        

        //--TRIMMABLE-BOUNDARY-START(424882)
        $asm.$cls(`$yyXP.LCFCP._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295392178)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295392178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$yyXP.LCFCP.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295392178)
            
            static $h = 424882;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295392178),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 424882,
      "h": 4295392178,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295392178)
  ],
  "h": 424882
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(424882)
        
        

        //--TRIMMABLE-BOUNDARY-START(1211314)
        $asm.$cls(`$yyXP.LCFCP.PageBuilderFeaturesCustomAttributesProvider`, ($self) => class PageBuilderFeaturesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296178610)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296178610)
            
            //--TRIMMABLE-BOUNDARY-START(8591145906)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591145906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$yyXP.LCFCP.PageBuilderFeaturesCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$yyXP.LCFCP.PageBuilderFeaturesCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $rEsjEc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1211314,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $ivfbhl ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1211314,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591145906)
            
            static $h = 1211314;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591145906),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1211314,
      "h": 8591145906,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591145906)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296178610),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1211314,
      "h": 4296178610,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296178610)
  ],
  "h": 1211314
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.PageBuilderFeaturesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}PageBuilderFeaturesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1211314)
        
        

        //--TRIMMABLE-BOUNDARY-START(228274)
        $asm.$cls(`$yyXP._LCFCPP$1.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295195570)
            static /*void */ CreatePropertySheet_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*T*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg1, /*int*/ __seq2, /*global::System.Object*/ __arg2, /*int*/ __seq3, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg3, /*int*/ __seq4, /*global::System.Object*/ __arg4, /*int*/ __seq5, /*global::System.Collections.Generic.IEnumerable<global::LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor>*/ __arg5, /*int*/ __seq6, /*global::Microsoft.AspNetCore.Components.EventCallback<global::System.Collections.Generic.IEnumerable<global::LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor>>*/ __arg6)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295195570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Target", $.$box(__arg0, T));
                __builder.AddComponentParameter(__seq1, "Features", $.$box(__arg1, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq2, "Filter", __arg2);
                __builder.AddComponentParameter(__seq3, "Theme", $.$clone(__arg3));
                __builder.AddComponentParameter(__seq4, "li-class", __arg4);
                __builder.AddComponentParameter(__seq5, "Selected", __arg5);
                __builder.AddComponentParameter(__seq6, "SelectedChanged", __arg6);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295195570)
            
            static $h = 228274;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295195570),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => T.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 14505642
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 131073
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 65309014
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": 131073
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor).$h
        },
        {
          "n": "__seq6",
          "p": 655361
        },
        {
          "n": "__arg6",
          "p": $.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor)).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreatePropertySheet_0",
      "d": 228274,
      "h": 4295195570,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295195570)
  ],
  "h": 228274
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Frameworks.Client.PageBuilder.PropertySelector.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}PropertySelector${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(228274)
        
        

        //--TRIMMABLE-BOUNDARY-START(97202)
        $asm.$cls(`$yyXP._LCFCPC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295064498)
            static /*void */ CreateDataList_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::System.Boolean*/ __arg1, /*int*/ __seq2, /*global::System.Int32?*/ __arg2, /*int*/ __seq3, /*global::System.Int32?*/ __arg3, /*int*/ __seq4, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg4, /*int*/ __seq5, /*global::System.String*/ __arg5, /*int*/ __seq6, /*global::LivingThing.Core.Frameworks.Common.Client.IViewController*/ __arg6, /*int*/ __seq7, /*global::LivingThing.Core.Frameworks.Common.Data.DataFilter*/ __arg7, /*int*/ __seq8, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg8)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295064498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "Selectable", $.$box(__arg1, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq2, "GridGap", $.$box(__arg2, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq3, "GridWidth", $.$box(__arg3, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq4, "Features", $.$box(__arg4, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq5, "ItemName", __arg5);
                __builder.AddComponentParameter(__seq6, "Controller", __arg6);
                __builder.AddComponentParameter(__seq7, "DataFilter", __arg7);
                __builder.AddComponentParameter(__seq8, "ChildContent", __arg8);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295064498)
            
            static $h = 97202;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295064498),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 262145
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": $.$typeNullable($.$$.S.Int32).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": $.$typeNullable($.$$.S.Int32).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": 14505642
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": 1310721
        },
        {
          "n": "__seq6",
          "p": 655361
        },
        {
          "n": "__arg6",
          "p": 5856680
        },
        {
          "n": "__seq7",
          "p": 655361
        },
        {
          "n": "__arg7",
          "p": 9734486
        },
        {
          "n": "__seq8",
          "p": 655361
        },
        {
          "n": "__arg8",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_0",
      "d": 97202,
      "h": 4295064498,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295064498)
  ],
  "h": 97202
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Frameworks.Client.PageBuilder.ComponentBrowser.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}ComponentBrowser${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(97202)
        
        

        //--TRIMMABLE-BOUNDARY-START(293810)
        $asm.$cls(`$yyXP._LCFCPW.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295261106)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::System.Boolean*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295261106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "IsFixed", $.$box(__arg1, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq2, "ChildContent", __arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295261106)
            
            static $h = 293810;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295261106),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 262145
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 293810,
      "h": 4295261106,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295261106)
  ],
  "h": 293810
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Frameworks.Client.PageBuilder.WidgetRenderer.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}WidgetRenderer${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(293810)
        
        

        //--TRIMMABLE-BOUNDARY-START(162738)
        $asm.$cls(`$yyXP._LCFCPP.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295130034)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg1, /*int*/ __seq2, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295130034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "ValueChanged", __arg1);
                __builder.AddComponentParameter(__seq2, "ValueExpression", __arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295130034)
            
            //--TRIMMABLE-BOUNDARY-START(8590097330)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::System.Object*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590097330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "rows", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590097330)
            
            static $h = 162738;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295130034),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 162738,
      "h": 4295130034,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295130034),
//--TRIMMABLE-BOUNDARY-START(8590097330),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 131073
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 162738,
      "h": 8590097330,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590097330)
  ],
  "h": 162738
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Frameworks.Client.PageBuilder.PageBuilder.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}PageBuilder${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(162738)
        
        

        //--TRIMMABLE-BOUNDARY-START(1407922)
        $asm.$cls(`$yyXP.LCFCP.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591342514)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591342514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rfUg.LCFCFW.Startup.AddRazorContainerComponentWidget($.$yyXP.LCFCPWB.BannerWidget, $.$yyXP.LCFCPWB.BannerWidgetView, services);
                $.$rfUg.LCFCFW.Startup.AddRazorComponentWidget($.$yyXP.LCFCPWS$1.SubscribeWidget, $.$yyXP.LCFCPWS$1.SubscribeWidgetView, services);
                $.$rfUg.LCFCFW.Startup.AddRazorComponentWidget($.$yyXP.LCFCPWF.FeatureWidget, $.$yyXP.LCFCPWF.FeatureWidgetView, services);
                $.$rfUg.LCFCFW.Startup.AddRazorComponentWidget($.$yyXP.LCFCPWM.MetricsCountWidget, $.$yyXP.LCFCPWM.MetricsCountWidgetView, services);
                $.$rfUg.LCFCFW.Startup.AddRazorComponentWidget($.$yyXP.LCFCPWC.ContactUsWidget, $.$yyXP.LCFCPWC.ContactUsWidgetView, services);
                $.$rfUg.LCFCFW.Startup.AddRazorComponentWidget($.$yyXP.LCFCPWS.SliderWidget, $.$yyXP.LCFCPWS.SliderWidgetView, services);
                $.$hDPm.LCFCI.InputEditorProviderExtension.AddInputEditor$1($.$bMcF.LFCW.UIRootWidget, $.$yyXP.LCFCP.UIRootWidgetInput, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591342514)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$yyXP.LCFCP.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296375218)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296375218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296375218)
            
            //--TRIMMABLE-BOUNDARY-START(4296375218)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296375218)
            
            static $h = 1407922;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591342514),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1407922,
      "h": 8591342514,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591342514)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296375218),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1407922,
      "h": 4296375218,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296375218)
  ],
  "h": 1407922
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1407922)
        
        

        //--TRIMMABLE-BOUNDARY-START(949170)
        $asm.$cls(`$yyXP.LCFCP.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180818354)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$yyXP.LCFCP.ComponentBrowser.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$yyXP.LCFCP.ComponentBrowser().$ctor$3();
                    }, $LdPbwc ??= {"r":2752627,"n":"","d":949170,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$yyXP.LCFCP.ComponentEditor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$yyXP.LCFCP.ComponentEditor().$ctor$3();
                    }, $SvojSa ??= {"r":2752627,"n":"","d":949170,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$yyXP.LCFCP.ComponentNavigator.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$yyXP.LCFCP.ComponentNavigator().$ctor$3();
                    }, $XsxLfe ??= {"r":2752627,"n":"","d":949170,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$yyXP.LCFCP.ComponentThumbnail.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$yyXP.LCFCP.ComponentThumbnail().$ctor$3();
                    }, $dOpKqd ??= {"r":2752627,"n":"","d":949170,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$yyXP.LCFCP.PageBuilder.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$yyXP.LCFCP.PageBuilder().$ctor$3();
                    }, $jloQlj ??= {"r":2752627,"n":"","d":949170,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$yyXP.LCFCP.TemplateMarket.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$yyXP.LCFCP.TemplateMarket().$ctor$3();
                    }, $EIANFi ??= {"r":2752627,"n":"","d":949170,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$yyXP.LCFCP.TemplatePreview.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$yyXP.LCFCP.TemplatePreview().$ctor$3();
                    }, $SKgDbd ??= {"r":2752627,"n":"","d":949170,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$yyXP.LCFCP.UIRootWidgetInput.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$yyXP.LCFCP.UIRootWidgetInput().$ctor$5();
                    }, $HCaPye ??= {"r":2752627,"n":"","d":949170,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$yyXP.LCFCP.WidgetRenderer.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$yyXP.LCFCP.WidgetRenderer().$ctor$3();
                    }, $sFuKFg ??= {"r":2752627,"n":"","d":949170,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180818354)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295916466)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295916466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295916466)
            
            //--TRIMMABLE-BOUNDARY-START(4295916466)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295916466)
            
            static $h = 949170;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180818354),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885851058,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 949170,
      "h": 17180818354,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180818354)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295916466),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 949170,
      "h": 4295916466,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295916466)
  ],
  "h": 949170
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(949170)
        
        

        //--TRIMMABLE-BOUNDARY-START(1276850)
        $asm.$cls(`$yyXP.LCFCP.PropertyDataBinding<,>`, (TClass, TViewConfiguration) => $asm.$gt(`$yyXP.LCFCP.PropertyDataBinding<,>`, [TClass, TViewConfiguration], ($self) => class PropertyDataBinding$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(137440230322)
            /*UIRootWidget*/ root = null;
            //--TRIMMABLE-BOUNDARY-END(137440230322)
            
            //--TRIMMABLE-BOUNDARY-START(30066047922)
            /*TClass*/ Data = $.$default(TClass);
            //--TRIMMABLE-BOUNDARY-END(30066047922)
            
            //--TRIMMABLE-BOUNDARY-START(120260361138)
            /*IViewStackPresenter<TViewConfiguration>*/ presenter = null;
            //--TRIMMABLE-BOUNDARY-END(120260361138)
            
            //--TRIMMABLE-BOUNDARY-START(98785524658)
            /*Func<PageBuilderMode>*/ getPageMode = null;
            //--TRIMMABLE-BOUNDARY-END(98785524658)
            
            //--TRIMMABLE-BOUNDARY-START(38655982514)
            /*PropertyDescriptorFilter*/ filter = null;
            //--TRIMMABLE-BOUNDARY-END(38655982514)
            
            //--TRIMMABLE-BOUNDARY-START(12886178738)
            $ctor$1(/*UIRootWidget*/ root, /*TClass*/ data, /*Func<PageBuilderMode>*/ pageMode, /*IViewStackPresenter<TViewConfiguration>*/ presenter)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886178738);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.root = root;
                    this.Data = data;
                    this.getPageMode = pageMode;
                    this.presenter = presenter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886178738)
            
            //--TRIMMABLE-BOUNDARY-START(150325132210)
            /*PropertyDataBinding<TClass, TViewConfiguration> */ WithFilter(/*PropertyDescriptorFilter*/ _filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325132210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.filter = _filter;
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(150325132210)
            
            //--TRIMMABLE-BOUNDARY-START(141735197618)
            /*object*/ get_Item$1(/*Widget*/ widget, /*string*/ path)
            {
                /*var*/ let desc = $.$fPer.LCFCP$1.PropertyExtension.GetValue($.$box(this.Data, TClass), path, null);
                return desc;
            }
            //--TRIMMABLE-BOUNDARY-END(141735197618)
            
            //--TRIMMABLE-BOUNDARY-START(115965393842)
            /*List<string>*/ presented = null;
            //--TRIMMABLE-BOUNDARY-END(115965393842)
            
            //--TRIMMABLE-BOUNDARY-START(107375459250)
            /*int */ get LoopIndex()
            {
                return -1;
            }
            //--TRIMMABLE-BOUNDARY-END(107375459250)
            
            //--TRIMMABLE-BOUNDARY-START(34361015218)
            /*object */ get DataSource()
            {
                return $.$box(this.Data, TClass);
            }
            //--TRIMMABLE-BOUNDARY-END(34361015218)
            
            //--TRIMMABLE-BOUNDARY-START(25771080626)
            /*IEnumerable<IPropertyDescriptor> */ get BindingPaths()
            {
                return $.$fPer.LCFCD.DataDescriptorFactory.From(TClass.$type, null, true).LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$Values;
            }
            //--TRIMMABLE-BOUNDARY-END(25771080626)
            
            //--TRIMMABLE-BOUNDARY-START(111670426546)
            /*IWidgetDataSource?*/ Parent = null;
            //--TRIMMABLE-BOUNDARY-END(111670426546)
            
            //--TRIMMABLE-BOUNDARY-START(124555328434)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(124555328434)
            
            //--TRIMMABLE-BOUNDARY-START(124555328434)
            //--TRIMMABLE-BOUNDARY-START(21476113330)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476113330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21476113330)
            
            //--TRIMMABLE-BOUNDARY-START(133145263026)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145263026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(133145263026)
            
            //--TRIMMABLE-BOUNDARY-END(124555328434)
            
            //--TRIMMABLE-BOUNDARY-START(103080491954)
            /*ConcurrentDictionary<string, Func<TClass, object>>*/ lambdas = null;
            //--TRIMMABLE-BOUNDARY-END(103080491954)
            
            //--TRIMMABLE-BOUNDARY-START(94490557362)
            /*T? */ Get(T, /*Widget*/ widget, /*string*/ path, /*T?*/ defaultValue, /*bool*/ throws)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490557362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return $.$bMcF.LFCD.UIDataBindingExtension.EvaluateBoundExpression(TClass, T, this, this.Data, widget, path, throws);
                }
                catch(e)
                {
                    return defaultValue;
                }
                /*var*/ let key = `_binding.${$.$strNN(path)}`;
                if (widget.Scratch.ContainsKey(key))
                {
                    /*var*/ let property = $.$dsp(widget.Scratch.get_Item(key), $.$$.S.Object, ($t) => $t.ToString);
                    try
                    {
                        try
                        {
                            if (T.$type === $.$$.S.String.$type)
                            {
                                property = `(${$.$strNN(property)}).ToString()`;
                            }
                            /*var*/ let _delegate = $.$DJRY.LCFCD.InterpreterExtension.CompileExpression(TClass, T, property, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "_" ], null, null));
                            return _delegate.Invoke(this.Data);
                        }
                        catch(e)
                        {
                            return defaultValue;
                        }
                    }
                    catch($e)
                    {
                        widget.Scratch.Remove$1(key);
                    }
                }
                /*var*/ let mode = this.getPageMode.Invoke();
                if (!this.presented.Contains(key) && this.Data !== null && (mode === 1/*PageBuilderMode.EditDragDrop*/ || mode === 2/*PageBuilderMode.EditJson*/))
                {
                    this.presented.Add(key);
                    $.$hDPm.LCFCI.ViewPresenterExtensions.ViewForResult(TViewConfiguration, $.$$.S.String, $.$yyXP.LCFCP.PropertySelector$$(TClass), this.presenter, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Binding", false), null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*builder*/ builder, /*sequence*/ sequence) =>
                    {
                        builder.AddAttribute$5(sequence++, "Label", `${$.$strNN(widget.Name)} needs a parameter ${$.$strNN($.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(path))}. Select a value that represents \"${$.$strNN($.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(path))}\"`);
                        builder.AddAttribute$4(sequence++, "Data", $.$box(this.Data, TClass));
                        builder.AddAttribute$3(sequence++, "Filter", this.filter);
                        builder.AddAttribute$4(sequence++, "Theme", $.$fPer.LCFC.Theme.Primary);
                    }, $TMepJc ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"sequence","p":655361}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), null, (() =>
                    {
                        //new TViewConfiguration()
                        const $t1 = TViewConfiguration.$isProxy === true ? TViewConfiguration.$prototype : TViewConfiguration;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.ViewFeatures = 1/*ViewFeatures.OKToolBar*/ | 2/*ViewFeatures.CancelToolBar*/;
                        return $i1;
                    })());
                }
                return defaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(94490557362)
            
            //--TRIMMABLE-BOUNDARY-START(146030164914)
            /*IWidgetDataSource */ With(TData, /*int*/ index, /*TData*/ scopedData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030164914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$bMcF.LFCD.UIDataBinding$$(TData))().$ctor$1(this, index, scopedData, null, new ($.$bMcF.LFCD.BindingExpressionEvaluator$$$(TData, $.$$.S.Object))().$ctor($.$bMcF.LFCD.UIDataBindingExtension, (...args) => $.$bMcF.LFCD.UIDataBindingExtension.EvaluateBoundExpression(TData, $.$$.S.Object,  ...args)), null);
            }
            //--TRIMMABLE-BOUNDARY-END(146030164914)
            
            //--TRIMMABLE-BOUNDARY-START(25771257584)
            //Generated interface implemetation for LivingThing.FluentUI.Core.DataBinding.IWidgetDataSource.DataSource.get
            get LFCD$IWidgetDataSource$DataSource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591388400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DataSource;
            }
            //--TRIMMABLE-BOUNDARY-END(25771257584)
            
            //--TRIMMABLE-BOUNDARY-START(34361192176)
            //Generated interface implemetation for LivingThing.FluentUI.Core.DataBinding.IWidgetDataSource.this[LivingThing.FluentUI.Core.Widgets.Widget, string].get
            LFCD$IWidgetDataSource$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361192176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34361192176)
            
            //--TRIMMABLE-BOUNDARY-START(17181322992)
            //Generated interface implemetation for LivingThing.FluentUI.Core.DataBinding.IWidgetDataSource.BindingPaths.get
            get LFCD$IWidgetDataSource$BindingPaths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296421104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BindingPaths;
            }
            //--TRIMMABLE-BOUNDARY-END(17181322992)
            
            //--TRIMMABLE-BOUNDARY-START(55836028656)
            //Generated interface implemetation for LivingThing.FluentUI.Core.DataBinding.IWidgetDataSource.Get<T>(LivingThing.FluentUI.Core.Widgets.Widget, string, T?, bool)
            LFCD$IWidgetDataSource$Get()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836028656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Get(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(55836028656)
            
            //--TRIMMABLE-BOUNDARY-START(73015897840)
            //Generated interface implemetation for LivingThing.FluentUI.Core.DataBinding.IWidgetDataSource.With<TData>(int, TData)
            LFCD$IWidgetDataSource$With()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015897840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.With(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(73015897840)
            
            //--TRIMMABLE-BOUNDARY-START(42951126768)
            //Generated interface implemetation for LivingThing.FluentUI.Core.DataBinding.IWidgetDataSource.LoopIndex.get
            get LFCD$IWidgetDataSource$LoopIndex()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130995952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoopIndex;
            }
            //--TRIMMABLE-BOUNDARY-END(42951126768)
            
            //--TRIMMABLE-BOUNDARY-START(51541061360)
            //Generated interface implemetation for LivingThing.FluentUI.Core.DataBinding.IWidgetDataSource.Parent.get
            get LFCD$IWidgetDataSource$Parent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425963248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Parent;
            }
            //--TRIMMABLE-BOUNDARY-END(51541061360)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(115965393842)
                this.presented = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(115965393842)
                
                //--TRIMMABLE-BOUNDARY-START(103080491954)
                this.lambdas = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$$.S.Func$$$(TClass, $.$$.S.Object)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(103080491954)
                
            }
            static $H = 1276850;
            static $h = 1276850;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066047922),
    {
      "p": TClass?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55835851698,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "n": "Data",
      "d": this.$h,
      "H": 30066047922,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066047922),
//--TRIMMABLE-BOUNDARY-START(141735197618),
    {
      "p": 131073,
      "i": [
        {
          "n": "widget",
          "p": 9907952
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "H": 73015720882,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "H": 141735197618,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(141735197618),
//--TRIMMABLE-BOUNDARY-START(107375459250),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81605655474,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "LoopIndex",
      "d": this.$h,
      "H": 107375459250,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375459250),
//--TRIMMABLE-BOUNDARY-START(34361015218),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64425786290,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "DataSource",
      "d": this.$h,
      "H": 34361015218,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361015218),
//--TRIMMABLE-BOUNDARY-START(25771080626),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47245917106,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "BindingPaths",
      "d": this.$h,
      "H": 25771080626,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771080626),
//--TRIMMABLE-BOUNDARY-START(111670426546),
    {
      "p": 1453808,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90195590066,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "n": "Parent",
      "d": this.$h,
      "H": 111670426546,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670426546)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(150325132210),
    {
      "r": this.$h,
      "p": [
        {
          "n": "_filter",
          "p": 42305878
        }
      ],
      "n": "WithFilter",
      "d": this.$h,
      "H": 150325132210,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150325132210),
//--TRIMMABLE-BOUNDARY-START(94490557362),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "defaultValue",
          "p": (T) => T.$h,
          "f": 65
        },
        {
          "n": "throws",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "g": [
        "T"
      ],
      "n": "Get",
      "d": this.$h,
      "H": 94490557362,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(94490557362),
//--TRIMMABLE-BOUNDARY-START(146030164914),
    {
      "r": 1453808,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "scopedData",
          "p": (TData) => TData.$h
        }
      ],
      "g": [
        "TData"
      ],
      "n": "With",
      "d": this.$h,
      "H": 146030164914,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(146030164914)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(137440230322),
    {
      "t": 9514736,
      "n": "root",
      "d": this.$h,
      "H": 137440230322,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(137440230322),
//--TRIMMABLE-BOUNDARY-START(120260361138),
    {
      "t": $.$vWqU.LCFCC.IViewStackPresenter$$(TViewConfiguration).$h,
      "n": "presenter",
      "d": this.$h,
      "H": 120260361138,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120260361138),
//--TRIMMABLE-BOUNDARY-START(98785524658),
    {
      "t": $.$$.S.Func$$($.$hDPm.LCFCI.PageBuilderMode).$h,
      "n": "getPageMode",
      "d": this.$h,
      "H": 98785524658,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98785524658),
//--TRIMMABLE-BOUNDARY-START(38655982514),
    {
      "t": 42305878,
      "n": "filter",
      "d": this.$h,
      "H": 38655982514,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655982514),
//--TRIMMABLE-BOUNDARY-START(115965393842),
    {
      "t": $.$$.SCG.List$$($.$$.S.String).$h,
      "n": "presented",
      "d": this.$h,
      "H": 115965393842,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(115965393842),
//--TRIMMABLE-BOUNDARY-START(103080491954),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$$.S.Func$$$(TClass, $.$$.S.Object)).$h,
      "n": "lambdas",
      "d": this.$h,
      "H": 103080491954,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(103080491954)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886178738),
    {
      "p": [
        {
          "n": "root",
          "p": 9514736
        },
        {
          "n": "data",
          "p": TClass?.$h??1572864
        },
        {
          "n": "pageMode",
          "p": $.$$.S.Func$$($.$hDPm.LCFCI.PageBuilderMode).$h
        },
        {
          "n": "presenter",
          "p": $.$vWqU.LCFCC.IViewStackPresenter$$(TViewConfiguration).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12886178738,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886178738)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(124555328434),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": this.$h,
        "H": 21476113330,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": this.$h,
        "H": 133145263026,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": this.$h,
      "H": 124555328434,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(124555328434)
  ],
  "s": [
    {
      "h": TClass?.$h??1572864,
      "n": "TClass",
      "f": 1
    },
    {
      "h": TViewConfiguration?.$h??1638400,
      "n": "TViewConfiguration",
      "f": 4,
      "c": [67131050
      ]
    }
  ],
  "r": 2,
  "H": 1276850,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCD.IWidgetDataSource, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.PropertyDataBinding<${TClass?.$fullName},${TViewConfiguration?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}PropertyDataBinding$${TClass?.$getFullName(separator)}$${TViewConfiguration?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1276850)
        
        

        //--TRIMMABLE-BOUNDARY-START(2784178)
        $asm.$cls(`$yyXP.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297751474)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297751474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297751474)
            
            //--TRIMMABLE-BOUNDARY-START(4297751474)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297751474)
            
            static $h = 2784178;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297751474),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2784178,
      "h": 4297751474,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297751474)
  ],
  "h": 2784178,
  "a": [
    {
      "t": 2718642,
      "c": 4297685938
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2784178)
        
        

        //--TRIMMABLE-BOUNDARY-START(2718642)
        $asm.$cls(`$yyXP.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297685938)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297685938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297685938)
            
            //--TRIMMABLE-BOUNDARY-START(4297685938)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297685938)
            
            static $h = 2718642;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297685938),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2718642,
      "h": 4297685938,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297685938)
  ],
  "h": 2718642
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2718642)
        
        

        //--TRIMMABLE-BOUNDARY-START(2325426)
        $asm.$cls(`$yyXP.LCFCPWM.MetricsCountWidget`, ($self) => class MetricsCountWidget extends $.$bMcF.LFCW.Widget
        {
            //--TRIMMABLE-BOUNDARY-START(21477161906)
            /*double*/ Count = 0;
            //--TRIMMABLE-BOUNDARY-END(21477161906)
            
            //--TRIMMABLE-BOUNDARY-START(55836900274)
            /*string?*/ Label = null;
            //--TRIMMABLE-BOUNDARY-END(55836900274)
            
            //--TRIMMABLE-BOUNDARY-START(25772129202)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(25772129202)
            
            //--TRIMMABLE-BOUNDARY-START(17182194610)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\MetricsCountWidget.cs", 11);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182194610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182194610)
            
            //--TRIMMABLE-BOUNDARY-START(17182194610)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17182194610)
            
            static $h = 2325426;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$bMcF.LFCW.Widget; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477161906),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362063794,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426834866,
        "f": 83886081
      },
      "n": "Count",
      "d": 2325426,
      "h": 21477161906,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477161906),
//--TRIMMABLE-BOUNDARY-START(55836900274),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541932978,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606704050,
        "f": 83886081
      },
      "n": "Label",
      "d": 2325426,
      "h": 55836900274,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836900274),
//--TRIMMABLE-BOUNDARY-START(25772129202),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951998386,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016769458,
        "f": 83886081
      },
      "n": "Description",
      "d": 2325426,
      "h": 25772129202,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772129202)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182194610),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2325426,
      "h": 17182194610,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182194610)
  ],
  "h": 2325426,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "//Icon=mdi mdi-counter"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.MetricsCount.MetricsCountWidget`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}MetricsCount${separator}MetricsCountWidget`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2325426)
        
        

        //--TRIMMABLE-BOUNDARY-START(2194354)
        $asm.$cls(`$yyXP.LCFCPWF.FeatureWidget`, ($self) => class FeatureWidget extends $.$bMcF.LFCW.Widget
        {
            //--TRIMMABLE-BOUNDARY-START(77311605682)
            /*WidgetIcon*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(77311605682)
            
            //--TRIMMABLE-BOUNDARY-START(81606572978)
            /*Color*/ IconColor;
            //--TRIMMABLE-BOUNDARY-END(81606572978)
            
            //--TRIMMABLE-BOUNDARY-START(133146180530)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(133146180530)
            
            //--TRIMMABLE-BOUNDARY-START(30066965426)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(30066965426)
            
            //--TRIMMABLE-BOUNDARY-START(85901540274)
            /*string?*/ MoreLink = null;
            //--TRIMMABLE-BOUNDARY-END(85901540274)
            
            //--TRIMMABLE-BOUNDARY-START(25771998130)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\FeatureWidget.cs", 12);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771998130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771998130)
            
            //--TRIMMABLE-BOUNDARY-START(25771998130)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25771998130)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77311605682)
                this.Icon = $.$default($.$bMcF.LFCW.WidgetIcon);
                //--TRIMMABLE-BOUNDARY-END(77311605682)
                
                //--TRIMMABLE-BOUNDARY-START(81606572978)
                this.IconColor = $.$default($.$fPer.LCFCDM.Color);
                //--TRIMMABLE-BOUNDARY-END(81606572978)
                
            }
            static $h = 2194354;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$bMcF.LFCW.Widget; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311605682),
    {
      "p": 11611888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246834610,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103081409458,
        "f": 83886081
      },
      "n": "Icon",
      "d": 2194354,
      "h": 77311605682,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311605682),
//--TRIMMABLE-BOUNDARY-START(81606572978),
    {
      "p": 25987414,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836769202,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111671344050,
        "f": 83886081
      },
      "n": "IconColor",
      "d": 2194354,
      "h": 81606572978,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606572978),
//--TRIMMABLE-BOUNDARY-START(133146180530),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016638386,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128851213234,
        "f": 83886081
      },
      "n": "Title",
      "d": 2194354,
      "h": 133146180530,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133146180530),
//--TRIMMABLE-BOUNDARY-START(30066965426),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656900018,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491474866,
        "f": 83886081
      },
      "n": "Description",
      "d": 2194354,
      "h": 30066965426,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066965426),
//--TRIMMABLE-BOUNDARY-START(85901540274),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426703794,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120261278642,
        "f": 83886081
      },
      "n": "MoreLink",
      "d": 2194354,
      "h": 85901540274,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85901540274)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771998130),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2194354,
      "h": 25771998130,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771998130)
  ],
  "h": 2194354,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "//Icon=mdi mdi-feature-search"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.Feature.FeatureWidget`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}Feature${separator}FeatureWidget`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2194354)
        
        

        //--TRIMMABLE-BOUNDARY-START(2587570)
        $asm.$cls(`$yyXP.LCFCPWS$1.SubscribeWidget`, ($self) => class SubscribeWidget extends $.$bMcF.LFCW.Widget
        {
            //--TRIMMABLE-BOUNDARY-START(55837162418)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(55837162418)
            
            //--TRIMMABLE-BOUNDARY-START(17182456754)
            /*string?*/ ButtonText = null;
            //--TRIMMABLE-BOUNDARY-END(17182456754)
            
            //--TRIMMABLE-BOUNDARY-START(12887489458)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\SubscribeWidget.cs", 11);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887489458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887489458)
            
            //--TRIMMABLE-BOUNDARY-START(12887489458)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12887489458)
            
            static $h = 2587570;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$bMcF.LFCW.Widget; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55837162418),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362325938,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51542195122,
        "f": 83886081
      },
      "n": "Title",
      "d": 2587570,
      "h": 55837162418,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55837162418),
//--TRIMMABLE-BOUNDARY-START(17182456754),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772391346,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42952260530,
        "f": 83886081
      },
      "n": "ButtonText",
      "d": 2587570,
      "h": 17182456754,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182456754)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887489458),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2587570,
      "h": 12887489458,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887489458)
  ],
  "h": 2587570,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "//Icon=mdi mdi-message"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.Subscribe.SubscribeWidget`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}Subscribe${separator}SubscribeWidget`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2587570)
        
        

        //--TRIMMABLE-BOUNDARY-START(1997746)
        $asm.$cls(`$yyXP.LCFCPWC.ContactUsWidget`, ($self) => class ContactUsWidget extends $.$bMcF.LFCW.Widget
        {
            //--TRIMMABLE-BOUNDARY-START(81606376370)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(81606376370)
            
            //--TRIMMABLE-BOUNDARY-START(77311409074)
            /*string?*/ SubTitle = null;
            //--TRIMMABLE-BOUNDARY-END(77311409074)
            
            //--TRIMMABLE-BOUNDARY-START(21476834226)
            /*Type?*/ FormType = null;
            //--TRIMMABLE-BOUNDARY-END(21476834226)
            
            //--TRIMMABLE-BOUNDARY-START(17181866930)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\ContactUsWidget.cs", 11);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181866930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181866930)
            
            //--TRIMMABLE-BOUNDARY-START(17181866930)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17181866930)
            
            static $h = 1997746;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$bMcF.LFCW.Widget; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81606376370),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246638002,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016441778,
        "f": 83886081
      },
      "n": "Title",
      "d": 1997746,
      "h": 81606376370,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606376370),
//--TRIMMABLE-BOUNDARY-START(77311409074),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656703410,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426507186,
        "f": 83886081
      },
      "n": "SubTitle",
      "d": 1997746,
      "h": 77311409074,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311409074),
//--TRIMMABLE-BOUNDARY-START(21476834226),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066768818,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836572594,
        "f": 83886081
      },
      "n": "FormType",
      "d": 1997746,
      "h": 21476834226,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476834226)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181866930),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1997746,
      "h": 17181866930,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181866930)
  ],
  "h": 1997746,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "//Icon=mdi mdi-contacts"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.ContactUs.ContactUsWidget`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}ContactUs${separator}ContactUsWidget`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1997746)
        
        

        //--TRIMMABLE-BOUNDARY-START(1735602)
        $asm.$str(`$yyXP.LCFCPWB.BackgroundImageSize`, ($self) => class BackgroundImageSize extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Auto = 0;
            static Contain = 1;
            static Cover = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1735602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Auto": 0n,
                    "Contain": 1n,
                    "Cover": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296702898)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296702898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296702898)
            
            //--TRIMMABLE-BOUNDARY-START(4296702898)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296702898)
            
            static $h = 1735602;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591670194),
    {
      "t": 1735602,
      "n": "Auto",
      "d": 1735602,
      "h": 8591670194,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591670194),
//--TRIMMABLE-BOUNDARY-START(12886637490),
    {
      "t": 1735602,
      "n": "Contain",
      "d": 1735602,
      "h": 12886637490,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886637490),
//--TRIMMABLE-BOUNDARY-START(17181604786),
    {
      "t": 1735602,
      "n": "Cover",
      "d": 1735602,
      "h": 17181604786,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181604786)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296702898),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1735602,
      "h": 4296702898,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296702898)
  ],
  "h": 1735602
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.Banner.BackgroundImageSize`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}Banner${separator}BackgroundImageSize`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1735602)
        
        

        //--TRIMMABLE-BOUNDARY-START(1145778)
        $asm.$str(`$yyXP.LCFCP.PageBuilderFeatures`, ($self) => class PageBuilderFeatures extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static RazorComponents = 1;
            static TopToolBar = 2;
            static WidgetTopToolBar = 4;
            static WidgetBottomToolBar = 8;
            static WidgetLeftToolBar = 16;
            static WidgetRightToolBar = 32;
            static RecoverUnsavedChanges = 64;
            static Default = 60;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1145778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "RazorComponents": 1n,
                    "TopToolBar": 2n,
                    "WidgetTopToolBar": 4n,
                    "WidgetBottomToolBar": 8n,
                    "WidgetLeftToolBar": 16n,
                    "WidgetRightToolBar": 32n,
                    "RecoverUnsavedChanges": 64n,
                    "Default": 60n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296113074)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296113074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296113074)
            
            //--TRIMMABLE-BOUNDARY-START(4296113074)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296113074)
            
            static $h = 1145778;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886047666),
    {
      "t": 1145778,
      "n": "None",
      "d": 1145778,
      "h": 12886047666,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886047666),
//--TRIMMABLE-BOUNDARY-START(17181014962),
    {
      "t": 1145778,
      "n": "RazorComponents",
      "d": 1145778,
      "h": 17181014962,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181014962),
//--TRIMMABLE-BOUNDARY-START(25770949554),
    {
      "t": 1145778,
      "n": "TopToolBar",
      "d": 1145778,
      "h": 25770949554,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770949554),
//--TRIMMABLE-BOUNDARY-START(42950818738),
    {
      "t": 1145778,
      "n": "WidgetTopToolBar",
      "d": 1145778,
      "h": 42950818738,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950818738),
//--TRIMMABLE-BOUNDARY-START(30065916850),
    {
      "t": 1145778,
      "n": "WidgetBottomToolBar",
      "d": 1145778,
      "h": 30065916850,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065916850),
//--TRIMMABLE-BOUNDARY-START(34360884146),
    {
      "t": 1145778,
      "n": "WidgetLeftToolBar",
      "d": 1145778,
      "h": 34360884146,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360884146),
//--TRIMMABLE-BOUNDARY-START(38655851442),
    {
      "t": 1145778,
      "n": "WidgetRightToolBar",
      "d": 1145778,
      "h": 38655851442,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655851442),
//--TRIMMABLE-BOUNDARY-START(21475982258),
    {
      "t": 1145778,
      "n": "RecoverUnsavedChanges",
      "d": 1145778,
      "h": 21475982258,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475982258),
//--TRIMMABLE-BOUNDARY-START(8591080370),
    {
      "t": 1145778,
      "n": "Default",
      "d": 1145778,
      "h": 8591080370,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591080370)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296113074),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1145778,
      "h": 4296113074,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296113074)
  ],
  "h": 1145778,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.PageBuilderFeatures`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}PageBuilderFeatures`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1145778)
        
        

        //--TRIMMABLE-BOUNDARY-START(359346)
        $asm.$cls(`$yyXP.LCFCP._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590293938)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590293938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590293938)
            
            //--TRIMMABLE-BOUNDARY-START(4295326642)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295326642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295326642)
            
            //--TRIMMABLE-BOUNDARY-START(4295326642)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295326642)
            
            static $h = 359346;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590293938),
    {
      "r": 65537,
      "n": "Execute",
      "d": 359346,
      "h": 8590293938,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590293938)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295326642),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 359346,
      "h": 4295326642,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295326642)
  ],
  "h": 359346
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(359346)
        
        

        //--TRIMMABLE-BOUNDARY-START(1538994)
        $asm.$cls(`$yyXP.LCFCP.TemplatePreview`, ($self) => class TemplatePreview extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(64426048434)
            /*FluentUITemplateModel*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(64426048434)
            
            //--TRIMMABLE-BOUNDARY-START(47246179250)
            /*UIRootWidget */ get Root()
            {
                return $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$bMcF.LFCW.UIRootWidget, this.UI.Json, false, "Root", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\TemplatePreview.razor.cs", "Root", 16);
            }
            //--TRIMMABLE-BOUNDARY-END(47246179250)
            
            //--TRIMMABLE-BOUNDARY-START(42951211954)
            /*string */ get OptimizedComponentName()
            {
                return "templatepreview";
            }
            //--TRIMMABLE-BOUNDARY-END(42951211954)
            
            //--TRIMMABLE-BOUNDARY-START(60131081138)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131081138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "UI":
                    this.UI = $.$cast(parameter.Value, $.$Iaui.LCFCM.FluentUITemplateModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(60131081138)
            
            //--TRIMMABLE-BOUNDARY-START(12886440882)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886440882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$yyXP.LCFCP.PageBuilder, 0);
                __builder.AddComponentParameter(1, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCW.UIRootWidget, this.Root));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12886440882)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591473586)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591473586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591473586)
            
            //--TRIMMABLE-BOUNDARY-START(8591473586)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8591473586)
            
            static $h = 1538994;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64426048434),
    {
      "p": 9577814,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656244658,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836113842,
        "f": 83886081
      },
      "n": "UI",
      "d": 1538994,
      "h": 64426048434,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64426048434),
//--TRIMMABLE-BOUNDARY-START(47246179250),
    {
      "p": 9514736,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066310066,
        "f": 50331650
      },
      "n": "Root",
      "d": 1538994,
      "h": 47246179250,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47246179250),
//--TRIMMABLE-BOUNDARY-START(42951211954),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476375474,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1538994,
      "h": 42951211954,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42951211954)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131081138),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1538994,
      "h": 60131081138,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60131081138),
//--TRIMMABLE-BOUNDARY-START(12886440882),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1538994,
      "h": 12886440882,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886440882)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591473586),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1538994,
      "h": 8591473586,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591473586)
  ],
  "h": 1538994
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.TemplatePreview`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}TemplatePreview`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1538994)
        
        

        //--TRIMMABLE-BOUNDARY-START(687026)
        $asm.$cls(`$yyXP.LCFCP.ComponentThumbnail`, ($self) => class ComponentThumbnail extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(81605065650)
            /*Type*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(81605065650)
            
            //--TRIMMABLE-BOUNDARY-START(17180556210)
            /*PageBuilder*/ Builder = null;
            //--TRIMMABLE-BOUNDARY-END(17180556210)
            
            //--TRIMMABLE-BOUNDARY-START(25770490802)
            /*void */ DragStart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770490802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Builder.DragComponent = this.Type;
            }
            //--TRIMMABLE-BOUNDARY-END(25770490802)
            
            //--TRIMMABLE-BOUNDARY-START(55835261874)
            /*string */ get OptimizedComponentName()
            {
                return "componentthumbnail";
            }
            //--TRIMMABLE-BOUNDARY-END(55835261874)
            
            //--TRIMMABLE-BOUNDARY-START(77310098354)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310098354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Type":
                    this.Type = $.$cast(parameter.Value, $.$$.S.Type);
                    return true;
                    case "Builder":
                    this.Builder = $.$cast(parameter.Value, $.$yyXP.LCFCP.PageBuilder);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(77310098354)
            
            //--TRIMMABLE-BOUNDARY-START(21475523506)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475523506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "text-center stack");
                __builder.AddAttribute$5(2, "draggable", "true");
                __builder.AddAttribute$7($.$macw.MACW.DragEventArgs, 3, "ondragstart", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.DragEventArgs, this, new $.$$.S.Action().$ctor(this, this.DragStart)));
                __builder.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 4);
                __builder.AddComponentParameter(5, "title", this.Type.Name);
                __builder.AddComponentParameter(6, "Class", "mgx-a mgt-1 mgb wx-07 hx-07 clickable pos-rel clip corner-1 flex");
                __builder.AddComponentParameter(7, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ & ~16/*CardFeatures.Pad*/), $.$hDPm.LCFCCC$1.CardFeatures));
                __builder.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    /*var*/ let icon = $.$fPer.LCFCT.TypesExtensions.GetIcon(this.Type);
                    __builder2.OpenElement(9, "i");
                    __builder2.AddAttribute$5(10, "class", $.$strNN($.$strNN((icon.Icon ?? "mdi mdi-video-input-component"/*MaterialDesignIconNames.VideoInputComponent*/)) + " mg-a") + " fsz-50");
                    __builder2.CloseElement();
                }), $TWudth ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":687026,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(11, "\r\n        ");
                __builder.OpenElement(12, "small");
                __builder.AddContent$4(13, $.$$.S.String.Replace$3.call(this.Type.Name, "Widget", ""));
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(21475523506)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885588914)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885588914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885588914)
            
            //--TRIMMABLE-BOUNDARY-START(12885588914)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885588914)
            
            static $h = 687026;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605065650),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540294578,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015131058,
        "f": 83886081
      },
      "n": "Type",
      "d": 687026,
      "h": 81605065650,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605065650),
//--TRIMMABLE-BOUNDARY-START(17180556210),
    {
      "p": 1080242,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360425394,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425196466,
        "f": 83886081
      },
      "n": "Builder",
      "d": 687026,
      "h": 17180556210,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180556210),
//--TRIMMABLE-BOUNDARY-START(55835261874),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950359986,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 687026,
      "h": 55835261874,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55835261874)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770490802),
    {
      "r": 65537,
      "n": "DragStart",
      "d": 687026,
      "h": 25770490802,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770490802),
//--TRIMMABLE-BOUNDARY-START(77310098354),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 687026,
      "h": 77310098354,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310098354),
//--TRIMMABLE-BOUNDARY-START(21475523506),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 687026,
      "h": 21475523506,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475523506)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885588914),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 687026,
      "h": 12885588914,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885588914)
  ],
  "h": 687026
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.ComponentThumbnail`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}ComponentThumbnail`; }
        });
        //--TRIMMABLE-BOUNDARY-END(687026)
        
        

        //--TRIMMABLE-BOUNDARY-START(621490)
        $asm.$cls(`$yyXP.LCFCP.ComponentNavigator`, ($self) => class ComponentNavigator extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(12885523378)
            /*PageBuilder*/ Builder = null;
            //--TRIMMABLE-BOUNDARY-END(12885523378)
            
            //--TRIMMABLE-BOUNDARY-START(51540229042)
            /*Dictionary<Widget, bool>*/ opened = null;
            //--TRIMMABLE-BOUNDARY-END(51540229042)
            
            //--TRIMMABLE-BOUNDARY-START(47245261746)
            /*bool */ IsOpen(/*Widget*/ widget)
            {
                /*var*/ let open;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245261746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (widget === this.Builder.Root)
                {
                    return true;
                }
                if (this.opened.TryGetValue(widget, $.$ref(() => open, ($v) => open = $v, $.$$.S.Boolean)))
                {
                    return open;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(47245261746)
            
            //--TRIMMABLE-BOUNDARY-START(68720098226)
            /*void */ ToggleOpen(/*Widget*/ widget)
            {
                /*var*/ let open;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720098226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.opened.TryGetValue(widget, $.$ref(() => open, ($v) => open = $v, $.$$.S.Boolean)))
                {
                    open = !open;
                    this.opened.set_Item(widget, open);
                }
                else 
                {
                    this.opened.set_Item(widget, true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720098226)
            
            //--TRIMMABLE-BOUNDARY-START(73015065522)
            /*ValueTask */ ToggleVisibility(/*Widget*/ widget)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015065522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                widget.Visible = !widget.Visible;
                return this.Builder.Renderers.get_Item(widget).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\ComponentNavigator.razor.cs", "ToggleVisibility", 47);
            }
            //--TRIMMABLE-BOUNDARY-END(73015065522)
            
            //--TRIMMABLE-BOUNDARY-START(21475457970)
            /*ValueTask */ Click(/*Widget*/ widget)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475457970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Builder.SetSelected(widget, false);
            }
            //--TRIMMABLE-BOUNDARY-END(21475457970)
            
            //--TRIMMABLE-BOUNDARY-START(55835196338)
            /*string */ get OptimizedComponentName()
            {
                return "componentnavigator";
            }
            //--TRIMMABLE-BOUNDARY-END(55835196338)
            
            //--TRIMMABLE-BOUNDARY-START(77310032818)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310032818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch3 = parameter.Name;
                switch($switch3)
                {
                    case "Builder":
                    this.Builder = $.$cast(parameter.Value, $.$yyXP.LCFCP.PageBuilder);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(77310032818)
            
            //--TRIMMABLE-BOUNDARY-START(17180490674)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180490674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetNode(this.Builder.Root));
            }
            //--TRIMMABLE-BOUNDARY-END(17180490674)
            
            //--TRIMMABLE-BOUNDARY-START(42950294450)
            /*RenderFragment */ GetNode(/*Widget*/ widget)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950294450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(1, "\r\n        ");
                    __builder2.OpenElement(2, "div");
                    __builder2.AddAttribute$5(3, "class", "pdl-1");
                    __builder2.OpenElement(4, "div");
                    __builder2.AddAttribute$5(5, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("bg-" + $.$strNN((widget === this.Builder.Selected ? "primary-03" : "card"))) + " clickable") + " pd-2") + " bdl") + " bdr") + " bdt") + " flex");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 6, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                    {
                        return this.Click(widget);
                    }, $gDfvld ??= {"r":65537,"n":"","d":621490,"h":0,"f":17825794})));
                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 7, "onclick", true);
                    __builder2.OpenElement(8, "i");
                    __builder2.AddAttribute$5(9, "class", $.$strNN($.$strNN("mdi" + " mdi-chevron-") + $.$strNN((this.IsOpen(widget) ? "down" : "right"))) + " clickable");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 10, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                    {
                        return this.ToggleOpen(widget);
                    }, $BsxSgl ??= {"r":65537,"n":"","d":621490,"h":0,"f":17825794})));
                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 11, "onclick", true);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(12, "\r\n                ");
                    __builder2.AddContent$4(13, widget.Name);
                    if (widget !== this.Builder.Root)
                    {
                        __builder2.AddMarkupContent(14, "<div class=\"fill\"></div>\r\n                        ");
                        __builder2.OpenElement(15, "i");
                        __builder2.AddAttribute$5(16, "class", "mdi mdi-content-copy clickable mgl-1");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 17, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                        {
                            return this.Builder.Copy(widget);
                        }, $ANrfhg ??= {"r":65537,"n":"","d":621490,"h":0,"f":17825794})));
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 18, "onclick", true);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(19, "\r\n                        ");
                        __builder2.OpenElement(20, "i");
                        __builder2.AddAttribute$5(21, "class", "mdi mdi-content-duplicate clickable mgl-1");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 22, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                        {
                            return this.Builder.Duplicate(widget);
                        }, $IckPZj ??= {"r":65537,"n":"","d":621490,"h":0,"f":17825794})));
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 23, "onclick", true);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(24, "\r\n                        ");
                        __builder2.OpenElement(25, "i");
                        __builder2.AddAttribute$5(26, "class", "mdi mdi-chevron-up clickable mgl-1");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 27, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                        {
                            return this.Builder.Up(widget);
                        }, $ginMjb ??= {"r":65537,"n":"","d":621490,"h":0,"f":17825794})));
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 28, "onclick", true);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(29, "\r\n                        ");
                        __builder2.OpenElement(30, "i");
                        __builder2.AddAttribute$5(31, "class", "mdi mdi-chevron-down clickable mgl-1");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 32, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                        {
                            return this.Builder.Down(widget);
                        }, $CxVnCk ??= {"r":65537,"n":"","d":621490,"h":0,"f":17825794})));
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 33, "onclick", true);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(34, "\r\n                        ");
                        __builder2.OpenElement(35, "i");
                        __builder2.AddAttribute$5(36, "class", $.$strNN($.$strNN($.$strNN("mdi" + " mdi-eye") + $.$strNN((!widget.Visible ? "-off" : ""))) + " clickable") + " mgl-1");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 37, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                        {
                            return this.ToggleVisibility(widget);
                        }, $RpShHf ??= {"r":65537,"n":"","d":621490,"h":0,"f":17825794})));
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 38, "onclick", true);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(39, "\r\n                        ");
                        __builder2.OpenElement(40, "i");
                        __builder2.AddAttribute$5(41, "class", "mdi mdi-delete cl-error clickable mgl-1");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 42, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                        {
                            return this.Builder.Remove(widget);
                        }, $zBRuei ??= {"r":65537,"n":"","d":621490,"h":0,"f":17825794})));
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 43, "onclick", true);
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    let container;
                    if ($.$is(widget, $.$bMcF.LFCW.ContainerWidget, { set $v($v){ container = $v; } }) && this.IsOpen(widget))
                    {
                        let $en4 = container.Children.SCG$IEnumerable$$$GetEnumerator();
                        while ($en4.SC$1$IEnumerator$MoveNext())
                        {
                            let child = $en4.SCG$IEnumerator$$$Current;
                            {
                                __builder2.AddContent$1(44, this.GetNode(child));
                            }
                        }
                    }
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(45, "\r\n        ");
                }, $uZmqpj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":621490,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(42950294450)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590556082)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590556082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590556082)
            
            //--TRIMMABLE-BOUNDARY-START(8590556082)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590556082)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51540229042)
                this.opened = new ($.$$.SCG.Dictionary$$$($.$bMcF.LFCW.Widget, $.$$.S.Boolean))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(51540229042)
                
            }
            static $h = 621490;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885523378),
    {
      "p": 1080242,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065392562,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425130930,
        "f": 83886081
      },
      "n": "Builder",
      "d": 621490,
      "h": 12885523378,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885523378),
//--TRIMMABLE-BOUNDARY-START(55835196338),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655327154,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 621490,
      "h": 55835196338,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55835196338)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245261746),
    {
      "r": 262145,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        }
      ],
      "n": "IsOpen",
      "d": 621490,
      "h": 47245261746,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245261746),
//--TRIMMABLE-BOUNDARY-START(68720098226),
    {
      "r": 65537,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        }
      ],
      "n": "ToggleOpen",
      "d": 621490,
      "h": 68720098226,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720098226),
//--TRIMMABLE-BOUNDARY-START(73015065522),
    {
      "r": 181338113,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        }
      ],
      "n": "ToggleVisibility",
      "d": 621490,
      "h": 73015065522,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015065522),
//--TRIMMABLE-BOUNDARY-START(21475457970),
    {
      "r": 181338113,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        }
      ],
      "n": "Click",
      "d": 621490,
      "h": 21475457970,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475457970),
//--TRIMMABLE-BOUNDARY-START(77310032818),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 621490,
      "h": 77310032818,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310032818),
//--TRIMMABLE-BOUNDARY-START(17180490674),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 621490,
      "h": 17180490674,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180490674),
//--TRIMMABLE-BOUNDARY-START(42950294450),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        }
      ],
      "n": "GetNode",
      "d": 621490,
      "h": 42950294450,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950294450)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540229042),
    {
      "t": $.$$.SCG.Dictionary$$$($.$bMcF.LFCW.Widget, $.$$.S.Boolean).$h,
      "n": "opened",
      "d": 621490,
      "h": 51540229042,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540229042)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590556082),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 621490,
      "h": 8590556082,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590556082)
  ],
  "h": 621490
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.ComponentNavigator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}ComponentNavigator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(621490)
        
        

        //--TRIMMABLE-BOUNDARY-START(1670066)
        $asm.$cls(`$yyXP.LCFCP.WidgetRenderer`, ($self) => class WidgetRenderer extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(240519838642)
            /*string */ get OptimizedComponentName()
            {
                return "widgetrenderer";
            }
            //--TRIMMABLE-BOUNDARY-END(240519838642)
            
            //--TRIMMABLE-BOUNDARY-START(326419184562)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326419184562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Property":
                    this.Property = $.$cast(parameter.Value, $.$$.SR.PropertyInfo);
                    return true;
                    case "Widget":
                    this.Widget = $.$cast(parameter.Value, $.$bMcF.LFCW.Widget);
                    return true;
                    case "Builder":
                    this.Builder = $.$cast(parameter.Value, $.$yyXP.LCFCP.PageBuilder);
                    return true;
                    case "DataSource":
                    this.DataSource = $.$cast(parameter.Value, $.$bMcF.LFCD.IWidgetDataSource);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(326419184562)
            
            //--TRIMMABLE-BOUNDARY-START(223339969458)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339969458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Context = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFC.IApplicationContextProvider, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(223339969458)
            
            //--TRIMMABLE-BOUNDARY-START(30066441138)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066441138);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066441138)
            
            //--TRIMMABLE-BOUNDARY-START(77311081394)
            /*IApplicationContextProvider*/ Context = null;
            //--TRIMMABLE-BOUNDARY-END(77311081394)
            
            //--TRIMMABLE-BOUNDARY-START(249109773234)
            /*PropertyInfo*/ Property = null;
            //--TRIMMABLE-BOUNDARY-END(249109773234)
            
            //--TRIMMABLE-BOUNDARY-START(339304086450)
            /*Widget*/ Widget = null;
            //--TRIMMABLE-BOUNDARY-END(339304086450)
            
            //--TRIMMABLE-BOUNDARY-START(51541277618)
            /*PageBuilder*/ Builder = null;
            //--TRIMMABLE-BOUNDARY-END(51541277618)
            
            //--TRIMMABLE-BOUNDARY-START(85901015986)
            /*IWidgetDataSource*/ DataSource = null;
            //--TRIMMABLE-BOUNDARY-END(85901015986)
            
            //--TRIMMABLE-BOUNDARY-START(60131212210)
            /*IEnumerable<Widget>? */ get ChildContents()
            {
                return (($.$as(this.Widget, $.$bMcF.LFCW.ContainerWidget))?.Children ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(60131212210)
            
            //--TRIMMABLE-BOUNDARY-START(231929904050)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929904050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Builder.Renderers.set_Item(this.Widget, this);
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(231929904050)
            
            //--TRIMMABLE-BOUNDARY-START(90195983282)
            /*void */ Dispose()
            {
                /*var*/ let rd;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195983282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Builder.Renderers.TryGetValue(this.Widget, $.$ref(() => rd, ($v) => rd = $v, $.$yyXP.LCFCP.WidgetRenderer)) && rd === this)
                {
                    this.Builder.Renderers.Remove$1(this.Widget);
                }
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(90195983282)
            
            //--TRIMMABLE-BOUNDARY-START(236224871346)
            /*void */ OnParametersSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224871346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.OnParametersSet();
            }
            //--TRIMMABLE-BOUNDARY-END(236224871346)
            
            //--TRIMMABLE-BOUNDARY-START(124555721650)
            /*string */ get FullTitle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095329202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let prefix = this.Title;
                if (prefix !== null)
                {
                    prefix += ": ";
                }
                return $.$strNN(prefix) + $.$strNN(this.Title);
            }
            //--TRIMMABLE-BOUNDARY-END(124555721650)
            
            //--TRIMMABLE-BOUNDARY-START(227634936754)
            /*string */ NameFrom(/*string*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634936754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ss = $.$$.S.String.Split$5.call(type, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*.*/ 46], [-1], null));
                return $.$$.System.Array.$ReadT1.call(ss, ((ss.length - 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(227634936754)
            
            //--TRIMMABLE-BOUNDARY-START(68721146802)
            /*ValueTask */ Clicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721146802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Builder.SetSelected(this.Widget, true);
            }
            //--TRIMMABLE-BOUNDARY-END(68721146802)
            
            //--TRIMMABLE-BOUNDARY-START(111670819762)
            /*ValueTask */ Drop()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670819762);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.DropOn(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111670819762)
            
            //--TRIMMABLE-BOUNDARY-START(107375852466)
            /*ValueTask */ DragStart()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375852466);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.DragComponentStart(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107375852466)
            
            //--TRIMMABLE-BOUNDARY-START(98785917874)
            /*ValueTask */ DragEnter()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98785917874);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.DragEnter(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785917874)
            
            //--TRIMMABLE-BOUNDARY-START(103080885170)
            /*ValueTask */ DragLeave()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103080885170);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.DragLeave(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080885170)
            
            //--TRIMMABLE-BOUNDARY-START(64426179506)
            /*ValueTask */ ChooseAndAddComponent()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426179506);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.ChooseAndAddComponent(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426179506)
            
            //--TRIMMABLE-BOUNDARY-START(120260754354)
            /*ValueTask */ EditAttributes()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120260754354);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.EditAttributes(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120260754354)
            
            //--TRIMMABLE-BOUNDARY-START(330714151858)
            /*ValueTask */ Unbind()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(330714151858);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.Unbind(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(330714151858)
            
            //--TRIMMABLE-BOUNDARY-START(94490950578)
            /*ValueTask */ Down()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490950578);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.Down(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490950578)
            
            //--TRIMMABLE-BOUNDARY-START(335009119154)
            /*ValueTask */ Up()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(335009119154);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.Up(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(335009119154)
            
            //--TRIMMABLE-BOUNDARY-START(115965787058)
            /*ValueTask */ Duplicate()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965787058);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.Duplicate(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115965787058)
            
            //--TRIMMABLE-BOUNDARY-START(253404740530)
            /*ValueTask */ Remove()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(253404740530);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.Remove(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253404740530)
            
            //--TRIMMABLE-BOUNDARY-START(81606048690)
            /*ValueTask */ Copy()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81606048690);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.Copy(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81606048690)
            
            //--TRIMMABLE-BOUNDARY-START(244814805938)
            /*ValueTask */ Paste()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244814805938);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.Paste(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244814805938)
            
            //--TRIMMABLE-BOUNDARY-START(38656375730)
            /*ValueTask */ AddLeftColumn()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656375730);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.AddLeftColumn(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656375730)
            
            //--TRIMMABLE-BOUNDARY-START(42951343026)
            /*ValueTask */ AddRightColumn()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951343026);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.AddRightColumn(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951343026)
            
            //--TRIMMABLE-BOUNDARY-START(47246310322)
            /*ValueTask */ AddTopRow()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246310322);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.AddTopRow(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246310322)
            
            //--TRIMMABLE-BOUNDARY-START(34361408434)
            /*ValueTask */ AddBottomRow()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361408434);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Builder.AddBottomRow(this.Widget);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361408434)
            
            //--TRIMMABLE-BOUNDARY-START(322124217266)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124217266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.FluentUI.Core.Widgets.Widget>?*/ let __ca1__;
                return $.$strNN($.$strNN(((this.Widget?.ToString() ?? null) ?? "Root")) + " => ") + $.$strNN($.$$.S.String.Join$5(", ", ((__ca1__ = this.ChildContents) !== null ? ($.$sl.SL.Enumerable.Select$1($.$bMcF.LFCW.Widget, $.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$bMcF.LFCW.Widget, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.ToString();
                }, $HGlqya ??= {"r":1310721,"p":[{"n":"s","p":9907952}],"n":"","d":1670066,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$$.S.String)) : $.$sl.SL.Enumerable.Empty($.$$.S.String))));
            }
            //--TRIMMABLE-BOUNDARY-END(322124217266)
            
            //--TRIMMABLE-BOUNDARY-START(73016114098)
            /*IBaseComponent*/ Component = null;
            //--TRIMMABLE-BOUNDARY-END(73016114098)
            
            //--TRIMMABLE-BOUNDARY-START(313534282674)
            /*object */ get Target()
            {
                return $.$cast(this.Component, $.$$.S.Object) ?? this.Widget;
            }
            //--TRIMMABLE-BOUNDARY-END(313534282674)
            
            //--TRIMMABLE-BOUNDARY-START(317829249970)
            /*string? */ get Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455067570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.Frameworks.Client.Components.IBaseComponent*/ let __ca2__;
                /*System.Type*/ let __ca3__;
                const $t3 = this.Widget;
                return (this.Widget?.Name ?? null) ?? (this.Widget?.Type ?? null) ?? $.$ifnn($t3, ($t) => $.$$.S.Object.GetType.call($t).Name) ?? ((__ca2__ = this.Component) !== null ? ((__ca3__ = $.$$.S.Object.GetType.call(__ca2__)) !== null ? __ca3__.Name : null) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(317829249970)
            
            //--TRIMMABLE-BOUNDARY-START(257699707826)
            /*RenderFragment? */ RenderWidget(/*Widget*/ widget)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699707826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let cWidget;
                if ($.$is(widget, $.$bMcF.LFCW.ComponentWidget, { set $v($v){ cWidget = $v; } }))
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                    {
                        /*var*/ let type = $.$yyXP.LCFCP.ComponentBrowser.Get(cWidget.TypeName);
                        builder.OpenComponent(1, type);
                        let $en4 = this.Widget.Attributes.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            let kv = $en4.Current;
                            {
                                /*var*/ let property = type.GetProperty$6(kv.Key);
                                if ($.$$.SR.PropertyInfo.op_Inequality$1(property, null))
                                {
                                    /*var*/ let propertyType = property.PropertyType;
                                    if (kv.Value !== null)
                                    {
                                        if (propertyType.IsAssignableFrom($.$$.S.Object.GetType.call(kv.Value)))
                                        {
                                            if (property.PropertyType === $.$$.S.String.$type)
                                            {
                                                builder.AddAttribute$5(2, kv.Key, $.$bMcF.LFCD.DataBindingExtension.Bind($.$dsp(kv.Value, $.$$.S.Object, ($t) => $t.ToString), cWidget, this.DataSource, null, false));
                                            }
                                            else 
                                            {
                                                builder.AddAttribute$4(2, kv.Key, kv.Value);
                                            }
                                        }
                                        else 
                                        {
                                            if (property.PropertyType === $.$$.S.String.$type)
                                            {
                                                builder.AddAttribute$5(2, kv.Key, $.$bMcF.LFCD.DataBindingExtension.Bind($.$dsp(kv.Value, $.$$.S.Object, ($t) => $t.ToString), cWidget, this.DataSource, null, false));
                                            }
                                            else 
                                            {
                                                /*var*/ let value = $.$sct.SC.TypeDescriptor.GetConverter$2(propertyType).ConvertFromInvariantString$1($.$dsp(kv.Value, $.$$.S.Object, ($t) => $t.ToString));
                                                builder.AddAttribute$4(2, kv.Key, value);
                                            }
                                        }
                                    }
                                    else 
                                    {
                                        if (property.PropertyType === $.$$.S.String.$type)
                                        {
                                            builder.AddAttribute$5(2, kv.Key, $.$bMcF.LFCD.DataBindingExtension.Bind($.$dsp(kv.Value, $.$$.S.Object, ($t) => $t.ToString), cWidget, this.DataSource, null, false));
                                        }
                                        else 
                                        {
                                            builder.AddAttribute$4(2, kv.Key, kv.Value);
                                        }
                                    }
                                }
                                else 
                                {
                                    builder.AddAttribute$4(2, kv.Key, kv.Value !== null ? $.$bMcF.LFCD.DataBindingExtension.Bind($.$dsp(kv.Value, $.$$.S.Object, ($t) => $t.ToString), cWidget, this.DataSource, null, false) : kv.Value);
                                }
                            }
                        }
                        /*var*/ let fragmentProperties = $.$sl.SL.Enumerable.Where($.$$.SR.PropertyInfo, type.GetProperties(), new ($.$$.S.Func$$$($.$$.SR.PropertyInfo, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                        {
                            return p.PropertyType === $.$mac.MAC.RenderFragment.$type;
                        }, $oBzYzd ??= {"r":262145,"p":[{"n":"p","p":119603201}],"n":"","d":1670066,"h":0,"f":17825794}));
                        let $en5 = fragmentProperties.SCG$IEnumerable$$$GetEnumerator();
                        while ($en5.SC$1$IEnumerator$MoveNext())
                        {
                            let property = $en5.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let childWidgets = cWidget.Children.ContainsKey(property.Name) ? cWidget.Children.get_Item(property.Name) : null;
                                if (childWidgets === null && (((this.Builder?.Mode ?? null) ?? 0/*PageBuilderMode.Read*/) !== 0/*PageBuilderMode.Read*/))
                                {
                                    childWidgets = new ($.$$.SCG.List$$($.$bMcF.LFCW.Widget))().$ctor$1();
                                    cWidget.Children.set_Item(property.Name, childWidgets);
                                }
                                if (childWidgets !== null)
                                {
                                    builder.AddAttribute$3(3, property.Name, new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*_builder*/ _builder) =>
                                    {
                                        _builder.OpenComponent(4, $.$yyXP.LCFCP.WidgetRenderer.$type);
                                        _builder.AddAttribute$4(6, "Property", property);
                                        _builder.AddAttribute$4(7, "Widget", childWidgets);
                                        _builder.AddAttribute$5(8, "Title", property.Name);
                                        _builder.AddAttribute$4(9, "Builder", this.Builder);
                                        _builder.AddAttribute$4(10, "DataSource", this.DataSource);
                                        _builder.CloseComponent();
                                    }), $auZeYe ??= {"r":65537,"p":[{"n":"_builder","p":7536755}],"n":"","d":1670066,"h":0,"f":17825794}));
                                }
                            }
                        }
                        builder.AddComponentReferenceCapture(7, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*component*/ component) =>
                        {
                            this.Component = $.$as(component, $.$hDPm.LCFCC$1.IBaseComponent);
                        }, $LpeqEf ??= {"r":65537,"p":[{"n":"component","p":131073}],"n":"","d":1670066,"h":0,"f":17825794}));
                        builder.CloseComponent();
                    }, $VPeeOk ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1670066,"h":0,"f":17825794});
                }
                return $.$bMcF.LFC.WidgetRendererExtension.Render($.$mac.MAC.RenderFragment, widget, this.DataSource ?? this.Builder.DataSource, this.Builder);
            }
            //--TRIMMABLE-BOUNDARY-END(257699707826)
            
            //--TRIMMABLE-BOUNDARY-START(55836244914)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836244914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((this.Builder?.Mode ?? null) ?? 0/*PageBuilderMode.Read*/) === 1/*PageBuilderMode.EditDragDrop*/)
                {
                    __builder.OpenElement(0, "span");
                    /*System.Collections.Generic.IEnumerable<LivingThing.FluentUI.Core.Widgets.Widget>?*/ let __ca1__;
                    __builder.AddAttribute$5(1, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("fragment " + $.$strNN(this.Widget.Type)) + $.$strNN(($.$$.SR.PropertyInfo.op_Inequality$1(this.Property, null) ? " " + $.$strNN(this.Property.Name) : ""))) + $.$strNN((!this.Widget.Visible ? " hidden" : ""))) + $.$strNN((((__ca1__ = this.ChildContents) !== null ? $.$sl.SL.Enumerable.Count$1($.$bMcF.LFCW.Widget, __ca1__) : null) === 0 ? " empty" : ""))) + $.$strNN(((this.Builder?.Selected ?? null) === this.Widget ? " selected" : ""))) + $.$strNN((this.Builder.DragOver === this.Widget && this.ChildContents !== null ? " dragOver" : "")));
                    __builder.AddAttribute$5(2, "ondragover", "event.preventDefault()");
                    __builder.AddAttribute$7($.$macw.MACW.DragEventArgs, 3, "ondragstart", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.DragEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.DragStart)));
                    __builder.AddAttribute$7($.$macw.MACW.DragEventArgs, 4, "ondrop", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.DragEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Drop)));
                    __builder.AddAttribute$7($.$macw.MACW.DragEventArgs, 5, "ondragenter", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.DragEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.DragEnter)));
                    __builder.AddAttribute$7($.$macw.MACW.DragEventArgs, 6, "ondragleave", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.DragEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.DragLeave)));
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 7, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Clicked)));
                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder, 8, "ondragstart", true);
                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder, 9, "ondrop", true);
                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder, 10, "onclick", true);
                    __builder.AddAttribute$5(11, "tabindex", "-1");
                    //if (false) { ... }
                    //else 
                    {
                        if (((this.Builder.Features & (4/*PageBuilderFeatures.WidgetTopToolBar*/)) == (4/*PageBuilderFeatures.WidgetTopToolBar*/)))
                        {
                            __builder.OpenElement(29, "div");
                            __builder.AddAttribute$5(30, "class", "menu pos-abs l-0 t-0 flex");
                            __builder.AddContent$1(31, this.WidgetTopToolBar(false));
                            __builder.CloseElement();
                        }
                        if (((this.Builder.Features & (32/*PageBuilderFeatures.WidgetRightToolBar*/)) == (32/*PageBuilderFeatures.WidgetRightToolBar*/)))
                        {
                            __builder.OpenElement(32, "div");
                            __builder.AddAttribute$5(33, "class", "menu pos-abs r-0 t-0 b-0 flex");
                            __builder.OpenElement(34, "div");
                            __builder.AddAttribute$5(35, "class", "mgy-a");
                            __builder.AddContent$1(36, this.WidgetRightToolBar());
                            __builder.CloseElement();
                            __builder.CloseElement();
                        }
                        if (((this.Builder.Features & (16/*PageBuilderFeatures.WidgetLeftToolBar*/)) == (16/*PageBuilderFeatures.WidgetLeftToolBar*/)))
                        {
                            __builder.OpenElement(37, "div");
                            __builder.AddAttribute$5(38, "class", "menu pos-abs l-0 t-0 b-0 flex");
                            __builder.OpenElement(39, "div");
                            __builder.AddAttribute$5(40, "class", "mgy-a");
                            __builder.AddContent$1(41, this.WidgetLeftToolBar());
                            __builder.CloseElement();
                            __builder.CloseElement();
                        }
                        if (((this.Builder.Features & (8/*PageBuilderFeatures.WidgetBottomToolBar*/)) == (8/*PageBuilderFeatures.WidgetBottomToolBar*/)))
                        {
                            __builder.OpenElement(42, "div");
                            __builder.AddAttribute$5(43, "class", "menu pos-abs l-0 r-0 b-0 flex");
                            __builder.OpenElement(44, "div");
                            __builder.AddAttribute$5(45, "class", "mgx-a");
                            __builder.AddContent$1(46, this.WidgetBottomToolBar());
                            __builder.CloseElement();
                            __builder.CloseElement();
                        }
                    }
                    $.$yyXP._LCFCPW.TypeInference.CreateCascadingValue_0($.$yyXP.LCFCP.WidgetRenderer, __builder, 47, 48, this, 49, true, 50, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$1(51, this.RenderWidget(this.Widget));
                    }, $nsMExk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1670066,"h":0,"f":17825794}));
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.AddContent$1(52, this.RenderWidget(this.Widget));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836244914)
            
            //--TRIMMABLE-BOUNDARY-START(347894021042)
            /*RenderFragment */ WidgetLeftToolBar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894021042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(53, "\r\n        ");
                    __builder2.OpenElement(54, "div");
                    __builder2.AddAttribute$5(55, "title", "Add Left Column");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 56, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.AddLeftColumn)));
                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 57, "onclick", true);
                    __builder2.AddMarkupContent(58, "<i class=\"mdi mdi-plus\"></i>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(59, "\r\n    ");
                }, $WjNYRb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1670066,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(347894021042)
            
            //--TRIMMABLE-BOUNDARY-START(352188988338)
            /*RenderFragment */ WidgetRightToolBar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188988338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(60, "\r\n        ");
                    __builder2.OpenElement(61, "div");
                    __builder2.AddAttribute$5(62, "title", "Add Right Column");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 63, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.AddRightColumn)));
                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 64, "onclick", true);
                    __builder2.AddMarkupContent(65, "<i class=\"mdi mdi-plus\"></i>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(66, "\r\n    ");
                }, $oqqXub ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1670066,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(352188988338)
            
            //--TRIMMABLE-BOUNDARY-START(343599053746)
            /*RenderFragment */ WidgetBottomToolBar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343599053746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(67, "\r\n        ");
                    __builder2.OpenElement(68, "div");
                    __builder2.AddAttribute$5(69, "title", "Add Bottom Row");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 70, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.AddBottomRow)));
                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 71, "onclick", true);
                    __builder2.AddMarkupContent(72, "<i class=\"mdi mdi-plus\"></i>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(73, "\r\n    ");
                }, $lEgiZa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1670066,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(343599053746)
            
            //--TRIMMABLE-BOUNDARY-START(356483955634)
            /*RenderFragment */ WidgetTopToolBar(/*bool*/ label)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483955634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(74, "\r\n        ");
                    __builder2.OpenElement(75, "span");
                    __builder2.AddAttribute$5(76, "class", "pdx");
                    __builder2.AddContent$4(77, this.Widget.Name);
                    __builder2.CloseElement();
                    if (this.Context.LCFC$IApplicationContextProvider$IsMobile)
                    {
                        __builder2.OpenElement(78, "div");
                        __builder2.AddAttribute$5(79, "title", "Add Content");
                        __builder2.AddAttribute$5(80, "class", `${$.$strNN((label ? "nowrap" : ""))}`);
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 81, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.ChooseAndAddComponent)));
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 82, "onclick", true);
                        __builder2.AddMarkupContent(83, "<i class=\"mdi mdi-plus\"></i>");
                        if (label)
                        {
                            __builder2.AddContent$4(84, "Add Content");
                        }
                        __builder2.CloseElement();
                    }
                    __builder2.OpenElement(85, "div");
                    __builder2.AddAttribute$5(86, "title", "Properties");
                    __builder2.AddAttribute$5(87, "class", `${$.$strNN((label ? "nowrap" : ""))}`);
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 88, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.EditAttributes)));
                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 89, "onclick", true);
                    __builder2.AddMarkupContent(90, "<i class=\"mdi mdi-menu\"></i>");
                    if (label)
                    {
                        __builder2.AddContent$4(91, "Properties");
                    }
                    __builder2.CloseElement();
                    if (this.Widget !== this.Builder.Root)
                    {
                        __builder2.OpenElement(92, "div");
                        __builder2.AddAttribute$5(93, "class", `${$.$strNN((label ? "nowrap" : ""))}`);
                        __builder2.AddAttribute$5(94, "title", "Unbind");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 95, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Unbind)));
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 96, "onclick", true);
                        __builder2.AddMarkupContent(97, "<i class=\"mdi mdi-scissors-cutting\"></i>");
                        if (label)
                        {
                            __builder2.AddContent$4(98, "Unbind");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(99, "\r\n            ");
                        __builder2.OpenElement(100, "div");
                        __builder2.AddAttribute$5(101, "title", "Move Up/Left");
                        __builder2.AddAttribute$5(102, "class", `${$.$strNN((label ? "nowrap" : ""))}`);
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 103, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Up)));
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 104, "onclick", true);
                        __builder2.AddMarkupContent(105, "<i class=\"mdi mdi-arrow-up\"></i>");
                        if (label)
                        {
                            __builder2.AddContent$4(106, "Move Up/Left");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(107, "\r\n            ");
                        __builder2.OpenElement(108, "div");
                        __builder2.AddAttribute$5(109, "title", "Move Down/Right");
                        __builder2.AddAttribute$5(110, "class", `${$.$strNN((label ? "nowrap" : ""))}`);
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 111, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Down)));
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 112, "onclick", true);
                        __builder2.AddMarkupContent(113, "<i class=\"mdi mdi-arrow-down\"></i>");
                        if (label)
                        {
                            __builder2.AddContent$4(114, "Move Down/Right");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(115, "\r\n            ");
                        __builder2.OpenElement(116, "div");
                        __builder2.AddAttribute$5(117, "title", "Duplicate");
                        __builder2.AddAttribute$5(118, "class", `${$.$strNN((label ? "nowrap" : ""))}`);
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 119, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Duplicate)));
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 120, "onclick", true);
                        __builder2.AddMarkupContent(121, "<i class=\"mdi mdi-content-duplicate\"></i>");
                        if (label)
                        {
                            __builder2.AddContent$4(122, "Duplicate");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(123, "\r\n            ");
                        __builder2.OpenElement(124, "div");
                        __builder2.AddAttribute$5(125, "title", "Remove");
                        __builder2.AddAttribute$5(126, "class", `${$.$strNN((label ? "nowrap" : ""))}`);
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 127, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Remove)));
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 128, "onclick", true);
                        __builder2.AddMarkupContent(129, "<i class=\"mdi mdi-delete\"></i>");
                        if (label)
                        {
                            __builder2.AddContent$4(130, "Remove");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(131, "\r\n            ");
                        __builder2.OpenElement(132, "div");
                        __builder2.AddAttribute$5(133, "title", "Copy");
                        __builder2.AddAttribute$5(134, "class", `${$.$strNN((label ? "nowrap" : ""))}`);
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 135, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Copy)));
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 136, "onclick", true);
                        __builder2.AddMarkupContent(137, "<i class=\"mdi mdi-content-copy\"></i>");
                        if (label)
                        {
                            __builder2.AddContent$4(138, "Copy");
                        }
                        __builder2.CloseElement();
                        if ($.$is(this.Builder.ClipBoard, $.$bMcF.LFCW.Widget) && this.ChildContents !== null)
                        {
                            __builder2.OpenElement(139, "div");
                            __builder2.AddAttribute$5(140, "title", "Paste");
                            __builder2.AddAttribute$5(141, "class", `${$.$strNN((label ? "nowrap" : ""))}`);
                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 142, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Paste)));
                            $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 143, "onclick", true);
                            __builder2.AddMarkupContent(144, "<i class=\"mdi mdi-content-paste\"></i>");
                            if (label)
                            {
                                __builder2.AddContent$4(145, "Paste");
                            }
                            __builder2.CloseElement();
                        }
                    }
                    __builder2.OpenElement(146, "div");
                    __builder2.AddAttribute$5(147, "title", "Add Top Row");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 148, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.AddTopRow)));
                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 149, "onclick", true);
                    __builder2.AddMarkupContent(150, "<i class=\"mdi mdi-plus\"></i>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(151, "\r\n    ");
                }, $vwoNle ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1670066,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(356483955634)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(30066441138)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(30066441138)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77311081394)
                this.Context = null;
                //--TRIMMABLE-BOUNDARY-END(77311081394)
                
            }
            static $h = 1670066;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(240519838642),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184685263794,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1670066,
      "h": 240519838642,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(240519838642),
//--TRIMMABLE-BOUNDARY-START(77311081394),
    {
      "p": 46041430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915460018,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283469511602,
        "f": 83886081
      },
      "n": "Context",
      "d": 1670066,
      "h": 77311081394,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311081394),
//--TRIMMABLE-BOUNDARY-START(249109773234),
    {
      "p": 119603201,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193275198386,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300649380786,
        "f": 83886081
      },
      "n": "Property",
      "d": 1670066,
      "h": 249109773234,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(249109773234),
//--TRIMMABLE-BOUNDARY-START(339304086450),
    {
      "p": 9907952,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219045002162,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309239315378,
        "f": 83886081
      },
      "n": "Widget",
      "d": 1670066,
      "h": 339304086450,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(339304086450),
//--TRIMMABLE-BOUNDARY-START(51541277618),
    {
      "p": 1080242,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145656242,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266289642418,
        "f": 83886081
      },
      "n": "Builder",
      "d": 1670066,
      "h": 51541277618,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541277618),
//--TRIMMABLE-BOUNDARY-START(85901015986),
    {
      "p": 1453808,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505394610,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292059446194,
        "f": 83886081
      },
      "n": "DataSource",
      "d": 1670066,
      "h": 85901015986,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85901015986),
//--TRIMMABLE-BOUNDARY-START(60131212210),
    {
      "p": $.$$.SCG.IEnumerable$$($.$bMcF.LFCW.Widget).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735590834,
        "f": 50331650
      },
      "n": "ChildContents",
      "d": 1670066,
      "h": 60131212210,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60131212210),
//--TRIMMABLE-BOUNDARY-START(124555721650),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095329202,
        "f": 50331650
      },
      "n": "FullTitle",
      "d": 1670066,
      "h": 124555721650,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(124555721650),
//--TRIMMABLE-BOUNDARY-START(73016114098),
    {
      "p": 25515690,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325525426,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274879577010,
        "f": 83886082
      },
      "n": "Component",
      "d": 1670066,
      "h": 73016114098,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016114098),
//--TRIMMABLE-BOUNDARY-START(313534282674),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201865132978,
        "f": 50331649
      },
      "n": "Target",
      "d": 1670066,
      "h": 313534282674,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(313534282674),
//--TRIMMABLE-BOUNDARY-START(317829249970),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210455067570,
        "f": 50331649
      },
      "n": "Title",
      "d": 1670066,
      "h": 317829249970,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(317829249970)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(326419184562),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1670066,
      "h": 326419184562,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(326419184562),
//--TRIMMABLE-BOUNDARY-START(223339969458),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1670066,
      "h": 223339969458,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(223339969458),
//--TRIMMABLE-BOUNDARY-START(231929904050),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1670066,
      "h": 231929904050,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(231929904050),
//--TRIMMABLE-BOUNDARY-START(90195983282),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1670066,
      "h": 90195983282,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195983282),
//--TRIMMABLE-BOUNDARY-START(236224871346),
    {
      "r": 65537,
      "n": "OnParametersSet",
      "d": 1670066,
      "h": 236224871346,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(236224871346),
//--TRIMMABLE-BOUNDARY-START(227634936754),
    {
      "r": 1310721,
      "p": [
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": "NameFrom",
      "d": 1670066,
      "h": 227634936754,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(227634936754),
//--TRIMMABLE-BOUNDARY-START(68721146802),
    {
      "r": 181338113,
      "n": "Clicked",
      "d": 1670066,
      "h": 68721146802,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68721146802),
//--TRIMMABLE-BOUNDARY-START(111670819762),
    {
      "r": 181338113,
      "n": "Drop",
      "d": 1670066,
      "h": 111670819762,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(111670819762),
//--TRIMMABLE-BOUNDARY-START(107375852466),
    {
      "r": 181338113,
      "n": "DragStart",
      "d": 1670066,
      "h": 107375852466,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107375852466),
//--TRIMMABLE-BOUNDARY-START(98785917874),
    {
      "r": 181338113,
      "n": "DragEnter",
      "d": 1670066,
      "h": 98785917874,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98785917874),
//--TRIMMABLE-BOUNDARY-START(103080885170),
    {
      "r": 181338113,
      "n": "DragLeave",
      "d": 1670066,
      "h": 103080885170,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103080885170),
//--TRIMMABLE-BOUNDARY-START(64426179506),
    {
      "r": 181338113,
      "n": "ChooseAndAddComponent",
      "d": 1670066,
      "h": 64426179506,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64426179506),
//--TRIMMABLE-BOUNDARY-START(120260754354),
    {
      "r": 181338113,
      "n": "EditAttributes",
      "d": 1670066,
      "h": 120260754354,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120260754354),
//--TRIMMABLE-BOUNDARY-START(330714151858),
    {
      "r": 181338113,
      "n": "Unbind",
      "d": 1670066,
      "h": 330714151858,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(330714151858),
//--TRIMMABLE-BOUNDARY-START(94490950578),
    {
      "r": 181338113,
      "n": "Down",
      "d": 1670066,
      "h": 94490950578,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94490950578),
//--TRIMMABLE-BOUNDARY-START(335009119154),
    {
      "r": 181338113,
      "n": "Up",
      "d": 1670066,
      "h": 335009119154,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(335009119154),
//--TRIMMABLE-BOUNDARY-START(115965787058),
    {
      "r": 181338113,
      "n": "Duplicate",
      "d": 1670066,
      "h": 115965787058,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115965787058),
//--TRIMMABLE-BOUNDARY-START(253404740530),
    {
      "r": 181338113,
      "n": "Remove",
      "d": 1670066,
      "h": 253404740530,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(253404740530),
//--TRIMMABLE-BOUNDARY-START(81606048690),
    {
      "r": 181338113,
      "n": "Copy",
      "d": 1670066,
      "h": 81606048690,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81606048690),
//--TRIMMABLE-BOUNDARY-START(244814805938),
    {
      "r": 181338113,
      "n": "Paste",
      "d": 1670066,
      "h": 244814805938,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(244814805938),
//--TRIMMABLE-BOUNDARY-START(38656375730),
    {
      "r": 181338113,
      "n": "AddLeftColumn",
      "d": 1670066,
      "h": 38656375730,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38656375730),
//--TRIMMABLE-BOUNDARY-START(42951343026),
    {
      "r": 181338113,
      "n": "AddRightColumn",
      "d": 1670066,
      "h": 42951343026,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42951343026),
//--TRIMMABLE-BOUNDARY-START(47246310322),
    {
      "r": 181338113,
      "n": "AddTopRow",
      "d": 1670066,
      "h": 47246310322,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47246310322),
//--TRIMMABLE-BOUNDARY-START(34361408434),
    {
      "r": 181338113,
      "n": "AddBottomRow",
      "d": 1670066,
      "h": 34361408434,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34361408434),
//--TRIMMABLE-BOUNDARY-START(322124217266),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1670066,
      "h": 322124217266,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(322124217266),
//--TRIMMABLE-BOUNDARY-START(257699707826),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        }
      ],
      "n": "RenderWidget",
      "d": 1670066,
      "h": 257699707826,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(257699707826),
//--TRIMMABLE-BOUNDARY-START(55836244914),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1670066,
      "h": 55836244914,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55836244914),
//--TRIMMABLE-BOUNDARY-START(347894021042),
    {
      "r": 6881395,
      "n": "WidgetLeftToolBar",
      "d": 1670066,
      "h": 347894021042,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(347894021042),
//--TRIMMABLE-BOUNDARY-START(352188988338),
    {
      "r": 6881395,
      "n": "WidgetRightToolBar",
      "d": 1670066,
      "h": 352188988338,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(352188988338),
//--TRIMMABLE-BOUNDARY-START(343599053746),
    {
      "r": 6881395,
      "n": "WidgetBottomToolBar",
      "d": 1670066,
      "h": 343599053746,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(343599053746),
//--TRIMMABLE-BOUNDARY-START(356483955634),
    {
      "r": 6881395,
      "p": [
        {
          "n": "label",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "WidgetTopToolBar",
      "d": 1670066,
      "h": 356483955634,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(356483955634)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066441138),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1670066,
      "h": 30066441138,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066441138)
  ],
  "h": 1670066
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.WidgetRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}WidgetRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1670066)
        
        

        //--TRIMMABLE-BOUNDARY-START(1080242)
        $asm.$cls(`$yyXP.LCFCP.PageBuilder`, ($self) => class PageBuilder extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(502512253874)
            /*string */ get OptimizedComponentName()
            {
                return "pagebuilder";
            }
            //--TRIMMABLE-BOUNDARY-END(502512253874)
            
            //--TRIMMABLE-BOUNDARY-START(768800226226)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(768800226226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Mode":
                    this.Mode = $.$cast(parameter.Value, $.$hDPm.LCFCI.PageBuilderMode);
                    return true;
                    case "Widgets":
                    this.Widgets = $.$cast(parameter.Value, $.$typeArray($.$$.S.Type));
                    return true;
                    case "ModeChanged":
                    this.ModeChanged = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$hDPm.LCFCI.PageBuilderMode));
                    return true;
                    case "Root":
                    this.Root = $.$cast(parameter.Value, $.$bMcF.LFCW.UIRootWidget);
                    return true;
                    case "RootChanged":
                    this.RootChanged = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$bMcF.LFCW.UIRootWidget));
                    return true;
                    case "OnNewWidget":
                    this.OnNewWidget = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$bMcF.LFCW.Widget));
                    return true;
                    case "Features":
                    this.Features = $.$cast(parameter.Value, $.$yyXP.LCFCP.PageBuilderFeatures);
                    return true;
                    case "DataSource":
                    this.DataSource = $.$cast(parameter.Value, $.$bMcF.LFCD.IWidgetDataSource);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(768800226226)
            
            //--TRIMMABLE-BOUNDARY-START(446677679026)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446677679026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Context = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFC.IApplicationContextProvider, serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Prompt = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientPromptService, serviceProvider);
                this.JavaScript = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, serviceProvider);
                this.StorageService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFCS$5.IPersistentStorageService, serviceProvider);
                this.UI = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IUIService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(446677679026)
            
            //--TRIMMABLE-BOUNDARY-START(468152515506)
            /*PageBuilderMode*/ mode = 1;
            //--TRIMMABLE-BOUNDARY-END(468152515506)
            
            //--TRIMMABLE-BOUNDARY-START(472447482802)
            /*PageBuilderMode */ get Mode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123627442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.mode;
            }
            /*PageBuilderMode */ set Mode(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(644246174642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.mode !== value)
                {
                    this.mode = value;
                    this.ModeChanged.InvokeAsync$1(this.mode);
                    if (this.mode === 3/*PageBuilderMode.EditHtml*/)
                    {
                        if ($.$sl.SL.Enumerable.Count$1($.$bMcF.LFCW.Widget, this.Root.Children) === 0 || (!(this.Root.get_Item$1(0) !== null && ($.$is(this.Root.get_Item$1(0), $.$bMcF.LFCW.HtmlWidget)))))
                        {
                            this.Root.Insert(0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ new $.$bMcF.LFCW.HtmlWidget().$ctor$3() ], null, null));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(472447482802)
            
            //--TRIMMABLE-BOUNDARY-START(790275062706)
            /*Type[]?*/ Widgets = null;
            //--TRIMMABLE-BOUNDARY-END(790275062706)
            
            //--TRIMMABLE-BOUNDARY-START(476742450098)
            /*EventCallback<PageBuilderMode>*/ ModeChanged;
            //--TRIMMABLE-BOUNDARY-END(476742450098)
            
            //--TRIMMABLE-BOUNDARY-START(536871992242)
            /*UIRootWidget*/ Root = null;
            //--TRIMMABLE-BOUNDARY-END(536871992242)
            
            //--TRIMMABLE-BOUNDARY-START(541166959538)
            /*EventCallback<UIRootWidget>*/ RootChanged;
            //--TRIMMABLE-BOUNDARY-END(541166959538)
            
            //--TRIMMABLE-BOUNDARY-START(493922319282)
            /*EventCallback<Widget>*/ OnNewWidget;
            //--TRIMMABLE-BOUNDARY-END(493922319282)
            
            //--TRIMMABLE-BOUNDARY-START(214749445042)
            /*PageBuilderFeatures*/ Features = 0;
            //--TRIMMABLE-BOUNDARY-END(214749445042)
            
            //--TRIMMABLE-BOUNDARY-START(133145066418)
            /*IWidgetDataSource?*/ DataSource = null;
            //--TRIMMABLE-BOUNDARY-END(133145066418)
            
            //--TRIMMABLE-BOUNDARY-START(124555131826)
            /*IApplicationContextProvider*/ Context = null;
            //--TRIMMABLE-BOUNDARY-END(124555131826)
            
            //--TRIMMABLE-BOUNDARY-START(558346828722)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(558346828722)
            
            //--TRIMMABLE-BOUNDARY-START(511102188466)
            /*IUIClientPromptService*/ Prompt = null;
            //--TRIMMABLE-BOUNDARY-END(511102188466)
            
            //--TRIMMABLE-BOUNDARY-START(450972646322)
            /*IJavaScriptRunner*/ JavaScript = null;
            //--TRIMMABLE-BOUNDARY-END(450972646322)
            
            //--TRIMMABLE-BOUNDARY-START(751620357042)
            /*IPersistentStorageService*/ StorageService = null;
            //--TRIMMABLE-BOUNDARY-END(751620357042)
            
            //--TRIMMABLE-BOUNDARY-START(773095193522)
            /*IUIService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(773095193522)
            
            //--TRIMMABLE-BOUNDARY-START(206159510450)
            /*FluentUIEditMode */ get EditMode()
            {
                return this.Mode !== 0/*PageBuilderMode.Read*/ ? 1/*FluentUIEditMode.Editting*/ : 0/*FluentUIEditMode.None*/;
            }
            //--TRIMMABLE-BOUNDARY-END(206159510450)
            
            //--TRIMMABLE-BOUNDARY-START(137440033714)
            /*bool*/ dirty = false;
            //--TRIMMABLE-BOUNDARY-END(137440033714)
            
            //--TRIMMABLE-BOUNDARY-START(532577024946)
            /*Dictionary<Widget, WidgetRenderer>*/ Renderers = null;
            //--TRIMMABLE-BOUNDARY-END(532577024946)
            
            //--TRIMMABLE-BOUNDARY-START(785980095410)
            /*IDictionary<string, object> */ get ViewBag()
            {
                return (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.set_Item("Builder", this);
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(785980095410)
            
            //--TRIMMABLE-BOUNDARY-START(103080295346)
            /*ComponentBrowser?*/ browser = null;
            //--TRIMMABLE-BOUNDARY-END(103080295346)
            
            //--TRIMMABLE-BOUNDARY-START(107375262642)
            /*IPageComponentBrowser */ get Browser()
            {
                return this.browser;
            }
            //--TRIMMABLE-BOUNDARY-END(107375262642)
            
            //--TRIMMABLE-BOUNDARY-START(219044412338)
            /*bool*/ fullScreen = false;
            //--TRIMMABLE-BOUNDARY-END(219044412338)
            
            //--TRIMMABLE-BOUNDARY-START(764505258930)
            /*void */ ToggleFullScreen()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(764505258930);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.fullScreen = !this.fullScreen;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(764505258930)
            
            //--TRIMMABLE-BOUNDARY-START(459562580914)
            /*string?*/ jsonError = null;
            //--TRIMMABLE-BOUNDARY-END(459562580914)
            
            //--TRIMMABLE-BOUNDARY-START(455267613618)
            /*string */ get Json()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533692850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Mode === 3/*PageBuilderMode.EditHtml*/)
                {
                    return ($.$cast(this.Root.get_Item$1(0), $.$bMcF.LFCW.HtmlWidget)).Html;
                }
                else 
                {
                    return $.$fPer.LCFCS$1.Serialized.op_Implicit$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$bMcF.LFCW.UIRootWidget, this.Root, true, false, true, false, false, false, false, "Json", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "Json", 108));
                }
            }
            /*string */ set Json(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(635656240050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Mode === 3/*PageBuilderMode.EditHtml*/)
                {
                    ($.$cast(this.Root.get_Item$1(0), $.$bMcF.LFCW.HtmlWidget)).Html = value;
                }
                else 
                {
                    /*var*/ let previous = $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$bMcF.LFCW.UIRootWidget, this.Root, true, false, true, false, false, false, false, "Json", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "Json", 119);
                    try
                    {
                        this.jsonError = null;
                        {
                            this.Root = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$bMcF.LFCW.UIRootWidget, value, false, "Json", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "Json", 131);
                            this.RootChanged.InvokeAsync$1(this.Root);
                        }
                    }
                    catch(e)
                    {
                        this.jsonError = e.Message;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(455267613618)
            
            //--TRIMMABLE-BOUNDARY-START(120260164530)
            /*object?*/ ClipBoard = null;
            //--TRIMMABLE-BOUNDARY-END(120260164530)
            
            //--TRIMMABLE-BOUNDARY-START(167504804786)
            /*Type?*/ draggingComponent = null;
            //--TRIMMABLE-BOUNDARY-END(167504804786)
            
            //--TRIMMABLE-BOUNDARY-START(171799772082)
            /*Widget?*/ draggingWidget = null;
            //--TRIMMABLE-BOUNDARY-END(171799772082)
            
            //--TRIMMABLE-BOUNDARY-START(154619902898)
            /*Type? */ get DragComponent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994085298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.draggingComponent;
            }
            /*Type? */ set DragComponent(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592706567090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.draggingComponent = value;
                this.draggingWidget = null;
            }
            //--TRIMMABLE-BOUNDARY-END(154619902898)
            
            //--TRIMMABLE-BOUNDARY-START(184684673970)
            /*Widget? */ get DragWidget()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173954482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.draggingWidget;
            }
            /*Widget? */ set DragWidget(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(609886436274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.draggingWidget = value;
                this.draggingComponent = null;
            }
            //--TRIMMABLE-BOUNDARY-END(184684673970)
            
            //--TRIMMABLE-BOUNDARY-START(180389706674)
            /*ContainerWidget?*/ DragOver = null;
            //--TRIMMABLE-BOUNDARY-END(180389706674)
            
            //--TRIMMABLE-BOUNDARY-START(755915324338)
            /*Tabs?*/ tabs = null;
            //--TRIMMABLE-BOUNDARY-END(755915324338)
            
            //--TRIMMABLE-BOUNDARY-START(210454477746)
            /*ComponentEditor?*/ editor = null;
            //--TRIMMABLE-BOUNDARY-END(210454477746)
            
            //--TRIMMABLE-BOUNDARY-START(481037417394)
            /*ComponentNavigator?*/ navigator = null;
            //--TRIMMABLE-BOUNDARY-END(481037417394)
            
            //--TRIMMABLE-BOUNDARY-START(549756894130)
            /*Widget?*/ selected = null;
            //--TRIMMABLE-BOUNDARY-END(549756894130)
            
            //--TRIMMABLE-BOUNDARY-START(554051861426)
            /*Widget? */ get Selected()
            {
                return this.selected;
            }
            //--TRIMMABLE-BOUNDARY-END(554051861426)
            
            //--TRIMMABLE-BOUNDARY-START(747325389746)
            /*ValueTask */ SetSelected(/*Widget?*/ value, /*bool*/ switchToTab)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(747325389746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value !== this.selected)
                {
                    this.selected = value;
                    if (this.tabs !== null && switchToTab)
                    {
                        this.tabs.CurrentViewName = "selected";
                    }
                    return this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "SetSelected", 187);
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(747325389746)
            
            //--TRIMMABLE-BOUNDARY-START(545461926834)
            /*WidgetRenderer?*/ RootRenderer = null;
            //--TRIMMABLE-BOUNDARY-END(545461926834)
            
            //--TRIMMABLE-BOUNDARY-START(146029968306)
            /*bool*/ disposed = false;
            //--TRIMMABLE-BOUNDARY-END(146029968306)
            
            //--TRIMMABLE-BOUNDARY-START(489627351986)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489627351986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.UnitOfWork.LCFCI$IClientUnitOfWork$Assets.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResolvePath("LivingThing.Core.Frameworks.Client.PageBuilder.Blazor.css", true, false, false), this.ResolvePath("LivingThing.Core.Frameworks.Client.PageBuilder.Blazor.js", true, false, false) ], null, null));
                this.JavaScript.LCFCI$IJavaScriptRunner$Queue$1("pageBuilder.init", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mj.MJ.DotNetObjectReference.Create($.$yyXP.LCFCP.PageBuilder, this) ], null, null));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(489627351986)
            
            //--TRIMMABLE-BOUNDARY-START(141735001010)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735001010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.disposed = true;
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(141735001010)
            
            //--TRIMMABLE-BOUNDARY-START(498217286578)
            /*void */ OnParametersSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498217286578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.GetClassBuilder(true).From($.$$.S.Boolean, "edit", this.Mode !== 0/*PageBuilderMode.Read*/, null, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "OnParametersSet", 209);
                super.OnParametersSet();
            }
            //--TRIMMABLE-BOUNDARY-END(498217286578)
            
            //--TRIMMABLE-BOUNDARY-START(463857548210)
            /*void */ MarkDirty()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(463857548210);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.dirty = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(463857548210)
            
            //--TRIMMABLE-BOUNDARY-START(485332384690)
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(485332384690);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (firstRender && ((this.Features & (64/*PageBuilderFeatures.RecoverUnsavedChanges*/)) == (64/*PageBuilderFeatures.RecoverUnsavedChanges*/)))
                    {
                        let $t3, $r3;
                        /*var*/ let store = ($t3 = $.$fPer.LCFCS$5.LocalStorageExtension.GetItem($.$bMcF.LFCW.UIRootWidget, this.StorageService, this, "UI"), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        if (store !== null)
                        {
                            this.Root = store;
                            _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "OnAfterRenderAsync", 223);
                        }
                        _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                            {
                                while(!this.disposed)
                                {
                                    let $t4, $r4;
                                    ($t4 = $.$$.STT.Task.Delay$1(1000), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                    if (this.dirty)
                                    {
                                        try
                                        {
                                            let $t5, $r5;
                                            ($t5 = $.$fPer.LCFCS$5.LocalStorageExtension.SetItem($.$bMcF.LFCW.UIRootWidget, this.StorageService, this, "UI", this.Root), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                                            this.dirty = false;
                                        }
                                        catch($e)
                                        {
                                        }
                                    }
                                }
                            });
                        }, $jRQwha ??= {"r":178454529,"n":"","d":1080242,"h":0,"f":17829890}));
                    }
                    ($t6 = super.OnAfterRenderAsync(firstRender), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(485332384690)
            
            //--TRIMMABLE-BOUNDARY-START(743030422450)
            /*ValueTask */ SetLabelText(/*string*/ id, /*string*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(743030422450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let widget = $.$sl.SL.Enumerable.SingleOrDefault$1($.$bMcF.LFCW.Widget, this.Renderers.Keys, new ($.$$.S.Func$$$($.$bMcF.LFCW.Widget, $.$$.S.Boolean))().$ctor(this,  (/*k*/ k) =>
                {
                    return $.$$.S.String.ToString.call(k.Id) === id;
                }, $TeGche ??= {"r":262145,"p":[{"n":"k","p":9907952}],"n":"","d":1080242,"h":0,"f":17825794}));
                let label;
                if ($.$is(widget, $.$bMcF.LFCW.LabelWidget, { set $v($v){ label = $v; } }))
                {
                    label.Text = $.$$.S.String.Trim.call(text);
                    this.MarkDirty();
                    return this.Renderers.get_Item(label).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "SetLabelText", 253);
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(743030422450)
            
            //--TRIMMABLE-BOUNDARY-START(85900426162)
            /*ValueTask<Widget?> *//*async*/  AddComponent(/*Type*/ type, /*ContainerWidget*/ container)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$bMcF.LFCW.Widget), $.$bMcF.LFCW.Widget, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900426162);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*Widget?*/ let model = null;
                    if ($.$hDPm.LCFCC$1.BaseComponent.$type.IsAssignableFrom(type))
                    {
                        model = new $.$bMcF.LFCW.ComponentWidget().$ctor$5(type);
                    }
                    else 
                    {
                        if ($.$$.SR.ConstructorInfo.op_Inequality$2(type.GetConstructor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), null, [0], null)), null))
                        {
                            model = $.$cast($.$$.S.Activator.CreateInstance$9(type), $.$bMcF.LFCW.Widget);
                        }
                        else 
                        {
                            model = $.$cast($.$$.S.Activator.CreateInstance$6(type, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ null, $.$box(0, $.$$.S.Int32) ], null, null)), $.$bMcF.LFCW.Widget);
                        }
                    }
                    if (model !== null)
                    {
                        let $t7, $r7;
                        container.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ model ], null, null));
                        model.Parent = container;
                        ($t7 = this.OnNewWidget.InvokeAsync$1(model), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    }
                    ($t8 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddComponent", 286), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, model);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85900426162)
            
            //--TRIMMABLE-BOUNDARY-START(115965197234)
            /*ValueTask *//*async*/  ChooseAndAddComponent(/*Widget*/ widget)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965197234);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let container;
                    if ($.$is(widget, $.$bMcF.LFCW.ContainerWidget, { set $v($v){ container = $v; } }))
                    {
                        let $t9, $r9;
                        /*Type?*/ let component;
                        component = ($t9 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCC$IUIService$Prompt.LCFCC$IUIPromptService$Select($.$$.S.Type, "Component Type", null, new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.String))().$ctor(this,  (/*t*/ t) =>
                        {
                            return $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.String.Replace$3.call(t.Name, "Widget", ""));
                        }, $PTmqXd ??= {"r":1310721,"p":[{"n":"t","p":188547073}],"n":"","d":1080242,"h":0,"f":17825794}), this.Widgets ?? $.$sl.SL.Enumerable.ToArray($.$$.S.Type, $.$yyXP.LCFCP.ComponentBrowser.GetComponents(((this.Features & (1/*PageBuilderFeatures.RazorComponents*/)) == (1/*PageBuilderFeatures.RazorComponents*/))))), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        if (component !== null)
                        {
                            let $t10, $r10;
                            ($t10 = this.AddComponent(component, container), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(115965197234)
            
            //--TRIMMABLE-BOUNDARY-START(201864543154)
            /*ValueTask */ EditAttributes(/*Widget*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864543154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.selected = model;
                return this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "EditAttributes", 322);
            }
            //--TRIMMABLE-BOUNDARY-END(201864543154)
            
            //--TRIMMABLE-BOUNDARY-START(777390160818)
            /*ValueTask */ Unbind(/*Widget*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(777390160818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let keys = $.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Where($.$$.S.String, model.Scratch.Keys, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*k*/ k) =>
                {
                    return $.$$.S.String.StartsWith$3.call(k, "_binding.");
                }, $FIDWpj ??= {"r":262145,"p":[{"n":"k","p":1310721}],"n":"","d":1080242,"h":0,"f":17825794})));
                let $i11 = 0;
                let $arr11 = keys;
                while ($i11 < $arr11.length)
                {
                    let key = $arr11[$i11++];
                    model.Scratch.Remove$1(key);
                }
                this.MarkDirty();
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(777390160818)
            
            //--TRIMMABLE-BOUNDARY-START(188979641266)
            /*ValueTask *//*async*/  DropOn(/*Widget*/ targetWidget)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t13, $r13;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(188979641266);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let container = ($.$as(targetWidget, $.$bMcF.LFCW.ContainerWidget)) ?? targetWidget.Parent;
                    /*Widget?*/ let newWidget = null;
                    if (container !== null)
                    {
                        if (this.DragComponent !== null)
                        {
                            let $t12, $r12;
                            newWidget = ($t12 = this.AddComponent(this.DragComponent, container), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                        }
                        else if (this.DragWidget !== null)
                        {
                            /*var*/ let oldParent = this.DragWidget.Parent;
                            oldParent?.Remove$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.DragWidget ], null, null));
                            container.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.DragWidget ], null, null));
                            this.DragWidget.Parent = container;
                            if (oldParent !== null)
                            {
                            }
                            newWidget = this.DragWidget;
                        }
                    }
                    this.DragWidget = null;
                    this.DragOver = null;
                    this.MarkDirty();
                    if (newWidget !== null)
                    {
                        this.selected = newWidget;
                    }
                    ($t13 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "DropOn", 367), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(188979641266)
            
            //--TRIMMABLE-BOUNDARY-START(158914870194)
            /*ValueTask */ DragComponentStart(/*Widget*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914870194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.DragWidget = model;
                return this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "DragComponentStart", 373);
            }
            //--TRIMMABLE-BOUNDARY-END(158914870194)
            
            //--TRIMMABLE-BOUNDARY-START(163209837490)
            /*ValueTask *//*async*/  DragEnter(/*Widget*/ widget)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209837490);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let wasNull = this.DragOver === null;
                    this.DragOver = ($.$as(widget, $.$bMcF.LFCW.ContainerWidget)) ?? widget.Parent;
                    if (wasNull)
                    {
                        let $t14, $r14;
                        ($t14 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "DragEnter", 382), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                    }
                    else if (this.DragOver !== widget)
                    {
                        let $t15, $r15;
                        ($t15 = this.Renderers.get_Item(this.DragOver).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "DragEnter", 386), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(163209837490)
            
            //--TRIMMABLE-BOUNDARY-START(176094739378)
            /*ValueTask *//*async*/  DragLeave(/*Widget*/ widget)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176094739378);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.DragOver === widget)
                    {
                        let $t16, $r16;
                        this.DragOver = null;
                        ($t16 = this.Renderers.get_Item(widget).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "DragLeave", 395), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(176094739378)
            
            //--TRIMMABLE-BOUNDARY-START(193274608562)
            /*ValueTask */ Duplicate(/*Widget*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274608562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (model.Parent !== null)
                {
                    /*var*/ let ix = model.Parent.IndexOf(model);
                    /*var*/ let newModel = model.Clone();
                    this.selected = newModel;
                    model.Parent.Insert(((ix + 1) | 0), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ newModel ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(model.Parent).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "Duplicate", 416);
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(193274608562)
            
            //--TRIMMABLE-BOUNDARY-START(128850099122)
            /*ValueTask */ Copy(/*Widget*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850099122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ClipBoard = model.Clone();
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(128850099122)
            
            //--TRIMMABLE-BOUNDARY-START(506807221170)
            /*ValueTask */ Paste(/*Widget*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506807221170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let container;
                if ($.$is(model, $.$bMcF.LFCW.ContainerWidget, { set $v($v){ container = $v; } }))
                {
                    /*var*/ let widget = $.$as(this.ClipBoard, $.$bMcF.LFCW.Widget);
                    if (widget !== null)
                    {
                        /*var*/ let newModel = widget.Clone();
                        this.selected = newModel;
                        container.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ newModel ], null, null));
                        this.MarkDirty();
                    }
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(506807221170)
            
            //--TRIMMABLE-BOUNDARY-START(519692123058)
            /*ValueTask *//*async*/  Remove(/*Widget*/ model)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t17, $r17;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(519692123058);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    model.Parent.Remove$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ model ], null, null));
                    this.MarkDirty();
                    ($t17 = this.Renderers.get_Item(model.Parent).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "Remove", 447), ($.$$.N.AsyncResolver.IsCompleted($t17, { set $v($v) { $r17 = $v; } }) ? $r17 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t17)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(519692123058)
            
            //--TRIMMABLE-BOUNDARY-START(197569575858)
            /*ValueTask *//*async*/  Edit(/*Widget*/ widget)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t18, $r18;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197569575858);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t18 = this.UI.LCFCC$IUIService$Prompt.LCFCC$IUIPromptService$Form($.$bMcF.LFCW.Widget, "Edit " + $.$strNN(widget.Name) ?? widget.Type, "", "OK", "Cancel", widget), ($.$$.N.AsyncResolver.IsCompleted($t18, { set $v($v) { $r18 = $v; } }) ? $r18 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t18)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(197569575858)
            
            //--TRIMMABLE-BOUNDARY-START(781685128114)
            /*ValueTask */ Up(/*Widget*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(781685128114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (model.MoveUp())
                {
                    this.MarkDirty();
                    return this.Renderers.get_Item(model.Parent).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "Up", 460);
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(781685128114)
            
            //--TRIMMABLE-BOUNDARY-START(150324935602)
            /*ValueTask */ Down(/*Widget*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324935602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (model.MoveDown())
                {
                    this.MarkDirty();
                    return this.Renderers.get_Item(model.Parent).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "Down", 470);
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(150324935602)
            
            //--TRIMMABLE-BOUNDARY-START(90195393458)
            /*ValueTask */ AddLeftColumn(/*Widget*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195393458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let root;
                let hStackWidget;
                let hStackWidget2;
                if ($.$is(model, $.$bMcF.LFCW.UIRootWidget, { set $v($v){ root = $v; } }))
                {
                    let hstack;
                    if ($.$sl.SL.Enumerable.Count$1($.$bMcF.LFCW.Widget, root.Children) === 0)
                    {
                        root.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    }
                    else if ($.$sl.SL.Enumerable.Count$1($.$bMcF.LFCW.Widget, root.Children) === 1 && $.$is(root.get_Item$1(0), $.$bMcF.LFCW.HStackWidget, { set $v($v){ hstack = $v; } }))
                    {
                        hstack.Insert(0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    }
                    else 
                    {
                        /*System.Collections.Generic.IEnumerable<LivingThing.FluentUI.Core.Widgets.Widget>*/ let __ca1__;
                        /*var*/ let currentChildCount = ((__ca1__ = root.Children) !== null ? $.$sl.SL.Enumerable.Count$1($.$bMcF.LFCW.Widget, __ca1__) : null);
                        hstack = new $.$bMcF.LFCW.HStackWidget().$ctor$9();
                        hstack.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                        /*var*/ let w = ($.$$.S.Int32.op_GreaterThan(currentChildCount, 1) ? new $.$bMcF.LFCW.VStackWidget().$ctor$10(root.Children) : currentChildCount === 1 ? root.get_Item$1(0) : null);
                        if (w !== null)
                        {
                            hstack.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ w ], null, null));
                        }
                        root.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ $.$cast(hstack, $.$bMcF.LFCW.Widget) ], null, null));
                    }
                    this.MarkDirty();
                    return this.Renderers.get_Item(root).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddLeftColumn", 511);
                }
                else if ($.$is(model, $.$bMcF.LFCW.HStackWidget, { set $v($v){ hStackWidget = $v; } }))
                {
                    hStackWidget.InsertBefore(model, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(hStackWidget).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddLeftColumn", 517);
                }
                else if ($.$is(model.Parent, $.$bMcF.LFCW.HStackWidget, { set $v($v){ hStackWidget2 = $v; } }))
                {
                    hStackWidget2.InsertBefore(model, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(hStackWidget2).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddLeftColumn", 523);
                }
                else if (model.Parent !== null)
                {
                    /*var*/ let initialParent = model.Parent;
                    /*int*/ let initialIndex = model.Parent.IndexOf(model);
                    /*var*/ let hstack = new $.$bMcF.LFCW.HStackWidget().$ctor$9();
                    hstack.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), model ], null, null));
                    initialParent.Insert(initialIndex, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ $.$cast(hstack, $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(initialParent).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddLeftColumn", 535);
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(90195393458)
            
            //--TRIMMABLE-BOUNDARY-START(94490360754)
            /*ValueTask */ AddRightColumn(/*Widget*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490360754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let root;
                let hStackWidget;
                let hStackWidget2;
                if ($.$is(model, $.$bMcF.LFCW.UIRootWidget, { set $v($v){ root = $v; } }))
                {
                    let hstack;
                    if ($.$sl.SL.Enumerable.Count$1($.$bMcF.LFCW.Widget, root.Children) === 0)
                    {
                        root.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    }
                    else if ($.$sl.SL.Enumerable.Count$1($.$bMcF.LFCW.Widget, root.Children) === 1 && $.$is(root.get_Item$1(0), $.$bMcF.LFCW.HStackWidget, { set $v($v){ hstack = $v; } }))
                    {
                        hstack.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    }
                    else 
                    {
                        /*System.Collections.Generic.IEnumerable<LivingThing.FluentUI.Core.Widgets.Widget>*/ let __ca2__;
                        /*var*/ let currentChildCount = ((__ca2__ = root.Children) !== null ? $.$sl.SL.Enumerable.Count$1($.$bMcF.LFCW.Widget, __ca2__) : null);
                        hstack = new $.$bMcF.LFCW.HStackWidget().$ctor$9();
                        /*var*/ let w = ($.$$.S.Int32.op_GreaterThan(currentChildCount, 1) ? new $.$bMcF.LFCW.VStackWidget().$ctor$10(root.Children) : currentChildCount === 1 ? root.get_Item$1(0) : null);
                        if (w !== null)
                        {
                            hstack.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ w ], null, null));
                        }
                        hstack.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                        root.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ $.$cast(hstack, $.$bMcF.LFCW.Widget) ], null, null));
                    }
                    this.MarkDirty();
                    return this.Renderers.get_Item(root).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddRightColumn", 576);
                }
                else if ($.$is(model, $.$bMcF.LFCW.HStackWidget, { set $v($v){ hStackWidget = $v; } }))
                {
                    hStackWidget.InsertAfter(model, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(hStackWidget).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddRightColumn", 582);
                }
                else if ($.$is(model.Parent, $.$bMcF.LFCW.HStackWidget, { set $v($v){ hStackWidget2 = $v; } }))
                {
                    hStackWidget2.InsertAfter(model, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(hStackWidget2).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddRightColumn", 588);
                }
                else if (model.Parent !== null)
                {
                    /*var*/ let initialParent = model.Parent;
                    /*int*/ let initialIndex = model.Parent.IndexOf(model);
                    /*var*/ let hstack = new $.$bMcF.LFCW.HStackWidget().$ctor$9();
                    hstack.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ model, this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    initialParent.Insert(initialIndex, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ $.$cast(hstack, $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(initialParent).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddRightColumn", 600);
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(94490360754)
            
            //--TRIMMABLE-BOUNDARY-START(98785328050)
            /*ValueTask */ AddTopRow(/*Widget*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785328050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let root;
                let vStackWidget;
                let vStackWidget2;
                if ($.$is(model, $.$bMcF.LFCW.UIRootWidget, { set $v($v){ root = $v; } }))
                {
                    root.Insert(0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(root).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddTopRow", 611);
                }
                else if ($.$is(model, $.$bMcF.LFCW.VStackWidget, { set $v($v){ vStackWidget = $v; } }))
                {
                    vStackWidget.InsertBefore(model, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(vStackWidget).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddTopRow", 617);
                }
                else if ($.$is(model.Parent, $.$bMcF.LFCW.VStackWidget, { set $v($v){ vStackWidget2 = $v; } }))
                {
                    vStackWidget2.InsertBefore(model, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(vStackWidget2).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddTopRow", 623);
                }
                else if (model.Parent !== null)
                {
                    /*var*/ let initialParent = model.Parent;
                    /*int*/ let initialIndex = model.Parent.IndexOf(model);
                    /*var*/ let vstack = new $.$bMcF.LFCW.VStackWidget().$ctor$9();
                    vstack.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), model ], null, null));
                    initialParent.Insert(initialIndex, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ $.$cast(vstack, $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(initialParent).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddTopRow", 635);
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(98785328050)
            
            //--TRIMMABLE-BOUNDARY-START(81605458866)
            /*ValueTask */ AddBottomRow(/*Widget*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605458866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let root;
                let vStackWidget;
                let vStackWidget2;
                if ($.$is(model, $.$bMcF.LFCW.UIRootWidget, { set $v($v){ root = $v; } }))
                {
                    root.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(root).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddBottomRow", 646);
                }
                else if ($.$is(model, $.$bMcF.LFCW.VStackWidget, { set $v($v){ vStackWidget = $v; } }))
                {
                    vStackWidget.InsertAfter(model, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(vStackWidget).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddBottomRow", 652);
                }
                else if ($.$is(model.Parent, $.$bMcF.LFCW.VStackWidget, { set $v($v){ vStackWidget2 = $v; } }))
                {
                    vStackWidget2.InsertAfter(model, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(vStackWidget2).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddBottomRow", 658);
                }
                else if (model.Parent !== null)
                {
                    /*var*/ let initialParent = model.Parent;
                    /*int*/ let initialIndex = model.Parent.IndexOf(model);
                    /*var*/ let vstack = new $.$bMcF.LFCW.VStackWidget().$ctor$9();
                    vstack.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ model, this.selected = $.$cast(new $.$bMcF.LFCW.PlaceHolderWidget().$ctor$6(), $.$bMcF.LFCW.Widget) ], null, null));
                    initialParent.Insert(initialIndex, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bMcF.LFCW.Widget), [ $.$cast(vstack, $.$bMcF.LFCW.Widget) ], null, null));
                    this.MarkDirty();
                    return this.Renderers.get_Item(initialParent).StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "AddBottomRow", 670);
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(81605458866)
            
            //--TRIMMABLE-BOUNDARY-START(760210291634)
            /*Task *//*async*/  TemplateMarket()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t19, $r19;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(760210291634);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*UIRootWidget?*/ let template = null;
                    template = ($t19 = $.$hDPm.LCFCI.ViewPresenterExtensions.ViewForResult($.$hDPm.LCFCI.ViewConfiguration, $.$bMcF.LFCW.UIRootWidget, $.$yyXP.LCFCP.TemplateMarket, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Template Market", false), null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)));
                    if (template !== null)
                    {
                        let $t20, $r20;
                        this.Root = template;
                        ($t20 = this.RootChanged.InvokeAsync$1(template), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(760210291634)
            
            //--TRIMMABLE-BOUNDARY-START(515397155762)
            /*Task *//*async*/  Publish()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(515397155762);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t21, $r21;
                        let $t22, $r22;
                        /*var*/ let value = ($t21 = $.$hDPm.LCFCI.ViewPresenterExtensions.Form($.$hDPm.LCFCI.ViewConfiguration, $.$Iaui.LCFCM.FluentUITemplateModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Template Properties", false), null, null, null, null, 0, 4131, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21)));
                        value.Json = $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$bMcF.LFCW.UIRootWidget, this.Root, true, false, true, false, false, false, false, "Publish", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\PageBuilder.razor.cs", "Publish", 701).Json;
                        ($t22 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$Iaui.LCFCM.FluentUITemplateModel, this.Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.FluentUITemplateModel), [ value ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t22, { set $v($v) { $r22 = $v; } }) ? $r22 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t22)));
                    }
                    catch($e)
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(515397155762)
            
            //--TRIMMABLE-BOUNDARY-START(523987090354)
            /*object? */ Render(/*Widget?*/ widget, /*IWidgetDataSource*/ dataSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523987090354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Mode === 1/*PageBuilderMode.EditDragDrop*/)
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*_builder*/ _builder) =>
                    {
                        _builder.OpenComponent$1($.$yyXP.LCFCP.WidgetRenderer, 1);
                        _builder.SetKey(widget);
                        _builder.AddAttribute$4(2, "Widget", widget);
                        _builder.AddAttribute$4(4, "Builder", this);
                        _builder.AddAttribute$4(5, "DataSource", dataSource);
                        _builder.CloseComponent();
                    }), $MCZMVf ??= {"r":65537,"p":[{"n":"_builder","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                }
                else 
                {
                    return $.$bMcF.LFC.WidgetRendererExtension.Render($.$mac.MAC.RenderFragment, widget, dataSource, this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(523987090354)
            
            //--TRIMMABLE-BOUNDARY-START(528282057650)
            /*object? */ RenderChildren(/*ContainerWidget?*/ container, /*IWidgetDataSource*/ dataSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528282057650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.Join$1(null, $.$bMcF.LFC.ChildrenRendererExtension.RenderChildren($.$mac.MAC.RenderFragment, container, dataSource, this).SCG$IDictionary$$$$Values);
            }
            //--TRIMMABLE-BOUNDARY-END(528282057650)
            
            //--TRIMMABLE-BOUNDARY-START(111670229938)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670229938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty(this.OwnAttributes(null), $.$fPer.LCFC.Stringy.op_Implicit$3("class"), new ($.$$.S.Func$$($.$$.S.Object))().$ctor(this,  () =>
                {
                    return $.$strNN($.$strNN($.$strNN($.$strNN((this.Mode !== 0/*PageBuilderMode.Read*/ ? "edit " : "")) + $.$strNN((this.DragComponent !== null || this.DragWidget !== null ? "dragging " : ""))) + "hf mihx-2 stack clip ") + $.$strNN((this.fullScreen ? "pos-fix t-0 b-0 l-0 r-0 bg-tertiary z-10 " : ""))) + $.$strNN((((this.Features & (4/*PageBuilderFeatures.WidgetTopToolBar*/ | 8/*PageBuilderFeatures.WidgetBottomToolBar*/ | 16/*PageBuilderFeatures.WidgetLeftToolBar*/ | 32/*PageBuilderFeatures.WidgetRightToolBar*/)) == (4/*PageBuilderFeatures.WidgetTopToolBar*/ | 8/*PageBuilderFeatures.WidgetBottomToolBar*/ | 16/*PageBuilderFeatures.WidgetLeftToolBar*/ | 32/*PageBuilderFeatures.WidgetRightToolBar*/)) ? "with-toolbar" : ""));
                }, $GVhnPd ??= {"r":131073,"n":"","d":1080242,"h":0,"f":17825794})))));
                if (((this.Features & (2/*PageBuilderFeatures.TopToolBar*/)) == (2/*PageBuilderFeatures.TopToolBar*/)))
                {
                    __builder.OpenElement(2, "div");
                    __builder.AddAttribute$5(3, "class", "bg-black pd");
                    __builder.OpenComponent$1($.$macw.MACF.EditForm, 4);
                    __builder.AddComponentParameter(5, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                    __builder.AddAttribute$3(6, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*_*/ _0) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 7);
                            __builder2.AddAttribute$3(8, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*___*/ ___) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 9);
                                    __builder3.AddAttribute$3(10, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*____*/ ____) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddMarkupContent(11, "<i class=\"mdi mdi-office-building-cog-outline\"></i>");
                                        }, $zWlGWc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                                    }), $CbqJye ??= {"r":6881395,"p":[{"n":"____","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(12, "\r\n                    ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 13);
                                    __builder3.AddAttribute$3(14, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddMarkupContent(15, "<h3 class=\"mg-0\">Builder</h3>");
                                        }, $vknIEf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                                    }), $mJybQg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(16, "\r\n                    ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 17);
                                    __builder3.AddComponentParameter(18, "Fill", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(19, "\r\n                    ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 20);
                                    __builder3.AddAttribute$3(21, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*____*/ ____) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            $.$yyXP._LCFCPP.TypeInference.CreateInputEditor_0($.$hDPm.LCFCI.PageBuilderMode, __builder4, 22, 23, this.Mode, 24, $.$mac.MAC.EventCallback.Factory.Create$6($.$hDPm.LCFCI.PageBuilderMode, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$hDPm.LCFCI.PageBuilderMode, this, new ($.$$.S.Action$$($.$hDPm.LCFCI.PageBuilderMode))().$ctor(this,  (/*__value*/ __value) =>
                                            {
                                                return this.Mode = __value;
                                            }, $AhJqge ??= {"r":65537,"p":[{"n":"__value","p":66606762}],"n":"","d":1080242,"h":0,"f":17825794}), this.Mode)), 25, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                            {
                                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Mode"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                            }, $AXkhEc ??= {"r":38797349,"n":"","d":1080242,"h":0,"f":17825794})).Invoke()));
                                        }, $KmzAtd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                                    }), $pvIgbi ??= {"r":6881395,"p":[{"n":"____","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(26, "\r\n                    ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 27);
                                    __builder3.AddAttribute$3(28, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*____*/ ____) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 29);
                                            __builder4.AddComponentParameter(30, "Class", "mdi mdi-fullscreen");
                                            __builder4.AddComponentParameter(31, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                            __builder4.AddComponentParameter(32, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToggleFullScreen))));
                                            __builder4.CloseComponent();
                                        }, $LYhrka ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                                    }), $wwSnFh ??= {"r":6881395,"p":[{"n":"____","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }, $helfWk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                            }), $UXTMvh ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }, $NYeegf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                    }), $kkriTb ??= {"r":6881395,"p":[{"n":"_","p":131188}],"n":"","d":1080242,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                __builder.OpenComponent$1($.$hDPm.LCFCCS$7.SideBar, 33);
                __builder.AddComponentParameter(34, "Side", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarSide, this.Context.LCFC$IApplicationContextProvider$IsMobile ? 4/*SideBarSide.Bottom*/ : 1/*SideBarSide.Left*/), $.$hDPm.LCFCCS$7.SideBarSide));
                __builder.AddComponentParameter(35, "ShowSide", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, this.Mode !== 0/*PageBuilderMode.Read*/), $.$$.S.Boolean));
                __builder.AddComponentParameter(36, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/ | 1/*SideBarFeatures.Dynamic*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                __builder.AddComponentParameter(37, "Class", "hf");
                __builder.AddComponentParameter(38, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.AddProperty$1(this.AttributesFor("sidebar"), $.$fPer.LCFC.Stringy.op_Implicit$3("bar-class"), `bdr pdr pos-rel ${$.$strNN((!this.Context.LCFC$IApplicationContextProvider$IsMobile ? (this.Mode === 2/*PageBuilderMode.EditJson*/ ? "wx-3" : "wx-3") : "mahx-2"))}`).AddProperty($.$fPer.LCFC.Stringy.op_Implicit$3("content-class"), "pdl pos-rel")));
                __builder.AddAttribute$3(39, "Bar", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 40);
                    __builder2.AddComponentParameter(41, "Class", "hf");
                    __builder2.AddComponentParameter(42, "Context", "___");
                    __builder2.AddComponentParameter(43, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder2.AddComponentParameter(44, "TabsFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT$1.TabsFeatures, 65/*TabsFeatures.Default*/ | 4/*TabsFeatures.TabsSelectedBorder*/), $.$hDPm.LCFCCT$1.TabsFeatures));
                    __builder2.AddAttribute$3(45, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        /*var*/ let renderer;
                        /*var*/ let bP = (this.DataSource?.LFCD$IWidgetDataSource$BindingPaths ?? null);
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>?*/ let __ca1__;
                        if ((__ca1__ = bP) !== null ? $.$sl.SL.Enumerable.Any$1($.$fPer.LCFCD$1.IPropertyDescriptor, __ca1__) : false)
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 46);
                            __builder3.AddComponentParameter(47, "title-class", "bg-highlight bdb pd clickable");
                            __builder3.AddAttribute$3(48, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(49, "<b>Available Bindings</b>");
                                }, $eBnJmk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                            }), $epwsFd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(50, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(51, "div");
                                    __builder4.AddAttribute$5(52, "class", "flex wrap");
                                    /*int*/ let itheme = 2;
                                    let $en23 = bP.SCG$IEnumerable$$$GetEnumerator();
                                    while ($en23.SC$1$IEnumerator$MoveNext())
                                    {
                                        let binding = $en23.SCG$IEnumerator$$$Current;
                                        {
                                            __builder4.OpenElement(53, "div");
                                            __builder4.AddAttribute$5(54, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("bd" + " bg-" + (($.$fPer.LCFC.Theme.op_Implicit$1(itheme)))) + " cl-white") + " pdx-2") + " pdy-1") + " corner-5") + " fsz-small") + " nowrap") + " animate");
                                            __builder4.AddAttribute$5(55, "title", binding.LCFCD$1$IPropertyDescriptor$Description);
                                            __builder4.AddContent$4(56, binding.LCFCD$1$IPropertyDescriptor$Name);
                                            __builder4.CloseElement();
                                        }
                                    }
                                    __builder4.CloseElement();
                                }, $tiEgMa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                            }), $tFiyPi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }
                        if (this.Mode === 1/*PageBuilderMode.EditDragDrop*/)
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 57);
                            __builder3.AddComponentParameter(58, "title-class", "bg-highlight bdb pd clickable");
                            __builder3.AddAttribute$3(59, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(60, "<b>Components</b>");
                                }, $ffchgj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                            }), $LFhQCh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(61, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$yyXP.LCFCP.ComponentBrowser, 62);
                                    __builder4.AddComponentParameter(63, "Builder", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$yyXP.LCFCP.PageBuilder, this));
                                    __builder4.AddComponentReferenceCapture(64, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                                    {
                                        this.browser = $.$cast(__value, $.$yyXP.LCFCP.ComponentBrowser);
                                    }, $zZowqh ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":1080242,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $YCFwza ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                            }), $MbTKtg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }
                        else if (this.Mode === 2/*PageBuilderMode.EditJson*/ || this.Mode === 3/*PageBuilderMode.EditHtml*/)
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 65);
                            __builder3.AddComponentParameter(66, "title-class", "bg-highlight bdb pd clickable");
                            __builder3.AddAttribute$3(67, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(68, "<b>Editor</b>");
                                }, $lvRUMh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                            }), $NofZMd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(69, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$macw.MACF.EditForm, 70);
                                    __builder4.AddComponentParameter(71, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                                    __builder4.AddAttribute$3(72, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*____*/ ____) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            $.$yyXP._LCFCPP.TypeInference.CreateInputEditor_1($.$$.S.String, __builder5, 73, 74, 16n, 75, "20", 76, this.Json, 77, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                            {
                                                return this.Json = __value;
                                            }, $YLsAbj ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1080242,"h":0,"f":17825794}), this.Json)), 78, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                            {
                                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Json"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                            }, $IeeYXi ??= {"r":38797349,"n":"","d":1080242,"h":0,"f":17825794})).Invoke()));
                                            __builder5.AddMarkupContent(79, "\r\n                                ");
                                            __builder5.OpenElement(80, "small");
                                            __builder5.AddAttribute$5(81, "class", "cl-error");
                                            __builder5.AddContent$4(82, this.jsonError);
                                            __builder5.CloseElement();
                                        }, $lxTplj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                                    }), $mvZkrh ??= {"r":6881395,"p":[{"n":"____","p":131188}],"n":"","d":1080242,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $ATqYbk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                            }), $ACDFFd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }
                        __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 83);
                        __builder3.AddComponentParameter(84, "title-class", "bg-highlight bdb pd clickable");
                        __builder3.AddAttribute$3(85, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(86, "<b>Navigator</b>");
                            }, $HrPadl ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                        }), $yBHcCd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(87, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$yyXP.LCFCP.ComponentNavigator, 88);
                                __builder4.AddComponentParameter(89, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                                __builder4.AddComponentParameter(90, "Builder", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$yyXP.LCFCP.PageBuilder, this));
                                __builder4.AddComponentReferenceCapture(91, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    this.navigator = $.$cast(__value, $.$yyXP.LCFCP.ComponentNavigator);
                                }, $EnoNFg ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":1080242,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                            }, $NIYvjf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                        }), $OoQLLc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        if (this.Mode !== 0/*PageBuilderMode.Read*/ && this.selected !== null && this.Renderers.TryGetValue(this.selected, $.$ref(() => renderer, ($v) => renderer = $v, $.$yyXP.LCFCP.WidgetRenderer)))
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 92);
                            __builder3.AddComponentParameter(93, "title-class", "bg-highlight bdb pd clickable");
                            __builder3.AddComponentParameter(94, "Class", "pdt");
                            __builder3.AddComponentParameter(95, "Name", "selected");
                            __builder3.AddAttribute$3(96, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(97, "b");
                                    __builder4.AddContent$4(98, renderer.Title);
                                    __builder4.CloseElement();
                                }, $VqzwZi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                            }), $tVZTgk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(99, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$yyXP.LCFCP.ComponentEditor, 100);
                                    __builder4.AddComponentParameter(101, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                                    __builder4.AddComponentParameter(102, "Renderer", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$yyXP.LCFCP.WidgetRenderer, renderer));
                                    __builder4.AddComponentParameter(103, "Builder", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$yyXP.LCFCP.PageBuilder, this));
                                    __builder4.SetKey(this.selected);
                                    __builder4.AddComponentReferenceCapture(104, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                                    {
                                        this.editor = $.$cast(__value, $.$yyXP.LCFCP.ComponentEditor);
                                    }, $Gagddg ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":1080242,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $vVqTlh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794});
                            }), $YPSBrb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1080242,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }
                    }), $dGLkua ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794}));
                    __builder2.AddComponentReferenceCapture(105, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.tabs = $.$cast(__value, $.$hDPm.LCFCCT$1.Tabs);
                    }, $TuNmEk ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":1080242,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $hLxgjh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794}));
                __builder.AddAttribute$3(106, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$yyXP.LCFCP.WidgetRenderer, 107);
                    __builder2.AddComponentParameter(108, "Builder", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$yyXP.LCFCP.PageBuilder, this));
                    __builder2.AddComponentParameter(109, "Widget", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCW.Widget, this.Root));
                    __builder2.SetKey(this.Root);
                    __builder2.AddComponentReferenceCapture(110, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.RootRenderer = $.$cast(__value, $.$yyXP.LCFCP.WidgetRenderer);
                    }, $CDnEAa ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":1080242,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $RkgRtd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1080242,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(111670229938)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12949935786)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IPageBuilder.Browser.get
            get LCFCI$IPageBuilder$Browser()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4360001194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Browser;
            }
            //--TRIMMABLE-BOUNDARY-END(12949935786)
            
            //--TRIMMABLE-BOUNDARY-START(12886879984)
            //Generated interface implemetation for LivingThing.FluentUI.Core.Renderer.IRootWidgetRenderer.EditMode.get
            get LFCR$IRootWidgetRenderer$EditMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296945392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EditMode;
            }
            //--TRIMMABLE-BOUNDARY-END(12886879984)
            
            //--TRIMMABLE-BOUNDARY-START(38656683760)
            //Generated interface implemetation for LivingThing.FluentUI.Core.Renderer.IRootWidgetRenderer.ViewBag.get
            get LFCR$IRootWidgetRenderer$ViewBag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131520240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ViewBag;
            }
            //--TRIMMABLE-BOUNDARY-END(38656683760)
            
            //--TRIMMABLE-BOUNDARY-START(30066749168)
            //Generated interface implemetation for LivingThing.FluentUI.Core.Renderer.IRootWidgetRenderer.ServiceProvider.get
            get LFCR$IRootWidgetRenderer$ServiceProvider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836552944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceProvider;
            }
            //--TRIMMABLE-BOUNDARY-END(30066749168)
            
            //--TRIMMABLE-BOUNDARY-START(47246618352)
            //Generated interface implemetation for LivingThing.FluentUI.Core.Renderer.IRootWidgetRenderer.Render(LivingThing.FluentUI.Core.Widgets.Widget?, LivingThing.FluentUI.Core.DataBinding.IWidgetDataSource)
            LFCR$IRootWidgetRenderer$Render()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246618352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Render(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47246618352)
            
            //--TRIMMABLE-BOUNDARY-START(51541585648)
            //Generated interface implemetation for LivingThing.FluentUI.Core.Renderer.IRootWidgetRenderer.RenderChildren(LivingThing.FluentUI.Core.Widgets.ContainerWidget?, LivingThing.FluentUI.Core.DataBinding.IWidgetDataSource)
            LFCR$IRootWidgetRenderer$RenderChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541585648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RenderChildren(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(51541585648)
            
            //--TRIMMABLE-BOUNDARY-START(77310491570)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310491570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77310491570)
            
            //--TRIMMABLE-BOUNDARY-START(77310491570)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(77310491570)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(476742450098)
                this.ModeChanged = $.$default($.$mac.MAC.EventCallback$$($.$hDPm.LCFCI.PageBuilderMode));
                //--TRIMMABLE-BOUNDARY-END(476742450098)
                
                //--TRIMMABLE-BOUNDARY-START(536871992242)
                this.Root = new $.$bMcF.LFCW.UIRootWidget().$ctor$7();
                //--TRIMMABLE-BOUNDARY-END(536871992242)
                
                //--TRIMMABLE-BOUNDARY-START(541166959538)
                this.RootChanged = $.$default($.$mac.MAC.EventCallback$$($.$bMcF.LFCW.UIRootWidget));
                //--TRIMMABLE-BOUNDARY-END(541166959538)
                
                //--TRIMMABLE-BOUNDARY-START(493922319282)
                this.OnNewWidget = $.$default($.$mac.MAC.EventCallback$$($.$bMcF.LFCW.Widget));
                //--TRIMMABLE-BOUNDARY-END(493922319282)
                
                //--TRIMMABLE-BOUNDARY-START(214749445042)
                this.Features = 60;
                //--TRIMMABLE-BOUNDARY-END(214749445042)
                
                //--TRIMMABLE-BOUNDARY-START(124555131826)
                this.Context = null;
                //--TRIMMABLE-BOUNDARY-END(124555131826)
                
                //--TRIMMABLE-BOUNDARY-START(558346828722)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(558346828722)
                
                //--TRIMMABLE-BOUNDARY-START(511102188466)
                this.Prompt = null;
                //--TRIMMABLE-BOUNDARY-END(511102188466)
                
                //--TRIMMABLE-BOUNDARY-START(450972646322)
                this.JavaScript = null;
                //--TRIMMABLE-BOUNDARY-END(450972646322)
                
                //--TRIMMABLE-BOUNDARY-START(751620357042)
                this.StorageService = null;
                //--TRIMMABLE-BOUNDARY-END(751620357042)
                
                //--TRIMMABLE-BOUNDARY-START(773095193522)
                this.UI = null;
                //--TRIMMABLE-BOUNDARY-END(773095193522)
                
                //--TRIMMABLE-BOUNDARY-START(532577024946)
                this.Renderers = new ($.$$.SCG.Dictionary$$$($.$bMcF.LFCW.Widget, $.$yyXP.LCFCP.WidgetRenderer))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(532577024946)
                
            }
            static $h = 1080242;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(502512253874),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 347893431218,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1080242,
      "h": 502512253874,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(502512253874),
//--TRIMMABLE-BOUNDARY-START(472447482802),
    {
      "p": 66606762,
      "g": {
        "r": 0,
        "d": 0,
        "h": 322123627442,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 644246174642,
        "f": 83886081
      },
      "n": "Mode",
      "d": 1080242,
      "h": 472447482802,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(472447482802),
//--TRIMMABLE-BOUNDARY-START(790275062706),
    {
      "p": $.$typeArray($.$$.S.Type).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 442382711730,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 738735455154,
        "f": 83886081
      },
      "n": "Widgets",
      "d": 1080242,
      "h": 790275062706,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(790275062706),
//--TRIMMABLE-BOUNDARY-START(476742450098),
    {
      "p": $.$mac.MAC.EventCallback$$($.$hDPm.LCFCI.PageBuilderMode).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 330713562034,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 652836109234,
        "f": 83886081
      },
      "n": "ModeChanged",
      "d": 1080242,
      "h": 476742450098,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(476742450098),
//--TRIMMABLE-BOUNDARY-START(536871992242),
    {
      "p": 9514736,
      "g": {
        "r": 0,
        "d": 0,
        "h": 373663234994,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 687195847602,
        "f": 83886081
      },
      "n": "Root",
      "d": 1080242,
      "h": 536871992242,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(536871992242),
//--TRIMMABLE-BOUNDARY-START(541166959538),
    {
      "p": $.$mac.MAC.EventCallback$$($.$bMcF.LFCW.UIRootWidget).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 382253169586,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 695785782194,
        "f": 83886081
      },
      "n": "RootChanged",
      "d": 1080242,
      "h": 541166959538,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(541166959538),
//--TRIMMABLE-BOUNDARY-START(493922319282),
    {
      "p": $.$mac.MAC.EventCallback$$($.$bMcF.LFCW.Widget).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 339303496626,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 661426043826,
        "f": 83886081
      },
      "n": "OnNewWidget",
      "d": 1080242,
      "h": 493922319282,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(493922319282),
//--TRIMMABLE-BOUNDARY-START(214749445042),
    {
      "p": 1145778,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296353823666,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 618476370866,
        "f": 83886081
      },
      "n": "Features",
      "d": 1080242,
      "h": 214749445042,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214749445042),
//--TRIMMABLE-BOUNDARY-START(133145066418),
    {
      "p": 1453808,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253404150706,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 584116632498,
        "f": 83886081
      },
      "n": "DataSource",
      "d": 1080242,
      "h": 133145066418,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133145066418),
//--TRIMMABLE-BOUNDARY-START(124555131826),
    {
      "p": 46041430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244814216114,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 575526697906,
        "f": 83886081
      },
      "n": "Context",
      "d": 1080242,
      "h": 124555131826,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124555131826),
//--TRIMMABLE-BOUNDARY-START(558346828722),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 408022973362,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 712965651378,
        "f": 83886081
      },
      "n": "Server",
      "d": 1080242,
      "h": 558346828722,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(558346828722),
//--TRIMMABLE-BOUNDARY-START(511102188466),
    {
      "p": 65427114,
      "g": {
        "r": 0,
        "d": 0,
        "h": 356483365810,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 670015978418,
        "f": 83886081
      },
      "n": "Prompt",
      "d": 1080242,
      "h": 511102188466,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(511102188466),
//--TRIMMABLE-BOUNDARY-START(450972646322),
    {
      "p": 64509610,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304943758258,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 627066305458,
        "f": 83886081
      },
      "n": "JavaScript",
      "d": 1080242,
      "h": 450972646322,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(450972646322),
//--TRIMMABLE-BOUNDARY-START(751620357042),
    {
      "p": 63932758,
      "g": {
        "r": 0,
        "d": 0,
        "h": 416612907954,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 721555585970,
        "f": 83886081
      },
      "n": "StorageService",
      "d": 1080242,
      "h": 751620357042,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(751620357042),
//--TRIMMABLE-BOUNDARY-START(773095193522),
    {
      "p": 5594536,
      "g": {
        "r": 0,
        "d": 0,
        "h": 425202842546,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 730145520562,
        "f": 83886081
      },
      "n": "UI",
      "d": 1080242,
      "h": 773095193522,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(773095193522),
//--TRIMMABLE-BOUNDARY-START(206159510450),
    {
      "p": 1847024,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287763889074,
        "f": 50331649
      },
      "n": "EditMode",
      "d": 1080242,
      "h": 206159510450,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206159510450),
//--TRIMMABLE-BOUNDARY-START(532577024946),
    {
      "p": $.$$.SCG.Dictionary$$$($.$bMcF.LFCW.Widget, $.$yyXP.LCFCP.WidgetRenderer).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 365073300402,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 678605913010,
        "f": 83886088
      },
      "n": "Renderers",
      "d": 1080242,
      "h": 532577024946,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(532577024946),
//--TRIMMABLE-BOUNDARY-START(785980095410),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 433792777138,
        "f": 50331649
      },
      "n": "ViewBag",
      "d": 1080242,
      "h": 785980095410,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(785980095410),
//--TRIMMABLE-BOUNDARY-START(107375262642),
    {
      "p": 65099434,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227634346930,
        "f": 50331649
      },
      "n": "Browser",
      "d": 1080242,
      "h": 107375262642,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375262642),
//--TRIMMABLE-BOUNDARY-START(455267613618),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313533692850,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 635656240050,
        "f": 83886082
      },
      "n": "Json",
      "d": 1080242,
      "h": 455267613618,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(455267613618),
//--TRIMMABLE-BOUNDARY-START(120260164530),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236224281522,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 566936763314,
        "f": 83886088
      },
      "n": "ClipBoard",
      "d": 1080242,
      "h": 120260164530,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(120260164530),
//--TRIMMABLE-BOUNDARY-START(154619902898),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261994085298,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 592706567090,
        "f": 83886088
      },
      "n": "DragComponent",
      "d": 1080242,
      "h": 154619902898,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(154619902898),
//--TRIMMABLE-BOUNDARY-START(184684673970),
    {
      "p": 9907952,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279173954482,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 609886436274,
        "f": 83886088
      },
      "n": "DragWidget",
      "d": 1080242,
      "h": 184684673970,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(184684673970),
//--TRIMMABLE-BOUNDARY-START(180389706674),
    {
      "p": 5517040,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270584019890,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 601296501682,
        "f": 83886088
      },
      "n": "DragOver",
      "d": 1080242,
      "h": 180389706674,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(180389706674),
//--TRIMMABLE-BOUNDARY-START(554051861426),
    {
      "p": 9907952,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399433038770,
        "f": 50331649
      },
      "n": "Selected",
      "d": 1080242,
      "h": 554051861426,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(554051861426),
//--TRIMMABLE-BOUNDARY-START(545461926834),
    {
      "p": 1670066,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390843104178,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 704375716786,
        "f": 83886082
      },
      "n": "RootRenderer",
      "d": 1080242,
      "h": 545461926834,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(545461926834)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(768800226226),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1080242,
      "h": 768800226226,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(768800226226),
//--TRIMMABLE-BOUNDARY-START(446677679026),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1080242,
      "h": 446677679026,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(446677679026),
//--TRIMMABLE-BOUNDARY-START(764505258930),
    {
      "r": 65537,
      "n": "ToggleFullScreen",
      "d": 1080242,
      "h": 764505258930,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(764505258930),
//--TRIMMABLE-BOUNDARY-START(747325389746),
    {
      "r": 181338113,
      "p": [
        {
          "n": "value",
          "p": 9907952
        },
        {
          "n": "switchToTab",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "SetSelected",
      "d": 1080242,
      "h": 747325389746,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(747325389746),
//--TRIMMABLE-BOUNDARY-START(489627351986),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1080242,
      "h": 489627351986,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(489627351986),
//--TRIMMABLE-BOUNDARY-START(141735001010),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1080242,
      "h": 141735001010,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(141735001010),
//--TRIMMABLE-BOUNDARY-START(498217286578),
    {
      "r": 65537,
      "n": "OnParametersSet",
      "d": 1080242,
      "h": 498217286578,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(498217286578),
//--TRIMMABLE-BOUNDARY-START(463857548210),
    {
      "r": 65537,
      "n": "MarkDirty",
      "d": 1080242,
      "h": 463857548210,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(463857548210),
//--TRIMMABLE-BOUNDARY-START(485332384690),
    {
      "r": 178454529,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": 1080242,
      "h": 485332384690,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(485332384690),
//--TRIMMABLE-BOUNDARY-START(743030422450),
    {
      "r": 181338113,
      "p": [
        {
          "n": "id",
          "p": 1310721
        },
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "SetLabelText",
      "d": 1080242,
      "h": 743030422450,
      "f": 16777217,
      "a": [
        {
          "t": 2818162,
          "c": 8592752754
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(743030422450),
//--TRIMMABLE-BOUNDARY-START(85900426162),
    {
      "r": $.$$.STT.ValueTask$$($.$bMcF.LFCW.Widget).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "container",
          "p": 5517040
        }
      ],
      "n": "AddComponent",
      "d": 1080242,
      "h": 85900426162,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(85900426162),
//--TRIMMABLE-BOUNDARY-START(115965197234),
    {
      "r": 181338113,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        }
      ],
      "n": "ChooseAndAddComponent",
      "d": 1080242,
      "h": 115965197234,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(115965197234),
//--TRIMMABLE-BOUNDARY-START(201864543154),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 9907952
        }
      ],
      "n": "EditAttributes",
      "d": 1080242,
      "h": 201864543154,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(201864543154),
//--TRIMMABLE-BOUNDARY-START(777390160818),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 9907952
        }
      ],
      "n": "Unbind",
      "d": 1080242,
      "h": 777390160818,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(777390160818),
//--TRIMMABLE-BOUNDARY-START(188979641266),
    {
      "r": 181338113,
      "p": [
        {
          "n": "targetWidget",
          "p": 9907952
        }
      ],
      "n": "DropOn",
      "d": 1080242,
      "h": 188979641266,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(188979641266),
//--TRIMMABLE-BOUNDARY-START(158914870194),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 9907952
        }
      ],
      "n": "DragComponentStart",
      "d": 1080242,
      "h": 158914870194,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(158914870194),
//--TRIMMABLE-BOUNDARY-START(163209837490),
    {
      "r": 181338113,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        }
      ],
      "n": "DragEnter",
      "d": 1080242,
      "h": 163209837490,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(163209837490),
//--TRIMMABLE-BOUNDARY-START(176094739378),
    {
      "r": 181338113,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        }
      ],
      "n": "DragLeave",
      "d": 1080242,
      "h": 176094739378,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(176094739378),
//--TRIMMABLE-BOUNDARY-START(193274608562),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 9907952
        }
      ],
      "n": "Duplicate",
      "d": 1080242,
      "h": 193274608562,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(193274608562),
//--TRIMMABLE-BOUNDARY-START(128850099122),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 9907952
        }
      ],
      "n": "Copy",
      "d": 1080242,
      "h": 128850099122,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(128850099122),
//--TRIMMABLE-BOUNDARY-START(506807221170),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 9907952
        }
      ],
      "n": "Paste",
      "d": 1080242,
      "h": 506807221170,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(506807221170),
//--TRIMMABLE-BOUNDARY-START(519692123058),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 9907952
        }
      ],
      "n": "Remove",
      "d": 1080242,
      "h": 519692123058,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(519692123058),
//--TRIMMABLE-BOUNDARY-START(197569575858),
    {
      "r": 181338113,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        }
      ],
      "n": "Edit",
      "d": 1080242,
      "h": 197569575858,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(197569575858),
//--TRIMMABLE-BOUNDARY-START(781685128114),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 9907952
        }
      ],
      "n": "Up",
      "d": 1080242,
      "h": 781685128114,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(781685128114),
//--TRIMMABLE-BOUNDARY-START(150324935602),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 9907952
        }
      ],
      "n": "Down",
      "d": 1080242,
      "h": 150324935602,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(150324935602),
//--TRIMMABLE-BOUNDARY-START(90195393458),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 9907952
        }
      ],
      "n": "AddLeftColumn",
      "d": 1080242,
      "h": 90195393458,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(90195393458),
//--TRIMMABLE-BOUNDARY-START(94490360754),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 9907952
        }
      ],
      "n": "AddRightColumn",
      "d": 1080242,
      "h": 94490360754,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(94490360754),
//--TRIMMABLE-BOUNDARY-START(98785328050),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 9907952
        }
      ],
      "n": "AddTopRow",
      "d": 1080242,
      "h": 98785328050,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(98785328050),
//--TRIMMABLE-BOUNDARY-START(81605458866),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 9907952
        }
      ],
      "n": "AddBottomRow",
      "d": 1080242,
      "h": 81605458866,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(81605458866),
//--TRIMMABLE-BOUNDARY-START(760210291634),
    {
      "r": 178454529,
      "n": "TemplateMarket",
      "d": 1080242,
      "h": 760210291634,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(760210291634),
//--TRIMMABLE-BOUNDARY-START(515397155762),
    {
      "r": 178454529,
      "n": "Publish",
      "d": 1080242,
      "h": 515397155762,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(515397155762),
//--TRIMMABLE-BOUNDARY-START(523987090354),
    {
      "r": 131073,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        },
        {
          "n": "dataSource",
          "p": 1453808
        }
      ],
      "n": "Render",
      "d": 1080242,
      "h": 523987090354,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(523987090354),
//--TRIMMABLE-BOUNDARY-START(528282057650),
    {
      "r": 131073,
      "p": [
        {
          "n": "container",
          "p": 5517040
        },
        {
          "n": "dataSource",
          "p": 1453808
        }
      ],
      "n": "RenderChildren",
      "d": 1080242,
      "h": 528282057650,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(528282057650),
//--TRIMMABLE-BOUNDARY-START(111670229938),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1080242,
      "h": 111670229938,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(111670229938)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(468152515506),
    {
      "t": 66606762,
      "n": "mode",
      "d": 1080242,
      "h": 468152515506,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(468152515506),
//--TRIMMABLE-BOUNDARY-START(137440033714),
    {
      "t": 262145,
      "n": "dirty",
      "d": 1080242,
      "h": 137440033714,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(137440033714),
//--TRIMMABLE-BOUNDARY-START(103080295346),
    {
      "t": 490418,
      "n": "browser",
      "d": 1080242,
      "h": 103080295346,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(103080295346),
//--TRIMMABLE-BOUNDARY-START(219044412338),
    {
      "t": 262145,
      "n": "fullScreen",
      "d": 1080242,
      "h": 219044412338,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(219044412338),
//--TRIMMABLE-BOUNDARY-START(459562580914),
    {
      "t": 1310721,
      "n": "jsonError",
      "d": 1080242,
      "h": 459562580914,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(459562580914),
//--TRIMMABLE-BOUNDARY-START(167504804786),
    {
      "t": 188547073,
      "n": "draggingComponent",
      "d": 1080242,
      "h": 167504804786,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(167504804786),
//--TRIMMABLE-BOUNDARY-START(171799772082),
    {
      "t": 9907952,
      "n": "draggingWidget",
      "d": 1080242,
      "h": 171799772082,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(171799772082),
//--TRIMMABLE-BOUNDARY-START(755915324338),
    {
      "t": 55793322,
      "n": "tabs",
      "d": 1080242,
      "h": 755915324338,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(755915324338),
//--TRIMMABLE-BOUNDARY-START(210454477746),
    {
      "t": 555954,
      "n": "editor",
      "d": 1080242,
      "h": 210454477746,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(210454477746),
//--TRIMMABLE-BOUNDARY-START(481037417394),
    {
      "t": 621490,
      "n": "navigator",
      "d": 1080242,
      "h": 481037417394,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(481037417394),
//--TRIMMABLE-BOUNDARY-START(549756894130),
    {
      "t": 9907952,
      "n": "selected",
      "d": 1080242,
      "h": 549756894130,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(549756894130),
//--TRIMMABLE-BOUNDARY-START(146029968306),
    {
      "t": 262145,
      "n": "disposed",
      "d": 1080242,
      "h": 146029968306,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(146029968306)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(77310491570),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1080242,
      "h": 77310491570,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310491570)
  ],
  "h": 1080242,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/PageBuilder",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCI.IPageBuilder, $.$bMcF.LFCR.IRootWidgetRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.PageBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}PageBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1080242)
        
        

        //--TRIMMABLE-BOUNDARY-START(555954)
        $asm.$cls(`$yyXP.LCFCP.ComponentEditor`, ($self) => class ComponentEditor extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(73014999986)
            /*string */ get OptimizedComponentName()
            {
                return "componenteditor";
            }
            //--TRIMMABLE-BOUNDARY-END(73014999986)
            
            //--TRIMMABLE-BOUNDARY-START(98784803762)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784803762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Renderer":
                    this.Renderer = $.$cast(parameter.Value, $.$yyXP.LCFCP.WidgetRenderer);
                    return true;
                    case "Builder":
                    this.Builder = $.$cast(parameter.Value, $.$yyXP.LCFCP.PageBuilder);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(98784803762)
            
            //--TRIMMABLE-BOUNDARY-START(25770359730)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770359730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this.Renderer?.Target ?? null) !== null)
                {
                    __builder.AddContent$1(0, this.GetForm());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770359730)
            
            //--TRIMMABLE-BOUNDARY-START(4295523250)
            /*RenderFragment */ _GetForm(T, /*T*/ target)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295523250);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$(T), 1);
                        __builder2.AddComponentParameter(2, "Model", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck(T, target), T));
                        __builder2.AddComponentParameter(3, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                        __builder2.AddComponentParameter(4, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.OwnAttributes(null)));
                        __builder2.AddComponentParameter(5, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                        __builder2.AddComponentParameter(6, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCF$2.FormBuilderFeatures, 0/*FormBuilderFeatures.Default*/ | 128/*FormBuilderFeatures.ComplexFieldsAsAccordion*/), $.$hDPm.LCFCCF$2.FormBuilderFeatures));
                        __builder2.AddComponentParameter(7, "FieldFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$2.InputFieldFeatures, 4/*InputFieldFeatures.Default*/ | 2/*InputFieldFeatures.Horizontal*/), $.$hDPm.LCFCCI$2.InputFieldFeatures));
                        __builder2.AddComponentParameter(8, "accordiontab-class", "bdb pdb");
                        __builder2.AddComponentParameter(9, "accordiontab-content-class", "pdt");
                        __builder2.AddComponentParameter(10, "accordiontab-title-class", "pd bg-highlight");
                        __builder2.AddComponentParameter(11, "field-class", "mgx");
                        __builder2.AddComponentParameter(12, "field-label-class", "fsz-small");
                        __builder2.CloseComponent();
                    }, $TWaeWb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":555954,"h":0,"f":17825794});
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295523250)
            
            //--TRIMMABLE-BOUNDARY-START(64425065394)
            /*RenderFragment */ GetForm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425065394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*dynamic*/ let m = this.Renderer.Target;
                return this._GetForm(T, m);
            }
            //--TRIMMABLE-BOUNDARY-END(64425065394)
            
            //--TRIMMABLE-BOUNDARY-START(77309967282)
            /*WidgetRenderer*/ Renderer = null;
            //--TRIMMABLE-BOUNDARY-END(77309967282)
            
            //--TRIMMABLE-BOUNDARY-START(21475392434)
            /*PageBuilder*/ Builder = null;
            //--TRIMMABLE-BOUNDARY-END(21475392434)
            
            //--TRIMMABLE-BOUNDARY-START(30065327026)
            /*void */ Field(/*IObservableDataDescriptor*/ field)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065327026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                field.LCFCR$IReactiveObservable$Subscribe(new ($.$$.S.Action$$$($.$fPer.LCFCR.IReactiveObservable, $.$fPer.LCFCR.IReactiveObservableChanges))().$ctor(this,  (/*s*/ s, /*v*/ v) =>
                {
                    if (this.Renderer.Component !== null)
                    {
                        this.Renderer.Widget.Attributes.set_Item(field.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$Name, v.LCFCR$IReactiveObservableChanges$NewValue);
                    }
                    this.Builder.MarkDirty();
                    _ = this.Renderer.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\ComponentEditor.razor.cs", "Field", 30);
                }, $IedFyg ??= {"r":65537,"p":[{"n":"s","p":54167894},{"n":"v","p":54298966}],"n":"","d":555954,"h":0,"f":17825794}), null, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(30065327026)
            
            //--TRIMMABLE-BOUNDARY-START(34360294322)
            /*bool */ FilterProperty(/*object*/ model, /*IPropertyDescriptor*/ property)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360294322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Renderer.Component !== null)
                {
                    return property.LCFCD$1$IPropertyDescriptor$GetAttribute($.$mac.MAC.ParameterAttribute) !== null && !$.$mac.MAC.EventCallback.$type.IsAssignableFrom(property.LCFCD$1$IPropertyDescriptor$ValueType.LCFCD$1$ITypeDescriptor$SystemType) && !(property.LCFCD$1$IPropertyDescriptor$ValueType.LCFCD$1$ITypeDescriptor$SystemType.IsGenericType && $.$mac.MAC.EventCallback$$().$type.IsAssignableFrom(property.LCFCD$1$IPropertyDescriptor$ValueType.LCFCD$1$ITypeDescriptor$SystemType.GetGenericTypeDefinition())) && property.LCFCD$1$IPropertyDescriptor$ValueType.LCFCD$1$ITypeDescriptor$SystemType !== $.$mac.MAC.RenderFragment.$type;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(34360294322)
            
            //--TRIMMABLE-BOUNDARY-START(68720032690)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720032690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Edit($.$fPer.LCFC.InputType, new ($.$$.S.Func$$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$fPer.LCFCA$1.SchemaType, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p, /*s*/ s) =>
                {
                    return p.LCFCD$1$IPropertyDescriptor$Name === "InputType";
                }, $ybDgel ??= {"r":262145,"p":[{"n":"p","p":40733014},{"n":"s","p":2722134}],"n":"","d":555954,"h":0,"f":17825794}), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                {
                    /*var*/ let param_p = $.$sle.SLE.Expression.Parameter($.$fPer.LCFCD$1.IPropertyDescriptor.$type, "p");
                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5(param_p, "InputType"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [ param_p ], null, null));
                }, $UpNEFb ??= {"r":38797349,"n":"","d":555954,"h":0,"f":17825794})).Invoke()), new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$fPer.LCFC.InputType))().$ctor(this,  (/*t*/ t) =>
                {
                    return 20n;
                }, $CiPHxj ??= {"r":47614294,"p":[{"n":"t","p":40733014}],"n":"","d":555954,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(68720032690)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4318975658)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.FormBuilder.IFormFieldEditController.Field(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor)
            LCFCCF$2$IFormFieldEditController$Field()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4318975658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Field(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4318975658)
            
            //--TRIMMABLE-BOUNDARY-START(4319237802)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.FormBuilder.IFormFilterController.FilterProperty(object, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor)
            LCFCCF$2$IFormFilterController$FilterProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4319237802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FilterProperty(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4319237802)
            
            //--TRIMMABLE-BOUNDARY-START(4335831382)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptorModifier.ModifyDescriptor(LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptorModifierBuilder)
            LCFCD$1$IPropertyDescriptorModifier$ModifyDescriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4335831382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ModifyDescriptor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4335831382)
            
            //--TRIMMABLE-BOUNDARY-START(17180425138)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180425138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180425138)
            
            //--TRIMMABLE-BOUNDARY-START(17180425138)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17180425138)
            
            static $h = 555954;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014999986),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540163506,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 555954,
      "h": 73014999986,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73014999986),
//--TRIMMABLE-BOUNDARY-START(77309967282),
    {
      "p": 1670066,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130098098,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489836466,
        "f": 83886081
      },
      "n": "Renderer",
      "d": 555954,
      "h": 77309967282,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77309967282),
//--TRIMMABLE-BOUNDARY-START(21475392434),
    {
      "p": 1080242,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950228914,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899901874,
        "f": 83886081
      },
      "n": "Builder",
      "d": 555954,
      "h": 21475392434,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475392434)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98784803762),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 555954,
      "h": 98784803762,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98784803762),
//--TRIMMABLE-BOUNDARY-START(25770359730),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 555954,
      "h": 25770359730,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770359730),
//--TRIMMABLE-BOUNDARY-START(4295523250),
    {
      "r": 6881395,
      "p": [
        {
          "n": "target",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "_GetForm",
      "d": 555954,
      "h": 4295523250,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(4295523250),
//--TRIMMABLE-BOUNDARY-START(64425065394),
    {
      "r": 6881395,
      "n": "GetForm",
      "d": 555954,
      "h": 64425065394,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425065394),
//--TRIMMABLE-BOUNDARY-START(30065327026),
    {
      "r": 65537,
      "p": [
        {
          "n": "field",
          "p": 40536406
        }
      ],
      "n": "Field",
      "d": 555954,
      "h": 30065327026,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065327026),
//--TRIMMABLE-BOUNDARY-START(34360294322),
    {
      "r": 262145,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "property",
          "p": 40733014
        }
      ],
      "n": "FilterProperty",
      "d": 555954,
      "h": 34360294322,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360294322),
//--TRIMMABLE-BOUNDARY-START(68720032690),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 555954,
      "h": 68720032690,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720032690)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180425138),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 555954,
      "h": 17180425138,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180425138)
  ],
  "h": 555954
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCF$2.IFormFieldEditController, $.$hDPm.LCFCCF$2.IFormFilterController, $.$hDPm.LCFCCF$2.IFormFieldEditPropertyController, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$hDPm.LCFCCF$2.IFormController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.ComponentEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}ComponentEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(555954)
        
        

        //--TRIMMABLE-BOUNDARY-START(490418)
        $asm.$cls(`$yyXP.LCFCP.ComponentBrowser`, ($self) => class ComponentBrowser extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(68719967154)
            /*string */ get OptimizedComponentName()
            {
                return "componentbrowser";
            }
            //--TRIMMABLE-BOUNDARY-END(68719967154)
            
            //--TRIMMABLE-BOUNDARY-START(81604869042)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604869042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Builder":
                    this.Builder = $.$cast(parameter.Value, $.$yyXP.LCFCP.PageBuilder);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(81604869042)
            
            //--TRIMMABLE-BOUNDARY-START(8590425010)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590425010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<Type>*/ let componentTypes = new ($.$$.SCG.List$$($.$$.S.Type))().$ctor$1();
                /*var*/ let assemblies = $.$$.S.AppDomain.CurrentDomain.GetAssemblies();
                let $i2 = 0;
                let $arr2 = assemblies;
                while ($i2 < $arr2.length)
                {
                    let a = $arr2[$i2++];
                    try
                    {
                        /*var*/ let types = a.GetExportedTypes();
                        let $i3 = 0;
                        let $arr3 = types;
                        while ($i3 < $arr3.length)
                        {
                            let type = $arr3[$i3++];
                            if (!type.IsAbstract$1 && !type.IsGenericType && $.$hDPm.LCFCC$1.IWidgetComponent.$type.IsAssignableFrom(type))
                            {
                                componentTypes.Add(type);
                            }
                        }
                    }
                    catch($e)
                    {
                    }
                }
                $.$yyXP.LCFCP.ComponentBrowser.components = $.$sl.SL.Enumerable.ToArray($.$$.S.Type, $.$sl.SL.Enumerable.Concat($.$$.S.Type, $.$bMcF.LFCW.WidgetFactory.WidgetTypes, componentTypes));
            }
            //--TRIMMABLE-BOUNDARY-END(8590425010)
            
            //--TRIMMABLE-BOUNDARY-START(17180359602)
            /*PageBuilder*/ Builder = null;
            //--TRIMMABLE-BOUNDARY-END(17180359602)
            
            //--TRIMMABLE-BOUNDARY-START(25770294194)
            /*Type[]*/ static components = null;
            //--TRIMMABLE-BOUNDARY-END(25770294194)
            
            //--TRIMMABLE-BOUNDARY-START(55835065266)
            static /*Type[] */ GetComponents(/*bool*/ includeRazorComponents)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835065266);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !includeRazorComponents ? $.$sl.SL.Enumerable.ToArray($.$$.S.Type, $.$sl.SL.Enumerable.Except$1($.$$.S.Type, $.$bMcF.LFCW.WidgetFactory.WidgetTypes, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [$.$bMcF.LFCW.UIRootWidget.$type, $.$bMcF.LFCW.NopWidget.$type, $.$bMcF.LFCW.ComponentWidget.$type], null, null))) : $.$yyXP.LCFCP.ComponentBrowser.components;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835065266)
            
            //--TRIMMABLE-BOUNDARY-START(51540097970)
            static /*Type? */ Get(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540097970);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return name === null ? null : $.$sl.SL.Enumerable.SingleOrDefault$1($.$$.S.Type, $.$yyXP.LCFCP.ComponentBrowser.GetComponents(true), new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.FullName === name;
                    }, $nLOBcb ??= {"r":262145,"p":[{"n":"c","p":188547073}],"n":"","d":490418,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.FirstOrDefault$1($.$$.S.Type, $.$yyXP.LCFCP.ComponentBrowser.GetComponents(true), new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Name === name;
                    }, $ZtXHre ??= {"r":262145,"p":[{"n":"c","p":188547073}],"n":"","d":490418,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540097970)
            
            //--TRIMMABLE-BOUNDARY-START(64424999858)
            /*Type[] */ LCFCI$IPageComponentBrowser$GetComponents(/*bool*/ includeRazorComponents)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424999858);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$yyXP.LCFCP.ComponentBrowser.GetComponents(includeRazorComponents);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424999858)
            
            //--TRIMMABLE-BOUNDARY-START(60130032562)
            /*Type? */ LCFCI$IPageComponentBrowser$Get(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130032562);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$yyXP.LCFCP.ComponentBrowser.Get(name);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130032562)
            
            //--TRIMMABLE-BOUNDARY-START(30065261490)
            /*IEnumerable<IDataListItemContext<Type>> */ Filter(/*IEnumerable<IDataListItemContext<Type>>*/ models, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065261490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !$.$$.S.String.IsNullOrEmpty(key) ? $.$sl.SL.Enumerable.Where($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.S.Type), models, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.S.Type), $.$$.S.Boolean))().$ctor(this,  (/*m*/ m) =>
                {
                    return $.$$.S.String.Contains$2.call(m.LCFCCD$1$IDataListItemContext$$$Data.Name, key, 3/*StringComparison.InvariantCultureIgnoreCase*/);
                }, $pIuEma ??= {"r":262145,"p":[{"n":"m","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.S.Type).$h}],"n":"","d":490418,"h":0,"f":17825794})) : models;
            }
            //--TRIMMABLE-BOUNDARY-END(30065261490)
            
            //--TRIMMABLE-BOUNDARY-START(21475326898)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475326898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$yyXP._LCFCPC.TypeInference.CreateDataList_0($.$$.S.Type, __builder, 0, 1, this.Builder.Widgets ?? $.$yyXP.LCFCP.ComponentBrowser.GetComponents(((this.Builder.Features & (1/*PageBuilderFeatures.RazorComponents*/)) == (1/*PageBuilderFeatures.RazorComponents*/))), 2, true, 3, 10, 4, 70, 5, 35184372092928n | 8n, 6, "Widgets", 7, this, 8, $.$fPer.LCFCD.DataFilter.All, 9, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Type, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.Type))))().$ctor(this,  (/*component*/ component) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$yyXP.LCFCP.ComponentThumbnail, 10);
                        __builder2.AddComponentParameter(11, "Type", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Type, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Type, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.Type)).op_Implicit$1(component)));
                        __builder2.AddComponentParameter(12, "Builder", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$yyXP.LCFCP.PageBuilder, this.Builder));
                        __builder2.CloseComponent();
                    }, $LIZLtc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":490418,"h":0,"f":17825794});
                }, $ccrFba ??= {"r":6881395,"p":[{"n":"component","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Type, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.Type)).$h}],"n":"","d":490418,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(21475326898)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4312946346)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListPostFilterController<System.Type>.Filter(System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.IDataListItemContext<System.Type>>, string?)
            LCFCCD$1$IDataListPostFilterController$System$Type$Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312946346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312946346)
            
            //--TRIMMABLE-BOUNDARY-START(12885392306)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885392306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885392306)
            
            //--TRIMMABLE-BOUNDARY-START(12885392306)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885392306)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180359602)
                this.Builder = null;
                //--TRIMMABLE-BOUNDARY-END(17180359602)
                
            }
            static $h = 490418;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719967154),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245130674,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 490418,
      "h": 68719967154,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68719967154),
//--TRIMMABLE-BOUNDARY-START(17180359602),
    {
      "p": 1080242,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655196082,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309901746,
        "f": 83886081
      },
      "n": "Builder",
      "d": 490418,
      "h": 17180359602,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180359602)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81604869042),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 490418,
      "h": 81604869042,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604869042),
//--TRIMMABLE-BOUNDARY-START(55835065266),
    {
      "r": $.$typeArray($.$$.S.Type).$h,
      "p": [
        {
          "n": "includeRazorComponents",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "GetComponents",
      "d": 490418,
      "h": 55835065266,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835065266),
//--TRIMMABLE-BOUNDARY-START(51540097970),
    {
      "r": 188547073,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Get",
      "d": 490418,
      "h": 51540097970,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540097970),
//--TRIMMABLE-BOUNDARY-START(30065261490),
    {
      "r": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.S.Type)).$h,
      "p": [
        {
          "n": "models",
          "p": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.S.Type)).$h
        },
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "Filter",
      "d": 490418,
      "h": 30065261490,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065261490),
//--TRIMMABLE-BOUNDARY-START(21475326898),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 490418,
      "h": 21475326898,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475326898)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770294194),
    {
      "t": $.$typeArray($.$$.S.Type).$h,
      "n": "components",
      "d": 490418,
      "h": 25770294194,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25770294194)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885392306),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 490418,
      "h": 12885392306,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885392306)
  ],
  "h": 490418
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCI.IPageComponentBrowser, $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$$.S.Type), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$$.S.Type), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.ComponentBrowser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}ComponentBrowser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(490418)
        
        

        //--TRIMMABLE-BOUNDARY-START(1866674)
        $asm.$cls(`$yyXP.LCFCPWB.BannerWidget`, ($self) => class BannerWidget extends $.$bMcF.LFCW.ContainerWidget
        {
            //--TRIMMABLE-BOUNDARY-START(25771670450)
            $ctor$6()
            {
                super.$ctor$5("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\BannerWidget.cs", 25);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771670450);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771670450)
            
            //--TRIMMABLE-BOUNDARY-START(30066637746)
            $ctor$7(/*string?*/ component, /*int*/ line)
            {
                super.$ctor$5(component, line);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066637746);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066637746)
            
            //--TRIMMABLE-BOUNDARY-START(94491147186)
            /*WidgetResponsive<WidgetDimension>*/ Height;
            //--TRIMMABLE-BOUNDARY-END(94491147186)
            
            //--TRIMMABLE-BOUNDARY-START(38656572338)
            /*WidgetImage*/ BackgroundImage;
            //--TRIMMABLE-BOUNDARY-END(38656572338)
            
            //--TRIMMABLE-BOUNDARY-START(42951539634)
            /*bool*/ BackgroundImageRepeat = false;
            //--TRIMMABLE-BOUNDARY-END(42951539634)
            
            //--TRIMMABLE-BOUNDARY-START(47246506930)
            /*BackgroundImageSize*/ BackgroundImageSize = 0;
            //--TRIMMABLE-BOUNDARY-END(47246506930)
            
            //--TRIMMABLE-BOUNDARY-START(34361605042)
            /*Color*/ BackgroundColor;
            //--TRIMMABLE-BOUNDARY-END(34361605042)
            
            //--TRIMMABLE-BOUNDARY-START(25771670450)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(25771670450)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(94491147186)
                this.Height = $.$default($.$bMcF.LFCW.WidgetResponsive$$($.$bMcF.LFCW.WidgetDimension));
                //--TRIMMABLE-BOUNDARY-END(94491147186)
                
                //--TRIMMABLE-BOUNDARY-START(38656572338)
                this.BackgroundImage = $.$rfUg.LCFCF.FluentUIUtility.DefaultImage;
                //--TRIMMABLE-BOUNDARY-END(38656572338)
                
                //--TRIMMABLE-BOUNDARY-START(34361605042)
                this.BackgroundColor = $.$default($.$fPer.LCFCDM.Color);
                //--TRIMMABLE-BOUNDARY-END(34361605042)
                
            }
            static $h = 1866674;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$bMcF.LFCW.ContainerWidget; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94491147186),
    {
      "p": $.$bMcF.LFCW.WidgetResponsive$$($.$bMcF.LFCW.WidgetDimension).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196179890,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440820146,
        "f": 83886081
      },
      "n": "Height",
      "d": 1866674,
      "h": 94491147186,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94491147186),
//--TRIMMABLE-BOUNDARY-START(38656572338),
    {
      "p": 11808496,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426376114,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111671016370,
        "f": 83886081
      },
      "n": "BackgroundImage",
      "d": 1866674,
      "h": 38656572338,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656572338),
//--TRIMMABLE-BOUNDARY-START(42951539634),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016310706,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260950962,
        "f": 83886081
      },
      "n": "BackgroundImageRepeat",
      "d": 1866674,
      "h": 42951539634,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951539634),
//--TRIMMABLE-BOUNDARY-START(47246506930),
    {
      "p": 1735602,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606245298,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850885554,
        "f": 83886081
      },
      "n": "BackgroundImageSize",
      "d": 1866674,
      "h": 47246506930,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246506930),
//--TRIMMABLE-BOUNDARY-START(34361605042),
    {
      "p": 25987414,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836441522,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103081081778,
        "f": 83886081
      },
      "n": "BackgroundColor",
      "d": 1866674,
      "h": 34361605042,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361605042)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771670450),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1866674,
      "h": 25771670450,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771670450),
//--TRIMMABLE-BOUNDARY-START(30066637746),
    {
      "p": [
        {
          "n": "component",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126025729,
              "c": 4420993025
            }
          ]
        },
        {
          "n": "line",
          "p": 655361,
          "f": 65,
          "v": 0,
          "a": [
            {
              "t": 126091265,
              "c": 4421058561
            }
          ]
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1866674,
      "h": 30066637746,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066637746)
  ],
  "h": 1866674,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "//Icon=mdi mdi-wallpaper"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.Banner.BannerWidget`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}Banner${separator}BannerWidget`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1866674)
        
        

        //--TRIMMABLE-BOUNDARY-START(2456498)
        $asm.$cls(`$yyXP.LCFCPWS.SliderWidget`, ($self) => class SliderWidget extends $.$bMcF.LFCW.ContainerWidget
        {
            //--TRIMMABLE-BOUNDARY-START(21477292978)
            /*bool*/ AutoPlay = false;
            //--TRIMMABLE-BOUNDARY-END(21477292978)
            
            //--TRIMMABLE-BOUNDARY-START(25772260274)
            /*bool*/ Button = false;
            //--TRIMMABLE-BOUNDARY-END(25772260274)
            
            //--TRIMMABLE-BOUNDARY-START(30067227570)
            /*bool*/ ButtonOverlay = false;
            //--TRIMMABLE-BOUNDARY-END(30067227570)
            
            //--TRIMMABLE-BOUNDARY-START(103081671602)
            /*IEnumerable<Widget> */ get Slides()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426965938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Children;
            }
            /*IEnumerable<Widget> */ set Slides(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786704306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Children = $.$sl.SL.Enumerable.ToList($.$bMcF.LFCW.Widget, value);
            }
            //--TRIMMABLE-BOUNDARY-END(103081671602)
            
            //--TRIMMABLE-BOUNDARY-START(17182325682)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor\\SliderWidget.cs", 13);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182325682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182325682)
            
            //--TRIMMABLE-BOUNDARY-START(17182325682)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(17182325682)
            
            static $h = 2456498;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$bMcF.LFCW.ContainerWidget; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477292978),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657162162,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016900530,
        "f": 83886081
      },
      "n": "AutoPlay",
      "d": 2456498,
      "h": 21477292978,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477292978),
//--TRIMMABLE-BOUNDARY-START(25772260274),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247096754,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606835122,
        "f": 83886081
      },
      "n": "Button",
      "d": 2456498,
      "h": 25772260274,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772260274),
//--TRIMMABLE-BOUNDARY-START(30067227570),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837031346,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196769714,
        "f": 83886081
      },
      "n": "ButtonOverlay",
      "d": 2456498,
      "h": 30067227570,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067227570),
//--TRIMMABLE-BOUNDARY-START(103081671602),
    {
      "p": $.$$.SCG.IEnumerable$$($.$bMcF.LFCW.Widget).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426965938,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98786704306,
        "f": 83886081
      },
      "n": "Slides",
      "d": 2456498,
      "h": 103081671602,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103081671602)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182325682),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2456498,
      "h": 17182325682,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182325682)
  ],
  "h": 2456498,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "//Icon=mdi mdi-slide"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.Slider.SliderWidget`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}Slider${separator}SliderWidget`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2456498)
        
        

        //--TRIMMABLE-BOUNDARY-START(2063282)
        $asm.$cls(`$yyXP.LCFCPWC.ContactUsWidget<>`, (T) => $asm.$gt(`$yyXP.LCFCPWC.ContactUsWidget<>`, [T], ($self) => class ContactUsWidget$$ extends $.$yyXP.LCFCPWC.ContactUsWidget
        {
            //--TRIMMABLE-BOUNDARY-START(4297030578)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297030578);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.FormType = T.$type;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297030578)
            
            //--TRIMMABLE-BOUNDARY-START(4297030578)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297030578)
            
            static $H = 2063282;
            static $h = 2063282;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yyXP.LCFCPWC.ContactUsWidget; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297030578),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 4297030578,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297030578)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 2063282,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.ContactUs.ContactUsWidget<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}ContactUs${separator}ContactUsWidget$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2063282)
        
        

        //--TRIMMABLE-BOUNDARY-START(2390962)
        $asm.$cls(`$yyXP.LCFCPWM.MetricsCountWidgetView`, ($self) => class MetricsCountWidgetView extends $.$rfUg.LCFCFW.WidgetComponent$$($.$yyXP.LCFCPWM.MetricsCountWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8592325554)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592325554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "col-2 miwx-2 text-center");
                __builder.OpenElement(2, "h2");
                __builder.AddAttribute$5(3, "class", "cl-white mgt-0");
                __builder.OpenComponent$1($.$hDPm.LCFCCC$12.Counter, 4);
                __builder.AddComponentParameter(5, "To", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Double, this.ViewModel.Count), $.$$.S.Double));
                __builder.CloseComponent();
                __builder.AddMarkupContent(6, "+\r\n    ");
                __builder.CloseElement();
                __builder.AddMarkupContent(7, "\r\n    ");
                __builder.OpenElement(8, "h2");
                __builder.AddAttribute$5(9, "class", "cl-white mgb-1");
                __builder.AddContent$4(10, this.ViewModel.Label);
                __builder.CloseElement();
                __builder.AddMarkupContent(11, "\r\n    ");
                __builder.OpenElement(12, "em");
                __builder.AddAttribute$5(13, "class", "op-8");
                __builder.AddContent$4(14, this.ViewModel.Description);
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8592325554)
            
            //--TRIMMABLE-BOUNDARY-START(4297358258)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297358258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297358258)
            
            //--TRIMMABLE-BOUNDARY-START(4297358258)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4297358258)
            
            static $h = 2390962;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFW.WidgetComponent$$($.$yyXP.LCFCPWM.MetricsCountWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592325554),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2390962,
      "h": 8592325554,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592325554)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297358258),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2390962,
      "h": 4297358258,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297358258)
  ],
  "h": 2390962
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.MetricsCount.MetricsCountWidgetView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}MetricsCount${separator}MetricsCountWidgetView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2390962)
        
        

        //--TRIMMABLE-BOUNDARY-START(2259890)
        $asm.$cls(`$yyXP.LCFCPWF.FeatureWidgetView`, ($self) => class FeatureWidgetView extends $.$rfUg.LCFCFW.WidgetComponent$$($.$yyXP.LCFCPWF.FeatureWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8592194482)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592194482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "col-2 miwx-2 text-center");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "di-i-block wx-07 hx-07 flex bd round mgx-a");
                __builder.AddAttribute$5(4, "style", $.$strNN("background-color:" + $.$strNN((this.ViewModel.IconColor).ToString())) + ";");
                __builder.OpenElement(5, "i");
                __builder.AddAttribute$5(6, "class", $.$strNN($.$strNN($.$strNN((this.ViewModel.Icon).ToString()) + " fsz-50") + " text-center") + " mg-a");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(7, "\r\n    ");
                __builder.OpenElement(8, "h4");
                __builder.AddContent$4(9, this.ViewModel.Title);
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\r\n    ");
                __builder.OpenElement(11, "em");
                __builder.AddAttribute$5(12, "class", "fsz-small op-8");
                __builder.AddContent$4(13, this.ViewModel.Description);
                __builder.CloseElement();
                if (this.ViewModel.MoreLink !== null)
                {
                    __builder.OpenElement(14, "a");
                    __builder.AddAttribute$5(15, "class", "cl-primary d-block mgt fw-bold");
                    __builder.AddAttribute$5(16, "href", this.ViewModel.MoreLink);
                    __builder.AddContent$4(17, "Learn more");
                    __builder.CloseElement();
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8592194482)
            
            //--TRIMMABLE-BOUNDARY-START(4297227186)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297227186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297227186)
            
            //--TRIMMABLE-BOUNDARY-START(4297227186)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4297227186)
            
            static $h = 2259890;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFW.WidgetComponent$$($.$yyXP.LCFCPWF.FeatureWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592194482),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2259890,
      "h": 8592194482,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592194482)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297227186),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2259890,
      "h": 4297227186,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297227186)
  ],
  "h": 2259890
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.Feature.FeatureWidgetView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}Feature${separator}FeatureWidgetView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2259890)
        
        

        //--TRIMMABLE-BOUNDARY-START(2128818)
        $asm.$cls(`$yyXP.LCFCPWC.ContactUsWidgetView`, ($self) => class ContactUsWidgetView extends $.$rfUg.LCFCFW.WidgetComponent$$($.$yyXP.LCFCPWC.ContactUsWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8592063410)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592063410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "h1");
                __builder.AddAttribute$5(1, "class", "cl-white text-center");
                __builder.AddContent$4(2, this.ViewModel.Title);
                __builder.CloseElement();
                __builder.AddMarkupContent(3, "\r\n");
                __builder.OpenElement(4, "h3");
                __builder.AddAttribute$5(5, "class", "cl-white text-center");
                __builder.AddContent$4(6, this.ViewModel.SubTitle);
                __builder.CloseElement();
                __builder.AddMarkupContent(7, "\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 8);
                __builder.AddComponentParameter(9, "Class", "mg-a mawx-4 miwx-3");
                __builder.AddComponentParameter(10, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ | 4/*CardFeatures.Shadow*/), $.$hDPm.LCFCCC$1.CardFeatures));
                __builder.AddAttribute$3(11, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.AddContent$1(12, $.$fPer.LCFCT.TypesExtensions.CallGenericMethod$1($.$mac.MAC.RenderFragment, this, "GetForm", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [this.ViewModel.FormType], [-1], null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null)));
                }), $yzpmok ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2128818,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8592063410)
            
            //--TRIMMABLE-BOUNDARY-START(12887030706)
            /*RenderFragment */ GetForm(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887030706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$(T), 13);
                    __builder2.AddAttribute$3(14, "Submit", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 15);
                        __builder3.AddComponentParameter(16, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Secondary));
                        __builder3.AddComponentParameter(17, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 1024/*ButtonFeatures.Large*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder3.AddComponentParameter(18, "Class", "d-block miwx-2 wp-100");
                        __builder3.AddAttribute$3(19, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                        {
                            __builder4.AddContent$4(20, "Sign Up");
                        }), $mcCXea ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":2128818,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                    }), $irXjsa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2128818,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $kNIDKh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2128818,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(12887030706)
            
            //--TRIMMABLE-BOUNDARY-START(4297096114)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297096114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297096114)
            
            //--TRIMMABLE-BOUNDARY-START(4297096114)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4297096114)
            
            static $h = 2128818;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFW.WidgetComponent$$($.$yyXP.LCFCPWC.ContactUsWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592063410),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2128818,
      "h": 8592063410,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592063410),
//--TRIMMABLE-BOUNDARY-START(12887030706),
    {
      "r": 6881395,
      "g": [
        "T"
      ],
      "n": "GetForm",
      "d": 2128818,
      "h": 12887030706,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(12887030706)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297096114),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2128818,
      "h": 4297096114,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297096114)
  ],
  "h": 2128818
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.ContactUs.ContactUsWidgetView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}ContactUs${separator}ContactUsWidgetView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2128818)
        
        

        //--TRIMMABLE-BOUNDARY-START(2653106)
        $asm.$cls(`$yyXP.LCFCPWS$1.SubscribeWidgetView`, ($self) => class SubscribeWidgetView extends $.$rfUg.LCFCFW.WidgetComponent$$($.$yyXP.LCFCPWS$1.SubscribeWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8592587698)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592587698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pd-10 flex");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "mg-a text-center");
                __builder.OpenElement(4, "h2");
                __builder.AddAttribute$5(5, "class", "mgt-0 cl-white");
                __builder.AddContent$4(6, this.ViewModel.Title);
                __builder.CloseElement();
                __builder.AddMarkupContent(7, "\r\n        ");
                __builder.OpenElement(8, "div");
                __builder.AddAttribute$5(9, "class", "row bg-white mawx-5 mg-a");
                __builder.AddMarkupContent(10, "<div class=\"col-10\"><input class=\"wp-100 hf pd bg-transparent bd-none\" placeholder=\"Email\"></div>\r\n            ");
                __builder.OpenElement(11, "div");
                __builder.AddAttribute$5(12, "class", "col-a");
                __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 13);
                __builder.AddComponentParameter(14, "Class", "nowrap");
                __builder.AddComponentParameter(15, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                __builder.AddComponentParameter(16, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ & ~32/*ButtonFeatures.Corner*/ & ~16/*ButtonFeatures.Shadow*/ | 1024/*ButtonFeatures.Large*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                __builder.AddAttribute$3(17, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$4(18, this.ViewModel.ButtonText ?? "Subscribe");
                }), $Jclaoj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2653106,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8592587698)
            
            //--TRIMMABLE-BOUNDARY-START(4297620402)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297620402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297620402)
            
            //--TRIMMABLE-BOUNDARY-START(4297620402)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4297620402)
            
            static $h = 2653106;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFW.WidgetComponent$$($.$yyXP.LCFCPWS$1.SubscribeWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592587698),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2653106,
      "h": 8592587698,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592587698)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297620402),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2653106,
      "h": 4297620402,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297620402)
  ],
  "h": 2653106
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.Subscribe.SubscribeWidgetView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}Subscribe${separator}SubscribeWidgetView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2653106)
        
        

        //--TRIMMABLE-BOUNDARY-START(2522034)
        $asm.$cls(`$yyXP.LCFCPWS.SliderWidgetView`, ($self) => class SliderWidgetView extends $.$rfUg.LCFCFW.WidgetComponent$$($.$yyXP.LCFCPWS.SliderWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8592456626)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592456626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCS$9.Slider, 0);
                __builder.AddComponentParameter(1, "SliderFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$9.SliderFeatures, (this.ViewModel.AutoPlay ? 128/*SliderFeatures.AutoPlay*/ : 0/*SliderFeatures.None*/) | (this.ViewModel.Button ? 32/*SliderFeatures.Button*/ : 0/*SliderFeatures.None*/) | (this.ViewModel.ButtonOverlay ? 64/*SliderFeatures.ButtonOverlay*/ : 0/*SliderFeatures.None*/)), $.$hDPm.LCFCCS$9.SliderFeatures));
                __builder.AddComponentParameter(2, "MultiViewFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$6.MultiViewFeatures, 68/*MultiViewFeatures.Default*/ | 2/*MultiViewFeatures.Transition*/), $.$hDPm.LCFCCM$6.MultiViewFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    let $en1 = this.ViewModel.Slides.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let widget = $en1.SCG$IEnumerator$$$Current;
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCS$9.Slide, 4);
                            __builder2.AddComponentParameter(5, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.S.String.ToString.call(widget.Id)));
                            __builder2.AddComponentParameter(6, "TransitionIn", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 81/*DisplayMode.SlideInLeft*/), $.$hDPm.LCFCI.DisplayMode));
                            __builder2.AddComponentParameter(7, "TransitionOut", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 86/*DisplayMode.SlideOutRight*/), $.$hDPm.LCFCI.DisplayMode));
                            __builder2.AddAttribute$3(8, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.AddContent$1(9, $.$cast(this.Renderer.LFCR$IRootWidgetRenderer$Render(widget, this.DataSource), $.$mac.MAC.RenderFragment));
                                }, $KFUPnd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2522034,"h":0,"f":17825794});
                            }), $sHmMPd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":2522034,"h":0,"f":17825794}));
                            __builder2.SetKey(widget);
                            __builder2.CloseComponent();
                        }
                    }
                }), $FNGLKe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2522034,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8592456626)
            
            //--TRIMMABLE-BOUNDARY-START(4297489330)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297489330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297489330)
            
            //--TRIMMABLE-BOUNDARY-START(4297489330)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4297489330)
            
            static $h = 2522034;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFW.WidgetComponent$$($.$yyXP.LCFCPWS.SliderWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592456626),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2522034,
      "h": 8592456626,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592456626)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297489330),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2522034,
      "h": 4297489330,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297489330)
  ],
  "h": 2522034
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.Slider.SliderWidgetView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}Slider${separator}SliderWidgetView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2522034)
        
        

        //--TRIMMABLE-BOUNDARY-START(1932210)
        $asm.$cls(`$yyXP.LCFCPWB.BannerWidgetView`, ($self) => class BannerWidgetView extends $.$rfUg.LCFCFW.WidgetContainer$$($.$yyXP.LCFCPWB.BannerWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8591866802)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591866802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "mihx-3 clip pos-rel");
                __builder.AddAttribute$5(2, "style", "height:" + $.$strNN((this.ViewModel.Height.Desktop).ToString()));
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "pos-abs t-0 b-0 l-0 r-0 bg-contain");
                __builder.AddAttribute$5(5, "style", $.$strNN($.$strNN($.$strNN($.$strNN("background-image:url('" + $.$strNN((this.ViewModel.BackgroundImage.Url))) + "');background-repeat:") + $.$strNN((this.ViewModel.BackgroundImageRepeat ? "repeat" : "no-repeat"))) + ";background-size:") + $.$strNN(($.$$.S.String.ToLower.call($.$$.S.Enum.ToStringT($.$yyXP.LCFCPWB.BackgroundImageSize, $.$$.S.UInt32, this.ViewModel.BackgroundImageSize)))));
                __builder.CloseElement();
                if ($.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Color, $.$fPer.LCFCDM.ColorUnitTypes, this.ViewModel.BackgroundColor))
                {
                    __builder.OpenElement(6, "div");
                    __builder.AddAttribute$5(7, "class", "pos-abs t-0 b-0 l-0 r-0");
                    __builder.AddAttribute$5(8, "style", "background-color:" + $.$strNN((this.ViewModel.BackgroundColor).ToString()));
                    __builder.CloseElement();
                }
                __builder.OpenElement(9, "div");
                __builder.AddAttribute$5(10, "class", "pos-abs t-0 b-0 l-0 r-0 stack");
                __builder.AddContent$1(11, this.ChildContent);
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8591866802)
            
            //--TRIMMABLE-BOUNDARY-START(4296899506)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296899506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296899506)
            
            //--TRIMMABLE-BOUNDARY-START(4296899506)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296899506)
            
            static $h = 1932210;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFW.WidgetContainer$$($.$yyXP.LCFCPWB.BannerWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591866802),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1932210,
      "h": 8591866802,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591866802)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296899506),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1932210,
      "h": 4296899506,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296899506)
  ],
  "h": 1932210
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.Widgets.Banner.BannerWidgetView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}Widgets${separator}Banner${separator}BannerWidgetView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1932210)
        
        

        //--TRIMMABLE-BOUNDARY-START(1604530)
        $asm.$cls(`$yyXP.LCFCP.UIRootWidgetInput`, ($self) => class UIRootWidgetInput extends $.$hDPm.LCFCI.BaseInputEditor$$($.$bMcF.LFCW.UIRootWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(51541212082)
            /*string */ get OptimizedComponentName()
            {
                return "uirootwidgetinput";
            }
            //--TRIMMABLE-BOUNDARY-END(51541212082)
            
            //--TRIMMABLE-BOUNDARY-START(38656310194)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656310194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Prompt = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientPromptService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(38656310194)
            
            //--TRIMMABLE-BOUNDARY-START(42951277490)
            /*PageBuilderMode*/ mode = 0;
            //--TRIMMABLE-BOUNDARY-END(42951277490)
            
            //--TRIMMABLE-BOUNDARY-START(17181473714)
            /*IWidgetDataSource?*/ dataSource = null;
            //--TRIMMABLE-BOUNDARY-END(17181473714)
            
            //--TRIMMABLE-BOUNDARY-START(55836179378)
            /*IUIClientPromptService*/ Prompt = null;
            //--TRIMMABLE-BOUNDARY-END(55836179378)
            
            //--TRIMMABLE-BOUNDARY-START(47246244786)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246244786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Value ??= new $.$bMcF.LFCW.UIRootWidget().$ctor$7();
                this.dataSource = new ($.$yyXP.LCFCP.PropertyDataBinding$$$($.$$.S.Object, $.$hDPm.LCFCI.ViewConfiguration))().$ctor$1(this.Value, null, new ($.$$.S.Func$$($.$hDPm.LCFCI.PageBuilderMode))().$ctor(this,  () =>
                {
                    return this.mode;
                }, $ZQrNJa ??= {"r":66606762,"n":"","d":1604530,"h":0,"f":17825794}), this.Prompt);
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(47246244786)
            
            //--TRIMMABLE-BOUNDARY-START(68721081266)
            /*void */ ToggleMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721081266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.mode === 0/*PageBuilderMode.Read*/)
                {
                    this.mode = 1/*PageBuilderMode.EditDragDrop*/;
                }
                else 
                {
                    this.mode = 0/*PageBuilderMode.Read*/;
                    this.ValueChanged.InvokeAsync$1(this.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721081266)
            
            //--TRIMMABLE-BOUNDARY-START(12886506418)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886506418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.FluentUI.Core.Widgets.Widget>*/ let __ca1__;
                /*bool*/ let empty = !(((__ca1__ = this.Value.Children) !== null ? $.$sl.SL.Enumerable.Any$1($.$bMcF.LFCW.Widget, __ca1__) : false));
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 1, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, (this.mode === 0/*PageBuilderMode.Read*/ ? new $.$$.S.Action().$ctor(this, this.ToggleMode) : null)));
                __builder.AddAttribute$5(2, "class", `mihx-2 pos-rel bg-tertiary${$.$strNN((empty && this.mode === 0/*PageBuilderMode.Read*/ ? " stack" : ""))}${$.$strNN((this.mode === 0/*PageBuilderMode.Read*/ ? " hf" : " fix z-10"))} animate fadeIn`);
                __builder.AddAttribute$5(3, "style", `${$.$strNN((this.mode === 0/*PageBuilderMode.Read*/ ? "-transform:scale(0.1)" : ""))}`);
                __builder.OpenComponent$1($.$yyXP.LCFCP.PageBuilder, 4);
                __builder.AddComponentParameter(5, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCW.UIRootWidget, this.Value));
                __builder.AddComponentParameter(6, "DataSource", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCD.IWidgetDataSource, this.dataSource));
                __builder.AddComponentParameter(7, "Class", "hf");
                __builder.AddComponentParameter(8, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$yyXP.LCFCP.PageBuilderFeatures, 60/*PageBuilderFeatures.Default*/ | 2/*PageBuilderFeatures.TopToolBar*/), $.$yyXP.LCFCP.PageBuilderFeatures));
                __builder.AddComponentParameter(9, "Mode", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.PageBuilderMode, this.mode), $.$hDPm.LCFCI.PageBuilderMode));
                __builder.AddComponentParameter(10, "ModeChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$hDPm.LCFCI.PageBuilderMode), $.$mac.MAC.EventCallback.Factory.Create$6($.$hDPm.LCFCI.PageBuilderMode, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$hDPm.LCFCI.PageBuilderMode, this, new ($.$$.S.Action$$($.$hDPm.LCFCI.PageBuilderMode))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.mode = __value;
                }, $cILpvi ??= {"r":65537,"p":[{"n":"__value","p":66606762}],"n":"","d":1604530,"h":0,"f":17825794}), this.mode))));
                __builder.CloseComponent();
                if (empty && this.mode === 0/*PageBuilderMode.Read*/)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 11);
                    __builder.AddComponentParameter(12, "Class", "mg-a clickable");
                    __builder.AddComponentParameter(13, "Message", "No UI here yet. Click here to start building.");
                    __builder.CloseComponent();
                }
                if (this.mode !== 0/*PageBuilderMode.Read*/)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 14);
                    __builder.AddComponentParameter(15, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder.AddComponentParameter(16, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 1024/*ButtonFeatures.Large*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder.AddComponentParameter(17, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `pos-abs r-0 b-0 mg mdi ${$.$strNN((this.mode === 0/*PageBuilderMode.Read*/ ? "mdi-pencil" : "mdi-content-save"))}`));
                    __builder.AddComponentParameter(18, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToggleMode))));
                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder, 19, "onclick", true);
                    __builder.CloseComponent();
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12886506418)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591539122)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591539122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591539122)
            
            //--TRIMMABLE-BOUNDARY-START(8591539122)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8591539122)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55836179378)
                this.Prompt = null;
                //--TRIMMABLE-BOUNDARY-END(55836179378)
                
            }
            static $h = 1604530;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCI.BaseInputEditor$$($.$bMcF.LFCW.UIRootWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51541212082),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771408306,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1604530,
      "h": 51541212082,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51541212082),
//--TRIMMABLE-BOUNDARY-START(55836179378),
    {
      "p": 65427114,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361342898,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426113970,
        "f": 83886081
      },
      "n": "Prompt",
      "d": 1604530,
      "h": 55836179378,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836179378)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38656310194),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1604530,
      "h": 38656310194,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656310194),
//--TRIMMABLE-BOUNDARY-START(47246244786),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1604530,
      "h": 47246244786,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47246244786),
//--TRIMMABLE-BOUNDARY-START(68721081266),
    {
      "r": 65537,
      "n": "ToggleMode",
      "d": 1604530,
      "h": 68721081266,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68721081266),
//--TRIMMABLE-BOUNDARY-START(12886506418),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1604530,
      "h": 12886506418,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886506418)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42951277490),
    {
      "t": 66606762,
      "n": "mode",
      "d": 1604530,
      "h": 42951277490,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42951277490),
//--TRIMMABLE-BOUNDARY-START(17181473714),
    {
      "t": 1453808,
      "n": "dataSource",
      "d": 1604530,
      "h": 17181473714,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181473714)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591539122),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1604530,
      "h": 8591539122,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591539122)
  ],
  "h": 1604530
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$$.S.IDisposable, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.UIRootWidget)), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$bMcF.LFCW.UIRootWidget), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.UIRootWidget)), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$fPer.LCFC.ISelectOption$$($.$bMcF.LFCW.UIRootWidget)), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$bMcF.LFCW.UIRootWidget), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$bMcF.LFCW.UIRootWidget), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.UIRootWidgetInput`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}UIRootWidgetInput`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1604530)
        
        

        //--TRIMMABLE-BOUNDARY-START(1342386)
        $asm.$cls(`$yyXP.LCFCP.PropertySelector<>`, (T) => $asm.$gt(`$yyXP.LCFCP.PropertySelector<>`, [T], ($self) => class PropertySelector$$ extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(107375524786)
            /*string */ get OptimizedComponentName()
            {
                return "propertyselector";
            }
            //--TRIMMABLE-BOUNDARY-END(107375524786)
            
            //--TRIMMABLE-BOUNDARY-START(150325197746)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325197746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Label":
                    this.Label = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Data":
                    this.Data = $.$cast(parameter.Value, T);
                    return true;
                    case "Filter":
                    this.Filter = $.$cast(parameter.Value, $.$fPer.LCFCD$1.PropertyDescriptorFilter);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(150325197746)
            
            //--TRIMMABLE-BOUNDARY-START(98785590194)
            /*string*/ Label = null;
            //--TRIMMABLE-BOUNDARY-END(98785590194)
            
            //--TRIMMABLE-BOUNDARY-START(34361080754)
            /*T*/ Data = $.$default(T);
            //--TRIMMABLE-BOUNDARY-END(34361080754)
            
            //--TRIMMABLE-BOUNDARY-START(42951015346)
            /*PropertyDescriptorFilter*/ Filter = null;
            //--TRIMMABLE-BOUNDARY-END(42951015346)
            
            //--TRIMMABLE-BOUNDARY-START(38656048050)
            /*string*/ expression = null;
            //--TRIMMABLE-BOUNDARY-END(38656048050)
            
            //--TRIMMABLE-BOUNDARY-START(111670492082)
            /*IEnumerable<IObservableDataDescriptor>*/ selected = null;
            //--TRIMMABLE-BOUNDARY-END(111670492082)
            
            //--TRIMMABLE-BOUNDARY-START(94490622898)
            /*IHostView*/ Host = null;
            //--TRIMMABLE-BOUNDARY-END(94490622898)
            
            //--TRIMMABLE-BOUNDARY-START(90195655602)
            /*Task<string> */ GetResult()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195655602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let path = "";
                if (this.selected !== null)
                {
                    path = "_." + $.$strNN($.$$.S.String.Replace$3.call($.$$.S.String.Join$5(".", $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCD$1.IObservableDataDescriptor, $.$$.S.String, this.selected, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IObservableDataDescriptor, $.$$.S.String))().$ctor(this,  (/**/ s) =>
                    {
                        return s.LCFCD$1$IObservableDataDescriptor$Name;
                    }, $SZSGkl ??= {"r":1310721,"p":[{"n":"s","p":40536406}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}))), ".[", "["));
                }
                if (this.expression !== null)
                {
                    path = $.$$.S.String.Replace$3.call(this.expression, "#", path);
                }
                return $.$$.STT.Task.FromResult($.$$.S.String, path);
            }
            //--TRIMMABLE-BOUNDARY-END(90195655602)
            
            //--TRIMMABLE-BOUNDARY-START(30066113458)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066113458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCS$7.SideBar, 0);
                __builder.AddComponentParameter(1, "Class", "pd hf");
                __builder.AddComponentParameter(2, "Side", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarSide, 4/*SideBarSide.Bottom*/), $.$hDPm.LCFCCS$7.SideBarSide));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(4, "h3");
                    __builder2.AddContent$4(5, this.Label);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(6, "\r\n        ");
                    $.$yyXP._LCFCPP$1.TypeInference.CreatePropertySheet_0(T, __builder2, 7, 8, this.Data, 9, 35184372092928n | 65536n | 8388608n, 10, "Filter", 11, $.$clone(this.Theme), 12, "pdy-2", 13, this.selected, 14, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor), this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor), this, new ($.$$.S.Action$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor)))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.selected = __value;
                    }, $LxGhRj ??= {"r":65537,"p":[{"n":"__value","p":$.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), this.selected)));
                }), $lPmXnd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.AddAttribute$3(15, "Bar", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$macw.MACF.EditForm, 16);
                    __builder2.AddComponentParameter(17, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, $.$yyXP.LCFCP.PropertySelector$$(T).model));
                    __builder2.AddAttribute$3(18, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$($.$$.S.String), 19);
                            __builder3.AddComponentParameter(20, "PlaceHolder", "Converter(use # for property placeholder)");
                            __builder3.AddComponentParameter(21, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.expression));
                            __builder3.AddComponentParameter(22, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/**/ __value) =>
                            {
                                return this.expression = __value;
                            }, $JVrFFk ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), this.expression))));
                            __builder3.AddComponentParameter(23, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                            {
                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "expression"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                            }, $fhMyji ??= {"r":38797349,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).Invoke())));
                            __builder3.CloseComponent();
                        }, $dcAGJa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $NTWyLe ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $pAWrzk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(30066113458)
            
            //--TRIMMABLE-BOUNDARY-START(103080557490)
            /*object*/ static model = null;
            //--TRIMMABLE-BOUNDARY-END(103080557490)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12888661416)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IPushResultComponent<string>.Host.set
            set LCFCC$IPushResultComponent$$$Host(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298726824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Host = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12888661416)
            
            //--TRIMMABLE-BOUNDARY-START(25771146162)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771146162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771146162)
            
            //--TRIMMABLE-BOUNDARY-START(25771146162)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25771146162)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42951015346)
                this.Filter = new $.$fPer.LCFCD$1.PropertyDescriptorFilter().$ctor(this,  (/*s*/ s, /*b*/ b) =>
                {
                    return true;
                }, $QeIIsj ??= {"r":262145,"p":[{"n":"s","p":2394454},{"n":"b","p":40733014}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                //--TRIMMABLE-BOUNDARY-END(42951015346)
                
            }
            //--TRIMMABLE-BOUNDARY-START(21476178866)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476178866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(103080557490)
                    this.model = {  };
                    //--TRIMMABLE-BOUNDARY-END(103080557490)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476178866)
            
            static $H = 1342386;
            static $h = 1342386;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107375524786),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85900688306,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 107375524786,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107375524786),
//--TRIMMABLE-BOUNDARY-START(98785590194),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77310753714,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 146030230450,
        "h": Number(BigInt(this.$h)|0x2200000000n),
        "f": 83886081
      },
      "n": "Label",
      "d": this.$h,
      "H": 98785590194,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98785590194),
//--TRIMMABLE-BOUNDARY-START(34361080754),
    {
      "p": T?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51540949938,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 120260426674,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 83886081
      },
      "n": "Data",
      "d": this.$h,
      "H": 34361080754,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361080754),
//--TRIMMABLE-BOUNDARY-START(42951015346),
    {
      "p": 42305878,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60130884530,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 128850361266,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 83886081
      },
      "n": "Filter",
      "d": this.$h,
      "H": 42951015346,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42951015346),
//--TRIMMABLE-BOUNDARY-START(94490622898),
    {
      "p": 3300776,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68720819122,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 137440295858,
        "h": Number(BigInt(this.$h)|0x2000000000n),
        "f": 83886081
      },
      "n": "Host",
      "d": this.$h,
      "H": 94490622898,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490622898)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(150325197746),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 150325197746,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150325197746),
//--TRIMMABLE-BOUNDARY-START(90195655602),
    {
      "r": $.$$.STT.Task$$($.$$.S.String).$h,
      "n": "GetResult",
      "d": this.$h,
      "H": 90195655602,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195655602),
//--TRIMMABLE-BOUNDARY-START(30066113458),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 30066113458,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30066113458)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656048050),
    {
      "t": 1310721,
      "n": "expression",
      "d": this.$h,
      "H": 38656048050,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656048050),
//--TRIMMABLE-BOUNDARY-START(111670492082),
    {
      "t": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor).$h,
      "n": "selected",
      "d": this.$h,
      "H": 111670492082,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(111670492082),
//--TRIMMABLE-BOUNDARY-START(103080557490),
    {
      "t": 131073,
      "n": "model",
      "d": this.$h,
      "H": 103080557490,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(103080557490)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771146162),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 25771146162,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771146162)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 1342386,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.IPushResultComponent$$($.$$.S.String), $.$vWqU.LCFCC.IResultComponent$$($.$$.S.String), $.$vWqU.LCFCC.IResultComponent, $.$vWqU.LCFCC.IHostedView, $.$vWqU.LCFCC.IViewBase ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.PropertySelector<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}PropertySelector$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1342386)
        
        

        //--TRIMMABLE-BOUNDARY-START(1473458)
        $asm.$cls(`$yyXP.LCFCP.TemplateMarket`, ($self) => class TemplateMarket extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(60131015602)
            /*string */ get OptimizedComponentName()
            {
                return "templatemarket";
            }
            //--TRIMMABLE-BOUNDARY-END(60131015602)
            
            //--TRIMMABLE-BOUNDARY-START(51541081010)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541081010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Prompt = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientPromptService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(51541081010)
            
            //--TRIMMABLE-BOUNDARY-START(64425982898)
            /*IUIClientPromptService*/ Prompt = null;
            //--TRIMMABLE-BOUNDARY-END(64425982898)
            
            //--TRIMMABLE-BOUNDARY-START(68720950194)
            /*UIRootWidget*/ selected = null;
            //--TRIMMABLE-BOUNDARY-END(68720950194)
            
            //--TRIMMABLE-BOUNDARY-START(47246113714)
            /*IHostView*/ Host = null;
            //--TRIMMABLE-BOUNDARY-END(47246113714)
            
            //--TRIMMABLE-BOUNDARY-START(55836048306)
            /*ValueTask<bool> */ OnSelected(/*DataListSelection<FluentUITemplateModel>*/ selection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836048306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$yyXP.LCFCP.TemplatePreview, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data.Name, false), null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*builder*/ builder, /*i*/ i) =>
                {
                    builder.AddAttribute$4(i++, "UI", selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data);
                }, $jMGtRh ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"i","p":655361}],"n":"","d":1473458,"h":0,"f":17825794}), null, null);
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(55836048306)
            
            //--TRIMMABLE-BOUNDARY-START(17181342642)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181342642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$Iaui.LCFCM.FluentUITemplateModel), 0);
                __builder.AddComponentParameter(1, "ItemsPerRow", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), -1), $.$$.S.Int32));
                __builder.AddComponentParameter(2, "li-class", "mawx-25");
                __builder.AddComponentParameter(3, "PadContent", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 2), $.$$.S.Int32));
                __builder.AddComponentParameter(4, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                __builder.AddComponentParameter(5, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(6, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                __builder.AddAttribute$3(7, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.FluentUITemplateModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.FluentUITemplateModel))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 8);
                        __builder2.AddComponentParameter(9, "Class", "stack");
                        __builder2.AddComponentParameter(10, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, (21/*CardFeatures.Default*/ & ~4/*CardFeatures.Shadow*/) | 2/*CardFeatures.Corner*/), $.$hDPm.LCFCCC$1.CardFeatures));
                        __builder2.AddAttribute$3(11, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(12, "div");
                            __builder3.AddAttribute$5(13, "class", "hx-2");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 14);
                            __builder3.AddComponentParameter(15, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, context.Model.Icon));
                            __builder3.AddComponentParameter(16, "Class", "mg-a d-block mawp-10 mahp-10");
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(17, "\r\n            ");
                            __builder3.OpenElement(18, "h3");
                            __builder3.AddAttribute$5(19, "class", "nowrap");
                            __builder3.AddContent$4(20, context.Model.Name);
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(21, "\r\n            ");
                            __builder3.OpenElement(22, "span");
                            __builder3.AddAttribute$5(23, "class", "nowrap");
                            __builder3.AddContent$4(24, context.Model.Description$1);
                            __builder3.CloseElement();
                        }), $aNsdRc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1473458,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $UxFGmb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1473458,"h":0,"f":17825794});
                }), $IacnEe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.FluentUITemplateModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.FluentUITemplateModel)).$h}],"n":"","d":1473458,"h":0,"f":17825794}));
                __builder.AddAttribute$3(25, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 26);
                    __builder2.AddComponentParameter(27, "Message", "Nothing here. Be the first to publish a template");
                    __builder2.CloseComponent();
                }), $KpwMmc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1473458,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17181342642)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Frameworks.Common.Models.FluentUITemplateModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Frameworks.Common.Models.FluentUITemplateModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Frameworks$Common$Models$FluentUITemplateModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(12888661416)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IPushResultComponent<LivingThing.FluentUI.Core.Widgets.UIRootWidget>.Host.set
            set LCFCC$IPushResultComponent$$$Host(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298726824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Host = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12888661416)
            
            //--TRIMMABLE-BOUNDARY-START(12886375346)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886375346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886375346)
            
            //--TRIMMABLE-BOUNDARY-START(12886375346)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12886375346)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64425982898)
                this.Prompt = null;
                //--TRIMMABLE-BOUNDARY-END(64425982898)
                
            }
            static $h = 1473458;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60131015602),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361211826,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1473458,
      "h": 60131015602,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60131015602),
//--TRIMMABLE-BOUNDARY-START(64425982898),
    {
      "p": 65427114,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951146418,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900819378,
        "f": 83886081
      },
      "n": "Prompt",
      "d": 1473458,
      "h": 64425982898,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425982898),
//--TRIMMABLE-BOUNDARY-START(47246113714),
    {
      "p": 3300776,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771277234,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310884786,
        "f": 83886081
      },
      "n": "Host",
      "d": 1473458,
      "h": 47246113714,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246113714)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51541081010),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1473458,
      "h": 51541081010,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541081010),
//--TRIMMABLE-BOUNDARY-START(55836048306),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$Iaui.LCFCM.FluentUITemplateModel).$h
        }
      ],
      "n": "OnSelected",
      "d": 1473458,
      "h": 55836048306,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836048306),
//--TRIMMABLE-BOUNDARY-START(17181342642),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1473458,
      "h": 17181342642,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17181342642)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(68720950194),
    {
      "t": 9514736,
      "n": "selected",
      "d": 1473458,
      "h": 68720950194,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68720950194)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886375346),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1473458,
      "h": 12886375346,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886375346)
  ],
  "h": 1473458
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$Iaui.LCFCM.FluentUITemplateModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$Iaui.LCFCM.FluentUITemplateModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$vWqU.LCFCC.IPushResultComponent$$($.$bMcF.LFCW.UIRootWidget), $.$vWqU.LCFCC.IResultComponent$$($.$bMcF.LFCW.UIRootWidget), $.$vWqU.LCFCC.IResultComponent, $.$vWqU.LCFCC.IHostedView, $.$vWqU.LCFCC.IViewBase ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.PageBuilder.TemplateMarket`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}PageBuilder${separator}TemplateMarket`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1473458)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(31666)
