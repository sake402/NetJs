﻿
declare var Define: any;
class PageBuilder {
    init(page:any): void {
        var observer = new MutationObserver((mutations) => {
            mutations.forEach(mutation => {
                mutation.addedNodes.forEach(node => {
                    if (node instanceof HTMLElement && (<HTMLElement>node).attributes.getNamedItem("contenteditable")?.value) {
                        node.addEventListener("blur", function () {
                            page.invokeMethodAsync("SetLabelText", node.id, node.textContent);
                        });
                    }
                })
            })
        });
        observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
    }
}

Define("pageBuilder", new PageBuilder());
