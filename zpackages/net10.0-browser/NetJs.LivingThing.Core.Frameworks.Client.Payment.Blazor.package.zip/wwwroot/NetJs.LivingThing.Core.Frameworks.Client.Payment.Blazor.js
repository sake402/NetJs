
//--TRIMMABLE-BOUNDARY-START(59056)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $nYKj) {
    "use strict";
    let _;
    let $FXDpse;
    let $wxmmJb;
    let $VwbJEa;
    let $ryFPPc;
    let $qvdSnj;
    let $rXJTRb;
    let $RCmOdc;
    let $sgjbie;
    let $SisUCe;
    let $HKHHva;
    let $wAlhuk;
    let $DBQvSk;
    let $TmZuob;
    let $YBtaMe;
    let $dnnzXd;
    let $FnUwlc;
    let $zTeAfb;
    let $wBWqbb;
    let $YDHJek;
    let $camnHg;
    let $qKtJhb;
    let $zpKlZg;
    let $kZKWPi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", 
    {
  "h": 59056,
  "f": "LivingThing.Core.Frameworks.Client.Payment.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.Payment.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.Payment.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(583344)
        $asm.$cls(`$wtdm.LCFCPP.PayStackConfiguration`, ($self) => class PayStackConfiguration extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885485232)
            /*string*/ APIKey = null;
            //--TRIMMABLE-BOUNDARY-END(12885485232)
            
            //--TRIMMABLE-BOUNDARY-START(8590517936)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590517936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590517936)
            
            //--TRIMMABLE-BOUNDARY-START(8590517936)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590517936)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885485232)
                this.APIKey = null;
                //--TRIMMABLE-BOUNDARY-END(12885485232)
                
            }
            static $h = 583344;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885485232),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475419824,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065354416,
        "f": 83886081
      },
      "n": "APIKey",
      "d": 583344,
      "h": 12885485232,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885485232)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590517936),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 583344,
      "h": 8590517936,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590517936)
  ],
  "h": 583344
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.PayStack.PayStackConfiguration`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}PayStack${separator}PayStackConfiguration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(583344)
        
        

        //--TRIMMABLE-BOUNDARY-START(1042096)
        $asm.$cls(`$wtdm.LCFCPP.PayStackPaymentResult`, ($self) => class PayStackPaymentResult extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(90195355312)
            /*string*/ Reference = null;
            //--TRIMMABLE-BOUNDARY-END(90195355312)
            
            //--TRIMMABLE-BOUNDARY-START(150324897456)
            /*string*/ Trans = null;
            //--TRIMMABLE-BOUNDARY-END(150324897456)
            
            //--TRIMMABLE-BOUNDARY-START(146029930160)
            /*string*/ Status = null;
            //--TRIMMABLE-BOUNDARY-END(146029930160)
            
            //--TRIMMABLE-BOUNDARY-START(85900388016)
            /*string*/ Message = null;
            //--TRIMMABLE-BOUNDARY-END(85900388016)
            
            //--TRIMMABLE-BOUNDARY-START(154619864752)
            /*string*/ Transaction = null;
            //--TRIMMABLE-BOUNDARY-END(154619864752)
            
            //--TRIMMABLE-BOUNDARY-START(158914832048)
            /*string*/ Trxref = null;
            //--TRIMMABLE-BOUNDARY-END(158914832048)
            
            //--TRIMMABLE-BOUNDARY-START(30065813168)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065813168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065813168)
            
            //--TRIMMABLE-BOUNDARY-START(30065813168)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30065813168)
            
            static $h = 1042096;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90195355312),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245682352,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375224496,
        "f": 83886081
      },
      "n": "Reference",
      "d": 1042096,
      "h": 90195355312,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195355312),
//--TRIMMABLE-BOUNDARY-START(150324897456),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425551536,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555093680,
        "f": 83886081
      },
      "n": "Trans",
      "d": 1042096,
      "h": 150324897456,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150324897456),
//--TRIMMABLE-BOUNDARY-START(146029930160),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835616944,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965159088,
        "f": 83886081
      },
      "n": "Status",
      "d": 1042096,
      "h": 146029930160,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146029930160),
//--TRIMMABLE-BOUNDARY-START(85900388016),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655747760,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785289904,
        "f": 83886081
      },
      "n": "Message",
      "d": 1042096,
      "h": 85900388016,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900388016),
//--TRIMMABLE-BOUNDARY-START(154619864752),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015486128,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145028272,
        "f": 83886081
      },
      "n": "Transaction",
      "d": 1042096,
      "h": 154619864752,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619864752),
//--TRIMMABLE-BOUNDARY-START(158914832048),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605420720,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734962864,
        "f": 83886081
      },
      "n": "Trxref",
      "d": 1042096,
      "h": 158914832048,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914832048)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065813168),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1042096,
      "h": 30065813168,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065813168)
  ],
  "h": 1042096
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.PayStack.PayStackPaymentResult`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}PayStack${separator}PayStackPaymentResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1042096)
        
        

        //--TRIMMABLE-BOUNDARY-START(1107632)
        $asm.$cls(`$wtdm.LCFCPP.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4296074928)
            static /*void */ AddPayStack(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296074928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$hDPm.LCFCI.IUIPaymentProcessor, $.$wtdm.LCFCPP.PayStackPaymentProcessor, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4296074928)
            
            static $h = 1107632;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296074928),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddPayStack",
      "d": 1107632,
      "h": 4296074928,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296074928)
  ],
  "h": 1107632
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.PayStack.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}PayStack${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1107632)
        
        

        //--TRIMMABLE-BOUNDARY-START(1238704)
        $asm.$cls(`$wtdm.LCFCPR.RemitaPaymentOptions`, ($self) => class RemitaPaymentOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115965355696)
            /*string*/ Key = null;
            //--TRIMMABLE-BOUNDARY-END(115965355696)
            
            //--TRIMMABLE-BOUNDARY-START(42950911664)
            /*string*/ CustomerId = null;
            //--TRIMMABLE-BOUNDARY-END(42950911664)
            
            //--TRIMMABLE-BOUNDARY-START(51540846256)
            /*string*/ FirstName = null;
            //--TRIMMABLE-BOUNDARY-END(51540846256)
            
            //--TRIMMABLE-BOUNDARY-START(120260322992)
            /*string*/ LastName = null;
            //--TRIMMABLE-BOUNDARY-END(120260322992)
            
            //--TRIMMABLE-BOUNDARY-START(47245878960)
            /*string*/ Email = null;
            //--TRIMMABLE-BOUNDARY-END(47245878960)
            
            //--TRIMMABLE-BOUNDARY-START(124555290288)
            /*string*/ Narration = null;
            //--TRIMMABLE-BOUNDARY-END(124555290288)
            
            //--TRIMMABLE-BOUNDARY-START(38655944368)
            /*double*/ Amount = 0;
            //--TRIMMABLE-BOUNDARY-END(38655944368)
            
            //--TRIMMABLE-BOUNDARY-START(34360977072)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360977072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360977072)
            
            //--TRIMMABLE-BOUNDARY-START(34360977072)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(34360977072)
            
            static $h = 1238704;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115965355696),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490519216,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504963248,
        "f": 83886081
      },
      "n": "Key",
      "d": 1238704,
      "h": 115965355696,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965355696),
//--TRIMMABLE-BOUNDARY-START(42950911664),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720715440,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735159472,
        "f": 83886081
      },
      "n": "CustomerId",
      "d": 1238704,
      "h": 42950911664,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950911664),
//--TRIMMABLE-BOUNDARY-START(51540846256),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900584624,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915028656,
        "f": 83886081
      },
      "n": "FirstName",
      "d": 1238704,
      "h": 51540846256,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540846256),
//--TRIMMABLE-BOUNDARY-START(120260322992),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080453808,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094897840,
        "f": 83886081
      },
      "n": "LastName",
      "d": 1238704,
      "h": 120260322992,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260322992),
//--TRIMMABLE-BOUNDARY-START(47245878960),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310650032,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325094064,
        "f": 83886081
      },
      "n": "Email",
      "d": 1238704,
      "h": 47245878960,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245878960),
//--TRIMMABLE-BOUNDARY-START(124555290288),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670388400,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184684832432,
        "f": 83886081
      },
      "n": "Narration",
      "d": 1238704,
      "h": 124555290288,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124555290288),
//--TRIMMABLE-BOUNDARY-START(38655944368),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130780848,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145224880,
        "f": 83886081
      },
      "n": "Amount",
      "d": 1238704,
      "h": 38655944368,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655944368)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360977072),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1238704,
      "h": 34360977072,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360977072)
  ],
  "h": 1238704
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.Remita.RemitaPaymentOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}Remita${separator}RemitaPaymentOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1238704)
        
        

        //--TRIMMABLE-BOUNDARY-START(321200)
        $asm.$cls(`$wtdm.LCFCP._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295288496)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295288496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$wtdm.LCFCP.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295288496)
            
            static $h = 321200;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295288496),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 321200,
      "h": 4295288496,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295288496)
  ],
  "h": 321200
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(321200)
        
        

        //--TRIMMABLE-BOUNDARY-START(386736)
        $asm.$cls(`$wtdm.LCFCP.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295354032)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295354032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$wtdm.LCFCPP.PayStackPaymentFeatures.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$wtdm.LCFCPP.PayStackPaymentFeaturesCustomAttributesProvider, $.$wtdm.LCFCPP.PayStackPaymentFeaturesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295354032)
            
            static $h = 386736;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295354032),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 386736,
      "h": 4295354032,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295354032)
  ],
  "h": 386736
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(386736)
        
        

        //--TRIMMABLE-BOUNDARY-START(452272)
        $asm.$cls(`$wtdm.LCFCP.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295419568)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295419568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295419568)
            
            static $h = 452272;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295419568),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 452272,
      "h": 4295419568,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295419568)
  ],
  "h": 452272
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(452272)
        
        

        //--TRIMMABLE-BOUNDARY-START(648880)
        $asm.$cls(`$wtdm.LCFCPP.PayStackMetadata`, ($self) => class PayStackMetadata extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295616176)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295616176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295616176)
            
            //--TRIMMABLE-BOUNDARY-START(4295616176)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295616176)
            
            static $h = 648880;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295616176),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 648880,
      "h": 4295616176,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295616176)
  ],
  "h": 648880
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.PayStack.PayStackMetadata`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}PayStack${separator}PayStackMetadata`; }
        });
        //--TRIMMABLE-BOUNDARY-END(648880)
        
        

        //--TRIMMABLE-BOUNDARY-START(779952)
        $asm.$cls(`$wtdm.LCFCPP.PayStackPaymentAPIOptions`, ($self) => class PayStackPaymentAPIOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(98785027760)
            /*string*/ Key = null;
            //--TRIMMABLE-BOUNDARY-END(98785027760)
            
            //--TRIMMABLE-BOUNDARY-START(42950452912)
            /*string*/ Email = null;
            //--TRIMMABLE-BOUNDARY-END(42950452912)
            
            //--TRIMMABLE-BOUNDARY-START(34360518320)
            /*int*/ Amount = 0;
            //--TRIMMABLE-BOUNDARY-END(34360518320)
            
            //--TRIMMABLE-BOUNDARY-START(38655485616)
            /*string*/ Currency = null;
            //--TRIMMABLE-BOUNDARY-END(38655485616)
            
            //--TRIMMABLE-BOUNDARY-START(158914569904)
            /*string?*/ SubAccount = null;
            //--TRIMMABLE-BOUNDARY-END(158914569904)
            
            //--TRIMMABLE-BOUNDARY-START(103079995056)
            /*string*/ Ref = null;
            //--TRIMMABLE-BOUNDARY-END(103079995056)
            
            //--TRIMMABLE-BOUNDARY-START(30065551024)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065551024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065551024)
            
            //--TRIMMABLE-BOUNDARY-START(30065551024)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30065551024)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38655485616)
                this.Currency = "NGN";
                //--TRIMMABLE-BOUNDARY-END(38655485616)
                
            }
            static $h = 779952;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98785027760),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310191280,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439733424,
        "f": 83886081
      },
      "n": "Key",
      "d": 779952,
      "h": 98785027760,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785027760),
//--TRIMMABLE-BOUNDARY-START(42950452912),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720256688,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849798832,
        "f": 83886081
      },
      "n": "Email",
      "d": 779952,
      "h": 42950452912,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950452912),
//--TRIMMABLE-BOUNDARY-START(34360518320),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540387504,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669929648,
        "f": 83886081
      },
      "n": "Amount",
      "d": 779952,
      "h": 34360518320,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360518320),
//--TRIMMABLE-BOUNDARY-START(38655485616),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130322096,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259864240,
        "f": 83886081
      },
      "n": "Currency",
      "d": 779952,
      "h": 38655485616,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655485616),
//--TRIMMABLE-BOUNDARY-START(158914569904),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490060464,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619602608,
        "f": 83886081
      },
      "n": "SubAccount",
      "d": 779952,
      "h": 158914569904,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "subaccount",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914569904),
//--TRIMMABLE-BOUNDARY-START(103079995056),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900125872,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029668016,
        "f": 83886081
      },
      "n": "Ref",
      "d": 779952,
      "h": 103079995056,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079995056)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065551024),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 779952,
      "h": 30065551024,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065551024)
  ],
  "h": 779952
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.PayStack.PayStackPaymentAPIOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}PayStack${separator}PayStackPaymentAPIOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(779952)
        
        

        //--TRIMMABLE-BOUNDARY-START(911024)
        $asm.$cls(`$wtdm.LCFCPP.PayStackPaymentFeaturesCustomAttributesProvider`, ($self) => class PayStackPaymentFeaturesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295878320)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295878320)
            
            //--TRIMMABLE-BOUNDARY-START(8590845616)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590845616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$wtdm.LCFCPP.PayStackPaymentFeaturesCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$wtdm.LCFCPP.PayStackPaymentFeaturesCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $wAlhuk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":911024,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $DBQvSk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":911024,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590845616)
            
            static $h = 911024;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590845616),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 911024,
      "h": 8590845616,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590845616)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295878320),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 911024,
      "h": 4295878320,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295878320)
  ],
  "h": 911024
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.PayStack.PayStackPaymentFeaturesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}PayStack${separator}PayStackPaymentFeaturesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(911024)
        
        

        //--TRIMMABLE-BOUNDARY-START(190128)
        $asm.$cls(`$wtdm._LCFCPSP.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295157424)
            static /*void */ CreatePropertySheet_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*T*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg2, /*int*/ __seq3, /*global::System.Object*/ __arg3, /*int*/ __seq4, /*global::System.Object*/ __arg4, /*int*/ __seq5, /*global::System.Object*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295157424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Target", $.$box(__arg0, T));
                __builder.AddComponentParameter(__seq1, "Class", __arg1);
                __builder.AddComponentParameter(__seq2, "Features", $.$box(__arg2, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq3, "PropertyFilter", __arg3);
                __builder.AddComponentParameter(__seq4, "li-class", __arg4);
                __builder.AddComponentParameter(__seq5, "value-class", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295157424)
            
            static $h = 190128;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295157424),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => T.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 14505642
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 131073
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": 131073
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreatePropertySheet_0",
      "d": 190128,
      "h": 4295157424,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295157424)
  ],
  "h": 190128
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Frameworks.Client.Payment.Shared.PaymentDetails.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}Shared${separator}PaymentDetails${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(190128)
        
        

        //--TRIMMABLE-BOUNDARY-START(124592)
        $asm.$cls(`$wtdm._LCFCPSB.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(8590059184)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590059184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590059184)
            
            //--TRIMMABLE-BOUNDARY-START(4295091888)
            static /*void */ CreateDataList_1(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.Client.IViewController*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295091888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "Controller", __arg1);
                __builder.AddComponentParameter(__seq2, "Features", $.$box(__arg2, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq3, "ChildContent", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295091888)
            
            static $h = 124592;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590059184),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 124592,
      "h": 8590059184,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590059184),
//--TRIMMABLE-BOUNDARY-START(4295091888),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 5856680
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 14505642
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_1",
      "d": 124592,
      "h": 4295091888,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295091888)
  ],
  "h": 124592
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Frameworks.Client.Payment.Shared.BankAccountInputEditor.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}Shared${separator}BankAccountInputEditor${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(124592)
        
        

        //--TRIMMABLE-BOUNDARY-START(1304240)
        $asm.$cls(`$wtdm.LCFCP.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591238832)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591238832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wtdm.LCFCP.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$hDPm.LCFCI.InputEditorProviderExtension.AddInputEditor$1($.$Iaui.LCFCM.PaymentModel, $.$wtdm.LCFCPS.PaymentInput, services);
                $.$hDPm.LCFCI.InputEditorProviderExtension.AddInputEditor$1($.$fPer.LCFCD.BankAccount, $.$wtdm.LCFCPS.BankAccountInputEditor, services);
                $.$wtdm.LCFCPP.Startup.AddPayStack(services);
                $.$wtdm.LCFCP._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591238832)
            
            //--TRIMMABLE-BOUNDARY-START(12886206128)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886206128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12886206128)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wtdm.LCFCP.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296271536)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296271536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296271536)
            
            //--TRIMMABLE-BOUNDARY-START(4296271536)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296271536)
            
            static $h = 1304240;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591238832),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1304240,
      "h": 8591238832,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591238832),
//--TRIMMABLE-BOUNDARY-START(12886206128),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 1304240,
      "h": 12886206128,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886206128)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296271536),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1304240,
      "h": 4296271536,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296271536)
  ],
  "h": 1304240
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1304240)
        
        

        //--TRIMMABLE-BOUNDARY-START(517808)
        $asm.$cls(`$wtdm.LCFCP.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180386992)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$wtdm.LCFCPP.PayStackPayment.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$wtdm.LCFCPP.PayStackPayment().$ctor$6();
                    }, $wxmmJb ??= {"r":2752627,"n":"","d":517808,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$wtdm.LCFCPR.RemitaPayment.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$wtdm.LCFCPR.RemitaPayment().$ctor$3();
                    }, $VwbJEa ??= {"r":2752627,"n":"","d":517808,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$wtdm.LCFCPS.BankAccountInputEditor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$wtdm.LCFCPS.BankAccountInputEditor().$ctor$5();
                    }, $ryFPPc ??= {"r":2752627,"n":"","d":517808,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$wtdm.LCFCPS.PaymentDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$wtdm.LCFCPS.PaymentDetails().$ctor$5();
                    }, $qvdSnj ??= {"r":2752627,"n":"","d":517808,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$wtdm.LCFCPS.PaymentInput.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$wtdm.LCFCPS.PaymentInput().$ctor$5();
                    }, $rXJTRb ??= {"r":2752627,"n":"","d":517808,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180386992)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295485104)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295485104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295485104)
            
            //--TRIMMABLE-BOUNDARY-START(4295485104)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295485104)
            
            static $h = 517808;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180386992),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885419696,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 517808,
      "h": 17180386992,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180386992)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295485104),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 517808,
      "h": 4295485104,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295485104)
  ],
  "h": 517808
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(517808)
        
        

        //--TRIMMABLE-BOUNDARY-START(976560)
        $asm.$cls(`$wtdm.LCFCPP.PayStackPaymentProcessor`, ($self) => class PayStackPaymentProcessor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51540584112)
            /*IResourcePathResolver*/ ResourcePathResolver = null;
            //--TRIMMABLE-BOUNDARY-END(51540584112)
            
            //--TRIMMABLE-BOUNDARY-START(4295943856)
            $ctor$1(/*IResourcePathResolver*/ resourcePathResolver)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295943856);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ResourcePathResolver = resourcePathResolver;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295943856)
            
            //--TRIMMABLE-BOUNDARY-START(55835551408)
            /*string */ get Title()
            {
                return "PayStack";
            }
            //--TRIMMABLE-BOUNDARY-END(55835551408)
            
            //--TRIMMABLE-BOUNDARY-START(12885878448)
            /*string */ get Description()
            {
                return "Supports various means of payment, Card, USSD, Transfer...";
            }
            //--TRIMMABLE-BOUNDARY-END(12885878448)
            
            //--TRIMMABLE-BOUNDARY-START(42950649520)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit(this.ResourcePathResolver.LCFCC$IResourcePathResolver$Resolve($.$wtdm.LCFCPP.PayStackPaymentProcessor.$type.Assembly.GetName().Name, "paystack/image.png", false));
            }
            //--TRIMMABLE-BOUNDARY-END(42950649520)
            
            //--TRIMMABLE-BOUNDARY-START(8590911152)
            /*bool */ CanPayFor(/*string?*/ serviceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590911152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590911152)
            
            //--TRIMMABLE-BOUNDARY-START(47245616816)
            /*RenderFragment<ContainerContext<object?>> */ Pay(/*Money*/ amount, /*string*/ title, /*string*/ referenceId, /*Action<PaymentResult>*/ onPaid, /*string?*/ description, /*string?*/ serviceName, /*IContact?*/ payer, /*Dictionary<IContact, Money>?*/ payeeSplit, /*PaymentModel?*/ createPayment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245616816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                    {
                        builder.OpenComponent$1($.$hDPm.LCFCCA$3.AuthenticationTicket, 1);
                        builder.AddAttribute$3(2, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$GfYa.LCFCA.DecodedAuthenticationTicket)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                            {
                                builder.OpenComponent$1($.$wtdm.LCFCPP.PayStackPayment, 1);
                                builder.AddAttribute$5(2, "CustomerEmail", (payer?.LCFCC$2$IContact$Email ?? null) ?? context.Data.Email);
                                builder.AddAttribute$5(3, "Reference", $.$hDPm.LCFCI.UIPaymentProcessorExtension.AsReferenceId$1(referenceId));
                                builder.AddAttribute$4(4, "Amount", $.$clone(amount));
                                builder.AddAttribute$4(5, "PaymentFeatures", $.$box(0/*PayStackPaymentFeatures.Default*/ | 1/*PayStackPaymentFeatures.AutoPay*/, $.$wtdm.LCFCPP.PayStackPaymentFeatures));
                                builder.AddAttribute$7($.$hDPm.LCFCI.PaymentResult, 6, "OnPaid", $.$mac.MAC.EventCallback.Factory.Create$8($.$hDPm.LCFCI.PaymentResult, this, onPaid));
                                builder.AddAttribute$5(7, "ServiceName", serviceName);
                                builder.CloseComponent();
                            }, $RCmOdc ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":976560,"h":0,"f":17825794});
                        }), $sgjbie ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h}],"n":"","d":976560,"h":0,"f":17825794}));
                        builder.CloseComponent();
                    }, $SisUCe ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":976560,"h":0,"f":17825794});
                }, $HKHHva ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":976560,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(47245616816)
            
            //--TRIMMABLE-BOUNDARY-START(4360591018)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IUIPaymentProcessor.CanPayFor(string?)
            LCFCI$IUIPaymentProcessor$CanPayFor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4360591018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanPayFor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4360591018)
            
            //--TRIMMABLE-BOUNDARY-START(8655558314)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IUIPaymentProcessor.Pay(LivingThing.Core.Frameworks.Common.Data.Measurements.Money, string, string, System.Action<LivingThing.Core.Frameworks.Client.Interface.PaymentResult>, string?, string?, LivingThing.Core.Frameworks.Common.Contacts.IContact?, System.Collections.Generic.Dictionary<LivingThing.Core.Frameworks.Common.Contacts.IContact, LivingThing.Core.Frameworks.Common.Data.Measurements.Money>?, LivingThing.Core.Frameworks.Common.Models.PaymentModel?)
            LCFCI$IUIPaymentProcessor$Pay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8655558314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Pay(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8655558314)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 976560;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835551408),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655682224,
        "f": 50331649
      },
      "n": "Title",
      "d": 976560,
      "h": 55835551408,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835551408),
//--TRIMMABLE-BOUNDARY-START(12885878448),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475813040,
        "f": 50331649
      },
      "n": "Description",
      "d": 976560,
      "h": 12885878448,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885878448),
//--TRIMMABLE-BOUNDARY-START(42950649520),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065747632,
        "f": 50331649
      },
      "n": "Icon",
      "d": 976560,
      "h": 42950649520,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950649520)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590911152),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceName",
          "p": 1310721
        }
      ],
      "n": "CanPayFor",
      "d": 976560,
      "h": 8590911152,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590911152),
//--TRIMMABLE-BOUNDARY-START(47245616816),
    {
      "r": $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)).$h,
      "p": [
        {
          "n": "amount",
          "p": 27822422
        },
        {
          "n": "title",
          "p": 1310721
        },
        {
          "n": "referenceId",
          "p": 1310721
        },
        {
          "n": "onPaid",
          "p": $.$$.S.Action$$($.$hDPm.LCFCI.PaymentResult).$h
        },
        {
          "n": "description",
          "p": 1310721
        },
        {
          "n": "serviceName",
          "p": 1310721
        },
        {
          "n": "payer",
          "p": 5081430,
          "f": 65
        },
        {
          "n": "payeeSplit",
          "p": $.$$.SCG.Dictionary$$$($.$fPer.LCFCC$2.IContact, $.$fPer.LCFCDM.Money).$h,
          "f": 65
        },
        {
          "n": "createPayment",
          "p": 12592470,
          "f": 65
        }
      ],
      "n": "Pay",
      "d": 976560,
      "h": 47245616816,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245616816)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540584112),
    {
      "t": 3825064,
      "n": "ResourcePathResolver",
      "d": 976560,
      "h": 51540584112,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540584112)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295943856),
    {
      "p": [
        {
          "n": "resourcePathResolver",
          "p": 3825064
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 976560,
      "h": 4295943856,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295943856)
  ],
  "h": 976560
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCI.IUIPaymentProcessor, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.PayStack.PayStackPaymentProcessor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}PayStack${separator}PayStackPaymentProcessor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(976560)
        
        

        //--TRIMMABLE-BOUNDARY-START(1631920)
        $asm.$cls(`$wtdm.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296599216)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296599216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296599216)
            
            //--TRIMMABLE-BOUNDARY-START(4296599216)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296599216)
            
            static $h = 1631920;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296599216),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1631920,
      "h": 4296599216,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296599216)
  ],
  "h": 1631920,
  "a": [
    {
      "t": 1566384,
      "c": 4296533680
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1631920)
        
        

        //--TRIMMABLE-BOUNDARY-START(1566384)
        $asm.$cls(`$wtdm.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296533680)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296533680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296533680)
            
            //--TRIMMABLE-BOUNDARY-START(4296533680)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296533680)
            
            static $h = 1566384;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296533680),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1566384,
      "h": 4296533680,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296533680)
  ],
  "h": 1566384
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1566384)
        
        

        //--TRIMMABLE-BOUNDARY-START(845488)
        $asm.$str(`$wtdm.LCFCPP.PayStackPaymentFeatures`, ($self) => class PayStackPaymentFeatures extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static AutoPay = 1;
            static Default = 0;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(845488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "AutoPay": 1n,
                    "Default": 0n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295812784)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295812784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295812784)
            
            //--TRIMMABLE-BOUNDARY-START(4295812784)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295812784)
            
            static $h = 845488;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180714672),
    {
      "t": 845488,
      "n": "None",
      "d": 845488,
      "h": 17180714672,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180714672),
//--TRIMMABLE-BOUNDARY-START(8590780080),
    {
      "t": 845488,
      "n": "AutoPay",
      "d": 845488,
      "h": 8590780080,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590780080),
//--TRIMMABLE-BOUNDARY-START(12885747376),
    {
      "t": 845488,
      "n": "Default",
      "d": 845488,
      "h": 12885747376,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885747376)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295812784),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 845488,
      "h": 4295812784,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295812784)
  ],
  "h": 845488,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.PayStack.PayStackPaymentFeatures`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}PayStack${separator}PayStackPaymentFeatures`; }
        });
        //--TRIMMABLE-BOUNDARY-END(845488)
        
        

        //--TRIMMABLE-BOUNDARY-START(255664)
        $asm.$cls(`$wtdm.LCFCP._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590190256)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590190256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590190256)
            
            //--TRIMMABLE-BOUNDARY-START(4295222960)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295222960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295222960)
            
            //--TRIMMABLE-BOUNDARY-START(4295222960)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295222960)
            
            static $h = 255664;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590190256),
    {
      "r": 65537,
      "n": "Execute",
      "d": 255664,
      "h": 8590190256,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590190256)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295222960),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 255664,
      "h": 4295222960,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295222960)
  ],
  "h": 255664
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(255664)
        
        

        //--TRIMMABLE-BOUNDARY-START(1173168)
        $asm.$cls(`$wtdm.LCFCPR.RemitaPayment`, ($self) => class RemitaPayment extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(167504897712)
            /*IJavaScriptRunner*/ JavaScript = null;
            //--TRIMMABLE-BOUNDARY-END(167504897712)
            
            //--TRIMMABLE-BOUNDARY-START(51540780720)
            /*IAssetsCollection*/ Assets$1 = null;
            //--TRIMMABLE-BOUNDARY-END(51540780720)
            
            //--TRIMMABLE-BOUNDARY-START(68720649904)
            /*string*/ CustomerId = null;
            //--TRIMMABLE-BOUNDARY-END(68720649904)
            
            //--TRIMMABLE-BOUNDARY-START(64425682608)
            /*string*/ CustomerFirstName = null;
            //--TRIMMABLE-BOUNDARY-END(64425682608)
            
            //--TRIMMABLE-BOUNDARY-START(73015617200)
            /*string*/ CustomerLastName = null;
            //--TRIMMABLE-BOUNDARY-END(73015617200)
            
            //--TRIMMABLE-BOUNDARY-START(60130715312)
            /*string*/ CustomerEmail = null;
            //--TRIMMABLE-BOUNDARY-END(60130715312)
            
            //--TRIMMABLE-BOUNDARY-START(171799865008)
            /*string*/ Narration = null;
            //--TRIMMABLE-BOUNDARY-END(171799865008)
            
            //--TRIMMABLE-BOUNDARY-START(47245813424)
            /*double*/ Amount = 0;
            //--TRIMMABLE-BOUNDARY-END(47245813424)
            
            //--TRIMMABLE-BOUNDARY-START(184684766896)
            /*EventCallback<string>*/ OnPaid;
            //--TRIMMABLE-BOUNDARY-END(184684766896)
            
            //--TRIMMABLE-BOUNDARY-START(180389799600)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389799600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Assets$1.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResolvePath("remita/remita-pay-inline.bundle.js", true, false, false) ], null, null));
                $.$hDPm.LCFCI.JavaScriptRunnerExtension.QueueOnce(this.JavaScript, "remita.init", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mj.MJ.DotNetObjectReference.Create($.$wtdm.LCFCPR.RemitaPayment, this) ], null, null));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(180389799600)
            
            //--TRIMMABLE-BOUNDARY-START(176094832304)
            /*void */ OnClick()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094832304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.JavaScript.LCFCI$IJavaScriptRunner$Queue$1("remita.pay", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ (() =>
                {
                    //new $.$wtdm.LCFCPR.RemitaPaymentOptions()
                    const $t1 = $.$wtdm.LCFCPR.RemitaPaymentOptions;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Key = "UzAwMDAyMzM1ODV8NDMxNDE4NjB8YzEwNzdiNTg3ZWJkOWZlMTc0MzI2MjRiZGI4NzQ0NDNjMmVhMzQ4YmNkMzBhMmVjM2M5MjQ3MjI1ZDE4YmY1MDkxYTQxOWJmNDhkYWM5N2YzMjNjOGY0NGUyMzU4MWIxMjhmZWU2N2NiMWY0NjU1MjYzYjI3MjZlYmUxOTI1OTg=";
                    $i1.Amount = this.Amount;
                    $i1.CustomerId = this.CustomerId;
                    $i1.Narration = this.Narration;
                    $i1.FirstName = this.CustomerFirstName;
                    $i1.LastName = this.CustomerLastName;
                    $i1.Email = this.CustomerEmail;
                    return $i1;
                })() ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(176094832304)
            
            //--TRIMMABLE-BOUNDARY-START(188979734192)
            /*string */ get OptimizedComponentName()
            {
                return "remitapayment";
            }
            //--TRIMMABLE-BOUNDARY-END(188979734192)
            
            //--TRIMMABLE-BOUNDARY-START(270584112816)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584112816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch2 = parameter.Name;
                switch($switch2)
                {
                    case "CustomerId":
                    this.CustomerId = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "CustomerFirstName":
                    this.CustomerFirstName = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "CustomerLastName":
                    this.CustomerLastName = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "CustomerEmail":
                    this.CustomerEmail = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Narration":
                    this.Narration = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Amount":
                    this.Amount = $.$cast(parameter.Value, $.$$.S.Double);
                    return true;
                    case "OnPaid":
                    this.OnPaid = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$$.S.String));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(270584112816)
            
            //--TRIMMABLE-BOUNDARY-START(163209930416)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209930416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.JavaScript = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, serviceProvider);
                this.Assets$1 = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCH.IAssetsCollection, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(163209930416)
            
            //--TRIMMABLE-BOUNDARY-START(55835748016)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835748016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 0);
                __builder.AddComponentParameter(1, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                __builder.AddComponentParameter(2, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.OnClick))));
                __builder.AddComponentParameter(3, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.OwnAttributes(null)));
                __builder.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(5, "img");
                    __builder2.AddAttribute$5(6, "src", this.ResolvePath("remita/remita-integration-2.png", true, false, false));
                    __builder2.CloseElement();
                }), $FXDpse ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1173168,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(55835748016)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(42950846128)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950846128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950846128)
            
            //--TRIMMABLE-BOUNDARY-START(42950846128)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(42950846128)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(167504897712)
                this.JavaScript = null;
                //--TRIMMABLE-BOUNDARY-END(167504897712)
                
                //--TRIMMABLE-BOUNDARY-START(51540780720)
                this.Assets$1 = null;
                //--TRIMMABLE-BOUNDARY-END(51540780720)
                
                //--TRIMMABLE-BOUNDARY-START(184684766896)
                this.OnPaid = $.$default($.$mac.MAC.EventCallback$$($.$$.S.String));
                //--TRIMMABLE-BOUNDARY-END(184684766896)
                
            }
            static $h = 1173168;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(167504897712),
    {
      "p": 64509610,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145159344,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249109276336,
        "f": 83886081
      },
      "n": "JavaScript",
      "d": 1173168,
      "h": 167504897712,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167504897712),
//--TRIMMABLE-BOUNDARY-START(51540780720),
    {
      "p": 61691562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195486384,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206159603376,
        "f": 83886081
      },
      "n": "Assets",
      "o": "@$1",
      "d": 1173168,
      "h": 51540780720,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540780720),
//--TRIMMABLE-BOUNDARY-START(68720649904),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965290160,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231929407152,
        "f": 83886081
      },
      "n": "CustomerId",
      "d": 1173168,
      "h": 68720649904,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720649904),
//--TRIMMABLE-BOUNDARY-START(64425682608),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375355568,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223339472560,
        "f": 83886081
      },
      "n": "CustomerFirstName",
      "d": 1173168,
      "h": 64425682608,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425682608),
//--TRIMMABLE-BOUNDARY-START(73015617200),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555224752,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240519341744,
        "f": 83886081
      },
      "n": "CustomerLastName",
      "d": 1173168,
      "h": 73015617200,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015617200),
//--TRIMMABLE-BOUNDARY-START(60130715312),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785420976,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214749537968,
        "f": 83886081
      },
      "n": "CustomerEmail",
      "d": 1173168,
      "h": 60130715312,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130715312),
//--TRIMMABLE-BOUNDARY-START(171799865008),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735093936,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257699210928,
        "f": 83886081
      },
      "n": "Narration",
      "d": 1173168,
      "h": 171799865008,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171799865008),
//--TRIMMABLE-BOUNDARY-START(47245813424),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605551792,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569668784,
        "f": 83886081
      },
      "n": "Amount",
      "d": 1173168,
      "h": 47245813424,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245813424),
//--TRIMMABLE-BOUNDARY-START(184684766896),
    {
      "p": $.$mac.MAC.EventCallback$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325028528,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266289145520,
        "f": 83886081
      },
      "n": "OnPaid",
      "d": 1173168,
      "h": 184684766896,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184684766896),
//--TRIMMABLE-BOUNDARY-START(188979734192),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914963120,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1173168,
      "h": 188979734192,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(188979734192)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(180389799600),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1173168,
      "h": 180389799600,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(180389799600),
//--TRIMMABLE-BOUNDARY-START(176094832304),
    {
      "r": 65537,
      "n": "OnClick",
      "d": 1173168,
      "h": 176094832304,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176094832304),
//--TRIMMABLE-BOUNDARY-START(270584112816),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1173168,
      "h": 270584112816,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(270584112816),
//--TRIMMABLE-BOUNDARY-START(163209930416),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1173168,
      "h": 163209930416,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163209930416),
//--TRIMMABLE-BOUNDARY-START(55835748016),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1173168,
      "h": 55835748016,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55835748016)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42950846128),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1173168,
      "h": 42950846128,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950846128)
  ],
  "h": 1173168
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.Remita.RemitaPayment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}Remita${separator}RemitaPayment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1173168)
        
        

        //--TRIMMABLE-BOUNDARY-START(1369776)
        $asm.$cls(`$wtdm.LCFCPS.BankAccountInputEditor`, ($self) => class BankAccountInputEditor extends $.$hDPm.LCFCI.BaseInputEditor$$($.$fPer.LCFCD.BankAccount)
        {
            //--TRIMMABLE-BOUNDARY-START(60130911920)
            /*string */ get OptimizedComponentName()
            {
                return "bankaccountinputeditor";
            }
            //--TRIMMABLE-BOUNDARY-END(60130911920)
            
            //--TRIMMABLE-BOUNDARY-START(17181238960)
            /*IEnumerable<Bank>?*/ static banks = null;
            //--TRIMMABLE-BOUNDARY-END(17181238960)
            
            //--TRIMMABLE-BOUNDARY-START(8591304368)
            /*string?*/ accountNumber = null;
            //--TRIMMABLE-BOUNDARY-END(8591304368)
            
            //--TRIMMABLE-BOUNDARY-START(12886271664)
            /*Bank*/ bank;
            //--TRIMMABLE-BOUNDARY-END(12886271664)
            
            //--TRIMMABLE-BOUNDARY-START(21476206256)
            /*IEnumerable<BankAccount>?*/ beneficiaries = null;
            //--TRIMMABLE-BOUNDARY-END(21476206256)
            
            //--TRIMMABLE-BOUNDARY-START(64425879216)
            /*BankAccount*/ resolvedAccount;
            //--TRIMMABLE-BOUNDARY-END(64425879216)
            
            //--TRIMMABLE-BOUNDARY-START(68720846512)
            /*bool*/ resolvingBank = false;
            //--TRIMMABLE-BOUNDARY-END(68720846512)
            
            //--TRIMMABLE-BOUNDARY-START(81605748400)
            /*InputEditorFeatures */ get SupportedFeatures()
            {
                return super.SupportedFeatures & ~32/*InputEditorFeatures.Pad*/;
            }
            //--TRIMMABLE-BOUNDARY-END(81605748400)
            
            //--TRIMMABLE-BOUNDARY-START(30066140848)
            /*Task *//*async*/  CheckAccount()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066140848);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.accountNumber !== null && this.bank.Name !== null)
                    {
                        this.resolvedAccount = new $.$fPer.LCFCD.BankAccount();
                        this.resolvingBank = true;
                        try
                        {
                            let $t1, $r1;
                            this.resolvedAccount = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.BankAccount, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankAccount)))().$ctor(this,  (/**/ server) =>
                            {
                                return server.LCFCP$IBankingRemoteService$ResolveAccount($.$clone(this.bank), this.accountNumber);
                            }, $zTeAfb ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankAccount)).$h,"p":[{"n":"server","p":411416}],"n":"","d":1369776,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                            if (this.resolvedAccount.AccountName !== null)
                            {
                                this.CurrentValue = $.$clone(this.resolvedAccount);
                            }
                        }
                        finally
                        {
                            {
                                this.resolvingBank = false;
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30066140848)
            
            //--TRIMMABLE-BOUNDARY-START(77310781104)
            /*Task *//*async*/  SelectBank()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310781104);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$wtdm.LCFCPS.BankAccountInputEditor.banks !== null)
                    {
                        let $t2, $r2;
                        let $t3, $r3;
                        this.bank = $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCD.Bank, (($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.Select$1($.$hDPm.LCFCI.ViewConfiguration, $.$fPer.LCFCD.Bank, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.Select$1($.$fPer.LCFCD.Bank, $.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.Bank), $.$wtdm.LCFCPS.BankAccountInputEditor.banks, new ($.$$.S.Func$$$($.$fPer.LCFCD.Bank, $.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.Bank)))().$ctor(this,  (/*b*/ b) =>
                        {
                            return new ($.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.Bank))().$ctor$3($.$clone(b));
                        }, $wBWqbb ??= {"r":$.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.Bank).$h,"p":[{"n":"b","p":5409110}],"n":"","d":1369776,"h":0,"f":17825794})), $.$$.SCG.IEnumerable$$($.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.Bank)), $.$$.SCG.IEnumerable$$($.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCD.Bank))), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Select Bank", false), null, 0, 1, 35184372092928n | 65536n | 8n | 8192n, null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)))));
                        ($t3 = this.CheckAccount(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77310781104)
            
            //--TRIMMABLE-BOUNDARY-START(55835944624)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t6, $r6;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835944624);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$wtdm.LCFCPS.BankAccountInputEditor.banks ??= ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute($.$nYKj.LCFCP.IBankingRemoteService, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.Bank), this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.Bank))))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.Bank))), $.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.Bank)), async ($asnycContext) => 
                        {
                            let $t5, $r5;
                            return ($t5 = server.LCFCP$IBankingRemoteService$GetBanks($.$fPer.LCFCD.DataFilter.Default), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        });
                    }, $YDHJek ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.Bank))).$h,"p":[{"n":"server","p":411416}],"n":"","d":1369776,"h":0,"f":17829890}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    this.beneficiaries = ($t6 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage.LCFCS$5$IPersistentStorageService$GetItem($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.BankAccount), "beneficiary"), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    this.accountNumber = this.Value.AccountNumber;
                    this.bank = this.Value.Bank;
                    ($t7 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55835944624)
            
            //--TRIMMABLE-BOUNDARY-START(51540977328)
            /*ValueTask<bool> *//*async*/  LCFCCD$1$IDataListSelectableController$LivingThing$Core$Frameworks$Common$Data$BankAccount$OnSelected(/*DataListSelection<BankAccount>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540977328);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.accountNumber = selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data.AccountNumber;
                    this.bank = selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data.Bank;
                    ($t8 = this.CheckAccount(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    _ = this.StateChanged(false, false, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor\\BankAccountInputEditor.razor.cs", "OnSelected", 73);
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51540977328)
            
            //--TRIMMABLE-BOUNDARY-START(73015813808)
            /*ValueTask */ SaveBeneficiary()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015813808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Data.BankAccount>?*/ let __ca1__;
                this.beneficiaries = ((__ca1__ = this.beneficiaries) !== null ? ($.$sl.SL.Enumerable.Reverse($.$fPer.LCFCD.BankAccount, $.$sl.SL.Enumerable.Distinct$1($.$fPer.LCFCD.BankAccount, $.$sl.SL.Enumerable.Concat($.$fPer.LCFCD.BankAccount, __ca1__, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.BankAccount), [this.resolvedAccount], null, null)))) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.BankAccount), [this.resolvedAccount], null, null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.BankAccount), [this.resolvedAccount], null, null));
                return this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage.LCFCS$5$IPersistentStorageService$SetItem($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.BankAccount), "beneficiary", this.beneficiaries);
            }
            //--TRIMMABLE-BOUNDARY-END(73015813808)
            
            //--TRIMMABLE-BOUNDARY-START(25771173552)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771173552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pd");
                __builder.AddMultipleAttributes(2, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(this.OwnAttributes(null))));
                $.$wtdm._LCFCPSB.TypeInference.CreateInputEditor_0($.$$.S.String, __builder, 3, 4, "mgt", 5, "Enter 10 digit Account Number", 6, this.accountNumber, 7, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$2($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredBindSetter$1($.$$.S.String, new ($.$$.S.Func$$$($.$$.S.String, $.$$.STT.Task))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.accountNumber = __value;
                    return $.$mac.MACC.RuntimeHelpers.InvokeAsynchronousDelegate$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.CheckAccount));
                }, $camnHg ??= {"r":178454529,"p":[{"n":"__value","p":1310721}],"n":"","d":1369776,"h":0,"f":17825794}), this.accountNumber), this.accountNumber)), 8, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                {
                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "accountNumber"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                }, $qKtJhb ??= {"r":38797349,"n":"","d":1369776,"h":0,"f":17825794})).Invoke()));
                __builder.AddMarkupContent(9, "\r\n    ");
                __builder.OpenElement(10, "div");
                __builder.AddAttribute$5(11, "class", "mgt flex pd clip wf");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 12, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.SelectBank)));
                if (this.bank.Name === null)
                {
                    __builder.AddMarkupContent(13, "<span class=\"op-8 fill\">Select Bank</span>");
                }
                else 
                {
                    __builder.OpenElement(14, "b");
                    __builder.AddAttribute$5(15, "class", "nowrap fill");
                    __builder.AddContent$4(16, this.bank.Name);
                    __builder.CloseElement();
                }
                __builder.AddMarkupContent(17, "<i class=\"mdi mdi-chevron-right\"></i>");
                __builder.CloseElement();
                if (this.resolvedAccount.AccountName !== null)
                {
                    __builder.OpenElement(18, "div");
                    __builder.AddAttribute$5(19, "class", "pd bg-success-01 mgt flex");
                    __builder.OpenElement(20, "b");
                    __builder.AddContent$4(21, this.resolvedAccount.AccountName);
                    __builder.CloseElement();
                    __builder.AddMarkupContent(22, "\r\n            ");
                    __builder.OpenElement(23, "button");
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 24, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.SaveBeneficiary)));
                    __builder.AddAttribute$5(25, "class", "mgl-a mdi mdi-content-save bg-transparent");
                    __builder.AddAttribute$5(26, "title", "Save Beneficiary");
                    __builder.AddAttribute$5(27, "type", "button");
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                if (this.resolvingBank)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 28);
                    __builder.AddComponentParameter(29, "Class", "fsz-30");
                    __builder.CloseComponent();
                }
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Data.BankAccount>?*/ let __ca1__;
                if ((__ca1__ = this.beneficiaries) !== null ? $.$sl.SL.Enumerable.Any$1($.$fPer.LCFCD.BankAccount, __ca1__) : false)
                {
                    __builder.OpenElement(30, "div");
                    __builder.AddAttribute$5(31, "class", "bg-card corner mgt");
                    __builder.AddMarkupContent(32, "<div class=\"bdb pdb\"><h4 class=\"mg-0\">Saved Beneficiaries</h4></div>\r\n            ");
                    $.$wtdm._LCFCPSB.TypeInference.CreateDataList_1($.$fPer.LCFCD.BankAccount, __builder, 33, 34, this.beneficiaries, 35, this, 36, 35184372092928n | 65536n, 37, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fPer.LCFCD.BankAccount, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fPer.LCFCD.BankAccount))))().$ctor(this,  (/*b*/ b) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(38, "div");
                            __builder2.AddAttribute$5(39, "class", "flex pdy");
                            __builder2.OpenElement(40, "div");
                            __builder2.AddAttribute$5(41, "class", "stack");
                            __builder2.OpenElement(42, "b");
                            __builder2.AddContent$4(43, b.Data.AccountName);
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(44, "\r\n                        ");
                            __builder2.OpenElement(45, "small");
                            __builder2.AddContent$4(46, b.Data.Bank.Name);
                            __builder2.AddContent$4(47, " ");
                            __builder2.AddContent$4(48, b.Data.AccountNumber);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }, $zpKlZg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1369776,"h":0,"f":17825794});
                    }, $kZKWPi ??= {"r":6881395,"p":[{"n":"b","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fPer.LCFCD.BankAccount, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fPer.LCFCD.BankAccount)).$h}],"n":"","d":1369776,"h":0,"f":17825794}));
                    __builder.CloseElement();
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(25771173552)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296337072)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296337072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296337072)
            
            //--TRIMMABLE-BOUNDARY-START(4296337072)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296337072)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12886271664)
                this.bank = $.$default($.$fPer.LCFCD.Bank);
                //--TRIMMABLE-BOUNDARY-END(12886271664)
                
                //--TRIMMABLE-BOUNDARY-START(64425879216)
                this.resolvedAccount = $.$default($.$fPer.LCFCD.BankAccount);
                //--TRIMMABLE-BOUNDARY-END(64425879216)
                
            }
            static $h = 1369776;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCI.BaseInputEditor$$($.$fPer.LCFCD.BankAccount); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130911920),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656075440,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1369776,
      "h": 60130911920,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130911920),
//--TRIMMABLE-BOUNDARY-START(81605748400),
    {
      "p": 27612842,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246010032,
        "f": 50364420
      },
      "n": "SupportedFeatures",
      "d": 1369776,
      "h": 81605748400,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(81605748400)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066140848),
    {
      "r": 178454529,
      "n": "CheckAccount",
      "d": 1369776,
      "h": 30066140848,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(30066140848),
//--TRIMMABLE-BOUNDARY-START(77310781104),
    {
      "r": 178454529,
      "n": "SelectBank",
      "d": 1369776,
      "h": 77310781104,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(77310781104),
//--TRIMMABLE-BOUNDARY-START(55835944624),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1369776,
      "h": 55835944624,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(55835944624),
//--TRIMMABLE-BOUNDARY-START(73015813808),
    {
      "r": 181338113,
      "n": "SaveBeneficiary",
      "d": 1369776,
      "h": 73015813808,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015813808),
//--TRIMMABLE-BOUNDARY-START(25771173552),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1369776,
      "h": 25771173552,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25771173552)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181238960),
    {
      "t": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.Bank).$h,
      "n": "banks",
      "d": 1369776,
      "h": 17181238960,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17181238960),
//--TRIMMABLE-BOUNDARY-START(8591304368),
    {
      "t": 1310721,
      "n": "accountNumber",
      "d": 1369776,
      "h": 8591304368,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591304368),
//--TRIMMABLE-BOUNDARY-START(12886271664),
    {
      "t": 5409110,
      "n": "bank",
      "d": 1369776,
      "h": 12886271664,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886271664),
//--TRIMMABLE-BOUNDARY-START(21476206256),
    {
      "t": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.BankAccount).$h,
      "n": "beneficiaries",
      "d": 1369776,
      "h": 21476206256,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476206256),
//--TRIMMABLE-BOUNDARY-START(64425879216),
    {
      "t": 5474646,
      "n": "resolvedAccount",
      "d": 1369776,
      "h": 64425879216,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425879216),
//--TRIMMABLE-BOUNDARY-START(68720846512),
    {
      "t": 262145,
      "n": "resolvingBank",
      "d": 1369776,
      "h": 68720846512,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68720846512)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296337072),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1369776,
      "h": 4296337072,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296337072)
  ],
  "h": 1369776
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$$.S.IDisposable, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCD.BankAccount)), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCD.BankAccount)), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCD.BankAccount)), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$fPer.LCFCD.BankAccount), $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$fPer.LCFCD.BankAccount), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$fPer.LCFCD.BankAccount), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCC$1.IManagedBaseComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.Shared.BankAccountInputEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}Shared${separator}BankAccountInputEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1369776)
        
        

        //--TRIMMABLE-BOUNDARY-START(714416)
        $asm.$cls(`$wtdm.LCFCPP.PayStackPayment`, ($self) => class PayStackPayment extends $.$hDPm.LCFCCB$4.Button
        {
            //--TRIMMABLE-BOUNDARY-START(236223915696)
            /*string */ get OptimizedComponentName()
            {
                return "paystackpayment button";
            }
            //--TRIMMABLE-BOUNDARY-END(236223915696)
            
            //--TRIMMABLE-BOUNDARY-START(382252803760)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252803760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "PaymentFeatures":
                    this.PaymentFeatures = $.$cast(parameter.Value, $.$wtdm.LCFCPP.PayStackPaymentFeatures);
                    return true;
                    case "ServiceName":
                    this.ServiceName = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "SubAccount":
                    this.SubAccount = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Reference":
                    this.Reference = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "CustomerEmail":
                    this.CustomerEmail = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Amount":
                    this.Amount = $.$cast(parameter.Value, $.$fPer.LCFCDM.Money);
                    return true;
                    case "OnPaid":
                    this.OnPaid = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$hDPm.LCFCI.PaymentResult));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(382252803760)
            
            //--TRIMMABLE-BOUNDARY-START(210454111920)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454111920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.JavaScript = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, serviceProvider);
                this.Assets$1 = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCH.IAssetsCollection, serviceProvider);
                this.Options = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$meo.MEO.IOptions$$($.$wtdm.LCFCPP.PayStackConfiguration), serviceProvider);
                this.ServiceOptions = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$meo.MEO.IOptionsSnapshot$$($.$wtdm.LCFCPP.PayStackConfiguration), serviceProvider);
                this.MessagePipeFactory = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UrvY.LCFCM.IMessagePipeFactory, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(210454111920)
            
            //--TRIMMABLE-BOUNDARY-START(214749079216)
            /*IJavaScriptRunner*/ JavaScript = null;
            //--TRIMMABLE-BOUNDARY-END(214749079216)
            
            //--TRIMMABLE-BOUNDARY-START(64425223856)
            /*IAssetsCollection*/ Assets$1 = null;
            //--TRIMMABLE-BOUNDARY-END(64425223856)
            
            //--TRIMMABLE-BOUNDARY-START(240518882992)
            /*IOptions<PayStackConfiguration>*/ Options = null;
            //--TRIMMABLE-BOUNDARY-END(240518882992)
            
            //--TRIMMABLE-BOUNDARY-START(270583654064)
            /*IOptionsSnapshot<PayStackConfiguration>*/ ServiceOptions = null;
            //--TRIMMABLE-BOUNDARY-END(270583654064)
            
            //--TRIMMABLE-BOUNDARY-START(219044046512)
            /*IMessagePipeFactory*/ MessagePipeFactory = null;
            //--TRIMMABLE-BOUNDARY-END(219044046512)
            
            //--TRIMMABLE-BOUNDARY-START(249108817584)
            /*PayStackPaymentFeatures*/ PaymentFeatures = 0;
            //--TRIMMABLE-BOUNDARY-END(249108817584)
            
            //--TRIMMABLE-BOUNDARY-START(266288686768)
            /*string?*/ ServiceName = null;
            //--TRIMMABLE-BOUNDARY-END(266288686768)
            
            //--TRIMMABLE-BOUNDARY-START(377957836464)
            /*string?*/ SubAccount = null;
            //--TRIMMABLE-BOUNDARY-END(377957836464)
            
            //--TRIMMABLE-BOUNDARY-START(261993719472)
            /*string*/ Reference = null;
            //--TRIMMABLE-BOUNDARY-END(261993719472)
            
            //--TRIMMABLE-BOUNDARY-START(81605093040)
            /*string*/ CustomerEmail = null;
            //--TRIMMABLE-BOUNDARY-END(81605093040)
            
            //--TRIMMABLE-BOUNDARY-START(60130256560)
            /*Money*/ Amount;
            //--TRIMMABLE-BOUNDARY-END(60130256560)
            
            //--TRIMMABLE-BOUNDARY-START(231928948400)
            /*EventCallback<PaymentResult>*/ OnPaid;
            //--TRIMMABLE-BOUNDARY-END(231928948400)
            
            //--TRIMMABLE-BOUNDARY-START(257698752176)
            /*TaskCompletionSource*/ ready = null;
            //--TRIMMABLE-BOUNDARY-END(257698752176)
            
            //--TRIMMABLE-BOUNDARY-START(55835289264)
            $ctor$6()
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835289264);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Theme = $.$fPer.LCFC.Theme.Transparent;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835289264)
            
            //--TRIMMABLE-BOUNDARY-START(68720191152)
            /*IMessagePipe?*/ bankPaymentNotificationPipe = null;
            //--TRIMMABLE-BOUNDARY-END(68720191152)
            
            //--TRIMMABLE-BOUNDARY-START(253403784880)
            /*Task */ RaiseHasPaid(/*string*/ _ref)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403784880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnPaid.InvokeAsync$1((() =>
                {
                    //new $.$hDPm.LCFCI.PaymentResult()
                    const $t2 = $.$hDPm.LCFCI.PaymentResult;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Reference = "PayStack/" + $.$strNN(_ref);
                    $i2.Amount = $.$clone(this.Amount);
                    return $i2;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(253403784880)
            
            //--TRIMMABLE-BOUNDARY-START(227633981104)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t4, $r4;
                    let $t5, $r5;
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227633981104);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    ($t4 = this.Assets$1.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "https://js.paystack.co/v1/inline.js", this.ResolvePath("LivingThing.Core.Frameworks.Client.Payment.js", true, false, false) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    ($t5 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.WaitForScriptLoad(this.JavaScript, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "paystack", "window.PaystackPop" ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    ($t6 = this.JavaScript.LCFCI$IJavaScriptRunner$Queue$1("paystack.init", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mj.MJ.DotNetObjectReference.Create($.$wtdm.LCFCPP.PayStackPayment, this) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    this.ready.SetResult();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(227633981104)
            
            //--TRIMMABLE-BOUNDARY-START(244813850288)
            /*void */ Paid(/*PayStackPaymentResult*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813850288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.RaiseHasPaid(result.Reference);
            }
            //--TRIMMABLE-BOUNDARY-END(244813850288)
            
            //--TRIMMABLE-BOUNDARY-START(77310125744)
            /*void */ Closed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310125744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(77310125744)
            
            //--TRIMMABLE-BOUNDARY-START(90195027632)
            /*ValueTask *//*async*/  Execute(/*MouseEventArgs?*/ arg)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t7, $r7;
                    let $t8, $r8;
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195027632);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t7 = super.Execute(arg), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    ($t8 = this.ready.Task, ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    /*var*/ let key = (this.Options.MEO$IOptions$LivingThing$Core$Frameworks$Client$Payment$PayStack$PayStackConfiguration$Value?.APIKey ?? null) ?? "pk_test_1170c1d80b09c74f8ee26a5bc0ab150f1aeed985";
                    if (this.ServiceName !== null)
                    {
                        key = (this.ServiceOptions.MEO$IOptionsSnapshot$LivingThing$Core$Frameworks$Client$Payment$PayStack$PayStackConfiguration$Get(this.ServiceName)?.APIKey ?? null) ?? key;
                    }
                    ($t9 = this.JavaScript.LCFCI$IJavaScriptRunner$Queue$1("paystack.pay", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ (() =>
                    {
                        //new $.$wtdm.LCFCPP.PayStackPaymentAPIOptions()
                        const $t10 = $.$wtdm.LCFCPP.PayStackPaymentAPIOptions;
                        const $i10 = new $t10();
                        $i10.$ctor$1();
                        $i10.Key = key;
                        $i10.Amount = $.$cast((this.Amount.Value * 100), $.$$.S.Int32);
                        $i10.Currency = this.Amount.Unit === 2/*MoneyUnitTypes.Dollar*/ ? "USD" : "NGN";
                        $i10.Email = this.CustomerEmail;
                        $i10.SubAccount = this.SubAccount;
                        $i10.Ref = $.$hDPm.LCFCI.UIPaymentProcessorExtension.AsReferenceId$1(this.Reference);
                        return $i10;
                    })() ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    if (this.bankPaymentNotificationPipe === null)
                    {
                        let $t11, $r11;
                        this.bankPaymentNotificationPipe = ($t11 = $.$UrvY.LCFCM.MessagePipeFactoryExtension.Join(this.MessagePipeFactory, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2($.$hDPm.LCFCI.UIPaymentProcessorExtension.AsReferenceId$1(this.Reference)), new $.$kVHt.LCFCH.WebSocketClientMetadata()), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                        this.bankPaymentNotificationPipe.LCFCM$IMessagePipe$Subscribe($.$nYKj.LCFCP.BankPayment, new ($.$$.S.Action$$($.$nYKj.LCFCP.BankPayment))().$ctor(this,  (/*payment*/ payment) =>
                        {
                            this.RaiseHasPaid(payment.Reference);
                        }, $YBtaMe ??= {"r":65537,"p":[{"n":"payment","p":83736}],"n":"","d":714416,"h":0,"f":17825794}));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(90195027632)
            
            //--TRIMMABLE-BOUNDARY-START(223339013808)
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t13, $r13;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(223339013808);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (firstRender && ((this.PaymentFeatures & (1/*PayStackPaymentFeatures.AutoPay*/)) == (1/*PayStackPaymentFeatures.AutoPay*/)))
                    {
                        let $t12, $r12;
                        ($t12 = this.Execute(null), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                    }
                    ($t13 = super.OnAfterRenderAsync(firstRender), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(223339013808)
            
            //--TRIMMABLE-BOUNDARY-START(85900060336)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900060336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.bankPaymentNotificationPipe?.S$IDisposable$Dispose();
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(85900060336)
            
            //--TRIMMABLE-BOUNDARY-START(73015158448)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015158448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ChildContent === null)
                {
                    this.ChildContent = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(0, "\r\n    ");
                        __builder2.AddMarkupContent(1, "<h2 class=\"mg-0 text-center\">Pay with Card</h2>\r\n    ");
                        __builder2.AddContent$1(2, this.GetImage(this.AttributesFor("img")));
                        __builder2.AddMarkupContent(3, "\r\n");
                    }, $dnnzXd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":714416,"h":0,"f":17825794});
                }
                if (!((this.PaymentFeatures & (1/*PayStackPaymentFeatures.AutoPay*/)) == (1/*PayStackPaymentFeatures.AutoPay*/)))
                {
                    /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this, super.BuildRenderTree);
                    __builder.AddContent$1(4, view);
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 5);
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015158448)
            
            //--TRIMMABLE-BOUNDARY-START(206159144624)
            /*RenderFragment */ GetImage(/*IEnumerable<KeyValuePair<Stringy, object?>>?*/ attributes)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206159144624);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(6, "img");
                        __builder2.AddAttribute$5(7, "class", "mawp-10");
                        __builder2.AddAttribute$5(8, "src", this.ResolvePath("paystack/image.png", true, false, false));
                        __builder2.AddMultipleAttributes(9, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(attributes)));
                        __builder2.CloseElement();
                    }, $FnUwlc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":714416,"h":0,"f":17825794});
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206159144624)
            
            //--TRIMMABLE-BOUNDARY-START(55835289264)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(55835289264)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(214749079216)
                this.JavaScript = null;
                //--TRIMMABLE-BOUNDARY-END(214749079216)
                
                //--TRIMMABLE-BOUNDARY-START(64425223856)
                this.Assets$1 = null;
                //--TRIMMABLE-BOUNDARY-END(64425223856)
                
                //--TRIMMABLE-BOUNDARY-START(240518882992)
                this.Options = null;
                //--TRIMMABLE-BOUNDARY-END(240518882992)
                
                //--TRIMMABLE-BOUNDARY-START(270583654064)
                this.ServiceOptions = null;
                //--TRIMMABLE-BOUNDARY-END(270583654064)
                
                //--TRIMMABLE-BOUNDARY-START(219044046512)
                this.MessagePipeFactory = null;
                //--TRIMMABLE-BOUNDARY-END(219044046512)
                
                //--TRIMMABLE-BOUNDARY-START(249108817584)
                this.PaymentFeatures = 0;
                //--TRIMMABLE-BOUNDARY-END(249108817584)
                
                //--TRIMMABLE-BOUNDARY-START(261993719472)
                this.Reference = null;
                //--TRIMMABLE-BOUNDARY-END(261993719472)
                
                //--TRIMMABLE-BOUNDARY-START(81605093040)
                this.CustomerEmail = null;
                //--TRIMMABLE-BOUNDARY-END(81605093040)
                
                //--TRIMMABLE-BOUNDARY-START(60130256560)
                this.Amount = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(60130256560)
                
                //--TRIMMABLE-BOUNDARY-START(231928948400)
                this.OnPaid = $.$default($.$mac.MAC.EventCallback$$($.$hDPm.LCFCI.PaymentResult));
                //--TRIMMABLE-BOUNDARY-END(231928948400)
                
                //--TRIMMABLE-BOUNDARY-START(257698752176)
                this.ready = new $.$$.STT.TaskCompletionSource().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(257698752176)
                
            }
            static $h = 714416;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCB$4.Button; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(236223915696),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324569776,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 714416,
      "h": 236223915696,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(236223915696),
//--TRIMMABLE-BOUNDARY-START(214749079216),
    {
      "p": 64509610,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554766000,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943392432,
        "f": 83886081
      },
      "n": "JavaScript",
      "d": 714416,
      "h": 214749079216,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214749079216),
//--TRIMMABLE-BOUNDARY-START(64425223856),
    {
      "p": 61691562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374896816,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763523248,
        "f": 83886081
      },
      "n": "Assets",
      "o": "@$1",
      "d": 714416,
      "h": 64425223856,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425223856),
//--TRIMMABLE-BOUNDARY-START(240518882992),
    {
      "p": $.$meo.MEO.IOptions$$($.$wtdm.LCFCPP.PayStackConfiguration).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914504368,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330713196208,
        "f": 83886081
      },
      "n": "Options",
      "d": 714416,
      "h": 240518882992,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(240518882992),
//--TRIMMABLE-BOUNDARY-START(270583654064),
    {
      "p": $.$meo.MEO.IOptionsSnapshot$$($.$wtdm.LCFCPP.PayStackConfiguration).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274242736,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 365072934576,
        "f": 83886081
      },
      "n": "ServiceOptions",
      "d": 714416,
      "h": 270583654064,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(270583654064),
//--TRIMMABLE-BOUNDARY-START(219044046512),
    {
      "p": 407004,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144700592,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313533327024,
        "f": 83886081
      },
      "n": "MessagePipeFactory",
      "d": 714416,
      "h": 219044046512,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(219044046512),
//--TRIMMABLE-BOUNDARY-START(249108817584),
    {
      "p": 845488,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504438960,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339303130800,
        "f": 83886081
      },
      "n": "PaymentFeatures",
      "d": 714416,
      "h": 249108817584,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(249108817584),
//--TRIMMABLE-BOUNDARY-START(266288686768),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684308144,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356482999984,
        "f": 83886081
      },
      "n": "ServiceName",
      "d": 714416,
      "h": 266288686768,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(266288686768),
//--TRIMMABLE-BOUNDARY-START(377957836464),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864177328,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 373662869168,
        "f": 83886081
      },
      "n": "SubAccount",
      "d": 714416,
      "h": 377957836464,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(377957836464),
//--TRIMMABLE-BOUNDARY-START(261993719472),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094373552,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347893065392,
        "f": 83886081
      },
      "n": "Reference",
      "d": 714416,
      "h": 261993719472,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(261993719472),
//--TRIMMABLE-BOUNDARY-START(81605093040),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964831408,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353457840,
        "f": 83886081
      },
      "n": "CustomerEmail",
      "d": 714416,
      "h": 81605093040,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605093040),
//--TRIMMABLE-BOUNDARY-START(60130256560),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784962224,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279173588656,
        "f": 83886081
      },
      "n": "Amount",
      "d": 714416,
      "h": 60130256560,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130256560),
//--TRIMMABLE-BOUNDARY-START(231928948400),
    {
      "p": $.$mac.MAC.EventCallback$$($.$hDPm.LCFCI.PaymentResult).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734635184,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322123261616,
        "f": 83886081
      },
      "n": "OnPaid",
      "d": 714416,
      "h": 231928948400,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231928948400)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(382252803760),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 714416,
      "h": 382252803760,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(382252803760),
//--TRIMMABLE-BOUNDARY-START(210454111920),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 714416,
      "h": 210454111920,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(210454111920),
//--TRIMMABLE-BOUNDARY-START(253403784880),
    {
      "r": 178454529,
      "p": [
        {
          "n": "_ref",
          "p": 1310721
        }
      ],
      "n": "RaiseHasPaid",
      "d": 714416,
      "h": 253403784880,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(253403784880),
//--TRIMMABLE-BOUNDARY-START(227633981104),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 714416,
      "h": 227633981104,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(227633981104),
//--TRIMMABLE-BOUNDARY-START(244813850288),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 1042096
        }
      ],
      "n": "Paid",
      "d": 714416,
      "h": 244813850288,
      "f": 16777217,
      "a": [
        {
          "t": 2818162,
          "c": 8592752754
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(244813850288),
//--TRIMMABLE-BOUNDARY-START(77310125744),
    {
      "r": 65537,
      "n": "Closed",
      "d": 714416,
      "h": 77310125744,
      "f": 16777217,
      "a": [
        {
          "t": 2818162,
          "c": 8592752754
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310125744),
//--TRIMMABLE-BOUNDARY-START(90195027632),
    {
      "r": 181338113,
      "p": [
        {
          "n": "arg",
          "p": 6750325
        }
      ],
      "n": "Execute",
      "d": 714416,
      "h": 90195027632,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(90195027632),
//--TRIMMABLE-BOUNDARY-START(223339013808),
    {
      "r": 178454529,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": 714416,
      "h": 223339013808,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(223339013808),
//--TRIMMABLE-BOUNDARY-START(85900060336),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 714416,
      "h": 85900060336,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900060336),
//--TRIMMABLE-BOUNDARY-START(73015158448),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 714416,
      "h": 73015158448,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(73015158448),
//--TRIMMABLE-BOUNDARY-START(206159144624),
    {
      "r": 6881395,
      "p": [
        {
          "n": "attributes",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)).$h,
          "f": 65
        }
      ],
      "n": "GetImage",
      "d": 714416,
      "h": 206159144624,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(206159144624)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(257698752176),
    {
      "t": 179568641,
      "n": "ready",
      "d": 714416,
      "h": 257698752176,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(257698752176),
//--TRIMMABLE-BOUNDARY-START(68720191152),
    {
      "t": 341468,
      "n": "bankPaymentNotificationPipe",
      "d": 714416,
      "h": 68720191152,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68720191152)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835289264),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 714416,
      "h": 55835289264,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835289264)
  ],
  "h": 714416
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IOrderedViewContent$$($.$hDPm.LCFCCB$4.ButtonSet), $.$hDPm.LCFCC$1.IOrderedViewContent, $.$fPer.LCFCD.IOrderedData, $.$$.S.IDisposable, $.$hDPm.LCFCI.IButton, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCC$1.IWidgetComponent, $.$vWqU.LCFCC.IBackButtonHandler, $.$vWqU.LCFCC.ITabable, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.PayStack.PayStackPayment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}PayStack${separator}PayStackPayment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(714416)
        
        

        //--TRIMMABLE-BOUNDARY-START(1435312)
        $asm.$cls(`$wtdm.LCFCPS.PaymentDetails`, ($self) => class PaymentDetails extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$Iaui.LCFCM.PaymentModel)
        {
            //--TRIMMABLE-BOUNDARY-START(38656140976)
            /*string */ get OptimizedComponentName()
            {
                return "paymentdetails";
            }
            //--TRIMMABLE-BOUNDARY-END(38656140976)
            
            //--TRIMMABLE-BOUNDARY-START(42951108272)
            /*PaymentModel*/ payment = null;
            //--TRIMMABLE-BOUNDARY-END(42951108272)
            
            //--TRIMMABLE-BOUNDARY-START(12886337200)
            /*IClipboardAccessor?*/ clipboard = null;
            //--TRIMMABLE-BOUNDARY-END(12886337200)
            
            //--TRIMMABLE-BOUNDARY-START(21476271792)
            /*bool */ FilterProperty(/*SchemaContext*/ schema, /*IPropertyDescriptor*/ property)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476271792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (property.LCFCD$1$IPropertyDescriptor$Name === "TargetId" && this.payment.TargetId.Empty)
                {
                    return false;
                }
                return $.$fPer.LCFCD$1.PropertyDescriptorExtesions.SchemaFilter(property, $.$clone(schema), null);
            }
            //--TRIMMABLE-BOUNDARY-END(21476271792)
            
            //--TRIMMABLE-BOUNDARY-START(17181304496)
            /*Task *//*async*/  CopyValue()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181304496);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*string?*/ let __ca1__;
                    ($t1 = this.clipboard.LCFCC$IClipboardAccessor$SetAsync(((__ca1__ = this.payment.Value) !== null ? $.$$.S.String.Trim$1.call(__ca1__, /*_*/ 95) : null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    _ = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Toast("Value copied!", null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17181304496)
            
            //--TRIMMABLE-BOUNDARY-START(34361173680)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361173680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.clipboard = $.$mxdi.MED.ServiceProviderServiceExtensions.GetService($.$vWqU.LCFCC.IClipboardAccessor, this.UnitOfWork.LCFCI$IClientUnitOfWork$ServiceProvider);
                this.payment = this.ViewModel;
                if (this.payment.OrderStatus !== 5/*PaymentOrderTransactionStatus.Completed*/ && this.payment.OrderStatus !== 6/*PaymentOrderTransactionStatus.Error*/ && this.payment.OrderStatus !== 7/*PaymentOrderTransactionStatus.Refunded*/)
                {
                    _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            while(!this.IsDisposed)
                            {
                                let $t2, $r2;
                                let $t3, $r3;
                                ($t2 = $.$$.STT.Task.Delay$1(15000), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                                /*var*/ let _p = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.TryReadSingle($.$Iaui.LCFCM.PaymentModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(this.payment.Identifier), null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                if (_p !== null)
                                {
                                    this.payment = _p;
                                    _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor\\PaymentDetails.razor.cs", "OnInitialized", 54);
                                    if (this.payment.OrderStatus === 5/*PaymentOrderTransactionStatus.Completed*/ || this.payment.OrderStatus === 6/*PaymentOrderTransactionStatus.Error*/ || this.payment.OrderStatus === 7/*PaymentOrderTransactionStatus.Refunded*/)
                                    {
                                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                                    }
                                }
                            }
                        });
                    }, $TmZuob ??= {"r":178454529,"n":"","d":1435312,"h":0,"f":17829890}));
                }
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(34361173680)
            
            //--TRIMMABLE-BOUNDARY-START(8591369904)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591369904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "flex");
                __builder.AddMarkupContent(2, "<div class=\"stack\"><div class=\"hx-05 wx-05 round bg-primary flex mgx-a\"><i class=\"mdi mdi-check mg-a fsz-40\"></i></div>\r\n        <span class=\"text-center mgx-a\">Payment</span></div>\r\n    ");
                __builder.AddMarkupContent(3, "<div class=\"stack mgy-a fill\"><div class=\"bdt bdw-2 bd-primary\"></div>\r\n        <span class=\"text-center\">_</span></div>\r\n    ");
                __builder.OpenElement(4, "div");
                __builder.AddAttribute$5(5, "class", "stack");
                __builder.OpenElement(6, "div");
                __builder.AddAttribute$5(7, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("hx-05" + " wx-05") + " round") + " bg-") + $.$strNN((this.payment.OrderStatus < 5/*PaymentOrderTransactionStatus.Completed*/ ? "info" : "primary"))) + " flex") + " mgx-a");
                __builder.OpenElement(8, "i");
                __builder.AddAttribute$5(9, "class", $.$strNN($.$strNN($.$strNN("mdi" + " mdi-") + $.$strNN((this.payment.OrderStatus < 5/*PaymentOrderTransactionStatus.Completed*/ ? "loading mdi-spin" : "check"))) + " mg-a") + " fsz-40");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\r\n        ");
                __builder.AddMarkupContent(11, "<span class=\"text-center mgx-a\">Processing</span>");
                __builder.CloseElement();
                __builder.AddMarkupContent(12, "\r\n    ");
                __builder.AddMarkupContent(13, "<div class=\"stack mgy-a fill\"><div class=\"bdt bdw-2 bd-primary\"></div>\r\n        <span class=\"text-center\">_</span></div>\r\n    ");
                __builder.OpenElement(14, "div");
                __builder.AddAttribute$5(15, "class", "stack");
                __builder.OpenElement(16, "div");
                __builder.AddAttribute$5(17, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("hx-05" + " wx-05") + " round") + " bg-") + $.$strNN((this.payment.OrderStatus === 5/*PaymentOrderTransactionStatus.Completed*/ ? "primary" : this.payment.OrderStatus === 6/*PaymentOrderTransactionStatus.Error*/ ? "fatal" : "info"))) + " flex") + " mgx-a");
                __builder.OpenElement(18, "i");
                __builder.AddAttribute$5(19, "class", $.$strNN($.$strNN($.$strNN("mdi" + " mdi-") + $.$strNN((this.payment.OrderStatus === 5/*PaymentOrderTransactionStatus.Completed*/ ? "check" : "close"))) + " mg-a") + " fsz-40");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(20, "\r\n        ");
                __builder.OpenElement(21, "span");
                __builder.AddAttribute$5(22, "class", "text-center mgx-a");
                __builder.AddContent$4(23, this.payment.OrderStatus === 5/*PaymentOrderTransactionStatus.Completed*/ ? "Completed" : this.payment.OrderStatus === 6/*PaymentOrderTransactionStatus.Error*/ ? "Error" : "");
                __builder.CloseElement();
                __builder.CloseElement();
                if (this.payment.OrderStatus === 6/*PaymentOrderTransactionStatus.Error*/ || this.payment.OrderStatus === 7/*PaymentOrderTransactionStatus.Refunded*/)
                {
                    __builder.AddMarkupContent(24, "<div class=\"stack mgy-a fill\"><div class=\"bdt bdw-2 bd-primary\"></div>\r\n            <span class=\"text-center\">_</span></div>\r\n        ");
                    __builder.OpenElement(25, "div");
                    __builder.AddAttribute$5(26, "class", "stack");
                    __builder.OpenElement(27, "div");
                    __builder.AddAttribute$5(28, "class", "hx-05 wx-05 round bg-primary flex mgx-a");
                    __builder.OpenElement(29, "i");
                    __builder.AddAttribute$5(30, "class", $.$strNN($.$strNN($.$strNN("mdi" + " mdi-") + $.$strNN((this.payment.OrderStatus === 7/*PaymentOrderTransactionStatus.Refunded*/ ? "check" : "loading mdi-spin"))) + " mg-a") + " fsz-40");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(31, "\r\n            ");
                    __builder.AddMarkupContent(32, "<span class=\"text-center mgx-a\">Refund</span>");
                    __builder.CloseElement();
                }
                __builder.CloseElement();
                if (this.payment.OrderStatus === 6/*PaymentOrderTransactionStatus.Error*/)
                {
                    __builder.AddMarkupContent(33, "<p class=\"text-center\">Your refund will complete processing in less than 24hr</p>");
                }
                /*string?*/ let __ca1__;
                if (!$.$$.S.String.IsNullOrEmpty(((__ca1__ = this.payment.Value) !== null ? $.$$.S.String.Trim$1.call(__ca1__, /*_*/ 95) : null)))
                {
                    __builder.OpenElement(34, "div");
                    __builder.AddAttribute$5(35, "class", "pd corner-5 mg bg-success-02 text-center flex");
                    __builder.OpenElement(36, "h3");
                    __builder.AddAttribute$5(37, "class", "mg-0");
                    __builder.AddAttribute$5(38, "style", "word-break: break-word;");
                    __builder.AddContent$4(39, this.payment.Value);
                    __builder.CloseElement();
                    if (this.clipboard !== null)
                    {
                        __builder.OpenElement(40, "button");
                        __builder.AddAttribute$5(41, "class", "mdi mdi-content-copy bg-transparent mgb-a fsz-20");
                        __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 42, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.CopyValue)));
                        __builder.CloseElement();
                    }
                    __builder.CloseElement();
                }
                __builder.AddMarkupContent(43, "<h4 class=\"mgb-2\">Payment Details</h4>\r\n");
                $.$wtdm._LCFCPSP.TypeInference.CreatePropertySheet_0($.$Iaui.LCFCM.PaymentModel, __builder, 44, 45, this.payment, 46, "pd bg-card bd", 47, 35184372092928n | 8388608n, 48, "FilterProperty", 49, "pdy-2 clip", 50, "fw-bold");
            }
            //--TRIMMABLE-BOUNDARY-END(8591369904)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296402608)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296402608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296402608)
            
            //--TRIMMABLE-BOUNDARY-START(4296402608)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296402608)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42951108272)
                this.payment = null;
                //--TRIMMABLE-BOUNDARY-END(42951108272)
                
            }
            static $h = 1435312;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$Iaui.LCFCM.PaymentModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656140976),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066206384,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1435312,
      "h": 38656140976,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38656140976)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476271792),
    {
      "r": 262145,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        },
        {
          "n": "property",
          "p": 40733014
        }
      ],
      "n": "FilterProperty",
      "d": 1435312,
      "h": 21476271792,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476271792),
//--TRIMMABLE-BOUNDARY-START(17181304496),
    {
      "r": 178454529,
      "n": "CopyValue",
      "d": 1435312,
      "h": 17181304496,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(17181304496),
//--TRIMMABLE-BOUNDARY-START(34361173680),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1435312,
      "h": 34361173680,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34361173680),
//--TRIMMABLE-BOUNDARY-START(8591369904),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1435312,
      "h": 8591369904,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591369904)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42951108272),
    {
      "t": 12592470,
      "n": "payment",
      "d": 1435312,
      "h": 42951108272,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42951108272),
//--TRIMMABLE-BOUNDARY-START(12886337200),
    {
      "t": 2776488,
      "n": "clipboard",
      "d": 1435312,
      "h": 12886337200,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886337200)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296402608),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1435312,
      "h": 4296402608,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296402608)
  ],
  "h": 1435312
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.Shared.PaymentDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}Shared${separator}PaymentDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1435312)
        
        

        //--TRIMMABLE-BOUNDARY-START(1500848)
        $asm.$cls(`$wtdm.LCFCPS.PaymentInput`, ($self) => class PaymentInput extends $.$hDPm.LCFCI.BaseInputEditor$$($.$Iaui.LCFCM.PaymentModel)
        {
            //--TRIMMABLE-BOUNDARY-START(30066271920)
            /*string */ get OptimizedComponentName()
            {
                return "paymentinput";
            }
            //--TRIMMABLE-BOUNDARY-END(30066271920)
            
            //--TRIMMABLE-BOUNDARY-START(4296468144)
            /*string?*/ _ref = null;
            //--TRIMMABLE-BOUNDARY-END(4296468144)
            
            //--TRIMMABLE-BOUNDARY-START(25771304624)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    let $t3, $r3;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771304624);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let paymentResult = ($t1 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Payment.LCFCI$IUIPaymentProcessorProvider$ProcessPayment($.$fPer.LCFCDM.Money.op_Implicit$1(this.Value.Amount), this.Value.Name, this.Value.Reference, this.Value.Summary, null, null, null, ($t2 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IReadOnlyAuthenticationService$GetTicket(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2))), null, this.Value), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    this._ref = paymentResult.Reference;
                    ($t3 = this.ValueChanged.InvokeAsync$1(this.Value), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    ($t4 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25771304624)
            
            //--TRIMMABLE-BOUNDARY-START(12886402736)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886402736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._ref !== null)
                {
                    __builder.AddMarkupContent(0, "<div class=\"text-center stack\"><i class=\"mgx-a fsz-100 mdi mdi-check-circle cl-success\"></i>\r\n        <h3>Payment Successful!</h3></div>");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886402736)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591435440)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591435440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591435440)
            
            //--TRIMMABLE-BOUNDARY-START(8591435440)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8591435440)
            
            static $h = 1500848;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCI.BaseInputEditor$$($.$Iaui.LCFCM.PaymentModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066271920),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476337328,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1500848,
      "h": 30066271920,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30066271920)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771304624),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1500848,
      "h": 25771304624,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(25771304624),
//--TRIMMABLE-BOUNDARY-START(12886402736),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1500848,
      "h": 12886402736,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886402736)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296468144),
    {
      "t": 1310721,
      "n": "_ref",
      "d": 1500848,
      "h": 4296468144,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296468144)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591435440),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1500848,
      "h": 8591435440,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591435440)
  ],
  "h": 1500848
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$$.S.IDisposable, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$fPer.LCFC.ISelectOption$$($.$Iaui.LCFCM.PaymentModel)), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$Iaui.LCFCM.PaymentModel), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$fPer.LCFC.ISelectOption$$($.$Iaui.LCFCM.PaymentModel)), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$fPer.LCFC.ISelectOption$$($.$Iaui.LCFCM.PaymentModel)), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$Iaui.LCFCM.PaymentModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$Iaui.LCFCM.PaymentModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Payment.Shared.PaymentInput`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Payment${separator}Shared${separator}PaymentInput`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1500848)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Payment"));
})();
//--TRIMMABLE-BOUNDARY-END(59056)
