var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/// <reference path="../../LivingThing.Core.Frameworks.Client.Blazor.Library/Components/Heading/Heading.razor.ts"></reference>
Define("paystack", {
    init: function (dotnet) {
        this.dotnet = dotnet;
    },
    pay: function (options) {
        var _this = this;
        var handler = PaystackPop.setup(__assign(__assign({}, options), { metadata: {
                custom_fields: [
                    {
                        display_name: "Mobile Number",
                        variable_name: "mobile_number",
                        value: "+2348012345678"
                    }
                ]
            }, callback: function (response) {
                _this.dotnet.invokeMethodAsync("Paid", response);
            }, onClose: function () {
                _this.dotnet.invokeMethodAsync("Closed");
            } }));
        handler.openIframe();
    }
});
/// <reference path="../../LivingThing.Core.Frameworks.Client.Blazor.Library/Components/Heading/Heading.razor.ts"></reference>
Define("remita", {
    init: function (dotnet) {
        this.dotnet = dotnet;
    },
    pay: function (options) {
        var _this = this;
        var paymentEngine = RmPaymentEngine.init(__assign(__assign({}, options), { onSuccess: function (response) {
                _this.dotnet.invokeMethodAsync("Paid", response);
            }, onError: function (response) {
                _this.dotnet.invokeMethodAsync("Error", response);
            }, onClose: function () {
                _this.dotnet.invokeMethodAsync("Closed");
            } }));
        paymentEngine.showPaymentWidget();
    }
});
