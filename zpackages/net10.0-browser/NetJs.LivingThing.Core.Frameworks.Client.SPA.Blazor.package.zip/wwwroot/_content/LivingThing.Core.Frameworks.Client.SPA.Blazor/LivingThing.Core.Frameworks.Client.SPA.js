Define("application", {
    init: function (app) {
        window.addEventListener("keydown", function (event) {
            //if (event.keyCode == 8) { //backspace
            //    // Prevent default (disable the back button behavior)
            //    event.preventDefault();
            //    app.invokeMethodAsync("NavigateBack");
            //}
        });
        document.addEventListener('backbutton', function () {
            var result = app.invokeMethodAsync("NavigateBack");
            result.then(function (backed) {
                if (backed) {
                    //window.history.pushState('', null, window.location.pathname);
                }
                else { //nothing to back
                    //tell user to press back again to exit
                }
            });
        });
        window.history.pushState('', null, window.location.pathname + window.location.search);
        window.addEventListener("popstate", function (e) {
            var result = app.invokeMethodAsync("NavigateBack");
            result.then(function (backed) {
                if (backed) {
                    //window.history.pushState('', null, window.location.pathname);
                }
                else { //nothing to back
                    //tell user to pres back again to exit
                }
            }).catch(function () {
            });
        });
    },
    navigated: function (url) {
        window.history.pushState('', null, window.location.pathname);
    },
    back: function () {
        var location = window.location.href;
        window.history.back();
        var p = new Promise(function (accept, reject) {
            setTimeout(function () {
                var newLocation = window.location.href;
                accept(location != newLocation);
            }, 20);
        });
        return p;
    }
});
